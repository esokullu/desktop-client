/*    */ package net.sbbi.upnp;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.xml.sax.Attributes;
/*    */ import org.xml.sax.helpers.DefaultHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServiceEventMessageParser
/*    */   extends DefaultHandler
/*    */ {
/* 63 */   private boolean readPropertyName = false;
/*    */   
/* 65 */   private String currentPropName = null;
/*    */   
/* 67 */   private Map changedStateVars = new HashMap();
/*    */   
/*    */ 
/*    */ 
/*    */   public Map getChangedStateVars()
/*    */   {
/* 73 */     return this.changedStateVars;
/*    */   }
/*    */   
/*    */   public void characters(char[] ch, int start, int length) {
/* 77 */     if (this.currentPropName != null) {
/* 78 */       String origChars = (String)this.changedStateVars.get(this.currentPropName);
/* 79 */       String newChars = new String(ch, start, length);
/* 80 */       if (origChars == null) {
/* 81 */         this.changedStateVars.put(this.currentPropName, newChars);
/*    */       } else {
/* 83 */         this.changedStateVars.put(this.currentPropName, origChars + newChars);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void startElement(String uri, String localName, String qName, Attributes attributes) {
/* 89 */     if (localName.equals("property")) {
/* 90 */       this.readPropertyName = true;
/* 91 */     } else if (this.readPropertyName) {
/* 92 */       this.currentPropName = localName;
/*    */     }
/*    */   }
/*    */   
/*    */   public void endElement(String uri, String localName, String qName) {
/* 97 */     if ((this.currentPropName != null) && (localName.equals(this.currentPropName))) {
/* 98 */       this.readPropertyName = false;
/* 99 */       this.currentPropName = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/ServiceEventMessageParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */