/*    */ package net.sbbi.upnp;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.commons.jxpath.xml.DOMParser;
/*    */ import org.apache.commons.jxpath.xml.XMLParser;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JXPathParser
/*    */   implements XMLParser
/*    */ {
/* 69 */   private static final Log log = LogFactory.getLog(JXPathParser.class);
/*    */   
/* 71 */   private char buggyChar = '\000';
/*    */   
/*    */   public Object parseXML(InputStream in) {
/* 74 */     StringBuffer xml = new StringBuffer();
/*    */     try {
/* 76 */       byte[] buffer = new byte['Ȁ'];
/* 77 */       int readen = 0;
/* 78 */       while ((readen = in.read(buffer)) != -1) {
/* 79 */         xml.append(new String(buffer, 0, readen));
/*    */       }
/*    */     } catch (IOException ex) {
/* 82 */       log.error("IOException occured during XML reception", ex);
/* 83 */       return null;
/*    */     }
/* 85 */     String doc = xml.toString();
/* 86 */     log.debug("Readen raw xml doc:\n" + doc);
/* 87 */     if (doc.indexOf(this.buggyChar) != -1) {
/* 88 */       doc = doc.replace(this.buggyChar, ' ');
/*    */     }
/*    */     
/* 91 */     ByteArrayInputStream in2 = new ByteArrayInputStream(doc.getBytes());
/* 92 */     DOMParser parser = new DOMParser();
/* 93 */     return parser.parseXML(in2);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/JXPathParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */