/*     */ package net.sbbi.upnp.devices;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.sbbi.upnp.services.UPNPService;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UPNPDevice
/*     */ {
/*  67 */   private static final Log log = LogFactory.getLog(UPNPDevice.class);
/*     */   
/*     */   protected String deviceType;
/*     */   
/*     */   protected String friendlyName;
/*     */   protected String manufacturer;
/*     */   protected URL manufacturerURL;
/*     */   protected URL presentationURL;
/*     */   protected String modelDescription;
/*     */   protected String modelName;
/*     */   protected String modelNumber;
/*     */   protected String modelURL;
/*     */   protected String serialNumber;
/*     */   protected String UDN;
/*     */   protected String USN;
/*     */   protected long UPC;
/*     */   protected List deviceIcons;
/*     */   protected List services;
/*     */   protected List childDevices;
/*     */   protected UPNPDevice parent;
/*     */   
/*     */   public URL getManufacturerURL()
/*     */   {
/*  90 */     return this.manufacturerURL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getPresentationURL()
/*     */   {
/*  99 */     return this.presentationURL;
/*     */   }
/*     */   
/*     */   public String getModelDescription() {
/* 103 */     return this.modelDescription;
/*     */   }
/*     */   
/*     */   public String getModelName() {
/* 107 */     return this.modelName;
/*     */   }
/*     */   
/*     */   public String getModelNumber() {
/* 111 */     return this.modelNumber;
/*     */   }
/*     */   
/*     */   public String getModelURL() {
/* 115 */     return this.modelURL;
/*     */   }
/*     */   
/*     */   public String getSerialNumber() {
/* 119 */     return this.serialNumber;
/*     */   }
/*     */   
/*     */   public String getUDN() {
/* 123 */     return this.UDN;
/*     */   }
/*     */   
/*     */   public String getUSN() {
/* 127 */     return this.USN;
/*     */   }
/*     */   
/*     */   public long getUPC() {
/* 131 */     return this.UPC;
/*     */   }
/*     */   
/*     */   public String getDeviceType() {
/* 135 */     return this.deviceType;
/*     */   }
/*     */   
/*     */   public String getFriendlyName() {
/* 139 */     return this.friendlyName;
/*     */   }
/*     */   
/*     */   public String getManufacturer() {
/* 143 */     return this.manufacturer;
/*     */   }
/*     */   
/*     */   public boolean isRootDevice() {
/* 147 */     return this instanceof UPNPRootDevice;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getDeviceIcons()
/*     */   {
/* 155 */     return this.deviceIcons;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getChildDevices()
/*     */   {
/* 164 */     if (this.childDevices == null) return null;
/* 165 */     List rtrVal = new ArrayList();
/* 166 */     for (Iterator itr = this.childDevices.iterator(); itr.hasNext();) {
/* 167 */       UPNPDevice device = (UPNPDevice)itr.next();
/* 168 */       rtrVal.add(device);
/* 169 */       List found = device.getChildDevices();
/* 170 */       if (found != null) {
/* 171 */         rtrVal.addAll(found);
/*     */       }
/*     */     }
/* 174 */     return rtrVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getTopLevelChildDevices()
/*     */   {
/* 184 */     if (this.childDevices == null) return null;
/* 185 */     List rtrVal = new ArrayList();
/* 186 */     for (Iterator itr = this.childDevices.iterator(); itr.hasNext();) {
/* 187 */       UPNPDevice device = (UPNPDevice)itr.next();
/* 188 */       rtrVal.add(device);
/*     */     }
/* 190 */     return rtrVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public UPNPDevice getDirectParent()
/*     */   {
/* 198 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UPNPDevice getChildDevice(String deviceURI)
/*     */   {
/* 209 */     if (log.isDebugEnabled()) log.debug("searching for device URI:" + deviceURI);
/* 210 */     if (getDeviceType().equals(deviceURI)) return this;
/* 211 */     if (this.childDevices == null) return null;
/* 212 */     for (Iterator itr = this.childDevices.iterator(); itr.hasNext();) {
/* 213 */       UPNPDevice device = (UPNPDevice)itr.next();
/* 214 */       UPNPDevice found = device.getChildDevice(deviceURI);
/* 215 */       if (found != null) {
/* 216 */         return found;
/*     */       }
/*     */     }
/* 219 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getServices()
/*     */   {
/* 227 */     if (this.services == null) return null;
/* 228 */     List rtrVal = new ArrayList();
/* 229 */     rtrVal.addAll(this.services);
/* 230 */     return rtrVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UPNPService getService(String serviceURI)
/*     */   {
/* 239 */     if (this.services == null) return null;
/* 240 */     if (log.isDebugEnabled()) log.debug("searching for service URI:" + serviceURI);
/* 241 */     for (Iterator itr = this.services.iterator(); itr.hasNext();) {
/* 242 */       UPNPService service = (UPNPService)itr.next();
/* 243 */       if (service.getServiceType().equals(serviceURI)) {
/* 244 */         return service;
/*     */       }
/*     */     }
/* 247 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UPNPService getServiceByID(String serviceID)
/*     */   {
/* 256 */     if (this.services == null) return null;
/* 257 */     if (log.isDebugEnabled()) log.debug("searching for service ID:" + serviceID);
/* 258 */     for (Iterator itr = this.services.iterator(); itr.hasNext();) {
/* 259 */       UPNPService service = (UPNPService)itr.next();
/* 260 */       if (service.getServiceId().equals(serviceID)) {
/* 261 */         return service;
/*     */       }
/*     */     }
/* 264 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getServices(String serviceURI)
/*     */   {
/* 275 */     if (this.services == null) return null;
/* 276 */     List rtrVal = new ArrayList();
/* 277 */     if (log.isDebugEnabled()) log.debug("searching for services URI:" + serviceURI);
/* 278 */     for (Iterator itr = this.services.iterator(); itr.hasNext();) {
/* 279 */       UPNPService service = (UPNPService)itr.next();
/* 280 */       if (service.getServiceType().equals(serviceURI)) {
/* 281 */         rtrVal.add(service);
/*     */       }
/*     */     }
/* 284 */     if (rtrVal.size() == 0) {
/* 285 */       return null;
/*     */     }
/* 287 */     return rtrVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 295 */     return getDeviceType();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/devices/UPNPDevice.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */