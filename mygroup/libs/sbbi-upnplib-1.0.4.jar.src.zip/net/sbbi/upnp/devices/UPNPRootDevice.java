/*     */ package net.sbbi.upnp.devices;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.sbbi.upnp.JXPathParser;
/*     */ import net.sbbi.upnp.services.UPNPService;
/*     */ import org.apache.commons.jxpath.Container;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ import org.apache.commons.jxpath.xml.DocumentContainer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UPNPRootDevice
/*     */   extends UPNPDevice
/*     */ {
/*  72 */   private static final Log log = LogFactory.getLog(UPNPRootDevice.class);
/*     */   
/*     */   private int specVersionMajor;
/*     */   
/*     */   private int specVersionMinor;
/*     */   
/*     */   private URL URLBase;
/*     */   
/*     */   private long validityTime;
/*     */   
/*     */   private long creationTime;
/*     */   
/*     */   private URL deviceDefLoc;
/*     */   
/*     */   private String deviceDefLocData;
/*     */   
/*     */   private String vendorFirmware;
/*     */   
/*     */   private String discoveryUSN;
/*     */   
/*     */   private String discoveryUDN;
/*     */   
/*     */   private DocumentContainer UPNPDevice;
/*     */   
/*     */ 
/*     */   public UPNPRootDevice(URL deviceDefLoc, String maxAge, String vendorFirmware, String discoveryUSN, String discoveryUDN)
/*     */     throws MalformedURLException, IllegalStateException
/*     */   {
/* 100 */     this(deviceDefLoc, maxAge);
/* 101 */     this.vendorFirmware = vendorFirmware;
/* 102 */     this.discoveryUSN = discoveryUSN;
/* 103 */     this.discoveryUDN = discoveryUDN;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UPNPRootDevice(URL deviceDefLoc, String maxAge, String vendorFirmware)
/*     */     throws MalformedURLException, IllegalStateException
/*     */   {
/* 117 */     this(deviceDefLoc, maxAge);
/* 118 */     this.vendorFirmware = vendorFirmware;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UPNPRootDevice(URL deviceDefLoc, String maxAge)
/*     */     throws MalformedURLException, IllegalStateException
/*     */   {
/* 131 */     this.deviceDefLoc = deviceDefLoc;
/* 132 */     DocumentContainer.registerXMLParser("DOM", new JXPathParser());
/* 133 */     this.UPNPDevice = new DocumentContainer(deviceDefLoc, "DOM");
/* 134 */     this.validityTime = (Integer.parseInt(maxAge) * 1000);
/* 135 */     this.creationTime = System.currentTimeMillis();
/*     */     
/* 137 */     JXPathContext context = JXPathContext.newContext(this);
/* 138 */     Pointer rootPtr = context.getPointer("UPNPDevice/root");
/* 139 */     JXPathContext rootCtx = context.getRelativeContext(rootPtr);
/*     */     
/* 141 */     this.specVersionMajor = Integer.parseInt((String)rootCtx.getValue("specVersion/major"));
/* 142 */     this.specVersionMinor = Integer.parseInt((String)rootCtx.getValue("specVersion/minor"));
/*     */     
/* 144 */     if ((this.specVersionMajor != 1) || (this.specVersionMinor != 0)) {
/* 145 */       throw new IllegalStateException("Unsupported device version (" + this.specVersionMajor + "." + this.specVersionMinor + ")");
/*     */     }
/* 147 */     boolean buildURLBase = true;
/* 148 */     String base = null;
/*     */     try {
/* 150 */       base = (String)rootCtx.getValue("URLBase");
/* 151 */       if ((base != null) && (base.trim().length() > 0)) {
/* 152 */         this.URLBase = new URL(base);
/* 153 */         if (log.isDebugEnabled()) log.debug("device URLBase " + this.URLBase);
/* 154 */         buildURLBase = false;
/*     */       }
/*     */       
/*     */     }
/*     */     catch (JXPathException ex) {}catch (MalformedURLException malformedEx)
/*     */     {
/* 160 */       log.warn("Error occured during device baseURL " + base + " parsing, building it from device default location", malformedEx);
/*     */     }
/* 162 */     if (buildURLBase) {
/* 163 */       String URL = deviceDefLoc.getProtocol() + "://" + deviceDefLoc.getHost() + ":" + deviceDefLoc.getPort();
/* 164 */       String path = deviceDefLoc.getPath();
/* 165 */       if (path != null) {
/* 166 */         int lastSlash = path.lastIndexOf('/');
/* 167 */         if (lastSlash != -1) {
/* 168 */           URL = URL + path.substring(0, lastSlash);
/*     */         }
/*     */       }
/* 171 */       this.URLBase = new URL(URL);
/*     */     }
/* 173 */     Pointer devicePtr = rootCtx.getPointer("device");
/* 174 */     JXPathContext deviceCtx = rootCtx.getRelativeContext(devicePtr);
/*     */     
/* 176 */     fillUPNPDevice(this, null, deviceCtx, this.URLBase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getValidityTime()
/*     */   {
/* 186 */     long elapsed = System.currentTimeMillis() - this.creationTime;
/* 187 */     return this.validityTime - elapsed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void resetValidityTime(String newMaxAge)
/*     */   {
/* 195 */     this.validityTime = (Integer.parseInt(newMaxAge) * 1000);
/* 196 */     this.creationTime = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getDeviceDefLoc()
/*     */   {
/* 204 */     return this.deviceDefLoc;
/*     */   }
/*     */   
/*     */   public int getSpecVersionMajor() {
/* 208 */     return this.specVersionMajor;
/*     */   }
/*     */   
/*     */   public int getSpecVersionMinor() {
/* 212 */     return this.specVersionMinor;
/*     */   }
/*     */   
/*     */   public String getVendorFirmware() {
/* 216 */     return this.vendorFirmware;
/*     */   }
/*     */   
/*     */   public String getDiscoveryUSN() {
/* 220 */     return this.discoveryUSN;
/*     */   }
/*     */   
/*     */   public String getDiscoveryUDN() {
/* 224 */     return this.discoveryUDN;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getURLBase()
/*     */   {
/* 233 */     return this.URLBase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void fillUPNPDevice(UPNPDevice device, UPNPDevice parent, JXPathContext deviceCtx, URL baseURL)
/*     */     throws MalformedURLException
/*     */   {
/* 246 */     device.deviceType = getMandatoryData(deviceCtx, "deviceType");
/* 247 */     if (log.isDebugEnabled()) log.debug("parsing device " + device.deviceType);
/* 248 */     device.friendlyName = getMandatoryData(deviceCtx, "friendlyName");
/* 249 */     device.manufacturer = getNonMandatoryData(deviceCtx, "manufacturer");
/* 250 */     String base = getNonMandatoryData(deviceCtx, "manufacturerURL");
/*     */     try {
/* 252 */       if (base != null) device.manufacturerURL = new URL(base);
/*     */     }
/*     */     catch (MalformedURLException ex) {}
/*     */     try
/*     */     {
/* 257 */       device.presentationURL = getURL(getNonMandatoryData(deviceCtx, "presentationURL"), this.URLBase);
/*     */     }
/*     */     catch (MalformedURLException ex) {}
/*     */     
/* 261 */     device.modelDescription = getNonMandatoryData(deviceCtx, "modelDescription");
/* 262 */     device.modelName = getMandatoryData(deviceCtx, "modelName");
/* 263 */     device.modelNumber = getNonMandatoryData(deviceCtx, "modelNumber");
/* 264 */     device.modelURL = getNonMandatoryData(deviceCtx, "modelURL");
/* 265 */     device.serialNumber = getNonMandatoryData(deviceCtx, "serialNumber");
/* 266 */     device.UDN = getMandatoryData(deviceCtx, "UDN");
/* 267 */     device.USN = this.UDN.concat("::").concat(this.deviceType);
/* 268 */     String tmp = getNonMandatoryData(deviceCtx, "UPC");
/* 269 */     if (tmp != null) {
/*     */       try {
/* 271 */         device.UPC = Long.parseLong(tmp);
/*     */       }
/*     */       catch (Exception ex) {}
/*     */     }
/*     */     
/* 276 */     device.parent = parent;
/*     */     
/* 278 */     fillUPNPServicesList(device, deviceCtx);
/* 279 */     fillUPNPDeviceIconsList(device, deviceCtx, this.URLBase);
/*     */     
/*     */     try
/*     */     {
/* 283 */       deviceListPtr = deviceCtx.getPointer("deviceList");
/*     */     } catch (JXPathException ex) {
/*     */       Pointer deviceListPtr;
/*     */       return;
/*     */     }
/*     */     Pointer deviceListPtr;
/* 289 */     JXPathContext deviceListCtx = deviceCtx.getRelativeContext(deviceListPtr);
/* 290 */     Double arraySize = (Double)deviceListCtx.getValue("count( device )");
/* 291 */     device.childDevices = new ArrayList();
/* 292 */     if (log.isDebugEnabled()) log.debug("child devices count is " + arraySize);
/* 293 */     for (int i = 1; i <= arraySize.intValue(); i++) {
/* 294 */       Pointer devicePtr = deviceListCtx.getPointer("device[" + i + "]");
/* 295 */       JXPathContext childDeviceCtx = deviceListCtx.getRelativeContext(devicePtr);
/* 296 */       UPNPDevice childDevice = new UPNPDevice();
/* 297 */       fillUPNPDevice(childDevice, device, childDeviceCtx, baseURL);
/* 298 */       if (log.isDebugEnabled()) log.debug("adding child device " + childDevice.getDeviceType());
/* 299 */       device.childDevices.add(childDevice);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getMandatoryData(JXPathContext ctx, String ctxFieldName) {
/* 304 */     String value = (String)ctx.getValue(ctxFieldName);
/* 305 */     if ((value != null) && (value.length() == 0)) {
/* 306 */       throw new JXPathException("Mandatory field " + ctxFieldName + " not provided, uncompliant UPNP device !!");
/*     */     }
/* 308 */     return value;
/*     */   }
/*     */   
/*     */   private String getNonMandatoryData(JXPathContext ctx, String ctxFieldName) {
/* 312 */     String value = null;
/*     */     try {
/* 314 */       value = (String)ctx.getValue(ctxFieldName);
/* 315 */       if ((value != null) && (value.length() == 0)) {
/* 316 */         value = null;
/*     */       }
/*     */     } catch (JXPathException ex) {
/* 319 */       value = null;
/*     */     }
/* 321 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void fillUPNPServicesList(UPNPDevice device, JXPathContext deviceCtx)
/*     */     throws MalformedURLException
/*     */   {
/* 332 */     Pointer serviceListPtr = deviceCtx.getPointer("serviceList");
/* 333 */     JXPathContext serviceListCtx = deviceCtx.getRelativeContext(serviceListPtr);
/* 334 */     Double arraySize = (Double)serviceListCtx.getValue("count( service )");
/* 335 */     if (log.isDebugEnabled()) log.debug("device services count is " + arraySize);
/* 336 */     device.services = new ArrayList();
/* 337 */     for (int i = 1; i <= arraySize.intValue(); i++)
/*     */     {
/* 339 */       Pointer servicePtr = serviceListCtx.getPointer("service[" + i + "]");
/* 340 */       JXPathContext serviceCtx = serviceListCtx.getRelativeContext(servicePtr);
/*     */       
/* 342 */       URL base = this.URLBase != null ? this.URLBase : this.deviceDefLoc;
/* 343 */       UPNPService service = new UPNPService(serviceCtx, base, this);
/* 344 */       device.services.add(service);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void fillUPNPDeviceIconsList(UPNPDevice device, JXPathContext deviceCtx, URL baseURL)
/*     */     throws MalformedURLException
/*     */   {
/*     */     try
/*     */     {
/* 359 */       iconListPtr = deviceCtx.getPointer("iconList");
/*     */     } catch (JXPathException ex) {
/*     */       Pointer iconListPtr;
/*     */       return;
/*     */     }
/*     */     Pointer iconListPtr;
/* 365 */     JXPathContext iconListCtx = deviceCtx.getRelativeContext(iconListPtr);
/* 366 */     Double arraySize = (Double)iconListCtx.getValue("count( icon )");
/* 367 */     if (log.isDebugEnabled()) log.debug("device icons count is " + arraySize);
/* 368 */     device.deviceIcons = new ArrayList();
/* 369 */     for (int i = 1; i <= arraySize.intValue(); i++)
/*     */     {
/* 371 */       DeviceIcon ico = new DeviceIcon();
/* 372 */       ico.mimeType = ((String)iconListCtx.getValue("icon[" + i + "]/mimetype"));
/* 373 */       ico.width = Integer.parseInt((String)iconListCtx.getValue("icon[" + i + "]/width"));
/* 374 */       ico.height = Integer.parseInt((String)iconListCtx.getValue("icon[" + i + "]/height"));
/* 375 */       ico.depth = Integer.parseInt((String)iconListCtx.getValue("icon[" + i + "]/depth"));
/* 376 */       ico.url = getURL((String)iconListCtx.getValue("icon[" + i + "]/url"), baseURL);
/* 377 */       if (log.isDebugEnabled()) log.debug("icon URL is " + ico.url);
/* 378 */       device.deviceIcons.add(ico);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final URL getURL(String url, URL baseURL)
/*     */     throws MalformedURLException
/*     */   {
/* 392 */     if ((url == null) || (url.trim().length() == 0)) return null;
/*     */     URL rtrVal;
/* 394 */     try { rtrVal = new URL(url);
/*     */     }
/*     */     catch (MalformedURLException malEx) {
/*     */       URL rtrVal;
/* 398 */       if (baseURL != null) {
/* 399 */         url = url.replace('\\', '/');
/* 400 */         URL rtrVal; if (url.charAt(0) != '/')
/*     */         {
/* 402 */           String externalForm = baseURL.toExternalForm();
/* 403 */           if (!externalForm.endsWith("/")) {
/* 404 */             externalForm = externalForm + "/";
/*     */           }
/* 406 */           rtrVal = new URL(externalForm + url);
/*     */         }
/*     */         else {
/* 409 */           String URLRoot = baseURL.getProtocol() + "://" + baseURL.getHost() + ":" + baseURL.getPort();
/* 410 */           rtrVal = new URL(URLRoot + url);
/*     */         }
/*     */       } else {
/* 413 */         throw malEx;
/*     */       }
/*     */     }
/* 416 */     return rtrVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDeviceDefLocData()
/*     */   {
/* 424 */     if (this.deviceDefLocData == null) {
/*     */       try {
/* 426 */         InputStream in = this.deviceDefLoc.openConnection().getInputStream();
/* 427 */         int readen = 0;
/* 428 */         byte[] buff = new byte['Ȁ'];
/* 429 */         StringBuffer strBuff = new StringBuffer();
/* 430 */         while ((readen = in.read(buff)) != -1) {
/* 431 */           strBuff.append(new String(buff, 0, readen));
/*     */         }
/* 433 */         in.close();
/* 434 */         this.deviceDefLocData = strBuff.toString();
/*     */       } catch (IOException ioEx) {
/* 436 */         return null;
/*     */       }
/*     */     }
/* 439 */     return this.deviceDefLocData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Container getUPNPDevice()
/*     */   {
/* 447 */     return this.UPNPDevice;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/devices/UPNPRootDevice.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */