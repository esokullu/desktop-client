/*    */ package net.sbbi.upnp.devices;
/*    */ 
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeviceIcon
/*    */ {
/*    */   protected String mimeType;
/*    */   protected int width;
/*    */   protected int height;
/*    */   protected int depth;
/*    */   protected URL url;
/*    */   
/*    */   public String getMimeType()
/*    */   {
/* 67 */     return this.mimeType;
/*    */   }
/*    */   
/*    */   public int getWidth() {
/* 71 */     return this.width;
/*    */   }
/*    */   
/*    */   public int getHeight() {
/* 75 */     return this.height;
/*    */   }
/*    */   
/*    */   public int getDepth() {
/* 79 */     return this.depth;
/*    */   }
/*    */   
/*    */   public URL getUrl() {
/* 83 */     return this.url;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/devices/DeviceIcon.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */