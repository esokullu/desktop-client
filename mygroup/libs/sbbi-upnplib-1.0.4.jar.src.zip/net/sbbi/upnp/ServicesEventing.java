/*     */ package net.sbbi.upnp;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.StringReader;
/*     */ import java.net.InetAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import net.sbbi.upnp.services.UPNPService;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServicesEventing
/*     */   implements Runnable
/*     */ {
/*  72 */   private static final Log log = LogFactory.getLog(ServicesEventing.class);
/*     */   
/*  74 */   private static final ServicesEventing singleton = new ServicesEventing();
/*  75 */   private boolean inService = false;
/*     */   
/*  77 */   private boolean daemon = true;
/*  78 */   private int daemonPort = 9999;
/*     */   
/*  80 */   private ServerSocket server = null;
/*     */   
/*  82 */   private List registered = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */   public static final ServicesEventing getInstance()
/*     */   {
/*  88 */     return singleton;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDaemon(boolean daemon)
/*     */   {
/*  97 */     this.daemon = daemon;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDaemonPort(int daemonPort)
/*     */   {
/* 106 */     this.daemonPort = daemonPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int register(UPNPService service, ServiceEventHandler handler, int subscriptionDuration)
/*     */     throws IOException
/*     */   {
/* 118 */     ServiceEventSubscription sub = registerEvent(service, handler, subscriptionDuration);
/* 119 */     if (sub != null) {
/* 120 */       return sub.getDurationTime();
/*     */     }
/* 122 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServiceEventSubscription registerEvent(UPNPService service, ServiceEventHandler handler, int subscriptionDuration)
/*     */     throws IOException
/*     */   {
/* 135 */     URL eventingLoc = service.getEventSubURL();
/*     */     
/* 137 */     if (eventingLoc != null)
/*     */     {
/* 139 */       if (!this.inService) startServicesEventingThread();
/* 140 */       String duration = Integer.toString(subscriptionDuration);
/* 141 */       if (subscriptionDuration == -1) {
/* 142 */         duration = "infinite";
/*     */       }
/*     */       
/* 145 */       Subscription sub = lookupSubscriber(service, handler);
/* 146 */       if (sub != null)
/*     */       {
/* 148 */         unRegister(service, handler);
/*     */       }
/*     */       
/* 151 */       StringBuffer packet = new StringBuffer(64);
/* 152 */       packet.append("SUBSCRIBE ").append(eventingLoc.getFile()).append(" HTTP/1.1\r\n");
/* 153 */       packet.append("HOST: ").append(eventingLoc.getHost()).append(":").append(eventingLoc.getPort()).append("\r\n");
/* 154 */       packet.append("CALLBACK: <http://").append(InetAddress.getLocalHost().getHostAddress()).append(":").append(this.daemonPort).append("").append(eventingLoc.getFile()).append(">\r\n");
/* 155 */       packet.append("NT: upnp:event\r\n");
/* 156 */       packet.append("Connection: close\r\n");
/* 157 */       packet.append("TIMEOUT: Second-").append(duration).append("\r\n\r\n");
/*     */       
/* 159 */       Socket skt = new Socket(eventingLoc.getHost(), eventingLoc.getPort());
/* 160 */       skt.setSoTimeout(30000);
/* 161 */       if (log.isDebugEnabled()) log.debug(packet);
/* 162 */       OutputStream out = skt.getOutputStream();
/* 163 */       out.write(packet.toString().getBytes());
/* 164 */       out.flush();
/*     */       
/* 166 */       InputStream in = skt.getInputStream();
/* 167 */       StringBuffer data = new StringBuffer();
/* 168 */       int readen = 0;
/* 169 */       byte[] buffer = new byte['Ā'];
/* 170 */       while ((readen = in.read(buffer)) != -1) {
/* 171 */         data.append(new String(buffer, 0, readen));
/*     */       }
/* 173 */       in.close();
/* 174 */       out.close();
/* 175 */       skt.close();
/* 176 */       if (log.isDebugEnabled()) log.debug(data.toString());
/* 177 */       if (data.toString().trim().length() > 0) {
/* 178 */         HttpResponse resp = new HttpResponse(data.toString());
/*     */         
/* 180 */         if (resp.getHeader().startsWith("HTTP/1.1 200 OK")) {
/* 181 */           String sid = resp.getHTTPHeaderField("SID");
/* 182 */           String actualTimeout = resp.getHTTPHeaderField("TIMEOUT");
/* 183 */           int durationTime = 0;
/*     */           
/* 185 */           if (!actualTimeout.equalsIgnoreCase("Second-infinite")) {
/* 186 */             durationTime = Integer.parseInt(actualTimeout.substring(7));
/*     */           }
/* 188 */           sub = new Subscription(null);
/* 189 */           sub.handler = handler;
/* 190 */           sub.sub = new ServiceEventSubscription(service.getServiceType(), service.getServiceId(), service.getEventSubURL(), sid, skt.getInetAddress(), durationTime);
/*     */           
/*     */ 
/* 193 */           synchronized (this.registered) {
/* 194 */             this.registered.add(sub);
/*     */           }
/* 196 */           return sub.sub;
/*     */         }
/*     */       }
/*     */     }
/* 200 */     return null;
/*     */   }
/*     */   
/*     */   private Subscription lookupSubscriber(UPNPService service, ServiceEventHandler handler) {
/*     */     Iterator i;
/* 205 */     synchronized (this.registered) {
/* 206 */       for (i = this.registered.iterator(); i.hasNext();) {
/* 207 */         Subscription sub = (Subscription)i.next();
/*     */         
/* 209 */         if ((sub.handler == handler) && (sub.sub.getServiceId().hashCode() == service.getServiceId().hashCode()) && (sub.sub.getServiceType().hashCode() == service.getServiceType().hashCode()) && (sub.sub.getServiceURL().equals(service.getEventSubURL())))
/*     */         {
/*     */ 
/*     */ 
/* 213 */           return sub;
/*     */         }
/*     */       }
/*     */     }
/* 217 */     return null;
/*     */   }
/*     */   
/*     */   private Subscription lookupSubscriber(String sid, InetAddress deviceIp) { Iterator i;
/* 221 */     synchronized (this.registered) {
/* 222 */       for (i = this.registered.iterator(); i.hasNext();) {
/* 223 */         Subscription sub = (Subscription)i.next();
/*     */         
/* 225 */         if ((sub.sub.getSID().equals(sid)) && (sub.sub.getDeviceIp().equals(deviceIp))) {
/* 226 */           return sub;
/*     */         }
/*     */       }
/*     */     }
/* 230 */     return null;
/*     */   }
/*     */   
/*     */   private Subscription lookupSubscriber(String sid) { Iterator i;
/* 234 */     synchronized (this.registered) {
/* 235 */       for (i = this.registered.iterator(); i.hasNext();) {
/* 236 */         Subscription sub = (Subscription)i.next();
/*     */         
/* 238 */         if (sub.sub.getSID().equals(sid)) {
/* 239 */           return sub;
/*     */         }
/*     */       }
/*     */     }
/* 243 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean unRegister(UPNPService service, ServiceEventHandler handler)
/*     */     throws IOException
/*     */   {
/* 255 */     URL eventingLoc = service.getEventSubURL();
/*     */     
/* 257 */     if (eventingLoc != null)
/*     */     {
/* 259 */       Subscription sub = lookupSubscriber(service, handler);
/* 260 */       if (sub != null) {
/* 261 */         synchronized (this.registered) {
/* 262 */           this.registered.remove(sub);
/*     */         }
/* 264 */         if (this.registered.size() == 0) {
/* 265 */           stopServicesEventingThread();
/*     */         }
/*     */         
/* 268 */         StringBuffer packet = new StringBuffer(64);
/* 269 */         packet.append("UNSUBSCRIBE  ").append(eventingLoc.getFile()).append(" HTTP/1.1\r\n");
/* 270 */         packet.append("HOST: ").append(eventingLoc.getHost()).append(":").append(eventingLoc.getPort()).append("\r\n");
/* 271 */         packet.append("SID: ").append(sub.sub.getSID()).append("\r\n\r\n");
/* 272 */         Socket skt = new Socket(eventingLoc.getHost(), eventingLoc.getPort());
/* 273 */         skt.setSoTimeout(30000);
/* 274 */         if (log.isDebugEnabled()) log.debug(packet);
/* 275 */         OutputStream out = skt.getOutputStream();
/* 276 */         out.write(packet.toString().getBytes());
/* 277 */         out.flush();
/*     */         
/* 279 */         InputStream in = skt.getInputStream();
/* 280 */         StringBuffer data = new StringBuffer();
/* 281 */         int readen = 0;
/* 282 */         byte[] buffer = new byte['Ā'];
/* 283 */         while ((readen = in.read(buffer)) != -1) {
/* 284 */           data.append(new String(buffer, 0, readen));
/*     */         }
/* 286 */         in.close();
/* 287 */         out.close();
/* 288 */         skt.close();
/* 289 */         if (log.isDebugEnabled()) log.debug(data.toString());
/* 290 */         if (data.toString().trim().length() > 0) {
/* 291 */           HttpResponse resp = new HttpResponse(data.toString());
/* 292 */           if (resp.getHeader().startsWith("HTTP/1.1 200 OK")) {
/* 293 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 298 */     return false;
/*     */   }
/*     */   
/*     */   private void startServicesEventingThread()
/*     */   {
/* 303 */     synchronized (singleton) {
/* 304 */       if (!this.inService) {
/* 305 */         Thread deamon = new Thread(singleton, "ServicesEventing daemon");
/* 306 */         deamon.setDaemon(this.daemon);
/* 307 */         this.inService = true;
/* 308 */         deamon.start();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void stopServicesEventingThread() {
/* 314 */     synchronized (singleton) {
/* 315 */       this.inService = false;
/*     */       try {
/* 317 */         this.server.close();
/*     */       }
/*     */       catch (IOException ex) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void run()
/*     */   {
/* 326 */     if (!Thread.currentThread().getName().equals("ServicesEventing daemon")) return;
/*     */     try {
/* 328 */       this.server = new ServerSocket(this.daemonPort);
/*     */     } catch (IOException ex) {
/* 330 */       log.error("Error during daemon server socket on port " + this.daemonPort + " creation", ex);
/* 331 */       return;
/*     */     }
/* 333 */     while (this.inService)
/*     */       try {
/* 335 */         Socket skt = this.server.accept();
/* 336 */         new Thread(new RequestProcessor(skt, null)).start();
/*     */       } catch (IOException ioEx) {
/* 338 */         if (this.inService)
/* 339 */           log.error("IO Exception during UPNP messages listening thread", ioEx);
/*     */       }
/*     */   }
/*     */   
/*     */   private class Subscription { private Subscription() {}
/*     */     
/* 345 */     Subscription(ServicesEventing.1 x1) { this(); }
/* 346 */     private ServiceEventSubscription sub = null;
/* 347 */     private ServiceEventHandler handler = null;
/*     */   }
/*     */   
/* 350 */   private class RequestProcessor implements Runnable { RequestProcessor(Socket x1, ServicesEventing.1 x2) { this(x1); }
/*     */     
/*     */     private Socket client;
/*     */     private RequestProcessor(Socket client)
/*     */     {
/* 355 */       this.client = client;
/*     */     }
/*     */     
/*     */     public void run() {
/*     */       try {
/* 360 */         this.client.setSoTimeout(30000);
/* 361 */         InputStream in = this.client.getInputStream();
/* 362 */         OutputStream out = this.client.getOutputStream();
/*     */         
/* 364 */         int readen = 0;
/* 365 */         StringBuffer data = new StringBuffer();
/* 366 */         byte[] buffer = new byte['Ā'];
/* 367 */         boolean EOF = false;
/* 368 */         while ((!EOF) && ((readen = in.read(buffer)) != -1)) {
/* 369 */           data.append(new String(buffer, 0, readen));
/*     */           
/*     */ 
/* 372 */           if (data.charAt(data.length() - 1) == 0) {
/* 373 */             EOF = true;
/*     */           }
/*     */         }
/*     */         
/* 377 */         String packet = data.toString();
/* 378 */         if (packet.trim().length() > 0)
/*     */         {
/* 380 */           if (packet.indexOf(0) != -1) packet = packet.replace('\000', ' ');
/* 381 */           HttpResponse resp = new HttpResponse(packet);
/* 382 */           if (resp.getHeader().startsWith("NOTIFY"))
/*     */           {
/* 384 */             String sid = resp.getHTTPHeaderField("SID");
/* 385 */             InetAddress deviceIp = this.client.getInetAddress();
/* 386 */             String postURL = resp.getHTTPHeaderField("SID");
/* 387 */             subscription = null;
/* 388 */             if ((sid != null) && (postURL != null)) {
/* 389 */               subscription = ServicesEventing.this.lookupSubscriber(sid, deviceIp);
/* 390 */               if (subscription == null)
/*     */               {
/* 392 */                 subscription = ServicesEventing.this.lookupSubscriber(sid);
/*     */               }
/*     */             }
/* 395 */             if (subscription != null)
/*     */             {
/* 397 */               out.write("HTTP/1.1 200 OK\r\n".getBytes());
/*     */             }
/*     */             else {
/* 400 */               out.write("HTTP/1.1 412 Precondition Failed\r\n".getBytes());
/*     */             }
/*     */             
/* 403 */             out.flush();
/* 404 */             in.close();
/* 405 */             out.close();
/* 406 */             this.client.close();
/*     */             
/* 408 */             if (subscription != null)
/*     */             {
/* 410 */               SAXParserFactory saxParFact = SAXParserFactory.newInstance();
/* 411 */               saxParFact.setValidating(false);
/* 412 */               saxParFact.setNamespaceAware(true);
/* 413 */               SAXParser parser = saxParFact.newSAXParser();
/* 414 */               ServiceEventMessageParser msgParser = new ServiceEventMessageParser();
/* 415 */               StringReader stringReader = new StringReader(resp.getBody());
/* 416 */               InputSource src = new InputSource(stringReader);
/* 417 */               parser.parse(src, msgParser);
/*     */               
/* 419 */               changedStateVars = msgParser.getChangedStateVars();
/* 420 */               for (i = changedStateVars.keySet().iterator(); i.hasNext();) {
/* 421 */                 String stateVarName = (String)i.next();
/* 422 */                 String stateVarNewVal = (String)changedStateVars.get(stateVarName);
/* 423 */                 ServicesEventing.Subscription.access$100(subscription).handleStateVariableEvent(stateVarName, stateVarNewVal);
/*     */               }
/*     */             }
/*     */           } } } catch (IOException ioEx) { ServicesEventing.Subscription subscription;
/*     */         Map changedStateVars;
/*     */         Iterator i;
/* 429 */         ServicesEventing.log.error("IO Exception during client processing thread", ioEx);
/*     */       } catch (Exception ex) {
/* 431 */         ServicesEventing.log.error("Unexpected error during client processing thread", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/ServicesEventing.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */