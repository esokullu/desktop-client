/*     */ package net.sbbi.upnp;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.MulticastSocket;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiscoveryListener
/*     */   implements Runnable
/*     */ {
/*  65 */   private static final Log log = LogFactory.getLog(DiscoveryListener.class);
/*     */   
/*  67 */   private static boolean MATCH_IP = true;
/*     */   private static final int DEFAULT_TIMEOUT = 250;
/*     */   
/*  70 */   static { String prop = System.getProperty("net.sbbi.upnp.ddos.matchip");
/*  71 */     if ((prop != null) && (prop.equals("false"))) { MATCH_IP = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*  76 */   private Map registeredHandlers = new HashMap();
/*     */   
/*  78 */   private final Object REGISTRATION_PROCESS = new Object();
/*     */   
/*  80 */   private static final DiscoveryListener singleton = new DiscoveryListener();
/*     */   
/*  82 */   private boolean inService = false;
/*  83 */   private boolean daemon = true;
/*     */   
/*     */   private MulticastSocket skt;
/*     */   
/*     */   private DatagramPacket input;
/*     */   
/*     */ 
/*     */   public static final DiscoveryListener getInstance()
/*     */   {
/*  92 */     return singleton;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDaemon(boolean daemon)
/*     */   {
/* 100 */     this.daemon = daemon;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerResultsHandler(DiscoveryResultsHandler resultsHandler, String searchTarget)
/*     */     throws IOException
/*     */   {
/* 110 */     synchronized (this.REGISTRATION_PROCESS) {
/* 111 */       if (!this.inService) startDevicesListenerThread();
/* 112 */       Set handlers = (Set)this.registeredHandlers.get(searchTarget);
/* 113 */       if (handlers == null) {
/* 114 */         handlers = new HashSet();
/* 115 */         this.registeredHandlers.put(searchTarget, handlers);
/*     */       }
/* 117 */       handlers.add(resultsHandler);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void unRegisterResultsHandler(DiscoveryResultsHandler resultsHandler, String searchTarget)
/*     */   {
/* 127 */     synchronized (this.REGISTRATION_PROCESS) {
/* 128 */       Set handlers = (Set)this.registeredHandlers.get(searchTarget);
/* 129 */       if (handlers != null) {
/* 130 */         handlers.remove(resultsHandler);
/* 131 */         if (handlers.size() == 0) {
/* 132 */           this.registeredHandlers.remove(searchTarget);
/*     */         }
/*     */       }
/* 135 */       if (this.registeredHandlers.size() == 0) {
/* 136 */         stopDevicesListenerThread();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void startDevicesListenerThread() throws IOException {
/* 142 */     synchronized (singleton) {
/* 143 */       if (!this.inService)
/*     */       {
/* 145 */         startMultiCastSocket();
/* 146 */         Thread deamon = new Thread(this, "DiscoveryListener daemon");
/* 147 */         deamon.setDaemon(this.daemon);
/* 148 */         deamon.start();
/* 149 */         while (!this.inService) {
/*     */           try
/*     */           {
/* 152 */             Thread.sleep(2L);
/*     */           }
/*     */           catch (InterruptedException ex) {}
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void stopDevicesListenerThread()
/*     */   {
/* 162 */     synchronized (singleton) {
/* 163 */       this.inService = false;
/*     */     }
/*     */   }
/*     */   
/*     */   private void startMultiCastSocket() throws IOException {
/* 168 */     int bindPort = 1901;
/* 169 */     String port = System.getProperty("net.sbbi.upnp.Discovery.bindPort");
/* 170 */     if (port != null) {
/* 171 */       bindPort = Integer.parseInt(port);
/*     */     }
/*     */     
/* 174 */     this.skt = new MulticastSocket(null);
/* 175 */     this.skt.bind(new InetSocketAddress(InetAddress.getByName("0.0.0.0"), bindPort));
/* 176 */     this.skt.setTimeToLive(4);
/* 177 */     this.skt.setSoTimeout(250);
/* 178 */     this.skt.joinGroup(InetAddress.getByName("239.255.255.250"));
/*     */     
/* 180 */     byte[] buf = new byte['ࠀ'];
/* 181 */     this.input = new DatagramPacket(buf, buf.length);
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/* 186 */     if (!Thread.currentThread().getName().equals("DiscoveryListener daemon")) {
/* 187 */       throw new RuntimeException("No right to call this method");
/*     */     }
/* 189 */     this.inService = true;
/* 190 */     while (this.inService) {
/*     */       try {
/* 192 */         listenBroadCast();
/*     */       }
/*     */       catch (SocketTimeoutException ex) {}catch (IOException ioEx)
/*     */       {
/* 196 */         log.error("IO Exception during UPNP DiscoveryListener messages listening thread", ioEx);
/*     */       } catch (Exception ex) {
/* 198 */         log.error("Fatal Error during UPNP DiscoveryListener messages listening thread, thread will exit", ex);
/* 199 */         this.inService = false;
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 204 */       this.skt.leaveGroup(InetAddress.getByName("239.255.255.250"));
/* 205 */       this.skt.close();
/*     */     }
/*     */     catch (Exception ex) {}
/*     */   }
/*     */   
/*     */   private void listenBroadCast()
/*     */     throws IOException
/*     */   {
/* 213 */     this.skt.receive(this.input);
/* 214 */     InetAddress from = this.input.getAddress();
/* 215 */     String received = new String(this.input.getData(), this.input.getOffset(), this.input.getLength());
/* 216 */     HttpResponse msg = null;
/*     */     try {
/* 218 */       msg = new HttpResponse(received);
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 221 */       if (log.isDebugEnabled()) log.debug("Skipping uncompliant HTTP message " + received);
/* 222 */       return;
/*     */     }
/* 224 */     String header = msg.getHeader();
/* 225 */     if ((header != null) && (header.startsWith("HTTP/1.1 200 OK")) && (msg.getHTTPHeaderField("st") != null))
/*     */     {
/* 227 */       String deviceDescrLoc = msg.getHTTPHeaderField("location");
/* 228 */       if ((deviceDescrLoc == null) || (deviceDescrLoc.trim().length() == 0)) {
/* 229 */         if (log.isDebugEnabled()) log.debug("Skipping SSDP message, missing HTTP header 'location' field");
/* 230 */         return;
/*     */       }
/* 232 */       URL loc = new URL(deviceDescrLoc);
/* 233 */       if (MATCH_IP) {
/* 234 */         InetAddress locHost = InetAddress.getByName(loc.getHost());
/* 235 */         if (!from.equals(locHost)) {
/* 236 */           log.warn("Discovery message sender IP " + from + " does not match device description IP " + locHost + " skipping device, set the net.sbbi.upnp.ddos.matchip system property" + " to false to avoid this check");
/*     */           
/*     */ 
/*     */ 
/* 240 */           return;
/*     */         }
/*     */       }
/* 243 */       if (log.isDebugEnabled()) log.debug("Processing " + deviceDescrLoc + " device description location");
/* 244 */       String st = msg.getHTTPHeaderField("st");
/* 245 */       if ((st == null) || (st.trim().length() == 0)) {
/* 246 */         if (log.isDebugEnabled()) log.debug("Skipping SSDP message, missing HTTP header 'st' field");
/* 247 */         return;
/*     */       }
/* 249 */       String usn = msg.getHTTPHeaderField("usn");
/* 250 */       if ((usn == null) || (usn.trim().length() == 0)) {
/* 251 */         if (log.isDebugEnabled()) log.debug("Skipping SSDP message, missing HTTP header 'usn' field");
/* 252 */         return;
/*     */       }
/* 254 */       String maxAge = msg.getHTTPFieldElement("Cache-Control", "max-age");
/* 255 */       if ((maxAge == null) || (maxAge.trim().length() == 0)) {
/* 256 */         if (log.isDebugEnabled()) log.debug("Skipping SSDP message, missing HTTP header 'max-age' field");
/* 257 */         return;
/*     */       }
/* 259 */       String server = msg.getHTTPHeaderField("server");
/* 260 */       if ((server == null) || (server.trim().length() == 0)) {
/* 261 */         if (log.isDebugEnabled()) log.debug("Skipping SSDP message, missing HTTP header 'server' field");
/* 262 */         return;
/*     */       }
/*     */       
/* 265 */       String udn = usn;
/* 266 */       int index = udn.indexOf("::");
/* 267 */       if (index != -1) udn = udn.substring(0, index);
/* 268 */       Iterator i; synchronized (this.REGISTRATION_PROCESS) {
/* 269 */         Set handlers = (Set)this.registeredHandlers.get(st);
/* 270 */         if (handlers != null) {
/* 271 */           for (i = handlers.iterator(); i.hasNext();) {
/* 272 */             DiscoveryResultsHandler handler = (DiscoveryResultsHandler)i.next();
/* 273 */             handler.discoveredDevice(usn, udn, st, maxAge, loc, server);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 278 */     else if (log.isDebugEnabled()) { log.debug("Skipping uncompliant HTTP message " + received);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/DiscoveryListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */