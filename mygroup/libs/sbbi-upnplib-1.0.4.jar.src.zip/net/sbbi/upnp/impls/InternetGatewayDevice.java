/*     */ package net.sbbi.upnp.impls;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import net.sbbi.upnp.Discovery;
/*     */ import net.sbbi.upnp.devices.UPNPDevice;
/*     */ import net.sbbi.upnp.devices.UPNPRootDevice;
/*     */ import net.sbbi.upnp.messages.ActionMessage;
/*     */ import net.sbbi.upnp.messages.ActionResponse;
/*     */ import net.sbbi.upnp.messages.StateVariableMessage;
/*     */ import net.sbbi.upnp.messages.StateVariableResponse;
/*     */ import net.sbbi.upnp.messages.UPNPMessageFactory;
/*     */ import net.sbbi.upnp.messages.UPNPResponseException;
/*     */ import net.sbbi.upnp.services.UPNPService;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InternetGatewayDevice
/*     */ {
/*  82 */   private static final Log log = LogFactory.getLog(InternetGatewayDevice.class);
/*     */   private UPNPRootDevice igd;
/*     */   private UPNPMessageFactory msgFactory;
/*     */   
/*     */   public InternetGatewayDevice(UPNPRootDevice igd) throws UnsupportedOperationException
/*     */   {
/*  88 */     this(igd, true, true);
/*     */   }
/*     */   
/*     */   private InternetGatewayDevice(UPNPRootDevice igd, boolean WANIPConnection, boolean WANPPPConnection) throws UnsupportedOperationException {
/*  92 */     this.igd = igd;
/*  93 */     UPNPDevice myIGDWANConnDevice = igd.getChildDevice("urn:schemas-upnp-org:device:WANConnectionDevice:1");
/*  94 */     if (myIGDWANConnDevice == null) {
/*  95 */       throw new UnsupportedOperationException("device urn:schemas-upnp-org:device:WANConnectionDevice:1 not supported by IGD device " + igd.getModelName());
/*     */     }
/*     */     
/*  98 */     UPNPService wanIPSrv = myIGDWANConnDevice.getService("urn:schemas-upnp-org:service:WANIPConnection:1");
/*  99 */     UPNPService wanPPPSrv = myIGDWANConnDevice.getService("urn:schemas-upnp-org:service:WANPPPConnection:1");
/*     */     
/* 101 */     if ((WANIPConnection) && (WANPPPConnection) && (wanIPSrv == null) && (wanPPPSrv == null))
/* 102 */       throw new UnsupportedOperationException("Unable to find any urn:schemas-upnp-org:service:WANIPConnection:1 or urn:schemas-upnp-org:service:WANPPPConnection:1 service");
/* 103 */     if ((WANIPConnection) && (!WANPPPConnection) && (wanIPSrv == null))
/* 104 */       throw new UnsupportedOperationException("Unable to find any urn:schemas-upnp-org:service:WANIPConnection:1 service");
/* 105 */     if ((!WANIPConnection) && (WANPPPConnection) && (wanPPPSrv == null)) {
/* 106 */       throw new UnsupportedOperationException("Unable to find any urn:schemas-upnp-org:service:WANPPPConnection:1 service");
/*     */     }
/*     */     
/* 109 */     if ((wanIPSrv != null) && (wanPPPSrv == null)) {
/* 110 */       this.msgFactory = UPNPMessageFactory.getNewInstance(wanIPSrv);
/* 111 */     } else if ((wanPPPSrv != null) && (wanIPSrv == null)) {
/* 112 */       this.msgFactory = UPNPMessageFactory.getNewInstance(wanPPPSrv);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 151 */       if (testWANInterface(wanIPSrv)) {
/* 152 */         this.msgFactory = UPNPMessageFactory.getNewInstance(wanIPSrv);
/* 153 */       } else if (testWANInterface(wanPPPSrv)) {
/* 154 */         this.msgFactory = UPNPMessageFactory.getNewInstance(wanPPPSrv);
/*     */       }
/* 156 */       if (this.msgFactory == null)
/*     */       {
/* 158 */         log.warn("Unable to detect active WANIPConnection, dfaulting to urn:schemas-upnp-org:service:WANIPConnection:1");
/* 159 */         this.msgFactory = UPNPMessageFactory.getNewInstance(wanIPSrv);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean testWANInterface(UPNPService srv) {
/* 165 */     UPNPMessageFactory tmp = UPNPMessageFactory.getNewInstance(srv);
/*     */     
/* 167 */     ActionMessage msg = tmp.getMessage("GetExternalIPAddress");
/* 168 */     String ipToParse = null;
/*     */     try {
/* 170 */       ipToParse = msg.service().getOutActionArgumentValue("NewExternalIPAddress");
/*     */ 
/*     */     }
/*     */     catch (UPNPResponseException ex) {}catch (IOException ex)
/*     */     {
/* 175 */       log.warn("IOException occured during device detection", ex);
/*     */     }
/* 177 */     if ((ipToParse != null) && (ipToParse.length() > 0) && (!ipToParse.equals("0.0.0.0"))) {
/*     */       try {
/* 179 */         return InetAddress.getByName(ipToParse) != null;
/*     */       }
/*     */       catch (UnknownHostException ex) {}
/*     */     }
/*     */     
/* 184 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public UPNPRootDevice getIGDRootDevice()
/*     */   {
/* 192 */     return this.igd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static InternetGatewayDevice[] getDevices(int timeout)
/*     */     throws IOException
/*     */   {
/* 203 */     return lookupDeviceDevices(timeout, 4, 3, true, true, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static InternetGatewayDevice[] getDevices(int timeout, int ttl, int mx, NetworkInterface ni)
/*     */     throws IOException
/*     */   {
/* 218 */     return lookupDeviceDevices(timeout, ttl, mx, true, true, ni);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static InternetGatewayDevice[] getIPDevices(int timeout)
/*     */     throws IOException
/*     */   {
/* 230 */     return lookupDeviceDevices(timeout, 4, 3, true, false, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static InternetGatewayDevice[] getPPPDevices(int timeout)
/*     */     throws IOException
/*     */   {
/* 242 */     return lookupDeviceDevices(timeout, 4, 3, false, true, null);
/*     */   }
/*     */   
/*     */   private static InternetGatewayDevice[] lookupDeviceDevices(int timeout, int ttl, int mx, boolean WANIPConnection, boolean WANPPPConnection, NetworkInterface ni) throws IOException {
/* 246 */     UPNPRootDevice[] devices = null;
/* 247 */     InternetGatewayDevice[] rtrVal = null;
/* 248 */     if (timeout == -1) {
/* 249 */       devices = Discovery.discover(1500, ttl, mx, "urn:schemas-upnp-org:device:InternetGatewayDevice:1", ni);
/*     */     } else
/* 251 */       devices = Discovery.discover(timeout, ttl, mx, "urn:schemas-upnp-org:device:InternetGatewayDevice:1", ni);
/*     */     int i;
/*     */     Iterator itr;
/* 254 */     if (devices != null) {
/* 255 */       Set valid = new HashSet();
/* 256 */       for (int i = 0; i < devices.length; i++) {
/*     */         try {
/* 258 */           valid.add(new InternetGatewayDevice(devices[i], WANIPConnection, WANPPPConnection));
/*     */         }
/*     */         catch (UnsupportedOperationException ex) {
/* 261 */           if (log.isDebugEnabled()) log.debug("UnsupportedOperationException during discovery " + ex.getMessage());
/*     */         }
/*     */       }
/* 264 */       if (valid.size() == 0) {
/* 265 */         return null;
/*     */       }
/* 267 */       rtrVal = new InternetGatewayDevice[valid.size()];
/* 268 */       i = 0;
/* 269 */       for (itr = valid.iterator(); itr.hasNext();) {
/* 270 */         rtrVal[(i++)] = ((InternetGatewayDevice)itr.next());
/*     */       }
/*     */     }
/*     */     
/* 274 */     return rtrVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExternalIPAddress()
/*     */     throws UPNPResponseException, IOException
/*     */   {
/* 284 */     ActionMessage msg = this.msgFactory.getMessage("GetExternalIPAddress");
/* 285 */     return msg.service().getOutActionArgumentValue("NewExternalIPAddress");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ActionResponse getGenericPortMappingEntry(int newPortMappingIndex)
/*     */     throws IOException, UPNPResponseException
/*     */   {
/* 299 */     ActionMessage msg = this.msgFactory.getMessage("GetGenericPortMappingEntry");
/* 300 */     msg.setInputParameter("NewPortMappingIndex", newPortMappingIndex);
/*     */     try
/*     */     {
/* 303 */       return msg.service();
/*     */     } catch (UPNPResponseException ex) {
/* 305 */       if (ex.getDetailErrorCode() == 714) {
/* 306 */         return null;
/*     */       }
/* 308 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ActionResponse getSpecificPortMappingEntry(String remoteHost, int externalPort, String protocol)
/*     */     throws IOException, UPNPResponseException
/*     */   {
/* 325 */     remoteHost = remoteHost == null ? "" : remoteHost;
/* 326 */     checkPortMappingProtocol(protocol);
/* 327 */     checkPortRange(externalPort);
/*     */     
/* 329 */     ActionMessage msg = this.msgFactory.getMessage("GetSpecificPortMappingEntry");
/* 330 */     msg.setInputParameter("NewRemoteHost", remoteHost).setInputParameter("NewExternalPort", externalPort).setInputParameter("NewProtocol", protocol);
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 335 */       return msg.service();
/*     */     } catch (UPNPResponseException ex) {
/* 337 */       if (ex.getDetailErrorCode() == 714) {
/* 338 */         return null;
/*     */       }
/* 340 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean addPortMapping(String description, String remoteHost, int internalPort, int externalPort, String internalClient, int leaseDuration, String protocol)
/*     */     throws IOException, UPNPResponseException
/*     */   {
/* 369 */     remoteHost = remoteHost == null ? "" : remoteHost;
/* 370 */     checkPortMappingProtocol(protocol);
/* 371 */     if (externalPort != 0) {
/* 372 */       checkPortRange(externalPort);
/*     */     }
/* 374 */     checkPortRange(internalPort);
/* 375 */     description = description == null ? "" : description;
/* 376 */     if (leaseDuration < 0) { throw new IllegalArgumentException("Invalid leaseDuration (" + leaseDuration + ") value");
/*     */     }
/* 378 */     ActionMessage msg = this.msgFactory.getMessage("AddPortMapping");
/* 379 */     msg.setInputParameter("NewRemoteHost", remoteHost).setInputParameter("NewExternalPort", externalPort).setInputParameter("NewProtocol", protocol).setInputParameter("NewInternalPort", internalPort).setInputParameter("NewInternalClient", internalClient).setInputParameter("NewEnabled", true).setInputParameter("NewPortMappingDescription", description).setInputParameter("NewLeaseDuration", leaseDuration);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 388 */       msg.service();
/* 389 */       return true;
/*     */     } catch (UPNPResponseException ex) {
/* 391 */       if (ex.getDetailErrorCode() == 718) {
/* 392 */         return false;
/*     */       }
/* 394 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean deletePortMapping(String remoteHost, int externalPort, String protocol)
/*     */     throws IOException, UPNPResponseException
/*     */   {
/* 409 */     remoteHost = remoteHost == null ? "" : remoteHost;
/* 410 */     checkPortMappingProtocol(protocol);
/* 411 */     checkPortRange(externalPort);
/* 412 */     ActionMessage msg = this.msgFactory.getMessage("DeletePortMapping");
/* 413 */     msg.setInputParameter("NewRemoteHost", remoteHost).setInputParameter("NewExternalPort", externalPort).setInputParameter("NewProtocol", protocol);
/*     */     
/*     */     try
/*     */     {
/* 417 */       msg.service();
/* 418 */       return true;
/*     */     } catch (UPNPResponseException ex) {
/* 420 */       if (ex.getDetailErrorCode() == 714) {
/* 421 */         return false;
/*     */       }
/* 423 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getNatMappingsCount()
/*     */     throws IOException, UPNPResponseException
/*     */   {
/* 435 */     Integer rtrval = null;
/* 436 */     StateVariableMessage natTableSize = this.msgFactory.getStateVariableMessage("PortMappingNumberOfEntries");
/*     */     try {
/* 438 */       StateVariableResponse resp = natTableSize.service();
/* 439 */       rtrval = new Integer(resp.getStateVariableValue());
/*     */     }
/*     */     catch (UPNPResponseException ex) {
/* 442 */       if (ex.getDetailErrorCode() != 404) {
/* 443 */         throw ex;
/*     */       }
/*     */     }
/* 446 */     return rtrval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getNatTableSize()
/*     */     throws IOException, UPNPResponseException
/*     */   {
/* 460 */     int startIndex = -1;
/* 461 */     for (int i = 0; i < 50; i++) {
/*     */       try {
/* 463 */         getGenericPortMappingEntry(i);
/* 464 */         startIndex = i;
/*     */       }
/*     */       catch (UPNPResponseException ex)
/*     */       {
/* 468 */         if ((ex.getDetailErrorCode() != 713) && (ex.getDetailErrorCode() != 402)) {
/* 469 */           throw ex;
/*     */         }
/*     */       }
/*     */     }
/* 473 */     if (startIndex == -1)
/*     */     {
/*     */ 
/* 476 */       return null;
/*     */     }
/* 478 */     size = 0;
/*     */     try
/*     */     {
/*     */       for (;;) {
/* 482 */         getGenericPortMappingEntry(startIndex++);
/* 483 */         size++;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 492 */       return new Integer(size);
/*     */     }
/*     */     catch (UPNPResponseException ex)
/*     */     {
/* 485 */       if ((ex.getDetailErrorCode() == 713) || (ex.getDetailErrorCode() != 402))
/*     */       {
/*     */ 
/*     */ 
/* 489 */         throw ex;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkPortMappingProtocol(String prot) throws IllegalArgumentException
/*     */   {
/* 496 */     if ((prot == null) || ((!prot.equals("TCP")) && (!prot.equals("UDP"))))
/* 497 */       throw new IllegalArgumentException("PortMappingProtocol must be either TCP or UDP");
/*     */   }
/*     */   
/*     */   private void checkPortRange(int port) throws IllegalArgumentException {
/* 501 */     if ((port < 1) || (port > 65535)) {
/* 502 */       throw new IllegalArgumentException("Port range must be between 1 and 65535");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/impls/InternetGatewayDevice.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */