package net.sbbi.upnp;

import java.net.URL;

public abstract interface DiscoveryEventHandler
{
  public abstract void eventSSDPAlive(String paramString1, String paramString2, String paramString3, String paramString4, URL paramURL);
  
  public abstract void eventSSDPByeBye(String paramString1, String paramString2, String paramString3);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/DiscoveryEventHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */