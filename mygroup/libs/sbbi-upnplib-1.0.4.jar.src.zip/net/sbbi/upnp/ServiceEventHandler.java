package net.sbbi.upnp;

public abstract interface ServiceEventHandler
{
  public abstract void handleStateVariableEvent(String paramString1, String paramString2);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/ServiceEventHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */