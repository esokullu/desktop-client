/*     */ package net.sbbi.upnp;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceEventSubscription
/*     */ {
/*  62 */   private String serviceType = null;
/*  63 */   private String serviceId = null;
/*  64 */   private URL serviceURL = null;
/*  65 */   private String SID = null;
/*  66 */   private InetAddress deviceIp = null;
/*  67 */   private int durationTime = 0;
/*     */   
/*     */   public ServiceEventSubscription(String serviceType, String serviceId, URL serviceURL, String sid, InetAddress deviceIp, int durationTime)
/*     */   {
/*  71 */     this.serviceType = serviceType;
/*  72 */     this.serviceId = serviceId;
/*  73 */     this.serviceURL = serviceURL;
/*  74 */     this.SID = sid;
/*  75 */     this.deviceIp = deviceIp;
/*  76 */     this.durationTime = durationTime;
/*     */   }
/*     */   
/*     */   public InetAddress getDeviceIp() {
/*  80 */     return this.deviceIp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDurationTime()
/*     */   {
/*  88 */     return this.durationTime;
/*     */   }
/*     */   
/*     */   public String getServiceId() {
/*  92 */     return this.serviceId;
/*     */   }
/*     */   
/*     */   public String getServiceType() {
/*  96 */     return this.serviceType;
/*     */   }
/*     */   
/*     */   public URL getServiceURL() {
/* 100 */     return this.serviceURL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSID()
/*     */   {
/* 108 */     return this.SID;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/ServiceEventSubscription.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */