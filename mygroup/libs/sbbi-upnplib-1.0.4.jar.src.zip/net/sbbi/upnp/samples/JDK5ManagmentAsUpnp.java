package net.sbbi.upnp.samples;

public class JDK5ManagmentAsUpnp
{
  public static void main(String[] args) {}
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/samples/JDK5ManagmentAsUpnp.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */