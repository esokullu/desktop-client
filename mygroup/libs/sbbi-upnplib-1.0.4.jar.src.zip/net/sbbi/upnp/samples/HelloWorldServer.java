/*    */ package net.sbbi.upnp.samples;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.rmi.registry.LocateRegistry;
/*    */ import java.rmi.registry.Registry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HelloWorldServer
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/*    */     try
/*    */     {
/* 63 */       Registry reg = LocateRegistry.createRegistry(1099);
/* 64 */       System.out.println("Registry created");
/* 65 */       HelloWorld hello = new HelloWorld();
/* 66 */       System.out.println("Object created");
/* 67 */       reg.bind("HelloWorld", hello);
/* 68 */       System.out.println("Object bound HelloWorld server is ready.");
/*    */     } catch (Exception e) {
/* 70 */       System.out.println("Hello Server failed: " + e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/samples/HelloWorldServer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */