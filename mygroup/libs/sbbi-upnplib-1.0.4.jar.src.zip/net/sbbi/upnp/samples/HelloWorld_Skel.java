package net.sbbi.upnp.samples;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.rmi.MarshalException;
import java.rmi.Remote;
import java.rmi.UnmarshalException;
import java.rmi.server.Operation;
import java.rmi.server.RemoteCall;
import java.rmi.server.Skeleton;
import java.rmi.server.SkeletonMismatchException;

public final class HelloWorld_Skel
  implements Skeleton
{
  private static final Operation[] operations = { new Operation("java.lang.String say(java.lang.String)") };
  private static final long interfaceHash = -8125058830566419586L;
  
  public void dispatch(Remote paramRemote, RemoteCall paramRemoteCall, int paramInt, long paramLong)
    throws Exception
  {
    if (paramInt < 0)
    {
      if (paramLong == 5497363165482560076L) {
        paramInt = 0;
      } else {
        throw new UnmarshalException("invalid method hash");
      }
    }
    else if (paramLong != -8125058830566419586L) {
      throw new SkeletonMismatchException("interface hash mismatch");
    }
    HelloWorld localHelloWorld = (HelloWorld)paramRemote;
    switch (paramInt)
    {
    case 0: 
      String str1;
      try
      {
        ObjectInput localObjectInput = paramRemoteCall.getInputStream();
        str1 = (String)localObjectInput.readObject();
      }
      catch (IOException localIOException2)
      {
        throw new UnmarshalException("error unmarshalling arguments", localIOException2);
      }
      catch (ClassNotFoundException localClassNotFoundException)
      {
        throw new UnmarshalException("error unmarshalling arguments", localClassNotFoundException);
      }
      finally
      {
        paramRemoteCall.releaseInputStream();
      }
      String str2 = localHelloWorld.say(str1);
      try
      {
        ObjectOutput localObjectOutput = paramRemoteCall.getResultStream(true);
        localObjectOutput.writeObject(str2);
      }
      catch (IOException localIOException1)
      {
        throw new MarshalException("error marshalling return", localIOException1);
      }
    default: 
      throw new UnmarshalException("invalid method number");
    }
  }
  
  public Operation[] getOperations()
  {
    return (Operation[])operations.clone();
  }
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/samples/HelloWorld_Skel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */