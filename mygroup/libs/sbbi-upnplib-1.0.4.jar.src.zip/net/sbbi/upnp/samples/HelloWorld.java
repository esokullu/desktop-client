/*    */ package net.sbbi.upnp.samples;
/*    */ 
/*    */ import java.net.InetAddress;
/*    */ import java.rmi.RemoteException;
/*    */ import net.sbbi.upnp.remote.UnicastRemoteObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HelloWorld
/*    */   extends UnicastRemoteObject
/*    */   implements HelloWorldInterface
/*    */ {
/*    */   public HelloWorld()
/*    */     throws RemoteException
/*    */   {}
/*    */   
/*    */   public String say(String myName)
/*    */     throws RemoteException
/*    */   {
/* 66 */     String hostName = "localhost";
/*    */     try {
/* 68 */       hostName = InetAddress.getLocalHost().getHostName();
/*    */     }
/*    */     catch (Exception ex) {}
/* 71 */     return "Hello world to " + myName + " from computer " + hostName;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/samples/HelloWorld.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */