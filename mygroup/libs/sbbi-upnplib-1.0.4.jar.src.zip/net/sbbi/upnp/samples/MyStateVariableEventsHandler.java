/*     */ package net.sbbi.upnp.samples;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.sbbi.upnp.Discovery;
/*     */ import net.sbbi.upnp.ServiceEventHandler;
/*     */ import net.sbbi.upnp.ServicesEventing;
/*     */ import net.sbbi.upnp.devices.UPNPDevice;
/*     */ import net.sbbi.upnp.devices.UPNPRootDevice;
/*     */ import net.sbbi.upnp.services.UPNPService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MyStateVariableEventsHandler
/*     */   implements ServiceEventHandler
/*     */ {
/*     */   public void handleStateVariableEvent(String varName, String newValue)
/*     */   {
/*  63 */     System.out.println("State variable " + varName + " changed to " + newValue);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  69 */     ServicesEventing instance = ServicesEventing.getInstance();
/*  70 */     MyStateVariableEventsHandler handler = new MyStateVariableEventsHandler();
/*  71 */     instance.setDaemon(false);
/*     */     
/*  73 */     UPNPRootDevice[] devices = null;
/*     */     try {
/*  75 */       devices = Discovery.discover();
/*     */     } catch (IOException ex) {
/*  77 */       ex.printStackTrace(System.err);
/*     */     }
/*  79 */     if (devices != null) {
/*  80 */       UPNPDevice firstDevice = (UPNPDevice)devices[0].getChildDevices().iterator().next();
/*     */       
/*  82 */       UPNPService firstService = (UPNPService)firstDevice.getServices().iterator().next();
/*     */       try
/*     */       {
/*  85 */         int duration = instance.register(firstService, handler, -1);
/*  86 */         if ((duration != -1) && (duration != 0)) {
/*  87 */           System.out.println("State variable events registered for " + duration + " ms");
/*  88 */         } else if (duration == 0) {
/*  89 */           System.out.println("State variable events registered for infinite ms");
/*     */         }
/*     */         try {
/*  92 */           Thread.sleep(5000L);
/*     */         }
/*     */         catch (InterruptedException ex) {}
/*     */         
/*  96 */         instance.unRegister(firstService, handler);
/*     */       } catch (IOException ex) {
/*  98 */         ex.printStackTrace(System.err);
/*     */       }
/*     */     }
/*     */     else {
/* 102 */       System.out.println("Unable to find devices");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/samples/MyStateVariableEventsHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */