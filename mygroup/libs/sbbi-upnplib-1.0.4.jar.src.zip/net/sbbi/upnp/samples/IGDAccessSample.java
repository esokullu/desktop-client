/*     */ package net.sbbi.upnp.samples;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.sbbi.upnp.Discovery;
/*     */ import net.sbbi.upnp.devices.UPNPDevice;
/*     */ import net.sbbi.upnp.devices.UPNPRootDevice;
/*     */ import net.sbbi.upnp.messages.ActionMessage;
/*     */ import net.sbbi.upnp.messages.ActionResponse;
/*     */ import net.sbbi.upnp.messages.UPNPMessageFactory;
/*     */ import net.sbbi.upnp.messages.UPNPResponseException;
/*     */ import net.sbbi.upnp.services.ServiceStateVariable;
/*     */ import net.sbbi.upnp.services.UPNPService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IGDAccessSample
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/*  71 */       UPNPRootDevice[] rootDevices = Discovery.discover(1500, "urn:schemas-upnp-org:device:InternetGatewayDevice:1");
/*     */       
/*     */ 
/*  74 */       if (rootDevices != null)
/*     */       {
/*  76 */         UPNPRootDevice rootDevice = rootDevices[0];
/*  77 */         System.out.println("Plugged to device " + rootDevice.getDeviceType() + ", manufactured by " + rootDevice.getManufacturer() + " model " + rootDevice.getModelName());
/*     */         
/*  79 */         List devices = rootDevice.getChildDevices();
/*  80 */         Iterator i; if (devices != null) {
/*  81 */           devices.add(rootDevice);
/*  82 */           for (i = devices.iterator(); i.hasNext();) {
/*  83 */             UPNPDevice device = (UPNPDevice)i.next();
/*  84 */             System.out.println();
/*  85 */             System.out.println("type " + device.getDeviceType());
/*  86 */             if (device.getDirectParent() != null) {
/*  87 */               System.out.println("parent type " + device.getDirectParent().getDeviceType());
/*     */             }
/*  89 */             List deviceServices = device.getServices();
/*  90 */             if (deviceServices != null) {
/*  91 */               for (iSrv = deviceServices.iterator(); iSrv.hasNext();) {
/*  92 */                 UPNPService srv = (UPNPService)iSrv.next();
/*  93 */                 System.out.println("  service " + srv.getServiceType() + " at " + srv.getSCPDURL());
/*  94 */                 for (itrActions = srv.getAvailableActionsName(); itrActions.hasNext();)
/*  95 */                   System.out.println("\t" + itrActions.next());
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         Iterator iSrv;
/*     */         Iterator itrActions;
/* 102 */         List rootChildDevices = rootDevice.getChildDevices();
/* 103 */         System.out.println("Child devices available : " + rootChildDevices);
/*     */         
/* 105 */         UPNPDevice wanConnDevice = rootDevice.getChildDevice("urn:schemas-upnp-org:device:WANConnectionDevice:1");
/*     */         
/* 107 */         if (wanConnDevice != null)
/*     */         {
/* 109 */           System.out.println("Found required device " + wanConnDevice.getDeviceType());
/*     */           
/* 111 */           UPNPService wanIPSrv = wanConnDevice.getService("urn:schemas-upnp-org:service:WANIPConnection:1");
/*     */           
/* 113 */           if (wanIPSrv != null) {
/* 114 */             System.out.println("Service " + wanIPSrv.getServiceType() + " found\n");
/* 115 */             if (wanIPSrv.getUPNPServiceAction("GetExternalIPAddress") != null)
/*     */             {
/* 117 */               UPNPMessageFactory wanIPMsgFactory = UPNPMessageFactory.getNewInstance(wanIPSrv);
/* 118 */               ActionMessage externalIPAdrMsg = wanIPMsgFactory.getMessage("GetExternalIPAddress");
/* 119 */               List params = externalIPAdrMsg.getInputParameterNames();
/*     */               
/* 121 */               System.out.println("Action required input params:");
/* 122 */               System.out.println(params);
/* 123 */               params = externalIPAdrMsg.getOutputParameterNames();
/*     */               
/*     */ 
/* 126 */               System.out.println("Action returned values:");
/* 127 */               System.out.println(params);
/*     */               try
/*     */               {
/* 130 */                 ActionResponse response = externalIPAdrMsg.service();
/* 131 */                 System.out.println("Message response values:");
/* 132 */                 for (int i = 0; i < params.size(); i++) {
/* 133 */                   String param = (String)params.get(i);
/* 134 */                   System.out.println(param + "=" + response.getOutActionArgumentValue(param));
/*     */                 }
/*     */               }
/*     */               catch (UPNPResponseException ex) {}
/*     */               
/* 139 */               System.out.println("Validity time remaining=" + rootDevice.getValidityTime());
/*     */               
/* 141 */               System.out.println("Query PortMappingDescription state variable");
/*     */               try {
/* 143 */                 System.out.println("Response=" + wanIPSrv.getUPNPServiceStateVariable("PortMappingDescription").getValue());
/*     */               }
/*     */               catch (UPNPResponseException ex) {}
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 152 */       ex.printStackTrace(System.err);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/samples/IGDAccessSample.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */