/*     */ package net.sbbi.upnp.samples;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.InetAddress;
/*     */ import net.sbbi.upnp.devices.UPNPRootDevice;
/*     */ import net.sbbi.upnp.impls.InternetGatewayDevice;
/*     */ import net.sbbi.upnp.messages.ActionResponse;
/*     */ import net.sbbi.upnp.messages.UPNPResponseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IGDPortsTest
/*     */ {
/*     */   public static final void main(String[] args)
/*     */   {
/*  68 */     int discoveryTiemout = 5000;
/*     */     try {
/*  70 */       InternetGatewayDevice[] IGDs = InternetGatewayDevice.getDevices(discoveryTiemout);
/*  71 */       if (IGDs != null) {
/*  72 */         for (int i = 0; i < IGDs.length; i++) {
/*  73 */           InternetGatewayDevice testIGD = IGDs[i];
/*  74 */           System.out.println("Found device " + testIGD.getIGDRootDevice().getModelName());
/*  75 */           System.out.println("NAT table size is " + testIGD.getNatTableSize());
/*     */           
/*  77 */           String localHostIP = InetAddress.getLocalHost().getHostAddress();
/*  78 */           boolean mapped = testIGD.addPortMapping("Some mapping description", null, 9090, 9090, localHostIP, 0, "TCP");
/*     */           
/*     */ 
/*  81 */           if (mapped)
/*     */           {
/*  83 */             System.out.println("Port 9090 mapped to " + localHostIP);
/*  84 */             System.out.println("Current mappings count is " + testIGD.getNatMappingsCount());
/*     */             
/*  86 */             ActionResponse resp = testIGD.getSpecificPortMappingEntry(null, 9090, "TCP");
/*  87 */             if (resp != null) {
/*  88 */               System.out.println("Port 9090 mapping confirmation received from device");
/*     */             }
/*     */             
/*  91 */             boolean unmapped = testIGD.deletePortMapping(null, 9090, "TCP");
/*  92 */             if (unmapped) {
/*  93 */               System.out.println("Port 9090 unmapped");
/*     */             }
/*     */           }
/*     */         }
/*     */       } else {
/*  98 */         System.out.println("Unable to find IGD on your network");
/*     */       }
/*     */     } catch (IOException ex) {
/* 101 */       System.err.println("IOException occured during discovery or ports mapping " + ex.getMessage());
/*     */     }
/*     */     catch (UPNPResponseException respEx) {
/* 104 */       System.err.println("UPNP device unhappy " + respEx.getDetailErrorCode() + " " + respEx.getDetailErrorDescription());
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/samples/IGDPortsTest.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */