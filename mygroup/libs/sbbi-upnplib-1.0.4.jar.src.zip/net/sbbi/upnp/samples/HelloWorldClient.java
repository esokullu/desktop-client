/*    */ package net.sbbi.upnp.samples;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.PrintStream;
/*    */ import java.rmi.Naming;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HelloWorldClient
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 61 */     if (args.length != 2) {
/* 62 */       System.out.println("HelloWorldClient <hostName> <myName>");
/* 63 */       System.exit(0);
/*    */     }
/* 65 */     String hostName = args[0];
/* 66 */     String say = args[1];
/*    */     try {
/* 68 */       HelloWorldInterface hello = (HelloWorldInterface)Naming.lookup("rmi://" + hostName + "/HelloWorld");
/* 69 */       System.out.println(hello.say(say));
/*    */     } catch (Exception e) {
/* 71 */       System.out.println("HelloWorldClient exception: " + e);
/*    */     }
/*    */     
/* 74 */     System.out.println("Press enter to exit");
/*    */     try {
/* 76 */       System.in.read();
/*    */     }
/*    */     catch (IOException ex) {}
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/samples/HelloWorldClient.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */