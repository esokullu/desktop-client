/*    */ package net.sbbi.upnp.samples;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.net.URL;
/*    */ import net.sbbi.upnp.DiscoveryAdvertisement;
/*    */ import net.sbbi.upnp.DiscoveryEventHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DiscoveryAdvertisementSample
/*    */ {
/*    */   public static final void main(String[] args)
/*    */     throws IOException
/*    */   {
/* 69 */     AdvHandler handler = new AdvHandler(null);
/*    */     
/* 71 */     DiscoveryAdvertisement.getInstance().setDaemon(false);
/* 72 */     System.out.println("Registering EVENT_SSDP_ALIVE event");
/* 73 */     DiscoveryAdvertisement.getInstance().registerEvent(0, "upnp:rootdevice", handler);
/* 74 */     System.out.println("Registering EVENT_SSDP_BYE_BYE event");
/* 75 */     DiscoveryAdvertisement.getInstance().registerEvent(1, "upnp:rootdevice", handler);
/* 76 */     System.out.println("Waiting for incoming events");
/*    */   }
/*    */   
/* 79 */   private static class AdvHandler implements DiscoveryEventHandler { AdvHandler(DiscoveryAdvertisementSample.1 x0) { this(); }
/*    */     
/*    */     public void eventSSDPAlive(String usn, String udn, String nt, String maxAge, URL location) {
/* 82 */       System.out.println("Root device at " + location + " plugged in network, advertisement will expire in " + maxAge + " ms");
/*    */     }
/*    */     
/*    */     public void eventSSDPByeBye(String usn, String udn, String nt) {
/* 86 */       System.out.println("Bye Bye usn:" + usn + " udn:" + udn + " nt:" + nt);
/*    */     }
/*    */     
/*    */     private AdvHandler() {}
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/samples/DiscoveryAdvertisementSample.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */