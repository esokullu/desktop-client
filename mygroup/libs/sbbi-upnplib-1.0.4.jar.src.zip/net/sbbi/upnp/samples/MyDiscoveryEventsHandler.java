/*     */ package net.sbbi.upnp.samples;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.sbbi.upnp.DiscoveryAdvertisement;
/*     */ import net.sbbi.upnp.DiscoveryEventHandler;
/*     */ import net.sbbi.upnp.devices.UPNPRootDevice;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MyDiscoveryEventsHandler
/*     */   implements DiscoveryEventHandler
/*     */ {
/*  62 */   private Map devices = new HashMap();
/*     */   
/*     */ 
/*     */   public void eventSSDPAlive(String usn, String udn, String nt, String maxAge, URL location)
/*     */   {
/*  67 */     System.out.println("Device " + usn + " at " + location + " of type " + nt + " alive");
/*     */     
/*     */ 
/*  70 */     if (this.devices.get(usn) == null)
/*     */     {
/*  72 */       UPNPRootDevice device = null;
/*     */       try {
/*  74 */         device = new UPNPRootDevice(location, maxAge);
/*  75 */         this.devices.put(usn, device);
/*  76 */         System.out.println("Device " + usn + " added");
/*     */       }
/*     */       catch (MalformedURLException ex) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void eventSSDPByeBye(String usn, String udn, String nt)
/*     */   {
/*  87 */     if (this.devices.get(usn) != null) {
/*  88 */       this.devices.remove(usn);
/*  89 */       System.out.println("Device " + usn + " leaves");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws IOException
/*     */   {
/*  98 */     DiscoveryAdvertisement instance = DiscoveryAdvertisement.getInstance();
/*  99 */     MyDiscoveryEventsHandler handler = new MyDiscoveryEventsHandler();
/* 100 */     instance.setDaemon(false);
/* 101 */     instance.registerEvent(0, "upnp:rootdevice", handler);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/samples/MyDiscoveryEventsHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */