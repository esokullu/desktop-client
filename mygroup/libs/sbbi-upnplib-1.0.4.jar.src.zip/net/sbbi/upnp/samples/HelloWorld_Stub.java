package net.sbbi.upnp.samples;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.reflect.Method;
import java.rmi.MarshalException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.UnexpectedException;
import java.rmi.UnmarshalException;
import java.rmi.server.Operation;
import java.rmi.server.RemoteCall;
import java.rmi.server.RemoteObject;
import java.rmi.server.RemoteRef;
import java.rmi.server.RemoteStub;

public final class HelloWorld_Stub
  extends RemoteStub
  implements HelloWorldInterface, Remote
{
  private static final Operation[] operations = { new Operation("java.lang.String say(java.lang.String)") };
  private static final long interfaceHash = -8125058830566419586L;
  private static final long serialVersionUID = 2L;
  private static boolean useNewInvoke;
  private static Method $method_say_0;
  
  static
  {
    try
    {
      RemoteRef.class.getMethod("invoke", new Class[] { Remote.class, Method.class, new Object[0].getClass(), Long.TYPE });
      useNewInvoke = true;
      $method_say_0 = HelloWorldInterface.class.getMethod("say", new Class[] { String.class });
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      useNewInvoke = false;
    }
  }
  
  public HelloWorld_Stub() {}
  
  public HelloWorld_Stub(RemoteRef paramRemoteRef)
  {
    super(paramRemoteRef);
  }
  
  public String say(String paramString)
    throws RemoteException
  {
    try
    {
      if (useNewInvoke)
      {
        localObject1 = this.ref.invoke(this, $method_say_0, new Object[] { paramString }, 5497363165482560076L);
        return (String)localObject1;
      }
      Object localObject1 = this.ref.newCall(this, operations, 0, -8125058830566419586L);
      try
      {
        ObjectOutput localObjectOutput = ((RemoteCall)localObject1).getOutputStream();
        localObjectOutput.writeObject(paramString);
      }
      catch (IOException localIOException1)
      {
        throw new MarshalException("error marshalling arguments", localIOException1);
      }
      this.ref.invoke((RemoteCall)localObject1);
      String str;
      try
      {
        ObjectInput localObjectInput = ((RemoteCall)localObject1).getInputStream();
        str = (String)localObjectInput.readObject();
      }
      catch (IOException localIOException2)
      {
        throw new UnmarshalException("error unmarshalling return", localIOException2);
      }
      catch (ClassNotFoundException localClassNotFoundException)
      {
        throw new UnmarshalException("error unmarshalling return", localClassNotFoundException);
      }
      finally
      {
        this.ref.done((RemoteCall)localObject1);
      }
      return str;
    }
    catch (RuntimeException localRuntimeException)
    {
      throw localRuntimeException;
    }
    catch (RemoteException localRemoteException)
    {
      throw localRemoteException;
    }
    catch (Exception localException)
    {
      throw new UnexpectedException("undeclared checked exception", localException);
    }
  }
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/samples/HelloWorld_Stub.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */