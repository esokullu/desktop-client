/*     */ package net.sbbi.upnp.services;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.Date;
/*     */ import java.util.Set;
/*     */ import net.sbbi.upnp.messages.StateVariableMessage;
/*     */ import net.sbbi.upnp.messages.StateVariableResponse;
/*     */ import net.sbbi.upnp.messages.UPNPMessageFactory;
/*     */ import net.sbbi.upnp.messages.UPNPResponseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceStateVariable
/*     */   implements ServiceStateVariableTypes
/*     */ {
/*  67 */   private StateVariableMessage stateVarMsg = null;
/*     */   
/*     */   protected String name;
/*     */   
/*     */   protected boolean sendEvents;
/*     */   
/*     */   protected String dataType;
/*     */   
/*     */   protected String defaultValue;
/*     */   
/*     */   protected String minimumRangeValue;
/*     */   
/*     */   protected String maximumRangeValue;
/*     */   
/*     */   protected String stepRangeValue;
/*     */   
/*     */   protected Set allowedvalues;
/*     */   
/*     */   protected UPNPService parent;
/*     */   
/*     */   public String getValue()
/*     */     throws UPNPResponseException, IOException
/*     */   {
/*  90 */     if (this.stateVarMsg == null) {
/*  91 */       synchronized (this) {
/*  92 */         if (this.stateVarMsg == null) {
/*  93 */           UPNPMessageFactory factory = UPNPMessageFactory.getNewInstance(this.parent);
/*  94 */           this.stateVarMsg = factory.getStateVariableMessage(this.name);
/*     */         }
/*     */       }
/*     */     }
/*  98 */     return this.stateVarMsg.service().getStateVariableValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 106 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public UPNPService getParent()
/*     */   {
/* 114 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSendEvents()
/*     */   {
/* 124 */     return this.sendEvents;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDefaultValue()
/*     */   {
/* 132 */     return this.defaultValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDataType()
/*     */   {
/* 140 */     return this.dataType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class getDataTypeAsClass()
/*     */   {
/* 148 */     return getDataTypeClassMapping(this.dataType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set getAllowedvalues()
/*     */   {
/* 156 */     return this.allowedvalues;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMinimumRangeValue()
/*     */   {
/* 164 */     return this.minimumRangeValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMaximumRangeValue()
/*     */   {
/* 172 */     return this.maximumRangeValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStepRangeValue()
/*     */   {
/* 180 */     return this.stepRangeValue;
/*     */   }
/*     */   
/*     */   public static Class getDataTypeClassMapping(String dataType) {
/* 184 */     int hash = dataType.hashCode();
/* 185 */     if (hash == UI1_INT) return Short.class;
/* 186 */     if (hash == UI2_INT) return Integer.class;
/* 187 */     if (hash == UI4_INT) return Long.class;
/* 188 */     if (hash == I1_INT) return Byte.class;
/* 189 */     if (hash == I2_INT) return Short.class;
/* 190 */     if (hash == I4_INT) return Integer.class;
/* 191 */     if (hash == INT_INT) return Integer.class;
/* 192 */     if (hash == R4_INT) return Float.class;
/* 193 */     if (hash == R8_INT) return Double.class;
/* 194 */     if (hash == NUMBER_INT) return Double.class;
/* 195 */     if (hash == FIXED_14_4_INT) return Double.class;
/* 196 */     if (hash == FLOAT_INT) return Float.class;
/* 197 */     if (hash == CHAR_INT) return Character.class;
/* 198 */     if (hash == STRING_INT) return String.class;
/* 199 */     if (hash == DATE_INT) return Date.class;
/* 200 */     if (hash == DATETIME_INT) return Date.class;
/* 201 */     if (hash == DATETIME_TZ_INT) return Date.class;
/* 202 */     if (hash == TIME_INT) return Date.class;
/* 203 */     if (hash == TIME_TZ_INT) return Date.class;
/* 204 */     if (hash == BOOLEAN_INT) return Boolean.class;
/* 205 */     if (hash == BIN_BASE64_INT) return String.class;
/* 206 */     if (hash == BIN_HEX_INT) return String.class;
/* 207 */     if (hash == URI_INT) return URI.class;
/* 208 */     if (hash == UUID_INT) return String.class;
/* 209 */     return null;
/*     */   }
/*     */   
/*     */   public static String getUPNPDataTypeMapping(String className) {
/* 213 */     if ((className.equals(Short.class.getName())) || (className.equals("short"))) return "i2";
/* 214 */     if ((className.equals(Byte.class.getName())) || (className.equals("byte"))) return "i1";
/* 215 */     if ((className.equals(Integer.class.getName())) || (className.equals("int"))) return "int";
/* 216 */     if ((className.equals(Long.class.getName())) || (className.equals("long"))) return "ui4";
/* 217 */     if ((className.equals(Float.class.getName())) || (className.equals("float"))) return "float";
/* 218 */     if ((className.equals(Double.class.getName())) || (className.equals("double"))) return "number";
/* 219 */     if ((className.equals(Character.class.getName())) || (className.equals("char"))) return "char";
/* 220 */     if ((className.equals(String.class.getName())) || (className.equals("string"))) return "string";
/* 221 */     if (className.equals(Date.class.getName())) return "dateTime";
/* 222 */     if ((className.equals(Boolean.class.getName())) || (className.equals("boolean"))) return "boolean";
/* 223 */     if (className.equals(URI.class.getName())) return "uri";
/* 224 */     return null;
/*     */   }
/*     */   
/*     */   public static Object UPNPToJavaObject(String dataType, String value) throws Throwable {
/* 228 */     if (value == null) throw new Exception("null value");
/* 229 */     if (dataType == null) throw new Exception("null dataType");
/* 230 */     int hash = dataType.hashCode();
/* 231 */     if (hash == UI1_INT) return new Short(value);
/* 232 */     if (hash == UI2_INT) return new Integer(value);
/* 233 */     if (hash == UI4_INT) return new Long(value);
/* 234 */     if (hash == I1_INT) return new Byte(value);
/* 235 */     if (hash == I2_INT) return new Short(value);
/* 236 */     if (hash == I4_INT) return new Integer(value);
/* 237 */     if (hash == INT_INT) return new Integer(value);
/* 238 */     if (hash == R4_INT) return new Float(value);
/* 239 */     if (hash == R8_INT) return new Double(value);
/* 240 */     if (hash == NUMBER_INT) return new Double(value);
/* 241 */     if (hash == FIXED_14_4_INT) return new Double(value);
/* 242 */     if (hash == FLOAT_INT) return new Float(value);
/* 243 */     if (hash == CHAR_INT) return new Character(value.charAt(0));
/* 244 */     if (hash == STRING_INT) return value;
/* 245 */     if (hash == DATE_INT) return ISO8601Date.parse(value);
/* 246 */     if (hash == DATETIME_INT) return ISO8601Date.parse(value);
/* 247 */     if (hash == DATETIME_TZ_INT) return ISO8601Date.parse(value);
/* 248 */     if (hash == TIME_INT) return ISO8601Date.parse(value);
/* 249 */     if (hash == TIME_TZ_INT) return ISO8601Date.parse(value);
/* 250 */     if (hash == BOOLEAN_INT) {
/* 251 */       if ((value.equals("1")) || (value.equalsIgnoreCase("yes")) || (value.equals("true"))) {
/* 252 */         return Boolean.TRUE;
/*     */       }
/* 254 */       return Boolean.FALSE;
/*     */     }
/* 256 */     if (hash == BIN_BASE64_INT) return value;
/* 257 */     if (hash == BIN_HEX_INT) return value;
/* 258 */     if (hash == URI_INT) return new URI(value);
/* 259 */     if (hash == UUID_INT) return value;
/* 260 */     throw new Exception("Unhandled data type " + dataType);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/services/ServiceStateVariable.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */