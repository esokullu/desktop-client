/*     */ package net.sbbi.upnp.services;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceAction
/*     */ {
/*     */   protected String name;
/*     */   protected UPNPService parent;
/*     */   private List orderedActionArguments;
/*     */   private List orderedInputActionArguments;
/*     */   private List orderedOutputActionArguments;
/*     */   private List orderedInputActionArgumentsNames;
/*     */   private List orderedOutputActionArgumentsNames;
/*     */   
/*     */   public UPNPService getParent()
/*     */   {
/*  71 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getActionArguments()
/*     */   {
/*  79 */     return this.orderedActionArguments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServiceActionArgument getActionArgument(String argumentName)
/*     */   {
/*  88 */     if (this.orderedActionArguments == null) return null;
/*  89 */     for (Iterator i = this.orderedActionArguments.iterator(); i.hasNext();) {
/*  90 */       ServiceActionArgument arg = (ServiceActionArgument)i.next();
/*  91 */       if (arg.getName().equals(argumentName)) return arg;
/*     */     }
/*  93 */     return null;
/*     */   }
/*     */   
/*     */   protected void setActionArguments(List orderedActionArguments) {
/*  97 */     this.orderedActionArguments = orderedActionArguments;
/*  98 */     this.orderedInputActionArguments = getListForActionArgument(orderedActionArguments, "in");
/*  99 */     this.orderedOutputActionArguments = getListForActionArgument(orderedActionArguments, "out");
/* 100 */     this.orderedInputActionArgumentsNames = getListForActionArgumentNames(orderedActionArguments, "in");
/* 101 */     this.orderedOutputActionArgumentsNames = getListForActionArgumentNames(orderedActionArguments, "out");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getInputActionArguments()
/*     */   {
/* 110 */     return this.orderedInputActionArguments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServiceActionArgument getInputActionArgument(String argumentName)
/*     */   {
/* 119 */     if (this.orderedInputActionArguments == null) return null;
/* 120 */     for (Iterator i = this.orderedInputActionArguments.iterator(); i.hasNext();) {
/* 121 */       ServiceActionArgument arg = (ServiceActionArgument)i.next();
/* 122 */       if (arg.getName().equals(argumentName)) return arg;
/*     */     }
/* 124 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getOutputActionArguments()
/*     */   {
/* 134 */     return this.orderedOutputActionArguments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServiceActionArgument getOutputActionArgument(String argumentName)
/*     */   {
/* 143 */     if (this.orderedOutputActionArguments == null) return null;
/* 144 */     for (Iterator i = this.orderedOutputActionArguments.iterator(); i.hasNext();) {
/* 145 */       ServiceActionArgument arg = (ServiceActionArgument)i.next();
/* 146 */       if (arg.getName().equals(argumentName)) return arg;
/*     */     }
/* 148 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getInputActionArgumentsNames()
/*     */   {
/* 157 */     return this.orderedInputActionArgumentsNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getOutputActionArgumentsNames()
/*     */   {
/* 166 */     return this.orderedOutputActionArgumentsNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 174 */     return this.name;
/*     */   }
/*     */   
/*     */   private List getListForActionArgument(List args, String direction) {
/* 178 */     if (args == null) return null;
/* 179 */     List rtrVal = new ArrayList();
/* 180 */     for (Iterator itr = args.iterator(); itr.hasNext();) {
/* 181 */       ServiceActionArgument actArg = (ServiceActionArgument)itr.next();
/* 182 */       if (actArg.getDirection() == direction) {
/* 183 */         rtrVal.add(actArg);
/*     */       }
/*     */     }
/* 186 */     if (rtrVal.size() == 0) rtrVal = null;
/* 187 */     return rtrVal;
/*     */   }
/*     */   
/*     */   private List getListForActionArgumentNames(List args, String direction) {
/* 191 */     if (args == null) return null;
/* 192 */     List rtrVal = new ArrayList();
/* 193 */     for (Iterator itr = args.iterator(); itr.hasNext();) {
/* 194 */       ServiceActionArgument actArg = (ServiceActionArgument)itr.next();
/* 195 */       if (actArg.getDirection() == direction) {
/* 196 */         rtrVal.add(actArg.getName());
/*     */       }
/*     */     }
/* 199 */     if (rtrVal.size() == 0) rtrVal = null;
/* 200 */     return rtrVal;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/services/ServiceAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */