/*     */ package net.sbbi.upnp.services;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ISO8601Date
/*     */ {
/*     */   private static boolean check(StringTokenizer st, String token)
/*     */     throws NumberFormatException
/*     */   {
/*     */     try
/*     */     {
/*  68 */       if (st.nextToken().equals(token)) {
/*  69 */         return true;
/*     */       }
/*  71 */       throw new NumberFormatException("Missing [" + token + "]");
/*     */     }
/*     */     catch (NoSuchElementException ex) {}
/*  74 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   private static Calendar getCalendar(String isodate)
/*     */     throws NumberFormatException
/*     */   {
/*  81 */     boolean isATime = isodate.indexOf(':') != -1;
/*  82 */     boolean isADate = (isodate.indexOf('-') != -1) || ((isodate.length() == 4) && (!isATime));
/*  83 */     if ((isATime) && (!isADate) && 
/*  84 */       (!isodate.toUpperCase().startsWith("T"))) {
/*  85 */       isodate = "T" + isodate;
/*     */     }
/*     */     
/*  88 */     StringTokenizer st = new StringTokenizer(isodate, "-T:.+Z", true);
/*  89 */     Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
/*  90 */     calendar.clear();
/*  91 */     if (isADate)
/*     */     {
/*  93 */       if (st.hasMoreTokens()) {
/*  94 */         int year = Integer.parseInt(st.nextToken());
/*  95 */         calendar.set(1, year);
/*     */       } else {
/*  97 */         return calendar;
/*     */       }
/*     */       
/* 100 */       if ((check(st, "-")) && (st.hasMoreTokens())) {
/* 101 */         int month = Integer.parseInt(st.nextToken()) - 1;
/* 102 */         calendar.set(2, month);
/*     */       } else {
/* 104 */         return calendar;
/*     */       }
/*     */       
/* 107 */       if ((check(st, "-")) && (st.hasMoreTokens())) {
/* 108 */         int day = Integer.parseInt(st.nextToken());
/* 109 */         calendar.set(5, day);
/*     */       } else {
/* 111 */         return calendar;
/*     */       }
/*     */     }
/*     */     
/* 115 */     if ((check(st, "T")) && (st.hasMoreTokens())) {
/* 116 */       int hour = Integer.parseInt(st.nextToken());
/* 117 */       calendar.set(11, hour);
/*     */     } else {
/* 119 */       calendar.set(11, 0);
/* 120 */       calendar.set(12, 0);
/* 121 */       calendar.set(13, 0);
/* 122 */       calendar.set(14, 0);
/* 123 */       return calendar;
/*     */     }
/*     */     
/* 126 */     if ((check(st, ":")) && (st.hasMoreTokens())) {
/* 127 */       int minutes = Integer.parseInt(st.nextToken());
/* 128 */       calendar.set(12, minutes);
/*     */     } else {
/* 130 */       calendar.set(12, 0);
/* 131 */       calendar.set(13, 0);
/* 132 */       calendar.set(14, 0);
/* 133 */       return calendar;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 141 */     if (!st.hasMoreTokens()) {
/* 142 */       return calendar;
/*     */     }
/* 144 */     String tok = st.nextToken();
/* 145 */     if (tok.equals(":")) {
/* 146 */       if (st.hasMoreTokens()) {
/* 147 */         int secondes = Integer.parseInt(st.nextToken());
/* 148 */         calendar.set(13, secondes);
/* 149 */         if (!st.hasMoreTokens()) {
/* 150 */           return calendar;
/*     */         }
/*     */         
/* 153 */         tok = st.nextToken();
/* 154 */         if (tok.equals("."))
/*     */         {
/* 156 */           String nt = st.nextToken();
/* 157 */           while (nt.length() < 3) {
/* 158 */             nt = nt + "0";
/*     */           }
/* 160 */           nt = nt.substring(0, 3);
/* 161 */           int millisec = Integer.parseInt(nt);
/*     */           
/* 163 */           calendar.set(14, millisec);
/* 164 */           if (!st.hasMoreTokens()) {
/* 165 */             return calendar;
/*     */           }
/* 167 */           tok = st.nextToken();
/*     */         } else {
/* 169 */           calendar.set(14, 0);
/*     */         }
/*     */       } else {
/* 172 */         throw new NumberFormatException("No secondes specified");
/*     */       }
/*     */     } else {
/* 175 */       calendar.set(13, 0);
/* 176 */       calendar.set(14, 0);
/*     */     }
/*     */     
/* 179 */     if (!tok.equals("Z")) {
/* 180 */       if ((!tok.equals("+")) && (!tok.equals("-"))) {
/* 181 */         throw new NumberFormatException("only Z, + or - allowed");
/*     */       }
/* 183 */       boolean plus = tok.equals("+");
/* 184 */       if (!st.hasMoreTokens()) {
/* 185 */         throw new NumberFormatException("Missing hour field");
/*     */       }
/* 187 */       int tzhour = Integer.parseInt(st.nextToken());
/* 188 */       int tzmin = 0;
/* 189 */       if ((check(st, ":")) && (st.hasMoreTokens())) {
/* 190 */         tzmin = Integer.parseInt(st.nextToken());
/*     */       } else {
/* 192 */         throw new NumberFormatException("Missing minute field");
/*     */       }
/* 194 */       if (plus) {
/* 195 */         calendar.add(10, -tzhour);
/* 196 */         calendar.add(12, -tzmin);
/*     */       } else {
/* 198 */         calendar.add(10, tzhour);
/* 199 */         calendar.add(12, tzmin);
/*     */       }
/*     */     }
/* 202 */     return calendar;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date parse(String isodate)
/*     */     throws NumberFormatException
/*     */   {
/* 213 */     Calendar calendar = getCalendar(isodate);
/* 214 */     return calendar.getTime();
/*     */   }
/*     */   
/*     */   private static String twoDigit(int i) {
/* 218 */     if ((i >= 0) && (i < 10)) {
/* 219 */       return "0" + String.valueOf(i);
/*     */     }
/* 221 */     return String.valueOf(i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getIsoDate(Date date)
/*     */   {
/* 230 */     Calendar calendar = new GregorianCalendar();
/* 231 */     calendar.setTime(date);
/* 232 */     StringBuffer buffer = new StringBuffer();
/* 233 */     buffer.append(calendar.get(1));
/* 234 */     buffer.append("-");
/* 235 */     buffer.append(twoDigit(calendar.get(2) + 1));
/* 236 */     buffer.append("-");
/* 237 */     buffer.append(twoDigit(calendar.get(5)));
/* 238 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getIsoDateTime(Date date)
/*     */   {
/* 247 */     Calendar calendar = new GregorianCalendar();
/* 248 */     calendar.setTime(date);
/* 249 */     StringBuffer buffer = new StringBuffer();
/* 250 */     buffer.append(calendar.get(1));
/* 251 */     buffer.append("-");
/* 252 */     buffer.append(twoDigit(calendar.get(2) + 1));
/* 253 */     buffer.append("-");
/* 254 */     buffer.append(twoDigit(calendar.get(5)));
/* 255 */     buffer.append("T");
/* 256 */     buffer.append(twoDigit(calendar.get(11)));
/* 257 */     buffer.append(":");
/* 258 */     buffer.append(twoDigit(calendar.get(12)));
/* 259 */     buffer.append(":");
/* 260 */     buffer.append(twoDigit(calendar.get(13)));
/* 261 */     buffer.append(".");
/* 262 */     buffer.append(twoDigit(calendar.get(14) / 10));
/* 263 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getIsoDateTimeZone(Date date)
/*     */   {
/* 272 */     Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
/* 273 */     calendar.setTime(date);
/* 274 */     StringBuffer buffer = new StringBuffer();
/* 275 */     buffer.append(calendar.get(1));
/* 276 */     buffer.append("-");
/* 277 */     buffer.append(twoDigit(calendar.get(2) + 1));
/* 278 */     buffer.append("-");
/* 279 */     buffer.append(twoDigit(calendar.get(5)));
/* 280 */     buffer.append("T");
/* 281 */     buffer.append(twoDigit(calendar.get(11)));
/* 282 */     buffer.append(":");
/* 283 */     buffer.append(twoDigit(calendar.get(12)));
/* 284 */     buffer.append(":");
/* 285 */     buffer.append(twoDigit(calendar.get(13)));
/* 286 */     buffer.append(".");
/* 287 */     buffer.append(twoDigit(calendar.get(14) / 10));
/* 288 */     buffer.append("Z");
/* 289 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getIsoTime(Date date)
/*     */   {
/* 298 */     Calendar calendar = new GregorianCalendar();
/* 299 */     calendar.setTime(date);
/* 300 */     StringBuffer buffer = new StringBuffer();
/* 301 */     buffer.append(twoDigit(calendar.get(11)));
/* 302 */     buffer.append(":");
/* 303 */     buffer.append(twoDigit(calendar.get(12)));
/* 304 */     buffer.append(":");
/* 305 */     buffer.append(twoDigit(calendar.get(13)));
/* 306 */     buffer.append(".");
/* 307 */     buffer.append(twoDigit(calendar.get(14) / 10));
/* 308 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getIsoTimeZone(Date date)
/*     */   {
/* 317 */     Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
/* 318 */     calendar.setTime(date);
/* 319 */     StringBuffer buffer = new StringBuffer();
/* 320 */     buffer.append(twoDigit(calendar.get(11)));
/* 321 */     buffer.append(":");
/* 322 */     buffer.append(twoDigit(calendar.get(12)));
/* 323 */     buffer.append(":");
/* 324 */     buffer.append(twoDigit(calendar.get(13)));
/* 325 */     buffer.append(".");
/* 326 */     buffer.append(twoDigit(calendar.get(14) / 10));
/* 327 */     buffer.append("Z");
/* 328 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/services/ISO8601Date.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */