/*     */ package net.sbbi.upnp.services;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface ServiceStateVariableTypes
/*     */ {
/*     */   public static final String UI1 = "ui1";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String UI2 = "ui2";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String UI4 = "ui4";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String I1 = "i1";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String I2 = "i2";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String I4 = "i4";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String INT = "int";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String R4 = "r4";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String R8 = "r8";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String NUMBER = "number";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String FIXED_14_4 = "fixed.14.4";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String FLOAT = "float";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String CHAR = "char";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String STRING = "string";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String DATE = "date";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String DATETIME = "dateTime";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String DATETIME_TZ = "dateTime.tz";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String TIME = "time";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String TIME_TZ = "time.tz";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String BOOLEAN = "boolean";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String BIN_BASE64 = "bin.base64";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String BIN_HEX = "bin.hex";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String URI = "uri";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String UUID = "uuid";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 163 */   public static final int UI1_INT = "ui1".hashCode();
/* 164 */   public static final int UI2_INT = "ui2".hashCode();
/* 165 */   public static final int UI4_INT = "ui4".hashCode();
/* 166 */   public static final int I1_INT = "i1".hashCode();
/* 167 */   public static final int I2_INT = "i2".hashCode();
/* 168 */   public static final int I4_INT = "i4".hashCode();
/* 169 */   public static final int INT_INT = "int".hashCode();
/* 170 */   public static final int R4_INT = "r4".hashCode();
/* 171 */   public static final int R8_INT = "r8".hashCode();
/* 172 */   public static final int NUMBER_INT = "number".hashCode();
/* 173 */   public static final int FIXED_14_4_INT = "fixed.14.4".hashCode();
/* 174 */   public static final int FLOAT_INT = "float".hashCode();
/* 175 */   public static final int CHAR_INT = "char".hashCode();
/* 176 */   public static final int STRING_INT = "string".hashCode();
/* 177 */   public static final int DATE_INT = "date".hashCode();
/* 178 */   public static final int DATETIME_INT = "dateTime".hashCode();
/* 179 */   public static final int DATETIME_TZ_INT = "dateTime.tz".hashCode();
/* 180 */   public static final int TIME_INT = "time".hashCode();
/* 181 */   public static final int TIME_TZ_INT = "time.tz".hashCode();
/* 182 */   public static final int BOOLEAN_INT = "boolean".hashCode();
/* 183 */   public static final int BIN_BASE64_INT = "bin.base64".hashCode();
/* 184 */   public static final int BIN_HEX_INT = "bin.hex".hashCode();
/* 185 */   public static final int URI_INT = "uri".hashCode();
/* 186 */   public static final int UUID_INT = "uuid".hashCode();
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/services/ServiceStateVariableTypes.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */