/*     */ package net.sbbi.upnp.services;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.sbbi.upnp.JXPathParser;
/*     */ import net.sbbi.upnp.devices.UPNPDevice;
/*     */ import net.sbbi.upnp.devices.UPNPRootDevice;
/*     */ import org.apache.commons.jxpath.Container;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ import org.apache.commons.jxpath.xml.DocumentContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UPNPService
/*     */ {
/*     */   protected String serviceType;
/*     */   protected String serviceId;
/*     */   private int specVersionMajor;
/*     */   private int specVersionMinor;
/*     */   protected URL SCPDURL;
/*     */   protected String SCPDURLData;
/*     */   protected URL controlURL;
/*     */   protected URL eventSubURL;
/*     */   protected UPNPDevice serviceOwnerDevice;
/*     */   protected Map UPNPServiceActions;
/*     */   protected Map UPNPServiceStateVariables;
/*     */   private String USN;
/*  81 */   private boolean parsedSCPD = false;
/*     */   private DocumentContainer UPNPService;
/*     */   
/*     */   public UPNPService(JXPathContext serviceCtx, URL baseDeviceURL, UPNPDevice serviceOwnerDevice) throws MalformedURLException {
/*  85 */     this.serviceOwnerDevice = serviceOwnerDevice;
/*  86 */     this.serviceType = ((String)serviceCtx.getValue("serviceType"));
/*  87 */     this.serviceId = ((String)serviceCtx.getValue("serviceId"));
/*  88 */     this.SCPDURL = UPNPRootDevice.getURL((String)serviceCtx.getValue("SCPDURL"), baseDeviceURL);
/*  89 */     this.controlURL = UPNPRootDevice.getURL((String)serviceCtx.getValue("controlURL"), baseDeviceURL);
/*  90 */     this.eventSubURL = UPNPRootDevice.getURL((String)serviceCtx.getValue("eventSubURL"), baseDeviceURL);
/*  91 */     this.USN = serviceOwnerDevice.getUDN().concat("::").concat(this.serviceType);
/*     */   }
/*     */   
/*     */   public String getServiceType() {
/*  95 */     return this.serviceType;
/*     */   }
/*     */   
/*     */   public String getServiceId() {
/*  99 */     return this.serviceId;
/*     */   }
/*     */   
/*     */   public String getUSN() {
/* 103 */     return this.USN;
/*     */   }
/*     */   
/*     */   public URL getSCPDURL() {
/* 107 */     return this.SCPDURL;
/*     */   }
/*     */   
/*     */   public URL getControlURL() {
/* 111 */     return this.controlURL;
/*     */   }
/*     */   
/*     */   public URL getEventSubURL() {
/* 115 */     return this.eventSubURL;
/*     */   }
/*     */   
/*     */   public int getSpecVersionMajor() {
/* 119 */     lazyInitiate();
/* 120 */     return this.specVersionMajor;
/*     */   }
/*     */   
/*     */   public int getSpecVersionMinor() {
/* 124 */     lazyInitiate();
/* 125 */     return this.specVersionMinor;
/*     */   }
/*     */   
/*     */   public UPNPDevice getServiceOwnerDevice() {
/* 129 */     return this.serviceOwnerDevice;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServiceAction getUPNPServiceAction(String actionName)
/*     */   {
/* 138 */     lazyInitiate();
/* 139 */     return (ServiceAction)this.UPNPServiceActions.get(actionName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServiceStateVariable getUPNPServiceStateVariable(String stateVariableName)
/*     */   {
/* 148 */     lazyInitiate();
/* 149 */     return (ServiceStateVariable)this.UPNPServiceStateVariables.get(stateVariableName);
/*     */   }
/*     */   
/*     */   public Iterator getAvailableActionsName() {
/* 153 */     lazyInitiate();
/* 154 */     return this.UPNPServiceActions.keySet().iterator();
/*     */   }
/*     */   
/*     */   public int getAvailableActionsSize() {
/* 158 */     lazyInitiate();
/* 159 */     return this.UPNPServiceActions.keySet().size();
/*     */   }
/*     */   
/*     */   public Iterator getAvailableStateVariableName() {
/* 163 */     lazyInitiate();
/* 164 */     return this.UPNPServiceStateVariables.keySet().iterator();
/*     */   }
/*     */   
/*     */   public int getAvailableStateVariableSize() {
/* 168 */     lazyInitiate();
/* 169 */     return this.UPNPServiceStateVariables.keySet().size();
/*     */   }
/*     */   
/*     */   private void parseSCPD() {
/*     */     try {
/* 174 */       DocumentContainer.registerXMLParser("DOM", new JXPathParser());
/* 175 */       this.UPNPService = new DocumentContainer(this.SCPDURL, "DOM");
/* 176 */       JXPathContext context = JXPathContext.newContext(this);
/* 177 */       Pointer rootPtr = context.getPointer("UPNPService/scpd");
/* 178 */       JXPathContext rootCtx = context.getRelativeContext(rootPtr);
/*     */       
/* 180 */       this.specVersionMajor = Integer.parseInt((String)rootCtx.getValue("specVersion/major"));
/* 181 */       this.specVersionMinor = Integer.parseInt((String)rootCtx.getValue("specVersion/minor"));
/*     */       
/* 183 */       parseServiceStateVariables(rootCtx);
/*     */       
/* 185 */       Pointer actionsListPtr = rootCtx.getPointer("actionList");
/* 186 */       JXPathContext actionsListCtx = context.getRelativeContext(actionsListPtr);
/* 187 */       Double arraySize = (Double)actionsListCtx.getValue("count( action )");
/* 188 */       this.UPNPServiceActions = new HashMap();
/* 189 */       for (int i = 1; i <= arraySize.intValue(); i++) {
/* 190 */         ServiceAction action = new ServiceAction();
/* 191 */         action.name = ((String)actionsListCtx.getValue("action[" + i + "]/name"));
/* 192 */         action.parent = this;
/* 193 */         Pointer argumentListPtr = null;
/*     */         try {
/* 195 */           argumentListPtr = actionsListCtx.getPointer("action[" + i + "]/argumentList");
/*     */         }
/*     */         catch (JXPathException ex) {}
/*     */         
/* 199 */         if (argumentListPtr != null) {
/* 200 */           JXPathContext argumentListCtx = actionsListCtx.getRelativeContext(argumentListPtr);
/* 201 */           Double arraySizeArgs = (Double)argumentListCtx.getValue("count( argument )");
/*     */           
/* 203 */           List orderedActionArguments = new ArrayList();
/* 204 */           for (int z = 1; z <= arraySizeArgs.intValue(); z++) {
/* 205 */             ServiceActionArgument arg = new ServiceActionArgument();
/* 206 */             arg.name = ((String)argumentListCtx.getValue("argument[" + z + "]/name"));
/* 207 */             String direction = (String)argumentListCtx.getValue("argument[" + z + "]/direction");
/* 208 */             arg.direction = (direction.equals("in") ? "in" : "out");
/* 209 */             String stateVarName = (String)argumentListCtx.getValue("argument[" + z + "]/relatedStateVariable");
/* 210 */             ServiceStateVariable stateVar = (ServiceStateVariable)this.UPNPServiceStateVariables.get(stateVarName);
/* 211 */             if (stateVar == null) {
/* 212 */               throw new IllegalArgumentException("Unable to find any state variable named " + stateVarName + " for service " + getServiceId() + " action " + action.name + " argument " + arg.name);
/*     */             }
/* 214 */             arg.relatedStateVariable = stateVar;
/* 215 */             orderedActionArguments.add(arg);
/*     */           }
/*     */           
/* 218 */           if (arraySizeArgs.intValue() > 0) {
/* 219 */             action.setActionArguments(orderedActionArguments);
/*     */           }
/*     */         }
/*     */         
/* 223 */         this.UPNPServiceActions.put(action.getName(), action);
/*     */       }
/* 225 */       this.parsedSCPD = true;
/*     */     } catch (Throwable t) {
/* 227 */       throw new RuntimeException("Error during lazy SCDP file parsing at " + this.SCPDURL, t);
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseServiceStateVariables(JXPathContext rootContext) {
/* 232 */     Pointer serviceStateTablePtr = rootContext.getPointer("serviceStateTable");
/* 233 */     JXPathContext serviceStateTableCtx = rootContext.getRelativeContext(serviceStateTablePtr);
/* 234 */     Double arraySize = (Double)serviceStateTableCtx.getValue("count( stateVariable )");
/* 235 */     this.UPNPServiceStateVariables = new HashMap();
/* 236 */     for (int i = 1; i <= arraySize.intValue(); i++) {
/* 237 */       ServiceStateVariable srvStateVar = new ServiceStateVariable();
/* 238 */       String sendEventsLcl = null;
/*     */       try {
/* 240 */         sendEventsLcl = (String)serviceStateTableCtx.getValue("stateVariable[" + i + "]/@sendEvents");
/*     */       }
/*     */       catch (JXPathException defEx) {
/* 243 */         sendEventsLcl = "yes";
/*     */       }
/* 245 */       srvStateVar.parent = this;
/* 246 */       srvStateVar.sendEvents = (!sendEventsLcl.equalsIgnoreCase("no"));
/* 247 */       srvStateVar.name = ((String)serviceStateTableCtx.getValue("stateVariable[" + i + "]/name"));
/* 248 */       srvStateVar.dataType = ((String)serviceStateTableCtx.getValue("stateVariable[" + i + "]/dataType"));
/*     */       try {
/* 250 */         srvStateVar.defaultValue = ((String)serviceStateTableCtx.getValue("stateVariable[" + i + "]/defaultValue"));
/*     */       }
/*     */       catch (JXPathException defEx) {}
/*     */       
/* 254 */       Pointer allowedValuesPtr = null;
/*     */       try {
/* 256 */         allowedValuesPtr = serviceStateTableCtx.getPointer("stateVariable[" + i + "]/allowedValueList");
/*     */       }
/*     */       catch (JXPathException ex) {}
/*     */       
/* 260 */       if (allowedValuesPtr != null) {
/* 261 */         JXPathContext allowedValuesCtx = serviceStateTableCtx.getRelativeContext(allowedValuesPtr);
/* 262 */         Double arraySizeAllowed = (Double)allowedValuesCtx.getValue("count( allowedValue )");
/* 263 */         srvStateVar.allowedvalues = new HashSet();
/* 264 */         for (int z = 1; z <= arraySizeAllowed.intValue(); z++) {
/* 265 */           String allowedValue = (String)allowedValuesCtx.getValue("allowedValue[" + z + "]");
/* 266 */           srvStateVar.allowedvalues.add(allowedValue);
/*     */         }
/*     */       }
/*     */       
/* 270 */       Pointer allowedValueRangePtr = null;
/*     */       try {
/* 272 */         allowedValueRangePtr = serviceStateTableCtx.getPointer("stateVariable[" + i + "]/allowedValueRange");
/*     */       }
/*     */       catch (JXPathException ex) {}
/*     */       
/* 276 */       if (allowedValueRangePtr != null)
/*     */       {
/* 278 */         srvStateVar.minimumRangeValue = ((String)serviceStateTableCtx.getValue("stateVariable[" + i + "]/allowedValueRange/minimum"));
/* 279 */         srvStateVar.maximumRangeValue = ((String)serviceStateTableCtx.getValue("stateVariable[" + i + "]/allowedValueRange/maximum"));
/*     */         try {
/* 281 */           srvStateVar.stepRangeValue = ((String)serviceStateTableCtx.getValue("stateVariable[" + i + "]/allowedValueRange/step"));
/*     */         }
/*     */         catch (JXPathException stepEx) {}
/*     */       }
/*     */       
/* 286 */       this.UPNPServiceStateVariables.put(srvStateVar.getName(), srvStateVar);
/*     */     }
/*     */   }
/*     */   
/*     */   private void lazyInitiate()
/*     */   {
/* 292 */     if (!this.parsedSCPD) {
/* 293 */       synchronized (this) {
/* 294 */         if (!this.parsedSCPD) {
/* 295 */           parseSCPD();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Container getUPNPService()
/*     */   {
/* 304 */     return this.UPNPService;
/*     */   }
/*     */   
/*     */   public String getSCDPData() {
/* 308 */     if (this.SCPDURLData == null) {
/*     */       try
/*     */       {
/* 311 */         InputStream in = this.SCPDURL.openConnection().getInputStream();
/* 312 */         int readen = 0;
/* 313 */         byte[] buff = new byte['Ȁ'];
/* 314 */         StringBuffer strBuff = new StringBuffer();
/* 315 */         while ((readen = in.read(buff)) != -1) {
/* 316 */           strBuff.append(new String(buff, 0, readen));
/*     */         }
/* 318 */         in.close();
/* 319 */         this.SCPDURLData = strBuff.toString();
/*     */       } catch (IOException ioEx) {
/* 321 */         return null;
/*     */       }
/*     */     }
/* 324 */     return this.SCPDURLData;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/services/UPNPService.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */