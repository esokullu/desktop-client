/*     */ package net.sbbi.upnp.jmx;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.MulticastSocket;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UPNPMBeanDevicesDiscoveryHandler
/*     */   implements Runnable
/*     */ {
/*  75 */   private static final Log log = LogFactory.getLog(UPNPMBeanDevicesDiscoveryHandler.class);
/*     */   
/*  77 */   private static final Map instances = new HashMap();
/*     */   
/*  79 */   private Set handledDevices = new HashSet();
/*     */   private MulticastSocket skt;
/*  81 */   private boolean isRunning = false;
/*  82 */   private boolean isRunningSSDPDaemon = false;
/*     */   private InetSocketAddress bindAddress;
/*     */   
/*     */   public static final UPNPMBeanDevicesDiscoveryHandler getInstance(InetSocketAddress bindAddress)
/*     */   {
/*  87 */     String key = bindAddress.toString();
/*  88 */     synchronized (instances) {
/*  89 */       UPNPMBeanDevicesDiscoveryHandler handler = (UPNPMBeanDevicesDiscoveryHandler)instances.get(key);
/*  90 */       if (handler == null) {
/*  91 */         handler = new UPNPMBeanDevicesDiscoveryHandler(bindAddress);
/*  92 */         instances.put(key, handler);
/*     */       }
/*  94 */       return handler;
/*     */     }
/*     */   }
/*     */   
/*     */   private UPNPMBeanDevicesDiscoveryHandler(InetSocketAddress bindAddress) {
/*  99 */     this.bindAddress = bindAddress;
/*     */   }
/*     */   
/*     */   protected void addUPNPMBeanDevice(UPNPMBeanDevice rootDevice) throws IOException {
/* 103 */     if (!rootDevice.isRootDevice()) return;
/* 104 */     synchronized (this.handledDevices) {
/* 105 */       for (Iterator i = this.handledDevices.iterator(); i.hasNext();) {
/* 106 */         UPNPMBeanDevice registred = (UPNPMBeanDevice)i.next();
/* 107 */         if ((registred.getDeviceType().equals(rootDevice.getDeviceType())) && (registred.getUuid().equals(rootDevice.getUuid())))
/*     */         {
/*     */ 
/* 110 */           throw new RuntimeException("An UPNPMBeanDevice object of type " + rootDevice.getDeviceType() + " with uuid " + rootDevice.getUuid() + " is already registred within this class, use a different UPNPMBeanDevice internalId");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 115 */       if (this.handledDevices.size() == 0) {
/* 116 */         Thread runner = new Thread(this, "UPNPMBeanDeviceDiscoveryHandler " + this.bindAddress.toString());
/* 117 */         runner.setDaemon(true);
/* 118 */         runner.start();
/*     */         
/* 120 */         SSDPAliveBroadcastMessageSender sender = new SSDPAliveBroadcastMessageSender(this.handledDevices, null);
/* 121 */         Thread runner2 = new Thread(sender, "SSDPAliveBroadcastMessageSender " + this.bindAddress.toString());
/* 122 */         runner2.setDaemon(true);
/* 123 */         runner2.start();
/*     */       }
/*     */       
/* 126 */       sendHello(rootDevice);
/* 127 */       this.handledDevices.add(rootDevice);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void removeUPNPMBeanDevice(UPNPMBeanDevice rootDevice) throws IOException {
/* 132 */     if (!rootDevice.isRootDevice()) return;
/* 133 */     synchronized (this.handledDevices) {
/* 134 */       if (this.handledDevices.contains(rootDevice)) {
/* 135 */         this.handledDevices.remove(rootDevice);
/* 136 */         sendByeBye(rootDevice);
/* 137 */         if ((this.handledDevices.size() == 0) && (this.isRunning)) {
/* 138 */           this.isRunning = false;
/* 139 */           this.isRunningSSDPDaemon = false;
/* 140 */           this.skt.close();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void sendHello(UPNPMBeanDevice dv) throws IOException {
/* 147 */     InetAddress group = InetAddress.getByName("239.255.255.250");
/* 148 */     MulticastSocket multi = new MulticastSocket(this.bindAddress.getPort());
/* 149 */     multi.setInterface(this.bindAddress.getAddress());
/* 150 */     multi.setTimeToLive(dv.getSSDPTTL());
/*     */     
/* 152 */     List packets = getReplyMessages(dv, true, dv.getSSDPAliveDelay());
/* 153 */     for (int i = 0; i < packets.size(); i++) {
/* 154 */       String packet = (String)packets.get(i);
/* 155 */       if (log.isDebugEnabled()) log.debug("Sending ssdp alive message on 239.255.255.250:1900 multicast address:\n" + packet.toString());
/* 156 */       byte[] pk = packet.getBytes();
/* 157 */       multi.send(new DatagramPacket(pk, pk.length, group, 1900));
/*     */     }
/* 159 */     multi.close();
/*     */   }
/*     */   
/*     */   private void sendByeBye(UPNPMBeanDevice dv) throws IOException {
/* 163 */     InetAddress group = InetAddress.getByName("239.255.255.250");
/* 164 */     MulticastSocket multi = new MulticastSocket(this.bindAddress.getPort());
/* 165 */     multi.setInterface(this.bindAddress.getAddress());
/* 166 */     multi.setTimeToLive(dv.getSSDPTTL());
/*     */     
/* 168 */     List packets = getByeByeReplyMessages(dv);
/* 169 */     for (int i = 0; i < packets.size(); i++) {
/* 170 */       String packet = (String)packets.get(i);
/* 171 */       if (log.isDebugEnabled()) log.debug("Sending ssdp:byebye message on 239.255.255.250:1900 multicast address:\n" + packet.toString());
/* 172 */       byte[] pk = packet.getBytes();
/* 173 */       multi.send(new DatagramPacket(pk, pk.length, group, 1900));
/*     */     }
/* 175 */     multi.close();
/*     */   }
/*     */   
/*     */ 
/*     */   private List getReplyMessages(UPNPMBeanDevice rootDevice, boolean ssdpAliveMsg, int maxAge)
/*     */   {
/* 181 */     List rtrVal = new ArrayList();
/*     */     
/* 183 */     StringBuffer basePacket = new StringBuffer();
/* 184 */     StringBuffer packet = null;
/* 185 */     if (ssdpAliveMsg) {
/* 186 */       basePacket.append("NOTIFY * HTTP/1.1\r\n");
/* 187 */       basePacket.append("HOST: 239.255.255.250:1900\r\n");
/*     */     } else {
/* 189 */       basePacket.append("HTTP/1.1 200 OK\r\n");
/*     */     }
/* 191 */     basePacket.append("CACHE-CONTROL: max-age = ").append(maxAge).append("\r\n");
/* 192 */     basePacket.append("LOCATION: ").append(rootDevice.getLocation()).append("\r\n");
/* 193 */     basePacket.append("SERVER: ").append(UPNPMBeanDevice.IMPL_NAME).append("\r\n");
/*     */     
/*     */ 
/* 196 */     packet = new StringBuffer(basePacket.toString());
/* 197 */     if (ssdpAliveMsg) {
/* 198 */       packet.append("NT: uuid:").append(rootDevice.getUuid()).append("\r\n");
/* 199 */       packet.append("NTS: ssdp:alive\r\n");
/*     */     } else {
/* 201 */       packet.append("ST: uuid:").append(rootDevice.getUuid()).append("\r\n");
/* 202 */       packet.append("EXT:\r\n");
/*     */     }
/* 204 */     packet.append("USN: uuid:").append(rootDevice.getUuid()).append("\r\n\r\n");
/* 205 */     rtrVal.add(packet.toString());
/*     */     
/* 207 */     packet = new StringBuffer(basePacket.toString());
/* 208 */     if (ssdpAliveMsg) {
/* 209 */       packet.append("NT: ").append(rootDevice.getDeviceType()).append("\r\n");
/* 210 */       packet.append("NTS: ssdp:alive\r\n");
/*     */     } else {
/* 212 */       packet.append("ST: ").append(rootDevice.getDeviceType()).append("\r\n");
/* 213 */       packet.append("EXT:\r\n");
/*     */     }
/* 215 */     packet.append("USN: uuid:").append(rootDevice.getUuid()).append("::").append(rootDevice.getDeviceType()).append("\r\n\r\n");
/* 216 */     rtrVal.add(packet.toString());
/*     */     
/* 218 */     packet = new StringBuffer(basePacket.toString());
/* 219 */     if (ssdpAliveMsg) {
/* 220 */       packet.append("NT: upnp:rootdevice\r\n");
/* 221 */       packet.append("NTS: ssdp:alive\r\n");
/*     */     } else {
/* 223 */       packet.append("ST: upnp:rootdevice\r\n");
/* 224 */       packet.append("EXT:\r\n");
/*     */     }
/* 226 */     packet.append("USN: uuid:").append(rootDevice.getUuid()).append("::upnp:rootdevice\r\n\r\n");
/* 227 */     rtrVal.add(packet.toString());
/*     */     
/* 229 */     packet = new StringBuffer(basePacket.toString());
/*     */     
/* 231 */     List services = new ArrayList();
/* 232 */     services.addAll(rootDevice.getUPNPMBeanServices());
/*     */     
/* 234 */     for (Iterator i = rootDevice.getUPNPMBeanChildrens().iterator(); i.hasNext();) {
/* 235 */       UPNPMBeanDevice child = (UPNPMBeanDevice)i.next();
/* 236 */       services.addAll(child.getUPNPMBeanServices());
/*     */       
/* 238 */       packet = new StringBuffer(basePacket.toString());
/* 239 */       if (ssdpAliveMsg) {
/* 240 */         packet.append("NT: uuid:").append(child.getUuid()).append("\r\n");
/* 241 */         packet.append("NTS: ssdp:alive\r\n");
/*     */       } else {
/* 243 */         packet.append("ST: uuid:").append(child.getUuid()).append("\r\n");
/* 244 */         packet.append("EXT:\r\n");
/*     */       }
/* 246 */       packet.append("USN: uuid:").append(child.getUuid()).append("\r\n\r\n");
/* 247 */       rtrVal.add(packet.toString());
/*     */       
/* 249 */       packet = new StringBuffer(basePacket.toString());
/* 250 */       if (ssdpAliveMsg) {
/* 251 */         packet.append("NT: ").append(child.getDeviceType()).append("\r\n");
/* 252 */         packet.append("NTS: ssdp:alive\r\n");
/*     */       } else {
/* 254 */         packet.append("ST: ").append(child.getDeviceType()).append("\r\n");
/* 255 */         packet.append("EXT:\r\n");
/*     */       }
/* 257 */       packet.append("USN: uuid:").append(child.getUuid()).append("::").append(child.getDeviceType()).append("\r\n\r\n");
/* 258 */       rtrVal.add(packet.toString());
/*     */     }
/*     */     
/*     */ 
/* 262 */     for (Iterator i = services.iterator(); i.hasNext();) {
/* 263 */       UPNPMBeanService srv = (UPNPMBeanService)i.next();
/*     */       
/* 265 */       if (ssdpAliveMsg) {
/* 266 */         packet.append("NT: ").append(srv.getServiceType()).append("\r\n");
/* 267 */         packet.append("NTS: ssdp:alive\r\n");
/*     */       } else {
/* 269 */         packet.append("ST: ").append(srv.getServiceType()).append("\r\n");
/* 270 */         packet.append("EXT:\r\n");
/*     */       }
/* 272 */       packet.append("USN: uuid:").append(srv.getDeviceUUID()).append("::").append(srv.getServiceType()).append("\r\n\r\n");
/* 273 */       rtrVal.add(packet.toString());
/*     */     }
/*     */     
/* 276 */     return rtrVal;
/*     */   }
/*     */   
/*     */   private List getByeByeReplyMessages(UPNPMBeanDevice rootDevice) {
/* 280 */     List rtrVal = new ArrayList();
/*     */     
/* 282 */     StringBuffer basePacket = new StringBuffer();
/* 283 */     StringBuffer packet = null;
/* 284 */     basePacket.append("NOTIFY * HTTP/1.1\r\n");
/* 285 */     basePacket.append("HOST: 239.255.255.250:1900\r\n");
/*     */     
/* 287 */     packet = new StringBuffer(basePacket.toString());
/* 288 */     packet.append("NT: uuid:").append(rootDevice.getUuid()).append("\r\n");
/* 289 */     packet.append("NTS: ssdp:byebye\r\n");
/* 290 */     packet.append("USN: uuid:").append(rootDevice.getUuid()).append("\r\n\r\n");
/* 291 */     rtrVal.add(packet.toString());
/*     */     
/* 293 */     packet = new StringBuffer(basePacket.toString());
/* 294 */     packet.append("NT: ").append(rootDevice.getDeviceType()).append("\r\n");
/* 295 */     packet.append("NTS: ssdp:byebye\r\n");
/* 296 */     packet.append("USN: uuid:").append(rootDevice.getUuid()).append("::").append(rootDevice.getDeviceType()).append("\r\n\r\n");
/* 297 */     rtrVal.add(packet.toString());
/*     */     
/* 299 */     packet = new StringBuffer(basePacket.toString());
/* 300 */     packet.append("NT: upnp:rootdevice\r\n");
/* 301 */     packet.append("NTS: ssdp:byebye\r\n");
/* 302 */     packet.append("USN: uuid:").append(rootDevice.getUuid()).append("::upnp:rootdevice\r\n\r\n");
/* 303 */     rtrVal.add(packet.toString());
/*     */     
/* 305 */     List services = new ArrayList();
/* 306 */     services.addAll(rootDevice.getUPNPMBeanServices());
/*     */     
/* 308 */     for (Iterator i = rootDevice.getUPNPMBeanChildrens().iterator(); i.hasNext();) {
/* 309 */       UPNPMBeanDevice child = (UPNPMBeanDevice)i.next();
/* 310 */       services.addAll(child.getUPNPMBeanServices());
/*     */       
/* 312 */       packet = new StringBuffer(basePacket.toString());
/* 313 */       packet.append("NT: uuid:").append(child.getUuid()).append("\r\n");
/* 314 */       packet.append("NTS: ssdp:byebye\r\n");
/* 315 */       packet.append("USN: uuid:").append(child.getUuid()).append("\r\n\r\n");
/* 316 */       rtrVal.add(packet.toString());
/*     */       
/* 318 */       packet = new StringBuffer(basePacket.toString());
/* 319 */       packet.append("NT: ").append(child.getDeviceType()).append("\r\n");
/* 320 */       packet.append("NTS: ssdp:byebye\r\n");
/* 321 */       packet.append("USN: uuid:").append(child.getUuid()).append("::").append(child.getDeviceType()).append("\r\n\r\n");
/* 322 */       rtrVal.add(packet.toString());
/*     */     }
/*     */     
/*     */ 
/* 326 */     for (Iterator i = services.iterator(); i.hasNext();) {
/* 327 */       UPNPMBeanService srv = (UPNPMBeanService)i.next();
/*     */       
/* 329 */       packet = new StringBuffer(basePacket.toString());
/* 330 */       packet.append("NT: urn:").append(srv.getServiceType()).append("\r\n");
/* 331 */       packet.append("NTS: ssdp:byebye\r\n");
/* 332 */       packet.append("USN: uuid:").append(srv.getDeviceUUID()).append("::").append(srv.getServiceType()).append("\r\n\r\n");
/* 333 */       rtrVal.add(packet.toString());
/*     */     }
/* 335 */     return rtrVal;
/*     */   }
/*     */   
/*     */   public void run() {
/* 339 */     InetAddress group = null;
/*     */     try {
/* 341 */       group = InetAddress.getByName("239.255.255.250");
/* 342 */       this.skt = new MulticastSocket(1900);
/* 343 */       this.skt.setInterface(this.bindAddress.getAddress());
/* 344 */       this.skt.joinGroup(group);
/*     */     } catch (IOException ex) {
/* 346 */       log.error("Error during multicast socket creation, thread cannot start", ex);
/* 347 */       return;
/*     */     }
/* 349 */     this.isRunning = true;
/* 350 */     while (this.isRunning)
/*     */       try {
/* 352 */         byte[] buffer = new byte['က'];
/* 353 */         DatagramPacket packet = new DatagramPacket(buffer, buffer.length, group, this.bindAddress.getPort());
/* 354 */         this.skt.receive(packet);
/* 355 */         String received = new String(packet.getData(), 0, packet.getLength());
/* 356 */         if (log.isDebugEnabled()) log.debug("Received message:\n" + received);
/* 357 */         HttpRequest req = new HttpRequest(received);
/* 358 */         if (req.getHttpCommand().equals("M-SEARCH")) {
/* 359 */           String man = req.getHTTPHeaderField("MAN");
/* 360 */           if (man.equals("\"ssdp:discover\"")) {
/* 361 */             String searchTarget = req.getHTTPHeaderField("ST");
/*     */             
/*     */ 
/* 364 */             if (searchTarget.equals("upnp:rootdevice")) {
/* 365 */               MulticastSocket multi = new MulticastSocket();
/* 366 */               multi.setInterface(this.bindAddress.getAddress());
/* 367 */               for (Iterator i = this.handledDevices.iterator(); i.hasNext();) {
/* 368 */                 UPNPMBeanDevice dv = (UPNPMBeanDevice)i.next();
/* 369 */                 List packets = getReplyMessages(dv, false, dv.getSSDPAliveDelay());
/* 370 */                 for (int z = 0; z < packets.size(); z++) {
/* 371 */                   String pack = (String)packets.get(z);
/* 372 */                   if (log.isDebugEnabled()) log.debug("Sending http reply message on " + packet.getAddress() + ":" + packet.getPort() + " multicast address:\n" + pack.toString());
/* 373 */                   byte[] pk = pack.getBytes();
/* 374 */                   multi.setTimeToLive(dv.getSSDPTTL());
/* 375 */                   multi.send(new DatagramPacket(pk, pk.length, packet.getAddress(), packet.getPort()));
/*     */                 }
/*     */               }
/* 378 */               multi.close();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 385 */         if (this.isRunning)
/* 386 */           log.error("Error during multicast socket IO operations", ex);
/*     */       }
/*     */   }
/*     */   
/*     */   private class SSDPAliveBroadcastMessageSender
/*     */     implements Runnable {
/* 392 */     SSDPAliveBroadcastMessageSender(Set x1, UPNPMBeanDevicesDiscoveryHandler.1 x2) { this(x1); }
/*     */     
/* 394 */     private Set devices = new HashSet();
/*     */     
/* 396 */     private Map devicesLastBroadCast = new HashMap();
/*     */     
/*     */     private SSDPAliveBroadcastMessageSender(Set upnpRootDevices) {
/* 399 */       this.devices = upnpRootDevices;
/*     */     }
/*     */     
/*     */     public void run() {
/* 403 */       UPNPMBeanDevicesDiscoveryHandler.this.isRunningSSDPDaemon = true;
/* 404 */       while (UPNPMBeanDevicesDiscoveryHandler.this.isRunningSSDPDaemon) { Iterator i;
/* 405 */         synchronized (this.devices)
/*     */         {
/* 407 */           for (i = this.devices.iterator(); i.hasNext();) {
/* 408 */             UPNPMBeanDevice dv = (UPNPMBeanDevice)i.next();
/* 409 */             String key = dv.getUuid();
/* 410 */             long deviceDelay = dv.getSSDPAliveDelay();
/* 411 */             Long lastCall = (Long)this.devicesLastBroadCast.get(key);
/* 412 */             if (lastCall == null) {
/* 413 */               lastCall = new Long(System.currentTimeMillis() + deviceDelay * 60L + 1000L);
/* 414 */               this.devicesLastBroadCast.put(key, lastCall);
/*     */             }
/* 416 */             if (lastCall.longValue() + deviceDelay * 60L < System.currentTimeMillis()) {
/*     */               try {
/* 418 */                 InetAddress group = InetAddress.getByName("239.255.255.250");
/* 419 */                 MulticastSocket multi = new MulticastSocket(UPNPMBeanDevicesDiscoveryHandler.this.bindAddress.getPort());
/* 420 */                 multi.setInterface(UPNPMBeanDevicesDiscoveryHandler.this.bindAddress.getAddress());
/* 421 */                 multi.setTimeToLive(dv.getSSDPTTL());
/* 422 */                 multi.joinGroup(group);
/* 423 */                 List packets = UPNPMBeanDevicesDiscoveryHandler.this.getReplyMessages(dv, true, dv.getSSDPAliveDelay());
/* 424 */                 for (int z = 0; z < packets.size(); z++) {
/* 425 */                   String pack = (String)packets.get(z);
/* 426 */                   if (UPNPMBeanDevicesDiscoveryHandler.log.isDebugEnabled()) UPNPMBeanDevicesDiscoveryHandler.log.debug("Sending http message on " + group.getAddress() + ":1900 multicast address:\n" + pack.toString());
/* 427 */                   byte[] pk = pack.getBytes();
/* 428 */                   multi.send(new DatagramPacket(pk, pk.length, group, 1900));
/*     */                 }
/* 430 */                 multi.leaveGroup(group);
/* 431 */                 multi.close();
/* 432 */                 this.devicesLastBroadCast.put(key, new Long(System.currentTimeMillis()));
/*     */               } catch (IOException ex) {
/* 434 */                 UPNPMBeanDevicesDiscoveryHandler.log.error("Error occured during SSDP alive broadcast message sending", ex);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         try {
/* 440 */           Thread.sleep(1000L);
/*     */         } catch (InterruptedException ex) {
/* 442 */           Thread.currentThread().interrupt();
/* 443 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/UPNPMBeanDevicesDiscoveryHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */