/*    */ package net.sbbi.upnp.jmx;
/*    */ 
/*    */ import java.util.Set;
/*    */ import javax.management.MBeanRegistration;
/*    */ import javax.management.MalformedObjectNameException;
/*    */ import javax.management.ObjectName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface UPNPDiscoveryMBean
/*    */   extends MBeanRegistration
/*    */ {
/* 70 */   public static final String SSDP_ALIVE_NOTIFICATION = (1.class$net$sbbi$upnp$jmx$UPNPDiscoveryMBean == null ? (1.class$net$sbbi$upnp$jmx$UPNPDiscoveryMBean = 1.class$("net.sbbi.upnp.jmx.UPNPDiscoveryMBean")) : 1.class$net$sbbi$upnp$jmx$UPNPDiscoveryMBean).getName() + ".ssdp.alive";
/*    */   
/*    */ 
/*    */ 
/* 74 */   public static final String SSDP_BYEBYE_NOTIFICATION = (1.class$net$sbbi$upnp$jmx$UPNPDiscoveryMBean == null ? (1.class$net$sbbi$upnp$jmx$UPNPDiscoveryMBean = 1.class$("net.sbbi.upnp.jmx.UPNPDiscoveryMBean")) : 1.class$net$sbbi$upnp$jmx$UPNPDiscoveryMBean).getName() + ".ssdp.byebye";
/*    */   
/*    */   public abstract Set getSearchTargets();
/*    */   
/*    */   public abstract ObjectName[] getRegisteredUPNPServiceMBeans(String paramString)
/*    */     throws MalformedObjectNameException;
/*    */   
/*    */   public abstract String[] getRegisteredUPNPServiceMBeansUDNs();
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/UPNPDiscoveryMBean.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */