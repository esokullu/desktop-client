/*    */ package net.sbbi.upnp.jmx;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import javax.management.IntrospectionException;
/*    */ import javax.management.MBeanAttributeInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UPNPAttributeInfo
/*    */   extends MBeanAttributeInfo
/*    */ {
/*    */   public UPNPAttributeInfo(String name1, String name2, Method method1, Method method2)
/*    */     throws IntrospectionException
/*    */   {
/* 64 */     super(name1, name2, method1, method2);
/*    */   }
/*    */   
/*    */   public UPNPAttributeInfo(String name1, String name2, String name3, boolean boolean1, boolean boolean2, boolean boolean3) {
/* 68 */     super(name1, name2, name3, boolean1, boolean2, boolean3);
/*    */   }
/*    */   
/*    */   public void setDefaultValue(String value) {}
/*    */   
/*    */   public void addAllowedValueList(String value) {}
/*    */   
/*    */   public void setUPNPDataType(String upnpDataType) {}
/*    */   
/*    */   public void setAllowedValueRange(String minimum, String maximum, String step) {}
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/UPNPAttributeInfo.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */