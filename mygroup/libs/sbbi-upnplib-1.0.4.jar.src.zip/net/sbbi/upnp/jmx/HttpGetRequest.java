/*     */ package net.sbbi.upnp.jmx;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpGetRequest
/*     */   implements HttpRequestHandler
/*     */ {
/*  60 */   private static final HttpGetRequest instance = new HttpGetRequest();
/*     */   
/*     */   public static HttpRequestHandler getInstance() {
/*  63 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String service(Set devices, HttpRequest request)
/*     */   {
/*  70 */     StringBuffer rtr = null;
/*  71 */     String filePath = request.getHttpCommandArg();
/*     */     
/*  73 */     boolean validGet = ((filePath.startsWith("/")) && (filePath.endsWith("/desc.xml"))) || ((filePath.startsWith("/")) && (filePath.endsWith("/scpd.xml")));
/*     */     
/*     */ 
/*  76 */     if (validGet) {
/*  77 */       String uuid = null;
/*  78 */       String serviceUuid = null;
/*  79 */       int lastSlash = filePath.lastIndexOf('/');
/*  80 */       if (lastSlash != -1) {
/*  81 */         uuid = filePath.substring(1, lastSlash);
/*  82 */         serviceUuid = uuid;
/*     */         
/*  84 */         int slashIndex = uuid.indexOf("/");
/*  85 */         if (slashIndex != -1) {
/*  86 */           uuid = uuid.substring(0, slashIndex);
/*     */         }
/*     */       }
/*  89 */       if (uuid != null)
/*     */       {
/*  91 */         UPNPMBeanDevice found = null;
/*  92 */         Iterator i; synchronized (devices) {
/*  93 */           for (i = devices.iterator(); i.hasNext();) {
/*  94 */             UPNPMBeanDevice dv = (UPNPMBeanDevice)i.next();
/*  95 */             if (dv.getUuid().equals(uuid)) {
/*  96 */               found = dv;
/*  97 */               break;
/*     */             }
/*     */           }
/*     */         }
/* 101 */         if (found != null) {
/* 102 */           String contentToReturn = null;
/* 103 */           if (filePath.endsWith("/desc.xml")) {
/* 104 */             contentToReturn = found.getDeviceInfo();
/* 105 */           } else if (filePath.endsWith("/scpd.xml")) {
/* 106 */             UPNPMBeanService srv = found.getUPNPMBeanService(serviceUuid);
/* 107 */             if (srv != null) {
/* 108 */               contentToReturn = srv.getDeviceSCDP();
/*     */             }
/*     */           }
/*     */           
/* 112 */           rtr = new StringBuffer();
/* 113 */           rtr.append("HTTP/1.1 200 OK\r\n");
/* 114 */           String accept = request.getHTTPHeaderField("CONTENT-LANGUAGE");
/* 115 */           if (accept != null) {
/* 116 */             rtr.append("CONTENT-LANGUAGE: ").append(accept).append("\r\n");
/*     */           }
/* 118 */           rtr.append("CONTENT-LENGTH: ").append(contentToReturn.length()).append("\r\n");
/* 119 */           rtr.append("CONTENT-TYPE: text/xml\r\n\r\n");
/* 120 */           rtr.append(contentToReturn);
/* 121 */           return rtr.toString();
/*     */         }
/*     */       }
/*     */     }
/* 125 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/HttpGetRequest.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */