package net.sbbi.upnp.jmx;

import java.util.Set;

public abstract interface HttpRequestHandler
{
  public abstract String service(Set paramSet, HttpRequest paramHttpRequest);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/HttpRequestHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */