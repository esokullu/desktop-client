/*     */ package net.sbbi.upnp.jmx;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpRequest
/*     */ {
/*     */   private String httpCommand;
/*     */   private String httpCommandArg;
/*     */   private Map fields;
/*     */   private String body;
/*     */   
/*     */   public HttpRequest(String rawHttpRequest)
/*     */   {
/*  70 */     if (rawHttpRequest.trim().length() == 0) {
/*  71 */       throw new IllegalArgumentException("Empty HTTP request message");
/*     */     }
/*  73 */     boolean bodyParsing = false;
/*  74 */     StringBuffer bodyParsed = new StringBuffer();
/*  75 */     this.fields = new HashMap();
/*  76 */     String[] lines = rawHttpRequest.split("\\r\\n");
/*  77 */     String header = lines[0].trim();
/*  78 */     int space = header.indexOf(" ");
/*  79 */     if (space != -1) {
/*  80 */       this.httpCommand = header.substring(0, space);
/*  81 */       int space2 = header.indexOf(" ", space + 1);
/*  82 */       if (space2 != -1) {
/*  83 */         this.httpCommandArg = header.substring(space + 1, space2);
/*     */       }
/*     */     }
/*     */     
/*  87 */     for (int i = 1; i < lines.length; i++)
/*     */     {
/*  89 */       String line = lines[i];
/*  90 */       if (line.length() == 0)
/*     */       {
/*  92 */         bodyParsing = true;
/*  93 */       } else if (bodyParsing)
/*     */       {
/*  95 */         bodyParsed.append(line).append("\r\n");
/*     */ 
/*     */       }
/*  98 */       else if (line.length() > 0) {
/*  99 */         int delim = line.indexOf(':');
/* 100 */         if (delim != -1) {
/* 101 */           String key = line.substring(0, delim).toUpperCase();
/* 102 */           String value = line.substring(delim + 1).trim();
/* 103 */           this.fields.put(key, value);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 108 */     if (bodyParsing) {
/* 109 */       this.body = bodyParsed.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getHttpCommand() {
/* 114 */     return this.httpCommand;
/*     */   }
/*     */   
/*     */   public String getHttpCommandArg() {
/* 118 */     return this.httpCommandArg;
/*     */   }
/*     */   
/*     */   public String getBody() {
/* 122 */     return this.body;
/*     */   }
/*     */   
/*     */   public String getHTTPFieldElement(String fieldName, String elementName) throws IllegalArgumentException {
/* 126 */     String fieldNameValue = getHTTPHeaderField(fieldName);
/* 127 */     if (fieldName != null)
/*     */     {
/* 129 */       StringTokenizer tokenizer = new StringTokenizer(fieldNameValue.trim(), ",");
/* 130 */       while (tokenizer.countTokens() > 0) {
/* 131 */         String nextToken = tokenizer.nextToken().trim();
/* 132 */         if (nextToken.startsWith(elementName)) {
/* 133 */           int index = nextToken.indexOf("=");
/* 134 */           if (index != -1) {
/* 135 */             return nextToken.substring(index + 1);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 140 */     return null;
/*     */   }
/*     */   
/*     */   public String getHTTPHeaderField(String fieldName) throws IllegalArgumentException {
/* 144 */     return (String)this.fields.get(fieldName.toUpperCase());
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/HttpRequest.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */