/*     */ package net.sbbi.upnp.jmx;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URL;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import javax.management.DynamicMBean;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.modelmbean.ModelMBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UPNPMBeanDevice
/*     */ {
/*  82 */   private static String libVersion = null;
/*     */   
/*  84 */   static { Properties props = new Properties();
/*     */     try {
/*  86 */       props.load(UPNPMBeanDevice.class.getClassLoader().getResourceAsStream("net/sbbi/upnp/version.properties"));
/*  87 */       libVersion = props.getProperty("release.version");
/*     */     } catch (IOException ex) {
/*  89 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*  93 */   public static final String IMPL_NAME = System.getProperty("os.name") + " UPnP/1.0 SuperBonBon Industries JMX UPNP/" + libVersion;
/*  94 */   public static int DEFAULT_MAX_AGE = 1800;
/*  95 */   public static int DEFAULT_TTL = 4;
/*     */   
/*  97 */   private static InetSocketAddress defaultBindAddr = getUPNPMBeansBoundAddr();
/*     */   
/*     */   private String uuid;
/*     */   
/*     */   private String internalId;
/*     */   
/*     */   private String deviceInfo;
/*     */   private InetSocketAddress bindAddress;
/*     */   private String location;
/* 106 */   private boolean rootDevice = true;
/* 107 */   private boolean started = false;
/*     */   
/* 109 */   private List childrens = new ArrayList();
/* 110 */   private List services = new ArrayList();
/*     */   
/*     */   private String vendorDomain;
/*     */   
/*     */   private String deviceType;
/*     */   
/*     */   private String manufacturer;
/*     */   
/*     */   private int deviceVersion;
/*     */   
/*     */   private String friendlyName;
/*     */   private String modelName;
/*     */   private URL manufacturerURL;
/*     */   private String modelDescription;
/*     */   private String modelNumber;
/*     */   private URL modelURL;
/*     */   private String serialNumber;
/*     */   private String UPC;
/* 128 */   private int SSDPAliveDelay = DEFAULT_MAX_AGE;
/* 129 */   private int SSDPTTL = DEFAULT_TTL;
/*     */   
/*     */   public UPNPMBeanDevice(String deviceType, int deviceVersion, String manufacturer, String friendlyName, String modelName, String internalId) throws RuntimeException
/*     */   {
/* 133 */     this("urn:schemas-upnp-org", deviceType, deviceVersion, manufacturer, friendlyName, modelName, internalId);
/*     */   }
/*     */   
/*     */   public UPNPMBeanDevice(String vendorDomain, String deviceType, int deviceVersion, String manufacturer, String friendlyName, String modelName, String internalId)
/*     */     throws RuntimeException
/*     */   {
/* 139 */     this.vendorDomain = vendorDomain;
/* 140 */     this.deviceVersion = deviceVersion;
/* 141 */     this.deviceType = ("urn:" + this.vendorDomain + ":device:" + deviceType + ":" + this.deviceVersion);
/* 142 */     this.manufacturer = manufacturer;
/* 143 */     this.friendlyName = friendlyName;
/* 144 */     this.modelName = modelName;
/* 145 */     this.internalId = internalId;
/* 146 */     if (this.internalId == null) this.internalId = this.deviceType;
/* 147 */     this.bindAddress = defaultBindAddr;
/* 148 */     generateDeviceUUID();
/*     */   }
/*     */   
/*     */   public void setBindAddress(InetSocketAddress bindAddress) {
/* 152 */     this.bindAddress = bindAddress;
/* 153 */     generateDeviceUUID();
/*     */   }
/*     */   
/*     */   public InetSocketAddress getBindAddress() {
/* 157 */     return this.bindAddress;
/*     */   }
/*     */   
/*     */   public int getSSDPAliveDelay() {
/* 161 */     return this.SSDPAliveDelay;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSSDPAliveDelay(int aliveDelay)
/*     */   {
/* 170 */     if (aliveDelay < DEFAULT_MAX_AGE) throw new IllegalArgumentException("SSDPAliveDelay must be greater than " + DEFAULT_MAX_AGE + " secs");
/* 171 */     this.SSDPAliveDelay = aliveDelay;
/*     */   }
/*     */   
/*     */   public int getSSDPTTL() {
/* 175 */     return this.SSDPTTL;
/*     */   }
/*     */   
/*     */   public void setSSDPTTL(int ssdpttl) {
/* 179 */     this.SSDPTTL = ssdpttl;
/*     */   }
/*     */   
/*     */   protected UPNPMBeanService getUPNPMBeanService(String serviceUuid) {
/* 183 */     for (Iterator i = this.services.iterator(); i.hasNext();)
/*     */     {
/* 185 */       UPNPMBeanService srv = (UPNPMBeanService)i.next();
/* 186 */       if (srv.getServiceUUID().equals(serviceUuid)) {
/* 187 */         return srv;
/*     */       }
/*     */     }
/* 190 */     return null;
/*     */   }
/*     */   
/*     */   protected List getUPNPMBeanServices() {
/* 194 */     return this.services;
/*     */   }
/*     */   
/*     */   protected List getUPNPMBeanChildrens() {
/* 198 */     return this.childrens;
/*     */   }
/*     */   
/*     */   protected String getUuid() {
/* 202 */     return this.uuid;
/*     */   }
/*     */   
/*     */   protected String getDeviceInfo() {
/* 206 */     return this.deviceInfo;
/*     */   }
/*     */   
/*     */   public boolean isStarted() {
/* 210 */     return this.started;
/*     */   }
/*     */   
/*     */   protected String getLocation() {
/* 214 */     return this.location;
/*     */   }
/*     */   
/*     */   protected String getDeviceType() {
/* 218 */     return this.deviceType;
/*     */   }
/*     */   
/*     */   protected boolean isRootDevice() {
/* 222 */     return this.rootDevice;
/*     */   }
/*     */   
/*     */   public void addChildMBean(UPNPMBeanDevice device) {
/* 226 */     device.rootDevice = false;
/* 227 */     this.childrens.add(device);
/*     */   }
/*     */   
/*     */   public void addService(ModelMBean mbean, ObjectName beanName, MBeanServer targetServer, String serviceId, String serviceType, int serviceVersion) throws IOException
/*     */   {
/* 232 */     addService(mbean.getMBeanInfo(), beanName, targetServer, serviceId, serviceType, serviceVersion);
/*     */   }
/*     */   
/*     */   public void addService(DynamicMBean mbean, ObjectName beanName, MBeanServer targetServer, String serviceId, String serviceType, int serviceVersion) throws IOException
/*     */   {
/* 237 */     addService(mbean.getMBeanInfo(), beanName, targetServer, serviceId, serviceType, serviceVersion);
/*     */   }
/*     */   
/*     */   public void addService(Object mbean, ObjectName beanName, MBeanServer targetServer, String serviceId, String serviceType, int serviceVersion) throws IOException, IntrospectionException, InstanceNotFoundException, ReflectionException
/*     */   {
/* 242 */     addService(targetServer.getMBeanInfo(beanName), beanName, targetServer, serviceId, serviceType, serviceVersion);
/*     */   }
/*     */   
/*     */   public void addService(MBeanInfo info, ObjectName beanName, MBeanServer targetServer, String serviceId, String serviceType, int serviceVersion) throws IOException
/*     */   {
/* 247 */     UPNPMBeanService deviceService = new UPNPMBeanService(this.uuid, this.vendorDomain, serviceId, serviceType, serviceVersion, info, beanName, targetServer);
/*     */     
/* 249 */     String newServiceType = deviceService.getServiceType();
/* 250 */     for (Iterator i = this.services.iterator(); i.hasNext();) {
/* 251 */       UPNPMBeanService srv = (UPNPMBeanService)i.next();
/* 252 */       if (srv.getServiceType().equals(newServiceType)) {
/* 253 */         throw new IOException("Service type " + serviceType + " for MBeans " + beanName + " is already used by MBeans " + srv.getObjectName() + ", you must use an unique service type");
/*     */       }
/*     */     }
/* 256 */     this.services.add(deviceService);
/*     */   }
/*     */   
/*     */   private void generateDeviceUUID() {
/*     */     try {
/* 261 */       MessageDigest md5 = MessageDigest.getInstance("MD5");
/*     */       
/*     */ 
/* 264 */       md5.update(this.deviceType.getBytes());
/* 265 */       md5.update(this.internalId.getBytes());
/* 266 */       md5.update(this.bindAddress.getHostName().getBytes());
/* 267 */       StringBuffer hexString = new StringBuffer();
/* 268 */       byte[] digest = md5.digest();
/* 269 */       for (int i = 0; i < digest.length; i++) {
/* 270 */         hexString.append(Integer.toHexString(0xFF & digest[i]));
/*     */       }
/* 272 */       this.uuid = hexString.toString().toUpperCase();
/*     */     } catch (Exception ex) {
/* 274 */       RuntimeException runTimeEx = new RuntimeException("Unexpected error during MD5 hash creation, check your JRE");
/* 275 */       runTimeEx.initCause(ex);
/* 276 */       throw runTimeEx;
/*     */     }
/*     */   }
/*     */   
/*     */   public void start() throws Exception {
/* 281 */     if (!this.started) {
/* 282 */       if (this.services.size() == 0) throw new Exception("No UPNP service defined");
/* 283 */       this.deviceInfo = getRootDeviceInfo(this.bindAddress, this.uuid);
/* 284 */       this.location = ("http://" + this.bindAddress.getAddress().getHostAddress() + ":" + this.bindAddress.getPort() + "/" + this.uuid + "/desc.xml");
/*     */       
/* 286 */       UPNPMBeanDevicesRequestsHandler.getInstance(this.bindAddress).addUPNPMBeanDevice(this);
/* 287 */       UPNPMBeanDevicesDiscoveryHandler.getInstance(this.bindAddress).addUPNPMBeanDevice(this);
/* 288 */       this.started = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private static InetSocketAddress getUPNPMBeansBoundAddr() {
/* 293 */     String boundAdr = System.getProperty("net.sbbi.upnp.UPNPMBeanDevice.boundAddr");
/* 294 */     InetSocketAddress defaultBoundAddr = null;
/*     */     try {
/* 296 */       InetAddress adr = null;
/* 297 */       if (boundAdr != null) {
/* 298 */         adr = InetAddress.getByName(boundAdr);
/*     */       } else {
/* 300 */         adr = InetAddress.getLocalHost();
/*     */       }
/* 302 */       defaultBoundAddr = new InetSocketAddress(adr, 8895);
/*     */     } catch (IOException ex) {
/* 304 */       defaultBoundAddr = new InetSocketAddress("localhost", 8895);
/*     */     }
/* 306 */     return defaultBoundAddr;
/*     */   }
/*     */   
/*     */   public void stop() throws IOException {
/* 310 */     if (this.started) {
/* 311 */       UPNPMBeanDevicesRequestsHandler.getInstance(this.bindAddress).removeUPNPMBeanDevice(this);
/* 312 */       UPNPMBeanDevicesDiscoveryHandler.getInstance(this.bindAddress).removeUPNPMBeanDevice(this);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getRootDeviceInfo(InetSocketAddress adr, String uuid)
/*     */   {
/* 318 */     StringBuffer rtrVal = new StringBuffer();
/* 319 */     rtrVal.append("<?xml version=\"1.0\" ?>\r\n");
/* 320 */     rtrVal.append("<root xmlns=\"urn:schemas-upnp-org:device-1-0\">\r\n");
/* 321 */     rtrVal.append("<specVersion><major>1</major><minor>0</minor></specVersion>\r\n");
/* 322 */     rtrVal.append("<URLBase>http://").append(adr.getAddress().getHostAddress()).append(":").append(adr.getPort()).append("</URLBase>\r\n");
/* 323 */     getDeviceInfo(this, rtrVal);
/* 324 */     rtrVal.append("</root>");
/* 325 */     return rtrVal.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   private void getDeviceInfo(UPNPMBeanDevice device, StringBuffer buffer)
/*     */   {
/* 331 */     buffer.append("<device>\r\n");
/* 332 */     buffer.append("<deviceType>").append(device.deviceType).append("</deviceType>\r\n");
/* 333 */     buffer.append("<friendlyName>").append(device.friendlyName).append("</friendlyName>\r\n");
/* 334 */     buffer.append("<manufacturer>").append(device.manufacturer).append("</manufacturer>\r\n");
/* 335 */     if (device.manufacturerURL != null) {
/* 336 */       buffer.append("<manufacturerURL>").append(device.manufacturerURL).append("</manufacturerURL>\r\n");
/*     */     }
/* 338 */     if (device.modelDescription != null) {
/* 339 */       buffer.append("<modelDescription>").append(device.modelDescription).append("</modelDescription>\r\n");
/*     */     }
/* 341 */     buffer.append("<modelName>").append(device.modelName).append("</modelName>\r\n");
/* 342 */     if (device.modelNumber != null) {
/* 343 */       buffer.append("<modelNumber>").append(device.modelNumber).append("</modelNumber>\r\n");
/*     */     }
/* 345 */     if (device.modelURL != null) {
/* 346 */       buffer.append("<modelURL>").append(device.modelURL).append("</modelURL>\r\n");
/*     */     }
/* 348 */     if (device.serialNumber != null) {
/* 349 */       buffer.append("<serialNumber>").append(device.serialNumber).append("</serialNumber>\r\n");
/*     */     }
/* 351 */     buffer.append("<UDN>uuid:").append(device.uuid).append("</UDN>\r\n");
/* 352 */     if (device.UPC != null) {
/* 353 */       buffer.append("<UPC>").append(device.serialNumber).append("</UPC>\r\n");
/*     */     }
/* 355 */     buffer.append("<serviceList>\r\n");
/*     */     
/* 357 */     for (Iterator i = device.services.iterator(); i.hasNext();) {
/* 358 */       UPNPMBeanService srv = (UPNPMBeanService)i.next();
/* 359 */       buffer.append(srv.getServiceInfo());
/*     */     }
/* 361 */     buffer.append("</serviceList>\r\n");
/* 362 */     if (device.childrens.size() > 0) {
/* 363 */       buffer.append("<deviceList>\r\n");
/* 364 */       for (Iterator i = device.childrens.iterator(); i.hasNext();) {
/* 365 */         UPNPMBeanDevice dv = (UPNPMBeanDevice)i.next();
/* 366 */         getDeviceInfo(dv, buffer);
/*     */       }
/* 368 */       buffer.append("</deviceList>\r\n");
/*     */     }
/* 370 */     buffer.append("</device>\r\n");
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/UPNPMBeanDevice.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */