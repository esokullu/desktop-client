/*     */ package net.sbbi.upnp.jmx;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import net.sbbi.upnp.messages.UPNPResponseException;
/*     */ import net.sbbi.upnp.services.ServiceStateVariable;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpPostRequest
/*     */   implements HttpRequestHandler
/*     */ {
/*  79 */   private static final HttpPostRequest instance = new HttpPostRequest();
/*     */   
/*     */   private static final String STATE_VAR_ACTION_URN = "urn:schemas-upnp-org:control-1-0#QueryStateVariable";
/*     */   
/*  83 */   private DocumentBuilderFactory builder = DocumentBuilderFactory.newInstance();
/*     */   
/*     */   private HttpPostRequest() {
/*  86 */     this.builder.setNamespaceAware(true);
/*     */   }
/*     */   
/*     */   public static HttpRequestHandler getInstance() {
/*  90 */     return instance;
/*     */   }
/*     */   
/*     */   public String service(Set devices, HttpRequest request) {
/*  94 */     String rtr = null;
/*  95 */     String filePath = request.getHttpCommandArg();
/*     */     
/*  97 */     boolean validPostUrl = ((filePath.startsWith("/")) && (filePath.endsWith("/control"))) || ((filePath.startsWith("/")) && (filePath.endsWith("/events")));
/*     */     
/*     */ 
/* 100 */     if (validPostUrl) {
/* 101 */       String uuid = null;
/* 102 */       String serviceUuid = null;
/* 103 */       int lastSlash = filePath.lastIndexOf('/');
/* 104 */       if (lastSlash != -1) {
/* 105 */         serviceUuid = filePath.substring(1, lastSlash);
/*     */         
/* 107 */         int slashIndex = serviceUuid.indexOf("/");
/* 108 */         if (slashIndex != -1) {
/* 109 */           uuid = serviceUuid.substring(0, slashIndex);
/*     */         }
/*     */       }
/*     */       
/* 113 */       if (uuid != null)
/*     */       {
/* 115 */         UPNPMBeanDevice device = null;
/* 116 */         UPNPMBeanService service = null;
/* 117 */         Iterator i; synchronized (devices) {
/* 118 */           for (i = devices.iterator(); i.hasNext();) {
/* 119 */             UPNPMBeanDevice dv = (UPNPMBeanDevice)i.next();
/* 120 */             if (dv.getUuid().equals(uuid))
/*     */             {
/* 122 */               service = dv.getUPNPMBeanService(serviceUuid);
/* 123 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 128 */         if (service != null) {
/*     */           try {
/* 130 */             if (filePath.endsWith("/control")) {
/* 131 */               String soapAction = request.getHTTPHeaderField("SOAPACTION");
/* 132 */               String soapRequest = request.getBody();
/* 133 */               if ((soapRequest == null) || (soapRequest.trim().length() == 0)) {
/* 134 */                 throw new IllegalArgumentException("No SOAP request provided");
/*     */               }
/* 136 */               if (soapAction.indexOf("urn:schemas-upnp-org:control-1-0#QueryStateVariable") != -1) {
/* 137 */                 String requestedVar = getQueryStateVariableVarName(soapRequest);
/* 138 */                 if ((requestedVar == null) || (requestedVar.trim().length() == 0)) {
/* 139 */                   throw new IllegalArgumentException("No varname content provided");
/*     */                 }
/* 141 */                 Object result = null;
/*     */                 
/*     */ 
/* 144 */                 if (service.getOperationsStateVariables().get(requestedVar) == null) {
/*     */                   try {
/* 146 */                     result = service.getAttribute(requestedVar);
/*     */                   } catch (AttributeNotFoundException ex) {
/* 148 */                     throw new UPNPResponseException(404, "State varibale " + requestedVar + " unknown");
/*     */                   }
/*     */                 }
/* 151 */                 rtr = getQueryStateVariableResult(result);
/*     */               }
/*     */               else {
/* 154 */                 if ((soapAction == null) || (soapAction.trim().length() == 0)) {
/* 155 */                   throw new IllegalArgumentException("Missing SOAPACTION HTTP header");
/*     */                 }
/* 157 */                 if ((!soapAction.startsWith("\"")) || (!soapAction.endsWith("\"")) || (soapAction.indexOf("#") == -1))
/*     */                 {
/*     */ 
/* 160 */                   throw new IllegalArgumentException("Invalid SOAPACTION HTTP header (" + soapAction + ") check your specs");
/*     */                 }
/*     */                 
/* 163 */                 String actionName = getActionName(soapAction, service.getServiceType());
/* 164 */                 if (actionName == null) {
/* 165 */                   throw new UPNPResponseException(401, "Provided SOAPACTION (" + soapAction + ") wrongly " + "formatted or does not match target device type (" + device.getDeviceType() + ")");
/*     */                 }
/*     */                 
/* 168 */                 String[] providedParams = getActionParams(soapRequest, actionName, service.getServiceType());
/* 169 */                 Object result = null;
/* 170 */                 String[] signature = null;
/* 171 */                 Object[] parameters = null;
/* 172 */                 Object[] signatureAndVals = getSignatureAndParamsVals(providedParams, actionName, service);
/* 173 */                 if (signatureAndVals != null) {
/* 174 */                   signature = (String[])signatureAndVals[0];
/* 175 */                   parameters = (Object[])signatureAndVals[1];
/*     */                 }
/*     */                 try {
/* 178 */                   result = service.invoke(actionName, parameters, signature);
/*     */                 } catch (ReflectionException ex) {
/* 180 */                   throw ex.getTargetException();
/*     */                 }
/* 182 */                 rtr = getActionResult(result, service.getServiceType(), actionName);
/*     */               }
/* 184 */             } else if (filePath.endsWith("/events"))
/*     */             {
/* 186 */               throw new Exception("Not yet implemented :o(, try again with the next software version");
/*     */             }
/*     */           } catch (Exception ex) {
/* 189 */             rtr = createSOAPError(ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 194 */     return rtr;
/*     */   }
/*     */   
/*     */   private MBeanOperationInfo getOperationInfo(MBeanInfo beanInfo, String methodName)
/*     */   {
/* 199 */     MBeanOperationInfo[] ops = beanInfo.getOperations();
/* 200 */     for (int i = 0; i < ops.length; i++) {
/* 201 */       if (ops[i].getName().equals(methodName)) {
/* 202 */         return ops[i];
/*     */       }
/*     */     }
/* 205 */     return null;
/*     */   }
/*     */   
/*     */   private Object[] getParameterInfo(MBeanOperationInfo opInfo, String paramName) {
/* 209 */     MBeanParameterInfo[] args = opInfo.getSignature();
/* 210 */     for (int i = 0; i < args.length; i++) {
/* 211 */       if (args[i].getName().equals(paramName)) {
/* 212 */         return new Object[] { args[i], new Integer(i) };
/*     */       }
/*     */     }
/* 215 */     return null;
/*     */   }
/*     */   
/*     */   private Object[] getSignatureAndParamsVals(String[] providedParams, String methodName, UPNPMBeanService service) throws UPNPResponseException
/*     */   {
/* 220 */     MBeanOperationInfo opInfo = getOperationInfo(service.getMBeanInfo(), methodName);
/* 221 */     if (opInfo == null)
/*     */     {
/* 223 */       throw new RuntimeException("Unexpected null MBeanOperationInfo for operation " + methodName);
/*     */     }
/*     */     
/* 226 */     int providedParamsCount = 0;
/* 227 */     if (providedParams != null) {
/* 228 */       providedParamsCount = providedParams.length / 2;
/*     */     }
/* 230 */     if (opInfo.getSignature().length != providedParamsCount) {
/* 231 */       throw new UPNPResponseException(402, "Invalid provided parameter(s) count (" + providedParamsCount + ") for action " + methodName + ", " + opInfo.getSignature().length + " parameter(s) are needed");
/*     */     }
/*     */     
/*     */ 
/* 235 */     if (providedParamsCount == 0) {
/* 236 */       return null;
/*     */     }
/*     */     
/* 239 */     Object[] rtrVal = new Object[2];
/* 240 */     rtrVal[0] = new String[providedParamsCount];
/* 241 */     rtrVal[1] = new Object[providedParamsCount];
/*     */     
/* 243 */     for (int i = 0; i < providedParams.length; i += 2) {
/* 244 */       String paramName = providedParams[i];
/* 245 */       String paramValue = providedParams[(i + 1)];
/* 246 */       String paramType = (String)service.getOperationsStateVariables().get(paramName);
/* 247 */       if (paramType == null) {
/* 248 */         throw new UPNPResponseException(402, "Unknown action " + methodName + " parameter " + paramName);
/*     */       }
/* 250 */       Object[] beanParamInfos = getParameterInfo(opInfo, paramName);
/* 251 */       if (beanParamInfos == null)
/*     */       {
/* 253 */         throw new UPNPResponseException(402, "Unknown action " + methodName + " parameter " + paramName);
/*     */       }
/* 255 */       MBeanParameterInfo beanParamInfo = (MBeanParameterInfo)beanParamInfos[0];
/* 256 */       int paramSignaturePos = ((Integer)beanParamInfos[1]).intValue();
/* 257 */       Object value = null;
/*     */       try
/*     */       {
/* 260 */         value = ServiceStateVariable.UPNPToJavaObject(paramType, paramValue);
/*     */       } catch (Throwable t) {
/* 262 */         throw new UPNPResponseException(501, "Error occured during parameter " + paramName + "(" + paramType + ") value " + paramValue + " parsing:" + t.getMessage());
/*     */       }
/* 264 */       String[] sign = (String[])rtrVal[0];
/* 265 */       sign[paramSignaturePos] = beanParamInfo.getType();
/* 266 */       Object[] vals = (Object[])rtrVal[1];
/* 267 */       vals[paramSignaturePos] = value;
/*     */     }
/* 269 */     return rtrVal;
/*     */   }
/*     */   
/*     */   private String getActionName(String SOAPAction, String serviceType) {
/* 273 */     int index = SOAPAction.indexOf(serviceType);
/* 274 */     if (index != -1) {
/*     */       try {
/* 276 */         return SOAPAction.substring(serviceType.length() + 2, SOAPAction.length() - 1);
/*     */       }
/*     */       catch (Throwable t) {}
/*     */     }
/*     */     
/* 281 */     return null;
/*     */   }
/*     */   
/*     */   private String[] getActionParams(String xmlRequest, String actionName, String serviceType) throws Exception {
/* 285 */     String[] rtrVal = null;
/* 286 */     ByteArrayInputStream in = new ByteArrayInputStream(xmlRequest.getBytes());
/* 287 */     InputSource src = new InputSource(in);
/* 288 */     Document doc = null;
/* 289 */     synchronized (this.builder) {
/* 290 */       doc = this.builder.newDocumentBuilder().parse(src);
/*     */     }
/* 292 */     Element root = doc.getDocumentElement();
/* 293 */     Element body = (Element)root.getElementsByTagNameNS("http://schemas.xmlsoap.org/soap/envelope/", "Body").item(0);
/* 294 */     if (body == null) {
/* 295 */       throw new IllegalArgumentException("Missing body tag");
/*     */     }
/* 297 */     Element action = (Element)body.getElementsByTagNameNS(serviceType, actionName).item(0);
/* 298 */     if (action == null) {
/* 299 */       throw new IllegalArgumentException("Missing action tag " + actionName);
/*     */     }
/* 301 */     NodeList params = action.getChildNodes();
/* 302 */     int length = 0;
/* 303 */     for (int i = 0; i < params.getLength(); i++) {
/* 304 */       if ((params.item(i) instanceof Element)) {
/* 305 */         length++;
/*     */       }
/*     */     }
/* 308 */     if (length > 0) {
/* 309 */       rtrVal = new String[length * 2];
/* 310 */       int j = 0;
/* 311 */       for (int i = 0; i < params.getLength(); i++) {
/* 312 */         if ((params.item(i) instanceof Element)) {
/* 313 */           Element arg = (Element)params.item(i);
/* 314 */           rtrVal[j] = arg.getNodeName();
/* 315 */           rtrVal[(j + 1)] = arg.getFirstChild().getNodeValue();
/* 316 */           j += 2;
/*     */         }
/*     */       }
/*     */     }
/* 320 */     return rtrVal;
/*     */   }
/*     */   
/*     */   private String getQueryStateVariableVarName(String xmlRequest) throws Exception
/*     */   {
/* 325 */     ByteArrayInputStream in = new ByteArrayInputStream(xmlRequest.getBytes());
/* 326 */     InputSource src = new InputSource(in);
/* 327 */     Document doc = null;
/* 328 */     synchronized (this.builder) {
/* 329 */       doc = this.builder.newDocumentBuilder().parse(src);
/*     */     }
/* 331 */     Element root = doc.getDocumentElement();
/*     */     
/* 333 */     Element body = (Element)root.getElementsByTagNameNS("http://schemas.xmlsoap.org/soap/envelope/", "Body").item(0);
/* 334 */     if (body == null) {
/* 335 */       throw new IllegalArgumentException("Missing body tag");
/*     */     }
/* 337 */     Element query = (Element)body.getElementsByTagNameNS("urn:schemas-upnp-org:control-1-0", "QueryStateVariable").item(0);
/* 338 */     if (query == null) {
/* 339 */       throw new IllegalArgumentException("Missing query tag");
/*     */     }
/* 341 */     Element varName = (Element)query.getElementsByTagNameNS("urn:schemas-upnp-org:control-1-0", "varName").item(0);
/* 342 */     if (varName == null) {
/* 343 */       throw new IllegalArgumentException("Missing varName tag");
/*     */     }
/* 345 */     return varName.getFirstChild().getNodeValue();
/*     */   }
/*     */   
/*     */   private String createSOAPError(Throwable ex) {
/* 349 */     StringBuffer rtr = new StringBuffer();
/*     */     
/* 351 */     String errorDescription = null;
/*     */     int errorCode;
/* 353 */     if ((ex instanceof UPNPResponseException)) {
/* 354 */       UPNPResponseException upnpEx = (UPNPResponseException)ex;
/* 355 */       int errorCode = upnpEx.getDetailErrorCode();
/* 356 */       errorDescription = upnpEx.getDetailErrorDescription();
/* 357 */       if (upnpEx.getCause() != null) {
/* 358 */         ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 359 */         PrintWriter writer = new PrintWriter(out);
/* 360 */         upnpEx.getCause().printStackTrace(writer);
/* 361 */         writer.flush();
/* 362 */         writer.close();
/* 363 */         errorDescription = errorDescription + "\nAttached stack trace:\n" + new String(out.toByteArray());
/*     */       }
/*     */     } else {
/* 366 */       errorCode = 501;
/* 367 */       ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 368 */       PrintWriter writer = new PrintWriter(out);
/* 369 */       ex.printStackTrace(writer);
/* 370 */       writer.flush();
/* 371 */       writer.close();
/* 372 */       errorDescription = new String(out.toByteArray());
/*     */     }
/*     */     
/* 375 */     StringBuffer xml = new StringBuffer();
/* 376 */     xml.append("<?xml version=\"1.0\"?>\r\n").append("<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" ").append("s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">\r\n").append("<s:Body>\r\n<s:Fault>\r\n").append("<faultcode>s:Client</faultcode>\r\n").append("<faultstring>UPnPError</faultstring>\r\n").append("<detail>\r\n").append("<UPnPError xmlns=\"urn:schemas-upnp-org:control-1-0\">\r\n").append("<errorCode>").append(errorCode).append("</errorCode>\r\n").append("<errorDescription>").append(errorDescription).append("</errorDescription>\r\n").append("</UPnPError>\r\n").append("</detail>\r\n").append("</s:Fault></s:Body>\r\n").append("</s:Envelope>");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 391 */     rtr.append("HTTP/1.1 500 Server error\r\n").append("CONTENT-LENGTH: ").append(xml.length()).append("\r\n").append("CONTENT-TYPE: text/xml\r\n\r\n").append(xml);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 396 */     return rtr.toString();
/*     */   }
/*     */   
/*     */   private String getActionResult(Object result, String serviceType, String actionName) {
/* 400 */     StringBuffer xml = new StringBuffer();
/* 401 */     xml.append("<?xml version=\"1.0\"?>\r\n").append("<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" ").append("s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">\r\n").append("<s:Body>\r\n").append("<u:").append(actionName).append("Response xmlns:u=\"").append(serviceType).append("\">\r\n").append("<").append(actionName).append("_out>").append(getResultAsString(result)).append("</").append(actionName).append("_out>\r\n").append("</u:").append(actionName).append("Response>\r\n").append("</s:Body>\r\n").append("</s:Envelope>");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 412 */     StringBuffer rtr = new StringBuffer();
/* 413 */     rtr.append("HTTP/1.1 200 OK\r\n").append("CONTENT-LENGTH: ").append(xml.length()).append("\r\n").append("CONTENT-TYPE: text/xml; charset=\"utf-8\"\r\n").append("EXT:\r\n").append("SERVER: ").append(UPNPMBeanDevice.IMPL_NAME).append("\r\n\r\n").append(xml);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 420 */     return rtr.toString();
/*     */   }
/*     */   
/*     */   private String getQueryStateVariableResult(Object result) {
/* 424 */     StringBuffer xml = new StringBuffer();
/* 425 */     xml.append("<?xml version=\"1.0\"?>\r\n").append("<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" ").append("s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">\r\n").append("<s:Body>\r\n").append("<u:QueryStateVariableResponse xmlns:u=\"urn:schemas-upnp-org:control-1-0\">\r\n").append("<return>").append(getResultAsString(result)).append("</return>\r\n").append("</u:QueryStateVariableResponse>\r\n").append("</s:Body>\r\n").append("</s:Envelope>");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 436 */     StringBuffer rtr = new StringBuffer();
/* 437 */     rtr.append("HTTP/1.1 200 OK\r\n").append("CONTENT-LENGTH: ").append(xml.length()).append("\r\n").append("CONTENT-TYPE: text/xml; charset=\"utf-8\"\r\n").append("EXT:\r\n").append("SERVER: ").append(UPNPMBeanDevice.IMPL_NAME).append("\r\n\r\n").append(xml);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 444 */     return rtr.toString();
/*     */   }
/*     */   
/*     */   private String getResultAsString(Object result)
/*     */   {
/* 449 */     if (result == null) return "";
/* 450 */     String rtrVal = null;
/*     */     
/* 452 */     if ((result instanceof Object[])) {
/* 453 */       StringBuffer tmp = new StringBuffer();
/* 454 */       Object[] array = (Object[])result;
/* 455 */       for (int i = 0; i < array.length; i++) {
/* 456 */         Object val = array[i];
/* 457 */         if (val != null) {
/* 458 */           tmp.append(val.toString());
/*     */         } else {
/* 460 */           tmp.append("null");
/*     */         }
/* 462 */         if (i < array.length) tmp.append("\n");
/*     */       }
/* 464 */       rtrVal = tmp.toString();
/* 465 */     } else if ((result instanceof long[])) {
/* 466 */       StringBuffer tmp = new StringBuffer();
/* 467 */       long[] array = (long[])result;
/* 468 */       for (int i = 0; i < array.length; i++) {
/* 469 */         tmp.append(array[i]);
/* 470 */         if (i < array.length) tmp.append("\n");
/*     */       }
/* 472 */       rtrVal = tmp.toString();
/* 473 */     } else if ((result instanceof double[])) {
/* 474 */       StringBuffer tmp = new StringBuffer();
/* 475 */       double[] array = (double[])result;
/* 476 */       for (int i = 0; i < array.length; i++) {
/* 477 */         tmp.append(array[i]);
/* 478 */         if (i < array.length) tmp.append("\n");
/*     */       }
/* 480 */       rtrVal = tmp.toString();
/* 481 */     } else if ((result instanceof float[])) {
/* 482 */       StringBuffer tmp = new StringBuffer();
/* 483 */       float[] array = (float[])result;
/* 484 */       for (int i = 0; i < array.length; i++) {
/* 485 */         tmp.append(array[i]);
/* 486 */         if (i < array.length) tmp.append("\n");
/*     */       }
/* 488 */       rtrVal = tmp.toString();
/* 489 */     } else if ((result instanceof short[])) {
/* 490 */       StringBuffer tmp = new StringBuffer();
/* 491 */       short[] array = (short[])result;
/* 492 */       for (int i = 0; i < array.length; i++) {
/* 493 */         tmp.append(array[i]);
/* 494 */         if (i < array.length) tmp.append("\n");
/*     */       }
/* 496 */       rtrVal = tmp.toString();
/* 497 */     } else if ((result instanceof int[])) {
/* 498 */       StringBuffer tmp = new StringBuffer();
/* 499 */       int[] array = (int[])result;
/* 500 */       for (int i = 0; i < array.length; i++) {
/* 501 */         tmp.append(array[i]);
/* 502 */         if (i < array.length) tmp.append("\n");
/*     */       }
/* 504 */       rtrVal = tmp.toString();
/* 505 */     } else if ((result instanceof byte[])) {
/* 506 */       StringBuffer tmp = new StringBuffer();
/* 507 */       byte[] array = (byte[])result;
/* 508 */       for (int i = 0; i < array.length; i++) {
/* 509 */         tmp.append(array[i]);
/* 510 */         if (i < array.length) tmp.append("\n");
/*     */       }
/* 512 */       rtrVal = tmp.toString();
/* 513 */     } else if ((result instanceof char[])) {
/* 514 */       rtrVal = new String((char[])result);
/*     */     } else {
/* 516 */       rtrVal = result.toString();
/*     */     }
/* 518 */     if ((rtrVal.indexOf("<") != -1) || (rtrVal.indexOf(">") != -1)) {
/* 519 */       rtrVal = "<![CDATA[" + rtrVal + "]]>";
/*     */     }
/* 521 */     return rtrVal;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/HttpPostRequest.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */