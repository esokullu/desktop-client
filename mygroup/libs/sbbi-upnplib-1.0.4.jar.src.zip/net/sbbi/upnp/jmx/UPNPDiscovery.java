/*     */ package net.sbbi.upnp.jmx;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationBroadcaster;
/*     */ import javax.management.NotificationBroadcasterSupport;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectName;
/*     */ import net.sbbi.upnp.Discovery;
/*     */ import net.sbbi.upnp.DiscoveryAdvertisement;
/*     */ import net.sbbi.upnp.DiscoveryEventHandler;
/*     */ import net.sbbi.upnp.devices.UPNPDevice;
/*     */ import net.sbbi.upnp.devices.UPNPRootDevice;
/*     */ import net.sbbi.upnp.services.UPNPService;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UPNPDiscovery
/*     */   implements DiscoveryEventHandler, UPNPDiscoveryMBean, NotificationBroadcaster
/*     */ {
/*  92 */   private static final Log log = LogFactory.getLog(UPNPDiscovery.class);
/*     */   
/*     */   private MBeanServer server;
/*     */   private NotificationBroadcasterSupport notifier;
/*     */   private MBeanNotificationInfo[] notifInfo;
/*     */   private Map registeredBeansPerUDN;
/*     */   private Set searchTargets;
/*     */   private int discoveryTimeout;
/*     */   private boolean notifySSDPEvents;
/*     */   private boolean registerChildDevices;
/* 102 */   private long ssdpAliveSequenceNumber = 0L;
/* 103 */   private long ssdpByeByeSequenceNumber = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UPNPDiscovery(int discoveryTimeout, boolean notifySSDPEvents, boolean registerChildDevices)
/*     */   {
/* 115 */     this.registerChildDevices = registerChildDevices;
/* 116 */     this.notifySSDPEvents = notifySSDPEvents;
/* 117 */     this.discoveryTimeout = discoveryTimeout;
/* 118 */     if (this.discoveryTimeout == 0) {
/* 119 */       this.discoveryTimeout = 1500;
/*     */     }
/* 121 */     this.notifier = new NotificationBroadcasterSupport();
/* 122 */     this.registeredBeansPerUDN = new HashMap();
/* 123 */     String[] types = { SSDP_ALIVE_NOTIFICATION, SSDP_BYEBYE_NOTIFICATION };
/* 124 */     this.notifInfo = new MBeanNotificationInfo[] { new MBeanNotificationInfo(types, Notification.class.getName(), "SSDP UPNP events notifications") };
/* 125 */     this.searchTargets = new HashSet();
/* 126 */     this.searchTargets.add("upnp:rootdevice");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UPNPDiscovery(String searchTargets, int discoveryTimeout, boolean notifySSDPEvents, boolean registerChildDevices)
/*     */   {
/* 140 */     this(discoveryTimeout, notifySSDPEvents, registerChildDevices);
/* 141 */     String[] targets = searchTargets.split(",");
/* 142 */     this.searchTargets.clear();
/* 143 */     for (int i = 0; i < targets.length; i++) {
/* 144 */       this.searchTargets.add(targets[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UPNPDiscovery(String[] searchTargets, int discoveryTimeout, boolean notifySSDPEvents, boolean registerChildDevices)
/*     */   {
/* 160 */     this(discoveryTimeout, notifySSDPEvents, registerChildDevices);
/* 161 */     this.searchTargets.clear();
/* 162 */     for (int i = 0; i < searchTargets.length; i++) {
/* 163 */       this.searchTargets.add(searchTargets[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName[] getRegisteredUPNPServiceMBeans(String deviceUDN)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 174 */     Set registeredBeans = (Set)this.registeredBeansPerUDN.get(deviceUDN);
/* 175 */     ObjectName[] rtrVal = null;
/* 176 */     int z; Iterator i; if ((registeredBeans != null) && (registeredBeans.size() > 0)) {
/* 177 */       Set copy = new HashSet(registeredBeans);
/* 178 */       rtrVal = new ObjectName[copy.size()];
/* 179 */       z = 0;
/* 180 */       for (i = copy.iterator(); i.hasNext();) {
/* 181 */         UPNPServiceMBean srv = (UPNPServiceMBean)i.next();
/* 182 */         rtrVal[(z++)] = srv.getObjectName();
/*     */       }
/*     */     }
/* 185 */     return rtrVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getRegisteredUPNPServiceMBeansUDNs()
/*     */   {
/* 194 */     if (this.registeredBeansPerUDN.size() == 0) return null;
/* 195 */     Map copy = new HashMap(this.registeredBeansPerUDN);
/* 196 */     String[] rtrVal = new String[copy.size()];
/* 197 */     int z = 0;
/* 198 */     for (Iterator i = copy.keySet().iterator(); i.hasNext();) {
/* 199 */       rtrVal[(z++)] = ((String)i.next());
/*     */     }
/* 201 */     return rtrVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set getSearchTargets()
/*     */   {
/* 209 */     return Collections.unmodifiableSet(this.searchTargets);
/*     */   }
/*     */   
/*     */   public void addNotificationListener(NotificationListener listener, NotificationFilter filter, Object callback) throws IllegalArgumentException {
/* 213 */     this.notifier.addNotificationListener(listener, filter, callback);
/*     */   }
/*     */   
/*     */   public MBeanNotificationInfo[] getNotificationInfo() {
/* 217 */     if (this.notifySSDPEvents) {
/* 218 */       return this.notifInfo;
/*     */     }
/* 220 */     return null;
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(NotificationListener listener) throws ListenerNotFoundException {
/* 224 */     this.notifier.removeNotificationListener(listener);
/*     */   }
/*     */   
/*     */   public void postDeregister() {}
/*     */   
/*     */   public void postRegister(Boolean arg0) {}
/*     */   
/*     */   public void preDeregister() throws Exception
/*     */   {
/*     */     Iterator i;
/* 234 */     if (this.notifySSDPEvents)
/* 235 */       for (i = this.searchTargets.iterator(); i.hasNext();) {
/* 236 */         String st = (String)i.next();
/* 237 */         DiscoveryAdvertisement.getInstance().unRegisterEvent(0, st, this);
/* 238 */         DiscoveryAdvertisement.getInstance().unRegisterEvent(1, st, this); }
/*     */     Iterator i;
/*     */     Iterator z;
/* 241 */     synchronized (this.registeredBeansPerUDN) {
/* 242 */       for (i = this.registeredBeansPerUDN.values().iterator(); i.hasNext();) {
/* 243 */         Set registeredMBeans = (Set)i.next();
/* 244 */         for (z = registeredMBeans.iterator(); z.hasNext();) {
/* 245 */           UPNPServiceMBean bean = (UPNPServiceMBean)z.next();
/* 246 */           this.server.unregisterMBean(bean.getObjectName());
/*     */         }
/*     */       }
/*     */     }
/* 250 */     this.registeredBeansPerUDN.clear();
/*     */   }
/*     */   
/*     */   public ObjectName preRegister(MBeanServer server, ObjectName objectname) throws Exception {
/* 254 */     this.server = server;
/* 255 */     discoverDevices(this.discoveryTimeout);
/* 256 */     Iterator i; if (this.notifySSDPEvents) {
/* 257 */       for (i = this.searchTargets.iterator(); i.hasNext();) {
/* 258 */         String st = (String)i.next();
/* 259 */         DiscoveryAdvertisement.getInstance().registerEvent(0, st, this);
/* 260 */         DiscoveryAdvertisement.getInstance().registerEvent(1, st, this);
/*     */       }
/*     */     }
/* 263 */     return objectname;
/*     */   }
/*     */   
/*     */   public void eventSSDPAlive(String usn, String udn, String nt, String maxAge, URL location) {
/* 267 */     if (this.registeredBeansPerUDN.get(udn) == null)
/*     */     {
/* 269 */       if ((this.searchTargets.contains("upnp:rootdevice")) || (this.searchTargets.contains(nt))) {
/*     */         try {
/* 271 */           UPNPRootDevice newDevice = new UPNPRootDevice(location, maxAge, null, usn, udn);
/* 272 */           log.info("Registering new device " + newDevice.getModelName() + " at " + location);
/* 273 */           register(newDevice, nt, null, null);
/* 274 */           UPNPDiscoveryNotification notif = new UPNPDiscoveryNotification(UPNPDiscoveryMBean.SSDP_ALIVE_NOTIFICATION, this, this.ssdpAliveSequenceNumber++, System.currentTimeMillis());
/* 275 */           notif.setLocation(location);
/* 276 */           notif.setNt(nt);
/* 277 */           notif.setUdn(udn);
/* 278 */           notif.setUsn(usn);
/* 279 */           notif.setUPNPServiceMBeans(getRegisteredUPNPServiceMBeans(udn));
/* 280 */           this.notifier.sendNotification(notif);
/*     */         } catch (Exception ex) {
/* 282 */           log.error("Error during new device " + location + " registration", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void eventSSDPByeBye(String usn, String udn, String nt) {
/* 289 */     synchronized (this.registeredBeansPerUDN) {
/* 290 */       Set registeredBeans = (Set)this.registeredBeansPerUDN.get(udn);
/* 291 */       if (registeredBeans != null) {
/* 292 */         UPNPDiscoveryNotification notif = new UPNPDiscoveryNotification(UPNPDiscoveryMBean.SSDP_BYEBYE_NOTIFICATION, this, this.ssdpByeByeSequenceNumber++, System.currentTimeMillis());
/* 293 */         notif.setNt(nt);
/* 294 */         notif.setUdn(udn);
/* 295 */         notif.setUsn(usn);
/*     */         try {
/* 297 */           notif.setUPNPServiceMBeans(getRegisteredUPNPServiceMBeans(udn));
/*     */         } catch (MalformedObjectNameException ex) {
/* 299 */           log.error("Error during UPNPServiceMBean unregistration notification", ex);
/*     */         }
/* 301 */         log.info("Device " + usn + " shutdown");
/* 302 */         for (Iterator i = registeredBeans.iterator(); i.hasNext();) {
/* 303 */           UPNPServiceMBean bean = (UPNPServiceMBean)i.next();
/*     */           try {
/* 305 */             this.server.unregisterMBean(bean.getObjectName());
/*     */           } catch (Exception ex) {
/* 307 */             log.error("Error during UPNPServiceMBean unregistration", ex);
/*     */           }
/*     */         }
/* 310 */         this.registeredBeansPerUDN.remove(udn);
/* 311 */         this.notifier.sendNotification(notif);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void discoverDevices(int timeout) throws Exception
/*     */   {
/* 318 */     UPNPRootDevice[] dev = Discovery.discover(timeout, "upnp:rootdevice");
/* 319 */     if (dev != null) { Iterator j;
/* 320 */       for (int i = 0; i < dev.length; i++) {
/* 321 */         for (j = this.searchTargets.iterator(); j.hasNext();) {
/* 322 */           String st = (String)j.next();
/* 323 */           register(dev[i], st, null, null);
/*     */         }
/*     */       }
/*     */     } else {
/* 327 */       log.info("No devices found on the network");
/*     */     }
/*     */   }
/*     */   
/*     */   private void register(UPNPDevice device, String searchTarget, Set registeredMBeansContainer, String deviceUDN) throws Exception
/*     */   {
/* 333 */     List childrens = device.getTopLevelChildDevices();
/*     */     
/* 335 */     if ((searchTarget.equals("upnp:rootdevice")) || (device.getDeviceType().equals(searchTarget)))
/*     */     {
/* 337 */       synchronized (this.registeredBeansPerUDN) {
/* 338 */         if (deviceUDN == null) {
/* 339 */           deviceUDN = device.getUDN();
/*     */         }
/* 341 */         log.info("Registering UPNP device " + device.getDeviceType() + " " + device.getUDN() + " services");
/* 342 */         if (registeredMBeansContainer == null) {
/* 343 */           registeredMBeansContainer = new HashSet();
/* 344 */           this.registeredBeansPerUDN.put(deviceUDN, registeredMBeansContainer);
/*     */         }
/* 346 */         List services = device.getServices();
/* 347 */         if (services != null) {
/* 348 */           registerServices(device, this.server, services, registeredMBeansContainer);
/*     */         }
/* 350 */         if (childrens != null) { Iterator itr;
/* 351 */           if (this.registerChildDevices) {
/* 352 */             for (itr = childrens.iterator(); itr.hasNext();) {
/* 353 */               UPNPDevice childDevice = (UPNPDevice)itr.next();
/*     */               
/* 355 */               register(childDevice, "upnp:rootdevice", registeredMBeansContainer, deviceUDN);
/*     */             }
/*     */           }
/* 358 */           childrens = null;
/*     */         }
/*     */       } }
/*     */     Iterator itr;
/* 362 */     if (childrens != null) {
/* 363 */       for (itr = childrens.iterator(); itr.hasNext();) {
/* 364 */         UPNPDevice childDevice = (UPNPDevice)itr.next();
/* 365 */         register(childDevice, searchTarget, null, deviceUDN);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void registerServices(UPNPDevice device, MBeanServer server, List services, Set beansContainer) throws Exception {
/* 371 */     for (Iterator i = services.iterator(); i.hasNext();) {
/* 372 */       UPNPService srv = (UPNPService)i.next();
/* 373 */       UPNPServiceMBean mBean = new UPNPServiceMBean(device, srv, null, null);
/* 374 */       log.info("Registering service " + srv.getServiceId());
/* 375 */       server.registerMBean(mBean, mBean.getObjectName());
/* 376 */       beansContainer.add(mBean);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/UPNPDiscovery.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */