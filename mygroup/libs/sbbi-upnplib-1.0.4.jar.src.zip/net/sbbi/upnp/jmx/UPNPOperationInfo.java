/*    */ package net.sbbi.upnp.jmx;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import javax.management.MBeanOperationInfo;
/*    */ import javax.management.MBeanParameterInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UPNPOperationInfo
/*    */   extends MBeanOperationInfo
/*    */ {
/*    */   public UPNPOperationInfo(String name, Method method)
/*    */   {
/* 64 */     super(name, method);
/*    */   }
/*    */   
/*    */   public UPNPOperationInfo(String name, String param2, MBeanParameterInfo[] info, String arg3, int arg4) {
/* 68 */     super(name, param2, info, arg3, arg4);
/*    */   }
/*    */   
/*    */   public void addOutputArgumentType(UPNPAttributeInfo attribute) {}
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/UPNPOperationInfo.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */