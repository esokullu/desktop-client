/*     */ package net.sbbi.upnp.jmx;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.Set;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.DynamicMBean;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ReflectionException;
/*     */ import net.sbbi.upnp.devices.UPNPDevice;
/*     */ import net.sbbi.upnp.devices.UPNPRootDevice;
/*     */ import net.sbbi.upnp.messages.ActionMessage;
/*     */ import net.sbbi.upnp.messages.ActionResponse;
/*     */ import net.sbbi.upnp.messages.StateVariableMessage;
/*     */ import net.sbbi.upnp.messages.StateVariableResponse;
/*     */ import net.sbbi.upnp.messages.UPNPMessageFactory;
/*     */ import net.sbbi.upnp.messages.UPNPResponseException;
/*     */ import net.sbbi.upnp.services.ServiceAction;
/*     */ import net.sbbi.upnp.services.ServiceActionArgument;
/*     */ import net.sbbi.upnp.services.ServiceStateVariable;
/*     */ import net.sbbi.upnp.services.UPNPService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UPNPServiceMBean
/*     */   implements DynamicMBean
/*     */ {
/*     */   private UPNPService service;
/*     */   private UPNPDevice device;
/*     */   private UPNPMessageFactory fact;
/*     */   private ResourceBundle bundle;
/*     */   
/*     */   public UPNPServiceMBean(UPNPDevice device, UPNPService service)
/*     */   {
/*  96 */     this(device, service, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UPNPServiceMBean(UPNPDevice device, UPNPService service, Locale locale, String bundlePackage)
/*     */   {
/* 109 */     this.service = service;
/* 110 */     this.device = device;
/* 111 */     if (locale != null) {
/* 112 */       if ((bundlePackage != null) && (bundlePackage.length() == 0)) bundlePackage = null;
/* 113 */       String bundlename = service.getServiceId().replace(':', '_');
/* 114 */       if (bundlePackage != null) {
/* 115 */         if (!bundlePackage.endsWith("/")) {
/* 116 */           bundlePackage = bundlePackage + "/";
/*     */         }
/* 118 */         bundlename = bundlePackage + bundlename;
/*     */       }
/*     */       try {
/* 121 */         this.bundle = ResourceBundle.getBundle(bundlename, locale);
/*     */       }
/*     */       catch (Exception ex) {}
/*     */     }
/*     */     
/*     */ 
/* 127 */     this.fact = UPNPMessageFactory.getNewInstance(service);
/*     */   }
/*     */   
/*     */   public Object getAttribute(String attributeName) throws AttributeNotFoundException, MBeanException, ReflectionException
/*     */   {
/* 132 */     StateVariableMessage msg = this.fact.getStateVariableMessage(attributeName);
/* 133 */     if (msg != null) {
/*     */       try {
/* 135 */         StateVariableResponse resp = msg.service();
/* 136 */         return resp.getStateVariableValue();
/*     */       } catch (Exception ex) {
/* 138 */         if ((ex instanceof UPNPResponseException)) {
/* 139 */           UPNPResponseException respEx = (UPNPResponseException)ex;
/* 140 */           if (respEx.getDetailErrorCode() == 404)
/*     */           {
/* 142 */             throw new AttributeNotFoundException(respEx.getDetailErrorCode() + ":" + respEx.getDetailErrorDescription());
/*     */           }
/* 144 */           throw new MBeanException(ex, respEx.getDetailErrorCode() + ":" + respEx.getDetailErrorDescription());
/*     */         }
/* 146 */         throw new MBeanException(ex);
/*     */       }
/*     */     }
/*     */     
/* 150 */     throw new AttributeNotFoundException("Unable to find attribute " + attributeName);
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(String[] attributeNames) {
/* 154 */     AttributeList list = new AttributeList();
/* 155 */     for (int i = 0; i < attributeNames.length; i++) {
/*     */       try {
/* 157 */         Attribute attr = new Attribute(attributeNames[i], getAttribute(attributeNames[i]));
/* 158 */         list.add(attr);
/*     */       }
/*     */       catch (Exception ex) {}
/*     */     }
/*     */     
/* 163 */     return list;
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo() {
/* 167 */     Iterator itr = this.service.getAvailableStateVariableName();
/* 168 */     MBeanAttributeInfo[] attrs = new MBeanAttributeInfo[this.service.getAvailableStateVariableSize()];
/* 169 */     int i = 0;
/*     */     
/* 171 */     while (itr.hasNext()) {
/* 172 */       String stateVariable = (String)itr.next();
/*     */       
/* 174 */       ServiceStateVariable var = this.service.getUPNPServiceStateVariable(stateVariable);
/* 175 */       Class type = var.getDataTypeAsClass();
/*     */       
/* 177 */       String variableName = null;
/* 178 */       if (this.bundle != null) {
/*     */         try {
/* 180 */           variableName = this.bundle.getString("attribute." + stateVariable);
/*     */         }
/*     */         catch (Exception ex) {}
/*     */       }
/*     */       
/* 185 */       if (variableName == null) {
/* 186 */         variableName = stateVariable + " description";
/*     */       }
/*     */       
/* 189 */       MBeanAttributeInfo info = new MBeanAttributeInfo(stateVariable, type != null ? type.getName() : String.class.getName(), variableName, true, false, false);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 194 */       attrs[(i++)] = info;
/*     */     }
/*     */     
/* 197 */     itr = this.service.getAvailableActionsName();
/* 198 */     MBeanOperationInfo[] operations = new MBeanOperationInfo[this.service.getAvailableActionsSize()];
/* 199 */     i = 0;
/* 200 */     while (itr.hasNext()) {
/* 201 */       String serviceAction = (String)itr.next();
/* 202 */       ServiceAction action = this.service.getUPNPServiceAction(serviceAction);
/* 203 */       List args = action.getInputActionArguments();
/* 204 */       MBeanParameterInfo[] params = null;
/* 205 */       int z; Iterator itr3; if (args != null) {
/* 206 */         List tmp = new ArrayList();
/*     */         
/* 208 */         params = new MBeanParameterInfo[args.size()];
/* 209 */         z = 0;
/* 210 */         for (Iterator itr2 = args.iterator(); itr2.hasNext();) {
/* 211 */           ServiceActionArgument actArg = (ServiceActionArgument)itr2.next();
/*     */           
/* 213 */           Class type = actArg.getRelatedStateVariable().getDataTypeAsClass();
/* 214 */           String className = type != null ? type.getName() : String.class.getName();
/*     */           
/* 216 */           String actionArgName = null;
/* 217 */           if (this.bundle != null) {
/*     */             try {
/* 219 */               actionArgName = this.bundle.getString("operation." + action.getName() + "." + actArg.getName());
/*     */             }
/*     */             catch (Exception ex) {}
/*     */           }
/*     */           
/* 224 */           if (actionArgName == null) {
/* 225 */             actionArgName = actArg.getName() + " description";
/*     */           }
/*     */           
/* 228 */           MBeanParameterInfo param = new MBeanParameterInfo(actArg.getName(), className, actionArgName);
/* 229 */           tmp.add(param);
/* 230 */           params[(z++)] = param;
/*     */         }
/* 232 */         z = 0;
/* 233 */         params = new MBeanParameterInfo[tmp.size()];
/* 234 */         for (itr3 = tmp.iterator(); itr3.hasNext();) {
/* 235 */           params[(z++)] = ((MBeanParameterInfo)itr3.next());
/*     */         }
/*     */       } else {
/* 238 */         params = new MBeanParameterInfo[0];
/*     */       }
/*     */       
/* 241 */       String returnType = Map.class.getName();
/* 242 */       if (action.getOutputActionArguments() == null) {
/* 243 */         returnType = Void.TYPE.getName();
/*     */       }
/*     */       
/* 246 */       String actionName = null;
/* 247 */       if (this.bundle != null) {
/*     */         try {
/* 249 */           actionName = this.bundle.getString("operation." + action.getName());
/*     */         }
/*     */         catch (Exception ex) {}
/*     */       }
/*     */       
/* 254 */       if (actionName == null) {
/* 255 */         actionName = action.getName() + " description";
/*     */       }
/*     */       
/* 258 */       MBeanOperationInfo info = new MBeanOperationInfo(action.getName(), actionName, params, returnType, 1);
/*     */       
/*     */ 
/*     */ 
/* 262 */       operations[(i++)] = info;
/*     */     }
/*     */     
/* 265 */     String serviceDescr = null;
/* 266 */     if (this.bundle != null) {
/*     */       try {
/* 268 */         serviceDescr = this.bundle.getString("service.name");
/*     */       }
/*     */       catch (Exception ex) {}
/*     */     }
/*     */     
/* 273 */     if (serviceDescr == null) {
/* 274 */       serviceDescr = "Service Description";
/*     */     }
/*     */     
/* 277 */     return new MBeanInfo(getClass().getName(), serviceDescr, attrs, null, operations, null);
/*     */   }
/*     */   
/*     */   public Object invoke(String operationName, Object[] paramsValue, String[] signature) throws MBeanException, ReflectionException
/*     */   {
/* 282 */     ActionMessage msg = this.fact.getMessage(operationName);
/* 283 */     if (msg != null) {
/*     */       try {
/* 285 */         List msgParams = msg.getInputParameterNames();
/* 286 */         if ((paramsValue != null) && (msgParams != null)) {
/* 287 */           if (paramsValue.length != msgParams.size()) {
/* 288 */             return null;
/*     */           }
/* 290 */           int i = 0;
/* 291 */           for (Iterator itr = msgParams.iterator(); itr.hasNext(); i++) {
/* 292 */             String argName = (String)itr.next();
/*     */             try {
/* 294 */               msg.setInputParameter(argName, paramsValue[i]);
/*     */             } catch (IllegalArgumentException ex) {
/* 296 */               throw new MBeanException(ex);
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 301 */         ActionResponse resp = msg.service();
/* 302 */         List outParams = msg.getOutputParameterNames();
/* 303 */         if (outParams != null) {
/* 304 */           Map rtrVal = new HashMap();
/* 305 */           for (Iterator i = outParams.iterator(); i.hasNext();) {
/* 306 */             String argName = (String)i.next();
/* 307 */             String val = resp.getOutActionArgumentValue(argName);
/* 308 */             rtrVal.put(argName, val);
/*     */           }
/* 310 */           return rtrVal;
/*     */         }
/* 312 */         return null;
/*     */       } catch (Exception ex) {
/* 314 */         if ((ex instanceof UPNPResponseException)) {
/* 315 */           UPNPResponseException upnpEx = (UPNPResponseException)ex;
/* 316 */           throw new MBeanException(upnpEx, upnpEx.getMessage());
/*     */         }
/* 318 */         throw new MBeanException(ex);
/*     */       }
/*     */     }
/*     */     
/* 322 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setAttribute(Attribute attributeName)
/*     */     throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException
/*     */   {
/* 329 */     throw new AttributeNotFoundException("Unable to set attributes on an UPNP device");
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(AttributeList attributeNames) {
/* 333 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getObjectName()
/*     */     throws MalformedObjectNameException
/*     */   {
/* 342 */     return new ObjectName(getDeviceDomainName(this.device.getDeviceType()) + ":name=" + getDeviceServiceName(this.service.getServiceId()) + "_" + hashCode());
/*     */   }
/*     */   
/*     */ 
/*     */   private String getDeviceDomainName(String deviceType)
/*     */   {
/* 348 */     String[] tokens = deviceType.split(":");
/* 349 */     return tokens[(tokens.length - 2)].replace(':', '_');
/*     */   }
/*     */   
/*     */ 
/*     */   private String getDeviceServiceName(String serviceId)
/*     */   {
/* 355 */     String[] tokens = serviceId.split(":");
/* 356 */     return tokens[(tokens.length - 1)];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UPNPServiceMBean[] getUPNPRootDeviceAsMBeans(UPNPRootDevice device)
/*     */   {
/* 365 */     List services = device.getServices();
/* 366 */     Set mBeans = new HashSet();
/* 367 */     if (services != null) {
/* 368 */       registerServices(device, services, mBeans);
/*     */     }
/* 370 */     registerChildDevice(device.getChildDevices(), mBeans);
/*     */     
/* 372 */     UPNPServiceMBean[] rtrVal = new UPNPServiceMBean[mBeans.size()];
/* 373 */     int z = 0;
/* 374 */     for (Iterator i = mBeans.iterator(); i.hasNext();) {
/* 375 */       rtrVal[(z++)] = ((UPNPServiceMBean)i.next());
/*     */     }
/* 377 */     return rtrVal;
/*     */   }
/*     */   
/*     */   private static void registerServices(UPNPDevice device, List services, Set container) {
/* 381 */     for (Iterator i = services.iterator(); i.hasNext();) {
/* 382 */       UPNPService srv = (UPNPService)i.next();
/* 383 */       UPNPServiceMBean mBean = new UPNPServiceMBean(device, srv, null, null);
/* 384 */       container.add(mBean);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void registerChildDevice(List childDevices, Set container) { Iterator itr;
/* 389 */     if (childDevices != null) {
/* 390 */       for (itr = childDevices.iterator(); itr.hasNext();) {
/* 391 */         UPNPDevice device = (UPNPDevice)itr.next();
/* 392 */         List services = device.getServices();
/* 393 */         if (services != null) {
/* 394 */           registerServices(device, services, container);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/UPNPServiceMBean.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */