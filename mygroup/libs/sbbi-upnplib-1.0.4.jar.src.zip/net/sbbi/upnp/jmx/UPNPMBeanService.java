/*     */ package net.sbbi.upnp.jmx;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ReflectionException;
/*     */ import net.sbbi.upnp.services.ServiceStateVariable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UPNPMBeanService
/*     */ {
/*  84 */   private static final Log log = LogFactory.getLog(UPNPMBeanService.class);
/*     */   
/*     */   private String serviceType;
/*     */   private String serviceId;
/*     */   private String serviceUUID;
/*     */   private String deviceUUID;
/*     */   private String deviceSCDP;
/*     */   private Map operationsStateVariables;
/*     */   private MBeanServer targetServer;
/*     */   private MBeanInfo mbeanInfo;
/*     */   private ObjectName mbeanName;
/*     */   private Class targetBeanClass;
/*     */   
/*     */   protected UPNPMBeanService(String deviceUUID, String vendorDomain, String serviceId, String serviceType, int serviceVersion, MBeanInfo mbeanInfo, ObjectName mbeanName, MBeanServer targetServer)
/*     */     throws IOException
/*     */   {
/* 100 */     this.deviceUUID = deviceUUID;
/* 101 */     if (serviceId == null) {
/* 102 */       serviceId = generateServiceId(mbeanName);
/*     */     }
/* 104 */     this.serviceUUID = (deviceUUID + "/" + serviceId);
/* 105 */     this.serviceType = ("urn:" + vendorDomain + ":service:" + serviceType + ":" + serviceVersion);
/* 106 */     this.serviceId = ("urn:" + vendorDomain + ":serviceId:" + serviceId);
/* 107 */     this.deviceSCDP = getDeviceSSDP(mbeanInfo);
/*     */     try {
/* 109 */       this.targetBeanClass = Class.forName(mbeanInfo.getClassName());
/*     */     } catch (ClassNotFoundException ex) {
/* 111 */       IOException ex2 = new IOException("Unable to find target MBean class " + mbeanInfo.getClassName());
/* 112 */       ex2.initCause(ex);
/* 113 */       throw ex2;
/*     */     }
/* 115 */     this.mbeanName = mbeanName;
/* 116 */     this.mbeanInfo = mbeanInfo;
/* 117 */     this.targetServer = targetServer;
/*     */   }
/*     */   
/*     */   protected String getServiceUUID() {
/* 121 */     return this.serviceUUID;
/*     */   }
/*     */   
/*     */   protected String getDeviceUUID() {
/* 125 */     return this.deviceUUID;
/*     */   }
/*     */   
/*     */   private String generateServiceId(ObjectName mbeanName) {
/*     */     try {
/* 130 */       MessageDigest md5 = MessageDigest.getInstance("MD5");
/*     */       
/*     */ 
/* 133 */       md5.update(mbeanName.toString().getBytes());
/* 134 */       StringBuffer hexString = new StringBuffer();
/* 135 */       byte[] digest = md5.digest();
/* 136 */       for (int i = 0; i < digest.length; i++) {
/* 137 */         hexString.append(Integer.toHexString(0xFF & digest[i]));
/*     */       }
/* 139 */       return hexString.toString().toUpperCase();
/*     */     } catch (Exception ex) {
/* 141 */       RuntimeException runTimeEx = new RuntimeException("Unexpected error during MD5 hash creation, check your JRE");
/* 142 */       runTimeEx.initCause(ex);
/* 143 */       throw runTimeEx;
/*     */     }
/*     */   }
/*     */   
/*     */   protected String getServiceInfo() {
/* 148 */     StringBuffer rtrVal = new StringBuffer();
/* 149 */     rtrVal.append("<service>\r\n");
/* 150 */     rtrVal.append("<serviceType>").append(this.serviceType).append("</serviceType>\r\n");
/* 151 */     rtrVal.append("<serviceId>").append(this.serviceId).append("</serviceId>\r\n");
/* 152 */     rtrVal.append("<controlURL>").append("/").append(this.serviceUUID).append("/control").append("</controlURL>\r\n");
/* 153 */     rtrVal.append("<eventSubURL>").append("/").append(this.serviceUUID).append("/events").append("</eventSubURL>\r\n");
/* 154 */     rtrVal.append("<SCPDURL>").append("/").append(this.serviceUUID).append("/scpd.xml").append("</SCPDURL>\r\n");
/* 155 */     rtrVal.append("</service>\r\n");
/* 156 */     return rtrVal.toString();
/*     */   }
/*     */   
/*     */   protected Map getOperationsStateVariables() {
/* 160 */     return this.operationsStateVariables;
/*     */   }
/*     */   
/*     */   protected String getDeviceSCDP() {
/* 164 */     return this.deviceSCDP;
/*     */   }
/*     */   
/*     */   protected String getServiceType() {
/* 168 */     return this.serviceType;
/*     */   }
/*     */   
/*     */   protected Class getTargetBeanClass() {
/* 172 */     return this.targetBeanClass;
/*     */   }
/*     */   
/*     */   protected ObjectName getObjectName() {
/* 176 */     return this.mbeanName;
/*     */   }
/*     */   
/*     */   protected Object getAttribute(String attributeName) throws InstanceNotFoundException, AttributeNotFoundException, ReflectionException, MBeanException {
/* 180 */     return this.targetServer.getAttribute(this.mbeanName, attributeName);
/*     */   }
/*     */   
/*     */   protected Object invoke(String actionName, Object[] params, String[] signature) throws ReflectionException, InstanceNotFoundException, MBeanException {
/* 184 */     return this.targetServer.invoke(this.mbeanName, actionName, params, signature);
/*     */   }
/*     */   
/*     */   private String getDeviceSSDP(MBeanInfo info) throws IllegalArgumentException
/*     */   {
/* 189 */     MBeanOperationInfo[] ops = info.getOperations();
/* 190 */     MBeanAttributeInfo[] atts = info.getAttributes();
/*     */     
/* 192 */     if (((ops == null) || (ops.length == 0)) && ((atts == null) || (atts.length == 0)))
/*     */     {
/* 194 */       throw new IllegalArgumentException("MBean has no operation and no attribute and cannot be exposed as an UPNP device, provide at least one attribute");
/*     */     }
/* 196 */     Set deployedActionNames = new HashSet();
/* 197 */     this.operationsStateVariables = new HashMap();
/* 198 */     StringBuffer rtrVal = new StringBuffer();
/* 199 */     rtrVal.append("<?xml version=\"1.0\" ?>\r\n");
/* 200 */     rtrVal.append("<scpd xmlns=\"urn:schemas-upnp-org:service-1-0\">\r\n");
/* 201 */     rtrVal.append("<specVersion><major>1</major><minor>0</minor></specVersion>\r\n");
/*     */     
/* 203 */     if ((ops != null) && (ops.length > 0)) {
/* 204 */       rtrVal.append("<actionList>\r\n");
/* 205 */       for (int i = 0; i < ops.length; i++) {
/* 206 */         MBeanOperationInfo op = ops[i];
/* 207 */         StringBuffer action = new StringBuffer();
/* 208 */         if (deployedActionNames.contains(op.getName())) {
/* 209 */           log.debug("The " + op.getName() + " is allready deplyoed and cannot be reused, skipping operation deployment");
/*     */         }
/*     */         else {
/* 212 */           action.append("<action>\r\n");
/* 213 */           action.append("<name>");
/* 214 */           action.append(op.getName());
/* 215 */           action.append("</name>\r\n");
/* 216 */           action.append("<argumentList>\r\n");
/*     */           
/* 218 */           action.append("<argument>\r\n");
/* 219 */           action.append("<name>");
/*     */           
/* 221 */           String outVarName = op.getName() + "_out";
/* 222 */           String actionOutDataType = ServiceStateVariable.getUPNPDataTypeMapping(op.getReturnType());
/* 223 */           if (actionOutDataType == null) actionOutDataType = "string";
/* 224 */           action.append(outVarName);
/* 225 */           action.append("</name>\r\n");
/* 226 */           action.append("<direction>out</direction>\r\n");
/* 227 */           action.append("<relatedStateVariable>");
/* 228 */           action.append(outVarName);
/* 229 */           action.append("</relatedStateVariable>\r\n");
/* 230 */           action.append("</argument>\r\n");
/*     */           
/*     */ 
/* 233 */           boolean nonPrimitiveInputType = false;
/* 234 */           boolean duplicatedInputVarname = false;
/* 235 */           Map operationsInputStateVariables = new HashMap();
/* 236 */           if (op.getSignature() != null) {
/* 237 */             for (int z = 0; z < op.getSignature().length; z++) {
/* 238 */               MBeanParameterInfo param = op.getSignature()[z];
/*     */               
/* 240 */               String actionInDataType = ServiceStateVariable.getUPNPDataTypeMapping(param.getType());
/* 241 */               if (actionInDataType == null) {
/* 242 */                 nonPrimitiveInputType = true;
/* 243 */                 log.debug("The " + param.getType() + " type is not an UPNP compatible data type, use only primitives");
/* 244 */                 break;
/*     */               }
/* 246 */               String inVarName = param.getName();
/*     */               
/*     */ 
/* 249 */               String existing = (String)this.operationsStateVariables.get(inVarName);
/* 250 */               if ((existing != null) && (!existing.equals(actionInDataType))) {
/* 251 */                 String msg = "The operation " + op.getName() + " " + inVarName + " parameter already exists for another method with another data type (" + existing + ") either match the data type or change the parameter name" + " in you MBeanParameterInfo object for this operation";
/*     */                 
/*     */ 
/*     */ 
/* 255 */                 duplicatedInputVarname = true;
/* 256 */                 log.debug(msg);
/* 257 */                 break;
/*     */               }
/* 259 */               action.append("<argument>\r\n");
/* 260 */               action.append("<name>");
/* 261 */               operationsInputStateVariables.put(inVarName, actionInDataType);
/* 262 */               action.append(inVarName);
/* 263 */               action.append("</name>\r\n");
/* 264 */               action.append("<direction>in</direction>\r\n");
/* 265 */               action.append("<relatedStateVariable>");
/* 266 */               action.append(inVarName);
/* 267 */               action.append("</relatedStateVariable>\r\n");
/* 268 */               action.append("</argument>\r\n");
/*     */             }
/*     */           }
/*     */           
/* 272 */           action.append("</argumentList>\r\n");
/* 273 */           action.append("</action>\r\n");
/*     */           
/*     */ 
/* 276 */           if ((!nonPrimitiveInputType) && (!duplicatedInputVarname)) {
/* 277 */             this.operationsStateVariables.putAll(operationsInputStateVariables);
/* 278 */             this.operationsStateVariables.put(outVarName, actionOutDataType);
/* 279 */             rtrVal.append(action.toString());
/* 280 */             deployedActionNames.add(op.getName());
/*     */           }
/*     */         } }
/* 283 */       rtrVal.append("</actionList>\r\n");
/*     */     } else {
/* 285 */       rtrVal.append("<actionList/>\r\n");
/*     */     }
/*     */     
/*     */ 
/* 289 */     rtrVal.append("<serviceStateTable>\r\n");
/*     */     
/* 291 */     for (Iterator i = this.operationsStateVariables.keySet().iterator(); i.hasNext();) {
/* 292 */       String name = (String)i.next();
/* 293 */       String type = (String)this.operationsStateVariables.get(name);
/*     */       
/*     */ 
/* 296 */       rtrVal.append("<stateVariable sendEvents=\"no\">\r\n");
/* 297 */       rtrVal.append("<name>");
/* 298 */       rtrVal.append(name);
/* 299 */       rtrVal.append("</name>\r\n");
/* 300 */       rtrVal.append("<dataType>");
/* 301 */       rtrVal.append(type);
/* 302 */       rtrVal.append("</dataType>\r\n");
/* 303 */       rtrVal.append("</stateVariable>\r\n");
/*     */     }
/*     */     
/* 306 */     if ((atts != null) && (atts.length > 0)) {
/* 307 */       for (int i = 0; i < atts.length; i++) {
/* 308 */         MBeanAttributeInfo att = atts[i];
/* 309 */         if (att.isReadable()) {
/* 310 */           rtrVal.append("<stateVariable sendEvents=\"no\">\r\n");
/* 311 */           rtrVal.append("<name>");
/* 312 */           rtrVal.append(att.getName());
/* 313 */           rtrVal.append("</name>\r\n");
/* 314 */           rtrVal.append("<dataType>");
/*     */           
/* 316 */           String stateVarType = ServiceStateVariable.getUPNPDataTypeMapping(att.getType());
/* 317 */           if (stateVarType == null) stateVarType = "string";
/* 318 */           rtrVal.append(stateVarType);
/* 319 */           rtrVal.append("</dataType>\r\n");
/* 320 */           rtrVal.append("</stateVariable>\r\n");
/*     */         }
/*     */       }
/*     */     }
/* 324 */     rtrVal.append("</serviceStateTable>\r\n");
/* 325 */     rtrVal.append("</scpd>");
/* 326 */     return rtrVal.toString();
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo() {
/* 330 */     return this.mbeanInfo;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/UPNPMBeanService.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */