/*     */ package net.sbbi.upnp.jmx;
/*     */ 
/*     */ import java.net.URL;
/*     */ import javax.management.Notification;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UPNPDiscoveryNotification
/*     */   extends Notification
/*     */ {
/*     */   private String usn;
/*     */   private String udn;
/*     */   private String nt;
/*     */   private URL location;
/*     */   private ObjectName[] UPNPServiceMBeans;
/*     */   
/*     */   public UPNPDiscoveryNotification(String type, Object source, long sequenceNumber, long timeStamp)
/*     */   {
/*  69 */     super(type, source, sequenceNumber, timeStamp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getLocation()
/*     */   {
/*  77 */     return this.location;
/*     */   }
/*     */   
/*     */   protected void setLocation(URL location) {
/*  81 */     this.location = location;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNt()
/*     */   {
/*  89 */     return this.nt;
/*     */   }
/*     */   
/*     */   protected void setNt(String nt) {
/*  93 */     this.nt = nt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUdn()
/*     */   {
/* 101 */     return this.udn;
/*     */   }
/*     */   
/*     */   protected void setUdn(String udn) {
/* 105 */     this.udn = udn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUsn()
/*     */   {
/* 113 */     return this.usn;
/*     */   }
/*     */   
/*     */   protected void setUsn(String usn) {
/* 117 */     this.usn = usn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName[] getUPNPServiceMBeans()
/*     */   {
/* 125 */     return this.UPNPServiceMBeans;
/*     */   }
/*     */   
/*     */   protected void setUPNPServiceMBeans(ObjectName[] serviceMBeans) {
/* 129 */     this.UPNPServiceMBeans = serviceMBeans;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/UPNPDiscoveryNotification.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */