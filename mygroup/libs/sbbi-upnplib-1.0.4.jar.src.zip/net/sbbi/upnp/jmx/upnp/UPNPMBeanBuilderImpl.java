/*    */ package net.sbbi.upnp.jmx.upnp;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.MBeanInfo;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.ObjectInstance;
/*    */ import javax.management.ObjectName;
/*    */ import net.sbbi.upnp.jmx.UPNPMBeanDevice;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UPNPMBeanBuilderImpl
/*    */   implements UPNPMBeanBuilder
/*    */ {
/* 67 */   protected String domain = "sbbi.net";
/* 68 */   protected String vendor = "SuperBonBon Industries";
/*    */   
/*    */   public boolean select(ObjectName objectName, String className) {
/* 71 */     return true;
/*    */   }
/*    */   
/*    */   public UPNPMBeanDevice buildUPNPMBean(MBeanServer server, ObjectInstance objectInstance, MBeanInfo info) throws IOException
/*    */   {
/* 76 */     String descr = info.getDescription();
/* 77 */     if (descr == null) descr = "No MBean description available";
/* 78 */     String beanName = objectInstance.getObjectName().getKeyProperty("name");
/* 79 */     if (beanName == null) beanName = "No MBean name available";
/* 80 */     UPNPMBeanDevice dv = new UPNPMBeanDevice(this.domain, objectInstance.getClassName(), 1, this.vendor, descr, beanName, objectInstance.getObjectName().toString());
/*    */     
/* 82 */     dv.addService(info, objectInstance.getObjectName(), server, Integer.toString(info.getClassName().hashCode()), info.getClassName(), 1);
/*    */     
/* 84 */     return dv;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/upnp/UPNPMBeanBuilderImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */