/*    */ package net.sbbi.upnp.jmx.upnp;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.MalformedURLException;
/*    */ import java.util.Map;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.remote.JMXConnectorServer;
/*    */ import javax.management.remote.JMXConnectorServerProvider;
/*    */ import javax.management.remote.JMXServiceURL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerProvider
/*    */   implements JMXConnectorServerProvider
/*    */ {
/*    */   public static final String UPNP_PROTOCOL = "upnp";
/*    */   
/*    */   public JMXConnectorServer newJMXConnectorServer(JMXServiceURL serviceURL, Map env, MBeanServer server)
/*    */     throws IOException
/*    */   {
/* 73 */     String protocol = serviceURL.getProtocol();
/* 74 */     String path = serviceURL.getURLPath();
/* 75 */     if (!"upnp".equals(protocol)) { throw new MalformedURLException("Wrong protocol " + protocol + " for provider " + getClass().getName());
/*    */     }
/* 77 */     if ((path != null) && (path.trim().length() > 0)) throw new MalformedURLException("provider " + getClass().getName() + " does not support path " + path);
/* 78 */     return new UPNPConnectorServer(server, serviceURL, env);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/upnp/ServerProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */