/*     */ package net.sbbi.upnp.jmx.upnp;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MBeanServerInvocationHandler;
/*     */ import javax.management.MBeanServerNotification;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationEmitter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.remote.JMXConnectorServer;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import net.sbbi.upnp.jmx.UPNPDiscovery;
/*     */ import net.sbbi.upnp.jmx.UPNPDiscoveryMBean;
/*     */ import net.sbbi.upnp.jmx.UPNPMBeanDevice;
/*     */ import net.sbbi.upnp.jmx.UPNPServiceMBean;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UPNPConnectorServer
/*     */   extends JMXConnectorServer
/*     */   implements NotificationListener
/*     */ {
/*  92 */   private static final Log log = LogFactory.getLog(UPNPConnectorServer.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */   public static final String UPNP_MBEANS_BUILDER = UPNPConnectorServer.class.getName() + ".upnpbeans.builder";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */   public static final String EXPOSE_UPNP_DEVICES_AS_MBEANS = UPNPConnectorServer.class.getName() + ".upnpdevices.as.mbeans";
/*     */   
/*     */ 
/*     */ 
/* 109 */   public static final String EXPOSE_UPNP_DEVICES_AS_MBEANS_TIMEOUT = UPNPConnectorServer.class.getName() + ".upnpdevices.as.mbeans.timeout";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 115 */   public static final String HANDLE_SSDP_MESSAGES = UPNPConnectorServer.class.getName() + ".upnpdevices.as.mbeans.ssdp";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 120 */   public static final String EXPOSE_MBEANS_AS_UPNP_DEVICES = UPNPConnectorServer.class.getName() + ".mbeans.as.upnpdevices";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */   public static final String EXPOSE_EXISTING_MBEANS_AS_UPNP_DEVICES = UPNPConnectorServer.class.getName() + ".existing.mbeans.as.upnpdevices";
/*     */   
/*     */   private JMXServiceURL serviceURL;
/*     */   private Map env;
/*     */   private InetSocketAddress sktAddress;
/*     */   private UPNPMBeanBuilder builder;
/*     */   private Boolean exposeUPNPAsMBeans;
/*     */   private Boolean exposeMBeansAsUPNP;
/*     */   private Boolean exposeExistingMBeansAsUPNP;
/*     */   private Boolean handleSSDPMessages;
/* 136 */   private final Object STOP_PROCESS = new Object();
/* 137 */   private Map registeredMBeans = Collections.synchronizedMap(new HashMap());
/*     */   private ObjectName discoveryBeanName;
/*     */   
/*     */   public UPNPConnectorServer(MBeanServer server, JMXServiceURL serviceURL, Map env) throws IOException {
/* 141 */     super(server);
/* 142 */     this.serviceURL = serviceURL;
/* 143 */     this.env = env;
/*     */     
/* 145 */     this.sktAddress = new InetSocketAddress(InetAddress.getByName(serviceURL.getHost()), serviceURL.getPort());
/* 146 */     this.builder = ((UPNPMBeanBuilder)env.get(UPNP_MBEANS_BUILDER));
/* 147 */     if (this.builder == null) {
/* 148 */       this.builder = new UPNPMBeanBuilderImpl();
/*     */     }
/* 150 */     this.exposeUPNPAsMBeans = ((Boolean)env.get(EXPOSE_UPNP_DEVICES_AS_MBEANS));
/* 151 */     if (this.exposeUPNPAsMBeans == null) this.exposeUPNPAsMBeans = Boolean.FALSE;
/* 152 */     this.exposeMBeansAsUPNP = ((Boolean)env.get(EXPOSE_MBEANS_AS_UPNP_DEVICES));
/* 153 */     if (this.exposeMBeansAsUPNP == null) this.exposeMBeansAsUPNP = Boolean.TRUE;
/* 154 */     this.handleSSDPMessages = ((Boolean)env.get(HANDLE_SSDP_MESSAGES));
/* 155 */     if (this.handleSSDPMessages == null) this.handleSSDPMessages = Boolean.FALSE;
/* 156 */     this.exposeExistingMBeansAsUPNP = ((Boolean)env.get(EXPOSE_EXISTING_MBEANS_AS_UPNP_DEVICES));
/* 157 */     if (this.exposeExistingMBeansAsUPNP == null) { this.exposeExistingMBeansAsUPNP = Boolean.FALSE;
/*     */     }
/* 159 */     if ((!this.exposeMBeansAsUPNP.booleanValue()) && (!this.exposeUPNPAsMBeans.booleanValue()) && (!this.exposeExistingMBeansAsUPNP.booleanValue())) {
/* 160 */       throw new IOException("Useless UPNPConnectorServer since nothing will be deployed, unregister it");
/*     */     }
/*     */   }
/*     */   
/*     */   public JMXServiceURL getAddress() {
/* 165 */     return this.serviceURL;
/*     */   }
/*     */   
/*     */   public Map getAttributes() {
/* 169 */     return Collections.unmodifiableMap(this.env);
/*     */   }
/*     */   
/*     */   public boolean isActive() {
/* 173 */     return false;
/*     */   }
/*     */   
/*     */   public void start() throws IOException {
/* 177 */     MBeanServer server = getMBeanServer();
/* 178 */     if (this.exposeMBeansAsUPNP.booleanValue()) {
/*     */       try {
/* 180 */         ObjectName delegate = new ObjectName("JMImplementation:type=MBeanServerDelegate");
/* 181 */         NotificationEmitter emmiter = (NotificationEmitter)MBeanServerInvocationHandler.newProxyInstance(server, delegate, NotificationEmitter.class, false);
/*     */         
/* 183 */         emmiter.addNotificationListener(this, null, this);
/*     */       } catch (Exception ex) {
/* 185 */         IOException ioEx = new IOException("UPNPConnector start error");
/* 186 */         ioEx.initCause(ex);
/* 187 */         throw ioEx;
/*     */       }
/*     */     }
/* 190 */     if (this.exposeUPNPAsMBeans.booleanValue()) {
/* 191 */       int timeout = 2500;
/* 192 */       if (this.env.containsKey(EXPOSE_UPNP_DEVICES_AS_MBEANS_TIMEOUT)) {
/* 193 */         timeout = ((Integer)this.env.get(EXPOSE_UPNP_DEVICES_AS_MBEANS_TIMEOUT)).intValue();
/*     */       }
/*     */       try {
/* 196 */         this.discoveryBeanName = new ObjectName("UPNPLib discovery:name=Discovery MBean_" + hashCode());
/* 197 */         UPNPDiscoveryMBean bean = new UPNPDiscovery(timeout, this.handleSSDPMessages.booleanValue(), true);
/* 198 */         server.registerMBean(bean, this.discoveryBeanName);
/*     */       } catch (Exception ex) {
/* 200 */         IOException ioEx = new IOException("Error occured during MBeans discovery");
/* 201 */         ioEx.initCause(ex);
/* 202 */         throw ioEx; } }
/*     */     int c;
/*     */     Iterator i;
/* 205 */     if (this.exposeExistingMBeansAsUPNP.booleanValue()) {
/* 206 */       c = 0;
/* 207 */       Set objectInstances = super.getMBeanServer().queryNames(null, null);
/* 208 */       for (i = objectInstances.iterator(); i.hasNext();) {
/* 209 */         ObjectName name = (ObjectName)i.next();
/* 210 */         MBeanServerNotification not = new MBeanServerNotification("JMX.mbean.registered", this, c++, name);
/* 211 */         handleNotification(not, this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void stop() throws IOException {
/* 217 */     MBeanServer server = getMBeanServer();
/* 218 */     IOException error = null;
/* 219 */     if (this.exposeMBeansAsUPNP.booleanValue()) {
/*     */       try {
/* 221 */         ObjectName delegate = new ObjectName("JMImplementation:type=MBeanServerDelegate");
/* 222 */         NotificationEmitter emmiter = (NotificationEmitter)MBeanServerInvocationHandler.newProxyInstance(server, delegate, NotificationEmitter.class, false);
/* 223 */         emmiter.removeNotificationListener(this, null, this);
/*     */       }
/*     */       catch (Exception ex) {
/* 226 */         if (!(ex instanceof ListenerNotFoundException)) {
/* 227 */           IOException ioEx = new IOException("UPNPConnector stop error");
/* 228 */           ioEx.initCause(ex);
/* 229 */           error = ioEx;
/*     */         }
/*     */       }
/* 232 */       synchronized (this.STOP_PROCESS)
/*     */       {
/* 234 */         for (Iterator i = this.registeredMBeans.values().iterator(); i.hasNext();) {
/* 235 */           UPNPMBeanDevice dv = (UPNPMBeanDevice)i.next();
/*     */           try {
/* 237 */             dv.stop();
/*     */           } catch (IOException ex) {
/* 239 */             log.error("Error during UPNPMBean device stop", ex);
/*     */           }
/*     */         }
/* 242 */         this.registeredMBeans.clear();
/*     */       }
/*     */     }
/* 245 */     if (this.exposeUPNPAsMBeans.booleanValue()) {
/*     */       try {
/* 247 */         server.unregisterMBean(this.discoveryBeanName);
/*     */       } catch (Exception ex) {
/* 249 */         IOException ioEx = new IOException("Error occured during MBeans discovery");
/* 250 */         ioEx.initCause(ex);
/* 251 */         throw ioEx;
/*     */       }
/*     */     }
/* 254 */     if (error != null) {
/* 255 */       throw error;
/*     */     }
/*     */   }
/*     */   
/*     */   public void handleNotification(Notification notification, Object handBack)
/*     */   {
/* 261 */     if (notification.getType().equals("JMX.mbean.registered")) {
/* 262 */       MBeanServerNotification regNot = (MBeanServerNotification)notification;
/* 263 */       MBeanServer srv = getMBeanServer();
/* 264 */       ObjectName name = regNot.getMBeanName();
/*     */       try {
/* 266 */         ObjectInstance objIn = srv.getObjectInstance(name);
/* 267 */         String className = objIn.getClassName();
/*     */         
/* 269 */         if (className.equals(UPNPServiceMBean.class.getName())) return;
/* 270 */         if (this.builder.select(name, className)) {
/* 271 */           MBeanInfo info = srv.getMBeanInfo(name);
/* 272 */           UPNPMBeanDevice dv = this.builder.buildUPNPMBean(getMBeanServer(), objIn, info);
/* 273 */           if (dv != null) {
/* 274 */             dv.setBindAddress(this.sktAddress);
/* 275 */             dv.start();
/* 276 */             this.registeredMBeans.put(name.toString(), dv);
/*     */           }
/*     */         }
/*     */       } catch (Exception ex) {
/* 280 */         log.error("Error during UPNP Mbean device " + name.toString() + " creation", ex);
/*     */       }
/* 282 */     } else if (notification.getType().equals("JMX.mbean.unregistered")) {
/* 283 */       MBeanServerNotification regNot = (MBeanServerNotification)notification;
/* 284 */       String beanName = regNot.getMBeanName().toString();
/* 285 */       synchronized (this.STOP_PROCESS) {
/* 286 */         UPNPMBeanDevice dv = (UPNPMBeanDevice)this.registeredMBeans.get(beanName);
/* 287 */         if (dv != null) {
/*     */           try {
/* 289 */             dv.stop();
/*     */           } catch (Exception ex) {
/* 291 */             log.error("Error during UPNPMBean device stop", ex);
/*     */           }
/* 293 */           this.registeredMBeans.remove(beanName);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/upnp/UPNPConnectorServer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */