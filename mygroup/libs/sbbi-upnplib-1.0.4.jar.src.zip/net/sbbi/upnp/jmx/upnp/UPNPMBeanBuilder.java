package net.sbbi.upnp.jmx.upnp;

import java.io.IOException;
import javax.management.MBeanInfo;
import javax.management.MBeanServer;
import javax.management.ObjectInstance;
import javax.management.ObjectName;
import net.sbbi.upnp.jmx.UPNPMBeanDevice;

public abstract interface UPNPMBeanBuilder
{
  public abstract boolean select(ObjectName paramObjectName, String paramString);
  
  public abstract UPNPMBeanDevice buildUPNPMBean(MBeanServer paramMBeanServer, ObjectInstance paramObjectInstance, MBeanInfo paramMBeanInfo)
    throws IOException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/upnp/UPNPMBeanBuilder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */