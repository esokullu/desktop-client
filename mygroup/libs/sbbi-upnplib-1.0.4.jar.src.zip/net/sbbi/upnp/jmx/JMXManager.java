/*     */ package net.sbbi.upnp.jmx;
/*     */ 
/*     */ import javax.management.Attribute;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MBeanServerFactory;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.log.CommonsLogger;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMXManager
/*     */ {
/*  65 */   private static final JMXManager instance = new JMXManager();
/*     */   
/*  67 */   private static final org.apache.commons.logging.Log log = LogFactory.getLog(JMXManager.class);
/*     */   
/*  69 */   public JMXManager() { this.discBeanName = null; }
/*     */   
/*     */   private ObjectName discBeanName;
/*     */   private MBeanServer server;
/*     */   public static final JMXManager getInstance() {
/*  74 */     return instance;
/*     */   }
/*     */   
/*     */   public static final JMXManager getNewInstance(MBeanServer server) {
/*  78 */     JMXManager manager = new JMXManager();
/*  79 */     manager.setMBeanserver(server);
/*  80 */     return manager;
/*     */   }
/*     */   
/*     */   private void setMBeanserver(MBeanServer server) {
/*  84 */     this.server = server;
/*     */   }
/*     */   
/*     */   public void startup(int discoveryTimeout) throws Exception {
/*  88 */     this.discBeanName = new ObjectName("UPNPLib discovery:name=Discovery MBean_" + hashCode());
/*  89 */     UPNPDiscoveryMBean bean = new UPNPDiscovery(discoveryTimeout, true, true);
/*  90 */     this.server.registerMBean(bean, this.discBeanName);
/*     */   }
/*     */   
/*     */   public void shutdown() {
/*     */     try {
/*  95 */       this.server.unregisterMBean(this.discBeanName);
/*     */     } catch (Exception ex) {
/*  97 */       log.error("Error occured during UPNPDiscoveryMBean unregistration", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private MBeanServer initMBeanServer(MBeanServerConfig conf) throws Exception {
/* 102 */     mx4j.log.Log.redirectTo(new CommonsLogger());
/*     */     
/* 104 */     String oldSysProp = System.getProperty("javax.management.builder.initial");
/* 105 */     System.setProperty("javax.management.builder.initial", "mx4j.server.MX4JMBeanServerBuilder");
/* 106 */     MBeanServer server = MBeanServerFactory.createMBeanServer("UPNPLib");
/* 107 */     if (oldSysProp != null) {
/* 108 */       System.setProperty("javax.management.builder.initial", oldSysProp);
/*     */     }
/* 110 */     ObjectName serverName = new ObjectName("Http:name=HttpAdaptor");
/* 111 */     server.createMBean("mx4j.tools.adaptor.http.HttpAdaptor", serverName, null);
/*     */     
/* 113 */     server.setAttribute(serverName, new Attribute("Port", new Integer(conf.adapterAdapterPort)));
/*     */     
/* 115 */     Boolean allowWanBool = new Boolean(conf.allowWan);
/* 116 */     if (allowWanBool.booleanValue()) {
/* 117 */       server.setAttribute(serverName, new Attribute("Host", "0.0.0.0"));
/*     */     } else {
/* 119 */       server.setAttribute(serverName, new Attribute("Host", "localhost"));
/*     */     }
/*     */     
/* 122 */     ObjectName processorName = new ObjectName("Http:name=XSLTProcessor");
/* 123 */     server.createMBean("mx4j.tools.adaptor.http.XSLTProcessor", processorName, null);
/* 124 */     server.setAttribute(processorName, new Attribute("LocaleString", conf.locale));
/*     */     
/* 126 */     server.setAttribute(processorName, new Attribute("UseCache", Boolean.FALSE));
/*     */     
/* 128 */     server.setAttribute(processorName, new Attribute("PathInJar", "net/sbbi/jmx/xsl"));
/*     */     
/* 130 */     server.setAttribute(serverName, new Attribute("ProcessorName", processorName));
/*     */     
/* 132 */     server.invoke(serverName, "addAuthorization", new Object[] { conf.adapterUserName, conf.adapterPassword }, new String[] { "java.lang.String", "java.lang.String" });
/*     */     
/* 134 */     server.setAttribute(serverName, new Attribute("AuthenticationMethod", "basic"));
/*     */     
/* 136 */     server.invoke(serverName, "start", null, null);
/*     */     
/* 138 */     return server;
/*     */   }
/*     */   
/*     */   public static final void main(String[] args)
/*     */   {
/* 143 */     if (args.length != 6) {
/* 144 */       log.info("Usage : JMXManager <AdapterPort> <UserName> <Password> <AllowWan> <Locale> <discoveryTimeout>");
/* 145 */       System.exit(0);
/*     */     }
/*     */     try
/*     */     {
/* 149 */       JMXManager manager = getInstance();
/* 150 */       MBeanServerConfig conf = new MBeanServerConfig(args, null);
/* 151 */       manager.setMBeanserver(manager.initMBeanServer(conf));
/* 152 */       manager.startup(conf.discoveryTimeout);
/*     */     } catch (Exception ex) {
/* 154 */       log.error("Error during startup", ex);
/*     */     } }
/*     */   
/*     */   private static final class MBeanServerConfig { private String adapterAdapterPort;
/*     */     
/* 159 */     MBeanServerConfig(String[] x0, JMXManager.1 x1) { this(x0); }
/*     */     
/*     */ 
/*     */     private String adapterUserName;
/*     */     private String adapterPassword;
/*     */     private String allowWan;
/*     */     private String locale;
/*     */     private int discoveryTimeout;
/*     */     private MBeanServerConfig(String[] args)
/*     */     {
/* 169 */       this.adapterAdapterPort = args[0];
/* 170 */       this.adapterUserName = args[1];
/* 171 */       this.adapterPassword = args[2];
/* 172 */       this.allowWan = args[3];
/* 173 */       this.locale = args[4];
/* 174 */       this.discoveryTimeout = Integer.parseInt(args[5]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/JMXManager.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */