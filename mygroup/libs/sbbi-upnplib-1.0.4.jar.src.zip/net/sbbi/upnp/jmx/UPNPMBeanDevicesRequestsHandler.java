/*     */ package net.sbbi.upnp.jmx;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UPNPMBeanDevicesRequestsHandler
/*     */   implements Runnable
/*     */ {
/*  73 */   private static final Log log = LogFactory.getLog(UPNPMBeanDevicesRequestsHandler.class);
/*     */   
/*     */   private static final int MAX_HTTP_WORKERS = 10;
/*  76 */   private static final Map instances = new HashMap();
/*     */   
/*  78 */   private Set handledDevices = new HashSet();
/*  79 */   private Set httpWorkers = new HashSet();
/*     */   private ServerSocket srv;
/*  81 */   private boolean isRunning = false;
/*     */   private InetSocketAddress bindAddress;
/*     */   
/*     */   public static final UPNPMBeanDevicesRequestsHandler getInstance(InetSocketAddress bindAddress)
/*     */   {
/*  86 */     String key = bindAddress.toString();
/*  87 */     synchronized (instances) {
/*  88 */       UPNPMBeanDevicesRequestsHandler handler = (UPNPMBeanDevicesRequestsHandler)instances.get(key);
/*  89 */       if (handler == null) {
/*  90 */         handler = new UPNPMBeanDevicesRequestsHandler(bindAddress);
/*  91 */         instances.put(key, handler);
/*     */       }
/*  93 */       return handler;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*  98 */   private UPNPMBeanDevicesRequestsHandler(InetSocketAddress bindAddress) { this.bindAddress = bindAddress; }
/*     */   
/*     */   protected void addUPNPMBeanDevice(UPNPMBeanDevice rootDevice) {
/*     */     Iterator i;
/* 102 */     synchronized (this.handledDevices) {
/* 103 */       for (Iterator i = this.handledDevices.iterator(); i.hasNext();) {
/* 104 */         UPNPMBeanDevice registred = (UPNPMBeanDevice)i.next();
/* 105 */         if ((registred.getDeviceType().equals(rootDevice.getDeviceType())) && (registred.getUuid().equals(rootDevice.getUuid())))
/*     */         {
/*     */ 
/* 108 */           throw new RuntimeException("An UPNPMBeanDevice object of type " + rootDevice.getDeviceType() + " with uuid " + rootDevice.getUuid() + " is already registred within this class, use a different UPNPMBeanDevice internalId");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 113 */       if (this.handledDevices.size() == 0) {
/* 114 */         Thread runner = new Thread(this, "UPNPMBeanDevicesRequestsHandler " + this.bindAddress.toString());
/* 115 */         runner.setDaemon(true);
/* 116 */         runner.start();
/*     */       }
/* 118 */       this.handledDevices.add(rootDevice);
/*     */       
/* 120 */       for (i = rootDevice.getUPNPMBeanChildrens().iterator(); i.hasNext();) {
/* 121 */         this.handledDevices.add(i.next());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void removeUPNPMBeanDevice(UPNPMBeanDevice rootDevice) {
/* 127 */     synchronized (this.handledDevices) {
/* 128 */       if (this.handledDevices.contains(rootDevice)) {
/* 129 */         this.handledDevices.remove(rootDevice);
/*     */         
/* 131 */         for (Iterator i = rootDevice.getUPNPMBeanChildrens().iterator(); i.hasNext();) {
/* 132 */           this.handledDevices.remove(i.next());
/*     */         }
/* 134 */         if (this.handledDevices.size() == 0) {
/*     */           try {
/* 136 */             this.isRunning = false;
/* 137 */             this.srv.close();
/*     */           }
/*     */           catch (IOException ex) {}
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void notifyWorkerThreadEnd(HttpWorker worker)
/*     */   {
/* 147 */     synchronized (this.httpWorkers) {
/* 148 */       this.httpWorkers.remove(worker);
/*     */     }
/*     */   }
/*     */   
/*     */   public void run() {
/*     */     try {
/* 154 */       this.srv = new ServerSocket(this.bindAddress.getPort(), 200, this.bindAddress.getAddress());
/*     */     } catch (IOException ex) {
/* 156 */       log.error("Error during server socket creation, thread cannot start", ex);
/* 157 */       return;
/*     */     }
/* 159 */     this.isRunning = true;
/* 160 */     while (this.isRunning) {
/*     */       try {
/* 162 */         Socket skt = this.srv.accept();
/* 163 */         skt.setSoTimeout(30000);
/* 164 */         HttpWorker worker = new HttpWorker(skt, log, this.handledDevices, this);
/* 165 */         while (this.httpWorkers.size() >= 10) {
/*     */           try {
/* 167 */             Thread.sleep(100L);
/*     */           }
/*     */           catch (InterruptedException ex) {}
/*     */         }
/*     */         
/* 172 */         Thread workerThread = new Thread(worker, "UPNPMBeanDevicesRequestsHandler Http Worker " + this.httpWorkers.size());
/* 173 */         workerThread.start();
/* 174 */         synchronized (this.httpWorkers) {
/* 175 */           this.httpWorkers.add(worker);
/*     */         }
/*     */       } catch (IOException ex) {
/* 178 */         if (this.isRunning) {
/* 179 */           log.error("Error during client socket creation", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private class HttpWorker implements Runnable
/*     */   {
/*     */     private Socket client;
/*     */     private Log logger;
/*     */     private Set devices;
/*     */     private UPNPMBeanDevicesRequestsHandler handler;
/*     */     
/*     */     public HttpWorker(Socket client, Log log, Set handledDevices, UPNPMBeanDevicesRequestsHandler handler) {
/* 193 */       this.client = client;
/* 194 */       this.logger = log;
/* 195 */       this.devices = handledDevices;
/* 196 */       this.handler = handler;
/*     */     }
/*     */     
/*     */     public void run() {
/*     */       try {
/* 201 */         byte[] buffer = new byte['Ā'];
/* 202 */         InputStream in = this.client.getInputStream();
/* 203 */         StringBuffer request = new StringBuffer();
/* 204 */         int readen = 0;
/* 205 */         String firstReadenData = null;
/* 206 */         while (readen != -1) {
/* 207 */           readen = in.read(buffer);
/* 208 */           String data = new String(buffer, 0, readen);
/* 209 */           if (firstReadenData == null) {
/* 210 */             firstReadenData = data.toUpperCase();
/*     */           }
/* 212 */           request.append(data);
/*     */           
/* 214 */           String rawRequest = request.toString();
/* 215 */           if ((rawRequest.endsWith("\r\n\r\n")) && (firstReadenData.startsWith("GET"))) {
/* 216 */             readen = -1;
/* 217 */           } else if (rawRequest.indexOf("</s:Envelope>") != -1)
/*     */           {
/* 219 */             readen = -1;
/*     */           }
/*     */         }
/*     */         
/* 223 */         OutputStream out = this.client.getOutputStream();
/* 224 */         String req = request.toString().trim();
/* 225 */         if (this.logger.isDebugEnabled()) this.logger.debug("Received message:\n" + req);
/* 226 */         String toWrite = null;
/* 227 */         if (req.length() > 0) {
/* 228 */           HttpRequest httpReq = new HttpRequest(req);
/* 229 */           if ((httpReq.getHttpCommand() != null) && (httpReq.getHttpCommandArg() != null) && (httpReq.getHttpCommandArg().trim().length() > 0))
/*     */           {
/* 231 */             String cmd = httpReq.getHttpCommand();
/* 232 */             HttpRequestHandler handler = null;
/* 233 */             if (cmd.equals("GET")) {
/* 234 */               handler = HttpGetRequest.getInstance();
/*     */             }
/* 236 */             else if (cmd.equals("POST")) {
/* 237 */               handler = HttpPostRequest.getInstance();
/* 238 */             } else if (cmd.equals("SUBSCRIBE")) {
/* 239 */               handler = HttpSubscriptionRequest.getInstance();
/* 240 */             } else if (cmd.equals("UNSUBSCRIBE")) {
/* 241 */               handler = HttpSubscriptionRequest.getInstance();
/*     */             }
/* 243 */             if (handler != null) {
/* 244 */               toWrite = handler.service(this.devices, httpReq);
/*     */             }
/*     */           }
/*     */         }
/* 248 */         if (toWrite == null) {
/* 249 */           String content = "<html><head><title>Not found</title></head><body>The requested ressource cannot be found</body></html>";
/* 250 */           StringBuffer rtr = new StringBuffer();
/* 251 */           rtr.append("HTTP/1.1 404 Not Found\r\n");
/* 252 */           rtr.append("CONTENT-LENGTH: ").append(content.length()).append("\r\n");
/* 253 */           rtr.append("CONTENT-TYPE: text/html\r\n\r\n");
/* 254 */           rtr.append(content);
/* 255 */           toWrite = rtr.toString();
/*     */         }
/* 257 */         if (this.logger.isDebugEnabled()) this.logger.debug("Sending response :\n" + toWrite);
/* 258 */         out.write(toWrite.getBytes());
/* 259 */         out.flush();
/* 260 */         out.close();
/* 261 */         in.close();
/* 262 */         this.client.close();
/*     */       } catch (IOException ex) {
/* 264 */         this.logger.error("IO Exception occured during client serving", ex);
/*     */       } catch (Throwable t) {
/* 266 */         this.logger.error("Unexpected Exception occured during client serving", t);
/*     */       } finally {
/* 268 */         this.handler.notifyWorkerThreadEnd(this);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/jmx/UPNPMBeanDevicesRequestsHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */