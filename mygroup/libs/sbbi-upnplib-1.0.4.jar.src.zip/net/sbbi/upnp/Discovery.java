/*     */ package net.sbbi.upnp;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.Inet4Address;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.MulticastSocket;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import net.sbbi.upnp.devices.UPNPRootDevice;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Discovery
/*     */ {
/*  71 */   private static final Log log = LogFactory.getLog(Discovery.class);
/*     */   
/*     */   public static final String ROOT_DEVICES = "upnp:rootdevice";
/*     */   
/*     */   public static final String ALL_DEVICES = "ssdp:all";
/*     */   
/*     */   public static final int DEFAULT_MX = 3;
/*     */   
/*     */   public static final int DEFAULT_TTL = 4;
/*     */   
/*     */   public static final int DEFAULT_TIMEOUT = 1500;
/*     */   
/*     */   public static final String DEFAULT_SEARCH = "ssdp:all";
/*     */   
/*     */   public static final int DEFAULT_SSDP_SEARCH_PORT = 1901;
/*     */   
/*     */   public static final String SSDP_IP = "239.255.255.250";
/*     */   
/*     */   public static final int SSDP_PORT = 1900;
/*     */   
/*     */   public static UPNPRootDevice[] discover()
/*     */     throws IOException
/*     */   {
/*  94 */     return discover(1500, 4, 3, "ssdp:all");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UPNPRootDevice[] discover(String searchTarget)
/*     */     throws IOException
/*     */   {
/* 107 */     return discover(1500, 4, 3, searchTarget);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UPNPRootDevice[] discover(int timeOut, String searchTarget)
/*     */     throws IOException
/*     */   {
/* 121 */     return discover(timeOut, 4, 3, searchTarget);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UPNPRootDevice[] discover(int timeOut, int ttl, int mx, String searchTarget)
/*     */     throws IOException
/*     */   {
/* 137 */     return discoverDevices(timeOut, ttl, mx, searchTarget, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UPNPRootDevice[] discover(int timeOut, int ttl, int mx, String searchTarget, NetworkInterface ni)
/*     */     throws IOException
/*     */   {
/* 154 */     return discoverDevices(timeOut, ttl, mx, searchTarget, ni);
/*     */   }
/*     */   
/*     */   private static UPNPRootDevice[] discoverDevices(int timeOut, int ttl, int mx, String searchTarget, NetworkInterface ni) throws IOException {
/* 158 */     if ((searchTarget == null) || (searchTarget.trim().length() == 0)) {
/* 159 */       throw new IllegalArgumentException("Illegal searchTarget");
/*     */     }
/*     */     
/* 162 */     Map devices = new HashMap();
/*     */     
/* 164 */     DiscoveryResultsHandler handler = new DiscoveryResultsHandler() {
/*     */       private final Map val$devices;
/*     */       
/* 167 */       public void discoveredDevice(String usn, String udn, String nt, String maxAge, URL location, String firmware) { synchronized (this.val$devices) {
/* 168 */           if (!this.val$devices.containsKey(usn)) {
/*     */             try {
/* 170 */               UPNPRootDevice device = new UPNPRootDevice(location, maxAge, firmware, usn, udn);
/* 171 */               this.val$devices.put(usn, device);
/*     */             } catch (Exception ex) {
/* 173 */               Discovery.log.error("Error occured during upnp root device object creation from location " + location, ex);
/*     */             }
/*     */             
/*     */           }
/*     */         }
/*     */       }
/* 179 */     };
/* 180 */     DiscoveryListener.getInstance().registerResultsHandler(handler, searchTarget);
/* 181 */     Enumeration e; Enumeration adrs; Enumeration adrs; if (ni == null) {
/* 182 */       for (e = NetworkInterface.getNetworkInterfaces(); e.hasMoreElements();) {
/* 183 */         NetworkInterface intf = (NetworkInterface)e.nextElement();
/* 184 */         for (adrs = intf.getInetAddresses(); adrs.hasMoreElements();) {
/* 185 */           InetAddress adr = (InetAddress)adrs.nextElement();
/* 186 */           if (((adr instanceof Inet4Address)) && (!adr.isLoopbackAddress())) {
/* 187 */             sendSearchMessage(adr, ttl, mx, searchTarget);
/*     */           }
/*     */         }
/*     */       }
/*     */     } else {
/* 192 */       for (adrs = ni.getInetAddresses(); adrs.hasMoreElements();) {
/* 193 */         InetAddress adr = (InetAddress)adrs.nextElement();
/* 194 */         if (((adr instanceof Inet4Address)) && (!adr.isLoopbackAddress())) {
/* 195 */           sendSearchMessage(adr, ttl, mx, searchTarget);
/*     */         }
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 201 */       Thread.sleep(timeOut);
/*     */     }
/*     */     catch (InterruptedException ex) {}
/*     */     
/*     */ 
/* 206 */     DiscoveryListener.getInstance().unRegisterResultsHandler(handler, searchTarget);
/*     */     
/* 208 */     if (devices.size() == 0) {
/* 209 */       return null;
/*     */     }
/* 211 */     int j = 0;
/* 212 */     UPNPRootDevice[] rootDevices = new UPNPRootDevice[devices.size()];
/* 213 */     for (Iterator i = devices.values().iterator(); i.hasNext();) {
/* 214 */       rootDevices[(j++)] = ((UPNPRootDevice)i.next());
/*     */     }
/* 216 */     return rootDevices;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void sendSearchMessage(InetAddress src, int ttl, int mx, String searchTarget)
/*     */     throws IOException
/*     */   {
/* 230 */     int bindPort = 1901;
/* 231 */     String port = System.getProperty("net.sbbi.upnp.Discovery.bindPort");
/* 232 */     if (port != null) {
/* 233 */       bindPort = Integer.parseInt(port);
/*     */     }
/* 235 */     InetSocketAddress adr = new InetSocketAddress(InetAddress.getByName("239.255.255.250"), 1900);
/*     */     
/* 237 */     MulticastSocket skt = new MulticastSocket(null);
/* 238 */     skt.bind(new InetSocketAddress(src, bindPort));
/* 239 */     skt.setTimeToLive(ttl);
/* 240 */     StringBuffer packet = new StringBuffer();
/* 241 */     packet.append("M-SEARCH * HTTP/1.1\r\n");
/* 242 */     packet.append("HOST: 239.255.255.250:1900\r\n");
/* 243 */     packet.append("MAN: \"ssdp:discover\"\r\n");
/* 244 */     packet.append("MX: ").append(mx).append("\r\n");
/* 245 */     packet.append("ST: ").append(searchTarget).append("\r\n").append("\r\n");
/* 246 */     if (log.isDebugEnabled()) log.debug("Sending discovery message on 239.255.255.250:1900 multicast address form ip " + src.getHostAddress() + ":\n" + packet.toString());
/* 247 */     String toSend = packet.toString();
/* 248 */     byte[] pk = toSend.getBytes();
/* 249 */     skt.send(new DatagramPacket(pk, pk.length, adr));
/* 250 */     skt.disconnect();
/* 251 */     skt.close();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/Discovery.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */