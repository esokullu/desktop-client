/*     */ package net.sbbi.upnp.messages;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.StringReader;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import net.sbbi.upnp.services.ISO8601Date;
/*     */ import net.sbbi.upnp.services.ServiceAction;
/*     */ import net.sbbi.upnp.services.ServiceActionArgument;
/*     */ import net.sbbi.upnp.services.ServiceStateVariable;
/*     */ import net.sbbi.upnp.services.UPNPService;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActionMessage
/*     */ {
/*  71 */   private static final Log log = LogFactory.getLog(ActionMessage.class);
/*     */   
/*     */ 
/*     */   private UPNPService service;
/*     */   
/*     */   private ServiceAction serviceAction;
/*     */   
/*     */   private List inputParameters;
/*     */   
/*     */ 
/*     */   protected ActionMessage(UPNPService service, ServiceAction serviceAction)
/*     */   {
/*  83 */     this.service = service;
/*  84 */     this.serviceAction = serviceAction;
/*  85 */     if (serviceAction.getInputActionArguments() != null) {
/*  86 */       this.inputParameters = new ArrayList();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearInputParameters()
/*     */   {
/*  95 */     this.inputParameters.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ActionResponse service()
/*     */     throws IOException, UPNPResponseException
/*     */   {
/* 107 */     ActionResponse rtrVal = null;
/* 108 */     UPNPResponseException upnpEx = null;
/* 109 */     IOException ioEx = null;
/* 110 */     StringBuffer body = new StringBuffer(256);
/*     */     
/* 112 */     body.append("<?xml version=\"1.0\"?>\r\n");
/* 113 */     body.append("<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\"");
/* 114 */     body.append(" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">");
/* 115 */     body.append("<s:Body>");
/* 116 */     body.append("<u:").append(this.serviceAction.getName()).append(" xmlns:u=\"").append(this.service.getServiceType()).append("\">");
/*     */     Iterator itr;
/* 118 */     if (this.serviceAction.getInputActionArguments() != null)
/*     */     {
/* 120 */       for (itr = this.inputParameters.iterator(); itr.hasNext();) {
/* 121 */         InputParamContainer container = (InputParamContainer)itr.next();
/* 122 */         body.append("<").append(container.name).append(">").append(container.value);
/* 123 */         body.append("</").append(container.name).append(">");
/*     */       }
/*     */     }
/* 126 */     body.append("</u:").append(this.serviceAction.getName()).append(">");
/* 127 */     body.append("</s:Body>");
/* 128 */     body.append("</s:Envelope>");
/*     */     
/* 130 */     if (log.isDebugEnabled()) log.debug("POST prepared for URL " + this.service.getControlURL());
/* 131 */     URL url = new URL(this.service.getControlURL().toString());
/* 132 */     HttpURLConnection conn = (HttpURLConnection)url.openConnection();
/* 133 */     conn.setDoInput(true);
/* 134 */     conn.setDoOutput(true);
/* 135 */     conn.setUseCaches(false);
/* 136 */     conn.setRequestMethod("POST");
/* 137 */     HttpURLConnection.setFollowRedirects(false);
/*     */     
/* 139 */     conn.setRequestProperty("HOST", url.getHost() + ":" + url.getPort());
/* 140 */     conn.setRequestProperty("CONTENT-TYPE", "text/xml; charset=\"utf-8\"");
/* 141 */     conn.setRequestProperty("CONTENT-LENGTH", Integer.toString(body.length()));
/* 142 */     conn.setRequestProperty("SOAPACTION", "\"" + this.service.getServiceType() + "#" + this.serviceAction.getName() + "\"");
/* 143 */     OutputStream out = conn.getOutputStream();
/* 144 */     out.write(body.toString().getBytes());
/* 145 */     out.flush();
/* 146 */     out.close();
/* 147 */     conn.connect();
/* 148 */     InputStream input = null;
/*     */     
/* 150 */     if (log.isDebugEnabled()) log.debug("executing query :\n" + body);
/*     */     try {
/* 152 */       input = conn.getInputStream();
/*     */ 
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 157 */       input = conn.getErrorStream();
/*     */     }
/*     */     
/* 160 */     if (input != null) {
/* 161 */       int response = conn.getResponseCode();
/* 162 */       String responseBody = getResponseBody(input);
/* 163 */       if (log.isDebugEnabled()) log.debug("received response :\n" + responseBody);
/* 164 */       SAXParserFactory saxParFact = SAXParserFactory.newInstance();
/* 165 */       saxParFact.setValidating(false);
/* 166 */       saxParFact.setNamespaceAware(true);
/* 167 */       ActionMessageResponseParser msgParser = new ActionMessageResponseParser(this.serviceAction);
/* 168 */       StringReader stringReader = new StringReader(responseBody);
/* 169 */       InputSource src = new InputSource(stringReader);
/*     */       try {
/* 171 */         SAXParser parser = saxParFact.newSAXParser();
/* 172 */         parser.parse(src, msgParser);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 182 */           input.close();
/*     */         }
/*     */         catch (IOException ex) {}
/*     */         
/*     */ 
/* 187 */         if (upnpEx != null) {
/*     */           break label820;
/*     */         }
/*     */       }
/*     */       catch (ParserConfigurationException confEx)
/*     */       {
/* 176 */         throw new RuntimeException("ParserConfigurationException during SAX parser creation, please check your env settings:" + confEx.getMessage());
/*     */       }
/*     */       catch (SAXException saxEx) {
/* 179 */         upnpEx = new UPNPResponseException(899, saxEx.getMessage());
/*     */       } finally {
/*     */         try {
/* 182 */           input.close();
/*     */         }
/*     */         catch (IOException ex) {}
/*     */       }
/*     */       
/*     */ 
/* 188 */       if (response == 200) {
/* 189 */         rtrVal = msgParser.getActionResponse();
/* 190 */       } else if (response == 500) {
/* 191 */         upnpEx = msgParser.getUPNPResponseException();
/*     */       } else {
/* 193 */         ioEx = new IOException("Unexpected server HTTP response:" + response);
/*     */       }
/*     */     }
/*     */     try {
/*     */       label820:
/* 198 */       out.close();
/*     */     }
/*     */     catch (IOException ex) {}
/*     */     
/* 202 */     conn.disconnect();
/* 203 */     if (upnpEx != null) {
/* 204 */       throw upnpEx;
/*     */     }
/* 206 */     if ((rtrVal == null) && (ioEx == null)) {
/* 207 */       ioEx = new IOException("Unable to receive a response from the UPNP device");
/*     */     }
/* 209 */     if (ioEx != null) {
/* 210 */       throw ioEx;
/*     */     }
/* 212 */     return rtrVal;
/*     */   }
/*     */   
/*     */   private String getResponseBody(InputStream in) throws IOException {
/* 216 */     byte[] buffer = new byte['Ā'];
/* 217 */     int readen = 0;
/* 218 */     StringBuffer content = new StringBuffer(256);
/* 219 */     while ((readen = in.read(buffer)) != -1) {
/* 220 */       content.append(new String(buffer, 0, readen));
/*     */     }
/*     */     
/*     */ 
/* 224 */     int len = content.length();
/* 225 */     while (content.charAt(len - 1) == 0) {
/* 226 */       len--;
/* 227 */       content.setLength(len);
/*     */     }
/* 229 */     return content.toString().trim();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getInputParameterNames()
/*     */   {
/* 238 */     return this.serviceAction.getInputActionArgumentsNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getOutputParameterNames()
/*     */   {
/* 247 */     return this.serviceAction.getOutputActionArgumentsNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ActionMessage setInputParameter(String parameterName, Object parameterValue)
/*     */     throws IllegalArgumentException
/*     */   {
/* 261 */     if (parameterValue == null)
/* 262 */       return setInputParameter(parameterName, "");
/* 263 */     if ((parameterValue instanceof Date))
/* 264 */       return setInputParameter(parameterName, (Date)parameterValue);
/* 265 */     if ((parameterValue instanceof Boolean))
/* 266 */       return setInputParameter(parameterName, ((Boolean)parameterValue).booleanValue());
/* 267 */     if ((parameterValue instanceof Integer))
/* 268 */       return setInputParameter(parameterName, ((Integer)parameterValue).intValue());
/* 269 */     if ((parameterValue instanceof Byte))
/* 270 */       return setInputParameter(parameterName, ((Byte)parameterValue).byteValue());
/* 271 */     if ((parameterValue instanceof Short))
/* 272 */       return setInputParameter(parameterName, ((Short)parameterValue).shortValue());
/* 273 */     if ((parameterValue instanceof Float))
/* 274 */       return setInputParameter(parameterName, ((Float)parameterValue).floatValue());
/* 275 */     if ((parameterValue instanceof Double))
/* 276 */       return setInputParameter(parameterName, ((Double)parameterValue).doubleValue());
/* 277 */     if ((parameterValue instanceof Long)) {
/* 278 */       return setInputParameter(parameterName, ((Long)parameterValue).longValue());
/*     */     }
/* 280 */     return setInputParameter(parameterName, parameterValue.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ActionMessage setInputParameter(String parameterName, String parameterValue)
/*     */     throws IllegalArgumentException
/*     */   {
/* 295 */     if (this.serviceAction.getInputActionArguments() == null) throw new IllegalArgumentException("No input parameters required for this message");
/* 296 */     ServiceActionArgument arg = this.serviceAction.getInputActionArgument(parameterName);
/* 297 */     if (arg == null) throw new IllegalArgumentException("Wrong input argument name for this action:" + parameterName + " available parameters are : " + getInputParameterNames());
/* 298 */     for (Iterator i = this.inputParameters.iterator(); i.hasNext();) {
/* 299 */       InputParamContainer container = (InputParamContainer)i.next();
/* 300 */       if (container.name.equals(parameterName)) {
/* 301 */         container.value = parameterValue;
/* 302 */         return this;
/*     */       }
/*     */     }
/*     */     
/* 306 */     InputParamContainer container = new InputParamContainer(null);
/* 307 */     container.name = parameterName;
/* 308 */     container.value = parameterValue;
/* 309 */     this.inputParameters.add(container);
/* 310 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ActionMessage setInputParameter(String parameterName, Date parameterValue)
/*     */     throws IllegalArgumentException
/*     */   {
/* 323 */     if (this.serviceAction.getInputActionArguments() == null) throw new IllegalArgumentException("No input parameters required for this message");
/* 324 */     ServiceActionArgument arg = this.serviceAction.getInputActionArgument(parameterName);
/* 325 */     if (arg == null) throw new IllegalArgumentException("Wrong input argument name for this action:" + parameterName + " available parameters are : " + getInputParameterNames());
/* 326 */     ServiceStateVariable linkedVar = arg.getRelatedStateVariable();
/* 327 */     if (linkedVar.getDataType().equals("time"))
/* 328 */       return setInputParameter(parameterName, ISO8601Date.getIsoTime(parameterValue));
/* 329 */     if (linkedVar.getDataType().equals("time.tz"))
/* 330 */       return setInputParameter(parameterName, ISO8601Date.getIsoTimeZone(parameterValue));
/* 331 */     if (linkedVar.getDataType().equals("date"))
/* 332 */       return setInputParameter(parameterName, ISO8601Date.getIsoDate(parameterValue));
/* 333 */     if (linkedVar.getDataType().equals("dateTime"))
/* 334 */       return setInputParameter(parameterName, ISO8601Date.getIsoDateTime(parameterValue));
/* 335 */     if (linkedVar.getDataType().equals("dateTime.tz")) {
/* 336 */       return setInputParameter(parameterName, ISO8601Date.getIsoDateTimeZone(parameterValue));
/*     */     }
/* 338 */     throw new IllegalArgumentException("Related input state variable " + linkedVar.getName() + " is not of an date type");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ActionMessage setInputParameter(String parameterName, boolean parameterValue)
/*     */     throws IllegalArgumentException
/*     */   {
/* 352 */     return setInputParameter(parameterName, parameterValue ? "1" : "0");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ActionMessage setInputParameter(String parameterName, byte parameterValue)
/*     */     throws IllegalArgumentException
/*     */   {
/* 364 */     return setInputParameter(parameterName, Byte.toString(parameterValue));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ActionMessage setInputParameter(String parameterName, short parameterValue)
/*     */     throws IllegalArgumentException
/*     */   {
/* 376 */     return setInputParameter(parameterName, Short.toString(parameterValue));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ActionMessage setInputParameter(String parameterName, int parameterValue)
/*     */     throws IllegalArgumentException
/*     */   {
/* 388 */     return setInputParameter(parameterName, Integer.toString(parameterValue));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ActionMessage setInputParameter(String parameterName, long parameterValue)
/*     */     throws IllegalArgumentException
/*     */   {
/* 400 */     return setInputParameter(parameterName, Long.toString(parameterValue));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ActionMessage setInputParameter(String parameterName, float parameterValue)
/*     */     throws IllegalArgumentException
/*     */   {
/* 412 */     return setInputParameter(parameterName, Float.toString(parameterValue));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 424 */   public ActionMessage setInputParameter(String parameterName, double parameterValue)
/* 424 */     throws IllegalArgumentException { return setInputParameter(parameterName, Double.toString(parameterValue)); }
/*     */   
/*     */   private class InputParamContainer { private String name;
/*     */     
/*     */     private InputParamContainer() {}
/*     */     
/* 430 */     InputParamContainer(ActionMessage.1 x1) { this(); }
/*     */     
/*     */     private String value;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/messages/ActionMessage.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */