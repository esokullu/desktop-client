/*    */ package net.sbbi.upnp.messages;
/*    */ 
/*    */ import net.sbbi.upnp.services.ServiceStateVariable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StateVariableResponse
/*    */ {
/*    */   protected ServiceStateVariable stateVar;
/*    */   protected String stateVariableValue;
/*    */   
/*    */   public ServiceStateVariable getStateVar()
/*    */   {
/* 66 */     return this.stateVar;
/*    */   }
/*    */   
/*    */   public String getStateVariableValue() {
/* 70 */     return this.stateVariableValue;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/messages/StateVariableResponse.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */