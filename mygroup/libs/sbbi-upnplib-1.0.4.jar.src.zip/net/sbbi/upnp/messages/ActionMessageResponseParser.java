/*     */ package net.sbbi.upnp.messages;
/*     */ 
/*     */ import net.sbbi.upnp.services.ServiceAction;
/*     */ import net.sbbi.upnp.services.ServiceActionArgument;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActionMessageResponseParser
/*     */   extends DefaultHandler
/*     */ {
/*  64 */   private static final Log log = LogFactory.getLog(ActionMessageResponseParser.class);
/*     */   
/*     */   private static final String SOAP_FAULT_EL = "Fault";
/*     */   
/*     */   private ServiceAction serviceAction;
/*     */   private String bodyElementName;
/*  70 */   private boolean faultResponse = false;
/*     */   
/*     */   private UPNPResponseException msgEx;
/*  73 */   private boolean readFaultCode = false;
/*  74 */   private boolean readFaultString = false;
/*  75 */   private boolean readErrorCode = false;
/*  76 */   private boolean readErrorDescription = false;
/*  77 */   private boolean parseOutputParams = false;
/*     */   private ActionResponse result;
/*     */   private ServiceActionArgument parsedResultOutArg;
/*     */   
/*     */   protected ActionMessageResponseParser(ServiceAction serviceAction) {
/*  82 */     this.serviceAction = serviceAction;
/*  83 */     this.bodyElementName = (serviceAction.getName() + "Response");
/*     */   }
/*     */   
/*     */   protected UPNPResponseException getUPNPResponseException() {
/*  87 */     return this.msgEx;
/*     */   }
/*     */   
/*     */   protected ActionResponse getActionResponse() {
/*  91 */     return this.result;
/*     */   }
/*     */   
/*     */   public void characters(char[] ch, int start, int length) {
/*  95 */     if (this.parseOutputParams) {
/*  96 */       if (this.parsedResultOutArg != null) {
/*  97 */         String origChars = this.result.getOutActionArgumentValue(this.parsedResultOutArg.getName());
/*  98 */         String newChars = new String(ch, start, length);
/*  99 */         if (origChars == null) {
/* 100 */           this.result.addResult(this.parsedResultOutArg, newChars);
/*     */         } else {
/* 102 */           this.result.addResult(this.parsedResultOutArg, origChars + newChars);
/*     */         }
/*     */       }
/* 105 */     } else if (this.readFaultCode) {
/* 106 */       this.msgEx.faultCode = new String(ch, start, length);
/* 107 */       this.readFaultCode = false;
/* 108 */     } else if (this.readFaultString) {
/* 109 */       this.msgEx.faultString = new String(ch, start, length);
/* 110 */       this.readFaultString = false;
/* 111 */     } else if (this.readErrorCode) {
/* 112 */       String code = new String(ch, start, length);
/*     */       try {
/* 114 */         this.msgEx.detailErrorCode = Integer.parseInt(code);
/*     */       } catch (Throwable ex) {
/* 116 */         log.debug("Error during returned error code " + code + " parsing");
/*     */       }
/* 118 */       this.readErrorCode = false;
/* 119 */     } else if (this.readErrorDescription) {
/* 120 */       this.msgEx.detailErrorDescription = new String(ch, start, length);
/* 121 */       this.readErrorDescription = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public void startElement(String uri, String localName, String qName, Attributes attributes) {
/* 126 */     if (this.parseOutputParams) {
/* 127 */       ServiceActionArgument arg = this.serviceAction.getActionArgument(localName);
/* 128 */       if ((arg != null) && (arg.getDirection() == "out")) {
/* 129 */         this.parsedResultOutArg = arg;
/* 130 */         this.result.addResult(this.parsedResultOutArg, null);
/*     */       } else {
/* 132 */         this.parsedResultOutArg = null;
/*     */       }
/* 134 */     } else if (this.faultResponse) {
/* 135 */       if (localName.equals("faultcode")) {
/* 136 */         this.readFaultCode = true;
/* 137 */       } else if (localName.equals("faultstring")) {
/* 138 */         this.readFaultString = true;
/* 139 */       } else if (localName.equals("errorCode")) {
/* 140 */         this.readErrorCode = true;
/* 141 */       } else if (localName.equals("errorDescription")) {
/* 142 */         this.readErrorDescription = true;
/*     */       }
/* 144 */     } else if (localName.equals("Fault")) {
/* 145 */       this.msgEx = new UPNPResponseException();
/* 146 */       this.faultResponse = true;
/* 147 */     } else if (localName.equals(this.bodyElementName)) {
/* 148 */       this.parseOutputParams = true;
/* 149 */       this.result = new ActionResponse();
/*     */     }
/*     */   }
/*     */   
/*     */   public void endElement(String uri, String localName, String qName) {
/* 154 */     if ((this.parsedResultOutArg != null) && (this.parsedResultOutArg.getName().equals(localName))) {
/* 155 */       this.parsedResultOutArg = null;
/* 156 */     } else if (localName.equals(this.bodyElementName)) {
/* 157 */       this.parseOutputParams = false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/messages/ActionMessageResponseParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */