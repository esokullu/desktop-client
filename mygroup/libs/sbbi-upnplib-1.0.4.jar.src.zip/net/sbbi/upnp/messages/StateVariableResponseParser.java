/*     */ package net.sbbi.upnp.messages;
/*     */ 
/*     */ import net.sbbi.upnp.services.ServiceStateVariable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StateVariableResponseParser
/*     */   extends DefaultHandler
/*     */ {
/*  65 */   private static final Log log = LogFactory.getLog(StateVariableResponseParser.class);
/*     */   
/*     */   private static final String SOAP_FAULT_EL = "Fault";
/*     */   
/*     */   private ServiceStateVariable stateVar;
/*  70 */   private boolean faultResponse = false;
/*     */   
/*     */   private UPNPResponseException msgEx;
/*  73 */   private boolean readFaultCode = false;
/*  74 */   private boolean readFaultString = false;
/*  75 */   private boolean readErrorCode = false;
/*  76 */   private boolean readErrorDescription = false;
/*  77 */   private boolean parseStateVar = false;
/*     */   private StateVariableResponse result;
/*     */   
/*     */   protected StateVariableResponseParser(ServiceStateVariable stateVar) {
/*  81 */     this.stateVar = stateVar;
/*     */   }
/*     */   
/*     */   protected UPNPResponseException getUPNPResponseException() {
/*  85 */     return this.msgEx;
/*     */   }
/*     */   
/*     */   protected StateVariableResponse getStateVariableResponse() {
/*  89 */     return this.result;
/*     */   }
/*     */   
/*     */   public void characters(char[] ch, int start, int length) {
/*  93 */     if (this.parseStateVar) {
/*  94 */       String origChars = this.result.stateVariableValue;
/*  95 */       String newChars = new String(ch, start, length);
/*  96 */       if (origChars == null) {
/*  97 */         this.result.stateVariableValue = newChars;
/*     */       } else {
/*  99 */         this.result.stateVariableValue = (origChars + newChars);
/*     */       }
/* 101 */     } else if (this.readFaultCode) {
/* 102 */       this.msgEx.faultCode = new String(ch, start, length);
/* 103 */       this.readFaultCode = false;
/* 104 */     } else if (this.readFaultString) {
/* 105 */       this.msgEx.faultString = new String(ch, start, length);
/* 106 */       this.readFaultString = false;
/* 107 */     } else if (this.readErrorCode) {
/* 108 */       String code = new String(ch, start, length);
/*     */       try {
/* 110 */         this.msgEx.detailErrorCode = Integer.parseInt(code);
/*     */       } catch (Throwable ex) {
/* 112 */         log.debug("Error during returned error code " + code + " parsing");
/*     */       }
/* 114 */       this.readErrorCode = false;
/* 115 */     } else if (this.readErrorDescription) {
/* 116 */       this.msgEx.detailErrorDescription = new String(ch, start, length);
/* 117 */       this.readErrorDescription = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public void startElement(String uri, String localName, String qName, Attributes attributes)
/*     */   {
/* 123 */     if (this.faultResponse) {
/* 124 */       if (localName.equals("faultcode")) {
/* 125 */         this.readFaultCode = true;
/* 126 */       } else if (localName.equals("faultstring")) {
/* 127 */         this.readFaultString = true;
/* 128 */       } else if (localName.equals("errorCode")) {
/* 129 */         this.readErrorCode = true;
/* 130 */       } else if (localName.equals("errorDescription")) {
/* 131 */         this.readErrorDescription = true;
/*     */       }
/* 133 */     } else if (localName.equals("Fault")) {
/* 134 */       this.msgEx = new UPNPResponseException();
/* 135 */       this.faultResponse = true;
/* 136 */     } else if ((localName.equals("return")) || (localName.equals("varName")))
/*     */     {
/*     */ 
/* 139 */       this.parseStateVar = true;
/* 140 */       this.result = new StateVariableResponse();
/* 141 */       this.result.stateVar = this.stateVar;
/*     */     }
/*     */   }
/*     */   
/*     */   public void endElement(String uri, String localName, String qName)
/*     */     throws SAXException
/*     */   {
/* 148 */     if ((localName.equals("return")) || (localName.equals("varName"))) {
/* 149 */       this.parseStateVar = false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/messages/StateVariableResponseParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */