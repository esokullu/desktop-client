/*     */ package net.sbbi.upnp.messages;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.StringReader;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import net.sbbi.upnp.services.ServiceStateVariable;
/*     */ import net.sbbi.upnp.services.UPNPService;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StateVariableMessage
/*     */ {
/*  70 */   private static final Log log = LogFactory.getLog(StateVariableMessage.class);
/*     */   private UPNPService service;
/*     */   private ServiceStateVariable serviceStateVar;
/*     */   
/*     */   protected StateVariableMessage(UPNPService service, ServiceStateVariable serviceStateVar)
/*     */   {
/*  76 */     this.service = service;
/*  77 */     this.serviceStateVar = serviceStateVar;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StateVariableResponse service()
/*     */     throws IOException, UPNPResponseException
/*     */   {
/*  89 */     StateVariableResponse rtrVal = null;
/*  90 */     UPNPResponseException upnpEx = null;
/*  91 */     IOException ioEx = null;
/*  92 */     StringBuffer body = new StringBuffer(256);
/*     */     
/*  94 */     body.append("<?xml version=\"1.0\"?>\r\n");
/*  95 */     body.append("<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\"");
/*  96 */     body.append(" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">");
/*  97 */     body.append("<s:Body>");
/*  98 */     body.append("<u:QueryStateVariable xmlns:u=\"urn:schemas-upnp-org:control-1-0\">");
/*  99 */     body.append("<u:varName>").append(this.serviceStateVar.getName()).append("</u:varName>");
/* 100 */     body.append("</u:QueryStateVariable>");
/* 101 */     body.append("</s:Body>");
/* 102 */     body.append("</s:Envelope>");
/*     */     
/* 104 */     if (log.isDebugEnabled()) log.debug("POST prepared for URL " + this.service.getControlURL());
/* 105 */     URL url = new URL(this.service.getControlURL().toString());
/* 106 */     HttpURLConnection conn = (HttpURLConnection)url.openConnection();
/* 107 */     conn.setDoInput(true);
/* 108 */     conn.setDoOutput(true);
/* 109 */     conn.setUseCaches(false);
/* 110 */     conn.setRequestMethod("POST");
/* 111 */     HttpURLConnection.setFollowRedirects(false);
/*     */     
/* 113 */     conn.setRequestProperty("HOST", url.getHost() + ":" + url.getPort());
/* 114 */     conn.setRequestProperty("SOAPACTION", "\"urn:schemas-upnp-org:control-1-0#QueryStateVariable\"");
/* 115 */     conn.setRequestProperty("CONTENT-TYPE", "text/xml; charset=\"utf-8\"");
/* 116 */     conn.setRequestProperty("CONTENT-LENGTH", Integer.toString(body.length()));
/* 117 */     OutputStream out = conn.getOutputStream();
/* 118 */     out.write(body.toString().getBytes());
/* 119 */     out.flush();
/* 120 */     conn.connect();
/* 121 */     InputStream input = null;
/*     */     
/* 123 */     if (log.isDebugEnabled()) log.debug("executing query :\n" + body);
/*     */     try {
/* 125 */       input = conn.getInputStream();
/*     */ 
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 130 */       input = conn.getErrorStream();
/*     */     }
/*     */     
/* 133 */     if (input != null) {
/* 134 */       int response = conn.getResponseCode();
/* 135 */       String responseBody = getResponseBody(input);
/* 136 */       if (log.isDebugEnabled()) log.debug("received response :\n" + responseBody);
/* 137 */       SAXParserFactory saxParFact = SAXParserFactory.newInstance();
/* 138 */       saxParFact.setValidating(false);
/* 139 */       saxParFact.setNamespaceAware(true);
/* 140 */       StateVariableResponseParser msgParser = new StateVariableResponseParser(this.serviceStateVar);
/* 141 */       StringReader stringReader = new StringReader(responseBody);
/* 142 */       InputSource src = new InputSource(stringReader);
/*     */       try {
/* 144 */         SAXParser parser = saxParFact.newSAXParser();
/* 145 */         parser.parse(src, msgParser);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 155 */           input.close();
/*     */         }
/*     */         catch (IOException ex) {}
/*     */         
/*     */ 
/* 160 */         if (upnpEx != null) {
/*     */           break label654;
/*     */         }
/*     */       }
/*     */       catch (ParserConfigurationException confEx)
/*     */       {
/* 149 */         throw new RuntimeException("ParserConfigurationException during SAX parser creation, please check your env settings:" + confEx.getMessage());
/*     */       }
/*     */       catch (SAXException saxEx) {
/* 152 */         upnpEx = new UPNPResponseException(899, saxEx.getMessage());
/*     */       } finally {
/*     */         try {
/* 155 */           input.close();
/*     */         }
/*     */         catch (IOException ex) {}
/*     */       }
/*     */       
/*     */ 
/* 161 */       if (response == 200) {
/* 162 */         rtrVal = msgParser.getStateVariableResponse();
/* 163 */       } else if (response == 500) {
/* 164 */         upnpEx = msgParser.getUPNPResponseException();
/*     */       } else {
/* 166 */         ioEx = new IOException("Unexpected server HTTP response:" + response);
/*     */       }
/*     */     }
/*     */     try {
/*     */       label654:
/* 171 */       out.close();
/*     */     }
/*     */     catch (IOException ex) {}
/*     */     
/* 175 */     conn.disconnect();
/* 176 */     if (upnpEx != null) {
/* 177 */       throw upnpEx;
/*     */     }
/* 179 */     if ((rtrVal == null) && (ioEx == null)) {
/* 180 */       ioEx = new IOException("Unable to receive a response from the UPNP device");
/*     */     }
/* 182 */     if (ioEx != null) {
/* 183 */       throw ioEx;
/*     */     }
/* 185 */     return rtrVal;
/*     */   }
/*     */   
/*     */   private String getResponseBody(InputStream in) throws IOException {
/* 189 */     byte[] buffer = new byte['Ā'];
/* 190 */     int readen = 0;
/* 191 */     StringBuffer content = new StringBuffer(256);
/* 192 */     while ((readen = in.read(buffer)) != -1) {
/* 193 */       content.append(new String(buffer, 0, readen));
/*     */     }
/*     */     
/*     */ 
/* 197 */     int len = content.length();
/* 198 */     while (content.charAt(len - 1) == 0) {
/* 199 */       len--;
/* 200 */       content.setLength(len);
/*     */     }
/* 202 */     return content.toString().trim();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/messages/StateVariableMessage.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */