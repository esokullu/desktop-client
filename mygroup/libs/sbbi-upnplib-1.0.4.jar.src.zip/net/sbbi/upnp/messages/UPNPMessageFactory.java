/*     */ package net.sbbi.upnp.messages;
/*     */ 
/*     */ import net.sbbi.upnp.services.ServiceAction;
/*     */ import net.sbbi.upnp.services.ServiceStateVariable;
/*     */ import net.sbbi.upnp.services.UPNPService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UPNPMessageFactory
/*     */ {
/*     */   private UPNPService service;
/*     */   
/*     */   private UPNPMessageFactory(UPNPService service)
/*     */   {
/*  68 */     this.service = service;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UPNPMessageFactory getNewInstance(UPNPService service)
/*     */   {
/*  77 */     return new UPNPMessageFactory(service);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ActionMessage getMessage(String serviceActionName)
/*     */   {
/*  87 */     ServiceAction serviceAction = this.service.getUPNPServiceAction(serviceActionName);
/*  88 */     if (serviceAction != null) {
/*  89 */       return new ActionMessage(this.service, serviceAction);
/*     */     }
/*  91 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StateVariableMessage getStateVariableMessage(String serviceStateVariable)
/*     */   {
/* 101 */     ServiceStateVariable stateVar = this.service.getUPNPServiceStateVariable(serviceStateVariable);
/* 102 */     if (stateVar != null) {
/* 103 */       return new StateVariableMessage(this.service, stateVar);
/*     */     }
/* 105 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/messages/UPNPMessageFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */