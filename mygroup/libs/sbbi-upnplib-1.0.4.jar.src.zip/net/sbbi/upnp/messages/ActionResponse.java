/*    */ package net.sbbi.upnp.messages;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import net.sbbi.upnp.services.ServiceActionArgument;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionResponse
/*    */ {
/* 61 */   private Map outArguments = new HashMap();
/* 62 */   private Map outArgumentsVals = new HashMap();
/*    */   
/*    */ 
/*    */ 
/*    */   public ServiceActionArgument getOutActionArgument(String actionArgumentName)
/*    */   {
/* 68 */     return (ServiceActionArgument)this.outArguments.get(actionArgumentName);
/*    */   }
/*    */   
/*    */   public String getOutActionArgumentValue(String actionArgumentName) {
/* 72 */     return (String)this.outArgumentsVals.get(actionArgumentName);
/*    */   }
/*    */   
/*    */   public Set getOutActionArgumentNames() {
/* 76 */     return this.outArguments.keySet();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void addResult(ServiceActionArgument arg, String value)
/*    */   {
/* 86 */     this.outArguments.put(arg.getName(), arg);
/* 87 */     this.outArgumentsVals.put(arg.getName(), value);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 91 */     StringBuffer rtrVal = new StringBuffer();
/* 92 */     for (Iterator i = this.outArguments.keySet().iterator(); i.hasNext();) {
/* 93 */       String name = (String)i.next();
/* 94 */       String value = (String)this.outArgumentsVals.get(name);
/* 95 */       rtrVal.append(name).append("=").append(value);
/* 96 */       if (i.hasNext()) rtrVal.append("\n");
/*    */     }
/* 98 */     return rtrVal.toString();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/messages/ActionResponse.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */