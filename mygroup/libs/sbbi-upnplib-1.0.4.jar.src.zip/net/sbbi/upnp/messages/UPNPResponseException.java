/*    */ package net.sbbi.upnp.messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UPNPResponseException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 8313107558129180594L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected String faultCode;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected String faultString;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected int detailErrorCode;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected String detailErrorDescription;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public UPNPResponseException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public UPNPResponseException(int detailErrorCode, String detailErrorDescription)
/*    */   {
/* 69 */     this.detailErrorCode = detailErrorCode;
/* 70 */     this.detailErrorDescription = detailErrorDescription;
/*    */   }
/*    */   
/*    */   public String getFaultCode() {
/* 74 */     return this.faultCode == null ? "Client" : this.faultCode;
/*    */   }
/*    */   
/*    */   public String getFaultString() {
/* 78 */     return this.faultString == null ? "UPnPError" : this.faultString;
/*    */   }
/*    */   
/*    */   public int getDetailErrorCode() {
/* 82 */     return this.detailErrorCode;
/*    */   }
/*    */   
/*    */   public String getDetailErrorDescription() {
/* 86 */     return this.detailErrorDescription;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 90 */     return "Detailed error code :" + this.detailErrorCode + ", Detailed error description :" + this.detailErrorDescription;
/*    */   }
/*    */   
/*    */   public String getLocalizedMessage() {
/* 94 */     return getMessage();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/messages/UPNPResponseException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */