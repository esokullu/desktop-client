/*     */ package net.sbbi.upnp;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.MulticastSocket;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiscoveryAdvertisement
/*     */   implements Runnable
/*     */ {
/*  68 */   private static final Log log = LogFactory.getLog(DiscoveryAdvertisement.class);
/*     */   
/*  70 */   private static boolean MATCH_IP = true;
/*     */   private static final int DEFAULT_TIMEOUT = 250;
/*     */   
/*  73 */   static { String prop = System.getProperty("net.sbbi.upnp.ddos.matchip");
/*  74 */     if ((prop != null) && (prop.equals("false"))) { MATCH_IP = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static final int EVENT_SSDP_ALIVE = 0;
/*     */   
/*     */   public static final int EVENT_SSDP_BYE_BYE = 1;
/*     */   
/*     */   private static final String NTS_SSDP_ALIVE = "ssdp:alive";
/*     */   private static final String NTS_SSDP_BYE_BYE = "ssdp:byebye";
/*     */   private static final String NT_ALL_EVENTS = "DiscoveryAdvertisement:nt:allevents";
/*  86 */   private Map byeByeRegistered = new HashMap();
/*  87 */   private Map aliveRegistered = new HashMap();
/*  88 */   private Map USNPerIP = new HashMap();
/*     */   
/*  90 */   private final Object REGISTRATION_PROCESS = new Object();
/*     */   
/*  92 */   private static final DiscoveryAdvertisement singleton = new DiscoveryAdvertisement();
/*  93 */   private boolean inService = false;
/*  94 */   private boolean daemon = true;
/*     */   
/*     */   private MulticastSocket skt;
/*     */   
/*     */   private DatagramPacket input;
/*     */   
/*     */ 
/*     */   public static final DiscoveryAdvertisement getInstance()
/*     */   {
/* 103 */     return singleton;
/*     */   }
/*     */   
/*     */   public void setDaemon(boolean daemon) {
/* 107 */     this.daemon = daemon;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerEvent(int notificationEvent, String nt, DiscoveryEventHandler eventHandler)
/*     */     throws IOException
/*     */   {
/* 120 */     synchronized (this.REGISTRATION_PROCESS) {
/* 121 */       if (!this.inService) startDevicesListenerThread();
/* 122 */       if (nt == null) nt = "DiscoveryAdvertisement:nt:allevents";
/* 123 */       if (notificationEvent == 0) {
/* 124 */         Set handlers = (Set)this.aliveRegistered.get(nt);
/* 125 */         if (handlers == null) {
/* 126 */           handlers = new HashSet();
/* 127 */           this.aliveRegistered.put(nt, handlers);
/*     */         }
/* 129 */         handlers.add(eventHandler);
/* 130 */       } else if (notificationEvent == 1) {
/* 131 */         Set handlers = (Set)this.byeByeRegistered.get(nt);
/* 132 */         if (handlers == null) {
/* 133 */           handlers = new HashSet();
/* 134 */           this.byeByeRegistered.put(nt, handlers);
/*     */         }
/* 136 */         handlers.add(eventHandler);
/*     */       } else {
/* 138 */         throw new IllegalArgumentException("Unknown notificationEvent type");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void unRegisterEvent(int notificationEvent, String nt, DiscoveryEventHandler eventHandler)
/*     */   {
/* 152 */     synchronized (this.REGISTRATION_PROCESS) {
/* 153 */       if (nt == null) nt = "DiscoveryAdvertisement:nt:allevents";
/* 154 */       if (notificationEvent == 0) {
/* 155 */         Set handlers = (Set)this.aliveRegistered.get(nt);
/* 156 */         if (handlers != null) {
/* 157 */           handlers.remove(eventHandler);
/* 158 */           if (handlers.size() == 0) {
/* 159 */             this.aliveRegistered.remove(nt);
/*     */           }
/*     */         }
/* 162 */       } else if (notificationEvent == 1) {
/* 163 */         Set handlers = (Set)this.byeByeRegistered.get(nt);
/* 164 */         if (handlers != null) {
/* 165 */           handlers.remove(eventHandler);
/* 166 */           if (handlers.size() == 0) {
/* 167 */             this.byeByeRegistered.remove(nt);
/*     */           }
/*     */         }
/*     */       } else {
/* 171 */         throw new IllegalArgumentException("Unknown notificationEvent type");
/*     */       }
/* 173 */       if ((this.aliveRegistered.size() == 0) && (this.byeByeRegistered.size() == 0)) {
/* 174 */         stopDevicesListenerThread();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void startDevicesListenerThread() throws IOException {
/* 180 */     synchronized (singleton) {
/* 181 */       if (!this.inService) {
/* 182 */         startMultiCastSocket();
/* 183 */         Thread deamon = new Thread(this, "DiscoveryAdvertisement daemon");
/* 184 */         deamon.setDaemon(this.daemon);
/* 185 */         deamon.start();
/*     */         
/* 187 */         while (!this.inService) {
/*     */           try
/*     */           {
/* 190 */             Thread.sleep(2L);
/*     */           }
/*     */           catch (InterruptedException ex) {}
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void stopDevicesListenerThread()
/*     */   {
/* 200 */     synchronized (singleton) {
/* 201 */       this.inService = false;
/*     */     }
/*     */   }
/*     */   
/*     */   private void startMultiCastSocket() throws IOException
/*     */   {
/* 207 */     this.skt = new MulticastSocket(null);
/* 208 */     this.skt.bind(new InetSocketAddress(InetAddress.getByName("0.0.0.0"), 1900));
/* 209 */     this.skt.setTimeToLive(4);
/* 210 */     this.skt.setSoTimeout(250);
/* 211 */     this.skt.joinGroup(InetAddress.getByName("239.255.255.250"));
/*     */     
/* 213 */     byte[] buf = new byte['ࠀ'];
/* 214 */     this.input = new DatagramPacket(buf, buf.length);
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/* 219 */     if (!Thread.currentThread().getName().equals("DiscoveryAdvertisement daemon")) {
/* 220 */       throw new RuntimeException("No right to call this method");
/*     */     }
/* 222 */     this.inService = true;
/* 223 */     while (this.inService) {
/*     */       try {
/* 225 */         listenBroadCast();
/*     */       }
/*     */       catch (SocketTimeoutException ex) {}catch (IOException ioEx)
/*     */       {
/* 229 */         log.error("IO Exception during UPNP DiscoveryAdvertisement messages listening thread", ioEx);
/*     */       } catch (Exception ex) {
/* 231 */         log.error("Fatal Error during UPNP DiscoveryAdvertisement messages listening thread, thread will exit", ex);
/* 232 */         this.inService = false;
/* 233 */         this.aliveRegistered.clear();
/* 234 */         this.byeByeRegistered.clear();
/* 235 */         this.USNPerIP.clear();
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 240 */       this.skt.leaveGroup(InetAddress.getByName("239.255.255.250"));
/* 241 */       this.skt.close();
/*     */     }
/*     */     catch (Exception ex) {}
/*     */   }
/*     */   
/*     */   private void listenBroadCast()
/*     */     throws IOException
/*     */   {
/* 249 */     this.skt.receive(this.input);
/* 250 */     InetAddress from = this.input.getAddress();
/* 251 */     String received = new String(this.input.getData(), this.input.getOffset(), this.input.getLength());
/* 252 */     HttpResponse msg = null;
/*     */     try {
/* 254 */       msg = new HttpResponse(received);
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 257 */       if (log.isDebugEnabled()) log.debug("Skipping uncompliant HTTP message " + received);
/* 258 */       return;
/*     */     }
/* 260 */     String header = msg.getHeader();
/* 261 */     if ((header != null) && (header.startsWith("NOTIFY"))) {
/* 262 */       if (log.isDebugEnabled()) log.debug(received);
/* 263 */       String ntsField = msg.getHTTPHeaderField("nts");
/* 264 */       if ((ntsField == null) || (ntsField.trim().length() == 0)) {
/* 265 */         if (log.isDebugEnabled()) log.debug("Skipping SSDP message, missing HTTP header 'ntsField' field");
/* 266 */         return;
/*     */       }
/* 268 */       if (ntsField.equals("ssdp:alive")) {
/* 269 */         String deviceDescrLoc = msg.getHTTPHeaderField("location");
/* 270 */         if ((deviceDescrLoc == null) || (deviceDescrLoc.trim().length() == 0)) {
/* 271 */           if (log.isDebugEnabled()) log.debug("Skipping SSDP message, missing HTTP header 'location' field");
/* 272 */           return;
/*     */         }
/* 274 */         URL loc = new URL(deviceDescrLoc);
/* 275 */         if (MATCH_IP) {
/* 276 */           InetAddress locHost = InetAddress.getByName(loc.getHost());
/* 277 */           if (!from.equals(locHost)) {
/* 278 */             log.warn("Discovery message sender IP " + from + " does not match device description IP " + locHost + " skipping message, set the net.sbbi.upnp.ddos.matchip system property" + " to false to avoid this check");
/*     */             
/*     */ 
/*     */ 
/* 282 */             return;
/*     */           }
/*     */         }
/*     */         
/* 286 */         String nt = msg.getHTTPHeaderField("nt");
/* 287 */         if ((nt == null) || (nt.trim().length() == 0)) {
/* 288 */           if (log.isDebugEnabled()) log.debug("Skipping SSDP message, missing HTTP header 'nt' field");
/* 289 */           return;
/*     */         }
/* 291 */         String maxAge = msg.getHTTPFieldElement("Cache-Control", "max-age");
/* 292 */         if ((maxAge == null) || (maxAge.trim().length() == 0)) {
/* 293 */           if (log.isDebugEnabled()) log.debug("Skipping SSDP message, missing HTTP header 'max-age' field");
/* 294 */           return;
/*     */         }
/* 296 */         String usn = msg.getHTTPHeaderField("usn");
/* 297 */         if ((usn == null) || (usn.trim().length() == 0)) {
/* 298 */           if (log.isDebugEnabled()) log.debug("Skipping SSDP message, missing HTTP header 'usn' field");
/* 299 */           return;
/*     */         }
/*     */         
/* 302 */         this.USNPerIP.put(usn, from);
/* 303 */         String udn = usn;
/* 304 */         int index = udn.indexOf("::");
/* 305 */         if (index != -1) udn = udn.substring(0, index);
/* 306 */         Iterator i; synchronized (this.REGISTRATION_PROCESS) {
/* 307 */           Set handlers = (Set)this.aliveRegistered.get("DiscoveryAdvertisement:nt:allevents");
/* 308 */           Iterator i; if (handlers != null) {
/* 309 */             for (i = handlers.iterator(); i.hasNext();) {
/* 310 */               DiscoveryEventHandler eventHandler = (DiscoveryEventHandler)i.next();
/* 311 */               eventHandler.eventSSDPAlive(usn, udn, nt, maxAge, loc);
/*     */             }
/*     */           }
/* 314 */           handlers = (Set)this.aliveRegistered.get(nt);
/* 315 */           if (handlers != null) {
/* 316 */             for (i = handlers.iterator(); i.hasNext();) {
/* 317 */               DiscoveryEventHandler eventHandler = (DiscoveryEventHandler)i.next();
/* 318 */               eventHandler.eventSSDPAlive(usn, udn, nt, maxAge, loc);
/*     */             }
/*     */           }
/*     */         }
/* 322 */       } else if (ntsField.equals("ssdp:byebye")) {
/* 323 */         String usn = msg.getHTTPHeaderField("usn");
/* 324 */         if ((usn == null) || (usn.trim().length() == 0)) {
/* 325 */           if (log.isDebugEnabled()) log.debug("Skipping SSDP message, missing HTTP header 'usn' field");
/* 326 */           return;
/*     */         }
/* 328 */         String nt = msg.getHTTPHeaderField("nt");
/* 329 */         if ((nt == null) || (nt.trim().length() == 0)) {
/* 330 */           if (log.isDebugEnabled()) log.debug("Skipping SSDP message, missing HTTP header 'nt' field");
/* 331 */           return;
/*     */         }
/*     */         
/* 334 */         InetAddress originalAliveSenderIp = (InetAddress)this.USNPerIP.get(usn);
/* 335 */         if (originalAliveSenderIp != null)
/*     */         {
/*     */ 
/*     */ 
/* 339 */           if (!originalAliveSenderIp.equals(from))
/*     */           {
/*     */ 
/* 342 */             return;
/*     */           }
/*     */         }
/*     */         
/* 346 */         String udn = usn;
/* 347 */         int index = udn.indexOf("::");
/* 348 */         if (index != -1) udn = udn.substring(0, index);
/* 349 */         Iterator i; synchronized (this.REGISTRATION_PROCESS) {
/* 350 */           Set handlers = (Set)this.byeByeRegistered.get("DiscoveryAdvertisement:nt:allevents");
/* 351 */           Iterator i; if (handlers != null) {
/* 352 */             for (i = handlers.iterator(); i.hasNext();) {
/* 353 */               DiscoveryEventHandler eventHandler = (DiscoveryEventHandler)i.next();
/* 354 */               eventHandler.eventSSDPByeBye(usn, udn, nt);
/*     */             }
/*     */           }
/* 357 */           handlers = (Set)this.byeByeRegistered.get(nt);
/* 358 */           if (handlers != null) {
/* 359 */             for (i = handlers.iterator(); i.hasNext();) {
/* 360 */               DiscoveryEventHandler eventHandler = (DiscoveryEventHandler)i.next();
/* 361 */               eventHandler.eventSSDPByeBye(usn, udn, nt);
/*     */             }
/*     */           }
/*     */         }
/*     */       } else {
/* 366 */         log.warn("Unvalid NTS field value (" + ntsField + ") received in NOTIFY message :" + received);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/DiscoveryAdvertisement.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */