/*     */ package net.sbbi.upnp.remote;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.net.InetAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.rmi.Remote;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.server.ExportException;
/*     */ import java.rmi.server.RMIClientSocketFactory;
/*     */ import java.rmi.server.RMIServerSocketFactory;
/*     */ import java.rmi.server.RemoteServer;
/*     */ import java.rmi.server.RemoteStub;
/*     */ import java.rmi.server.ServerCloneException;
/*     */ import java.rmi.server.ServerRef;
/*     */ import net.sbbi.upnp.Discovery;
/*     */ import net.sbbi.upnp.devices.UPNPDevice;
/*     */ import net.sbbi.upnp.devices.UPNPRootDevice;
/*     */ import net.sbbi.upnp.messages.ActionMessage;
/*     */ import net.sbbi.upnp.messages.UPNPMessageFactory;
/*     */ import net.sbbi.upnp.services.UPNPService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnicastRemoteObject
/*     */   extends RemoteServer
/*     */ {
/*     */   private static final long serialVersionUID = 4974527148936298034L;
/* 111 */   private static Class[] portParamTypes = { Integer.TYPE };
/*     */   
/*     */ 
/* 114 */   private static Class[] portFactoryParamTypes = { Integer.TYPE, RMIClientSocketFactory.class, RMIServerSocketFactory.class };
/*     */   
/*     */ 
/*     */ 
/* 118 */   private static final Object DISCOVERY_PROCESS = new Object();
/* 119 */   private static final Object ANONYMOUS_PORT_LOOKUP = new Object();
/*     */   
/* 121 */   private UPNPDevice wanConnDevice = null;
/*     */   
/* 123 */   private boolean discoveryProcessCall = false;
/*     */   
/* 125 */   private boolean portOpened = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 130 */   private int port = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 135 */   private RMIClientSocketFactory csf = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 141 */   private RMIServerSocketFactory ssf = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected UnicastRemoteObject()
/*     */     throws RemoteException
/*     */   {
/* 150 */     synchronized (ANONYMOUS_PORT_LOOKUP) {
/*     */       try {
/* 152 */         ServerSocket srv = new ServerSocket(0);
/* 153 */         this.port = srv.getLocalPort();
/* 154 */         srv.close();
/*     */       } catch (Exception ex) {
/* 156 */         throw new RemoteException("Error occured during anonymous port assignation", ex);
/*     */       }
/*     */     }
/* 159 */     openPort();
/* 160 */     exportObject(this, this.port);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected UnicastRemoteObject(int port)
/*     */     throws RemoteException
/*     */   {
/* 172 */     this.port = port;
/* 173 */     openPort();
/* 174 */     exportObject(this, port);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected UnicastRemoteObject(int port, RMIClientSocketFactory csf, RMIServerSocketFactory ssf)
/*     */     throws RemoteException
/*     */   {
/* 189 */     this.port = port;
/* 190 */     this.csf = csf;
/* 191 */     this.ssf = ssf;
/* 192 */     openPort();
/* 193 */     exportObject(this, port, csf, ssf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 202 */     in.defaultReadObject();
/* 203 */     reexport();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/*     */     try
/*     */     {
/* 216 */       UnicastRemoteObject cloned = (UnicastRemoteObject)super.clone();
/* 217 */       cloned.reexport();
/*     */       
/* 219 */       return cloned;
/*     */     } catch (RemoteException e) {
/* 221 */       throw new ServerCloneException("Clone failed", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void reexport()
/*     */     throws RemoteException
/*     */   {
/* 231 */     closePort();
/* 232 */     if ((this.csf == null) && (this.ssf == null)) {
/* 233 */       exportObject(this, this.port);
/*     */     } else {
/* 235 */       exportObject(this, this.port, this.csf, this.ssf);
/*     */     }
/* 237 */     openPort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RemoteStub exportObject(Remote obj)
/*     */     throws RemoteException
/*     */   {
/* 248 */     return (RemoteStub)exportObject(obj, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Remote exportObject(Remote obj, int port)
/*     */     throws RemoteException
/*     */   {
/* 262 */     Object[] args = { new Integer(port) };
/*     */     
/* 264 */     return exportObject(obj, "UnicastServerRef", portParamTypes, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Remote exportObject(Remote obj, int port, RMIClientSocketFactory csf, RMIServerSocketFactory ssf)
/*     */     throws RemoteException
/*     */   {
/* 283 */     Object[] args = { new Integer(port), csf, ssf };
/*     */     
/* 285 */     return exportObject(obj, "UnicastServerRef2", portFactoryParamTypes, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Remote exportObject(Remote obj, String refType, Class[] params, Object[] args)
/*     */     throws RemoteException
/*     */   {
/* 298 */     String refClassName = "sun.rmi.server." + refType;
/*     */     
/*     */     try
/*     */     {
/* 302 */       refClass = Class.forName(refClassName);
/*     */     } catch (ClassNotFoundException e) { Class refClass;
/* 304 */       throw new ExportException("No class found for server ref type: " + refType);
/*     */     }
/*     */     
/*     */     Class refClass;
/* 308 */     if (!ServerRef.class.isAssignableFrom(refClass)) {
/* 309 */       throw new ExportException("Server ref class not instance of " + ServerRef.class.getName() + ": " + refClass.getName());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 318 */       Constructor cons = refClass.getConstructor(params);
/* 319 */       ServerRef serverRef = (ServerRef)cons.newInstance(args);
/*     */       
/*     */ 
/* 322 */       if ((obj instanceof UnicastRemoteObject))
/* 323 */         ((UnicastRemoteObject)obj).ref = serverRef;
/*     */     } catch (Exception e) {
/* 325 */       throw new ExportException("Exception creating instance of server ref class: " + refClass.getName(), e);
/*     */     }
/*     */     
/*     */     ServerRef serverRef;
/* 329 */     return serverRef.exportObject(obj, null);
/*     */   }
/*     */   
/*     */   private void openPort()
/*     */     throws RemoteException
/*     */   {
/* 335 */     discoverDevice();
/*     */     
/* 337 */     if ((this.wanConnDevice != null) && (!this.portOpened))
/*     */     {
/* 339 */       UPNPService wanIPSrv = this.wanConnDevice.getService("urn:schemas-upnp-org:service:WANIPConnection:1");
/* 340 */       String failStr = System.getProperty("net.sbbi.upnp.remote.failWhenNoDeviceFound");
/* 341 */       boolean fail = false;
/* 342 */       if ((failStr != null) && (failStr.equalsIgnoreCase("true"))) fail = true;
/* 343 */       if ((wanIPSrv == null) && (fail))
/* 344 */         throw new RemoteException("Device does not implement the urn:schemas-upnp-org:service:WANIPConnection:1 service");
/* 345 */       if ((wanIPSrv == null) && (!fail)) {
/* 346 */         return;
/*     */       }
/*     */       
/* 349 */       failStr = System.getProperty("net.sbbi.upnp.remote.failWhenDeviceCommEx");
/* 350 */       fail = false;
/* 351 */       if ((failStr != null) && (failStr.equalsIgnoreCase("true"))) { fail = true;
/*     */       }
/* 353 */       UPNPMessageFactory msgFactory = UPNPMessageFactory.getNewInstance(wanIPSrv);
/* 354 */       ActionMessage msg = msgFactory.getMessage("AddPortMapping");
/*     */       
/*     */       try
/*     */       {
/* 358 */         String localIP = InetAddress.getLocalHost().getHostAddress();
/*     */         
/* 360 */         msg.setInputParameter("NewRemoteHost", "").setInputParameter("NewExternalPort", this.port).setInputParameter("NewProtocol", "TCP").setInputParameter("NewInternalPort", this.port).setInputParameter("NewInternalClient", localIP).setInputParameter("NewEnabled", "1").setInputParameter("NewPortMappingDescription", "Remote Object " + getClass().getName() + " " + hashCode()).setInputParameter("NewLeaseDuration", "0");
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 368 */         msg.service();
/* 369 */         this.portOpened = true;
/*     */         
/* 371 */         UnicastObjectShutdownHook hook = new UnicastObjectShutdownHook(this, null);
/* 372 */         Runtime.getRuntime().addShutdownHook(hook);
/*     */       } catch (Exception ex) {
/* 374 */         if (fail) {
/* 375 */           throw new RemoteException("Error occured during port mapping", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void closePort()
/*     */   {
/* 385 */     if ((this.wanConnDevice != null) && (this.portOpened))
/*     */     {
/* 387 */       UPNPService wanIPSrv = this.wanConnDevice.getService("urn:schemas-upnp-org:service:WANIPConnection:1");
/* 388 */       if (wanIPSrv != null) {
/* 389 */         UPNPMessageFactory msgFactory = UPNPMessageFactory.getNewInstance(wanIPSrv);
/* 390 */         ActionMessage msg = msgFactory.getMessage("DeletePortMapping");
/*     */         try
/*     */         {
/* 393 */           msg.setInputParameter("NewRemoteHost", "").setInputParameter("NewExternalPort", this.port).setInputParameter("NewProtocol", "TCP");
/*     */           
/*     */ 
/* 396 */           msg.service();
/* 397 */           this.portOpened = false;
/*     */         }
/*     */         catch (Exception ex) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private final void discoverDevice()
/*     */     throws RemoteException
/*     */   {
/* 407 */     synchronized (DISCOVERY_PROCESS) {
/* 408 */       if (!this.discoveryProcessCall) {
/* 409 */         this.discoveryProcessCall = true;
/* 410 */         UPNPRootDevice rootIGDDevice = null;
/* 411 */         String failStr = System.getProperty("net.sbbi.upnp.remote.failWhenNoDeviceFound");
/* 412 */         boolean fail = false;
/* 413 */         if ((failStr != null) && (failStr.equalsIgnoreCase("true"))) { fail = true;
/*     */         }
/* 415 */         UPNPRootDevice[] devices = null;
/*     */         try {
/* 417 */           String timeout = System.getProperty("net.sbbi.upnp.remote.discoveryTimeout");
/* 418 */           if (timeout != null) {
/* 419 */             devices = Discovery.discover(Integer.parseInt(timeout), "urn:schemas-upnp-org:device:InternetGatewayDevice:1");
/*     */           } else {
/* 421 */             devices = Discovery.discover("urn:schemas-upnp-org:device:InternetGatewayDevice:1");
/*     */           }
/*     */         } catch (IOException ex) {
/* 424 */           throw new RemoteException("IOException occured during devices discovery", ex);
/*     */         }
/*     */         
/* 427 */         if ((devices == null) && (fail)) throw new IllegalStateException("No UPNP IGD (urn:schemas-upnp-org:device:InternetGatewayDevice:1) available, unable to create object");
/* 428 */         if ((devices != null) && (devices.length > 1)) {
/* 429 */           String deviceUDN = System.getProperty("net.sbbi.upnp.remote.deviceUDN");
/* 430 */           if (deviceUDN == null) {
/* 431 */             String UDNs = "";
/* 432 */             for (int i = 0; i < devices.length; i++) {
/* 433 */               UPNPRootDevice dv = devices[i];
/* 434 */               UDNs = UDNs + dv.getUDN();
/* 435 */               if (i < devices.length) {
/* 436 */                 UDNs = UDNs + ", ";
/*     */               }
/*     */             }
/* 439 */             throw new RemoteException("Found multiple IDG UPNP devices UDN's :" + UDNs + ", " + "please set the net.sbbi.upnp.remote.deviceUDN system " + "property with one of the following identifier to define " + "which UPNP device need to be used with remote objects");
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 445 */           StringBuffer foundUDN = new StringBuffer();
/* 446 */           for (int i = 0; i < devices.length; i++) {
/* 447 */             UPNPRootDevice dv = devices[i];
/* 448 */             if (dv.getUDN().equals(deviceUDN)) {
/* 449 */               rootIGDDevice = dv;
/* 450 */               break;
/*     */             }
/* 452 */             foundUDN.append(dv.getUDN());
/* 453 */             if (i < devices.length) foundUDN.append(", ");
/*     */           }
/* 455 */           if (rootIGDDevice == null) throw new RemoteException("No UPNP device matching UDN :" + deviceUDN + ", found UDN(s) are :" + foundUDN);
/*     */         }
/* 457 */         else if (devices != null) {
/* 458 */           rootIGDDevice = devices[0];
/*     */         }
/*     */         
/* 461 */         if (rootIGDDevice != null) {
/* 462 */           this.wanConnDevice = rootIGDDevice.getChildDevice("urn:schemas-upnp-org:device:WANConnectionDevice:1");
/* 463 */           if ((this.wanConnDevice == null) && (fail)) throw new RemoteException("Your UPNP device does not implements urn:schemas-upnp-org:device:WANConnectionDevice:1 required specs for NAT transversal");
/*     */         }
/*     */       } } }
/*     */   
/*     */   private class UnicastObjectShutdownHook extends Thread { private UnicastRemoteObject object;
/*     */     
/* 469 */     UnicastObjectShutdownHook(UnicastRemoteObject x1, UnicastRemoteObject.1 x2) { this(x1); }
/*     */     
/*     */ 
/*     */     private UnicastObjectShutdownHook(UnicastRemoteObject object)
/*     */     {
/* 474 */       this.object = object;
/*     */     }
/*     */     
/*     */     public void run() {
/* 478 */       this.object.closePort();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/remote/UnicastRemoteObject.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */