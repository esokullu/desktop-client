/*     */ package net.sbbi.upnp;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpResponse
/*     */ {
/*     */   private String header;
/*     */   private Map fields;
/*     */   private String body;
/*     */   
/*     */   protected HttpResponse(String rawHttpResponse)
/*     */     throws IllegalArgumentException
/*     */   {
/*  71 */     if ((rawHttpResponse == null) || (rawHttpResponse.trim().length() == 0)) {
/*  72 */       throw new IllegalArgumentException("Empty HTTP response message");
/*     */     }
/*  74 */     boolean bodyParsing = false;
/*  75 */     StringBuffer bodyParsed = new StringBuffer();
/*  76 */     this.fields = new HashMap();
/*  77 */     String[] lines = rawHttpResponse.split("\\r\\n");
/*  78 */     this.header = lines[0].trim();
/*     */     
/*  80 */     for (int i = 1; i < lines.length; i++)
/*     */     {
/*  82 */       String line = lines[i];
/*  83 */       if (line.length() == 0)
/*     */       {
/*  85 */         bodyParsing = true;
/*  86 */       } else if (bodyParsing)
/*     */       {
/*  88 */         bodyParsed.append(line).append("\r\n");
/*     */ 
/*     */       }
/*  91 */       else if (line.length() > 0) {
/*  92 */         int delim = line.indexOf(':');
/*  93 */         if (delim != -1) {
/*  94 */           String key = line.substring(0, delim).toUpperCase();
/*  95 */           String value = line.substring(delim + 1).trim();
/*  96 */           this.fields.put(key, value);
/*     */         } else {
/*  98 */           throw new IllegalArgumentException("Invalid HTTP message header :" + line);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 103 */     if (bodyParsing) {
/* 104 */       this.body = bodyParsed.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getHeader() {
/* 109 */     return this.header;
/*     */   }
/*     */   
/*     */   public String getBody() {
/* 113 */     return this.body;
/*     */   }
/*     */   
/*     */   public String getHTTPFieldElement(String fieldName, String elementName) throws IllegalArgumentException {
/* 117 */     String fieldNameValue = getHTTPHeaderField(fieldName);
/* 118 */     if (fieldName != null)
/*     */     {
/* 120 */       StringTokenizer tokenizer = new StringTokenizer(fieldNameValue.trim(), ",");
/* 121 */       while (tokenizer.countTokens() > 0) {
/* 122 */         String nextToken = tokenizer.nextToken().trim();
/* 123 */         if (nextToken.startsWith(elementName)) {
/* 124 */           int index = nextToken.indexOf("=");
/* 125 */           if (index != -1) {
/* 126 */             return nextToken.substring(index + 1).trim();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 131 */     throw new IllegalArgumentException("HTTP element field " + elementName + " is not present");
/*     */   }
/*     */   
/*     */   public String getHTTPHeaderField(String fieldName) throws IllegalArgumentException {
/* 135 */     String field = (String)this.fields.get(fieldName.toUpperCase());
/* 136 */     if (field == null) {
/* 137 */       throw new IllegalArgumentException("HTTP field " + fieldName + " is not present");
/*     */     }
/* 139 */     return field;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/sbbi-upnplib-1.0.4.jar!/net/sbbi/upnp/HttpResponse.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */