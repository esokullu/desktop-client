package net.sf.wraplog;

public class NoneLogger
  extends AbstractLogger
{
  protected void reallyLog(int logLevel, String message, Throwable error) {}
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/net/sf/wraplog/NoneLogger.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */