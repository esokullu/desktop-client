/*    */ package net.sf.wraplog;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.text.DateFormat;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemLogger
/*    */   extends AbstractLogger
/*    */ {
/* 49 */   private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
/*    */   
/*    */ 
/*    */   protected void reallyLog(int logLevel, String message, Throwable error)
/*    */   {
/*    */     PrintStream stream;
/*    */     PrintStream stream;
/* 56 */     if (logLevel < 2) {
/* 57 */       stream = System.out;
/*    */     }
/*    */     else {
/* 60 */       stream = System.err;
/*    */     }
/* 62 */     if (message == null) {
/* 63 */       throw new NullPointerException("message must not be null");
/*    */     }
/* 65 */     if (stream == null) {
/* 66 */       throw new NullPointerException("stream must not be null");
/*    */     }
/* 68 */     String threadName = Thread.currentThread().getName();
/* 69 */     String dateAndTime = this.format.format(new Date());
/* 70 */     stream.println(dateAndTime + " [" + threadName + "] " + getLevelText(logLevel) + " " + message);
/*    */     
/* 72 */     if (error != null) {
/* 73 */       error.printStackTrace(stream);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   protected String getLevelText(int logLevel)
/*    */   {
/*    */     String result;
/*    */     
/* 82 */     if (logLevel == 0) {
/* 83 */       result = "DEBUG";
/*    */     } else { String result;
/* 85 */       if (logLevel == 1) {
/* 86 */         result = "INFO ";
/*    */       } else { String result;
/* 88 */         if (logLevel == 2) {
/* 89 */           result = "WARN ";
/*    */         } else { String result;
/* 91 */           if (logLevel == 3) {
/* 92 */             result = "ERROR";
/*    */           }
/*    */           else
/* 95 */             throw new IllegalArgumentException("logLevel must be one of those defined in net.sf.warplog.Level, but is " + logLevel);
/*    */         }
/*    */       } }
/*    */     String result;
/* 99 */     return result;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/net/sf/wraplog/SystemLogger.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */