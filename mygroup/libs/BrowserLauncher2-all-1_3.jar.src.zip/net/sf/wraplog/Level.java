package net.sf.wraplog;

public class Level
{
  public static final int DEBUG = 0;
  public static final int ERROR = 3;
  public static final int INFO = 1;
  public static final int WARN = 2;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/net/sf/wraplog/Level.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */