/*     */ package net.sf.wraplog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractLogger
/*     */ {
/*  41 */   private int level = 0;
/*     */   private int loggedMessageCount;
/*     */   
/*     */   protected void checkLevel(int logLevel, String name) {
/*     */     String actualName;
/*     */     String actualName;
/*  47 */     if (name == null) {
/*  48 */       actualName = "level";
/*     */     }
/*     */     else {
/*  51 */       actualName = name;
/*     */     }
/*  53 */     if ((logLevel < 0) || (logLevel > 3)) {
/*  54 */       throw new IllegalArgumentException(actualName + " must be one of: Level.DEBUG, Level.INFO, Level.WARN, Level.ERROR");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void debug(String message)
/*     */   {
/*  61 */     debug(message, null);
/*     */   }
/*     */   
/*     */   public void debug(String message, Throwable error) {
/*  65 */     log(0, message, error);
/*     */   }
/*     */   
/*     */   public void error(String message) {
/*  69 */     error(message, null);
/*     */   }
/*     */   
/*     */   public void error(String message, Throwable error) {
/*  73 */     log(3, message, error);
/*     */   }
/*     */   
/*     */   public int getLevel() {
/*  77 */     return this.level;
/*     */   }
/*     */   
/*     */   public int getLoggedMessageCount()
/*     */   {
/*  82 */     return this.loggedMessageCount;
/*     */   }
/*     */   
/*     */   public void info(String message) {
/*  86 */     info(message, null);
/*     */   }
/*     */   
/*     */   public void info(String message, Throwable error) {
/*  90 */     log(1, message, error);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(int logLevel) {
/*  94 */     checkLevel(this.level, null);
/*  95 */     return logLevel >= this.level;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void reallyLog(int paramInt, String paramString, Throwable paramThrowable)
/*     */     throws Exception;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void log(int logLevel, String message)
/*     */   {
/* 114 */     log(logLevel, message, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void log(int logLevel, String message, Throwable error)
/*     */   {
/* 122 */     if (isEnabled(logLevel)) {
/*     */       try {
/* 124 */         reallyLog(logLevel, message, error);
/* 125 */         this.loggedMessageCount += 1;
/*     */       }
/*     */       catch (Exception error2) {
/* 128 */         throw new LoggingException("cannot log message: " + message, error2);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setLevel(int newLevel)
/*     */   {
/* 135 */     if ((this.level >= 0) || (this.level <= 3)) {
/* 136 */       this.level = newLevel;
/*     */     }
/*     */     else {
/* 139 */       throw new IllegalArgumentException("newLevel must be one of: Level.DEBUG, Level.INFO, Level.WARN, Level.ERROR");
/*     */     }
/*     */   }
/*     */   
/*     */   public void warn(String message)
/*     */   {
/* 145 */     warn(message, null);
/*     */   }
/*     */   
/*     */   public boolean isDebugEnabled() {
/* 149 */     return isEnabled(0);
/*     */   }
/*     */   
/*     */   public boolean isInfoEnabled() {
/* 153 */     return isEnabled(1);
/*     */   }
/*     */   
/*     */   public boolean isWarnEnabled() {
/* 157 */     return isEnabled(2);
/*     */   }
/*     */   
/*     */   public boolean isErrorEnabled() {
/* 161 */     return isEnabled(3);
/*     */   }
/*     */   
/*     */   public void warn(String message, Throwable error) {
/* 165 */     log(2, message, error);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/net/sf/wraplog/AbstractLogger.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */