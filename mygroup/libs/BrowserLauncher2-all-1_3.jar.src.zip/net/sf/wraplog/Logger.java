/*    */ package net.sf.wraplog;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ /**
/*    */  * @deprecated
/*    */  */
/*    */ public class Logger
/*    */   extends SystemLogger
/*    */ {
/*    */   private static Logger logger;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static synchronized Logger getLogger()
/*    */   {
/* 44 */     if (logger == null) {
/* 45 */       logger = new Logger();
/*    */     }
/* 47 */     return logger;
/*    */   }
/*    */   
/*    */ 
/*    */   /**
/*    */    * @deprecated
/*    */    */
/*    */   public static Logger getLogger(String name)
/*    */   {
/* 56 */     return getLogger();
/*    */   }
/*    */   
/*    */ 
/*    */   /**
/*    */    * @deprecated
/*    */    */
/*    */   public static Logger getLogger(Class clazz)
/*    */   {
/* 65 */     if (clazz == null) {
/* 66 */       throw new NullPointerException("parameter clazz must not be null");
/*    */     }
/* 68 */     return getLogger(clazz.getName());
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/net/sf/wraplog/Logger.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */