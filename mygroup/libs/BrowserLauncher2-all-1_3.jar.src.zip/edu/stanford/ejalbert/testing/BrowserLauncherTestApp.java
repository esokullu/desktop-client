/*     */ package edu.stanford.ejalbert.testing;
/*     */ 
/*     */ import edu.stanford.ejalbert.BrowserLauncher;
/*     */ import edu.stanford.ejalbert.browserprefui.BrowserPrefAction;
/*     */ import edu.stanford.ejalbert.exceptionhandler.BrowserLauncherErrorHandler;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Frame;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.ComboBoxModel;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRootPane;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import net.sf.wraplog.AbstractLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BrowserLauncherTestApp
/*     */   extends JFrame
/*     */ {
/*     */   private static final String debugResources = "edu.stanford.ejalbert.resources.Debugging";
/*     */   private TestAppLogger logger;
/*  69 */   private JComboBox browserBox = new JComboBox();
/*  70 */   private JLabel loggingLevelTxtFld = new JLabel();
/*  71 */   private JTextField urlTextField = new JTextField();
/*     */   private BrowserLauncher launcher;
/*  73 */   private JTextArea debugTextArea = new JTextArea();
/*  74 */   private JTextField browserListField = new JTextField();
/*     */   private ResourceBundle bundle;
/*  76 */   private JCheckBox windowPolicyCBox = new JCheckBox();
/*     */   
/*     */   public BrowserLauncherTestApp()
/*     */   {
/*     */     try {
/*  81 */       this.bundle = ResourceBundle.getBundle("edu.stanford.ejalbert.resources.Debugging");
/*  82 */       this.logger = initDebugLogging();
/*  83 */       this.loggingLevelTxtFld.setText(this.logger.getLevelText());
/*  84 */       super.setTitle(this.bundle.getString("label.app.title"));
/*  85 */       populateDebugInfo(this.bundle, this.debugTextArea);
/*  86 */       this.launcher = new BrowserLauncher(this.logger, new TestAppErrorHandler(this.debugTextArea));
/*     */       
/*     */ 
/*  89 */       ComboBoxModel cbModel = new DefaultComboBoxModel(this.launcher.getBrowserList().toArray());
/*     */       
/*  91 */       this.browserBox.setModel(cbModel);
/*  92 */       this.windowPolicyCBox.setSelected(this.launcher.getNewWindowPolicy());
/*  93 */       jbInit();
/*     */     }
/*     */     catch (Exception ex) {
/*  96 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   private TestAppLogger initDebugLogging() {
/* 101 */     String[] levelLabels = this.bundle.getString("logging.level.labels").split(";");
/*     */     
/* 103 */     this.debugTextArea.setEditable(false);
/* 104 */     this.debugTextArea.setLineWrap(true);
/* 105 */     this.debugTextArea.setWrapStyleWord(true);
/* 106 */     this.debugTextArea.setText("");
/* 107 */     return new TestAppLogger(this.debugTextArea, levelLabels, this.bundle.getString("logging.dateformat"));
/*     */   }
/*     */   
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 113 */     BrowserLauncherTestApp app = new BrowserLauncherTestApp();
/* 114 */     app.pack();
/* 115 */     app.setVisible(true);
/*     */   }
/*     */   
/*     */   private void windowPolicyItemStateChange(ItemEvent e) {
/* 119 */     this.launcher.setNewWindowPolicy(e.getStateChange() == 1);
/*     */   }
/*     */   
/*     */   private void populateDebugInfo(ResourceBundle bundle, JTextArea debugTextArea)
/*     */   {
/* 124 */     StringWriter stringWriter = new StringWriter();
/* 125 */     PrintWriter printWriter = new PrintWriter(stringWriter, true);
/*     */     
/* 127 */     printWriter.println(bundle.getString("debug.mssg"));
/* 128 */     printWriter.println();
/*     */     
/* 130 */     StringTokenizer tokenizer = new StringTokenizer(bundle.getString("debug.propnames"), ";", false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */     while (tokenizer.hasMoreTokens()) {
/* 137 */       String token = tokenizer.nextToken();
/* 138 */       int pipeSymbol = token.indexOf('|');
/* 139 */       String display = token.substring(0, pipeSymbol);
/* 140 */       String property = token.substring(pipeSymbol + 1);
/* 141 */       printWriter.print(display);
/* 142 */       printWriter.println(System.getProperty(property));
/*     */     }
/* 144 */     printWriter.close();
/* 145 */     debugTextArea.append(stringWriter.toString());
/*     */   }
/*     */   
/*     */   private void jbInit()
/*     */     throws Exception
/*     */   {
/* 151 */     BrowserPrefAction browserPrefAction = new BrowserPrefAction(this.bundle.getString("bttn.set.preference"), this.launcher, this);
/*     */     
/*     */ 
/*     */ 
/* 155 */     JButton prefBrowserBttn = new JButton(browserPrefAction);
/*     */     
/* 157 */     JButton browseButton = new JButton(this.bundle.getString("bttn.browse"));
/* 158 */     browseButton.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/* 160 */         BrowserLauncherTestApp.this.browseButton_actionPerformed(e);
/*     */       }
/* 162 */     });
/* 163 */     JLabel enterUrlLabel = new JLabel(this.bundle.getString("label.url"));
/* 164 */     this.urlTextField.setText(this.bundle.getString("url.default"));
/* 165 */     this.urlTextField.setColumns(25);
/* 166 */     JPanel urlPanel = new JPanel(new BorderLayout());
/* 167 */     urlPanel.add(enterUrlLabel, "Before");
/* 168 */     urlPanel.add(this.urlTextField, "Center");
/* 169 */     urlPanel.add(browseButton, "After");
/*     */     
/* 171 */     JScrollPane debugTextScrollPane = new JScrollPane(this.debugTextArea);
/*     */     
/*     */ 
/* 174 */     JLabel debugLevelLabel = new JLabel(this.bundle.getString("label.logging.level"));
/*     */     
/* 176 */     JButton loggingLevelBttn = new JButton(this.bundle.getString("bttn.set.logging"));
/*     */     
/* 178 */     loggingLevelBttn.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/* 180 */         BrowserLauncherTestApp.this.loggingLevelBttn_actionPerformed(e);
/*     */       }
/* 182 */     });
/* 183 */     JButton copyButton = new JButton(this.bundle.getString("bttn.copy"));
/* 184 */     copyButton.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/* 186 */         BrowserLauncherTestApp.this.copyButton_actionPerformed(e);
/*     */       }
/* 188 */     });
/* 189 */     JPanel debugTextBttnPanel = new JPanel();
/* 190 */     BoxLayout bttnBoxLayout = new BoxLayout(debugTextBttnPanel, 0);
/*     */     
/*     */ 
/* 193 */     debugTextBttnPanel.setLayout(bttnBoxLayout);
/* 194 */     debugTextBttnPanel.add(Box.createHorizontalStrut(2));
/* 195 */     debugTextBttnPanel.add(this.browserBox);
/* 196 */     debugTextBttnPanel.add(Box.createHorizontalStrut(2));
/* 197 */     debugTextBttnPanel.add(debugLevelLabel);
/* 198 */     debugTextBttnPanel.add(Box.createHorizontalStrut(3));
/* 199 */     debugTextBttnPanel.add(this.loggingLevelTxtFld);
/* 200 */     debugTextBttnPanel.add(Box.createHorizontalStrut(5));
/* 201 */     debugTextBttnPanel.add(Box.createHorizontalGlue());
/* 202 */     debugTextBttnPanel.add(loggingLevelBttn);
/* 203 */     debugTextBttnPanel.add(Box.createHorizontalStrut(3));
/* 204 */     debugTextBttnPanel.add(copyButton);
/* 205 */     debugTextBttnPanel.add(Box.createHorizontalStrut(2));
/*     */     
/* 207 */     this.windowPolicyCBox.addItemListener(new ItemListener() {
/*     */       public void itemStateChanged(ItemEvent e) {
/* 209 */         BrowserLauncherTestApp.this.windowPolicyItemStateChange(e);
/*     */       }
/* 211 */     });
/* 212 */     this.windowPolicyCBox.setText(this.bundle.getString("label.window.policy"));
/* 213 */     JLabel browserListLabel = new JLabel(this.bundle.getString("label.browser.list"));
/*     */     
/* 215 */     JPanel browserListPanel = new JPanel();
/* 216 */     BoxLayout browserListBoxLayout = new BoxLayout(browserListPanel, 0);
/*     */     
/*     */ 
/* 219 */     browserListPanel.setLayout(browserListBoxLayout);
/* 220 */     browserListPanel.add(browserListLabel);
/* 221 */     browserListPanel.add(Box.createHorizontalStrut(2));
/* 222 */     browserListPanel.add(this.browserListField);
/* 223 */     browserListPanel.add(Box.createHorizontalStrut(2));
/* 224 */     browserListPanel.add(this.windowPolicyCBox);
/* 225 */     browserListPanel.add(Box.createHorizontalStrut(2));
/* 226 */     browserListPanel.add(prefBrowserBttn);
/*     */     
/* 228 */     JPanel configPanel = new JPanel(new GridLayout(2, 1, 0, 2));
/* 229 */     configPanel.add(browserListPanel);
/* 230 */     configPanel.add(debugTextBttnPanel);
/*     */     
/* 232 */     JPanel mainPanel = new JPanel(new BorderLayout());
/* 233 */     mainPanel.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 3));
/* 234 */     mainPanel.add(debugTextScrollPane, "Center");
/*     */     
/* 236 */     mainPanel.add(urlPanel, "North");
/*     */     
/* 238 */     mainPanel.add(configPanel, "South");
/*     */     
/*     */ 
/* 241 */     getContentPane().add(mainPanel);
/* 242 */     getRootPane().setDefaultButton(browseButton);
/* 243 */     setDefaultCloseOperation(3);
/*     */   }
/*     */   
/*     */   private static void updateDebugTextArea(Exception exception, JTextArea debugTextArea)
/*     */   {
/* 248 */     StringWriter stringWriter = new StringWriter();
/* 249 */     PrintWriter printWriter = new PrintWriter(stringWriter, true);
/* 250 */     printWriter.println();
/* 251 */     exception.printStackTrace(printWriter);
/* 252 */     printWriter.println();
/* 253 */     printWriter.close();
/* 254 */     debugTextArea.append(stringWriter.toString());
/*     */   }
/*     */   
/*     */   private void browseButton_actionPerformed(ActionEvent e) {
/* 258 */     if (this.logger.isInfoEnabled()) {
/* 259 */       this.logger.info("browse button clicked");
/*     */     }
/*     */     try {
/* 262 */       String urlString = this.urlTextField.getText();
/* 263 */       if ((urlString == null) || (urlString.trim().length() == 0)) {
/* 264 */         throw new MalformedURLException("You must specify a url.");
/*     */       }
/* 266 */       new URL(urlString);
/* 267 */       BrowserLauncherErrorHandler errorHandler = new TestAppErrorHandler(this.debugTextArea);
/*     */       
/*     */ 
/* 270 */       String browserItems = this.browserListField.getText();
/* 271 */       if ((browserItems != null) && (browserItems.length() > 0)) {
/* 272 */         this.logger.debug("using browser list");
/* 273 */         String[] browserArray = browserItems.split("[ ]+");
/* 274 */         List browserList = Arrays.asList(browserArray);
/* 275 */         this.logger.debug(browserList.toString());
/* 276 */         this.launcher.openURLinBrowser(browserList, urlString);
/*     */       }
/*     */       else
/*     */       {
/* 280 */         String targetBrowser = this.browserBox.getSelectedItem().toString();
/* 281 */         this.logger.debug(targetBrowser);
/* 282 */         this.launcher.openURLinBrowser(targetBrowser, urlString);
/*     */       }
/*     */       
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 288 */       updateDebugTextArea(ex, this.debugTextArea);
/*     */       
/* 290 */       JOptionPane.showMessageDialog(this, ex.getMessage(), "Error Message", 0);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void copyButton_actionPerformed(ActionEvent e)
/*     */   {
/* 298 */     if (this.logger.isInfoEnabled()) {
/* 299 */       this.logger.info("copy button clicked");
/*     */     }
/* 301 */     this.debugTextArea.selectAll();
/* 302 */     this.debugTextArea.copy();
/* 303 */     this.debugTextArea.select(0, 0);
/*     */   }
/*     */   
/*     */   private void loggingLevelBttn_actionPerformed(ActionEvent e) {
/* 307 */     String[] levels = this.logger.getLevelOptions();
/* 308 */     int levelIndex = this.logger.getLevel();
/* 309 */     String level = (String)JOptionPane.showInputDialog(this, this.bundle.getString("logging.level.select.message"), this.bundle.getString("logging.level.select.title"), 3, null, levels, levels[levelIndex]);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 317 */     if ((level != null) && (level.length() > 0)) {
/* 318 */       levelIndex = -1;
/* 319 */       int idx = 0;int max = levels.length;
/* 320 */       for (; (idx < max) && (levelIndex == -1); idx++) {
/* 321 */         if (level.equals(levels[idx])) {
/* 322 */           levelIndex = idx;
/*     */         }
/*     */       }
/*     */       
/* 326 */       this.logger.setLevel(levelIndex);
/* 327 */       this.loggingLevelTxtFld.setText(this.logger.getLevelText());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class TestAppErrorHandler implements BrowserLauncherErrorHandler
/*     */   {
/*     */     private JTextArea debugTextArea;
/*     */     
/*     */     TestAppErrorHandler(JTextArea debugTextArea) {
/* 336 */       this.debugTextArea = debugTextArea;
/*     */     }
/*     */     
/*     */     public void handleException(Exception ex)
/*     */     {
/* 341 */       BrowserLauncherTestApp.updateDebugTextArea(ex, this.debugTextArea);
/*     */       
/* 343 */       JOptionPane.showMessageDialog(JOptionPane.getRootFrame(), ex.getMessage(), "Error Message", 0);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/testing/BrowserLauncherTestApp.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */