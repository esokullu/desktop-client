/*     */ package edu.stanford.ejalbert.testing;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.wraplog.AbstractLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TestAppLogger
/*     */   extends AbstractLogger
/*     */ {
/*     */   private JTextArea debugTextArea;
/*     */   private String[] levelText;
/*     */   private SimpleDateFormat format;
/*     */   
/*     */   public TestAppLogger(JTextArea debugTextArea, String[] levelLabels, String dateFormat)
/*     */   {
/*  48 */     this.debugTextArea = debugTextArea;
/*  49 */     this.levelText = levelLabels;
/*  50 */     this.format = new SimpleDateFormat(dateFormat);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void reallyLog(int logLevel, String message, Throwable error)
/*     */     throws Exception
/*     */   {
/*  69 */     if (message == null) {
/*  70 */       message = "null";
/*     */     }
/*  72 */     StringWriter stringWriter = new StringWriter();
/*  73 */     PrintWriter printWriter = new PrintWriter(stringWriter, true);
/*  74 */     String threadName = Thread.currentThread().getName();
/*  75 */     String dateAndTime = this.format.format(new Date());
/*  76 */     printWriter.println(dateAndTime + " [" + threadName + "] " + getLevelText(logLevel) + " " + message);
/*     */     
/*  78 */     if (error != null) {
/*  79 */       error.printStackTrace(printWriter);
/*     */     }
/*  81 */     printWriter.println();
/*  82 */     printWriter.close();
/*  83 */     this.debugTextArea.append(stringWriter.toString());
/*     */   }
/*     */   
/*     */   public String getLevelText() {
/*  87 */     return getLevelText(getLevel());
/*     */   }
/*     */   
/*     */   public String[] getLevelOptions() {
/*  91 */     return this.levelText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String getLevelText(int logLevel)
/*     */   {
/*  98 */     if ((logLevel < 0) || (logLevel > 3)) {
/*  99 */       throw new IllegalArgumentException("logLevel must be one of those defined in net.sf.warplog.Level, but is " + Integer.toString(logLevel));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 104 */     return this.levelText[logLevel];
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/testing/TestAppLogger.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */