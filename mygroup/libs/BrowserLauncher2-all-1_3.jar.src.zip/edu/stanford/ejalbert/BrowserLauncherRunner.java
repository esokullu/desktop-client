/*     */ package edu.stanford.ejalbert;
/*     */ 
/*     */ import edu.stanford.ejalbert.exceptionhandler.BrowserLauncherErrorHandler;
/*     */ import edu.stanford.ejalbert.launching.IBrowserLaunching;
/*     */ import java.util.List;
/*     */ import net.sf.wraplog.AbstractLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BrowserLauncherRunner
/*     */   implements Runnable
/*     */ {
/*     */   private final List targetBrowsers;
/*     */   private final String targetBrowser;
/*     */   private final String url;
/*     */   private final BrowserLauncherErrorHandler errorHandler;
/*     */   private final IBrowserLaunching launcher;
/*     */   private final AbstractLogger logger;
/*     */   
/*     */   BrowserLauncherRunner(IBrowserLaunching launcher, String url, AbstractLogger logger, BrowserLauncherErrorHandler errorHandler)
/*     */   {
/*  58 */     this(launcher, null, null, url, logger, errorHandler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   BrowserLauncherRunner(IBrowserLaunching launcher, String browserName, String url, AbstractLogger logger, BrowserLauncherErrorHandler errorHandler)
/*     */   {
/*  66 */     this(launcher, browserName, null, url, logger, errorHandler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   BrowserLauncherRunner(IBrowserLaunching launcher, List browserList, String url, AbstractLogger logger, BrowserLauncherErrorHandler errorHandler)
/*     */   {
/*  74 */     this(launcher, null, browserList, url, logger, errorHandler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private BrowserLauncherRunner(IBrowserLaunching launcher, String browserName, List browserList, String url, AbstractLogger logger, BrowserLauncherErrorHandler errorHandler)
/*     */   {
/*  93 */     if (launcher == null) {
/*  94 */       throw new IllegalArgumentException("launcher cannot be null.");
/*     */     }
/*  96 */     if (url == null) {
/*  97 */       throw new IllegalArgumentException("url cannot be null.");
/*     */     }
/*  99 */     if (errorHandler == null) {
/* 100 */       throw new IllegalArgumentException("errorHandler cannot be null.");
/*     */     }
/* 102 */     if (logger == null) {
/* 103 */       throw new IllegalArgumentException("logger cannot be null");
/*     */     }
/* 105 */     this.targetBrowsers = browserList;
/* 106 */     this.launcher = launcher;
/* 107 */     this.url = url;
/* 108 */     this.targetBrowser = browserName;
/* 109 */     this.errorHandler = errorHandler;
/* 110 */     this.logger = logger;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/* 127 */       if (this.targetBrowser != null) {
/* 128 */         this.launcher.openUrl(this.targetBrowser, this.url);
/*     */ 
/*     */       }
/* 131 */       else if (this.targetBrowsers != null) {
/* 132 */         this.launcher.openUrl(this.targetBrowsers, this.url);
/*     */       }
/*     */       else
/*     */       {
/* 136 */         this.launcher.openUrl(this.url);
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 140 */       this.logger.error("fatal error opening url", ex);
/* 141 */       this.errorHandler.handleException(ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/BrowserLauncherRunner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */