/*     */ package edu.stanford.ejalbert;
/*     */ 
/*     */ import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;
/*     */ import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;
/*     */ import edu.stanford.ejalbert.exception.UnsupportedOperatingSystemException;
/*     */ import edu.stanford.ejalbert.exceptionhandler.BrowserLauncherDefaultErrorHandler;
/*     */ import edu.stanford.ejalbert.exceptionhandler.BrowserLauncherErrorHandler;
/*     */ import edu.stanford.ejalbert.launching.BrowserLaunchingFactory;
/*     */ import edu.stanford.ejalbert.launching.IBrowserLaunching;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import net.sf.wraplog.AbstractLogger;
/*     */ import net.sf.wraplog.NoneLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BrowserLauncher
/*     */ {
/*     */   public static final String BROWSER_SYSTEM_PROPERTY = "edu.stanford.ejalbert.preferred.browser";
/*     */   public static final String WINDOWS_BROWSER_DISC_POLICY_PROPERTY = "win.browser.disc.policy";
/*     */   public static final String WINDOWS_BROWSER_DISC_POLICY_DISK = "disk";
/*     */   public static final String WINDOWS_BROWSER_DISC_POLICY_REGISTRY = "registry";
/*     */   private final IBrowserLaunching launching;
/*     */   private AbstractLogger logger;
/*     */   private BrowserLauncherErrorHandler errorHandler;
/*     */   
/*     */   public BrowserLauncher()
/*     */     throws BrowserLaunchingInitializingException, UnsupportedOperatingSystemException
/*     */   {
/* 153 */     this(null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BrowserLauncher(AbstractLogger logger)
/*     */     throws BrowserLaunchingInitializingException, UnsupportedOperatingSystemException
/*     */   {
/* 177 */     this(logger, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BrowserLauncher(AbstractLogger logger, BrowserLauncherErrorHandler errorHandler)
/*     */     throws BrowserLaunchingInitializingException, UnsupportedOperatingSystemException
/*     */   {
/* 205 */     if (logger == null) {
/* 206 */       logger = new NoneLogger();
/*     */     }
/* 208 */     this.logger = logger;
/*     */     
/* 210 */     if (errorHandler == null) {
/* 211 */       errorHandler = new BrowserLauncherDefaultErrorHandler();
/*     */     }
/* 213 */     this.errorHandler = errorHandler;
/*     */     
/*     */ 
/* 216 */     this.launching = initBrowserLauncher();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private IBrowserLaunching initBrowserLauncher()
/*     */     throws UnsupportedOperatingSystemException, BrowserLaunchingInitializingException
/*     */   {
/* 234 */     if (this.logger == null) {
/* 235 */       throw new IllegalArgumentException("the logger cannot be null at this point.");
/*     */     }
/*     */     
/* 238 */     IBrowserLaunching launching = BrowserLaunchingFactory.createSystemBrowserLaunching(this.logger);
/*     */     
/* 240 */     launching.initialize();
/* 241 */     return launching;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static void openURL(String urlString)
/*     */     throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException
/*     */   {
/* 257 */     BrowserLauncher launcher = new BrowserLauncher(null);
/* 258 */     launcher.openURLinBrowser(urlString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 269 */     if (args.length == 0) {
/* 270 */       System.err.println("Usage: java -jar BrowserLauncher.jar url_value");
/*     */     } else {
/*     */       try
/*     */       {
/* 274 */         BrowserLauncher launcher = new BrowserLauncher(null);
/* 275 */         launcher.openURLinBrowser(args[0]);
/*     */       }
/*     */       catch (BrowserLaunchingInitializingException ex) {
/* 278 */         ex.printStackTrace();
/*     */ 
/*     */       }
/*     */       catch (UnsupportedOperatingSystemException ex)
/*     */       {
/*     */ 
/* 284 */         ex.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLogger getLogger()
/*     */   {
/* 297 */     return this.logger;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getBrowserList()
/*     */   {
/* 308 */     return this.launching.getBrowserList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openURLinBrowser(String urlString)
/*     */   {
/* 318 */     Runnable runner = new BrowserLauncherRunner(this.launching, urlString, this.logger, this.errorHandler);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 323 */     Thread launcherThread = new Thread(runner);
/* 324 */     launcherThread.start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openURLinBrowser(String browser, String urlString)
/*     */   {
/* 340 */     Runnable runner = new BrowserLauncherRunner(this.launching, browser, urlString, this.logger, this.errorHandler);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 346 */     Thread launcherThread = new Thread(runner);
/* 347 */     launcherThread.start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openURLinBrowser(List browsers, String urlString)
/*     */   {
/* 371 */     Runnable runner = new BrowserLauncherRunner(this.launching, browsers, urlString, this.logger, this.errorHandler);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 377 */     Thread launcherThread = new Thread(runner);
/* 378 */     launcherThread.start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getNewWindowPolicy()
/*     */   {
/* 396 */     return this.launching.getNewWindowPolicy();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNewWindowPolicy(boolean forceNewWindow)
/*     */   {
/* 405 */     this.launching.setNewWindowPolicy(forceNewWindow);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/BrowserLauncher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */