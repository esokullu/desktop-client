/*    */ package edu.stanford.ejalbert.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BrowserLaunchingExecutionException
/*    */   extends Exception
/*    */ {
/*    */   public BrowserLaunchingExecutionException(Throwable cause)
/*    */   {
/* 34 */     super(cause);
/*    */   }
/*    */   
/*    */   public BrowserLaunchingExecutionException(String message) {
/* 38 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/exception/BrowserLaunchingExecutionException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */