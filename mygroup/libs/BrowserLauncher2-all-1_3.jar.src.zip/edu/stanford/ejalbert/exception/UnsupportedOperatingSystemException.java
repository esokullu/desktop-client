/*    */ package edu.stanford.ejalbert.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedOperatingSystemException
/*    */   extends Exception
/*    */ {
/*    */   public UnsupportedOperatingSystemException(String message)
/*    */   {
/* 34 */     super(message);
/*    */   }
/*    */   
/*    */   public UnsupportedOperatingSystemException(Throwable cause) {
/* 38 */     super(cause);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/exception/UnsupportedOperatingSystemException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */