/*     */ package edu.stanford.ejalbert.browserprefui;
/*     */ 
/*     */ import edu.stanford.ejalbert.BrowserLauncher;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dialog;
/*     */ import java.awt.Frame;
/*     */ import java.awt.HeadlessException;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.List;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BrowserPrefDialog
/*     */   extends JDialog
/*     */ {
/*  50 */   private JList browserList = new JList();
/*  51 */   private String selectedBrowser = null;
/*     */   
/*     */   private static final String UI_BUNDLE = "edu.stanford.ejalbert.browserprefui.BrowserPrefs";
/*     */   
/*     */   public BrowserPrefDialog(Dialog owner, BrowserLauncher launcher)
/*     */     throws HeadlessException
/*     */   {
/*  58 */     super(owner, true);
/*  59 */     initDialog(launcher);
/*     */   }
/*     */   
/*     */   public BrowserPrefDialog(Frame owner, BrowserLauncher launcher)
/*     */     throws HeadlessException
/*     */   {
/*  65 */     super(owner, true);
/*  66 */     initDialog(launcher);
/*     */   }
/*     */   
/*     */   public String getSelectedBrowser() {
/*  70 */     return this.selectedBrowser;
/*     */   }
/*     */   
/*     */   private void initDialog(BrowserLauncher launcher) throws MissingResourceException
/*     */   {
/*  75 */     setDefaultCloseOperation(2);
/*     */     
/*  77 */     ResourceBundle rbundle = ResourceBundle.getBundle("edu.stanford.ejalbert.browserprefui.BrowserPrefs");
/*     */     
/*  79 */     setTitle(rbundle.getString("dialog.title"));
/*     */     
/*  81 */     List browsers = launcher.getBrowserList();
/*  82 */     this.browserList.setListData(browsers.toArray());
/*  83 */     this.browserList.setSelectionMode(0);
/*     */     
/*  85 */     String prefBrowser = System.getProperty("edu.stanford.ejalbert.preferred.browser", null);
/*     */     
/*     */ 
/*  88 */     if (prefBrowser != null) {
/*  89 */       this.browserList.setSelectedValue(prefBrowser, true);
/*     */     }
/*  91 */     initGui(rbundle);
/*     */   }
/*     */   
/*     */   private void okButtonClicked() {
/*  95 */     this.selectedBrowser = ((String)this.browserList.getSelectedValue());
/*  96 */     dispose();
/*     */   }
/*     */   
/*     */   private void cancelButtonClicked() {
/* 100 */     dispose();
/*     */   }
/*     */   
/*     */   private void initGui(ResourceBundle rbundle) throws MissingResourceException
/*     */   {
/* 105 */     JButton okButton = new JButton(rbundle.getString("dialog.bttn.ok"));
/* 106 */     JButton cancelButton = new JButton(rbundle.getString("dialog.bttn.cancel"));
/* 107 */     JScrollPane browserListScroll = new JScrollPane(this.browserList);
/*     */     
/* 109 */     okButton.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent ae) {
/* 111 */         BrowserPrefDialog.this.okButtonClicked();
/*     */       }
/*     */       
/* 114 */     });
/* 115 */     cancelButton.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent ae) {
/* 117 */         BrowserPrefDialog.this.cancelButtonClicked();
/*     */       }
/*     */       
/* 120 */     });
/* 121 */     JPanel mainPanel = new JPanel(new BorderLayout(0, 2));
/* 122 */     JPanel buttonsPanel = new JPanel();
/*     */     
/* 124 */     buttonsPanel.add(okButton);
/* 125 */     buttonsPanel.add(cancelButton);
/* 126 */     mainPanel.add(browserListScroll, "Center");
/* 127 */     mainPanel.add(buttonsPanel, "South");
/* 128 */     getContentPane().add(mainPanel);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/browserprefui/BrowserPrefDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */