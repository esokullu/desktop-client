/*     */ package edu.stanford.ejalbert.browserprefui;
/*     */ 
/*     */ import edu.stanford.ejalbert.BrowserLauncher;
/*     */ import java.awt.Component;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.SwingUtilities;
/*     */ import net.sf.wraplog.AbstractLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BrowserPrefAction
/*     */   extends AbstractAction
/*     */ {
/*     */   private final BrowserLauncher browserLauncher;
/*     */   private final JFrame appFrame;
/*     */   
/*     */   public BrowserPrefAction(String name, BrowserLauncher browserLauncher, JFrame appFrame)
/*     */   {
/*  46 */     super(name);
/*  47 */     if (browserLauncher == null) {
/*  48 */       throw new IllegalArgumentException("browserLauncher cannot be null");
/*     */     }
/*  50 */     this.browserLauncher = browserLauncher;
/*  51 */     this.appFrame = appFrame;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public BrowserPrefAction(String name, Icon icon, BrowserLauncher browserLauncher, JFrame appFrame)
/*     */   {
/*  58 */     super(name, icon);
/*  59 */     if (browserLauncher == null) {
/*  60 */       throw new IllegalArgumentException("browserLauncher cannot be null");
/*     */     }
/*  62 */     this.browserLauncher = browserLauncher;
/*  63 */     this.appFrame = appFrame;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent e)
/*     */   {
/*  79 */     ActionEvent event = e;
/*  80 */     Runnable runner = new Runnable() {
/*     */       public void run() {
/*     */         try {
/*  83 */           BrowserPrefDialog dlg = new BrowserPrefDialog(BrowserPrefAction.this.appFrame, BrowserPrefAction.this.browserLauncher);
/*     */           
/*     */ 
/*  86 */           dlg.setLocationRelativeTo(BrowserPrefAction.this.appFrame);
/*  87 */           dlg.pack();
/*  88 */           dlg.setSize(275, 200);
/*  89 */           dlg.setVisible(true);
/*  90 */           String prefBrowser = dlg.getSelectedBrowser();
/*  91 */           if (prefBrowser != null) {
/*  92 */             System.setProperty("edu.stanford.ejalbert.preferred.browser", prefBrowser);
/*     */           }
/*     */           
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/*  98 */           BrowserPrefAction.this.browserLauncher.getLogger().error("problem getting/setting browser pref", ex);
/*     */         }
/*     */       }
/* 101 */     };
/* 102 */     SwingUtilities.invokeLater(runner);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/browserprefui/BrowserPrefAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */