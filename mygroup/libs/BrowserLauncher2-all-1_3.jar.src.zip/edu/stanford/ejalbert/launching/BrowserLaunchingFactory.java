/*     */ package edu.stanford.ejalbert.launching;
/*     */ 
/*     */ import edu.stanford.ejalbert.exception.UnsupportedOperatingSystemException;
/*     */ import edu.stanford.ejalbert.launching.macos.MacOs2_0BrowserLaunching;
/*     */ import edu.stanford.ejalbert.launching.macos.MacOs2_1BrowserLaunching;
/*     */ import edu.stanford.ejalbert.launching.macos.MacOs3_0BrowserLaunching;
/*     */ import edu.stanford.ejalbert.launching.macos.MacOs3_1BrowserLaunching;
/*     */ import edu.stanford.ejalbert.launching.misc.SunOSBrowserLaunching;
/*     */ import edu.stanford.ejalbert.launching.misc.UnixNetscapeBrowserLaunching;
/*     */ import edu.stanford.ejalbert.launching.windows.WindowsBrowserLaunching;
/*     */ import net.sf.wraplog.AbstractLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BrowserLaunchingFactory
/*     */ {
/*     */   public static IBrowserLaunching createSystemBrowserLaunching(AbstractLogger logger)
/*     */     throws UnsupportedOperatingSystemException
/*     */   {
/*  57 */     String osName = System.getProperty("os.name");
/*  58 */     if (osName.startsWith("Mac OS")) {
/*  59 */       logger.info("Mac OS");
/*  60 */       String mrjVersion = System.getProperty("mrj.version");
/*  61 */       String majorMRJVersion = mrjVersion.substring(0, 3);
/*     */       try {
/*  63 */         double version = Double.valueOf(majorMRJVersion).doubleValue();
/*  64 */         logger.info("version=" + Double.toString(version));
/*  65 */         if (version == 2.0D) {
/*  66 */           return new MacOs2_0BrowserLaunching();
/*     */         }
/*  68 */         if ((version >= 2.1D) && (version < 3.0D))
/*     */         {
/*     */ 
/*     */ 
/*  72 */           return new MacOs2_1BrowserLaunching();
/*     */         }
/*  74 */         if (version == 3.0D) {
/*  75 */           return new MacOs3_0BrowserLaunching();
/*     */         }
/*  77 */         if (version >= 3.1D)
/*     */         {
/*  79 */           return new MacOs3_1BrowserLaunching();
/*     */         }
/*     */         
/*  82 */         throw new UnsupportedOperatingSystemException("Unsupported MRJ version: " + version);
/*     */ 
/*     */       }
/*     */       catch (NumberFormatException nfe)
/*     */       {
/*  87 */         throw new UnsupportedOperatingSystemException("Invalid MRJ version: " + mrjVersion);
/*     */       }
/*     */     }
/*     */     
/*  91 */     if (osName.startsWith("Windows")) {
/*  92 */       logger.info("Windows OS");
/*  93 */       if ((osName.indexOf("9") != -1) || (osName.indexOf("Windows Me") != -1))
/*     */       {
/*  95 */         return new WindowsBrowserLaunching(logger, "windows.win9x");
/*     */       }
/*     */       
/*     */ 
/*  99 */       if (osName.indexOf("Vista") != -1) {
/* 100 */         return new WindowsBrowserLaunching(logger, "windows.winVista");
/*     */       }
/*     */       
/*     */ 
/* 104 */       if ((osName.indexOf("2000") != -1) || (osName.indexOf("XP") != -1))
/*     */       {
/* 106 */         return new WindowsBrowserLaunching(logger, "windows.win2000");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 111 */       return new WindowsBrowserLaunching(logger, "windows.winNT");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 116 */     if (osName.startsWith("SunOS")) {
/* 117 */       logger.info("SunOS");
/* 118 */       return new SunOSBrowserLaunching(logger);
/*     */     }
/*     */     
/* 121 */     logger.info("Unix-type OS");
/* 122 */     return new UnixNetscapeBrowserLaunching(logger, "/edu/stanford/ejalbert/launching/misc/linuxUnixConfig.properties");
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/launching/BrowserLaunchingFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */