/*    */ package edu.stanford.ejalbert.launching.utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LaunchingUtils
/*    */ {
/*    */   private static final String REPLACE_BROWSER = "<browser>";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static final String REPLACE_URL = "<url>";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String replaceArgs(String commands, String browserArg, String urlArg)
/*    */   {
/* 37 */     if (browserArg != null) {
/* 38 */       commands = commands.replaceAll("<browser>", browserArg);
/*    */     }
/*    */     
/* 41 */     if (urlArg != null) {
/* 42 */       int urlPos = commands.indexOf("<url>");
/* 43 */       StringBuffer buf = new StringBuffer();
/* 44 */       while (urlPos > 0) {
/* 45 */         buf.append(commands.substring(0, urlPos));
/* 46 */         buf.append(urlArg);
/* 47 */         buf.append(commands.substring(urlPos + "<url>".length()));
/* 48 */         commands = buf.toString();
/* 49 */         urlPos = commands.indexOf("<url>");
/* 50 */         buf.setLength(0);
/*    */       }
/*    */     }
/* 53 */     return commands;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/launching/utils/LaunchingUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */