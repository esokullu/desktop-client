/*     */ package edu.stanford.ejalbert.launching.macos;
/*     */ 
/*     */ import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;
/*     */ import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;
/*     */ import edu.stanford.ejalbert.exception.UnsupportedOperatingSystemException;
/*     */ import edu.stanford.ejalbert.launching.IBrowserLaunching;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MacOsBrowserLaunching
/*     */   implements IBrowserLaunching
/*     */ {
/*  40 */   private boolean forceNewWindow = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final String FINDER_CREATOR = "MACS";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openUrl(String browser, String urlString)
/*     */     throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException
/*     */   {
/*  65 */     openUrl(urlString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openUrl(List browsers, String urlString)
/*     */     throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException
/*     */   {
/*  83 */     openUrl(urlString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getNewWindowPolicy()
/*     */   {
/* 101 */     return this.forceNewWindow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNewWindowPolicy(boolean forceNewWindow)
/*     */   {
/* 111 */     this.forceNewWindow = forceNewWindow;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/launching/macos/MacOsBrowserLaunching.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */