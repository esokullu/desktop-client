/*     */ package edu.stanford.ejalbert.launching.macos;
/*     */ 
/*     */ import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;
/*     */ import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;
/*     */ import edu.stanford.ejalbert.exception.UnsupportedOperatingSystemException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MacOs2_0BrowserLaunching
/*     */   extends MacOsBrowserLaunching
/*     */ {
/*     */   private static final String GURL_EVENT = "GURL";
/*     */   private Class aeDescClass;
/*     */   private Constructor aeTargetConstructor;
/*     */   private Constructor appleEventConstructor;
/*     */   private Constructor aeDescConstructor;
/*     */   private Method makeOSType;
/*     */   private Method putParameter;
/*     */   private Method sendNoReply;
/*     */   private Integer keyDirectObject;
/*     */   private Integer kAutoGenerateReturnID;
/*     */   private Integer kAnyTransactionID;
/*     */   
/*     */   public void initialize()
/*     */     throws BrowserLaunchingInitializingException
/*     */   {
/*     */     try
/*     */     {
/*  58 */       Class aeTargetClass = Class.forName("com.apple.MacOS.AETarget");
/*  59 */       Class osUtilsClass = Class.forName("com.apple.MacOS.OSUtils");
/*  60 */       Class appleEventClass = Class.forName("com.apple.MacOS.AppleEvent");
/*  61 */       Class aeClass = Class.forName("com.apple.MacOS.ae");
/*  62 */       this.aeDescClass = Class.forName("com.apple.MacOS.AEDesc");
/*     */       
/*  64 */       this.aeTargetConstructor = aeTargetClass.getDeclaredConstructor(new Class[] { Integer.TYPE });
/*     */       
/*  66 */       this.appleEventConstructor = appleEventClass.getDeclaredConstructor(new Class[] { Integer.TYPE, Integer.TYPE, aeTargetClass, Integer.TYPE, Integer.TYPE });
/*     */       
/*     */ 
/*  69 */       this.aeDescConstructor = this.aeDescClass.getDeclaredConstructor(new Class[] { String.class });
/*     */       
/*     */ 
/*  72 */       this.makeOSType = osUtilsClass.getDeclaredMethod("makeOSType", new Class[] { String.class });
/*     */       
/*  74 */       this.putParameter = appleEventClass.getDeclaredMethod("putParameter", new Class[] { Integer.TYPE, this.aeDescClass });
/*     */       
/*  76 */       this.sendNoReply = appleEventClass.getDeclaredMethod("sendNoReply", new Class[0]);
/*     */       
/*     */ 
/*     */ 
/*  80 */       Field keyDirectObjectField = aeClass.getDeclaredField("keyDirectObject");
/*     */       
/*  82 */       this.keyDirectObject = ((Integer)keyDirectObjectField.get(null));
/*  83 */       Field autoGenerateReturnIDField = appleEventClass.getDeclaredField("kAutoGenerateReturnID");
/*     */       
/*  85 */       this.kAutoGenerateReturnID = ((Integer)autoGenerateReturnIDField.get(null));
/*  86 */       Field anyTransactionIDField = appleEventClass.getDeclaredField("kAnyTransactionID");
/*     */       
/*  88 */       this.kAnyTransactionID = ((Integer)anyTransactionIDField.get(null));
/*     */     }
/*     */     catch (Exception cnfe) {
/*  91 */       throw new BrowserLaunchingInitializingException(cnfe);
/*     */     }
/*     */   }
/*     */   
/*     */   private Object getBrowser() throws BrowserLaunchingInitializingException
/*     */   {
/*     */     try {
/*  98 */       Integer finderCreatorCode = (Integer)this.makeOSType.invoke(null, new Object[] { "MACS" });
/*     */       
/* 100 */       Object aeTarget = this.aeTargetConstructor.newInstance(new Object[] { finderCreatorCode });
/*     */       
/* 102 */       Integer gurlType = (Integer)this.makeOSType.invoke(null, new Object[] { "GURL" });
/*     */       
/* 104 */       return this.appleEventConstructor.newInstance(new Object[] { gurlType, gurlType, aeTarget, this.kAutoGenerateReturnID, this.kAnyTransactionID });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 116 */       throw new BrowserLaunchingInitializingException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void openUrl(String urlString)
/*     */     throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException
/*     */   {
/* 124 */     Object browser = getBrowser();
/* 125 */     Object aeDesc = null;
/*     */     try {
/* 127 */       aeDesc = this.aeDescConstructor.newInstance(new Object[] { urlString });
/* 128 */       this.putParameter.invoke(browser, new Object[] { this.keyDirectObject, aeDesc });
/* 129 */       this.sendNoReply.invoke(browser, new Object[0]);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 133 */       throw new BrowserLaunchingExecutionException(e);
/*     */     }
/*     */     finally
/*     */     {
/* 137 */       aeDesc = null;
/* 138 */       browser = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getBrowserList()
/*     */   {
/* 149 */     List browserList = new ArrayList(1);
/* 150 */     browserList.add("Default");
/* 151 */     return browserList;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/launching/macos/MacOs2_0BrowserLaunching.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */