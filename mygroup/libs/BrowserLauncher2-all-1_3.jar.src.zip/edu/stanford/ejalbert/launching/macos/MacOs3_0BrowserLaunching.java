/*    */ package edu.stanford.ejalbert.launching.macos;
/*    */ 
/*    */ import edu.stanford.ejalbert.BrowserLauncher;
/*    */ import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;
/*    */ import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;
/*    */ import edu.stanford.ejalbert.exception.UnsupportedOperatingSystemException;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MacOs3_0BrowserLaunching
/*    */   extends MacOsBrowserLaunching
/*    */ {
/*    */   public void initialize()
/*    */     throws BrowserLaunchingInitializingException
/*    */   {
/*    */     try
/*    */     {
/* 44 */       Class linker = Class.forName("com.apple.mrj.jdirect.Linker");
/* 45 */       Constructor constructor = linker.getConstructor(new Class[] { Class.class });
/* 46 */       linkage = constructor.newInstance(new Object[] { BrowserLauncher.class });
/*    */     }
/*    */     catch (Exception e) {
/*    */       Object linkage;
/* 50 */       throw new BrowserLaunchingInitializingException(e);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void openUrl(String urlString)
/*    */     throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException
/*    */   {
/* 58 */     int[] instance = new int[1];
/* 59 */     int result = ICStart(instance, 0);
/* 60 */     if (result == 0) {
/* 61 */       int[] selectionStart = { 0 };
/* 62 */       byte[] urlBytes = urlString.getBytes();
/* 63 */       int[] selectionEnd = { urlBytes.length };
/* 64 */       result = ICLaunchURL(instance[0], new byte[] { 0 }, urlBytes, urlBytes.length, selectionStart, selectionEnd);
/*    */       
/*    */ 
/* 67 */       if (result == 0)
/*    */       {
/*    */ 
/* 70 */         ICStop(instance);
/*    */       }
/*    */       else {
/* 73 */         throw new BrowserLaunchingExecutionException("Unable to launch URL: " + result);
/*    */       }
/*    */     }
/*    */     else
/*    */     {
/* 78 */       throw new BrowserLaunchingExecutionException("Unable to create an Internet Config instance: " + result);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public List getBrowserList()
/*    */   {
/* 90 */     List browserList = new ArrayList(1);
/* 91 */     browserList.add("Default");
/* 92 */     return browserList;
/*    */   }
/*    */   
/*    */   private static native int ICStart(int[] paramArrayOfInt, int paramInt);
/*    */   
/*    */   private static native int ICStop(int[] paramArrayOfInt);
/*    */   
/*    */   private static native int ICLaunchURL(int paramInt1, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/launching/macos/MacOs3_0BrowserLaunching.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */