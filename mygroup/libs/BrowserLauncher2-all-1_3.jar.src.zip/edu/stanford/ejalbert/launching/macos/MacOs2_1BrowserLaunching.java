/*     */ package edu.stanford.ejalbert.launching.macos;
/*     */ 
/*     */ import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;
/*     */ import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;
/*     */ import edu.stanford.ejalbert.exception.UnsupportedOperatingSystemException;
/*     */ import edu.stanford.ejalbert.launching.IBrowserLaunching;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MacOs2_1BrowserLaunching
/*     */   extends MacOsBrowserLaunching
/*     */   implements IBrowserLaunching
/*     */ {
/*     */   private static final String FINDER_TYPE = "FNDR";
/*     */   private Object kSystemFolderType;
/*     */   private Method findFolder;
/*     */   private Method getFileCreator;
/*     */   private Method getFileType;
/*     */   private String browser;
/*     */   
/*     */   public void initialize()
/*     */     throws BrowserLaunchingInitializingException
/*     */   {
/*     */     try
/*     */     {
/*  58 */       Class mrjFileUtilsClass = Class.forName("com.apple.mrj.MRJFileUtils");
/*     */       
/*  60 */       Class mrjOSTypeClass = Class.forName("com.apple.mrj.MRJOSType");
/*  61 */       Field systemFolderField = mrjFileUtilsClass.getDeclaredField("kSystemFolderType");
/*     */       
/*  63 */       this.kSystemFolderType = systemFolderField.get(null);
/*  64 */       this.findFolder = mrjFileUtilsClass.getDeclaredMethod("findFolder", new Class[] { mrjOSTypeClass });
/*     */       
/*  66 */       this.getFileCreator = mrjFileUtilsClass.getDeclaredMethod("getFileCreator", new Class[] { File.class });
/*     */       
/*  68 */       this.getFileType = mrjFileUtilsClass.getDeclaredMethod("getFileType", new Class[] { File.class });
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  72 */       throw new BrowserLaunchingInitializingException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getBrowser() throws BrowserLaunchingInitializingException
/*     */   {
/*  78 */     if (this.browser != null) {
/*  79 */       return this.browser;
/*     */     }
/*     */     File systemFolder;
/*     */     try
/*     */     {
/*  84 */       systemFolder = (File)this.findFolder.invoke(null, new Object[] { this.kSystemFolderType });
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  88 */       throw new BrowserLaunchingInitializingException(e);
/*     */     }
/*  90 */     String[] systemFolderFiles = systemFolder.list();
/*     */     
/*  92 */     for (int i = 0; i < systemFolderFiles.length; i++) {
/*     */       try {
/*  94 */         File file = new File(systemFolder, systemFolderFiles[i]);
/*  95 */         if (file.isFile())
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */           Object fileType = this.getFileType.invoke(null, new Object[] { file });
/* 104 */           if ("FNDR".equals(fileType.toString())) {
/* 105 */             Object fileCreator = this.getFileCreator.invoke(null, new Object[] { file });
/*     */             
/* 107 */             if ("MACS".equals(fileCreator.toString())) {
/* 108 */               this.browser = file.toString();
/* 109 */               return this.browser;
/*     */             }
/*     */           }
/*     */         }
/*     */       } catch (Exception e) {
/* 114 */         throw new BrowserLaunchingInitializingException(e);
/*     */       }
/*     */     }
/* 117 */     throw new BrowserLaunchingInitializingException("Unable to find finder");
/*     */   }
/*     */   
/*     */ 
/*     */   public void openUrl(String urlString)
/*     */     throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException
/*     */   {
/* 124 */     String browser = getBrowser();
/*     */     try {
/* 126 */       Runtime.getRuntime().exec(new String[] { browser, urlString });
/*     */     }
/*     */     catch (IOException e) {
/* 129 */       throw new BrowserLaunchingExecutionException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getBrowserList()
/*     */   {
/* 140 */     List browserList = new ArrayList(1);
/* 141 */     browserList.add("Default");
/* 142 */     return browserList;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/launching/macos/MacOs2_1BrowserLaunching.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */