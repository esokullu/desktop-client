/*    */ package edu.stanford.ejalbert.launching.macos;
/*    */ 
/*    */ import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;
/*    */ import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;
/*    */ import edu.stanford.ejalbert.exception.UnsupportedOperatingSystemException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MacOs3_1BrowserLaunching
/*    */   extends MacOsBrowserLaunching
/*    */ {
/*    */   private Method openURL;
/*    */   
/*    */   public void initialize()
/*    */     throws BrowserLaunchingInitializingException
/*    */   {
/*    */     try
/*    */     {
/* 43 */       Class mrjFileUtilsClass = Class.forName("com.apple.mrj.MRJFileUtils");
/*    */       
/* 45 */       this.openURL = mrjFileUtilsClass.getDeclaredMethod("openURL", new Class[] { String.class });
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 49 */       throw new BrowserLaunchingInitializingException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public void openUrl(String urlString)
/*    */     throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException
/*    */   {
/*    */     try
/*    */     {
/* 58 */       this.openURL.invoke(null, new Object[] { urlString });
/*    */     }
/*    */     catch (Exception e) {
/* 61 */       throw new BrowserLaunchingExecutionException(e);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public List getBrowserList()
/*    */   {
/* 72 */     List browserList = new ArrayList(1);
/* 73 */     browserList.add("Default");
/* 74 */     return browserList;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/launching/macos/MacOs3_1BrowserLaunching.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */