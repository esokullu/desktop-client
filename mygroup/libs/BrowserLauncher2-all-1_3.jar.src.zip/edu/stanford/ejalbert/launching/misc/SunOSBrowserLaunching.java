/*    */ package edu.stanford.ejalbert.launching.misc;
/*    */ 
/*    */ import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;
/*    */ import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;
/*    */ import edu.stanford.ejalbert.exception.UnsupportedOperatingSystemException;
/*    */ import net.sf.wraplog.AbstractLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SunOSBrowserLaunching
/*    */   extends UnixNetscapeBrowserLaunching
/*    */ {
/*    */   public static final String CONFIGFILE_SUNOS = "/edu/stanford/ejalbert/launching/misc/sunOSConfig.properties";
/*    */   
/*    */   public SunOSBrowserLaunching(AbstractLogger logger)
/*    */   {
/* 51 */     super(logger, "/edu/stanford/ejalbert/launching/misc/sunOSConfig.properties");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void openUrl(String urlString)
/*    */     throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException
/*    */   {
/*    */     try
/*    */     {
/* 68 */       this.logger.info(urlString);
/*    */       
/* 70 */       String browserId = System.getProperty("edu.stanford.ejalbert.preferred.browser", null);
/*    */       
/*    */ 
/* 73 */       StandardUnixBrowser defBrowser = getBrowser("Default");
/*    */       
/* 75 */       if (browserId != null) {
/* 76 */         this.logger.info("browser pref defined in system prop. Failing over to super.openUrl() method");
/*    */         
/* 78 */         super.openUrl(urlString);
/*    */ 
/*    */ 
/*    */       }
/* 82 */       else if (defBrowser == null) {
/* 83 */         this.logger.info("no default browser defined. Failing over to super.openUrl() method");
/*    */         
/* 85 */         super.openUrl(urlString);
/*    */       }
/*    */       else {
/* 88 */         this.logger.info(defBrowser.getBrowserDisplayName());
/* 89 */         Process process = Runtime.getRuntime().exec(defBrowser.getArgsForStartingBrowser(urlString));
/*    */         
/* 91 */         process.waitFor();
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 95 */       throw new BrowserLaunchingExecutionException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/launching/misc/SunOSBrowserLaunching.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */