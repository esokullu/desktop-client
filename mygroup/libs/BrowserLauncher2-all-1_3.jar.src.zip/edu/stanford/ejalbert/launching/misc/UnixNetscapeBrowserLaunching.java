/*     */ package edu.stanford.ejalbert.launching.misc;
/*     */ 
/*     */ import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;
/*     */ import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;
/*     */ import edu.stanford.ejalbert.exception.UnsupportedOperatingSystemException;
/*     */ import edu.stanford.ejalbert.launching.BrowserDescription;
/*     */ import edu.stanford.ejalbert.launching.IBrowserLaunching;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import net.sf.wraplog.AbstractLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnixNetscapeBrowserLaunching
/*     */   implements IBrowserLaunching
/*     */ {
/*     */   public static final String CONFIGFILE_LINUX_UNIX = "/edu/stanford/ejalbert/launching/misc/linuxUnixConfig.properties";
/*  59 */   private Map unixBrowsers = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*     */   
/*     */ 
/*     */ 
/*     */   protected final AbstractLogger logger;
/*     */   
/*     */ 
/*     */ 
/*     */   private final String configFileName;
/*     */   
/*     */ 
/*  70 */   private boolean forceNewWindow = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UnixNetscapeBrowserLaunching(AbstractLogger logger, String configFile)
/*     */   {
/*  80 */     if (configFile == null) {
/*  81 */       throw new IllegalArgumentException("config file cannot be null");
/*     */     }
/*  83 */     this.logger = logger;
/*  84 */     this.configFileName = configFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected StandardUnixBrowser getBrowser(String key)
/*     */   {
/*  94 */     return (StandardUnixBrowser)this.unixBrowsers.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean openUrlWithBrowser(UnixBrowser unixBrowser, String urlString)
/*     */     throws BrowserLaunchingExecutionException
/*     */   {
/* 109 */     boolean success = false;
/* 110 */     this.logger.info(unixBrowser.getBrowserDisplayName());
/* 111 */     this.logger.info(urlString);
/*     */     try {
/* 113 */       int exitCode = -1;
/* 114 */       Process process = null;
/*     */       
/*     */ 
/*     */ 
/* 118 */       if (!this.forceNewWindow) {
/* 119 */         String[] args = unixBrowser.getArgsForOpenBrowser(urlString);
/* 120 */         if (this.logger.isDebugEnabled()) {
/* 121 */           this.logger.debug(Arrays.asList(args).toString());
/*     */         }
/* 123 */         process = Runtime.getRuntime().exec(args);
/* 124 */         exitCode = process.waitFor();
/*     */       }
/*     */       
/* 127 */       if ((this.forceNewWindow) && (exitCode != 0)) {
/* 128 */         String[] args = unixBrowser.getArgsForForcingNewBrowserWindow(urlString);
/* 129 */         if (this.logger.isDebugEnabled()) {
/* 130 */           this.logger.debug(Arrays.asList(args).toString());
/*     */         }
/* 132 */         process = Runtime.getRuntime().exec(args);
/* 133 */         exitCode = process.waitFor();
/*     */       }
/*     */       
/* 136 */       if (exitCode != 0) {
/* 137 */         String[] args = unixBrowser.getArgsForStartingBrowser(urlString);
/* 138 */         if (this.logger.isDebugEnabled()) {
/* 139 */           this.logger.debug(Arrays.asList(args).toString());
/*     */         }
/* 141 */         process = Runtime.getRuntime().exec(args);
/* 142 */         exitCode = process.waitFor();
/*     */       }
/* 144 */       if (exitCode == 0) {
/* 145 */         success = true;
/*     */       }
/*     */       
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 151 */       throw new BrowserLaunchingExecutionException(e);
/*     */     }
/* 153 */     return success;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize()
/*     */     throws BrowserLaunchingInitializingException
/*     */   {
/*     */     try
/*     */     {
/* 169 */       URL configUrl = getClass().getResource(this.configFileName);
/* 170 */       if (configUrl == null) {
/* 171 */         throw new BrowserLaunchingInitializingException("unable to find config file: " + this.configFileName);
/*     */       }
/*     */       
/* 174 */       StringBuffer potentialBrowserNames = new StringBuffer();
/* 175 */       Properties configProps = new Properties();
/* 176 */       configProps.load(configUrl.openStream());
/* 177 */       String sepChar = configProps.getProperty("delimchar");
/* 178 */       Iterator keysIter = configProps.keySet().iterator();
/* 179 */       while (keysIter.hasNext()) {
/* 180 */         String key = (String)keysIter.next();
/* 181 */         if (key.startsWith("browser.")) {
/* 182 */           StandardUnixBrowser browser = new StandardUnixBrowser(sepChar, configProps.getProperty(key));
/*     */           
/*     */ 
/* 185 */           if (browser.isBrowserAvailable(this.logger)) {
/* 186 */             this.unixBrowsers.put(browser.getBrowserDisplayName(), browser);
/*     */           }
/*     */           else
/*     */           {
/* 190 */             if (potentialBrowserNames.length() > 0) {
/* 191 */               potentialBrowserNames.append("; ");
/*     */             }
/* 193 */             potentialBrowserNames.append(browser.getBrowserDisplayName());
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 198 */       if (this.unixBrowsers.size() == 0)
/*     */       {
/* 200 */         throw new BrowserLaunchingInitializingException("one of the supported browsers must be installed: " + potentialBrowserNames);
/*     */       }
/*     */       
/*     */ 
/* 204 */       this.logger.info(this.unixBrowsers.keySet().toString());
/* 205 */       this.unixBrowsers = Collections.unmodifiableMap(this.unixBrowsers);
/*     */     }
/*     */     catch (IOException ioex) {
/* 208 */       throw new BrowserLaunchingInitializingException(ioex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openUrl(String urlString)
/*     */     throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException
/*     */   {
/*     */     try
/*     */     {
/* 223 */       this.logger.info(urlString);
/* 224 */       boolean success = false;
/*     */       
/* 226 */       List unixBrowsersList = new ArrayList(this.unixBrowsers.values());
/*     */       
/* 228 */       String browserId = System.getProperty("edu.stanford.ejalbert.preferred.browser", null);
/*     */       
/*     */ 
/* 231 */       if (browserId != null) {
/* 232 */         UnixBrowser unixBrowser = (UnixBrowser)this.unixBrowsers.get(browserId);
/*     */         
/* 234 */         if (unixBrowser != null)
/*     */         {
/* 236 */           unixBrowsersList.add(0, unixBrowser);
/*     */         }
/*     */       }
/*     */       
/* 240 */       Iterator iter = unixBrowsersList.iterator();
/*     */       
/*     */ 
/* 243 */       while ((iter.hasNext()) && (!success)) {
/* 244 */         UnixBrowser browser = (UnixBrowser)iter.next();
/* 245 */         success = openUrlWithBrowser(browser, urlString);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 250 */       throw new BrowserLaunchingExecutionException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openUrl(String browser, String urlString)
/*     */     throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException
/*     */   {
/* 270 */     UnixBrowser unixBrowser = (UnixBrowser)this.unixBrowsers.get(browser);
/* 271 */     if ((unixBrowser == null) || ("Default".equals(browser)))
/*     */     {
/* 273 */       this.logger.debug("falling through to non-targetted openUrl");
/* 274 */       openUrl(urlString);
/*     */     }
/*     */     else {
/* 277 */       boolean success = openUrlWithBrowser(unixBrowser, urlString);
/*     */       
/* 279 */       if (!success) {
/* 280 */         this.logger.debug("open browser failure, trying non-targetted openUrl");
/*     */         
/* 282 */         openUrl(urlString);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openUrl(List browsers, String urlString)
/*     */     throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException
/*     */   {
/* 308 */     if ((browsers == null) || (browsers.isEmpty())) {
/* 309 */       this.logger.debug("falling through to non-targetted openUrl");
/* 310 */       openUrl(urlString);
/*     */     }
/*     */     else {
/* 313 */       boolean success = false;
/* 314 */       Iterator iter = browsers.iterator();
/* 315 */       while ((iter.hasNext()) && (!success)) {
/* 316 */         UnixBrowser unixBrowser = (UnixBrowser)this.unixBrowsers.get(iter.next());
/*     */         
/* 318 */         if (unixBrowser != null) {
/* 319 */           success = openUrlWithBrowser(unixBrowser, urlString);
/*     */         }
/*     */       }
/*     */       
/* 323 */       if (!success) {
/* 324 */         this.logger.debug("none of listed browsers succeeded; falling through to non-targetted openUrl");
/*     */         
/* 326 */         openUrl(urlString);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getBrowserList()
/*     */   {
/* 339 */     List browsers = new ArrayList();
/*     */     
/* 341 */     if (!this.unixBrowsers.containsKey("Default")) {
/* 342 */       browsers.add("Default");
/*     */     }
/* 344 */     browsers.addAll(this.unixBrowsers.keySet());
/* 345 */     return browsers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getNewWindowPolicy()
/*     */   {
/* 364 */     return this.forceNewWindow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNewWindowPolicy(boolean forceNewWindow)
/*     */   {
/* 373 */     this.forceNewWindow = forceNewWindow;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/launching/misc/UnixNetscapeBrowserLaunching.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */