/*     */ package edu.stanford.ejalbert.launching.misc;
/*     */ 
/*     */ import edu.stanford.ejalbert.launching.utils.LaunchingUtils;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import net.sf.wraplog.AbstractLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StandardUnixBrowser
/*     */   implements UnixBrowser
/*     */ {
/*     */   private final String browserName;
/*     */   private final String browserArgName;
/*     */   private final String argsForOpenBrowser;
/*     */   private final String argsForStartBrowser;
/*     */   private final String argsForForcedBrowserWindow;
/*     */   
/*     */   StandardUnixBrowser(String configSep, String configStr)
/*     */   {
/*  68 */     String[] configItems = configStr.split(configSep, -2);
/*  69 */     this.browserName = configItems[0];
/*  70 */     this.browserArgName = configItems[1];
/*  71 */     this.argsForStartBrowser = configItems[2];
/*  72 */     this.argsForOpenBrowser = configItems[3];
/*  73 */     if (configItems.length == 5) {
/*  74 */       this.argsForForcedBrowserWindow = configItems[4];
/*     */     }
/*     */     else {
/*  77 */       this.argsForForcedBrowserWindow = configItems[2];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  87 */     StringBuffer buf = new StringBuffer();
/*  88 */     buf.append("display name=");
/*  89 */     buf.append(this.browserName);
/*  90 */     buf.append(" executable name=");
/*  91 */     buf.append(this.browserArgName);
/*  92 */     buf.append(" argsForStartBrowser=");
/*  93 */     buf.append(this.argsForStartBrowser);
/*  94 */     buf.append(" argsForOpenBrowser=");
/*  95 */     buf.append(this.argsForOpenBrowser);
/*  96 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] getCommandLineArgs(String argsString, String urlString)
/*     */   {
/* 110 */     argsString = LaunchingUtils.replaceArgs(argsString, this.browserArgName, urlString);
/*     */     
/*     */ 
/* 113 */     return argsString.split("[ ]");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBrowserDisplayName()
/*     */   {
/* 124 */     return this.browserName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBrowserApplicationName()
/*     */   {
/* 133 */     return this.browserArgName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getArgsForOpenBrowser(String urlString)
/*     */   {
/* 146 */     String argsStartString = (this.argsForOpenBrowser != null) && (this.argsForOpenBrowser.length() > 0) ? this.argsForOpenBrowser : this.argsForStartBrowser;
/*     */     
/*     */ 
/* 149 */     return getCommandLineArgs(argsStartString, urlString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getArgsForStartingBrowser(String urlString)
/*     */   {
/* 160 */     return getCommandLineArgs(this.argsForStartBrowser, urlString);
/*     */   }
/*     */   
/*     */   public String[] getArgsForForcingNewBrowserWindow(String urlString) {
/* 164 */     return getCommandLineArgs(this.argsForForcedBrowserWindow, urlString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBrowserAvailable(AbstractLogger logger)
/*     */   {
/* 174 */     boolean isAvailable = false;
/*     */     try {
/* 176 */       Process process = Runtime.getRuntime().exec(new String[] { "which", this.browserArgName });
/*     */       
/* 178 */       InputStream errStream = process.getErrorStream();
/* 179 */       InputStream inStream = process.getInputStream();
/* 180 */       BufferedReader errIn = new BufferedReader(new InputStreamReader(errStream));
/*     */       
/* 182 */       BufferedReader in = new BufferedReader(new InputStreamReader(inStream));
/*     */       
/* 184 */       String whichOutput = in.readLine();
/* 185 */       String whichErrOutput = errIn.readLine();
/* 186 */       in.close();
/* 187 */       errIn.close();
/* 188 */       if (whichOutput != null) {
/* 189 */         logger.debug(whichOutput);
/*     */       }
/* 191 */       if (whichErrOutput != null) {
/* 192 */         logger.debug(whichErrOutput);
/*     */       }
/* 194 */       isAvailable = (whichOutput != null) && (whichOutput.startsWith("/"));
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 198 */       logger.error("io error executing which command", ex);
/*     */     }
/* 200 */     return isAvailable;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/launching/misc/StandardUnixBrowser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */