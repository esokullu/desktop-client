package edu.stanford.ejalbert.launching.misc;

import edu.stanford.ejalbert.launching.BrowserDescription;
import net.sf.wraplog.AbstractLogger;

public abstract interface UnixBrowser
  extends BrowserDescription
{
  public abstract String[] getArgsForOpenBrowser(String paramString);
  
  public abstract String[] getArgsForStartingBrowser(String paramString);
  
  public abstract String[] getArgsForForcingNewBrowserWindow(String paramString);
  
  public abstract boolean isBrowserAvailable(AbstractLogger paramAbstractLogger);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/launching/misc/UnixBrowser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */