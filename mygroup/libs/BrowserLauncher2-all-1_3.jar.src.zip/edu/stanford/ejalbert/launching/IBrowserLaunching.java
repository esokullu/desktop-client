package edu.stanford.ejalbert.launching;

import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;
import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;
import edu.stanford.ejalbert.exception.UnsupportedOperatingSystemException;
import java.util.List;

public abstract interface IBrowserLaunching
{
  public static final String BROWSER_SYSTEM_PROPERTY = "edu.stanford.ejalbert.preferred.browser";
  public static final String WINDOWS_BROWSER_DISC_POLICY_PROPERTY = "win.browser.disc.policy";
  public static final String WINDOWS_BROWSER_DISC_POLICY_DISK = "disk";
  public static final String WINDOWS_BROWSER_DISC_POLICY_REGISTRY = "registry";
  public static final String PROP_KEY_DELIMITER = "delimchar";
  public static final String PROP_KEY_BROWSER_PREFIX = "browser.";
  public static final String PROTOCOL_HTTP = "http";
  public static final String PROTOCOL_FILE = "file";
  public static final String PROTOCOL_MAILTO = "mailto";
  public static final String BROWSER_DEFAULT = "Default";
  
  public abstract void initialize()
    throws BrowserLaunchingInitializingException;
  
  public abstract void openUrl(String paramString)
    throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException;
  
  public abstract void openUrl(String paramString1, String paramString2)
    throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException;
  
  public abstract void openUrl(List paramList, String paramString)
    throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException;
  
  public abstract List getBrowserList();
  
  public abstract boolean getNewWindowPolicy();
  
  public abstract void setNewWindowPolicy(boolean paramBoolean);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/launching/IBrowserLaunching.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */