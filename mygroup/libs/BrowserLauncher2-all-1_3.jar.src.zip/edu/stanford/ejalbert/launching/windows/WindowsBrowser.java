/*     */ package edu.stanford.ejalbert.launching.windows;
/*     */ 
/*     */ import edu.stanford.ejalbert.launching.BrowserDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WindowsBrowser
/*     */   implements BrowserDescription
/*     */ {
/*     */   private final String displayName;
/*     */   private final String exe;
/*     */   private final String forceWindowArgs;
/*  50 */   private String pathToExe = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String subDirName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   WindowsBrowser(String delimChar, String configInfo)
/*     */   {
/*  73 */     String[] configItems = configInfo.split(delimChar, 4);
/*  74 */     this.displayName = configItems[0];
/*  75 */     this.exe = configItems[1];
/*  76 */     this.forceWindowArgs = configItems[2];
/*  77 */     this.subDirName = configItems[3];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  86 */     StringBuffer buf = new StringBuffer();
/*  87 */     buf.append(this.displayName);
/*  88 */     buf.append(": ForceWindowArg=");
/*  89 */     buf.append(this.forceWindowArgs);
/*  90 */     buf.append("; SubDir name=");
/*  91 */     buf.append(this.subDirName);
/*  92 */     buf.append("; Path to exe=");
/*  93 */     if (this.pathToExe != null) {
/*  94 */       buf.append(this.pathToExe);
/*     */     }
/*  96 */     buf.append("; Exe name=");
/*  97 */     buf.append(this.exe);
/*  98 */     return buf.toString();
/*     */   }
/*     */   
/*     */   void setPathToExe(String path) {
/* 102 */     this.pathToExe = path;
/* 103 */     if (!this.pathToExe.endsWith("\\")) {
/* 104 */       StringBuffer buf = new StringBuffer(this.pathToExe.length() + 2);
/* 105 */       buf.append(this.pathToExe);
/* 106 */       buf.append('\\');
/* 107 */       this.pathToExe = buf.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   String getPathToExe() {
/* 112 */     return this.pathToExe;
/*     */   }
/*     */   
/*     */   String getSubDirName() {
/* 116 */     return this.subDirName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBrowserDisplayName()
/*     */   {
/* 127 */     return this.displayName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBrowserApplicationName()
/*     */   {
/* 136 */     return this.exe;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getForceNewWindowArgs()
/*     */   {
/* 145 */     return this.forceWindowArgs;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/launching/windows/WindowsBrowser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */