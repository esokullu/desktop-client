/*     */ package edu.stanford.ejalbert.launching.windows;
/*     */ 
/*     */ import at.jta.RegistryErrorException;
/*     */ import at.jta.Regor;
/*     */ import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;
/*     */ import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;
/*     */ import edu.stanford.ejalbert.exception.UnsupportedOperatingSystemException;
/*     */ import edu.stanford.ejalbert.launching.IBrowserLaunching;
/*     */ import edu.stanford.ejalbert.launching.utils.LaunchingUtils;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TreeMap;
/*     */ import net.sf.wraplog.AbstractLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WindowsBrowserLaunching
/*     */   implements IBrowserLaunching
/*     */ {
/*     */   private static final String CONFIGFILE_WINDOWS = "/edu/stanford/ejalbert/launching/windows/windowsConfig.properties";
/*     */   public static final String WINKEY_WINVISTA = "windows.winVista";
/*     */   public static final String WINKEY_WIN2000 = "windows.win2000";
/*     */   public static final String WINKEY_WIN9X = "windows.win9x";
/*     */   public static final String WINKEY_WINNT = "windows.winNT";
/*  82 */   private static final String[] WIN_KEYS = { "windows.win2000", "windows.win9x", "windows.winNT", "windows.winVista" };
/*     */   
/*     */   protected final AbstractLogger logger;
/*     */   
/*     */   static
/*     */   {
/*  88 */     Arrays.sort(WIN_KEYS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */   private Map browserNameAndExeMap = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */   private List browsersToCheck = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String commandsDefaultBrowser;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String commandsTargettedBrowser;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String windowsKey;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 127 */   private boolean forceNewWindow = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */   private boolean useRegistry = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String programFilesFolderTemplate;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String driveLetters;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WindowsBrowserLaunching(AbstractLogger logger, String windowsKey)
/*     */   {
/* 154 */     if (windowsKey == null) {
/* 155 */       throw new IllegalArgumentException("windowsKey cannot be null");
/*     */     }
/* 157 */     if (Arrays.binarySearch(WIN_KEYS, windowsKey) < 0) {
/* 158 */       throw new IllegalArgumentException(windowsKey + " is invalid");
/*     */     }
/* 160 */     this.logger = logger;
/* 161 */     this.windowsKey = windowsKey;
/* 162 */     logger.info(windowsKey);
/*     */   }
/*     */   
/*     */   private String getArrayAsString(String[] array) {
/* 166 */     return Arrays.asList(array).toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getProtocol(String urlString)
/*     */     throws MalformedURLException
/*     */   {
/* 178 */     URL url = new URL(urlString);
/* 179 */     return url.getProtocol();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map getBrowserMap()
/*     */   {
/* 191 */     synchronized (WindowsBrowserLaunching.class) {
/* 192 */       if (this.browserNameAndExeMap == null) {
/* 193 */         this.browserNameAndExeMap = new HashMap();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 199 */         List tempBrowsersToCheck = new ArrayList(this.browsersToCheck);
/*     */         
/* 201 */         if (this.useRegistry) {
/* 202 */           this.browserNameAndExeMap.putAll(getAvailableBrowsers(tempBrowsersToCheck));
/*     */         }
/*     */         
/*     */ 
/* 206 */         if (!tempBrowsersToCheck.isEmpty()) {
/* 207 */           this.browserNameAndExeMap.putAll(processFilePathsForBrowsers(tempBrowsersToCheck));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 212 */     return this.browserNameAndExeMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private File getProgramFilesPath()
/*     */   {
/* 221 */     File progFilesPath = null;
/* 222 */     if ((this.driveLetters != null) && (this.programFilesFolderTemplate != null)) {
/* 223 */       String[] drives = this.driveLetters.split(";");
/* 224 */       for (int idx = 0; (idx < drives.length) && (progFilesPath == null); idx++) {
/* 225 */         String path = MessageFormat.format(this.programFilesFolderTemplate, new Object[] { drives[idx] });
/*     */         
/*     */ 
/* 228 */         File pfPath = new File(path);
/* 229 */         this.logger.debug(path);
/* 230 */         this.logger.debug(pfPath.getPath());
/* 231 */         if (pfPath.exists()) {
/* 232 */           progFilesPath = pfPath;
/*     */         }
/*     */       }
/*     */     }
/* 236 */     return progFilesPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map processFilePathsForBrowsers(List tmpBrowsersToCheck)
/*     */   {
/* 252 */     this.logger.debug("finding available browsers in program files path");
/* 253 */     this.logger.debug("browsers to check: " + tmpBrowsersToCheck);
/* 254 */     Map browsersAvailable = new HashMap();
/* 255 */     File progFilesPath = getProgramFilesPath();
/* 256 */     if (progFilesPath != null) {
/* 257 */       this.logger.debug("program files path: " + progFilesPath.getPath());
/* 258 */       File[] subDirs = progFilesPath.listFiles(new DirFileFilter(null));
/* 259 */       int subDirsCnt = subDirs != null ? subDirs.length : 0;
/*     */       
/* 261 */       Iterator iter = tmpBrowsersToCheck.iterator();
/* 262 */       Map dirNameToBrowser = new HashMap();
/* 263 */       while (iter.hasNext()) {
/* 264 */         WindowsBrowser wBrowser = (WindowsBrowser)iter.next();
/* 265 */         dirNameToBrowser.put(wBrowser.getSubDirName(), wBrowser);
/*     */       }
/*     */       
/* 268 */       for (int idx = 0; (idx < subDirsCnt) && (!tmpBrowsersToCheck.isEmpty()); 
/* 269 */           idx++) {
/* 270 */         if (dirNameToBrowser.containsKey(subDirs[idx].getName())) {
/* 271 */           WindowsBrowser wBrowser = (WindowsBrowser)dirNameToBrowser.get(subDirs[idx].getName());
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 276 */           String exeName = wBrowser.getBrowserApplicationName() + ".exe";
/*     */           
/* 278 */           File fullPathToExe = findExeFilePath(subDirs[idx], exeName);
/*     */           
/*     */ 
/* 281 */           if (fullPathToExe != null) {
/* 282 */             this.logger.debug("Adding browser " + wBrowser.getBrowserDisplayName() + " to available list.");
/*     */             
/*     */ 
/* 285 */             wBrowser.setPathToExe(fullPathToExe.getPath());
/* 286 */             this.logger.debug(wBrowser.getPathToExe());
/*     */             
/*     */ 
/* 289 */             browsersAvailable.put(wBrowser.getBrowserDisplayName(), wBrowser);
/*     */             
/* 291 */             browsersAvailable.put(wBrowser.getBrowserApplicationName(), wBrowser);
/*     */             
/*     */ 
/* 294 */             tmpBrowsersToCheck.remove(wBrowser);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 299 */     return browsersAvailable;
/*     */   }
/*     */   
/*     */   private File findExeFilePath(File path, String exeName) {
/* 303 */     File exePath = null;
/* 304 */     File[] exeFiles = path.listFiles(new ExeFileNameFilter(null));
/* 305 */     if ((exeFiles != null) && (exeFiles.length > 0)) {
/* 306 */       for (int idx = 0; (idx < exeFiles.length) && (exePath == null); idx++) {
/* 307 */         if (exeFiles[idx].getName().equalsIgnoreCase(exeName))
/*     */         {
/* 309 */           exePath = exeFiles[idx].getParentFile();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 314 */     if (exePath == null) {
/* 315 */       File[] subDirs = path.listFiles(new DirFileFilter(null));
/* 316 */       if ((subDirs != null) && (subDirs.length > 0)) {
/* 317 */         for (int idx = 0; (idx < subDirs.length) && (exePath == null); idx++) {
/* 318 */           exePath = findExeFilePath(subDirs[idx], exeName);
/*     */         }
/*     */       }
/*     */     }
/* 322 */     return exePath;
/*     */   }
/*     */   
/*     */   private static final class DirFileFilter implements FileFilter
/*     */   {
/*     */     DirFileFilter(WindowsBrowserLaunching.0 x0) {
/* 328 */       this();
/*     */     }
/*     */     
/* 331 */     public boolean accept(File pathname) { return pathname.isDirectory(); }
/*     */     
/*     */     private DirFileFilter() {}
/*     */   }
/*     */   
/*     */   private static final class ExeFileNameFilter implements FilenameFilter
/*     */   {
/*     */     ExeFileNameFilter(WindowsBrowserLaunching.0 x0) {
/* 339 */       this();
/*     */     }
/*     */     
/* 342 */     public boolean accept(File dir, String name) { return name.toLowerCase().endsWith(".exe"); }
/*     */     
/*     */     private ExeFileNameFilter() {}
/*     */   }
/*     */   
/*     */   private Map getExeNamesToBrowsers(List tempBrowsersToCheck) {
/* 348 */     Map exeNamesToBrowsers = new HashMap();
/* 349 */     Iterator iter = tempBrowsersToCheck.iterator();
/* 350 */     while (iter.hasNext()) {
/* 351 */       WindowsBrowser winBrowser = (WindowsBrowser)iter.next();
/* 352 */       String exeName = winBrowser.getBrowserApplicationName().toLowerCase() + ".exe";
/*     */       
/* 354 */       exeNamesToBrowsers.put(exeName, winBrowser);
/*     */     }
/* 356 */     return exeNamesToBrowsers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WindowsBrowser getBrowserFromRegistryEntry(Regor regor, int key, String subKey, String exeKey, Map exesToBrowserObjs)
/*     */     throws RegistryErrorException
/*     */   {
/* 366 */     WindowsBrowser winBrowser = null;
/* 367 */     int key2 = regor.openKey(key, subKey);
/* 368 */     List values = regor.listValueNames(key2);
/*     */     
/* 370 */     for (int x = 0; 
/* 371 */         (values != null) && (x < values.size()) && (winBrowser == null); 
/* 372 */         x++) {
/* 373 */       byte[] buf = regor.readValue(key2, (String)values.get(x));
/*     */       
/*     */ 
/* 376 */       String path = buf != null ? Regor.parseValue(buf) : "";
/*     */       
/* 378 */       String lpath = path.toLowerCase();
/* 379 */       if (lpath.endsWith(exeKey)) {
/* 380 */         winBrowser = (WindowsBrowser)exesToBrowserObjs.get(exeKey);
/*     */         
/*     */ 
/* 383 */         StringTokenizer tokenizer = new StringTokenizer(path, "\\", false);
/*     */         
/* 385 */         StringBuffer pathBuf = new StringBuffer();
/* 386 */         int tokCnt = tokenizer.countTokens();
/*     */         
/* 388 */         for (int idx = 1; idx < tokCnt; idx++) {
/* 389 */           pathBuf.append(tokenizer.nextToken());
/* 390 */           pathBuf.append('\\');
/*     */         }
/* 392 */         winBrowser.setPathToExe(pathBuf.toString());
/*     */       }
/*     */     }
/* 395 */     return winBrowser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map getAvailableBrowsers(List tempBrowsersToCheck)
/*     */   {
/* 408 */     this.logger.debug("finding available browsers using registry");
/* 409 */     this.logger.debug("browsers to check: " + tempBrowsersToCheck);
/* 410 */     Map browsersAvailable = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*     */     try
/*     */     {
/* 413 */       Map exesToBrowserObjs = getExeNamesToBrowsers(tempBrowsersToCheck);
/*     */       
/* 415 */       Regor regor = new Regor();
/* 416 */       String subKeyName = "Software\\Microsoft\\Windows\\CurrentVersion\\App Paths";
/*     */       
/* 418 */       int key = regor.openKey(-2147483646, subKeyName);
/*     */       
/* 420 */       if (key > -1) {
/* 421 */         List keys = regor.listKeys(key);
/* 422 */         Collections.sort(keys, String.CASE_INSENSITIVE_ORDER);
/* 423 */         Iterator keysIter = exesToBrowserObjs.keySet().iterator();
/* 424 */         while (keysIter.hasNext()) {
/* 425 */           String exeKey = (String)keysIter.next();
/* 426 */           int index = Collections.binarySearch(keys, exeKey, String.CASE_INSENSITIVE_ORDER);
/*     */           
/*     */ 
/*     */ 
/* 430 */           if (index >= 0) {
/* 431 */             WindowsBrowser winBrowser = getBrowserFromRegistryEntry(regor, key, (String)keys.get(index), exeKey, exesToBrowserObjs);
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 437 */             if (winBrowser != null) {
/* 438 */               if (this.logger.isDebugEnabled()) {
/* 439 */                 this.logger.debug("Adding browser " + winBrowser.getBrowserDisplayName() + " to available list.");
/*     */                 
/*     */ 
/*     */ 
/* 443 */                 this.logger.debug(winBrowser.getPathToExe());
/*     */               }
/*     */               
/*     */ 
/* 447 */               browsersAvailable.put(winBrowser.getBrowserDisplayName(), winBrowser);
/*     */               
/*     */ 
/* 450 */               browsersAvailable.put(winBrowser.getBrowserApplicationName(), winBrowser);
/*     */               
/*     */ 
/* 453 */               tempBrowsersToCheck.remove(winBrowser);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (RegistryErrorException ex) {
/* 460 */       this.logger.error("problem accessing registry", ex);
/*     */     }
/* 462 */     return browsersAvailable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] getCommandArgs(String protocol, String urlString)
/*     */   {
/* 474 */     String commandArgs = LaunchingUtils.replaceArgs(this.commandsDefaultBrowser, null, urlString);
/*     */     
/*     */ 
/*     */ 
/* 478 */     return commandArgs.split("[ ]");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getCommandArgs(String protocol, WindowsBrowser winbrowser, String urlString, boolean forceNewWindow)
/*     */   {
/* 497 */     String commandArgs = LaunchingUtils.replaceArgs(this.commandsTargettedBrowser, winbrowser.getBrowserApplicationName(), urlString);
/*     */     
/*     */ 
/*     */ 
/* 501 */     String args = "";
/* 502 */     if (forceNewWindow) {
/* 503 */       args = winbrowser.getForceNewWindowArgs();
/*     */     }
/* 505 */     commandArgs = commandArgs.replaceAll("<args>", args);
/* 506 */     int pathLoc = commandArgs.indexOf("<path>");
/* 507 */     if (pathLoc > 0) {
/* 508 */       StringBuffer buf = new StringBuffer();
/* 509 */       buf.append(commandArgs.substring(0, pathLoc));
/* 510 */       buf.append(winbrowser.getPathToExe());
/* 511 */       buf.append(commandArgs.substring(pathLoc + 6));
/* 512 */       commandArgs = buf.toString();
/*     */     }
/* 514 */     return commandArgs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean openUrlWithBrowser(WindowsBrowser winBrowser, String protocol, String urlString)
/*     */     throws BrowserLaunchingExecutionException
/*     */   {
/* 531 */     boolean success = false;
/*     */     try {
/* 533 */       this.logger.info(winBrowser.getBrowserDisplayName());
/* 534 */       this.logger.info(urlString);
/* 535 */       this.logger.info(protocol);
/* 536 */       String args = getCommandArgs(protocol, winBrowser, urlString, this.forceNewWindow);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 541 */       if (this.logger.isDebugEnabled()) {
/* 542 */         this.logger.debug(args);
/*     */       }
/* 544 */       Process process = Runtime.getRuntime().exec(args);
/*     */       
/*     */ 
/* 547 */       process.waitFor();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 558 */       int exitValue = process.exitValue();
/* 559 */       success = (exitValue == 0) || (exitValue == 1);
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 564 */       throw new BrowserLaunchingExecutionException(e);
/*     */     }
/* 566 */     return success;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize()
/*     */     throws BrowserLaunchingInitializingException
/*     */   {
/*     */     try
/*     */     {
/* 583 */       URL configUrl = getClass().getResource("/edu/stanford/ejalbert/launching/windows/windowsConfig.properties");
/* 584 */       if (configUrl == null) {
/* 585 */         throw new BrowserLaunchingInitializingException("unable to find config file: /edu/stanford/ejalbert/launching/windows/windowsConfig.properties");
/*     */       }
/*     */       
/* 588 */       Properties configProps = new Properties();
/* 589 */       configProps.load(configUrl.openStream());
/*     */       
/* 591 */       String sepChar = configProps.getProperty("delimchar");
/*     */       
/* 593 */       Iterator keysIter = configProps.keySet().iterator();
/* 594 */       while (keysIter.hasNext()) {
/* 595 */         String key = (String)keysIter.next();
/* 596 */         if (key.startsWith("browser.")) {
/* 597 */           WindowsBrowser winBrowser = new WindowsBrowser(sepChar, configProps.getProperty(key));
/*     */           
/*     */ 
/* 600 */           this.browsersToCheck.add(winBrowser);
/*     */         }
/*     */       }
/*     */       
/* 604 */       String windowsConfigStr = configProps.getProperty(this.windowsKey, null);
/*     */       
/*     */ 
/* 607 */       if (windowsConfigStr == null) {
/* 608 */         throw new BrowserLaunchingInitializingException(this.windowsKey + " is not a valid property");
/*     */       }
/*     */       
/* 611 */       String[] winConfigItems = windowsConfigStr.split(sepChar);
/* 612 */       this.commandsDefaultBrowser = winConfigItems[0];
/* 613 */       this.commandsTargettedBrowser = winConfigItems[1];
/* 614 */       Boolean boolVal = new Boolean(winConfigItems[2]);
/* 615 */       this.useRegistry = boolVal.booleanValue();
/*     */       
/*     */ 
/*     */ 
/* 619 */       String propValue = System.getProperty("win.browser.disc.policy", null);
/*     */       
/*     */ 
/* 622 */       if ("disk".equals(propValue))
/*     */       {
/* 624 */         this.useRegistry = false;
/*     */       }
/* 626 */       else if ("registry".equals(propValue))
/*     */       {
/* 628 */         this.useRegistry = true;
/*     */       }
/* 630 */       if (this.logger.isDebugEnabled()) {
/* 631 */         this.logger.debug("Browser discovery policy property value=" + (propValue == null ? "null" : propValue));
/*     */         
/* 633 */         this.logger.debug("useRegistry=" + Boolean.toString(this.useRegistry));
/*     */       }
/*     */       
/* 636 */       this.programFilesFolderTemplate = configProps.getProperty("program.files.template", null);
/*     */       
/*     */ 
/* 639 */       this.driveLetters = configProps.getProperty("drive.letters", null);
/*     */       
/*     */ 
/*     */ 
/* 643 */       this.browsersToCheck = Collections.unmodifiableList(this.browsersToCheck);
/*     */     }
/*     */     catch (IOException ioex) {
/* 646 */       throw new BrowserLaunchingInitializingException(ioex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openUrl(String urlString)
/*     */     throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException
/*     */   {
/*     */     try
/*     */     {
/* 663 */       this.logger.info(urlString);
/* 664 */       String protocol = getProtocol(urlString);
/* 665 */       this.logger.info(protocol);
/*     */       
/* 667 */       boolean successfullSystemPropLaunch = false;
/* 668 */       String browserName = System.getProperty("edu.stanford.ejalbert.preferred.browser", null);
/*     */       
/*     */ 
/* 671 */       if (browserName != null) {
/* 672 */         Map browserMap = getBrowserMap();
/* 673 */         WindowsBrowser winBrowser = (WindowsBrowser)browserMap.get(browserName);
/*     */         
/* 675 */         if (winBrowser != null) {
/* 676 */           this.logger.debug("using browser from system property");
/* 677 */           successfullSystemPropLaunch = openUrlWithBrowser(winBrowser, protocol, urlString);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 683 */       if (!successfullSystemPropLaunch) {
/* 684 */         String[] args = getCommandArgs(protocol, urlString);
/*     */         
/* 686 */         if (this.logger.isDebugEnabled()) {
/* 687 */           this.logger.debug(getArrayAsString(args));
/*     */         }
/* 689 */         Process process = Runtime.getRuntime().exec(args);
/*     */         
/*     */ 
/* 692 */         process.waitFor();
/* 693 */         process.exitValue();
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 697 */       this.logger.error("fatal exception", e);
/* 698 */       throw new BrowserLaunchingExecutionException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openUrl(String browser, String urlString)
/*     */     throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException
/*     */   {
/* 719 */     if (("Default".equals(browser)) || (browser == null))
/*     */     {
/* 721 */       this.logger.info("default or null browser target; falling through to non-targetted openUrl");
/*     */       
/* 723 */       openUrl(urlString);
/*     */     }
/*     */     else {
/* 726 */       Map browserMap = getBrowserMap();
/* 727 */       WindowsBrowser winBrowser = (WindowsBrowser)browserMap.get(browser);
/* 728 */       if (winBrowser == null) {
/* 729 */         this.logger.info("the available browsers list does not contain: " + browser);
/*     */         
/* 731 */         this.logger.info("falling through to non-targetted openUrl");
/* 732 */         openUrl(urlString);
/*     */       }
/*     */       else {
/* 735 */         String protocol = null;
/*     */         try {
/* 737 */           protocol = getProtocol(urlString);
/*     */         }
/*     */         catch (MalformedURLException malrulex) {
/* 740 */           throw new BrowserLaunchingExecutionException(malrulex);
/*     */         }
/* 742 */         boolean successfullLaunch = openUrlWithBrowser(winBrowser, protocol, urlString);
/*     */         
/*     */ 
/*     */ 
/* 746 */         if (!successfullLaunch) {
/* 747 */           this.logger.debug("falling through to non-targetted openUrl");
/* 748 */           openUrl(urlString);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openUrl(List browsers, String urlString)
/*     */     throws UnsupportedOperatingSystemException, BrowserLaunchingExecutionException, BrowserLaunchingInitializingException
/*     */   {
/* 775 */     if ((browsers == null) || (browsers.isEmpty())) {
/* 776 */       this.logger.debug("falling through to non-targetted openUrl");
/* 777 */       openUrl(urlString);
/*     */     }
/*     */     else {
/* 780 */       String protocol = null;
/*     */       try {
/* 782 */         protocol = getProtocol(urlString);
/*     */       }
/*     */       catch (MalformedURLException malrulex) {
/* 785 */         throw new BrowserLaunchingExecutionException(malrulex);
/*     */       }
/* 787 */       Map browserMap = getBrowserMap();
/* 788 */       boolean success = false;
/* 789 */       Iterator iter = browsers.iterator();
/* 790 */       while ((iter.hasNext()) && (!success)) {
/* 791 */         WindowsBrowser winBrowser = (WindowsBrowser)browserMap.get(iter.next());
/*     */         
/* 793 */         if (winBrowser != null) {
/* 794 */           success = openUrlWithBrowser(winBrowser, protocol, urlString);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 799 */       if (!success) {
/* 800 */         this.logger.debug("none of listed browsers succeeded; falling through to non-targetted openUrl");
/*     */         
/* 802 */         openUrl(urlString);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getBrowserList()
/*     */   {
/* 815 */     Map browserMap = getBrowserMap();
/* 816 */     List browsers = new ArrayList();
/* 817 */     browsers.add("Default");
/*     */     
/* 819 */     Iterator iter = browserMap.keySet().iterator();
/* 820 */     while (iter.hasNext()) {
/* 821 */       String key = (String)iter.next();
/* 822 */       WindowsBrowser winBrowser = (WindowsBrowser)browserMap.get(key);
/* 823 */       if (key.equals(winBrowser.getBrowserDisplayName())) {
/* 824 */         browsers.add(winBrowser.getBrowserDisplayName());
/*     */       }
/*     */     }
/* 827 */     return browsers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getNewWindowPolicy()
/*     */   {
/* 846 */     return this.forceNewWindow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNewWindowPolicy(boolean forceNewWindow)
/*     */   {
/* 855 */     this.forceNewWindow = forceNewWindow;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/launching/windows/WindowsBrowserLaunching.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */