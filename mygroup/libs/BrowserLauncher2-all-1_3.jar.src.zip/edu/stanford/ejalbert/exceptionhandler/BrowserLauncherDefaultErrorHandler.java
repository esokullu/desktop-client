/*    */ package edu.stanford.ejalbert.exceptionhandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BrowserLauncherDefaultErrorHandler
/*    */   implements BrowserLauncherErrorHandler
/*    */ {
/*    */   public void handleException(Exception ex)
/*    */   {
/* 42 */     ex.printStackTrace();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/exceptionhandler/BrowserLauncherDefaultErrorHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */