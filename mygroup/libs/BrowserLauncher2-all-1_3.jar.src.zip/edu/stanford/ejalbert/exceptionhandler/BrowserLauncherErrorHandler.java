package edu.stanford.ejalbert.exceptionhandler;

public abstract interface BrowserLauncherErrorHandler
{
  public abstract void handleException(Exception paramException);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/edu/stanford/ejalbert/exceptionhandler/BrowserLauncherErrorHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */