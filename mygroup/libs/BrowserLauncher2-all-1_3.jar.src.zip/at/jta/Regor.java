/*     */ package at.jta;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Regor
/*     */ {
/*     */   public static final int HKEY_CLASSES_ROOT = Integer.MIN_VALUE;
/*     */   public static final int HKEY_CURRENT_USER = -2147483647;
/*     */   public static final int HKEY_LOCAL_MACHINE = -2147483646;
/*     */   public static final int ERROR_SUCCESS = 0;
/*     */   public static final int ERROR_FILE_NOT_FOUND = 2;
/*     */   public static final int ERROR_ACCESS_DENIED = 5;
/*     */   public static final int NATIVE_HANDLE = 0;
/*     */   public static final int ERROR_CODE = 1;
/*     */   public static final int SUBKEYS_NUMBER = 0;
/*     */   public static final int VALUES_NUMBER = 2;
/*     */   public static final int MAX_KEY_LENGTH = 3;
/*     */   public static final int MAX_VALUE_NAME_LENGTH = 4;
/*     */   public static final int DELETE = 65536;
/*     */   public static final int KEY_QUERY_VALUE = 1;
/*     */   public static final int KEY_SET_VALUE = 2;
/*     */   public static final int KEY_CREATE_SUB_KEY = 4;
/*     */   public static final int KEY_ENUMERATE_SUB_KEYS = 8;
/*     */   public static final int KEY_READ = 131097;
/*     */   public static final int KEY_WRITE = 131078;
/*     */   public static final int KEY_ALL_ACCESS = 983103;
/*  87 */   private Method openKey = null;
/*  88 */   private Method closeKey = null;
/*  89 */   private Method delKey = null;
/*  90 */   private Method createKey = null;
/*  91 */   private Method flushKey = null;
/*  92 */   private Method queryValue = null;
/*  93 */   private Method setValue = null;
/*  94 */   private Method delValue = null;
/*  95 */   private Method queryInfoKey = null;
/*  96 */   private Method enumKey = null;
/*  97 */   private Method enumValue = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Regor()
/*     */     throws RegistryErrorException
/*     */   {
/* 106 */     checkOS();
/* 107 */     initMethods();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkOS()
/*     */   {
/* 115 */     String str = System.getProperty("os.name");
/* 116 */     if ((str == null) || (str.toLowerCase().indexOf("windows") == -1)) {
/* 117 */       throw new NotSupportedOSException("Operating system: " + str + " is not supported!");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] enumValueName(int key, int valueNameIndex, int maxValueNameLength)
/*     */     throws RegistryErrorException
/*     */   {
/*     */     try
/*     */     {
/* 135 */       return (byte[])this.enumValue.invoke(null, new Object[] { new Integer(key), new Integer(valueNameIndex), new Integer(maxValueNameLength) });
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 139 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 143 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 147 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List listValueNames(int key, String subkey)
/*     */     throws RegistryErrorException
/*     */   {
/* 160 */     int handle = -1;
/*     */     try {
/* 162 */       handle = openKey(key, subkey, 131097);
/* 163 */       if (handle != -1)
/*     */       {
/* 165 */         int[] info = getChildInformation(handle);
/* 166 */         if ((info != null) && (info[0] != -1))
/*     */         {
/* 168 */           List ret = new ArrayList();
/* 169 */           for (int x = 0; x != info[2]; x++)
/*     */           {
/* 171 */             String tmp = parseValue(enumValueName(handle, x, info[4] + 1));
/* 172 */             if (tmp != null)
/* 173 */               ret.add(tmp);
/*     */           }
/* 175 */           return ret.isEmpty() ? null : ret;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (RegistryErrorException ex)
/*     */     {
/* 181 */       throw ex;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 185 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     finally {
/* 188 */       closeKey(handle);
/*     */     }
/* 190 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List listValueNames(int key)
/*     */     throws RegistryErrorException
/*     */   {
/* 201 */     return listValueNames(key, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] enumKeys(int key, int subkeyIndex, int maxKeyNameLength)
/*     */     throws RegistryErrorException
/*     */   {
/*     */     try
/*     */     {
/* 219 */       return (byte[])this.enumKey.invoke(null, new Object[] { new Integer(key), new Integer(subkeyIndex), new Integer(maxKeyNameLength) });
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 223 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 227 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 231 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List listKeys(int key, String subkey)
/*     */     throws RegistryErrorException
/*     */   {
/* 244 */     int handle = -1;
/*     */     try {
/* 246 */       handle = openKey(key, subkey, 131097);
/* 247 */       if (handle != -1)
/*     */       {
/* 249 */         int[] info = getChildInformation(handle);
/* 250 */         if ((info != null) && (info[0] != -1))
/*     */         {
/* 252 */           List ret = new ArrayList();
/* 253 */           for (int x = 0; x != info[0]; x++)
/*     */           {
/* 255 */             String tmp = parseValue(enumKeys(handle, x, info[3] + 1));
/* 256 */             if (tmp != null)
/* 257 */               ret.add(tmp);
/*     */           }
/* 259 */           return ret.isEmpty() ? null : ret;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (RegistryErrorException ex)
/*     */     {
/* 265 */       throw ex;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 269 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     finally {
/* 272 */       closeKey(handle);
/*     */     }
/* 274 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List listKeys(int key)
/*     */     throws RegistryErrorException
/*     */   {
/* 285 */     return listKeys(key, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int[] getChildInformation(int key)
/*     */     throws RegistryErrorException
/*     */   {
/*     */     try
/*     */     {
/* 304 */       return (int[])this.queryInfoKey.invoke(null, new Object[] { new Integer(key) });
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 308 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 312 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 316 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int delValue(int key, String valueName)
/*     */     throws RegistryErrorException
/*     */   {
/*     */     try
/*     */     {
/* 332 */       Integer ret = (Integer)this.delValue.invoke(null, new Object[] { new Integer(key), getString(valueName) });
/* 333 */       if (ret != null) {
/* 334 */         return ret.intValue();
/*     */       }
/* 336 */       return -1;
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 340 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 344 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 348 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int setValue(int key, String valueName, String value)
/*     */     throws RegistryErrorException
/*     */   {
/*     */     try
/*     */     {
/* 366 */       Integer ret = (Integer)this.setValue.invoke(null, new Object[] { new Integer(key), getString(valueName), getString(value) });
/* 367 */       if (ret != null) {
/* 368 */         return ret.intValue();
/*     */       }
/* 370 */       return -1;
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 374 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 378 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 382 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] readValue(int key, String valueName)
/*     */     throws RegistryErrorException
/*     */   {
/*     */     try
/*     */     {
/* 399 */       return (byte[])this.queryValue.invoke(null, new Object[] { new Integer(key), getString(valueName) });
/*     */ 
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 404 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 408 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 412 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int flushKey(int key)
/*     */     throws RegistryErrorException
/*     */   {
/*     */     try
/*     */     {
/* 426 */       Integer ret = (Integer)this.flushKey.invoke(null, new Object[] { new Integer(key) });
/* 427 */       if (ret != null) {
/* 428 */         return ret.intValue();
/*     */       }
/* 430 */       return -1;
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 434 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 438 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 442 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int delKey(int key, String subkey)
/*     */     throws RegistryErrorException
/*     */   {
/* 455 */     if ((subkey == null) || (subkey.length() == 0)) {
/* 456 */       throw new RegistryErrorException("subkey cannot be null");
/*     */     }
/*     */     try {
/* 459 */       Integer ret = (Integer)this.delKey.invoke(null, new Object[] { new Integer(key), getString(subkey) });
/* 460 */       if (ret != null) {
/* 461 */         return ret.intValue();
/*     */       }
/* 463 */       return -1;
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 467 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 471 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 475 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int createKey(int key, String subkey)
/*     */     throws RegistryErrorException
/*     */   {
/*     */     try
/*     */     {
/* 492 */       int[] result = (int[])this.createKey.invoke(null, new Object[] { new Integer(key), getString(subkey) });
/* 493 */       if (result[1] == 0) {
/* 494 */         return result[0];
/*     */       }
/* 496 */       return -1;
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 500 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 504 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 508 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int closeKey(int key)
/*     */     throws RegistryErrorException
/*     */   {
/*     */     try
/*     */     {
/* 524 */       Integer ret = (Integer)this.closeKey.invoke(null, new Object[] { new Integer(key) });
/* 525 */       if (ret != null) {
/* 526 */         return ret.intValue();
/*     */       }
/* 528 */       return -1;
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 532 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 536 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 540 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int openKey(int key, String subkey, int security_mask)
/*     */     throws RegistryErrorException
/*     */   {
/*     */     try
/*     */     {
/* 557 */       int[] result = (int[])this.openKey.invoke(null, new Object[] { new Integer(key), getString(subkey), new Integer(security_mask) });
/* 558 */       if ((result == null) || (result[1] != 0)) {
/* 559 */         return -1;
/*     */       }
/* 561 */       return result[0];
/*     */     }
/*     */     catch (InvocationTargetException ex1)
/*     */     {
/* 565 */       throw new RegistryErrorException(ex1.getMessage());
/*     */     }
/*     */     catch (IllegalArgumentException ex1)
/*     */     {
/* 569 */       throw new RegistryErrorException(ex1.getMessage());
/*     */     }
/*     */     catch (IllegalAccessException ex1)
/*     */     {
/* 573 */       throw new RegistryErrorException(ex1.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int openKey(int key, String subkey)
/*     */     throws RegistryErrorException
/*     */   {
/* 588 */     return openKey(key, subkey, 983103);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] getString(String str)
/*     */   {
/* 598 */     if (str == null)
/* 599 */       str = "";
/* 600 */     return (str += "\000").getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String parseValue(byte[] buf)
/*     */   {
/* 610 */     if (buf == null)
/* 611 */       return null;
/* 612 */     String ret = new String(buf);
/* 613 */     if (ret.charAt(ret.length() - 1) == 0)
/* 614 */       return ret.substring(0, ret.length() - 1);
/* 615 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initMethods()
/*     */     throws RegistryErrorException
/*     */   {
/* 626 */     Class clazz = null;
/*     */     try
/*     */     {
/* 629 */       clazz = Class.forName("java.util.prefs.WindowsPreferences");
/*     */       
/* 631 */       Method[] ms = clazz.getDeclaredMethods();
/* 632 */       if (ms == null) {
/* 633 */         throw new RegistryErrorException("Cannot access java.util.prefs.WindowsPreferences class!");
/*     */       }
/* 635 */       for (int x = 0; x != ms.length; x++)
/*     */       {
/* 637 */         if (ms[x] != null)
/*     */         {
/* 639 */           if (ms[x].getName().equals("WindowsRegOpenKey"))
/*     */           {
/* 641 */             this.openKey = ms[x];
/* 642 */             this.openKey.setAccessible(true);
/*     */           }
/* 644 */           else if (ms[x].getName().equals("WindowsRegCloseKey"))
/*     */           {
/* 646 */             this.closeKey = ms[x];
/* 647 */             this.closeKey.setAccessible(true);
/*     */           }
/* 649 */           else if (ms[x].getName().equals("WindowsRegCreateKeyEx"))
/*     */           {
/* 651 */             this.createKey = ms[x];
/* 652 */             this.createKey.setAccessible(true);
/*     */           }
/* 654 */           else if (ms[x].getName().equals("WindowsRegDeleteKey"))
/*     */           {
/* 656 */             this.delKey = ms[x];
/* 657 */             this.delKey.setAccessible(true);
/*     */           }
/* 659 */           else if (ms[x].getName().equals("WindowsRegFlushKey"))
/*     */           {
/* 661 */             this.flushKey = ms[x];
/* 662 */             this.flushKey.setAccessible(true);
/*     */           }
/* 664 */           else if (ms[x].getName().equals("WindowsRegQueryValueEx"))
/*     */           {
/* 666 */             this.queryValue = ms[x];
/* 667 */             this.queryValue.setAccessible(true);
/*     */           }
/* 669 */           else if (ms[x].getName().equals("WindowsRegSetValueEx"))
/*     */           {
/* 671 */             this.setValue = ms[x];
/* 672 */             this.setValue.setAccessible(true);
/*     */           }
/* 674 */           else if (ms[x].getName().equals("WindowsRegDeleteValue"))
/*     */           {
/* 676 */             this.delValue = ms[x];
/* 677 */             this.delValue.setAccessible(true);
/*     */           }
/* 679 */           else if (ms[x].getName().equals("WindowsRegQueryInfoKey"))
/*     */           {
/* 681 */             this.queryInfoKey = ms[x];
/* 682 */             this.queryInfoKey.setAccessible(true);
/*     */           }
/* 684 */           else if (ms[x].getName().equals("WindowsRegEnumKeyEx"))
/*     */           {
/* 686 */             this.enumKey = ms[x];
/* 687 */             this.enumKey.setAccessible(true);
/*     */           }
/* 689 */           else if (ms[x].getName().equals("WindowsRegEnumValue"))
/*     */           {
/* 691 */             this.enumValue = ms[x];
/* 692 */             this.enumValue.setAccessible(true);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/* 699 */       throw new RegistryErrorException(ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/* 711 */     Regor regor = new Regor();
/*     */     
/* 713 */     int key = regor.openKey(-2147483646, "Software\\Microsoft");int key2 = -1;
/*     */     
/* 715 */     List l = regor.listKeys(key);
/* 716 */     System.out.println("SOME KEYS....");
/* 717 */     for (int x = 0; (l != null) && (x != l.size()); x++)
/* 718 */       System.out.println(x + " == " + l.get(x));
/* 719 */     if (l.size() > 0)
/* 720 */       key2 = regor.openKey(key, (String)l.get(0));
/* 721 */     l = regor.listValueNames(key2);
/* 722 */     System.out.println("SOME VALUENAMES.....");
/* 723 */     for (int x = 0; (l != null) && (x != l.size()); x++)
/* 724 */       System.out.println(x + " == " + l.get(x));
/* 725 */     System.out.println("SOME STRING VALUES....");
/* 726 */     for (int x = 0; (l != null) && (x != l.size()); x++)
/*     */     {
/* 728 */       byte[] buf = regor.readValue(key2, (String)l.get(x));
/* 729 */       System.out.println(x + ": " + l.get(x) + " == " + parseValue(buf));
/*     */     }
/*     */     
/* 732 */     System.out.println("default entry == " + parseValue(regor.readValue(key, null)));
/*     */     
/* 734 */     l = regor.listKeys(-2147483646);
/* 735 */     System.out.println("KEYS FROM LOCAL_MACHINE....");
/* 736 */     for (int x = 0; (l != null) && (x != l.size()); x++)
/* 737 */       System.out.println(x + " == " + l.get(x));
/* 738 */     regor.closeKey(key2);
/* 739 */     regor.closeKey(key);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/at/jta/Regor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */