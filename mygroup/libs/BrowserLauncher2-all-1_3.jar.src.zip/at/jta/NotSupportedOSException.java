/*    */ package at.jta;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotSupportedOSException
/*    */   extends RuntimeException
/*    */ {
/*    */   public NotSupportedOSException(String str)
/*    */   {
/* 26 */     super(str);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/at/jta/NotSupportedOSException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */