/*    */ package at.jta;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegistryErrorException
/*    */   extends IOException
/*    */ {
/*    */   public RegistryErrorException(String reason)
/*    */   {
/* 29 */     super(reason);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/BrowserLauncher2-all-1_3.jar!/at/jta/RegistryErrorException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */