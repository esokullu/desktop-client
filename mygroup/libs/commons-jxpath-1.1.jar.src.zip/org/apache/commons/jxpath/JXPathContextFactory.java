/*     */ package org.apache.commons.jxpath;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JXPathContextFactory
/*     */ {
/*     */   public static final String FACTORY_NAME_PROPERTY = "org.apache.commons.jxpath.JXPathContextFactory";
/*     */   private static final String DEFAULT_FACTORY_CLASS = "org.apache.commons.jxpath.ri.JXPathContextFactoryReferenceImpl";
/*     */   
/*     */   public static JXPathContextFactory newInstance()
/*     */   {
/* 138 */     String factoryImplName = findFactory("org.apache.commons.jxpath.JXPathContextFactory", "org.apache.commons.jxpath.ri.JXPathContextFactoryReferenceImpl");
/*     */     
/*     */ 
/* 141 */     if (factoryImplName == null) {
/* 142 */       throw new JXPathContextFactoryConfigurationError("No default implementation found");
/*     */     }
/*     */     
/*     */     JXPathContextFactory factoryImpl;
/*     */     try
/*     */     {
/* 148 */       Class clazz = Class.forName(factoryImplName);
/* 149 */       factoryImpl = (JXPathContextFactory)clazz.newInstance();
/*     */     }
/*     */     catch (ClassNotFoundException cnfe) {
/* 152 */       throw new JXPathContextFactoryConfigurationError(cnfe);
/*     */     }
/*     */     catch (IllegalAccessException iae) {
/* 155 */       throw new JXPathContextFactoryConfigurationError(iae);
/*     */     }
/*     */     catch (InstantiationException ie) {
/* 158 */       throw new JXPathContextFactoryConfigurationError(ie);
/*     */     }
/* 160 */     return factoryImpl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 184 */   private static String foundFactory = null;
/*     */   
/*     */ 
/*     */ 
/* 188 */   private static boolean debug = false;
/*     */   
/*     */   static {
/* 191 */     try { debug = System.getProperty("jxpath.debug") != null;
/*     */     }
/*     */     catch (SecurityException se) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String findFactory(String property, String defaultFactory)
/*     */   {
/*     */     try
/*     */     {
/* 208 */       String systemProp = System.getProperty(property);
/* 209 */       if (systemProp != null) {
/* 210 */         if (debug) {
/* 211 */           System.err.println("JXPath: found system property" + systemProp);
/*     */         }
/*     */         
/* 214 */         return systemProp;
/*     */       }
/*     */     }
/*     */     catch (SecurityException se) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 222 */     if (foundFactory != null) {
/* 223 */       return foundFactory;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 228 */       String systemProp = System.getProperty(property);
/* 229 */       if (systemProp != null) {
/* 230 */         if (debug) {
/* 231 */           System.err.println("JXPath: found system property" + systemProp);
/*     */         }
/*     */         
/* 234 */         return systemProp;
/*     */       }
/*     */     }
/*     */     catch (SecurityException se) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 244 */       String javah = System.getProperty("java.home");
/* 245 */       String configFile = javah + File.separator + "lib" + File.separator + "jxpath.properties";
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 251 */       File f = new File(configFile);
/* 252 */       if (f.exists()) {
/* 253 */         Properties props = new Properties();
/* 254 */         props.load(new FileInputStream(f));
/* 255 */         foundFactory = props.getProperty(property);
/* 256 */         if (debug) {
/* 257 */           System.err.println("JXPath: found java.home property " + foundFactory);
/*     */         }
/*     */         
/* 260 */         if (foundFactory != null) {
/* 261 */           return foundFactory;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 266 */       if (debug) {
/* 267 */         ex.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/* 271 */     String serviceId = "META-INF/services/" + property;
/*     */     try
/*     */     {
/* 274 */       ClassLoader cl = JXPathContextFactory.class.getClassLoader();
/* 275 */       InputStream is = null;
/* 276 */       if (cl == null) {
/* 277 */         is = ClassLoader.getSystemResourceAsStream(serviceId);
/*     */       }
/*     */       else {
/* 280 */         is = cl.getResourceAsStream(serviceId);
/*     */       }
/*     */       
/* 283 */       if (is != null) {
/* 284 */         if (debug) {
/* 285 */           System.err.println("JXPath: found  " + serviceId);
/*     */         }
/* 287 */         BufferedReader rd = new BufferedReader(new InputStreamReader(is));
/*     */         
/*     */ 
/* 290 */         foundFactory = rd.readLine();
/* 291 */         rd.close();
/*     */         
/* 293 */         if (debug) {
/* 294 */           System.err.println("JXPath: loaded from services: " + foundFactory);
/*     */         }
/*     */         
/* 297 */         if ((foundFactory != null) && (!"".equals(foundFactory))) {
/* 298 */           return foundFactory;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 303 */       if (debug) {
/* 304 */         ex.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/* 308 */     return defaultFactory;
/*     */   }
/*     */   
/*     */   public abstract JXPathContext newContext(JXPathContext paramJXPathContext, Object paramObject)
/*     */     throws JXPathContextFactoryConfigurationError;
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/JXPathContextFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */