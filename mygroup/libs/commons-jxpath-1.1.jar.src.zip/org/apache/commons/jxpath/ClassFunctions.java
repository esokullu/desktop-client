/*     */ package org.apache.commons.jxpath;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.jxpath.functions.ConstructorFunction;
/*     */ import org.apache.commons.jxpath.functions.MethodFunction;
/*     */ import org.apache.commons.jxpath.util.MethodLookupUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassFunctions
/*     */   implements Functions
/*     */ {
/*     */   private Class functionClass;
/*     */   private String namespace;
/* 102 */   private static final Object[] EMPTY_ARRAY = new Object[0];
/*     */   
/*     */   public ClassFunctions(Class functionClass, String namespace) {
/* 105 */     this.functionClass = functionClass;
/* 106 */     this.namespace = namespace;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set getUsedNamespaces()
/*     */   {
/* 115 */     return Collections.singleton(this.namespace);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Function getFunction(String namespace, String name, Object[] parameters)
/*     */   {
/* 134 */     if (!namespace.equals(this.namespace)) {
/* 135 */       return null;
/*     */     }
/*     */     
/* 138 */     if (parameters == null) {
/* 139 */       parameters = EMPTY_ARRAY;
/*     */     }
/*     */     
/* 142 */     if (name.equals("new")) {
/* 143 */       Constructor constructor = MethodLookupUtils.lookupConstructor(this.functionClass, parameters);
/*     */       
/* 145 */       if (constructor != null) {
/* 146 */         return new ConstructorFunction(constructor);
/*     */       }
/*     */     }
/*     */     else {
/* 150 */       Method method = MethodLookupUtils.lookupStaticMethod(this.functionClass, name, parameters);
/*     */       
/* 152 */       if (method != null) {
/* 153 */         return new MethodFunction(method);
/*     */       }
/*     */       
/* 156 */       method = MethodLookupUtils.lookupMethod(this.functionClass, name, parameters);
/*     */       
/* 158 */       if (method != null) {
/* 159 */         return new MethodFunction(method);
/*     */       }
/*     */     }
/*     */     
/* 163 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ClassFunctions.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */