package org.apache.commons.jxpath;

import java.util.Iterator;

public abstract interface CompiledExpression
{
  public abstract Object getValue(JXPathContext paramJXPathContext);
  
  public abstract Object getValue(JXPathContext paramJXPathContext, Class paramClass);
  
  public abstract void setValue(JXPathContext paramJXPathContext, Object paramObject);
  
  public abstract Pointer createPath(JXPathContext paramJXPathContext);
  
  public abstract Pointer createPathAndSetValue(JXPathContext paramJXPathContext, Object paramObject);
  
  public abstract Iterator iterate(JXPathContext paramJXPathContext);
  
  public abstract Pointer getPointer(JXPathContext paramJXPathContext, String paramString);
  
  public abstract Iterator iteratePointers(JXPathContext paramJXPathContext);
  
  public abstract void removePath(JXPathContext paramJXPathContext);
  
  public abstract void removeAll(JXPathContext paramJXPathContext);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/CompiledExpression.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */