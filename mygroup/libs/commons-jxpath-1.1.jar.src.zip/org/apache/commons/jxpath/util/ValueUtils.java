/*     */ package org.apache.commons.jxpath.util;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.beans.IndexedPropertyDescriptor;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.AbstractList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.jxpath.Container;
/*     */ import org.apache.commons.jxpath.DynamicPropertyHandler;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValueUtils
/*     */ {
/*  88 */   private static Map dynamicPropertyHandlerMap = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean isCollection(Object value)
/*     */   {
/*  94 */     if (value == null) {
/*  95 */       return false;
/*     */     }
/*  97 */     if (value.getClass().isArray()) {
/*  98 */       return true;
/*     */     }
/* 100 */     if ((value instanceof Collection)) {
/* 101 */       return true;
/*     */     }
/* 103 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getCollectionHint(Class clazz)
/*     */   {
/* 112 */     if (clazz.isArray()) {
/* 113 */       return 1;
/*     */     }
/*     */     
/* 116 */     if (Collection.class.isAssignableFrom(clazz)) {
/* 117 */       return 1;
/*     */     }
/*     */     
/* 120 */     if (clazz.isPrimitive()) {
/* 121 */       return -1;
/*     */     }
/*     */     
/* 124 */     if (clazz.isInterface()) {
/* 125 */       return 0;
/*     */     }
/*     */     
/* 128 */     if (Modifier.isFinal(clazz.getModifiers())) {
/* 129 */       return -1;
/*     */     }
/*     */     
/* 132 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getLength(Object collection)
/*     */   {
/* 140 */     if (collection == null) {
/* 141 */       return 0;
/*     */     }
/* 143 */     if (collection.getClass().isArray()) {
/* 144 */       return Array.getLength(collection);
/*     */     }
/* 146 */     if ((collection instanceof Collection)) {
/* 147 */       return ((Collection)collection).size();
/*     */     }
/*     */     
/* 150 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Iterator iterate(Object collection)
/*     */   {
/* 160 */     if (collection == null) {
/* 161 */       return Collections.EMPTY_LIST.iterator();
/*     */     }
/* 163 */     if (collection.getClass().isArray()) {
/* 164 */       int length = Array.getLength(collection);
/* 165 */       if (length == 0) {
/* 166 */         return Collections.EMPTY_LIST.iterator();
/*     */       }
/* 168 */       ArrayList list = new ArrayList();
/* 169 */       for (int i = 0; i < length; i++) {
/* 170 */         list.add(Array.get(collection, i));
/*     */       }
/* 172 */       return list.iterator();
/*     */     }
/* 174 */     if ((collection instanceof Collection)) {
/* 175 */       return ((Collection)collection).iterator();
/*     */     }
/*     */     
/* 178 */     return Collections.singletonList(collection).iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object expandCollection(Object collection, int size)
/*     */   {
/* 187 */     if (collection == null) {
/* 188 */       return null;
/*     */     }
/* 190 */     if (collection.getClass().isArray()) {
/* 191 */       Object bigger = Array.newInstance(collection.getClass().getComponentType(), size);
/*     */       
/*     */ 
/*     */ 
/* 195 */       System.arraycopy(collection, 0, bigger, 0, Array.getLength(collection));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 201 */       return bigger;
/*     */     }
/* 203 */     if ((collection instanceof Collection)) {
/* 204 */       while (((Collection)collection).size() < size) {
/* 205 */         ((Collection)collection).add(null);
/*     */       }
/* 207 */       return collection;
/*     */     }
/*     */     
/* 210 */     throw new JXPathException("Cannot turn " + collection.getClass().getName() + " into a collection of size " + size);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object remove(Object collection, int index)
/*     */   {
/* 222 */     collection = openContainers(collection);
/* 223 */     if (collection == null) {
/* 224 */       return null;
/*     */     }
/* 226 */     if (collection.getClass().isArray()) {
/* 227 */       int length = Array.getLength(collection);
/* 228 */       Object smaller = Array.newInstance(collection.getClass().getComponentType(), length - 1);
/*     */       
/*     */ 
/*     */ 
/* 232 */       if (index > 0) {
/* 233 */         System.arraycopy(collection, 0, smaller, 0, index);
/*     */       }
/* 235 */       if (index < length - 1) {
/* 236 */         System.arraycopy(collection, index + 1, smaller, index, length - index - 1);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 243 */       return smaller;
/*     */     }
/* 245 */     if ((collection instanceof List)) {
/* 246 */       int size = ((List)collection).size();
/* 247 */       if (index < size) {
/* 248 */         ((List)collection).remove(index);
/*     */       }
/* 250 */       return collection;
/*     */     }
/* 252 */     if ((collection instanceof Collection)) {
/* 253 */       Iterator it = ((Collection)collection).iterator();
/* 254 */       for (int i = 0; i < index; i++) {
/* 255 */         if (!it.hasNext()) {
/*     */           break;
/*     */         }
/* 258 */         it.next();
/*     */       }
/* 260 */       if (it.hasNext()) {
/* 261 */         it.next();
/* 262 */         it.remove();
/*     */       }
/* 264 */       return collection;
/*     */     }
/*     */     
/* 267 */     throw new JXPathException("Cannot remove " + collection.getClass().getName() + "[" + index + "]");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getValue(Object collection, int index)
/*     */   {
/* 280 */     collection = openContainers(collection);
/* 281 */     Object value = collection;
/* 282 */     if (collection != null) {
/* 283 */       if (collection.getClass().isArray()) {
/* 284 */         if ((index < 0) || (index >= Array.getLength(collection))) {
/* 285 */           return null;
/*     */         }
/* 287 */         value = Array.get(collection, index);
/*     */       }
/* 289 */       else if ((collection instanceof List)) {
/* 290 */         if ((index < 0) || (index >= ((List)collection).size())) {
/* 291 */           return null;
/*     */         }
/* 293 */         value = ((List)collection).get(index);
/*     */       }
/* 295 */       else if ((collection instanceof Collection)) {
/* 296 */         int i = 0;
/* 297 */         Iterator it = ((Collection)collection).iterator();
/* 298 */         for (; i < index; i++) {
/* 299 */           it.next();
/*     */         }
/* 301 */         if (it.hasNext()) {
/* 302 */           value = it.next();
/*     */         }
/*     */         else {
/* 305 */           value = null;
/*     */         }
/*     */       }
/*     */     }
/* 309 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setValue(Object collection, int index, Object value)
/*     */   {
/* 317 */     collection = openContainers(collection);
/* 318 */     if (collection != null) {
/* 319 */       if (collection.getClass().isArray()) {
/* 320 */         Array.set(collection, index, convert(value, collection.getClass().getComponentType()));
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 325 */       else if ((collection instanceof List)) {
/* 326 */         ((List)collection).set(index, value);
/*     */       }
/* 328 */       else if ((collection instanceof Collection)) {
/* 329 */         throw new UnsupportedOperationException("Cannot set value of an element of a " + collection.getClass().getName());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getValue(Object bean, PropertyDescriptor propertyDescriptor)
/*     */   {
/*     */     Object value;
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 346 */       Method method = getAccessibleMethod(propertyDescriptor.getReadMethod());
/*     */       
/* 348 */       if (method == null) {
/* 349 */         throw new JXPathException("No read method");
/*     */       }
/* 351 */       value = method.invoke(bean, new Object[0]);
/*     */     }
/*     */     catch (Exception ex) {
/* 354 */       throw new JXPathException("Cannot access property: " + (bean == null ? "null" : bean.getClass().getName()) + "." + propertyDescriptor.getName(), ex);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 361 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setValue(Object bean, PropertyDescriptor propertyDescriptor, Object value)
/*     */   {
/*     */     try
/*     */     {
/* 374 */       Method method = getAccessibleMethod(propertyDescriptor.getWriteMethod());
/*     */       
/* 376 */       if (method == null) {
/* 377 */         throw new JXPathException("No write method");
/*     */       }
/* 379 */       value = convert(value, propertyDescriptor.getPropertyType());
/* 380 */       value = method.invoke(bean, new Object[] { value });
/*     */     }
/*     */     catch (Exception ex) {
/* 383 */       throw new JXPathException("Cannot modify property: " + (bean == null ? "null" : bean.getClass().getName()) + "." + propertyDescriptor.getName(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object convert(Object value, Class type)
/*     */   {
/*     */     try
/*     */     {
/* 394 */       return TypeUtils.convert(value, type);
/*     */     }
/*     */     catch (Exception ex) {
/* 397 */       throw new JXPathException("Cannot convert value of class " + (value == null ? "null" : value.getClass().getName()) + " to type " + type, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getValue(Object bean, PropertyDescriptor propertyDescriptor, int index)
/*     */   {
/* 415 */     if ((propertyDescriptor instanceof IndexedPropertyDescriptor)) {
/*     */       try {
/* 417 */         IndexedPropertyDescriptor ipd = (IndexedPropertyDescriptor)propertyDescriptor;
/*     */         
/* 419 */         Method method = ipd.getIndexedReadMethod();
/* 420 */         if (method != null) {
/* 421 */           return method.invoke(bean, new Object[] { new Integer(index) });
/*     */         }
/*     */         
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 427 */         throw new JXPathException("Cannot access property: " + propertyDescriptor.getName(), ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 435 */     return getValue(getValue(bean, propertyDescriptor), index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setValue(Object bean, PropertyDescriptor propertyDescriptor, int index, Object value)
/*     */   {
/* 449 */     if ((propertyDescriptor instanceof IndexedPropertyDescriptor)) {
/*     */       try {
/* 451 */         IndexedPropertyDescriptor ipd = (IndexedPropertyDescriptor)propertyDescriptor;
/*     */         
/* 453 */         Method method = ipd.getIndexedWriteMethod();
/* 454 */         if (method != null) {
/* 455 */           method.invoke(bean, new Object[] { new Integer(index), convert(value, ipd.getIndexedPropertyType()) });
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 460 */           return;
/*     */         }
/*     */       }
/*     */       catch (Exception ex) {
/* 464 */         ex.printStackTrace();
/* 465 */         throw new RuntimeException("Cannot access property: " + propertyDescriptor.getName() + ", " + ex.getMessage());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 473 */     Object collection = getValue(bean, propertyDescriptor);
/* 474 */     if (isCollection(openContainers(collection))) {
/* 475 */       setValue(collection, index, value);
/*     */     }
/* 477 */     else if (index == 0) {
/* 478 */       setValue(bean, propertyDescriptor, value);
/*     */     }
/*     */     else {
/* 481 */       throw new RuntimeException("Not a collection: " + propertyDescriptor.getName());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object openContainers(Object collection)
/*     */   {
/* 491 */     while ((collection instanceof Container)) {
/* 492 */       collection = ((Container)collection).getValue();
/*     */     }
/* 494 */     return collection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DynamicPropertyHandler getDynamicPropertyHandler(Class clazz)
/*     */   {
/* 503 */     DynamicPropertyHandler handler = (DynamicPropertyHandler)dynamicPropertyHandlerMap.get(clazz);
/*     */     
/* 505 */     if (handler == null) {
/*     */       try {
/* 507 */         handler = (DynamicPropertyHandler)clazz.newInstance();
/*     */       }
/*     */       catch (Exception ex) {
/* 510 */         throw new JXPathException("Cannot allocate dynamic property handler of class " + clazz.getName(), ex);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 515 */       dynamicPropertyHandlerMap.put(clazz, handler);
/*     */     }
/* 517 */     return handler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method getAccessibleMethod(Method method)
/*     */   {
/* 537 */     if (method == null) {
/* 538 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 542 */     if (!Modifier.isPublic(method.getModifiers())) {
/* 543 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 547 */     Class clazz = method.getDeclaringClass();
/* 548 */     if (Modifier.isPublic(clazz.getModifiers())) {
/* 549 */       return method;
/*     */     }
/*     */     
/*     */ 
/* 553 */     method = getAccessibleMethodFromInterfaceNest(clazz, method.getName(), method.getParameterTypes());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 558 */     return method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Method getAccessibleMethodFromInterfaceNest(Class clazz, String methodName, Class[] parameterTypes)
/*     */   {
/* 578 */     Method method = null;
/*     */     
/*     */ 
/* 581 */     Class[] interfaces = clazz.getInterfaces();
/* 582 */     for (int i = 0; i < interfaces.length; i++)
/*     */     {
/*     */ 
/* 585 */       if (Modifier.isPublic(interfaces[i].getModifiers()))
/*     */       {
/*     */ 
/*     */         try
/*     */         {
/*     */ 
/* 591 */           method = interfaces[i].getDeclaredMethod(methodName, parameterTypes);
/*     */         }
/*     */         catch (NoSuchMethodException e) {}
/*     */         
/*     */ 
/*     */ 
/* 597 */         if (method != null) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/* 602 */         method = getAccessibleMethodFromInterfaceNest(interfaces[i], methodName, parameterTypes);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 607 */         if (method != null) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 613 */     return method;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/util/ValueUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */