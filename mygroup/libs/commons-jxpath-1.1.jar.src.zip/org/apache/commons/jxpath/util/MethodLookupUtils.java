/*     */ package org.apache.commons.jxpath.util;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.jxpath.ExpressionContext;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodLookupUtils
/*     */ {
/*     */   private static final int NO_MATCH = 0;
/*     */   private static final int APPROXIMATE_MATCH = 1;
/*     */   private static final int EXACT_MATCH = 2;
/*  84 */   private static final Object[] EMPTY_ARRAY = new Object[0];
/*     */   
/*     */ 
/*     */ 
/*     */   public static Constructor lookupConstructor(Class targetClass, Object[] parameters)
/*     */   {
/*  90 */     boolean tryExact = true;
/*  91 */     int count = parameters.length;
/*  92 */     Class[] types = new Class[count];
/*  93 */     for (int i = 0; i < count; i++) {
/*  94 */       Object param = parameters[i];
/*  95 */       if (param != null) {
/*  96 */         types[i] = param.getClass();
/*     */       }
/*     */       else {
/*  99 */         types[i] = null;
/* 100 */         tryExact = false;
/*     */       }
/*     */     }
/*     */     
/* 104 */     Constructor constructor = null;
/*     */     
/* 106 */     if (tryExact) {
/*     */       try
/*     */       {
/* 109 */         constructor = targetClass.getConstructor(types);
/* 110 */         if (constructor != null) {
/* 111 */           return constructor;
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodException ex) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 119 */     int currentMatch = 0;
/* 120 */     boolean ambiguous = false;
/*     */     
/*     */ 
/* 123 */     Constructor[] constructors = targetClass.getConstructors();
/* 124 */     for (int i = 0; i < constructors.length; i++) {
/* 125 */       int match = matchParameterTypes(constructors[i].getParameterTypes(), parameters);
/*     */       
/*     */ 
/*     */ 
/* 129 */       if (match != 0) {
/* 130 */         if (match > currentMatch) {
/* 131 */           constructor = constructors[i];
/* 132 */           currentMatch = match;
/* 133 */           ambiguous = false;
/*     */         }
/* 135 */         else if (match == currentMatch) {
/* 136 */           ambiguous = true;
/*     */         }
/*     */       }
/*     */     }
/* 140 */     if (ambiguous) {
/* 141 */       throw new JXPathException("Ambigous constructor " + Arrays.asList(parameters));
/*     */     }
/*     */     
/* 144 */     return constructor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method lookupStaticMethod(Class targetClass, String name, Object[] parameters)
/*     */   {
/* 152 */     boolean tryExact = true;
/* 153 */     int count = parameters.length;
/* 154 */     Class[] types = new Class[count];
/* 155 */     for (int i = 0; i < count; i++) {
/* 156 */       Object param = parameters[i];
/* 157 */       if (param != null) {
/* 158 */         types[i] = param.getClass();
/*     */       }
/*     */       else {
/* 161 */         types[i] = null;
/* 162 */         tryExact = false;
/*     */       }
/*     */     }
/*     */     
/* 166 */     Method method = null;
/*     */     
/* 168 */     if (tryExact) {
/*     */       try
/*     */       {
/* 171 */         method = targetClass.getMethod(name, types);
/* 172 */         if ((method != null) && (Modifier.isStatic(method.getModifiers())))
/*     */         {
/* 174 */           return method;
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodException ex) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 182 */     int currentMatch = 0;
/* 183 */     boolean ambiguous = false;
/*     */     
/*     */ 
/* 186 */     Method[] methods = targetClass.getMethods();
/* 187 */     for (int i = 0; i < methods.length; i++) {
/* 188 */       if ((Modifier.isStatic(methods[i].getModifiers())) && (methods[i].getName().equals(name)))
/*     */       {
/* 190 */         int match = matchParameterTypes(methods[i].getParameterTypes(), parameters);
/*     */         
/*     */ 
/*     */ 
/* 194 */         if (match != 0) {
/* 195 */           if (match > currentMatch) {
/* 196 */             method = methods[i];
/* 197 */             currentMatch = match;
/* 198 */             ambiguous = false;
/*     */           }
/* 200 */           else if (match == currentMatch) {
/* 201 */             ambiguous = true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 206 */     if (ambiguous) {
/* 207 */       throw new JXPathException("Ambigous method call: " + name);
/*     */     }
/* 209 */     return method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method lookupMethod(Class targetClass, String name, Object[] parameters)
/*     */   {
/* 217 */     if ((parameters.length < 1) || (parameters[0] == null)) {
/* 218 */       return null;
/*     */     }
/*     */     
/* 221 */     if (matchType(targetClass, parameters[0]) == 0) {
/* 222 */       return null;
/*     */     }
/*     */     
/* 225 */     targetClass = TypeUtils.convert(parameters[0], targetClass).getClass();
/*     */     
/* 227 */     boolean tryExact = true;
/* 228 */     int count = parameters.length - 1;
/* 229 */     Class[] types = new Class[count];
/* 230 */     Object[] arguments = new Object[count];
/* 231 */     for (int i = 0; i < count; i++) {
/* 232 */       Object param = parameters[(i + 1)];
/* 233 */       arguments[i] = param;
/* 234 */       if (param != null) {
/* 235 */         types[i] = param.getClass();
/*     */       }
/*     */       else {
/* 238 */         types[i] = null;
/* 239 */         tryExact = false;
/*     */       }
/*     */     }
/*     */     
/* 243 */     Method method = null;
/*     */     
/* 245 */     if (tryExact) {
/*     */       try
/*     */       {
/* 248 */         method = targetClass.getMethod(name, types);
/* 249 */         if ((method != null) && (!Modifier.isStatic(method.getModifiers())))
/*     */         {
/* 251 */           return method;
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodException ex) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 259 */     int currentMatch = 0;
/* 260 */     boolean ambiguous = false;
/*     */     
/*     */ 
/* 263 */     Method[] methods = targetClass.getMethods();
/* 264 */     for (int i = 0; i < methods.length; i++) {
/* 265 */       if ((!Modifier.isStatic(methods[i].getModifiers())) && (methods[i].getName().equals(name)))
/*     */       {
/* 267 */         int match = matchParameterTypes(methods[i].getParameterTypes(), arguments);
/*     */         
/*     */ 
/*     */ 
/* 271 */         if (match != 0) {
/* 272 */           if (match > currentMatch) {
/* 273 */             method = methods[i];
/* 274 */             currentMatch = match;
/* 275 */             ambiguous = false;
/*     */           }
/* 277 */           else if (match == currentMatch) {
/* 278 */             ambiguous = true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 283 */     if (ambiguous) {
/* 284 */       throw new JXPathException("Ambigous method call: " + name);
/*     */     }
/* 286 */     return method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static int matchParameterTypes(Class[] types, Object[] parameters)
/*     */   {
/* 293 */     int pi = 0;
/* 294 */     if ((types.length >= 1) && (ExpressionContext.class.isAssignableFrom(types[0])))
/*     */     {
/* 296 */       pi++;
/*     */     }
/* 298 */     if (types.length != parameters.length + pi) {
/* 299 */       return 0;
/*     */     }
/* 301 */     int totalMatch = 2;
/* 302 */     for (int i = 0; i < parameters.length; i++) {
/* 303 */       int match = matchType(types[(i + pi)], parameters[i]);
/* 304 */       if (match == 0) {
/* 305 */         return 0;
/*     */       }
/* 307 */       if (match < totalMatch) {
/* 308 */         totalMatch = match;
/*     */       }
/*     */     }
/* 311 */     return totalMatch;
/*     */   }
/*     */   
/*     */   private static int matchType(Class expected, Object object) {
/* 315 */     if (object == null) {
/* 316 */       return 1;
/*     */     }
/*     */     
/* 319 */     Class actual = object.getClass();
/*     */     
/* 321 */     if (expected.equals(actual)) {
/* 322 */       return 2;
/*     */     }
/* 324 */     if (expected.isAssignableFrom(actual)) {
/* 325 */       return 2;
/*     */     }
/*     */     
/* 328 */     if (TypeUtils.canConvert(object, expected)) {
/* 329 */       return 1;
/*     */     }
/*     */     
/* 332 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/util/MethodLookupUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */