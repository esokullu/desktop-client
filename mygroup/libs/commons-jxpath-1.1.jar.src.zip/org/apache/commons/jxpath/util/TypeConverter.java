package org.apache.commons.jxpath.util;

public abstract interface TypeConverter
{
  public abstract boolean canConvert(Object paramObject, Class paramClass);
  
  public abstract Object convert(Object paramObject, Class paramClass);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/util/TypeConverter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */