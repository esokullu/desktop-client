/*     */ package org.apache.commons.jxpath.util;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.NodeSet;
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicTypeConverter
/*     */   implements TypeConverter
/*     */ {
/*     */   public boolean canConvert(Object object, Class toType)
/*     */   {
/*  91 */     if (object == null) {
/*  92 */       return true;
/*     */     }
/*     */     
/*  95 */     if (toType == Object.class) {
/*  96 */       return true;
/*     */     }
/*     */     
/*  99 */     Class fromType = object.getClass();
/* 100 */     if (fromType.equals(toType)) {
/* 101 */       return true;
/*     */     }
/*     */     
/* 104 */     if (toType.isAssignableFrom(fromType)) {
/* 105 */       return true;
/*     */     }
/*     */     
/* 108 */     if (toType == String.class) {
/* 109 */       return true;
/*     */     }
/*     */     
/* 112 */     if ((object instanceof Boolean)) {
/* 113 */       if ((toType == Boolean.TYPE) || (Number.class.isAssignableFrom(toType)))
/*     */       {
/* 115 */         return true;
/*     */       }
/*     */     }
/* 118 */     else if ((object instanceof Number)) {
/* 119 */       if ((toType.isPrimitive()) || (Number.class.isAssignableFrom(toType)))
/*     */       {
/* 121 */         return true;
/*     */       }
/*     */     }
/* 124 */     else if ((object instanceof Character)) {
/* 125 */       if (toType == Character.TYPE) {
/* 126 */         return true;
/*     */       }
/*     */     }
/* 129 */     else if ((object instanceof String)) {
/* 130 */       if (toType.isPrimitive()) {
/* 131 */         return true;
/*     */       }
/* 133 */       if ((toType == Boolean.class) || (toType == Character.class) || (toType == Byte.class) || (toType == Short.class) || (toType == Integer.class) || (toType == Long.class) || (toType == Float.class) || (toType == Double.class))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 141 */         return true;
/*     */       }
/*     */     }
/* 144 */     else if (fromType.isArray())
/*     */     {
/* 146 */       if (toType.isArray()) {
/* 147 */         Class cType = toType.getComponentType();
/* 148 */         int length = Array.getLength(object);
/* 149 */         for (int i = 0; i < length; i++) {
/* 150 */           Object value = Array.get(object, i);
/* 151 */           if (!canConvert(value, cType)) {
/* 152 */             return false;
/*     */           }
/*     */         }
/* 155 */         return true;
/*     */       }
/* 157 */       if (Collection.class.isAssignableFrom(toType)) {
/* 158 */         return canCreateCollection(toType);
/*     */       }
/* 160 */       if (Array.getLength(object) == 1) {
/* 161 */         Object value = Array.get(object, 0);
/* 162 */         return canConvert(value, toType);
/*     */       }
/*     */     }
/* 165 */     else if ((object instanceof Collection))
/*     */     {
/* 167 */       if (toType.isArray()) {
/* 168 */         Class cType = toType.getComponentType();
/* 169 */         Iterator it = ((Collection)object).iterator();
/* 170 */         while (it.hasNext()) {
/* 171 */           Object value = it.next();
/* 172 */           if (!canConvert(value, cType)) {
/* 173 */             return false;
/*     */           }
/*     */         }
/* 176 */         return true;
/*     */       }
/* 178 */       if (Collection.class.isAssignableFrom(toType)) {
/* 179 */         return canCreateCollection(toType);
/*     */       }
/* 181 */       if (((Collection)object).size() == 1) {
/*     */         Object value;
/* 183 */         if ((object instanceof List)) {
/* 184 */           value = ((List)object).get(0);
/*     */         }
/*     */         else {
/* 187 */           Iterator it = ((Collection)object).iterator();
/* 188 */           value = it.next();
/*     */         }
/* 190 */         return canConvert(value, toType);
/*     */       }
/*     */     } else {
/* 193 */       if ((object instanceof NodeSet)) {
/* 194 */         return canConvert(((NodeSet)object).getValues(), toType);
/*     */       }
/* 196 */       if ((object instanceof Pointer))
/* 197 */         return canConvert(((Pointer)object).getValue(), toType);
/*     */     }
/* 199 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object convert(Object object, Class toType)
/*     */   {
/* 207 */     if (object == null) {
/* 208 */       if (toType.isPrimitive()) {
/* 209 */         return convertNullToPrimitive(toType);
/*     */       }
/* 211 */       return null;
/*     */     }
/*     */     
/* 214 */     if (toType == Object.class) {
/* 215 */       return object;
/*     */     }
/*     */     
/* 218 */     Class fromType = object.getClass();
/* 219 */     if ((fromType.equals(toType)) || (toType.isAssignableFrom(fromType))) {
/* 220 */       return object;
/*     */     }
/*     */     
/* 223 */     if (toType == String.class) {
/* 224 */       return object.toString();
/*     */     }
/*     */     
/* 227 */     if ((object instanceof Boolean)) {
/* 228 */       if (toType == Boolean.TYPE) {
/* 229 */         return object;
/*     */       }
/* 231 */       boolean value = ((Boolean)object).booleanValue();
/* 232 */       return allocateNumber(toType, value ? 1.0D : 0.0D);
/*     */     }
/* 234 */     if ((object instanceof Number)) {
/* 235 */       double value = ((Number)object).doubleValue();
/* 236 */       if ((toType == Boolean.TYPE) || (toType == Boolean.class)) {
/* 237 */         return value == 0.0D ? Boolean.FALSE : Boolean.TRUE;
/*     */       }
/* 239 */       if ((toType.isPrimitive()) || (Number.class.isAssignableFrom(toType)))
/*     */       {
/* 241 */         return allocateNumber(toType, value);
/*     */       }
/*     */     }
/* 244 */     else if ((object instanceof Character)) {
/* 245 */       if (toType == Character.TYPE) {
/* 246 */         return object;
/*     */       }
/*     */     }
/* 249 */     else if ((object instanceof String)) {
/* 250 */       Object value = convertStringToPrimitive(object, toType);
/* 251 */       if (value != null) {
/* 252 */         return value;
/*     */       }
/*     */     }
/* 255 */     else if (fromType.isArray()) {
/* 256 */       int length = Array.getLength(object);
/* 257 */       if (toType.isArray()) {
/* 258 */         Class cType = toType.getComponentType();
/*     */         
/* 260 */         Object array = Array.newInstance(cType, length);
/* 261 */         for (int i = 0; i < length; i++) {
/* 262 */           Object value = Array.get(object, i);
/* 263 */           Array.set(array, i, convert(value, cType));
/*     */         }
/* 265 */         return array;
/*     */       }
/* 267 */       if (Collection.class.isAssignableFrom(toType)) {
/* 268 */         Collection collection = allocateCollection(toType);
/* 269 */         for (int i = 0; i < length; i++) {
/* 270 */           collection.add(Array.get(object, i));
/*     */         }
/* 272 */         return unmodifiableCollection(collection);
/*     */       }
/* 274 */       if (length == 1) {
/* 275 */         Object value = Array.get(object, 0);
/* 276 */         return convert(value, toType);
/*     */       }
/*     */     } else {
/* 279 */       if ((object instanceof Collection)) {
/* 280 */         int length = ((Collection)object).size();
/* 281 */         if (toType.isArray()) {
/* 282 */           Class cType = toType.getComponentType();
/* 283 */           Object array = Array.newInstance(cType, length);
/* 284 */           Iterator it = ((Collection)object).iterator();
/* 285 */           for (int i = 0; i < length; i++) {
/* 286 */             Object value = it.next();
/* 287 */             Array.set(array, i, convert(value, cType));
/*     */           }
/* 289 */           return array;
/*     */         }
/* 291 */         if (Collection.class.isAssignableFrom(toType)) {
/* 292 */           Collection collection = allocateCollection(toType);
/* 293 */           collection.addAll((Collection)object);
/* 294 */           return unmodifiableCollection(collection);
/*     */         }
/* 296 */         if (length == 1) {
/*     */           Object value;
/* 298 */           if ((object instanceof List)) {
/* 299 */             value = ((List)object).get(0);
/*     */           }
/*     */           else {
/* 302 */             Iterator it = ((Collection)object).iterator();
/* 303 */             value = it.next();
/*     */           }
/* 305 */           return convert(value, toType);
/*     */         }
/*     */         
/* 308 */         throw new RuntimeException("Cannot convert collection to " + toType + ", it contains " + length + " elements");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 316 */       if ((object instanceof NodeSet)) {
/* 317 */         return convert(((NodeSet)object).getValues(), toType);
/*     */       }
/* 319 */       if ((object instanceof Pointer)) {
/* 320 */         return convert(((Pointer)object).getValue(), toType);
/*     */       }
/*     */     }
/* 323 */     throw new RuntimeException("Cannot convert " + object.getClass() + " to " + toType);
/*     */   }
/*     */   
/*     */   private Object convertNullToPrimitive(Class toType)
/*     */   {
/* 328 */     if (toType == Boolean.TYPE) {
/* 329 */       return Boolean.FALSE;
/*     */     }
/* 331 */     if (toType == Character.TYPE) {
/* 332 */       return new Character('\000');
/*     */     }
/* 334 */     if (toType == Byte.TYPE) {
/* 335 */       return new Byte((byte)0);
/*     */     }
/* 337 */     if (toType == Short.TYPE) {
/* 338 */       return new Short((short)0);
/*     */     }
/* 340 */     if (toType == Integer.TYPE) {
/* 341 */       return new Integer(0);
/*     */     }
/* 343 */     if (toType == Long.TYPE) {
/* 344 */       return new Long(0L);
/*     */     }
/* 346 */     if (toType == Float.TYPE) {
/* 347 */       return new Float(0.0F);
/*     */     }
/* 349 */     if (toType == Double.TYPE) {
/* 350 */       return new Double(0.0D);
/*     */     }
/* 352 */     return null;
/*     */   }
/*     */   
/*     */   private Object convertStringToPrimitive(Object object, Class toType) {
/* 356 */     if ((toType == Boolean.TYPE) || (toType == Boolean.class)) {
/* 357 */       return Boolean.valueOf((String)object);
/*     */     }
/* 359 */     if ((toType == Character.TYPE) || (toType == Character.class)) {
/* 360 */       return new Character(((String)object).charAt(0));
/*     */     }
/* 362 */     if ((toType == Byte.TYPE) || (toType == Byte.class)) {
/* 363 */       return new Byte((String)object);
/*     */     }
/* 365 */     if ((toType == Short.TYPE) || (toType == Short.class)) {
/* 366 */       return new Short((String)object);
/*     */     }
/* 368 */     if ((toType == Integer.TYPE) || (toType == Integer.class)) {
/* 369 */       return new Integer((String)object);
/*     */     }
/* 371 */     if ((toType == Long.TYPE) || (toType == Long.class)) {
/* 372 */       return new Long((String)object);
/*     */     }
/* 374 */     if ((toType == Float.TYPE) || (toType == Float.class)) {
/* 375 */       return new Float((String)object);
/*     */     }
/* 377 */     if ((toType == Double.TYPE) || (toType == Double.class)) {
/* 378 */       return new Double((String)object);
/*     */     }
/* 380 */     return null;
/*     */   }
/*     */   
/*     */   private static Number allocateNumber(Class type, double value) {
/* 384 */     if ((type == Byte.class) || (type == Byte.TYPE)) {
/* 385 */       return new Byte((byte)(int)value);
/*     */     }
/* 387 */     if ((type == Short.class) || (type == Short.TYPE)) {
/* 388 */       return new Short((short)(int)value);
/*     */     }
/* 390 */     if ((type == Integer.class) || (type == Integer.TYPE)) {
/* 391 */       return new Integer((int)value);
/*     */     }
/* 393 */     if ((type == Long.class) || (type == Long.TYPE)) {
/* 394 */       return new Long(value);
/*     */     }
/* 396 */     if ((type == Float.class) || (type == Float.TYPE)) {
/* 397 */       return new Float((float)value);
/*     */     }
/* 399 */     if ((type == Double.class) || (type == Double.TYPE)) {
/* 400 */       return new Double(value);
/*     */     }
/* 402 */     return null;
/*     */   }
/*     */   
/*     */   private static boolean canCreateCollection(Class type) {
/* 406 */     if ((!type.isInterface()) && ((type.getModifiers() | 0x400) == 0))
/*     */     {
/* 408 */       return true;
/*     */     }
/*     */     
/* 411 */     if (type == List.class) {
/* 412 */       return true;
/*     */     }
/*     */     
/* 415 */     if (type == Set.class) {
/* 416 */       return true;
/*     */     }
/* 418 */     return false;
/*     */   }
/*     */   
/*     */   private static Collection allocateCollection(Class type) {
/* 422 */     if ((!type.isInterface()) && ((type.getModifiers() | 0x400) == 0)) {
/*     */       try
/*     */       {
/* 425 */         return (Collection)type.newInstance();
/*     */       }
/*     */       catch (Exception ex) {
/* 428 */         throw new JXPathException("Cannot create collection of type: " + type, ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 434 */     if (type == List.class) {
/* 435 */       return new ArrayList();
/*     */     }
/* 437 */     if (type == Set.class) {
/* 438 */       return new HashSet();
/*     */     }
/* 440 */     throw new RuntimeException("Cannot create collection of type: " + type);
/*     */   }
/*     */   
/*     */   private Collection unmodifiableCollection(Collection collection) {
/* 444 */     if ((collection instanceof List)) {
/* 445 */       return Collections.unmodifiableList((List)collection);
/*     */     }
/* 447 */     if ((collection instanceof Set)) {
/* 448 */       return Collections.unmodifiableSet((Set)collection);
/*     */     }
/*     */     
/*     */ 
/* 452 */     return collection;
/*     */   }
/*     */   
/*     */   static class ValueNodeSet implements NodeSet {
/*     */     private List values;
/*     */     private List pointers;
/*     */     
/*     */     public ValueNodeSet(List values) {
/* 460 */       this.values = values;
/*     */     }
/*     */     
/*     */     public List getValues() {
/* 464 */       return Collections.unmodifiableList(this.values);
/*     */     }
/*     */     
/*     */     public List getNodes() {
/* 468 */       return Collections.unmodifiableList(this.values);
/*     */     }
/*     */     
/*     */     public List getPointers() {
/* 472 */       if (this.pointers == null) {
/* 473 */         this.pointers = new ArrayList();
/* 474 */         for (int i = 0; i < this.values.size(); i++) {
/* 475 */           this.pointers.add(new BasicTypeConverter.ValuePointer(this.values.get(i)));
/*     */         }
/* 477 */         this.pointers = Collections.unmodifiableList(this.pointers);
/*     */       }
/* 479 */       return this.pointers;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ValuePointer implements Pointer {
/*     */     private Object bean;
/*     */     
/*     */     public ValuePointer(Object object) {
/* 487 */       this.bean = object;
/*     */     }
/*     */     
/*     */     public Object getValue() {
/* 491 */       return this.bean;
/*     */     }
/*     */     
/*     */     public Object getNode() {
/* 495 */       return this.bean;
/*     */     }
/*     */     
/*     */     public Object getRootNode() {
/* 499 */       return this.bean;
/*     */     }
/*     */     
/*     */     public void setValue(Object value) {
/* 503 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public Object clone() {
/* 507 */       return this;
/*     */     }
/*     */     
/*     */     public int compareTo(Object object) {
/* 511 */       return 0;
/*     */     }
/*     */     
/*     */     public String asPath() {
/* 515 */       if (this.bean == null) {
/* 516 */         return "null()";
/*     */       }
/* 518 */       if ((this.bean instanceof Number)) {
/* 519 */         String string = this.bean.toString();
/* 520 */         if (string.endsWith(".0")) {
/* 521 */           string = string.substring(0, string.length() - 2);
/*     */         }
/* 523 */         return string;
/*     */       }
/* 525 */       if ((this.bean instanceof Boolean)) {
/* 526 */         return ((Boolean)this.bean).booleanValue() ? "true()" : "false()";
/*     */       }
/* 528 */       if ((this.bean instanceof String)) {
/* 529 */         return "'" + this.bean + "'";
/*     */       }
/* 531 */       return "{object of type " + this.bean.getClass().getName() + "}";
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/util/BasicTypeConverter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */