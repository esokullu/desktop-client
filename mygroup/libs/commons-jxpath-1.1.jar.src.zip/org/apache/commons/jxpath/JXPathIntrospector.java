/*     */ package org.apache.commons.jxpath;
/*     */ 
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JXPathIntrospector
/*     */ {
/*  77 */   private static HashMap byClass = new HashMap();
/*  78 */   private static HashMap byInterface = new HashMap();
/*     */   
/*     */   static {
/*  81 */     registerAtomicClass(Boolean.TYPE);
/*  82 */     registerAtomicClass(Boolean.class);
/*  83 */     registerAtomicClass(Byte.TYPE);
/*  84 */     registerAtomicClass(Byte.class);
/*  85 */     registerAtomicClass(Character.TYPE);
/*  86 */     registerAtomicClass(Character.class);
/*  87 */     registerAtomicClass(Short.TYPE);
/*  88 */     registerAtomicClass(Short.class);
/*  89 */     registerAtomicClass(Integer.TYPE);
/*  90 */     registerAtomicClass(Integer.class);
/*  91 */     registerAtomicClass(Long.TYPE);
/*  92 */     registerAtomicClass(Long.class);
/*  93 */     registerAtomicClass(Float.TYPE);
/*  94 */     registerAtomicClass(Float.class);
/*  95 */     registerAtomicClass(Double.TYPE);
/*  96 */     registerAtomicClass(Double.class);
/*  97 */     registerAtomicClass(String.class);
/*  98 */     registerAtomicClass(java.util.Date.class);
/*  99 */     registerAtomicClass(java.sql.Date.class);
/* 100 */     registerAtomicClass(Time.class);
/* 101 */     registerAtomicClass(Timestamp.class);
/*     */     
/* 103 */     registerDynamicClass(Map.class, MapDynamicPropertyHandler.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void registerAtomicClass(Class beanClass)
/*     */   {
/* 111 */     byClass.put(beanClass, new JXPathBasicBeanInfo(beanClass, true));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void registerDynamicClass(Class beanClass, Class dynamicPropertyHandlerClass)
/*     */   {
/* 122 */     JXPathBasicBeanInfo bi = new JXPathBasicBeanInfo(beanClass, dynamicPropertyHandlerClass);
/*     */     
/* 124 */     if (beanClass.isInterface()) {
/* 125 */       byInterface.put(beanClass, bi);
/*     */     }
/*     */     else {
/* 128 */       byClass.put(beanClass, bi);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JXPathBeanInfo getBeanInfo(Class beanClass)
/*     */   {
/* 146 */     JXPathBeanInfo beanInfo = (JXPathBeanInfo)byClass.get(beanClass);
/* 147 */     if (beanInfo == null) {
/* 148 */       beanInfo = findDynamicBeanInfo(beanClass);
/* 149 */       if (beanInfo == null) {
/* 150 */         beanInfo = findInformant(beanClass);
/* 151 */         if (beanInfo == null) {
/* 152 */           beanInfo = new JXPathBasicBeanInfo(beanClass);
/*     */         }
/*     */       }
/* 155 */       byClass.put(beanClass, beanInfo);
/*     */     }
/* 157 */     return beanInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static JXPathBeanInfo findDynamicBeanInfo(Class beanClass)
/*     */   {
/*     */     JXPathBeanInfo beanInfo;
/*     */     
/* 166 */     if (beanClass.isInterface()) {
/* 167 */       beanInfo = (JXPathBeanInfo)byInterface.get(beanClass);
/* 168 */       if (beanInfo != null) {
/* 169 */         return beanInfo;
/*     */       }
/*     */     }
/*     */     
/* 173 */     Class[] interfaces = beanClass.getInterfaces();
/* 174 */     if (interfaces != null) {
/* 175 */       for (int i = 0; i < interfaces.length; i++) {
/* 176 */         beanInfo = findDynamicBeanInfo(interfaces[i]);
/* 177 */         if (beanInfo != null) {
/* 178 */           return beanInfo;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 183 */     Class sup = beanClass.getSuperclass();
/* 184 */     if (sup != null) {
/* 185 */       return findDynamicBeanInfo(sup);
/*     */     }
/* 187 */     return null;
/*     */   }
/*     */   
/*     */   private static synchronized JXPathBeanInfo findInformant(Class beanClass) {
/* 191 */     String name = beanClass.getName() + "XBeanInfo";
/*     */     try {
/* 193 */       return (JXPathBeanInfo)instantiate(beanClass, name);
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/* 201 */         if (JXPathBeanInfo.class.isAssignableFrom(beanClass)) {
/* 202 */           return (JXPathBeanInfo)beanClass.newInstance();
/*     */         }
/*     */       }
/*     */       catch (Exception ex) {}
/*     */     }
/*     */     
/*     */ 
/* 209 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object instantiate(Class sibling, String className)
/*     */     throws Exception
/*     */   {
/* 222 */     ClassLoader cl = sibling.getClassLoader();
/* 223 */     if (cl != null) {
/*     */       try {
/* 225 */         Class cls = cl.loadClass(className);
/* 226 */         return cls.newInstance();
/*     */       }
/*     */       catch (Exception ex) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 234 */     Class cls = Class.forName(className);
/* 235 */     return cls.newInstance();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/JXPathIntrospector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */