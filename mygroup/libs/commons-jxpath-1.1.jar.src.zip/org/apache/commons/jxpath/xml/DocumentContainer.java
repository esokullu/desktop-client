/*     */ package org.apache.commons.jxpath.xml;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.jxpath.Container;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocumentContainer
/*     */   implements Container
/*     */ {
/*     */   public static final String MODEL_DOM = "DOM";
/*     */   public static final String MODEL_JDOM = "JDOM";
/*     */   private Object document;
/*     */   private URL xmlURL;
/*     */   private String model;
/*  93 */   private static HashMap parserClasses = new HashMap();
/*     */   
/*  95 */   static { parserClasses.put("DOM", "org.apache.commons.jxpath.xml.DOMParser");
/*     */     
/*  97 */     parserClasses.put("JDOM", "org.apache.commons.jxpath.xml.JDOMParser");
/*     */   }
/*     */   
/*     */ 
/* 101 */   private static HashMap parsers = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void registerXMLParser(String model, XMLParser parser)
/*     */   {
/* 108 */     parsers.put(model, parser);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocumentContainer(URL xmlURL)
/*     */   {
/* 119 */     this(xmlURL, "DOM");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DocumentContainer(URL xmlURL, String model)
/*     */   {
/* 130 */     this.xmlURL = xmlURL;
/* 131 */     if (xmlURL == null) {
/* 132 */       throw new JXPathException("XML URL is null");
/*     */     }
/* 134 */     this.model = model;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getValue()
/*     */   {
/* 141 */     if (this.document == null) {
/*     */       try {
/* 143 */         InputStream stream = null;
/*     */         try {
/* 145 */           if (this.xmlURL != null) {
/* 146 */             stream = this.xmlURL.openStream();
/*     */           }
/* 148 */           this.document = getParser(this.model).parseXML(stream);
/*     */         }
/*     */         finally {
/* 151 */           if (stream != null) {
/* 152 */             stream.close();
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception ex) {
/* 157 */         throw new JXPathException("Cannot read XML from: " + this.xmlURL.toString(), ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 162 */     return this.document;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/* 169 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final XMLParser getParser(String model)
/*     */   {
/* 176 */     XMLParser parser = (XMLParser)parsers.get(model);
/* 177 */     if (parser == null) {
/* 178 */       String className = (String)parserClasses.get(model);
/* 179 */       if (className == null) {
/* 180 */         throw new JXPathException("Unsupported XML model: " + model);
/*     */       }
/*     */       try {
/* 183 */         Class clazz = Class.forName(className);
/* 184 */         parser = (XMLParser)clazz.newInstance();
/*     */       }
/*     */       catch (Exception ex) {
/* 187 */         throw new JXPathException("Cannot allocate XMLParser: " + className);
/*     */       }
/*     */       
/* 190 */       parsers.put(model, parser);
/*     */     }
/* 192 */     return parser;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/xml/DocumentContainer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */