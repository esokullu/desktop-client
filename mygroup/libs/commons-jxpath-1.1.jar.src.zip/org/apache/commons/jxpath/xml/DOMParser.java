/*    */ package org.apache.commons.jxpath.xml;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import javax.xml.parsers.DocumentBuilderFactory;
/*    */ import org.apache.commons.jxpath.JXPathException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DOMParser
/*    */   implements XMLParser
/*    */ {
/*    */   public Object parseXML(InputStream stream)
/*    */   {
/*    */     try
/*    */     {
/* 80 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*    */       
/* 82 */       return factory.newDocumentBuilder().parse(stream);
/*    */     }
/*    */     catch (Exception ex) {
/* 85 */       throw new JXPathException("DOM parser error", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/xml/DOMParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */