/*    */ package org.apache.commons.jxpath.xml;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import org.apache.commons.jxpath.JXPathException;
/*    */ import org.jdom.input.SAXBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JDOMParser
/*    */   implements XMLParser
/*    */ {
/*    */   public Object parseXML(InputStream stream)
/*    */   {
/*    */     try
/*    */     {
/* 79 */       SAXBuilder builder = new SAXBuilder();
/* 80 */       return builder.build(stream);
/*    */     }
/*    */     catch (Exception ex) {
/* 83 */       throw new JXPathException("JDOM parser error", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/xml/JDOMParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */