package org.apache.commons.jxpath;

public abstract interface Function
{
  public abstract Object invoke(ExpressionContext paramExpressionContext, Object[] paramArrayOfObject);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/Function.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */