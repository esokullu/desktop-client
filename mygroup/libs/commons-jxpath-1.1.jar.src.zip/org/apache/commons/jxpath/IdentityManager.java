package org.apache.commons.jxpath;

public abstract interface IdentityManager
{
  public abstract Pointer getPointerByID(JXPathContext paramJXPathContext, String paramString);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/IdentityManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */