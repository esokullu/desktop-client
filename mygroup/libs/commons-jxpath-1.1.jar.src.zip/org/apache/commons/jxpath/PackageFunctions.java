/*     */ package org.apache.commons.jxpath;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.jxpath.functions.ConstructorFunction;
/*     */ import org.apache.commons.jxpath.functions.MethodFunction;
/*     */ import org.apache.commons.jxpath.util.MethodLookupUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PackageFunctions
/*     */   implements Functions
/*     */ {
/*     */   private String classPrefix;
/*     */   private String namespace;
/* 118 */   private static final Object[] EMPTY_ARRAY = new Object[0];
/*     */   
/*     */   public PackageFunctions(String classPrefix, String namespace) {
/* 121 */     this.classPrefix = classPrefix;
/* 122 */     this.namespace = namespace;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set getUsedNamespaces()
/*     */   {
/* 129 */     return Collections.singleton(this.namespace);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Function getFunction(String namespace, String name, Object[] parameters)
/*     */   {
/* 158 */     if (((namespace == null) && (this.namespace != null)) || ((namespace != null) && (!namespace.equals(this.namespace))))
/*     */     {
/* 160 */       return null;
/*     */     }
/*     */     
/* 163 */     if (parameters == null) {
/* 164 */       parameters = EMPTY_ARRAY;
/*     */     }
/*     */     
/* 167 */     if (parameters.length >= 1) {
/* 168 */       Object target = parameters[0];
/* 169 */       if (target != null) {
/* 170 */         Method method = MethodLookupUtils.lookupMethod(target.getClass(), name, parameters);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 175 */         if (method != null) {
/* 176 */           return new MethodFunction(method);
/*     */         }
/*     */         
/* 179 */         if ((target instanceof NodeSet)) {
/* 180 */           target = ((NodeSet)target).getPointers();
/*     */         }
/*     */         
/* 183 */         method = MethodLookupUtils.lookupMethod(target.getClass(), name, parameters);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 188 */         if (method != null) {
/* 189 */           return new MethodFunction(method);
/*     */         }
/*     */         
/* 192 */         if ((target instanceof Collection)) {
/* 193 */           Iterator iter = ((Collection)target).iterator();
/* 194 */           if (iter.hasNext()) {
/* 195 */             target = iter.next();
/* 196 */             if ((target instanceof Pointer)) {
/* 197 */               target = ((Pointer)target).getValue();
/*     */             }
/*     */           }
/*     */           else {
/* 201 */             target = null;
/*     */           }
/*     */         }
/*     */       }
/* 205 */       if (target != null) {
/* 206 */         Method method = MethodLookupUtils.lookupMethod(target.getClass(), name, parameters);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 211 */         if (method != null) {
/* 212 */           return new MethodFunction(method);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 217 */     String fullName = this.classPrefix + name;
/* 218 */     int inx = fullName.lastIndexOf('.');
/* 219 */     if (inx == -1) {
/* 220 */       return null;
/*     */     }
/*     */     
/* 223 */     String className = fullName.substring(0, inx);
/* 224 */     String methodName = fullName.substring(inx + 1);
/*     */     Class functionClass;
/*     */     try
/*     */     {
/* 228 */       functionClass = Class.forName(className);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 231 */       throw new JXPathException("Cannot invoke extension function " + (namespace != null ? namespace + ":" + name : name), ex);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 237 */     if (methodName.endsWith("new")) {
/* 238 */       Constructor constructor = MethodLookupUtils.lookupConstructor(functionClass, parameters);
/*     */       
/* 240 */       if (constructor != null) {
/* 241 */         return new ConstructorFunction(constructor);
/*     */       }
/*     */     }
/*     */     else {
/* 245 */       Method method = MethodLookupUtils.lookupStaticMethod(functionClass, methodName, parameters);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 250 */       if (method != null) {
/* 251 */         return new MethodFunction(method);
/*     */       }
/*     */     }
/* 254 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/PackageFunctions.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */