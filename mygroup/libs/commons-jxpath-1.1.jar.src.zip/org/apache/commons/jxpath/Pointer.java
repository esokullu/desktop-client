package org.apache.commons.jxpath;

import java.io.Serializable;

public abstract interface Pointer
  extends Cloneable, Comparable, Serializable
{
  public abstract Object getValue();
  
  public abstract Object getNode();
  
  public abstract void setValue(Object paramObject);
  
  public abstract Object getRootNode();
  
  public abstract String asPath();
  
  public abstract Object clone();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/Pointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */