/*     */ package org.apache.commons.jxpath;
/*     */ 
/*     */ import java.net.URL;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import org.apache.commons.jxpath.xml.DocumentContainer;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ /**
/*     */  * @deprecated
/*     */  */
/*     */ public class XMLDocumentContainer
/*     */   implements Container
/*     */ {
/*     */   private DocumentContainer delegate;
/*     */   private Object document;
/*     */   private URL xmlURL;
/*     */   private Source source;
/*     */   private String parser;
/*     */   
/*     */   public XMLDocumentContainer(URL xmlURL)
/*     */   {
/* 102 */     this.delegate = new DocumentContainer(xmlURL);
/*     */   }
/*     */   
/*     */   public XMLDocumentContainer(Source source) {
/* 106 */     this.source = source;
/* 107 */     if (source == null) {
/* 108 */       throw new RuntimeException("Source is null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getValue()
/*     */   {
/* 116 */     if (this.document == null) {
/*     */       try {
/* 118 */         if (this.source != null) {
/* 119 */           DOMResult result = new DOMResult();
/* 120 */           Transformer trans = TransformerFactory.newInstance().newTransformer();
/*     */           
/* 122 */           trans.transform(this.source, result);
/* 123 */           this.document = ((Document)result.getNode());
/*     */         }
/*     */         else {
/* 126 */           this.document = this.delegate.getValue();
/*     */         }
/*     */       }
/*     */       catch (Exception ex) {
/* 130 */         throw new JXPathException("Cannot read XML from: " + (this.source != null ? this.source.getSystemId() : this.xmlURL != null ? this.xmlURL.toString() : "<<undefined source>>"), ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 140 */     return this.document;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/* 147 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/XMLDocumentContainer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */