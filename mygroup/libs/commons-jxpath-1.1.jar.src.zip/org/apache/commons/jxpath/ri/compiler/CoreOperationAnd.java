/*    */ package org.apache.commons.jxpath.ri.compiler;
/*    */ 
/*    */ import org.apache.commons.jxpath.ri.EvalContext;
/*    */ import org.apache.commons.jxpath.ri.InfoSetUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoreOperationAnd
/*    */   extends CoreOperation
/*    */ {
/*    */   public CoreOperationAnd(Expression[] args)
/*    */   {
/* 68 */     super(args);
/*    */   }
/*    */   
/*    */   public Object computeValue(EvalContext context) {
/* 72 */     for (int i = 0; i < this.args.length; i++) {
/* 73 */       if (!InfoSetUtil.booleanValue(this.args[i].computeValue(context))) {
/* 74 */         return Boolean.FALSE;
/*    */       }
/*    */     }
/* 77 */     return Boolean.TRUE;
/*    */   }
/*    */   
/*    */   protected int getPrecedence() {
/* 81 */     return 1;
/*    */   }
/*    */   
/*    */   protected boolean isSymmetric() {
/* 85 */     return true;
/*    */   }
/*    */   
/*    */   public String getSymbol() {
/* 89 */     return "and";
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/CoreOperationAnd.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */