/*    */ package org.apache.commons.jxpath.ri.compiler;
/*    */ 
/*    */ import org.apache.commons.jxpath.ri.EvalContext;
/*    */ import org.apache.commons.jxpath.ri.InfoSetUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoreOperationNegate
/*    */   extends CoreOperation
/*    */ {
/*    */   public CoreOperationNegate(Expression arg)
/*    */   {
/* 68 */     super(new Expression[] { arg });
/*    */   }
/*    */   
/*    */   public Object computeValue(EvalContext context) {
/* 72 */     double a = InfoSetUtil.doubleValue(this.args[0].computeValue(context));
/* 73 */     return new Double(-a);
/*    */   }
/*    */   
/*    */   protected int getPrecedence() {
/* 77 */     return 6;
/*    */   }
/*    */   
/*    */   protected boolean isSymmetric() {
/* 81 */     return false;
/*    */   }
/*    */   
/*    */   public String getSymbol() {
/* 85 */     return "-";
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/CoreOperationNegate.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */