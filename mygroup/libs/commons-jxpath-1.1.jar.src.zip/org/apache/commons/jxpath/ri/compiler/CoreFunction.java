/*     */ package org.apache.commons.jxpath.ri.compiler;
/*     */ 
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.DecimalFormatSymbols;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.Collection;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.InfoSetUtil;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoreFunction
/*     */   extends Operation
/*     */ {
/*  86 */   private static final Double ZERO = new Double(0.0D);
/*     */   private int functionCode;
/*     */   
/*     */   public CoreFunction(int functionCode, Expression[] args) {
/*  90 */     super(args);
/*  91 */     this.functionCode = functionCode;
/*     */   }
/*     */   
/*     */   public int getFunctionCode() {
/*  95 */     return this.functionCode;
/*     */   }
/*     */   
/*     */   protected String getFunctionName() {
/*  99 */     switch (this.functionCode) {
/*     */     case 1: 
/* 101 */       return "last";
/*     */     case 2: 
/* 103 */       return "position";
/*     */     case 3: 
/* 105 */       return "count";
/*     */     case 4: 
/* 107 */       return "id";
/*     */     case 5: 
/* 109 */       return "local-name";
/*     */     case 6: 
/* 111 */       return "namespace-uri";
/*     */     case 7: 
/* 113 */       return "name";
/*     */     case 8: 
/* 115 */       return "string";
/*     */     case 9: 
/* 117 */       return "concat";
/*     */     case 10: 
/* 119 */       return "starts-with";
/*     */     case 11: 
/* 121 */       return "contains";
/*     */     case 12: 
/* 123 */       return "substring-before";
/*     */     case 13: 
/* 125 */       return "substring-after";
/*     */     case 14: 
/* 127 */       return "substring";
/*     */     case 15: 
/* 129 */       return "string-length";
/*     */     case 16: 
/* 131 */       return "normalize-space";
/*     */     case 17: 
/* 133 */       return "translate";
/*     */     case 18: 
/* 135 */       return "boolean";
/*     */     case 19: 
/* 137 */       return "not";
/*     */     case 20: 
/* 139 */       return "true";
/*     */     case 21: 
/* 141 */       return "false";
/*     */     case 22: 
/* 143 */       return "lang";
/*     */     case 23: 
/* 145 */       return "number";
/*     */     case 24: 
/* 147 */       return "sum";
/*     */     case 25: 
/* 149 */       return "floor";
/*     */     case 26: 
/* 151 */       return "ceiling";
/*     */     case 27: 
/* 153 */       return "round";
/*     */     case 29: 
/* 155 */       return "key";
/*     */     case 30: 
/* 157 */       return "format-number";
/*     */     }
/* 159 */     return "unknownFunction" + this.functionCode + "()";
/*     */   }
/*     */   
/*     */   public Expression getArg1() {
/* 163 */     return this.args[0];
/*     */   }
/*     */   
/*     */   public Expression getArg2() {
/* 167 */     return this.args[1];
/*     */   }
/*     */   
/*     */   public Expression getArg3() {
/* 171 */     return this.args[2];
/*     */   }
/*     */   
/*     */   public int getArgumentCount() {
/* 175 */     if (this.args == null) {
/* 176 */       return 0;
/*     */     }
/* 178 */     return this.args.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean computeContextDependent()
/*     */   {
/* 187 */     if (super.computeContextDependent()) {
/* 188 */       return true;
/*     */     }
/*     */     
/* 191 */     switch (this.functionCode) {
/*     */     case 1: 
/*     */     case 2: 
/* 194 */       return true;
/*     */     
/*     */     case 5: 
/*     */     case 6: 
/*     */     case 7: 
/*     */     case 8: 
/*     */     case 18: 
/*     */     case 22: 
/*     */     case 23: 
/* 203 */       return (this.args == null) || (this.args.length == 0);
/*     */     
/*     */     case 3: 
/*     */     case 4: 
/*     */     case 9: 
/*     */     case 10: 
/*     */     case 11: 
/*     */     case 12: 
/*     */     case 13: 
/*     */     case 14: 
/*     */     case 15: 
/*     */     case 16: 
/*     */     case 17: 
/*     */     case 19: 
/*     */     case 20: 
/*     */     case 21: 
/*     */     case 24: 
/*     */     case 25: 
/*     */     case 26: 
/*     */     case 27: 
/* 223 */       return false;
/*     */     
/*     */     case 30: 
/* 226 */       return (this.args != null) && (this.args.length == 2);
/*     */     }
/*     */     
/* 229 */     return false;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 233 */     StringBuffer buffer = new StringBuffer();
/* 234 */     buffer.append(getFunctionName());
/* 235 */     buffer.append('(');
/* 236 */     Expression[] args = getArguments();
/* 237 */     if (args != null) {
/* 238 */       for (int i = 0; i < args.length; i++) {
/* 239 */         if (i > 0) {
/* 240 */           buffer.append(", ");
/*     */         }
/* 242 */         buffer.append(args[i]);
/*     */       }
/*     */     }
/* 245 */     buffer.append(')');
/* 246 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public Object compute(EvalContext context) {
/* 250 */     return computeValue(context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object computeValue(EvalContext context)
/*     */   {
/* 257 */     switch (this.functionCode) {
/*     */     case 1: 
/* 259 */       return functionLast(context);
/*     */     case 2: 
/* 261 */       return functionPosition(context);
/*     */     case 3: 
/* 263 */       return functionCount(context);
/*     */     case 22: 
/* 265 */       return functionLang(context);
/*     */     case 4: 
/* 267 */       return functionID(context);
/*     */     case 5: 
/* 269 */       return functionLocalName(context);
/*     */     case 6: 
/* 271 */       return functionNamespaceURI(context);
/*     */     case 7: 
/* 273 */       return functionName(context);
/*     */     case 8: 
/* 275 */       return functionString(context);
/*     */     case 9: 
/* 277 */       return functionConcat(context);
/*     */     case 10: 
/* 279 */       return functionStartsWith(context);
/*     */     case 11: 
/* 281 */       return functionContains(context);
/*     */     case 12: 
/* 283 */       return functionSubstringBefore(context);
/*     */     case 13: 
/* 285 */       return functionSubstringAfter(context);
/*     */     case 14: 
/* 287 */       return functionSubstring(context);
/*     */     case 15: 
/* 289 */       return functionStringLength(context);
/*     */     case 16: 
/* 291 */       return functionNormalizeSpace(context);
/*     */     case 17: 
/* 293 */       return functionTranslate(context);
/*     */     case 18: 
/* 295 */       return functionBoolean(context);
/*     */     case 19: 
/* 297 */       return functionNot(context);
/*     */     case 20: 
/* 299 */       return functionTrue(context);
/*     */     case 21: 
/* 301 */       return functionFalse(context);
/*     */     case 28: 
/* 303 */       return functionNull(context);
/*     */     case 23: 
/* 305 */       return functionNumber(context);
/*     */     case 24: 
/* 307 */       return functionSum(context);
/*     */     case 25: 
/* 309 */       return functionFloor(context);
/*     */     case 26: 
/* 311 */       return functionCeiling(context);
/*     */     case 27: 
/* 313 */       return functionRound(context);
/*     */     case 29: 
/* 315 */       return functionKey(context);
/*     */     case 30: 
/* 317 */       return functionFormatNumber(context);
/*     */     }
/* 319 */     return null;
/*     */   }
/*     */   
/*     */   protected Object functionLast(EvalContext context) {
/* 323 */     assertArgCount(0);
/*     */     
/*     */ 
/* 326 */     int old = context.getCurrentPosition();
/* 327 */     context.reset();
/* 328 */     int count = 0;
/* 329 */     while (context.nextNode()) {
/* 330 */       count++;
/*     */     }
/*     */     
/*     */ 
/* 334 */     if (old != 0) {
/* 335 */       context.setPosition(old);
/*     */     }
/* 337 */     return new Double(count);
/*     */   }
/*     */   
/*     */   protected Object functionPosition(EvalContext context) {
/* 341 */     assertArgCount(0);
/* 342 */     return new Integer(context.getCurrentPosition());
/*     */   }
/*     */   
/*     */   protected Object functionCount(EvalContext context) {
/* 346 */     assertArgCount(1);
/* 347 */     Expression arg1 = getArg1();
/* 348 */     int count = 0;
/* 349 */     Object value = arg1.compute(context);
/* 350 */     if ((value instanceof NodePointer)) {
/* 351 */       value = ((NodePointer)value).getValue();
/*     */     }
/* 353 */     if ((value instanceof EvalContext)) {
/* 354 */       EvalContext ctx = (EvalContext)value;
/* 355 */       while (ctx.hasNext()) {
/* 356 */         ctx.next();
/* 357 */         count++;
/*     */       }
/*     */     }
/* 360 */     else if ((value instanceof Collection)) {
/* 361 */       count = ((Collection)value).size();
/*     */     }
/* 363 */     else if (value == null) {
/* 364 */       count = 0;
/*     */     }
/*     */     else {
/* 367 */       count = 1;
/*     */     }
/* 369 */     return new Double(count);
/*     */   }
/*     */   
/*     */   protected Object functionLang(EvalContext context) {
/* 373 */     assertArgCount(1);
/* 374 */     String lang = InfoSetUtil.stringValue(getArg1().computeValue(context));
/* 375 */     NodePointer pointer = (NodePointer)context.getSingleNodePointer();
/* 376 */     if (pointer == null) {
/* 377 */       return Boolean.FALSE;
/*     */     }
/* 379 */     return pointer.isLanguage(lang) ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */   
/*     */   protected Object functionID(EvalContext context) {
/* 383 */     assertArgCount(1);
/* 384 */     String id = InfoSetUtil.stringValue(getArg1().computeValue(context));
/* 385 */     JXPathContext jxpathContext = context.getJXPathContext();
/* 386 */     NodePointer pointer = (NodePointer)jxpathContext.getContextPointer();
/* 387 */     return pointer.getPointerByID(jxpathContext, id);
/*     */   }
/*     */   
/*     */   protected Object functionKey(EvalContext context) {
/* 391 */     assertArgCount(2);
/* 392 */     String key = InfoSetUtil.stringValue(getArg1().computeValue(context));
/* 393 */     String value = InfoSetUtil.stringValue(getArg2().computeValue(context));
/* 394 */     JXPathContext jxpathContext = context.getJXPathContext();
/* 395 */     NodePointer pointer = (NodePointer)jxpathContext.getContextPointer();
/* 396 */     return pointer.getPointerByKey(jxpathContext, key, value);
/*     */   }
/*     */   
/*     */   protected Object functionNamespaceURI(EvalContext context) {
/* 400 */     if (getArgumentCount() == 0) {
/* 401 */       return context.getCurrentNodePointer();
/*     */     }
/* 403 */     assertArgCount(1);
/* 404 */     Object set = getArg1().compute(context);
/* 405 */     if ((set instanceof EvalContext)) {
/* 406 */       EvalContext ctx = (EvalContext)set;
/* 407 */       if (ctx.hasNext()) {
/* 408 */         NodePointer ptr = (NodePointer)ctx.next();
/* 409 */         String str = ptr.getNamespaceURI();
/* 410 */         return str == null ? "" : str;
/*     */       }
/*     */     }
/* 413 */     return "";
/*     */   }
/*     */   
/*     */   protected Object functionLocalName(EvalContext context) {
/* 417 */     if (getArgumentCount() == 0) {
/* 418 */       return context.getCurrentNodePointer();
/*     */     }
/* 420 */     assertArgCount(1);
/* 421 */     Object set = getArg1().compute(context);
/* 422 */     if ((set instanceof EvalContext)) {
/* 423 */       EvalContext ctx = (EvalContext)set;
/* 424 */       if (ctx.hasNext()) {
/* 425 */         NodePointer ptr = (NodePointer)ctx.next();
/* 426 */         return ptr.getName().getName();
/*     */       }
/*     */     }
/* 429 */     return "";
/*     */   }
/*     */   
/*     */   protected Object functionName(EvalContext context) {
/* 433 */     if (getArgumentCount() == 0) {
/* 434 */       return context.getCurrentNodePointer();
/*     */     }
/* 436 */     assertArgCount(1);
/* 437 */     Object set = getArg1().compute(context);
/* 438 */     if ((set instanceof EvalContext)) {
/* 439 */       EvalContext ctx = (EvalContext)set;
/* 440 */       if (ctx.hasNext()) {
/* 441 */         NodePointer ptr = (NodePointer)ctx.next();
/* 442 */         return ptr.getExpandedName().toString();
/*     */       }
/*     */     }
/* 445 */     return "";
/*     */   }
/*     */   
/*     */   protected Object functionString(EvalContext context) {
/* 449 */     if (getArgumentCount() == 0) {
/* 450 */       return InfoSetUtil.stringValue(context.getCurrentNodePointer());
/*     */     }
/* 452 */     assertArgCount(1);
/* 453 */     return InfoSetUtil.stringValue(getArg1().computeValue(context));
/*     */   }
/*     */   
/*     */   protected Object functionConcat(EvalContext context) {
/* 457 */     if (getArgumentCount() < 2) {
/* 458 */       assertArgCount(2);
/*     */     }
/* 460 */     StringBuffer buffer = new StringBuffer();
/* 461 */     Expression[] args = getArguments();
/* 462 */     for (int i = 0; i < args.length; i++) {
/* 463 */       buffer.append(InfoSetUtil.stringValue(args[i].compute(context)));
/*     */     }
/* 465 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   protected Object functionStartsWith(EvalContext context) {
/* 469 */     assertArgCount(2);
/* 470 */     String s1 = InfoSetUtil.stringValue(getArg1().computeValue(context));
/* 471 */     String s2 = InfoSetUtil.stringValue(getArg2().computeValue(context));
/* 472 */     return s1.startsWith(s2) ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */   
/*     */   protected Object functionContains(EvalContext context) {
/* 476 */     assertArgCount(2);
/* 477 */     String s1 = InfoSetUtil.stringValue(getArg1().computeValue(context));
/* 478 */     String s2 = InfoSetUtil.stringValue(getArg2().computeValue(context));
/* 479 */     return s1.indexOf(s2) != -1 ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */   
/*     */   protected Object functionSubstringBefore(EvalContext context) {
/* 483 */     assertArgCount(2);
/* 484 */     String s1 = InfoSetUtil.stringValue(getArg1().computeValue(context));
/* 485 */     String s2 = InfoSetUtil.stringValue(getArg2().computeValue(context));
/* 486 */     int index = s1.indexOf(s2);
/* 487 */     if (index == -1) {
/* 488 */       return "";
/*     */     }
/* 490 */     return s1.substring(0, index);
/*     */   }
/*     */   
/*     */   protected Object functionSubstringAfter(EvalContext context) {
/* 494 */     assertArgCount(2);
/* 495 */     String s1 = InfoSetUtil.stringValue(getArg1().computeValue(context));
/* 496 */     String s2 = InfoSetUtil.stringValue(getArg2().computeValue(context));
/* 497 */     int index = s1.indexOf(s2);
/* 498 */     if (index == -1) {
/* 499 */       return "";
/*     */     }
/* 501 */     return s1.substring(index + s2.length());
/*     */   }
/*     */   
/*     */   protected Object functionSubstring(EvalContext context) {
/* 505 */     int ac = getArgumentCount();
/* 506 */     if ((ac != 2) && (ac != 3)) {
/* 507 */       assertArgCount(2);
/*     */     }
/*     */     
/* 510 */     String s1 = InfoSetUtil.stringValue(getArg1().computeValue(context));
/* 511 */     double from = InfoSetUtil.doubleValue(getArg2().computeValue(context));
/* 512 */     if (Double.isNaN(from)) {
/* 513 */       return "";
/*     */     }
/*     */     
/* 516 */     from = Math.round(from);
/* 517 */     if (ac == 2) {
/* 518 */       if (from < 1.0D) {
/* 519 */         from = 1.0D;
/*     */       }
/* 521 */       return s1.substring((int)from - 1);
/*     */     }
/*     */     
/* 524 */     double length = InfoSetUtil.doubleValue(getArg3().computeValue(context));
/*     */     
/* 526 */     length = Math.round(length);
/* 527 */     if (length < 0.0D) {
/* 528 */       return "";
/*     */     }
/*     */     
/* 531 */     double to = from + length;
/* 532 */     if (to < 1.0D) {
/* 533 */       return "";
/*     */     }
/*     */     
/* 536 */     if (to > s1.length() + 1) {
/* 537 */       if (from < 1.0D) {
/* 538 */         from = 1.0D;
/*     */       }
/* 540 */       return s1.substring((int)from - 1);
/*     */     }
/*     */     
/* 543 */     if (from < 1.0D) {
/* 544 */       from = 1.0D;
/*     */     }
/* 546 */     return s1.substring((int)from - 1, (int)(to - 1.0D));
/*     */   }
/*     */   
/*     */   protected Object functionStringLength(EvalContext context)
/*     */   {
/*     */     String s;
/* 552 */     if (getArgumentCount() == 0) {
/* 553 */       s = InfoSetUtil.stringValue(context.getCurrentNodePointer());
/*     */     }
/*     */     else {
/* 556 */       assertArgCount(1);
/* 557 */       s = InfoSetUtil.stringValue(getArg1().computeValue(context));
/*     */     }
/* 559 */     return new Double(s.length());
/*     */   }
/*     */   
/*     */   protected Object functionNormalizeSpace(EvalContext context) {
/* 563 */     assertArgCount(1);
/* 564 */     String s = InfoSetUtil.stringValue(getArg1().computeValue(context));
/* 565 */     char[] chars = s.toCharArray();
/* 566 */     int out = 0;
/* 567 */     int phase = 0;
/* 568 */     for (int in = 0; in < chars.length; in++) {
/* 569 */       switch (chars[in]) {
/*     */       case '\t': 
/*     */       case '\n': 
/*     */       case '\r': 
/*     */       case ' ': 
/* 574 */         if (phase != 0)
/*     */         {
/*     */ 
/* 577 */           if (phase == 1) {
/* 578 */             phase = 2;
/* 579 */             chars[(out++)] = ' ';
/*     */           } }
/*     */         break;
/*     */       default: 
/* 583 */         chars[(out++)] = chars[in];
/* 584 */         phase = 1;
/*     */       }
/*     */     }
/* 587 */     if (phase == 2) {
/* 588 */       out--;
/*     */     }
/* 590 */     return new String(chars, 0, out);
/*     */   }
/*     */   
/*     */   protected Object functionTranslate(EvalContext context) {
/* 594 */     assertArgCount(3);
/* 595 */     String s1 = InfoSetUtil.stringValue(getArg1().computeValue(context));
/* 596 */     String s2 = InfoSetUtil.stringValue(getArg2().computeValue(context));
/* 597 */     String s3 = InfoSetUtil.stringValue(getArg3().computeValue(context));
/* 598 */     char[] chars = s1.toCharArray();
/* 599 */     int out = 0;
/* 600 */     for (int in = 0; in < chars.length; in++) {
/* 601 */       char c = chars[in];
/* 602 */       int inx = s2.indexOf(c);
/* 603 */       if (inx != -1) {
/* 604 */         if (inx < s3.length()) {
/* 605 */           chars[(out++)] = s3.charAt(inx);
/*     */         }
/*     */       }
/*     */       else {
/* 609 */         chars[(out++)] = c;
/*     */       }
/*     */     }
/* 612 */     return new String(chars, 0, out);
/*     */   }
/*     */   
/*     */   protected Object functionBoolean(EvalContext context) {
/* 616 */     assertArgCount(1);
/* 617 */     return InfoSetUtil.booleanValue(getArg1().computeValue(context)) ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object functionNot(EvalContext context)
/*     */   {
/* 623 */     assertArgCount(1);
/* 624 */     return InfoSetUtil.booleanValue(getArg1().computeValue(context)) ? Boolean.FALSE : Boolean.TRUE;
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object functionTrue(EvalContext context)
/*     */   {
/* 630 */     assertArgCount(0);
/* 631 */     return Boolean.TRUE;
/*     */   }
/*     */   
/*     */   protected Object functionFalse(EvalContext context) {
/* 635 */     assertArgCount(0);
/* 636 */     return Boolean.FALSE;
/*     */   }
/*     */   
/*     */   protected Object functionNull(EvalContext context) {
/* 640 */     assertArgCount(0);
/* 641 */     return null;
/*     */   }
/*     */   
/*     */   protected Object functionNumber(EvalContext context) {
/* 645 */     if (getArgumentCount() == 0) {
/* 646 */       return InfoSetUtil.number(context.getCurrentNodePointer());
/*     */     }
/* 648 */     assertArgCount(1);
/* 649 */     return InfoSetUtil.number(getArg1().computeValue(context));
/*     */   }
/*     */   
/*     */   protected Object functionSum(EvalContext context) {
/* 653 */     assertArgCount(1);
/* 654 */     Object v = getArg1().compute(context);
/* 655 */     if (v == null) {
/* 656 */       return ZERO;
/*     */     }
/* 658 */     if ((v instanceof EvalContext)) {
/* 659 */       double sum = 0.0D;
/* 660 */       EvalContext ctx = (EvalContext)v;
/* 661 */       while (ctx.hasNext()) {
/* 662 */         NodePointer ptr = (NodePointer)ctx.next();
/* 663 */         sum += InfoSetUtil.doubleValue(ptr);
/*     */       }
/* 665 */       return new Double(sum);
/*     */     }
/* 667 */     throw new JXPathException("Invalid argument type for 'sum': " + v.getClass().getName());
/*     */   }
/*     */   
/*     */   protected Object functionFloor(EvalContext context)
/*     */   {
/* 672 */     assertArgCount(1);
/* 673 */     double v = InfoSetUtil.doubleValue(getArg1().computeValue(context));
/* 674 */     return new Double(Math.floor(v));
/*     */   }
/*     */   
/*     */   protected Object functionCeiling(EvalContext context) {
/* 678 */     assertArgCount(1);
/* 679 */     double v = InfoSetUtil.doubleValue(getArg1().computeValue(context));
/* 680 */     return new Double(Math.ceil(v));
/*     */   }
/*     */   
/*     */   protected Object functionRound(EvalContext context) {
/* 684 */     assertArgCount(1);
/* 685 */     double v = InfoSetUtil.doubleValue(getArg1().computeValue(context));
/* 686 */     return new Double(Math.round(v));
/*     */   }
/*     */   
/*     */   private Object functionFormatNumber(EvalContext context) {
/* 690 */     int ac = getArgumentCount();
/* 691 */     if ((ac != 2) && (ac != 3)) {
/* 692 */       assertArgCount(2);
/*     */     }
/*     */     
/* 695 */     double number = InfoSetUtil.doubleValue(getArg1().computeValue(context));
/*     */     
/* 697 */     String pattern = InfoSetUtil.stringValue(getArg2().computeValue(context));
/*     */     
/*     */ 
/* 700 */     DecimalFormatSymbols symbols = null;
/* 701 */     if (ac == 3) {
/* 702 */       String symbolsName = InfoSetUtil.stringValue(getArg3().computeValue(context));
/*     */       
/* 704 */       symbols = context.getJXPathContext().getDecimalFormatSymbols(symbolsName);
/*     */     }
/*     */     else
/*     */     {
/* 708 */       NodePointer pointer = context.getCurrentNodePointer();
/*     */       Locale locale;
/* 710 */       if (pointer != null) {
/* 711 */         locale = pointer.getLocale();
/*     */       }
/*     */       else {
/* 714 */         locale = context.getJXPathContext().getLocale();
/*     */       }
/* 716 */       symbols = new DecimalFormatSymbols(locale);
/*     */     }
/*     */     
/* 719 */     DecimalFormat format = (DecimalFormat)NumberFormat.getInstance();
/* 720 */     format.setDecimalFormatSymbols(symbols);
/* 721 */     format.applyLocalizedPattern(pattern);
/* 722 */     return format.format(number);
/*     */   }
/*     */   
/*     */   private void assertArgCount(int count) {
/* 726 */     if (getArgumentCount() != count) {
/* 727 */       throw new JXPathException("Incorrect number of argument: " + this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/CoreFunction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */