/*     */ package org.apache.commons.jxpath.ri.compiler;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.axes.InitialContext;
/*     */ import org.apache.commons.jxpath.ri.axes.PredicateContext;
/*     */ import org.apache.commons.jxpath.ri.axes.RootContext;
/*     */ import org.apache.commons.jxpath.ri.axes.SimplePathInterpreter;
/*     */ import org.apache.commons.jxpath.ri.axes.UnionContext;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpressionPath
/*     */   extends Path
/*     */ {
/*     */   private Expression expression;
/*     */   private Expression[] predicates;
/*  84 */   private boolean basicKnown = false;
/*     */   
/*     */ 
/*     */   private boolean basic;
/*     */   
/*     */ 
/*     */   public ExpressionPath(Expression expression, Expression[] predicates, Step[] steps)
/*     */   {
/*  92 */     super(steps);
/*  93 */     this.expression = expression;
/*  94 */     this.predicates = predicates;
/*     */   }
/*     */   
/*     */   public Expression getExpression() {
/*  98 */     return this.expression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Expression[] getPredicates()
/*     */   {
/* 106 */     return this.predicates;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean computeContextDependent()
/*     */   {
/* 114 */     if (this.expression.isContextDependent()) {
/* 115 */       return true;
/*     */     }
/* 117 */     if (this.predicates != null) {
/* 118 */       for (int i = 0; i < this.predicates.length; i++) {
/* 119 */         if (this.predicates[i].isContextDependent()) {
/* 120 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 124 */     return super.computeContextDependent();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSimpleExpressionPath()
/*     */   {
/* 132 */     if (!this.basicKnown) {
/* 133 */       this.basicKnown = true;
/* 134 */       this.basic = ((isSimplePath()) && (areBasicPredicates(getPredicates())));
/*     */     }
/* 136 */     return this.basic;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 140 */     StringBuffer buffer = new StringBuffer();
/* 141 */     if (((this.expression instanceof CoreOperation)) || ((this.expression instanceof ExpressionPath)) || ((this.expression instanceof LocationPath)))
/*     */     {
/*     */ 
/* 144 */       buffer.append('(');
/* 145 */       buffer.append(this.expression);
/* 146 */       buffer.append(')');
/*     */     }
/*     */     else {
/* 149 */       buffer.append(this.expression);
/*     */     }
/* 151 */     if (this.predicates != null) {
/* 152 */       for (int i = 0; i < this.predicates.length; i++) {
/* 153 */         buffer.append('[');
/* 154 */         buffer.append(this.predicates[i]);
/* 155 */         buffer.append(']');
/*     */       }
/*     */     }
/*     */     
/* 159 */     Step[] steps = getSteps();
/* 160 */     if (steps != null) {
/* 161 */       for (int i = 0; i < steps.length; i++) {
/* 162 */         buffer.append("/");
/* 163 */         buffer.append(steps[i]);
/*     */       }
/*     */     }
/* 166 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public Object compute(EvalContext context) {
/* 170 */     return expressionPath(context, false);
/*     */   }
/*     */   
/*     */   public Object computeValue(EvalContext context) {
/* 174 */     return expressionPath(context, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object expressionPath(EvalContext evalContext, boolean firstMatch)
/*     */   {
/* 184 */     Object value = this.expression.compute(evalContext);
/*     */     EvalContext context;
/* 186 */     if ((value instanceof InitialContext))
/*     */     {
/*     */ 
/* 189 */       context = (InitialContext)value;
/*     */     }
/* 191 */     else if ((value instanceof EvalContext))
/*     */     {
/*     */ 
/* 194 */       context = new UnionContext(evalContext, new EvalContext[] { (EvalContext)value });
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 200 */       context = evalContext.getRootContext().getConstantContext(value);
/*     */     }
/*     */     
/* 203 */     if ((firstMatch) && (isSimpleExpressionPath()) && (!(context instanceof UnionContext)))
/*     */     {
/*     */ 
/* 206 */       EvalContext ctx = context;
/* 207 */       NodePointer ptr = (NodePointer)ctx.getSingleNodePointer();
/* 208 */       if ((ptr != null) && ((ptr.getIndex() == Integer.MIN_VALUE) || (this.predicates == null) || (this.predicates.length == 0)))
/*     */       {
/*     */ 
/*     */ 
/* 212 */         return SimplePathInterpreter.interpretSimpleExpressionPath(evalContext, ptr, this.predicates, getSteps());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 219 */     if (this.predicates != null) {
/* 220 */       for (int j = 0; j < this.predicates.length; j++) {
/* 221 */         context = new PredicateContext(context, this.predicates[j]);
/*     */       }
/*     */     }
/* 224 */     if (firstMatch) {
/* 225 */       return getSingleNodePointerForSteps(context);
/*     */     }
/*     */     
/* 228 */     return evalSteps(context);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/ExpressionPath.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */