/*     */ package org.apache.commons.jxpath.ri.model.beans;
/*     */ 
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NullElementPointer
/*     */   extends CollectionPointer
/*     */ {
/*     */   public NullElementPointer(NodePointer parent, int index)
/*     */   {
/*  82 */     super(parent, (Object)null);
/*  83 */     this.index = index;
/*     */   }
/*     */   
/*     */   public QName getName() {
/*  87 */     return null;
/*     */   }
/*     */   
/*     */   public Object getBaseValue() {
/*  91 */     return null;
/*     */   }
/*     */   
/*     */   public Object getImmediateNode() {
/*  95 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/*  99 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 103 */     return false;
/*     */   }
/*     */   
/*     */   public PropertyPointer getPropertyPointer() {
/* 107 */     return new NullPropertyPointer(this);
/*     */   }
/*     */   
/*     */   public NodePointer getValuePointer() {
/* 111 */     return new NullPointer(this, getName());
/*     */   }
/*     */   
/*     */   public void setValue(Object value) {
/* 115 */     throw new UnsupportedOperationException("Collection element does not exist: " + this);
/*     */   }
/*     */   
/*     */   public boolean isActual()
/*     */   {
/* 120 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isContainer() {
/* 124 */     return true;
/*     */   }
/*     */   
/*     */   public NodePointer createPath(JXPathContext context) {
/* 128 */     return this.parent.createChild(context, null, this.index);
/*     */   }
/*     */   
/*     */   public NodePointer createPath(JXPathContext context, Object value) {
/* 132 */     return this.parent.createChild(context, null, this.index, value);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 136 */     return getParent().hashCode() + this.index;
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 140 */     if (object == this) {
/* 141 */       return true;
/*     */     }
/*     */     
/* 144 */     if (!(object instanceof NullElementPointer)) {
/* 145 */       return false;
/*     */     }
/*     */     
/* 148 */     NullElementPointer other = (NullElementPointer)object;
/* 149 */     return (getParent() == other.getParent()) && (this.index == other.index);
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 153 */     return 0;
/*     */   }
/*     */   
/*     */   public String asPath() {
/* 157 */     StringBuffer buffer = new StringBuffer();
/* 158 */     NodePointer parent = getParent();
/* 159 */     if (parent != null) {
/* 160 */       buffer.append(parent.asPath());
/*     */     }
/* 162 */     if (this.index != Integer.MIN_VALUE)
/*     */     {
/* 164 */       if ((parent != null) && (parent.getIndex() != Integer.MIN_VALUE)) {
/* 165 */         buffer.append("/.");
/*     */       }
/* 167 */       else if ((parent != null) && (parent.getParent() != null) && (parent.getParent().getIndex() != Integer.MIN_VALUE))
/*     */       {
/*     */ 
/*     */ 
/* 171 */         buffer.append("/.");
/*     */       }
/* 173 */       buffer.append("[").append(this.index + 1).append(']');
/*     */     }
/*     */     
/* 176 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/beans/NullElementPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */