/*     */ package org.apache.commons.jxpath.ri.compiler;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.jxpath.Function;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.axes.RootContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtensionFunction
/*     */   extends Operation
/*     */ {
/*     */   private QName functionName;
/*     */   
/*     */   public ExtensionFunction(QName functionName, Expression[] args)
/*     */   {
/*  83 */     super(args);
/*  84 */     this.functionName = functionName;
/*     */   }
/*     */   
/*     */   public QName getFunctionName() {
/*  88 */     return this.functionName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean computeContextDependent()
/*     */   {
/*  96 */     return true;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 100 */     StringBuffer buffer = new StringBuffer();
/* 101 */     buffer.append(this.functionName);
/* 102 */     buffer.append('(');
/* 103 */     Expression[] args = getArguments();
/* 104 */     if (args != null) {
/* 105 */       for (int i = 0; i < args.length; i++) {
/* 106 */         if (i > 0) {
/* 107 */           buffer.append(", ");
/*     */         }
/* 109 */         buffer.append(args[i]);
/*     */       }
/*     */     }
/* 112 */     buffer.append(')');
/* 113 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public Object compute(EvalContext context) {
/* 117 */     return computeValue(context);
/*     */   }
/*     */   
/*     */   public Object computeValue(EvalContext context) {
/* 121 */     Object[] parameters = null;
/* 122 */     if (this.args != null) {
/* 123 */       parameters = new Object[this.args.length];
/* 124 */       for (int i = 0; i < this.args.length; i++) {
/* 125 */         parameters[i] = convert(this.args[i].compute(context));
/*     */       }
/*     */     }
/*     */     
/* 129 */     Function function = context.getRootContext().getFunction(this.functionName, parameters);
/*     */     
/* 131 */     if (function == null) {
/* 132 */       throw new JXPathException("No such function: " + this.functionName + Arrays.asList(parameters));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 138 */     return function.invoke(context, parameters);
/*     */   }
/*     */   
/*     */   private Object convert(Object object) {
/* 142 */     if ((object instanceof EvalContext)) {
/* 143 */       return ((EvalContext)object).getNodeSet();
/*     */     }
/* 145 */     return object;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/ExtensionFunction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */