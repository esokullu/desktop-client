/*     */ package org.apache.commons.jxpath.ri;
/*     */ 
/*     */ import java.io.StringReader;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.ri.parser.ParseException;
/*     */ import org.apache.commons.jxpath.ri.parser.Token;
/*     */ import org.apache.commons.jxpath.ri.parser.TokenMgrError;
/*     */ import org.apache.commons.jxpath.ri.parser.XPathParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Parser
/*     */ {
/*  79 */   private static XPathParser parser = new XPathParser(new StringReader(""));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object parseExpression(String expression, Compiler compiler)
/*     */   {
/*  89 */     synchronized (parser) {
/*  90 */       parser.setCompiler(compiler);
/*  91 */       Object expr = null;
/*     */       try {
/*  93 */         parser.ReInit(new StringReader(expression));
/*  94 */         expr = parser.parseExpression();
/*     */       }
/*     */       catch (TokenMgrError e) {
/*  97 */         throw new JXPathException("Invalid XPath: '" + addEscapes(expression) + "'. Invalid symbol '" + addEscapes(String.valueOf(e.getCharacter())) + "' " + describePosition(expression, e.getPosition()));
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (ParseException e)
/*     */       {
/*     */ 
/*     */ 
/* 106 */         throw new JXPathException("Invalid XPath: '" + addEscapes(expression) + "'. Syntax error " + describePosition(expression, e.currentToken.beginColumn));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */       e = (TokenMgrError)expr;return e;
/*     */     }
/*     */   }
/*     */   
/*     */   private static String describePosition(String expression, int position) {
/* 119 */     if (position <= 0) {
/* 120 */       return "at the beginning of the expression";
/*     */     }
/* 122 */     if (position >= expression.length()) {
/* 123 */       return "- expression incomplete";
/*     */     }
/*     */     
/* 126 */     return "after: '" + addEscapes(expression.substring(0, position)) + "'";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String addEscapes(String string)
/*     */   {
/* 133 */     return TokenMgrError.addEscapes(string);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/Parser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */