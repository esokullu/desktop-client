/*     */ package org.apache.commons.jxpath.ri;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import org.apache.commons.jxpath.CompiledExpression;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ import org.apache.commons.jxpath.ri.compiler.Expression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JXPathCompiledExpression
/*     */   implements CompiledExpression
/*     */ {
/*     */   private String xpath;
/*     */   private Expression expression;
/*     */   
/*     */   public JXPathCompiledExpression(String xpath, Expression expression)
/*     */   {
/*  81 */     this.xpath = xpath;
/*  82 */     this.expression = expression;
/*     */   }
/*     */   
/*     */   protected String getXPath() {
/*  86 */     return this.xpath;
/*     */   }
/*     */   
/*     */   protected Expression getExpression() {
/*  90 */     return this.expression;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  94 */     return this.xpath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getValue(JXPathContext context)
/*     */   {
/* 101 */     return ((JXPathContextReferenceImpl)context).getValue(this.xpath, this.expression);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValue(JXPathContext context, Class requiredType)
/*     */   {
/* 109 */     return ((JXPathContextReferenceImpl)context).getValue(this.xpath, this.expression, requiredType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(JXPathContext context, Object value)
/*     */   {
/* 117 */     ((JXPathContextReferenceImpl)context).setValue(this.xpath, this.expression, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pointer createPath(JXPathContext context)
/*     */   {
/* 125 */     return ((JXPathContextReferenceImpl)context).createPath(this.xpath, this.expression);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pointer createPathAndSetValue(JXPathContext context, Object value)
/*     */   {
/* 133 */     return ((JXPathContextReferenceImpl)context).createPathAndSetValue(this.xpath, this.expression, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator iterate(JXPathContext context)
/*     */   {
/* 141 */     return ((JXPathContextReferenceImpl)context).iterate(this.xpath, this.expression);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pointer getPointer(JXPathContext context, String xpath)
/*     */   {
/* 149 */     return ((JXPathContextReferenceImpl)context).getPointer(xpath, this.expression);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator iteratePointers(JXPathContext context)
/*     */   {
/* 157 */     return ((JXPathContextReferenceImpl)context).iteratePointers(this.xpath, this.expression);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removePath(JXPathContext context)
/*     */   {
/* 165 */     ((JXPathContextReferenceImpl)context).removePath(this.xpath, this.expression);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void removeAll(JXPathContext context)
/*     */   {
/* 172 */     ((JXPathContextReferenceImpl)context).removeAll(this.xpath, this.expression);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/JXPathCompiledExpression.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */