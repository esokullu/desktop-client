/*    */ package org.apache.commons.jxpath.ri.compiler;
/*    */ 
/*    */ import org.apache.commons.jxpath.ri.EvalContext;
/*    */ import org.apache.commons.jxpath.ri.InfoSetUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoreOperationAdd
/*    */   extends CoreOperation
/*    */ {
/*    */   public CoreOperationAdd(Expression[] args)
/*    */   {
/* 68 */     super(args);
/*    */   }
/*    */   
/*    */   public Object computeValue(EvalContext context) {
/* 72 */     double s = 0.0D;
/* 73 */     for (int i = 0; i < this.args.length; i++) {
/* 74 */       s += InfoSetUtil.doubleValue(this.args[i].computeValue(context));
/*    */     }
/* 76 */     return new Double(s);
/*    */   }
/*    */   
/*    */   protected int getPrecedence() {
/* 80 */     return 4;
/*    */   }
/*    */   
/*    */   protected boolean isSymmetric() {
/* 84 */     return true;
/*    */   }
/*    */   
/*    */   public String getSymbol() {
/* 88 */     return "+";
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/CoreOperationAdd.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */