/*     */ package org.apache.commons.jxpath.ri.model.dom;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMNodeIterator
/*     */   implements NodeIterator
/*     */ {
/*     */   private NodePointer parent;
/*     */   private NodeTest nodeTest;
/*     */   private String namespaceURI;
/*     */   private Node node;
/*  80 */   private Node child = null;
/*     */   private boolean reverse;
/*  82 */   private int position = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMNodeIterator(NodePointer parent, NodeTest nodeTest, boolean reverse, NodePointer startWith)
/*     */   {
/*  90 */     this.parent = parent;
/*  91 */     this.node = ((Node)parent.getNode());
/*  92 */     if (startWith != null) {
/*  93 */       this.child = ((Node)startWith.getNode());
/*     */     }
/*  95 */     this.nodeTest = nodeTest;
/*  96 */     this.reverse = reverse;
/*     */   }
/*     */   
/*     */   public NodePointer getNodePointer() {
/* 100 */     if (this.child == null) {
/* 101 */       if (!setPosition(1)) {
/* 102 */         return null;
/*     */       }
/* 104 */       this.position = 0;
/*     */     }
/*     */     
/* 107 */     return new DOMNodePointer(this.parent, this.child);
/*     */   }
/*     */   
/*     */   public int getPosition() {
/* 111 */     return this.position;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 115 */     while (this.position < position) {
/* 116 */       if (!next()) {
/* 117 */         return false;
/*     */       }
/*     */     }
/* 120 */     while (this.position > position) {
/* 121 */       if (!previous()) {
/* 122 */         return false;
/*     */       }
/*     */     }
/* 125 */     return true;
/*     */   }
/*     */   
/*     */   private boolean previous() {
/* 129 */     this.position -= 1;
/* 130 */     if (!this.reverse) {
/* 131 */       this.child = this.child.getPreviousSibling();
/*     */       do {
/* 133 */         this.child = this.child.getPreviousSibling();
/* 132 */         if (this.child == null) break; } while (!testChild());
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 137 */       this.child = this.child.getNextSibling();
/* 138 */       while ((this.child != null) && (!testChild())) {
/* 139 */         this.child = this.child.getNextSibling();
/*     */       }
/*     */     }
/* 142 */     return this.child != null;
/*     */   }
/*     */   
/*     */   private boolean next() {
/* 146 */     this.position += 1;
/* 147 */     if (!this.reverse) {
/* 148 */       if (this.position == 1) {
/* 149 */         if (this.child == null) {
/* 150 */           this.child = this.node.getFirstChild();
/*     */         }
/*     */         else {
/* 153 */           this.child = this.child.getNextSibling();
/*     */         }
/*     */       }
/*     */       else {
/* 157 */         this.child = this.child.getNextSibling();
/*     */       }
/*     */       do {
/* 160 */         this.child = this.child.getNextSibling();
/* 159 */         if (this.child == null) break; } while (!testChild());
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 164 */       if (this.position == 1) {
/* 165 */         if (this.child == null) {
/* 166 */           this.child = this.node.getLastChild();
/*     */         }
/*     */         else {
/* 169 */           this.child = this.child.getPreviousSibling();
/*     */         }
/*     */       }
/*     */       else {
/* 173 */         this.child = this.child.getPreviousSibling();
/*     */       }
/* 175 */       while ((this.child != null) && (!testChild())) {
/* 176 */         this.child = this.child.getPreviousSibling();
/*     */       }
/*     */     }
/* 179 */     return this.child != null;
/*     */   }
/*     */   
/*     */   private boolean testChild() {
/* 183 */     return DOMNodePointer.testNode(this.parent, this.child, this.nodeTest);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dom/DOMNodeIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */