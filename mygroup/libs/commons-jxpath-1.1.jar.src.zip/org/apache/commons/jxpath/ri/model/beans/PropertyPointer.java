/*     */ package org.apache.commons.jxpath.ri.model.beans;
/*     */ 
/*     */ import org.apache.commons.jxpath.AbstractFactory;
/*     */ import org.apache.commons.jxpath.JXPathBeanInfo;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.JXPathIntrospector;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.util.ValueUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PropertyPointer
/*     */   extends NodePointer
/*     */ {
/*     */   public static final int UNSPECIFIED_PROPERTY = Integer.MIN_VALUE;
/*  82 */   protected int propertyIndex = Integer.MIN_VALUE;
/*     */   
/*     */ 
/*     */   protected Object bean;
/*     */   
/*     */ 
/*     */   public PropertyPointer(NodePointer parent)
/*     */   {
/*  90 */     super(parent);
/*     */   }
/*     */   
/*     */   public int getPropertyIndex() {
/*  94 */     return this.propertyIndex;
/*     */   }
/*     */   
/*     */   public void setPropertyIndex(int index) {
/*  98 */     this.propertyIndex = index;
/*  99 */     index = Integer.MIN_VALUE;
/*     */   }
/*     */   
/*     */   public Object getBean() {
/* 103 */     if (this.bean == null) {
/* 104 */       this.bean = getParent().getNode();
/*     */     }
/* 106 */     return this.bean;
/*     */   }
/*     */   
/*     */   public QName getName() {
/* 110 */     return new QName(null, getPropertyName());
/*     */   }
/*     */   
/*     */   public abstract String getPropertyName();
/*     */   
/*     */   public abstract void setPropertyName(String paramString);
/*     */   
/*     */   public abstract int getPropertyCount();
/*     */   
/*     */   public abstract String[] getPropertyNames();
/*     */   
/*     */   protected abstract boolean isActualProperty();
/*     */   
/*     */   public boolean isActual() {
/* 124 */     if (!isActualProperty()) {
/* 125 */       return false;
/*     */     }
/*     */     
/* 128 */     return super.isActual();
/*     */   }
/*     */   
/* 131 */   private static final Object UNINITIALIZED = new Object();
/*     */   
/* 133 */   private Object value = UNINITIALIZED;
/*     */   
/* 135 */   public Object getImmediateNode() { if (this.value == UNINITIALIZED) {
/* 136 */       if (this.index == Integer.MIN_VALUE) {
/* 137 */         this.value = getBaseValue();
/*     */       }
/*     */       else {
/* 140 */         this.value = ValueUtils.getValue(getBaseValue(), this.index);
/*     */       }
/*     */     }
/* 143 */     return this.value;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 147 */     Object value = getBaseValue();
/* 148 */     return (value != null) && (ValueUtils.isCollection(value));
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 152 */     Object value = getNode();
/* 153 */     return (value == null) || (JXPathIntrospector.getBeanInfo(value.getClass()).isAtomic());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 162 */     return ValueUtils.getLength(getBaseValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer getImmediateValuePointer()
/*     */   {
/* 171 */     return NodePointer.newChildNodePointer(this, getName(), getImmediateNode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public NodePointer createPath(JXPathContext context)
/*     */   {
/* 178 */     if (getImmediateNode() == null) {
/* 179 */       AbstractFactory factory = getAbstractFactory(context);
/* 180 */       int inx = this.index == Integer.MIN_VALUE ? 0 : this.index;
/* 181 */       boolean success = factory.createObject(context, this, getBean(), getPropertyName(), inx);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 188 */       if (!success) {
/* 189 */         throw new JXPathException("Factory " + factory + " could not create an object for path: " + asPath());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 196 */     return this;
/*     */   }
/*     */   
/*     */   public NodePointer createPath(JXPathContext context, Object value)
/*     */   {
/* 201 */     if ((this.index != Integer.MIN_VALUE) && (this.index >= getLength())) {
/* 202 */       createPath(context);
/*     */     }
/* 204 */     setValue(value);
/* 205 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index, Object value)
/*     */   {
/* 214 */     PropertyPointer prop = (PropertyPointer)clone();
/* 215 */     if (name != null) {
/* 216 */       prop.setPropertyName(name.toString());
/*     */     }
/* 218 */     prop.setIndex(index);
/* 219 */     return prop.createPath(context, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index)
/*     */   {
/* 227 */     PropertyPointer prop = (PropertyPointer)clone();
/* 228 */     if (name != null) {
/* 229 */       prop.setPropertyName(name.toString());
/*     */     }
/* 231 */     prop.setIndex(index);
/* 232 */     return prop.createPath(context);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 236 */     return getParent().hashCode() + this.propertyIndex + this.index;
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 240 */     if (object == this) {
/* 241 */       return true;
/*     */     }
/*     */     
/* 244 */     if (!(object instanceof PropertyPointer)) {
/* 245 */       return false;
/*     */     }
/*     */     
/* 248 */     PropertyPointer other = (PropertyPointer)object;
/* 249 */     if ((this.parent != other.parent) && (
/* 250 */       (this.parent == null) || (!this.parent.equals(other.parent)))) {
/* 251 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 255 */     if ((getPropertyIndex() != other.getPropertyIndex()) || (!getPropertyName().equals(other.getPropertyName())))
/*     */     {
/* 257 */       return false;
/*     */     }
/*     */     
/* 260 */     int iThis = this.index == Integer.MIN_VALUE ? 0 : this.index;
/* 261 */     int iOther = other.index == Integer.MIN_VALUE ? 0 : other.index;
/* 262 */     return iThis == iOther;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2)
/*     */   {
/* 269 */     return getValuePointer().compareChildNodePointers(pointer1, pointer2);
/*     */   }
/*     */   
/*     */   private AbstractFactory getAbstractFactory(JXPathContext context) {
/* 273 */     AbstractFactory factory = context.getFactory();
/* 274 */     if (factory == null) {
/* 275 */       throw new JXPathException("Factory is not set on the JXPathContext - cannot create path: " + asPath());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 280 */     return factory;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/beans/PropertyPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */