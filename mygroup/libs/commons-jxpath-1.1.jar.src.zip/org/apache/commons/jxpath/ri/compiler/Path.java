/*     */ package org.apache.commons.jxpath.ri.compiler;
/*     */ 
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.axes.AncestorContext;
/*     */ import org.apache.commons.jxpath.ri.axes.AttributeContext;
/*     */ import org.apache.commons.jxpath.ri.axes.ChildContext;
/*     */ import org.apache.commons.jxpath.ri.axes.DescendantContext;
/*     */ import org.apache.commons.jxpath.ri.axes.NamespaceContext;
/*     */ import org.apache.commons.jxpath.ri.axes.ParentContext;
/*     */ import org.apache.commons.jxpath.ri.axes.PrecedingOrFollowingContext;
/*     */ import org.apache.commons.jxpath.ri.axes.PredicateContext;
/*     */ import org.apache.commons.jxpath.ri.axes.SelfContext;
/*     */ import org.apache.commons.jxpath.ri.axes.SimplePathInterpreter;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Path
/*     */   extends Expression
/*     */ {
/*     */   private Step[] steps;
/*  86 */   private boolean basicKnown = false;
/*     */   private boolean basic;
/*     */   
/*     */   public Path(Step[] steps) {
/*  90 */     this.steps = steps;
/*     */   }
/*     */   
/*     */   public Step[] getSteps() {
/*  94 */     return this.steps;
/*     */   }
/*     */   
/*     */   public boolean computeContextDependent() {
/*  98 */     if (this.steps != null) {
/*  99 */       for (int i = 0; i < this.steps.length; i++) {
/* 100 */         if (this.steps[i].isContextDependent()) {
/* 101 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 106 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSimplePath()
/*     */   {
/* 115 */     if (!this.basicKnown) {
/* 116 */       this.basicKnown = true;
/* 117 */       this.basic = true;
/* 118 */       Step[] steps = getSteps();
/* 119 */       for (int i = 0; i < steps.length; i++) {
/* 120 */         boolean accepted = false;
/* 121 */         if ((steps[i].getAxis() == 1) && ((steps[i].getNodeTest() instanceof NodeTypeTest)) && (((NodeTypeTest)steps[i].getNodeTest()).getNodeType() == 1))
/*     */         {
/*     */ 
/*     */ 
/* 125 */           accepted = true;
/*     */         }
/* 127 */         else if (((steps[i].getAxis() == 2) || (steps[i].getAxis() == 5)) && ((steps[i].getNodeTest() instanceof NodeNameTest)) && (!((NodeNameTest)steps[i].getNodeTest()).getNodeName().getName().equals("*")))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */           accepted = true;
/*     */         }
/* 138 */         if (accepted) {
/* 139 */           accepted = areBasicPredicates(steps[i].getPredicates());
/*     */         }
/* 141 */         if (!accepted) {
/* 142 */           this.basic = false;
/* 143 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 147 */     return this.basic;
/*     */   }
/*     */   
/*     */   protected boolean areBasicPredicates(Expression[] predicates) {
/* 151 */     if ((predicates != null) && (predicates.length != 0)) {
/* 152 */       boolean firstIndex = true;
/* 153 */       for (int i = 0; i < predicates.length; i++) {
/* 154 */         if ((predicates[i] instanceof NameAttributeTest)) {
/* 155 */           if (((NameAttributeTest)predicates[i]).getNameTestExpression().isContextDependent())
/*     */           {
/*     */ 
/* 158 */             return false;
/*     */           }
/*     */         } else {
/* 161 */           if (predicates[i].isContextDependent()) {
/* 162 */             return false;
/*     */           }
/*     */           
/* 165 */           if (!firstIndex) {
/* 166 */             return false;
/*     */           }
/* 168 */           firstIndex = false;
/*     */         }
/*     */       }
/*     */     }
/* 172 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Pointer getSingleNodePointerForSteps(EvalContext context)
/*     */   {
/* 180 */     if (this.steps.length == 0) {
/* 181 */       return context.getSingleNodePointer();
/*     */     }
/*     */     
/* 184 */     if (isSimplePath()) {
/* 185 */       NodePointer ptr = (NodePointer)context.getSingleNodePointer();
/* 186 */       return SimplePathInterpreter.interpretSimpleLocationPath(context, ptr, this.steps);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 192 */     return searchForPath(context);
/*     */   }
/*     */   
/*     */   private Pointer searchForPath(EvalContext context)
/*     */   {
/* 197 */     for (int i = 0; i < this.steps.length; i++) {
/* 198 */       context = createContextForStep(context, this.steps[i].getAxis(), this.steps[i].getNodeTest());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 203 */       Expression[] predicates = this.steps[i].getPredicates();
/* 204 */       if (predicates != null) {
/* 205 */         for (int j = 0; j < predicates.length; j++) {
/* 206 */           context = new PredicateContext(context, predicates[j]);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 211 */     return context.getSingleNodePointer();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected EvalContext evalSteps(EvalContext context)
/*     */   {
/* 219 */     if (this.steps.length == 0) {
/* 220 */       return context;
/*     */     }
/*     */     
/* 223 */     for (int i = 0; i < this.steps.length; i++) {
/* 224 */       context = createContextForStep(context, this.steps[i].getAxis(), this.steps[i].getNodeTest());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 229 */       Expression[] predicates = this.steps[i].getPredicates();
/* 230 */       if (predicates != null) {
/* 231 */         for (int j = 0; j < predicates.length; j++) {
/* 232 */           context = new PredicateContext(context, predicates[j]);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 237 */     return context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected EvalContext createContextForStep(EvalContext context, int axis, NodeTest nodeTest)
/*     */   {
/* 249 */     switch (axis) {
/*     */     case 4: 
/* 251 */       return new AncestorContext(context, false, nodeTest);
/*     */     case 10: 
/* 253 */       return new AncestorContext(context, true, nodeTest);
/*     */     case 5: 
/* 255 */       return new AttributeContext(context, nodeTest);
/*     */     case 2: 
/* 257 */       return new ChildContext(context, nodeTest, false, false);
/*     */     case 9: 
/* 259 */       return new DescendantContext(context, false, nodeTest);
/*     */     case 13: 
/* 261 */       return new DescendantContext(context, true, nodeTest);
/*     */     case 8: 
/* 263 */       return new PrecedingOrFollowingContext(context, nodeTest, false);
/*     */     
/*     */ 
/*     */ 
/*     */     case 11: 
/* 268 */       return new ChildContext(context, nodeTest, true, false);
/*     */     case 6: 
/* 270 */       return new NamespaceContext(context, nodeTest);
/*     */     case 3: 
/* 272 */       return new ParentContext(context, nodeTest);
/*     */     case 7: 
/* 274 */       return new PrecedingOrFollowingContext(context, nodeTest, true);
/*     */     case 12: 
/* 276 */       return new ChildContext(context, nodeTest, true, true);
/*     */     case 1: 
/* 278 */       return new SelfContext(context, nodeTest);
/*     */     }
/* 280 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/Path.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */