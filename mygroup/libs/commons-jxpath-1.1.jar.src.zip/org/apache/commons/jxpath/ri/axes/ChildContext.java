/*     */ package org.apache.commons.jxpath.ri.axes;
/*     */ 
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChildContext
/*     */   extends EvalContext
/*     */ {
/*     */   private NodeTest nodeTest;
/*     */   private boolean startFromParentLocation;
/*     */   private boolean reverse;
/*     */   private NodeIterator iterator;
/*     */   
/*     */   public ChildContext(EvalContext parentContext, NodeTest nodeTest, boolean startFromParentLocation, boolean reverse)
/*     */   {
/*  89 */     super(parentContext);
/*  90 */     this.nodeTest = nodeTest;
/*  91 */     this.startFromParentLocation = startFromParentLocation;
/*  92 */     this.reverse = reverse;
/*     */   }
/*     */   
/*     */   public NodePointer getCurrentNodePointer() {
/*  96 */     if ((this.position == 0) && 
/*  97 */       (!setPosition(1))) {
/*  98 */       return null;
/*     */     }
/*     */     
/* 101 */     if (this.iterator != null) {
/* 102 */       return this.iterator.getNodePointer();
/*     */     }
/*     */     
/* 105 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pointer getSingleNodePointer()
/*     */   {
/* 117 */     if (this.position == 0) {
/* 118 */       while (nextSet()) {
/* 119 */         prepare();
/* 120 */         if (this.iterator == null) {
/* 121 */           return null;
/*     */         }
/*     */         
/* 124 */         NodePointer pointer = this.iterator.getNodePointer();
/* 125 */         if (pointer != null) {
/* 126 */           return pointer;
/*     */         }
/*     */       }
/* 129 */       return null;
/*     */     }
/* 131 */     return getCurrentNodePointer();
/*     */   }
/*     */   
/*     */   public boolean nextNode() {
/* 135 */     return setPosition(getCurrentPosition() + 1);
/*     */   }
/*     */   
/*     */   public void reset() {
/* 139 */     super.reset();
/* 140 */     this.iterator = null;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 144 */     int oldPosition = getCurrentPosition();
/* 145 */     super.setPosition(position);
/* 146 */     if (oldPosition == 0) {
/* 147 */       prepare();
/*     */     }
/* 149 */     if (this.iterator == null) {
/* 150 */       return false;
/*     */     }
/* 152 */     return this.iterator.setPosition(position);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void prepare()
/*     */   {
/* 159 */     NodePointer parent = this.parentContext.getCurrentNodePointer();
/* 160 */     if (parent == null) {
/* 161 */       return;
/*     */     }
/* 163 */     if (this.startFromParentLocation) {
/* 164 */       NodePointer pointer = parent.getParent();
/* 165 */       while ((pointer != null) && (pointer.isContainer())) {
/* 166 */         pointer = pointer.getParent();
/*     */       }
/*     */       
/* 169 */       this.iterator = pointer.childIterator(this.nodeTest, this.reverse, parent);
/*     */     }
/*     */     else {
/* 172 */       this.iterator = parent.childIterator(this.nodeTest, this.reverse, null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/axes/ChildContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */