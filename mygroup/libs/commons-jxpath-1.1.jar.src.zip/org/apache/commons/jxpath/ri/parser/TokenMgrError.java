/*     */ package org.apache.commons.jxpath.ri.parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenMgrError
/*     */   extends Error
/*     */ {
/*     */   static final int LEXICAL_ERROR = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int STATIC_LEXER_ERROR = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int INVALID_LEXICAL_STATE = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int LOOP_DETECTED = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int errorCode;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int position;
/*     */   
/*     */ 
/*     */ 
/*     */   private char character;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String addEscapes(String str)
/*     */   {
/*  46 */     StringBuffer retval = new StringBuffer();
/*     */     
/*  48 */     for (int i = 0; i < str.length(); i++) {
/*  49 */       switch (str.charAt(i))
/*     */       {
/*     */       case '\000': 
/*     */         break;
/*     */       case '\b': 
/*  54 */         retval.append("\\b");
/*  55 */         break;
/*     */       case '\t': 
/*  57 */         retval.append("\\t");
/*  58 */         break;
/*     */       case '\n': 
/*  60 */         retval.append("\\n");
/*  61 */         break;
/*     */       case '\f': 
/*  63 */         retval.append("\\f");
/*  64 */         break;
/*     */       case '\r': 
/*  66 */         retval.append("\\r");
/*  67 */         break;
/*     */       case '"': 
/*  69 */         retval.append("\\\"");
/*  70 */         break;
/*     */       case '\'': 
/*  72 */         retval.append("\\'");
/*  73 */         break;
/*     */       case '\\': 
/*  75 */         retval.append("\\\\");
/*  76 */         break;
/*     */       default:  char ch;
/*  78 */         if (((ch = str.charAt(i)) < ' ') || (ch > '~')) {
/*  79 */           String s = "0000" + Integer.toString(ch, 16);
/*  80 */           retval.append("\\u" + s.substring(s.length() - 4, s.length()));
/*     */         } else {
/*  82 */           retval.append(ch);
/*     */         }
/*     */         break;
/*     */       }
/*     */     }
/*  87 */     return retval.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String LexicalError(boolean EOFSeen, int lexState, int errorLine, int errorColumn, String errorAfter, char curChar)
/*     */   {
/* 103 */     return "Lexical error at line " + errorLine + ", column " + errorColumn + ".  Encountered: " + (EOFSeen ? "<EOF> " : new StringBuffer().append("\"").append(addEscapes(String.valueOf(curChar))).append("\"").append(" (").append(curChar).append("), ").toString()) + "after : \"" + addEscapes(errorAfter) + "\"";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 120 */     return super.getMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TokenMgrError() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public TokenMgrError(String message, int reason)
/*     */   {
/* 131 */     super(message);
/* 132 */     this.errorCode = reason;
/*     */   }
/*     */   
/*     */   public TokenMgrError(boolean EOFSeen, int lexState, int errorLine, int errorColumn, String errorAfter, char curChar, int reason) {
/* 136 */     this(LexicalError(EOFSeen, lexState, errorLine, errorColumn, errorAfter, curChar), reason);
/*     */     
/*     */ 
/* 139 */     this.position = (errorColumn - 1);
/* 140 */     this.character = curChar;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPosition()
/*     */   {
/* 149 */     return this.position;
/*     */   }
/*     */   
/*     */   public char getCharacter() {
/* 153 */     return this.character;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/parser/TokenMgrError.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */