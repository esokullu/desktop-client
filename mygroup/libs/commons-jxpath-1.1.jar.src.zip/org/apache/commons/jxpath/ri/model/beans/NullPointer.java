/*     */ package org.apache.commons.jxpath.ri.model.beans;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NullPointer
/*     */   extends PropertyOwnerPointer
/*     */ {
/*     */   private QName name;
/*     */   private String id;
/*     */   
/*     */   public NullPointer(QName name, Locale locale)
/*     */   {
/*  79 */     super(null, locale);
/*  80 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public NullPointer(NodePointer parent, QName name)
/*     */   {
/*  87 */     super(parent);
/*  88 */     this.name = name;
/*     */   }
/*     */   
/*     */   public NullPointer(Locale locale, String id) {
/*  92 */     super(null, locale);
/*  93 */     this.id = id;
/*     */   }
/*     */   
/*     */   public QName getName() {
/*  97 */     return this.name;
/*     */   }
/*     */   
/*     */   public Object getBaseValue() {
/* 101 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 105 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 109 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isActual() {
/* 113 */     return false;
/*     */   }
/*     */   
/*     */   public PropertyPointer getPropertyPointer() {
/* 117 */     return new NullPropertyPointer(this);
/*     */   }
/*     */   
/*     */   public NodePointer createPath(JXPathContext context, Object value) {
/* 121 */     if (this.parent != null) {
/* 122 */       return this.parent.createPath(context, value).getValuePointer();
/*     */     }
/*     */     
/* 125 */     throw new UnsupportedOperationException("Cannot create the root object: " + asPath());
/*     */   }
/*     */   
/*     */ 
/*     */   public NodePointer createPath(JXPathContext context)
/*     */   {
/* 131 */     if (this.parent != null) {
/* 132 */       return this.parent.createPath(context).getValuePointer();
/*     */     }
/*     */     
/* 135 */     throw new UnsupportedOperationException("Cannot create the root object: " + asPath());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index)
/*     */   {
/* 145 */     return createPath(context).createChild(context, name, index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index, Object value)
/*     */   {
/* 154 */     return createPath(context).createChild(context, name, index, value);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 158 */     return this.name == null ? 0 : this.name.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 162 */     if (object == this) {
/* 163 */       return true;
/*     */     }
/*     */     
/* 166 */     if (!(object instanceof NullPointer)) {
/* 167 */       return false;
/*     */     }
/*     */     
/* 170 */     NullPointer other = (NullPointer)object;
/* 171 */     return ((this.name == null) && (other.name == null)) || ((this.name != null) && (this.name.equals(other.name)));
/*     */   }
/*     */   
/*     */   public String asPath()
/*     */   {
/* 176 */     if (this.id != null) {
/* 177 */       return "id(" + this.id + ")";
/*     */     }
/*     */     
/* 180 */     if (this.parent != null) {
/* 181 */       return super.asPath();
/*     */     }
/* 183 */     return "null()";
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 187 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/beans/NullPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */