/*     */ package org.apache.commons.jxpath.ri.model.dom;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.util.TypeUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMAttributePointer
/*     */   extends NodePointer
/*     */ {
/*     */   private Attr attr;
/*     */   
/*     */   public DOMAttributePointer(NodePointer parent, Attr attr)
/*     */   {
/*  82 */     super(parent);
/*  83 */     this.attr = attr;
/*     */   }
/*     */   
/*     */   public QName getName() {
/*  87 */     return new QName(DOMNodePointer.getPrefix(this.attr), DOMNodePointer.getLocalName(this.attr));
/*     */   }
/*     */   
/*     */ 
/*     */   public QName getExpandedName()
/*     */   {
/*  93 */     return new QName(getNamespaceURI(), DOMNodePointer.getLocalName(this.attr));
/*     */   }
/*     */   
/*     */   public String getNamespaceURI() {
/*  97 */     String prefix = DOMNodePointer.getPrefix(this.attr);
/*  98 */     if (prefix == null) {
/*  99 */       return null;
/*     */     }
/* 101 */     return this.parent.getNamespaceURI(prefix);
/*     */   }
/*     */   
/*     */   public Object getBaseValue() {
/* 105 */     return this.attr;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 109 */     return false;
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 113 */     return 1;
/*     */   }
/*     */   
/*     */   public Object getImmediateNode() {
/* 117 */     String value = this.attr.getValue();
/* 118 */     if (value == null) {
/* 119 */       return null;
/*     */     }
/* 121 */     if ((value.equals("")) && (!this.attr.getSpecified())) {
/* 122 */       return null;
/*     */     }
/* 124 */     return value;
/*     */   }
/*     */   
/*     */   public boolean isActual() {
/* 128 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 132 */     return true;
/*     */   }
/*     */   
/*     */   public boolean testNode(NodeTest nodeTest) {
/* 136 */     return (nodeTest == null) || (((nodeTest instanceof NodeTypeTest)) && (((NodeTypeTest)nodeTest).getNodeType() == 1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/* 146 */     this.attr.setValue((String)TypeUtils.convert(value, String.class));
/*     */   }
/*     */   
/*     */   public void remove() {
/* 150 */     this.attr.getOwnerElement().removeAttributeNode(this.attr);
/*     */   }
/*     */   
/*     */ 
/*     */   public String asPath()
/*     */   {
/* 156 */     StringBuffer buffer = new StringBuffer();
/* 157 */     if (this.parent != null) {
/* 158 */       buffer.append(this.parent.asPath());
/* 159 */       if ((buffer.length() == 0) || (buffer.charAt(buffer.length() - 1) != '/'))
/*     */       {
/* 161 */         buffer.append('/');
/*     */       }
/*     */     }
/* 164 */     buffer.append('@');
/* 165 */     buffer.append(getName());
/* 166 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 170 */     return System.identityHashCode(this.attr);
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 174 */     if (object == this) {
/* 175 */       return true;
/*     */     }
/*     */     
/* 178 */     if (!(object instanceof DOMAttributePointer)) {
/* 179 */       return false;
/*     */     }
/*     */     
/* 182 */     DOMAttributePointer other = (DOMAttributePointer)object;
/* 183 */     return this.attr == other.attr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2)
/*     */   {
/* 191 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dom/DOMAttributePointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */