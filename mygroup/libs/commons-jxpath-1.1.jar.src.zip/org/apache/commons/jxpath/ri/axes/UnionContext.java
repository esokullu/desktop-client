/*     */ package org.apache.commons.jxpath.ri.axes;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnionContext
/*     */   extends EvalContext
/*     */ {
/*  79 */   private boolean startedSet = false;
/*     */   private EvalContext[] contexts;
/*     */   private List list;
/*     */   
/*     */   public UnionContext(EvalContext parentContext, EvalContext[] contexts) {
/*  84 */     super(parentContext);
/*  85 */     this.contexts = contexts;
/*     */   }
/*     */   
/*     */   public int getDocumentOrder() {
/*  89 */     if (this.contexts.length > 1) {
/*  90 */       return 1;
/*     */     }
/*  92 */     return super.getDocumentOrder();
/*     */   }
/*     */   
/*     */   public NodePointer getCurrentNodePointer() {
/*  96 */     if ((this.position == 0) && 
/*  97 */       (!setPosition(1))) {
/*  98 */       return null;
/*     */     }
/*     */     
/* 101 */     return (NodePointer)this.list.get(this.position - 1);
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 105 */     super.setPosition(position);
/* 106 */     if (this.list == null) {
/* 107 */       prepareList();
/*     */     }
/* 109 */     return (position >= 1) && (position <= this.list.size());
/*     */   }
/*     */   
/*     */   public boolean nextSet() {
/* 113 */     if (this.startedSet) {
/* 114 */       return false;
/*     */     }
/* 116 */     this.startedSet = true;
/* 117 */     return true;
/*     */   }
/*     */   
/*     */   public boolean nextNode() {
/* 121 */     return setPosition(this.position + 1);
/*     */   }
/*     */   
/*     */   private void prepareList() {
/* 125 */     this.list = new ArrayList();
/* 126 */     HashSet set = new HashSet();
/* 127 */     for (int i = 0; i < this.contexts.length; i++) {
/* 128 */       EvalContext ctx = this.contexts[i];
/* 129 */       for (goto 88; ctx.nextSet(); 
/* 130 */           ctx.nextNode()) {
/* 131 */         continue;NodePointer ptr = ctx.getCurrentNodePointer();
/* 132 */         if (!set.contains(ptr)) {
/* 133 */           ptr = (NodePointer)ptr.clone();
/* 134 */           this.list.add(ptr);
/* 135 */           set.add(ptr);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/axes/UnionContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */