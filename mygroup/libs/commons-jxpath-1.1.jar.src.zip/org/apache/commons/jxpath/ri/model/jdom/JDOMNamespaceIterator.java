/*     */ package org.apache.commons.jxpath.ri.model.jdom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.Namespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDOMNamespaceIterator
/*     */   implements NodeIterator
/*     */ {
/*     */   private NodePointer parent;
/*     */   private List namespaces;
/*     */   private Set prefixes;
/*  84 */   private int position = 0;
/*     */   
/*     */   public JDOMNamespaceIterator(NodePointer parent) {
/*  87 */     this.parent = parent;
/*  88 */     Object node = parent.getNode();
/*  89 */     if ((node instanceof Element)) {
/*  90 */       this.namespaces = new ArrayList();
/*  91 */       this.prefixes = new HashSet();
/*  92 */       collectNamespaces((Element)parent.getNode());
/*     */     }
/*     */   }
/*     */   
/*     */   private void collectNamespaces(Element element) {
/*  97 */     Namespace ns = element.getNamespace();
/*  98 */     if ((ns != null) && (!this.prefixes.contains(ns.getPrefix()))) {
/*  99 */       this.namespaces.add(ns);
/* 100 */       this.prefixes.add(ns.getPrefix());
/*     */     }
/* 102 */     List others = element.getAdditionalNamespaces();
/* 103 */     for (int i = 0; i < others.size(); i++) {
/* 104 */       ns = (Namespace)others.get(i);
/* 105 */       if ((ns != null) && (!this.prefixes.contains(ns.getPrefix()))) {
/* 106 */         this.namespaces.add(ns);
/* 107 */         this.prefixes.add(ns.getPrefix());
/*     */       }
/*     */     }
/* 110 */     Element parent = element.getParent();
/* 111 */     if (parent != null) {
/* 112 */       collectNamespaces(parent);
/*     */     }
/*     */   }
/*     */   
/*     */   public NodePointer getNodePointer() {
/* 117 */     if (this.position == 0) {
/* 118 */       if (!setPosition(1)) {
/* 119 */         return null;
/*     */       }
/* 121 */       this.position = 0;
/*     */     }
/* 123 */     int index = this.position - 1;
/* 124 */     if (index < 0) {
/* 125 */       index = 0;
/*     */     }
/* 127 */     Namespace ns = (Namespace)this.namespaces.get(index);
/* 128 */     return new JDOMNamespacePointer(this.parent, ns.getPrefix(), ns.getURI());
/*     */   }
/*     */   
/*     */   public int getPosition() {
/* 132 */     return this.position;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 136 */     this.position = position;
/* 137 */     return (position >= 1) && (position <= this.namespaces.size());
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/jdom/JDOMNamespaceIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */