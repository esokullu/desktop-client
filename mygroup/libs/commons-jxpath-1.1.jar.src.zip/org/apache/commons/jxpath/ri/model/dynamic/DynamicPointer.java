/*     */ package org.apache.commons.jxpath.ri.model.dynamic;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.DynamicPropertyHandler;
/*     */ import org.apache.commons.jxpath.JXPathBeanInfo;
/*     */ import org.apache.commons.jxpath.JXPathIntrospector;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.PropertyOwnerPointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.PropertyPointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DynamicPointer
/*     */   extends PropertyOwnerPointer
/*     */ {
/*     */   private QName name;
/*     */   private Object bean;
/*     */   private DynamicPropertyHandler handler;
/*     */   private String[] names;
/*     */   
/*     */   public DynamicPointer(QName name, Object bean, DynamicPropertyHandler handler, Locale locale)
/*     */   {
/*  91 */     super(null, locale);
/*  92 */     this.name = name;
/*  93 */     this.bean = bean;
/*  94 */     this.handler = handler;
/*     */   }
/*     */   
/*     */ 
/*     */   public DynamicPointer(NodePointer parent, QName name, Object bean, DynamicPropertyHandler handler)
/*     */   {
/* 100 */     super(parent);
/* 101 */     this.name = name;
/* 102 */     this.bean = bean;
/* 103 */     this.handler = handler;
/*     */   }
/*     */   
/*     */   public PropertyPointer getPropertyPointer() {
/* 107 */     return new DynamicPropertyPointer(this, this.handler);
/*     */   }
/*     */   
/*     */ 
/*     */   public NodeIterator createNodeIterator(String property, boolean reverse, NodePointer startWith)
/*     */   {
/* 113 */     return new DynamicPropertyIterator(this, property, reverse, startWith);
/*     */   }
/*     */   
/*     */   public NodeIterator attributeIterator(QName name) {
/* 117 */     return new DynamicAttributeIterator(this, name);
/*     */   }
/*     */   
/*     */   public QName getName() {
/* 121 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getBaseValue()
/*     */   {
/* 128 */     return this.bean;
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 132 */     Object value = getNode();
/* 133 */     return (value == null) || (JXPathIntrospector.getBeanInfo(value.getClass()).isAtomic());
/*     */   }
/*     */   
/*     */   public boolean isCollection()
/*     */   {
/* 138 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 145 */     return 1;
/*     */   }
/*     */   
/*     */   public String asPath() {
/* 149 */     if (this.parent != null) {
/* 150 */       return super.asPath();
/*     */     }
/* 152 */     return "/";
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 156 */     return System.identityHashCode(this.bean) + this.name.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 160 */     if (object == this) {
/* 161 */       return true;
/*     */     }
/*     */     
/* 164 */     if (!(object instanceof DynamicPointer)) {
/* 165 */       return false;
/*     */     }
/*     */     
/* 168 */     DynamicPointer other = (DynamicPointer)object;
/* 169 */     return (this.bean == other.bean) && (this.name.equals(other.name));
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dynamic/DynamicPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */