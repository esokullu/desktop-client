/*     */ package org.apache.commons.jxpath.ri.model.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMNamespaceIterator
/*     */   implements NodeIterator
/*     */ {
/*     */   private NodePointer parent;
/*     */   private List attributes;
/*  82 */   private int position = 0;
/*     */   
/*     */   public DOMNamespaceIterator(NodePointer parent) {
/*  85 */     this.parent = parent;
/*  86 */     this.attributes = new ArrayList();
/*  87 */     collectNamespaces(this.attributes, (Node)parent.getNode());
/*     */   }
/*     */   
/*     */   private void collectNamespaces(List attributes, Node node) {
/*  91 */     Node parent = node.getParentNode();
/*  92 */     if (parent != null) {
/*  93 */       collectNamespaces(attributes, parent);
/*     */     }
/*  95 */     if (node.getNodeType() == 1) {
/*  96 */       NamedNodeMap map = node.getAttributes();
/*  97 */       int count = map.getLength();
/*  98 */       for (int i = 0; i < count; i++) {
/*  99 */         Attr attr = (Attr)map.item(i);
/* 100 */         String prefix = DOMNodePointer.getPrefix(attr);
/* 101 */         String name = DOMNodePointer.getLocalName(attr);
/* 102 */         if (((prefix != null) && (prefix.equals("xmlns"))) || ((prefix == null) && (name.equals("xmlns"))))
/*     */         {
/* 104 */           attributes.add(attr);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public NodePointer getNodePointer() {
/* 111 */     if (this.position == 0) {
/* 112 */       if (!setPosition(1)) {
/* 113 */         return null;
/*     */       }
/* 115 */       this.position = 0;
/*     */     }
/* 117 */     int index = this.position - 1;
/* 118 */     if (index < 0) {
/* 119 */       index = 0;
/*     */     }
/* 121 */     String prefix = "";
/* 122 */     Attr attr = (Attr)this.attributes.get(index);
/* 123 */     String name = attr.getPrefix();
/* 124 */     if ((name != null) && (name.equals("xmlns"))) {
/* 125 */       prefix = DOMNodePointer.getLocalName(attr);
/*     */     }
/* 127 */     return new NamespacePointer(this.parent, prefix, attr.getValue());
/*     */   }
/*     */   
/*     */   public int getPosition() {
/* 131 */     return this.position;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 135 */     this.position = position;
/* 136 */     return (position >= 1) && (position <= this.attributes.size());
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dom/DOMNamespaceIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */