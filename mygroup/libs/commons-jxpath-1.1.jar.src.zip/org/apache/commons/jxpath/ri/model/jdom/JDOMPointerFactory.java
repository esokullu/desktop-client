/*     */ package org.apache.commons.jxpath.ri.model.jdom;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointerFactory;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDOMPointerFactory
/*     */   implements NodePointerFactory
/*     */ {
/*     */   public static final int JDOM_POINTER_FACTORY_ORDER = 110;
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  83 */     return 110;
/*     */   }
/*     */   
/*     */ 
/*     */   public NodePointer createNodePointer(QName name, Object bean, Locale locale)
/*     */   {
/*  89 */     if ((bean instanceof Document)) {
/*  90 */       return new JDOMNodePointer(bean, locale);
/*     */     }
/*  92 */     if ((bean instanceof Element)) {
/*  93 */       return new JDOMNodePointer(bean, locale);
/*     */     }
/*  95 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public NodePointer createNodePointer(NodePointer parent, QName name, Object bean)
/*     */   {
/* 101 */     if ((bean instanceof Document)) {
/* 102 */       return new JDOMNodePointer(parent, bean);
/*     */     }
/* 104 */     if ((bean instanceof Element)) {
/* 105 */       return new JDOMNodePointer(parent, bean);
/*     */     }
/* 107 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/jdom/JDOMPointerFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */