/*     */ package org.apache.commons.jxpath.ri.model;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ import org.apache.commons.jxpath.ri.JXPathContextReferenceImpl;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
/*     */ import org.apache.commons.jxpath.ri.model.beans.NullPointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NodePointer
/*     */   implements Pointer
/*     */ {
/*     */   public static final int WHOLE_COLLECTION = Integer.MIN_VALUE;
/*  89 */   protected int index = Integer.MIN_VALUE;
/*     */   public static final String UNKNOWN_NAMESPACE = "<<unknown namespace>>";
/*  91 */   private boolean attribute = false;
/*     */   
/*     */ 
/*     */   private transient Object rootNode;
/*     */   
/*     */   protected NodePointer parent;
/*     */   
/*     */   protected Locale locale;
/*     */   
/*     */ 
/*     */   public static NodePointer newNodePointer(QName name, Object bean, Locale locale)
/*     */   {
/* 103 */     if (bean == null) {
/* 104 */       return new NullPointer(name, locale);
/*     */     }
/* 106 */     NodePointerFactory[] factories = JXPathContextReferenceImpl.getNodePointerFactories();
/*     */     
/* 108 */     for (int i = 0; i < factories.length; i++) {
/* 109 */       NodePointer pointer = factories[i].createNodePointer(name, bean, locale);
/*     */       
/* 111 */       if (pointer != null) {
/* 112 */         return pointer;
/*     */       }
/*     */     }
/* 115 */     throw new JXPathException("Could not allocate a NodePointer for object of " + bean.getClass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodePointer newChildNodePointer(NodePointer parent, QName name, Object bean)
/*     */   {
/* 129 */     NodePointerFactory[] factories = JXPathContextReferenceImpl.getNodePointerFactories();
/*     */     
/* 131 */     for (int i = 0; i < factories.length; i++) {
/* 132 */       NodePointer pointer = factories[i].createNodePointer(parent, name, bean);
/*     */       
/* 134 */       if (pointer != null) {
/* 135 */         return pointer;
/*     */       }
/*     */     }
/* 138 */     throw new JXPathException("Could not allocate a NodePointer for object of " + bean.getClass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected NodePointer(NodePointer parent)
/*     */   {
/* 147 */     this.parent = parent;
/*     */   }
/*     */   
/*     */   protected NodePointer(NodePointer parent, Locale locale) {
/* 151 */     this.parent = parent;
/* 152 */     this.locale = locale;
/*     */   }
/*     */   
/*     */   public NodePointer getParent() {
/* 156 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAttribute(boolean attribute)
/*     */   {
/* 163 */     this.attribute = attribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isAttribute()
/*     */   {
/* 170 */     return this.attribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isRoot()
/*     */   {
/* 177 */     return this.parent == null;
/*     */   }
/*     */   
/*     */ 
/*     */   public abstract boolean isLeaf();
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public boolean isNode()
/*     */   {
/* 189 */     return !isContainer();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isContainer()
/*     */   {
/* 197 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIndex()
/*     */   {
/* 208 */     return this.index;
/*     */   }
/*     */   
/*     */   public void setIndex(int index) {
/* 212 */     this.index = index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean isCollection();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int getLength();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValue()
/*     */   {
/* 234 */     NodePointer valuePointer = getValuePointer();
/* 235 */     if (valuePointer != this) {
/* 236 */       return valuePointer.getValue();
/*     */     }
/*     */     
/* 239 */     return getNode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer getValuePointer()
/*     */   {
/* 260 */     NodePointer ivp = getImmediateValuePointer();
/* 261 */     if (ivp != this) {
/* 262 */       return ivp.getValuePointer();
/*     */     }
/* 264 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer getImmediateValuePointer()
/*     */   {
/* 274 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActual()
/*     */   {
/* 291 */     if (this.index == Integer.MIN_VALUE) {
/* 292 */       return true;
/*     */     }
/*     */     
/* 295 */     return (this.index >= 0) && (this.index < getLength());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract QName getName();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Object getBaseValue();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Object getNodeValue()
/*     */   {
/* 318 */     return getNode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getNode()
/*     */   {
/* 327 */     return getValuePointer().getImmediateNode();
/*     */   }
/*     */   
/*     */   public Object getRootNode() {
/* 331 */     if (this.rootNode == null) {
/* 332 */       if (this.parent != null) {
/* 333 */         this.rootNode = this.parent.getRootNode();
/*     */       }
/*     */       else {
/* 336 */         this.rootNode = getImmediateNode();
/*     */       }
/*     */     }
/* 339 */     return this.rootNode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Object getImmediateNode();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setValue(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int compareChildNodePointers(NodePointer paramNodePointer1, NodePointer paramNodePointer2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean testNode(NodeTest test)
/*     */   {
/* 365 */     if (test == null) {
/* 366 */       return true;
/*     */     }
/* 368 */     if ((test instanceof NodeNameTest)) {
/* 369 */       if (isContainer()) {
/* 370 */         return false;
/*     */       }
/* 372 */       QName testName = ((NodeNameTest)test).getNodeName();
/* 373 */       QName nodeName = getName();
/* 374 */       String testPrefix = testName.getPrefix();
/* 375 */       String nodePrefix = nodeName.getPrefix();
/* 376 */       if (!equalStrings(testPrefix, nodePrefix)) {
/* 377 */         String testNS = getNamespaceURI(testPrefix);
/* 378 */         String nodeNS = getNamespaceURI(nodePrefix);
/* 379 */         if (!equalStrings(testNS, nodeNS)) {
/* 380 */           return false;
/*     */         }
/*     */       }
/* 383 */       String testLocalName = testName.getName();
/* 384 */       if (testLocalName.equals("*")) {
/* 385 */         return true;
/*     */       }
/* 387 */       return testLocalName.equals(nodeName.getName());
/*     */     }
/* 389 */     if (((test instanceof NodeTypeTest)) && 
/* 390 */       (((NodeTypeTest)test).getNodeType() == 1))
/*     */     {
/* 392 */       return isNode();
/*     */     }
/*     */     
/* 395 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean equalStrings(String s1, String s2) {
/* 399 */     if ((s1 == null) && (s2 != null)) {
/* 400 */       return false;
/*     */     }
/* 402 */     if ((s1 != null) && (!s1.equals(s2))) {
/* 403 */       return false;
/*     */     }
/* 405 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createPath(JXPathContext context, Object value)
/*     */   {
/* 413 */     setValue(value);
/* 414 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void remove() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createPath(JXPathContext context)
/*     */   {
/* 433 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index, Object value)
/*     */   {
/* 448 */     throw new JXPathException("Cannot create an object for path " + asPath() + "/" + name + "[" + (index + 1) + "]" + ", operation is not allowed for this type of node");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index)
/*     */   {
/* 470 */     throw new JXPathException("Cannot create an object for path " + asPath() + "/" + name + "[" + (index + 1) + "]" + ", operation is not allowed for this type of node");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createAttribute(JXPathContext context, QName name)
/*     */   {
/* 485 */     throw new JXPathException("Cannot create an attribute for path " + asPath() + "/@" + name + ", operation is not allowed for this type of node");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Locale getLocale()
/*     */   {
/* 497 */     if ((this.locale == null) && 
/* 498 */       (this.parent != null)) {
/* 499 */       this.locale = this.parent.getLocale();
/*     */     }
/*     */     
/* 502 */     return this.locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLanguage(String lang)
/*     */   {
/* 510 */     Locale loc = getLocale();
/* 511 */     String name = loc.toString().replace('_', '-');
/* 512 */     return name.toUpperCase().startsWith(lang.toUpperCase());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodeIterator childIterator(NodeTest test, boolean reverse, NodePointer startWith)
/*     */   {
/* 524 */     NodePointer valuePointer = getValuePointer();
/* 525 */     if ((valuePointer != null) && (valuePointer != this)) {
/* 526 */       return valuePointer.childIterator(test, reverse, startWith);
/*     */     }
/* 528 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodeIterator attributeIterator(QName qname)
/*     */   {
/* 537 */     NodePointer valuePointer = getValuePointer();
/* 538 */     if ((valuePointer != null) && (valuePointer != this)) {
/* 539 */       return valuePointer.attributeIterator(qname);
/*     */     }
/* 541 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodeIterator namespaceIterator()
/*     */   {
/* 550 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer namespacePointer(String namespace)
/*     */   {
/* 559 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getNamespaceURI(String prefix)
/*     */   {
/* 566 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getNamespaceURI()
/*     */   {
/* 573 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isDefaultNamespace(String prefix)
/*     */   {
/* 581 */     if (prefix == null) {
/* 582 */       return true;
/*     */     }
/*     */     
/* 585 */     String namespace = getNamespaceURI(prefix);
/* 586 */     if (namespace == null) {
/* 587 */       return false;
/*     */     }
/*     */     
/* 590 */     return namespace.equals(getDefaultNamespaceURI());
/*     */   }
/*     */   
/*     */   protected String getDefaultNamespaceURI() {
/* 594 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public QName getExpandedName()
/*     */   {
/* 602 */     return getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Pointer getPointerByID(JXPathContext context, String id)
/*     */   {
/* 609 */     return context.getPointerByID(id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pointer getPointerByKey(JXPathContext context, String key, String value)
/*     */   {
/* 620 */     return context.getPointerByKey(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String asPath()
/*     */   {
/* 629 */     if ((this.parent != null) && (this.parent.isContainer())) {
/* 630 */       return this.parent.asPath();
/*     */     }
/*     */     
/* 633 */     StringBuffer buffer = new StringBuffer();
/* 634 */     if (this.parent != null) {
/* 635 */       buffer.append(this.parent.asPath());
/*     */     }
/*     */     
/* 638 */     if ((buffer.length() == 0) || (buffer.charAt(buffer.length() - 1) != '/'))
/*     */     {
/* 640 */       buffer.append('/');
/*     */     }
/* 642 */     if (this.attribute) {
/* 643 */       buffer.append('@');
/*     */     }
/* 645 */     buffer.append(getName());
/*     */     
/* 647 */     if ((this.index != Integer.MIN_VALUE) && (isCollection())) {
/* 648 */       buffer.append('[').append(this.index + 1).append(']');
/*     */     }
/* 650 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 655 */       NodePointer ptr = (NodePointer)super.clone();
/* 656 */       if (this.parent != null) {
/* 657 */         ptr.parent = ((NodePointer)this.parent.clone());
/*     */       }
/* 659 */       return ptr;
/*     */     }
/*     */     catch (CloneNotSupportedException ex)
/*     */     {
/* 663 */       ex.printStackTrace();
/*     */     }
/* 665 */     return null;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 669 */     return asPath();
/*     */   }
/*     */   
/*     */   public int compareTo(Object object)
/*     */   {
/* 674 */     NodePointer pointer = (NodePointer)object;
/* 675 */     if (this.parent == pointer.parent) {
/* 676 */       if (this.parent == null) {
/* 677 */         return 0;
/*     */       }
/* 679 */       return this.parent.compareChildNodePointers(this, pointer);
/*     */     }
/*     */     
/*     */ 
/* 683 */     int depth1 = 0;
/* 684 */     NodePointer p1 = this;
/* 685 */     while (p1 != null) {
/* 686 */       depth1++;
/* 687 */       p1 = p1.parent;
/*     */     }
/* 689 */     int depth2 = 0;
/* 690 */     NodePointer p2 = pointer;
/* 691 */     while (p2 != null) {
/* 692 */       depth2++;
/* 693 */       p2 = p2.parent;
/*     */     }
/* 695 */     return compareNodePointers(this, depth1, pointer, depth2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int compareNodePointers(NodePointer p1, int depth1, NodePointer p2, int depth2)
/*     */   {
/* 704 */     if (depth1 < depth2) {
/* 705 */       int r = compareNodePointers(p1, depth1, p2.parent, depth2 - 1);
/* 706 */       if (r != 0) {
/* 707 */         return r;
/*     */       }
/* 709 */       return -1;
/*     */     }
/* 711 */     if (depth1 > depth2) {
/* 712 */       int r = compareNodePointers(p1.parent, depth1 - 1, p2, depth2);
/* 713 */       if (r != 0) {
/* 714 */         return r;
/*     */       }
/* 716 */       return 1;
/*     */     }
/* 718 */     if ((p1 == null) && (p2 == null)) {
/* 719 */       return 0;
/*     */     }
/*     */     
/* 722 */     if ((p1 != null) && (p1.equals(p2))) {
/* 723 */       return 0;
/*     */     }
/*     */     
/* 726 */     if (depth1 == 1) {
/* 727 */       throw new JXPathException("Cannot compare pointers that do not belong to the same tree: '" + p1 + "' and '" + p2 + "'");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 734 */     int r = compareNodePointers(p1.parent, depth1 - 1, p2.parent, depth2 - 1);
/*     */     
/* 736 */     if (r != 0) {
/* 737 */       return r;
/*     */     }
/*     */     
/* 740 */     return p1.parent.compareChildNodePointers(p1, p2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void printPointerChain()
/*     */   {
/* 747 */     printDeep(this, "");
/*     */   }
/*     */   
/*     */   private static void printDeep(NodePointer pointer, String indent) {
/* 751 */     if (indent.length() == 0) {
/* 752 */       System.err.println("POINTER: " + pointer + "(" + pointer.getClass().getName() + ")");
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/* 760 */       System.err.println(indent + " of " + pointer + "(" + pointer.getClass().getName() + ")");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 768 */     if (pointer.getParent() != null) {
/* 769 */       printDeep(pointer.getParent(), indent + "  ");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/NodePointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */