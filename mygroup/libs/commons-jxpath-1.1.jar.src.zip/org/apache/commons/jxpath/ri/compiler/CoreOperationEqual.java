/*    */ package org.apache.commons.jxpath.ri.compiler;
/*    */ 
/*    */ import org.apache.commons.jxpath.ri.EvalContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoreOperationEqual
/*    */   extends CoreOperationCompare
/*    */ {
/*    */   public CoreOperationEqual(Expression arg1, Expression arg2)
/*    */   {
/* 67 */     super(arg1, arg2);
/*    */   }
/*    */   
/*    */   public Object computeValue(EvalContext context) {
/* 71 */     return equal(context, this.args[0], this.args[1]) ? Boolean.TRUE : Boolean.FALSE;
/*    */   }
/*    */   
/*    */   protected int getPrecedence() {
/* 75 */     return 2;
/*    */   }
/*    */   
/*    */   protected boolean isSymmetric() {
/* 79 */     return true;
/*    */   }
/*    */   
/*    */   public String getSymbol() {
/* 83 */     return "=";
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/CoreOperationEqual.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */