/*     */ package org.apache.commons.jxpath.ri.model.dom;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointerFactory;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMPointerFactory
/*     */   implements NodePointerFactory
/*     */ {
/*     */   public static final int DOM_POINTER_FACTORY_ORDER = 100;
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  82 */     return 100;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createNodePointer(QName name, Object bean, Locale locale)
/*     */   {
/*  90 */     if ((bean instanceof Node)) {
/*  91 */       return new DOMNodePointer((Node)bean, locale);
/*     */     }
/*  93 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createNodePointer(NodePointer parent, QName name, Object bean)
/*     */   {
/* 101 */     if ((bean instanceof Node)) {
/* 102 */       return new DOMNodePointer(parent, (Node)bean);
/*     */     }
/* 104 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dom/DOMPointerFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */