/*     */ package org.apache.commons.jxpath.ri.axes;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.PropertyIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrecedingOrFollowingContext
/*     */   extends EvalContext
/*     */ {
/*     */   private NodeTest nodeTest;
/*  80 */   private boolean setStarted = false;
/*  81 */   private boolean started = false;
/*     */   
/*     */   private Stack stack;
/*     */   
/*     */   private Stack nameStack;
/*     */   
/*     */   private NodePointer currentNodePointer;
/*     */   private NodePointer currentRootLocation;
/*     */   private boolean reverse;
/*     */   
/*     */   public PrecedingOrFollowingContext(EvalContext parentContext, NodeTest nodeTest, boolean reverse)
/*     */   {
/*  93 */     super(parentContext);
/*  94 */     this.nodeTest = nodeTest;
/*  95 */     this.reverse = reverse;
/*     */   }
/*     */   
/*     */   public NodePointer getCurrentNodePointer() {
/*  99 */     return this.currentNodePointer;
/*     */   }
/*     */   
/*     */   public int getDocumentOrder() {
/* 103 */     return this.reverse ? -1 : 1;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 107 */     super.reset();
/* 108 */     this.stack = new Stack();
/* 109 */     this.setStarted = false;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 113 */     if (position < this.position) {
/* 114 */       reset();
/*     */     }
/*     */     
/* 117 */     while (this.position < position) {
/* 118 */       if (!nextNode()) {
/* 119 */         return false;
/*     */       }
/*     */     }
/* 122 */     return true;
/*     */   }
/*     */   
/*     */   public boolean nextNode() {
/* 126 */     if (!this.setStarted) {
/* 127 */       this.setStarted = true;
/* 128 */       this.currentRootLocation = this.parentContext.getCurrentNodePointer();
/* 129 */       NodePointer parent = getMaterialPointer(this.currentRootLocation.getParent());
/*     */       
/* 131 */       if (parent != null)
/*     */       {
/* 133 */         this.stack.push(parent.childIterator(null, this.reverse, this.currentRootLocation));
/*     */       }
/*     */     }
/* 159 */     for (;; 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 159 */         !this.stack.isEmpty()) {
/* 139 */       if (this.stack.isEmpty()) {
/* 140 */         this.currentRootLocation = getMaterialPointer(this.currentRootLocation.getParent());
/*     */         
/*     */ 
/* 143 */         if ((this.currentRootLocation == null) || (this.currentRootLocation.isRoot())) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/* 148 */         NodePointer parent = getMaterialPointer(this.currentRootLocation.getParent());
/*     */         
/* 150 */         if (parent != null)
/* 151 */           this.stack.push(parent.childIterator(null, this.reverse, this.currentRootLocation)); continue;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 160 */         if (!this.reverse) {
/* 161 */           NodeIterator it = (NodeIterator)this.stack.peek();
/* 162 */           if (it.setPosition(it.getPosition() + 1)) {
/* 163 */             this.currentNodePointer = it.getNodePointer();
/* 164 */             if (!this.currentNodePointer.isLeaf()) {
/* 165 */               this.stack.push(this.currentNodePointer.childIterator(null, this.reverse, null));
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/* 171 */             if (this.currentNodePointer.testNode(this.nodeTest)) {
/* 172 */               super.setPosition(getCurrentPosition() + 1);
/* 173 */               return true;
/*     */             }
/*     */             
/*     */           }
/*     */           else
/*     */           {
/* 179 */             this.stack.pop();
/*     */           }
/*     */         }
/*     */         else {
/* 183 */           NodeIterator it = (NodeIterator)this.stack.peek();
/* 184 */           if (it.setPosition(it.getPosition() + 1)) {
/* 185 */             this.currentNodePointer = it.getNodePointer();
/* 186 */             if (!this.currentNodePointer.isLeaf()) {
/* 187 */               this.stack.push(this.currentNodePointer.childIterator(null, this.reverse, null));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             }
/* 193 */             else if (this.currentNodePointer.testNode(this.nodeTest)) {
/* 194 */               super.setPosition(getCurrentPosition() + 1);
/* 195 */               return true;
/*     */             }
/*     */           }
/*     */           else {
/* 199 */             this.stack.pop();
/* 200 */             if (!this.stack.isEmpty()) {
/* 201 */               it = (PropertyIterator)this.stack.peek();
/* 202 */               this.currentNodePointer = it.getNodePointer();
/* 203 */               if (this.currentNodePointer.testNode(this.nodeTest)) {
/* 204 */                 super.setPosition(getCurrentPosition() + 1);
/* 205 */                 return true;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 212 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private NodePointer getMaterialPointer(NodePointer pointer)
/*     */   {
/* 220 */     while ((pointer != null) && (pointer.isContainer())) {
/* 221 */       pointer = pointer.getParent();
/*     */     }
/* 223 */     return pointer;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/axes/PrecedingOrFollowingContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */