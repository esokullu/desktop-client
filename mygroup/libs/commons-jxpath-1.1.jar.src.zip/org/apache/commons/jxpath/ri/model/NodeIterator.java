package org.apache.commons.jxpath.ri.model;

public abstract interface NodeIterator
{
  public abstract int getPosition();
  
  public abstract boolean setPosition(int paramInt);
  
  public abstract NodePointer getNodePointer();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/NodeIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */