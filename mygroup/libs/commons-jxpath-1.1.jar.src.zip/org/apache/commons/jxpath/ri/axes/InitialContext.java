/*     */ package org.apache.commons.jxpath.ri.axes;
/*     */ 
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InitialContext
/*     */   extends EvalContext
/*     */ {
/*  77 */   private boolean startedSet = false;
/*  78 */   private boolean started = false;
/*     */   private boolean collection;
/*     */   private NodePointer nodePointer;
/*     */   
/*     */   public InitialContext(EvalContext parentContext) {
/*  83 */     super(parentContext);
/*  84 */     this.nodePointer = parentContext.getCurrentNodePointer();
/*  85 */     if (this.nodePointer != null) {
/*  86 */       this.collection = (this.nodePointer.getIndex() == Integer.MIN_VALUE);
/*     */     }
/*     */   }
/*     */   
/*     */   public Pointer getSingleNodePointer()
/*     */   {
/*  92 */     return this.nodePointer;
/*     */   }
/*     */   
/*     */   public NodePointer getCurrentNodePointer() {
/*  96 */     return this.nodePointer;
/*     */   }
/*     */   
/*     */   public boolean nextNode() {
/* 100 */     return setPosition(this.position + 1);
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 104 */     this.position = position;
/* 105 */     if (this.collection) {
/* 106 */       if ((position >= 1) && (position <= this.nodePointer.getLength())) {
/* 107 */         this.nodePointer.setIndex(position - 1);
/* 108 */         return true;
/*     */       }
/* 110 */       return false;
/*     */     }
/*     */     
/* 113 */     return position == 1;
/*     */   }
/*     */   
/*     */   public boolean nextSet()
/*     */   {
/* 118 */     if (this.started) {
/* 119 */       return false;
/*     */     }
/* 121 */     this.started = true;
/* 122 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/axes/InitialContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */