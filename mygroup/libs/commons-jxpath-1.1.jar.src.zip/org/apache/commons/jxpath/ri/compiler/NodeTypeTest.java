/*    */ package org.apache.commons.jxpath.ri.compiler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NodeTypeTest
/*    */   extends NodeTest
/*    */ {
/*    */   private int nodeType;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NodeTypeTest(int nodeType)
/*    */   {
/* 74 */     this.nodeType = nodeType;
/*    */   }
/*    */   
/*    */   public int getNodeType() {
/* 78 */     return this.nodeType;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 82 */     return nodeTypeToString(this.nodeType) + "()";
/*    */   }
/*    */   
/*    */   public static String nodeTypeToString(int code) {
/* 86 */     switch (code) {
/*    */     case 1: 
/* 88 */       return "node";
/*    */     case 2: 
/* 90 */       return "text";
/*    */     case 3: 
/* 92 */       return "comment";
/*    */     case 4: 
/* 94 */       return "processing-instruction";
/*    */     }
/* 96 */     return "UNKNOWN";
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/NodeTypeTest.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */