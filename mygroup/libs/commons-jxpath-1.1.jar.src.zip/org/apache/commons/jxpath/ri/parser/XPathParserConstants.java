/*    */ package org.apache.commons.jxpath.ri.parser;
/*    */ 
/*    */ 
/*    */ public abstract interface XPathParserConstants
/*    */ {
/*    */   public static final int EOF = 0;
/*    */   
/*    */   public static final int S = 1;
/*    */   
/*    */   public static final int SLASH = 2;
/*    */   public static final int SLASHSLASH = 3;
/*    */   public static final int UNION = 4;
/*    */   public static final int PLUS = 5;
/*    */   public static final int MINUS = 6;
/*    */   public static final int EQ = 7;
/*    */   public static final int NEQ = 8;
/*    */   public static final int LT = 9;
/*    */   public static final int LTE = 10;
/*    */   public static final int GT = 11;
/*    */   public static final int GTE = 12;
/*    */   public static final int VARIABLE = 13;
/*    */   public static final int Literal = 14;
/*    */   public static final int Digit = 15;
/*    */   public static final int Number = 16;
/*    */   public static final int Letter = 17;
/*    */   public static final int BaseChar = 18;
/*    */   public static final int Ideographic = 19;
/*    */   public static final int CombiningChar = 20;
/*    */   public static final int UnicodeDigit = 21;
/*    */   public static final int Extender = 22;
/*    */   public static final int OR = 23;
/*    */   public static final int AND = 24;
/*    */   public static final int MOD = 25;
/*    */   public static final int DIV = 26;
/*    */   public static final int NODE = 27;
/*    */   public static final int TEXT = 28;
/*    */   public static final int COMMENT = 29;
/*    */   public static final int PI = 30;
/*    */   public static final int AXIS_SELF = 31;
/*    */   public static final int AXIS_CHILD = 32;
/*    */   public static final int AXIS_PARENT = 33;
/*    */   public static final int AXIS_ANCESTOR = 34;
/*    */   public static final int AXIS_ATTRIBUTE = 35;
/*    */   public static final int AXIS_NAMESPACE = 36;
/*    */   public static final int AXIS_PRECEDING = 37;
/*    */   public static final int AXIS_FOLLOWING = 38;
/*    */   public static final int AXIS_DESCENDANT = 39;
/*    */   public static final int AXIS_ANCESTOR_OR_SELF = 40;
/*    */   public static final int AXIS_FOLLOWING_SIBLING = 41;
/*    */   public static final int AXIS_PRECEDING_SIBLING = 42;
/*    */   public static final int AXIS_DESCENDANT_OR_SELF = 43;
/*    */   public static final int FUNCTION_LAST = 44;
/*    */   public static final int FUNCTION_POSITION = 45;
/*    */   public static final int FUNCTION_COUNT = 46;
/*    */   public static final int FUNCTION_ID = 47;
/*    */   public static final int FUNCTION_KEY = 48;
/*    */   public static final int FUNCTION_LOCAL_NAME = 49;
/*    */   public static final int FUNCTION_NAMESPACE_URI = 50;
/*    */   public static final int FUNCTION_NAME = 51;
/*    */   public static final int FUNCTION_STRING = 52;
/*    */   public static final int FUNCTION_CONCAT = 53;
/*    */   public static final int FUNCTION_STARTS_WITH = 54;
/*    */   public static final int FUNCTION_CONTAINS = 55;
/*    */   public static final int FUNCTION_SUBSTRING_BEFORE = 56;
/*    */   public static final int FUNCTION_SUBSTRING_AFTER = 57;
/*    */   public static final int FUNCTION_SUBSTRING = 58;
/*    */   public static final int FUNCTION_STRING_LENGTH = 59;
/*    */   public static final int FUNCTION_NORMALIZE_SPACE = 60;
/*    */   public static final int FUNCTION_TRANSLATE = 61;
/*    */   public static final int FUNCTION_BOOLEAN = 62;
/*    */   public static final int FUNCTION_NOT = 63;
/*    */   public static final int FUNCTION_TRUE = 64;
/*    */   public static final int FUNCTION_FALSE = 65;
/*    */   public static final int FUNCTION_NULL = 66;
/*    */   public static final int FUNCTION_LANG = 67;
/*    */   public static final int FUNCTION_NUMBER = 68;
/*    */   public static final int FUNCTION_SUM = 69;
/*    */   public static final int FUNCTION_FLOOR = 70;
/*    */   public static final int FUNCTION_CEILING = 71;
/*    */   public static final int FUNCTION_ROUND = 72;
/*    */   public static final int FUNCTION_FORMAT_NUMBER = 73;
/*    */   public static final int NCName = 74;
/*    */   public static final int DEFAULT = 0;
/* 84 */   public static final String[] tokenImage = { "<EOF>", "<S>", "\"/\"", "\"//\"", "\"|\"", "\"+\"", "\"-\"", "\"=\"", "\"!=\"", "\"<\"", "\"<=\"", "\">\"", "\">=\"", "\"$\"", "<Literal>", "<Digit>", "<Number>", "<Letter>", "<BaseChar>", "<Ideographic>", "<CombiningChar>", "<UnicodeDigit>", "<Extender>", "\"or\"", "\"and\"", "\"mod\"", "\"div\"", "\"node\"", "\"text\"", "\"comment\"", "\"processing-instruction\"", "\"self::\"", "\"child::\"", "\"parent::\"", "\"ancestor::\"", "\"attribute::\"", "\"namespace::\"", "\"preceding::\"", "\"following::\"", "\"descendant::\"", "\"ancestor-or-self::\"", "\"following-sibling::\"", "\"preceding-sibling::\"", "\"descendant-or-self::\"", "\"last\"", "\"position\"", "\"count\"", "\"id\"", "\"key\"", "\"local-name\"", "\"namespace-uri\"", "\"name\"", "\"string\"", "\"concat\"", "\"starts-with\"", "\"contains\"", "\"substring-before\"", "\"substring-after\"", "\"substring\"", "\"string-length\"", "\"normalize-space\"", "\"translate\"", "\"boolean\"", "\"not\"", "\"true\"", "\"false\"", "\"null\"", "\"lang\"", "\"number\"", "\"sum\"", "\"floor\"", "\"ceiling\"", "\"round\"", "\"format-number\"", "<NCName>", "\":\"", "\"(\"", "\")\"", "\".\"", "\"..\"", "\"[\"", "\"]\"", "\"@\"", "\",\"", "\"*\"" };
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/parser/XPathParserConstants.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */