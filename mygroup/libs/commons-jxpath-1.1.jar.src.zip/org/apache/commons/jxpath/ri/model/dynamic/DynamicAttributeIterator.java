/*    */ package org.apache.commons.jxpath.ri.model.dynamic;
/*    */ 
/*    */ import org.apache.commons.jxpath.ri.QName;
/*    */ import org.apache.commons.jxpath.ri.model.beans.BeanAttributeIterator;
/*    */ import org.apache.commons.jxpath.ri.model.beans.PropertyIterator;
/*    */ import org.apache.commons.jxpath.ri.model.beans.PropertyOwnerPointer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DynamicAttributeIterator
/*    */   extends BeanAttributeIterator
/*    */ {
/*    */   public DynamicAttributeIterator(PropertyOwnerPointer parent, QName name)
/*    */   {
/* 71 */     super(parent, name);
/*    */   }
/*    */   
/*    */   protected void prepareForIndividualProperty(String name) {
/* 75 */     ((DynamicPropertyPointer)getPropertyPointer()).setPropertyName(name);
/* 76 */     super.prepareForIndividualProperty(name);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dynamic/DynamicAttributeIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */