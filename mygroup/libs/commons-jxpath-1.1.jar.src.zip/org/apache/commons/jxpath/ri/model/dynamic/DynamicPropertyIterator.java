/*    */ package org.apache.commons.jxpath.ri.model.dynamic;
/*    */ 
/*    */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*    */ import org.apache.commons.jxpath.ri.model.beans.PropertyIterator;
/*    */ import org.apache.commons.jxpath.ri.model.beans.PropertyOwnerPointer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DynamicPropertyIterator
/*    */   extends PropertyIterator
/*    */ {
/*    */   public DynamicPropertyIterator(PropertyOwnerPointer pointer, String name, boolean reverse, NodePointer startWith)
/*    */   {
/* 76 */     super(pointer, name, reverse, startWith);
/*    */   }
/*    */   
/*    */   protected void prepareForIndividualProperty(String name) {
/* 80 */     ((DynamicPropertyPointer)getPropertyPointer()).setPropertyName(name);
/* 81 */     super.prepareForIndividualProperty(name);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dynamic/DynamicPropertyIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */