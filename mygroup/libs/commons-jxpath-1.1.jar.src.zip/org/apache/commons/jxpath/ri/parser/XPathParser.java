/*      */ package org.apache.commons.jxpath.ri.parser;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ 
/*      */ public class XPathParser implements XPathParserConstants {
/*      */   private org.apache.commons.jxpath.ri.Compiler compiler;
/*      */   public XPathParserTokenManager token_source;
/*      */   JavaCharStream jj_input_stream;
/*      */   public Token token;
/*      */   
/*   11 */   public void setCompiler(org.apache.commons.jxpath.ri.Compiler compiler) { this.compiler = compiler; }
/*      */   
/*      */   private String unescape(String string)
/*      */   {
/*   15 */     int index = string.indexOf("&apos;");
/*   16 */     while (index != -1) {
/*   17 */       string = string.substring(0, index) + "'" + string.substring(index + 6);
/*   18 */       index = string.indexOf("&apos;");
/*      */     }
/*   20 */     index = string.indexOf("&quot;");
/*   21 */     while (index != -1) {
/*   22 */       string = string.substring(0, index) + "\"" + string.substring(index + 6);
/*   23 */       index = string.indexOf("&quot;");
/*      */     }
/*   25 */     return string;
/*      */   }
/*      */   
/*      */   public final String NCName() throws ParseException
/*      */   {
/*   30 */     switch (this.jj_nt.kind) {
/*      */     case 23: 
/*      */     case 24: 
/*      */     case 25: 
/*      */     case 26: 
/*      */     case 74: 
/*   36 */       NCName_Without_CoreFunctions();
/*   37 */       break;
/*      */     case 27: 
/*   39 */       jj_consume_token(27);
/*   40 */       break;
/*      */     case 28: 
/*   42 */       jj_consume_token(28);
/*   43 */       break;
/*      */     case 29: 
/*   45 */       jj_consume_token(29);
/*   46 */       break;
/*      */     case 30: 
/*   48 */       jj_consume_token(30);
/*   49 */       break;
/*      */     case 44: 
/*   51 */       jj_consume_token(44);
/*   52 */       break;
/*      */     case 45: 
/*   54 */       jj_consume_token(45);
/*   55 */       break;
/*      */     case 46: 
/*   57 */       jj_consume_token(46);
/*   58 */       break;
/*      */     case 47: 
/*   60 */       jj_consume_token(47);
/*   61 */       break;
/*      */     case 49: 
/*   63 */       jj_consume_token(49);
/*   64 */       break;
/*      */     case 50: 
/*   66 */       jj_consume_token(50);
/*   67 */       break;
/*      */     case 51: 
/*   69 */       jj_consume_token(51);
/*   70 */       break;
/*      */     case 52: 
/*   72 */       jj_consume_token(52);
/*   73 */       break;
/*      */     case 53: 
/*   75 */       jj_consume_token(53);
/*   76 */       break;
/*      */     case 54: 
/*   78 */       jj_consume_token(54);
/*   79 */       break;
/*      */     case 55: 
/*   81 */       jj_consume_token(55);
/*   82 */       break;
/*      */     case 56: 
/*   84 */       jj_consume_token(56);
/*   85 */       break;
/*      */     case 57: 
/*   87 */       jj_consume_token(57);
/*   88 */       break;
/*      */     case 58: 
/*   90 */       jj_consume_token(58);
/*   91 */       break;
/*      */     case 59: 
/*   93 */       jj_consume_token(59);
/*   94 */       break;
/*      */     case 60: 
/*   96 */       jj_consume_token(60);
/*   97 */       break;
/*      */     case 61: 
/*   99 */       jj_consume_token(61);
/*  100 */       break;
/*      */     case 62: 
/*  102 */       jj_consume_token(62);
/*  103 */       break;
/*      */     case 63: 
/*  105 */       jj_consume_token(63);
/*  106 */       break;
/*      */     case 64: 
/*  108 */       jj_consume_token(64);
/*  109 */       break;
/*      */     case 65: 
/*  111 */       jj_consume_token(65);
/*  112 */       break;
/*      */     case 66: 
/*  114 */       jj_consume_token(66);
/*  115 */       break;
/*      */     case 67: 
/*  117 */       jj_consume_token(67);
/*  118 */       break;
/*      */     case 68: 
/*  120 */       jj_consume_token(68);
/*  121 */       break;
/*      */     case 69: 
/*  123 */       jj_consume_token(69);
/*  124 */       break;
/*      */     case 70: 
/*  126 */       jj_consume_token(70);
/*  127 */       break;
/*      */     case 71: 
/*  129 */       jj_consume_token(71);
/*  130 */       break;
/*      */     case 72: 
/*  132 */       jj_consume_token(72);
/*  133 */       break;
/*      */     case 48: 
/*  135 */       jj_consume_token(48);
/*  136 */       break;
/*      */     case 73: 
/*  138 */       jj_consume_token(73);
/*  139 */       break;
/*      */     case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39: case 40: case 41: case 42: case 43: default: 
/*  141 */       this.jj_la1[0] = this.jj_gen;
/*  142 */       jj_consume_token(-1);
/*  143 */       throw new ParseException();
/*      */     }
/*  145 */     return this.token.image;
/*      */   }
/*      */   
/*      */   public final String NCName_Without_CoreFunctions() throws ParseException
/*      */   {
/*  150 */     switch (this.jj_nt.kind) {
/*      */     case 74: 
/*  152 */       jj_consume_token(74);
/*  153 */       break;
/*      */     case 23: 
/*  155 */       jj_consume_token(23);
/*  156 */       break;
/*      */     case 24: 
/*  158 */       jj_consume_token(24);
/*  159 */       break;
/*      */     case 25: 
/*  161 */       jj_consume_token(25);
/*  162 */       break;
/*      */     case 26: 
/*  164 */       jj_consume_token(26);
/*  165 */       break;
/*      */     default: 
/*  167 */       this.jj_la1[1] = this.jj_gen;
/*  168 */       jj_consume_token(-1);
/*  169 */       throw new ParseException();
/*      */     }
/*  171 */     return this.token.image;
/*      */   }
/*      */   
/*      */   public final int CoreFunctionName() throws ParseException
/*      */   {
/*      */     int code;
/*  177 */     switch (this.jj_nt.kind) {
/*      */     case 44: 
/*  179 */       jj_consume_token(44);
/*  180 */       code = 1;
/*  181 */       break;
/*      */     case 45: 
/*  183 */       jj_consume_token(45);
/*  184 */       code = 2;
/*  185 */       break;
/*      */     case 46: 
/*  187 */       jj_consume_token(46);
/*  188 */       code = 3;
/*  189 */       break;
/*      */     case 47: 
/*  191 */       jj_consume_token(47);
/*  192 */       code = 4;
/*  193 */       break;
/*      */     case 49: 
/*  195 */       jj_consume_token(49);
/*  196 */       code = 5;
/*  197 */       break;
/*      */     case 50: 
/*  199 */       jj_consume_token(50);
/*  200 */       code = 6;
/*  201 */       break;
/*      */     case 51: 
/*  203 */       jj_consume_token(51);
/*  204 */       code = 7;
/*  205 */       break;
/*      */     case 52: 
/*  207 */       jj_consume_token(52);
/*  208 */       code = 8;
/*  209 */       break;
/*      */     case 53: 
/*  211 */       jj_consume_token(53);
/*  212 */       code = 9;
/*  213 */       break;
/*      */     case 54: 
/*  215 */       jj_consume_token(54);
/*  216 */       code = 10;
/*  217 */       break;
/*      */     case 55: 
/*  219 */       jj_consume_token(55);
/*  220 */       code = 11;
/*  221 */       break;
/*      */     case 56: 
/*  223 */       jj_consume_token(56);
/*  224 */       code = 12;
/*  225 */       break;
/*      */     case 57: 
/*  227 */       jj_consume_token(57);
/*  228 */       code = 13;
/*  229 */       break;
/*      */     case 58: 
/*  231 */       jj_consume_token(58);
/*  232 */       code = 14;
/*  233 */       break;
/*      */     case 59: 
/*  235 */       jj_consume_token(59);
/*  236 */       code = 15;
/*  237 */       break;
/*      */     case 60: 
/*  239 */       jj_consume_token(60);
/*  240 */       code = 16;
/*  241 */       break;
/*      */     case 61: 
/*  243 */       jj_consume_token(61);
/*  244 */       code = 17;
/*  245 */       break;
/*      */     case 62: 
/*  247 */       jj_consume_token(62);
/*  248 */       code = 18;
/*  249 */       break;
/*      */     case 63: 
/*  251 */       jj_consume_token(63);
/*  252 */       code = 19;
/*  253 */       break;
/*      */     case 64: 
/*  255 */       jj_consume_token(64);
/*  256 */       code = 20;
/*  257 */       break;
/*      */     case 65: 
/*  259 */       jj_consume_token(65);
/*  260 */       code = 21;
/*  261 */       break;
/*      */     case 66: 
/*  263 */       jj_consume_token(66);
/*  264 */       code = 28;
/*  265 */       break;
/*      */     case 67: 
/*  267 */       jj_consume_token(67);
/*  268 */       code = 22;
/*  269 */       break;
/*      */     case 68: 
/*  271 */       jj_consume_token(68);
/*  272 */       code = 23;
/*  273 */       break;
/*      */     case 69: 
/*  275 */       jj_consume_token(69);
/*  276 */       code = 24;
/*  277 */       break;
/*      */     case 70: 
/*  279 */       jj_consume_token(70);
/*  280 */       code = 25;
/*  281 */       break;
/*      */     case 71: 
/*  283 */       jj_consume_token(71);
/*  284 */       code = 26;
/*  285 */       break;
/*      */     case 72: 
/*  287 */       jj_consume_token(72);
/*  288 */       code = 27;
/*  289 */       break;
/*      */     case 48: 
/*  291 */       jj_consume_token(48);
/*  292 */       code = 29;
/*  293 */       break;
/*      */     case 73: 
/*  295 */       jj_consume_token(73);
/*  296 */       code = 30;
/*  297 */       break;
/*      */     default: 
/*  299 */       this.jj_la1[2] = this.jj_gen;
/*  300 */       jj_consume_token(-1);
/*  301 */       throw new ParseException();
/*      */     }
/*  303 */     return code;
/*      */   }
/*      */   
/*      */   public final Object QName() throws ParseException
/*      */   {
/*  308 */     String nc2 = null;
/*  309 */     String nc1 = NCName();
/*  310 */     switch (this.jj_nt.kind) {
/*      */     case 75: 
/*  312 */       jj_consume_token(75);
/*  313 */       nc2 = NCName();
/*  314 */       break;
/*      */     default: 
/*  316 */       this.jj_la1[3] = this.jj_gen;
/*      */     }
/*      */     
/*  319 */     if (nc2 == null) {
/*  320 */       return this.compiler.qname(null, nc1);
/*      */     }
/*      */     
/*  323 */     return this.compiler.qname(nc1, nc2);
/*      */   }
/*      */   
/*      */   public final Object QName_Without_CoreFunctions()
/*      */     throws ParseException
/*      */   {
/*  329 */     String nc2 = null;
/*  330 */     String nc1; if (jj_2_1(Integer.MAX_VALUE)) {
/*  331 */       nc1 = NCName();
/*  332 */       jj_consume_token(75);
/*  333 */       nc2 = NCName();
/*      */     } else {
/*  335 */       switch (this.jj_nt.kind) {
/*      */       case 23: 
/*      */       case 24: 
/*      */       case 25: 
/*      */       case 26: 
/*      */       case 74: 
/*  341 */         nc1 = NCName_Without_CoreFunctions();
/*  342 */         break;
/*      */       default: 
/*  344 */         this.jj_la1[4] = this.jj_gen;
/*  345 */         jj_consume_token(-1);
/*  346 */         throw new ParseException();
/*      */       }
/*      */     }
/*  349 */     if (nc2 == null) {
/*  350 */       return this.compiler.qname(null, nc1);
/*      */     }
/*      */     
/*  353 */     return this.compiler.qname(nc1, nc2);
/*      */   }
/*      */   
/*      */ 
/*      */   public final Object parseExpression()
/*      */     throws ParseException
/*      */   {
/*  360 */     Object ex = Expression();
/*  361 */     jj_consume_token(0);
/*  362 */     return ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Token jj_nt;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Token jj_scanpos;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Token jj_lastpos;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int jj_la;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Object LocationPath()
/*      */     throws ParseException
/*      */   {
/*  438 */     Object ex = null;
/*  439 */     switch (this.jj_nt.kind) {
/*      */     case 23: 
/*      */     case 24: 
/*      */     case 25: 
/*      */     case 26: 
/*      */     case 27: 
/*      */     case 28: 
/*      */     case 29: 
/*      */     case 30: 
/*      */     case 31: 
/*      */     case 32: 
/*      */     case 33: 
/*      */     case 34: 
/*      */     case 35: 
/*      */     case 36: 
/*      */     case 37: 
/*      */     case 38: 
/*      */     case 39: 
/*      */     case 40: 
/*      */     case 41: 
/*      */     case 42: 
/*      */     case 43: 
/*      */     case 44: 
/*      */     case 45: 
/*      */     case 46: 
/*      */     case 47: 
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/*      */     case 58: 
/*      */     case 59: 
/*      */     case 60: 
/*      */     case 61: 
/*      */     case 62: 
/*      */     case 63: 
/*      */     case 64: 
/*      */     case 65: 
/*      */     case 66: 
/*      */     case 67: 
/*      */     case 68: 
/*      */     case 69: 
/*      */     case 70: 
/*      */     case 71: 
/*      */     case 72: 
/*      */     case 73: 
/*      */     case 74: 
/*      */     case 78: 
/*      */     case 79: 
/*      */     case 82: 
/*      */     case 84: 
/*  496 */       ex = RelativeLocationPath();
/*  497 */       break;
/*      */     case 2: 
/*      */     case 3: 
/*  500 */       ex = AbsoluteLocationPath();
/*  501 */       break;
/*      */     case 4: case 5: case 6: case 7: case 8: case 9: case 10: case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19: case 20: case 21: case 22: case 75: case 76: case 77: case 80: case 81: case 83: default: 
/*  503 */       this.jj_la1[5] = this.jj_gen;
/*  504 */       jj_consume_token(-1);
/*  505 */       throw new ParseException();
/*      */     }
/*  507 */     return ex;
/*      */   }
/*      */   
/*      */ 
/*      */   public final Object AbsoluteLocationPath()
/*      */     throws ParseException
/*      */   {
/*  514 */     ArrayList steps = new ArrayList();
/*  515 */     if (jj_2_2(Integer.MAX_VALUE)) {
/*  516 */       LocationStep(steps);
/*      */       for (;;)
/*      */       {
/*  519 */         switch (this.jj_nt.kind)
/*      */         {
/*      */         case 2: 
/*      */         case 3: 
/*      */           break;
/*      */         default: 
/*  525 */           this.jj_la1[6] = this.jj_gen;
/*  526 */           break;
/*      */         }
/*  528 */         LocationStep(steps);
/*      */       }
/*      */     }
/*  531 */     switch (this.jj_nt.kind) {
/*      */     case 2: 
/*  533 */       jj_consume_token(2);
/*  534 */       break;
/*      */     default: 
/*  536 */       this.jj_la1[7] = this.jj_gen;
/*  537 */       jj_consume_token(-1);
/*  538 */       throw new ParseException();
/*      */     }
/*      */     
/*  541 */     return this.compiler.locationPath(true, steps.toArray());
/*      */   }
/*      */   
/*      */   public final Object RelativeLocationPath()
/*      */     throws ParseException
/*      */   {
/*  547 */     ArrayList steps = new ArrayList();
/*  548 */     NodeTest(steps);
/*      */     for (;;)
/*      */     {
/*  551 */       switch (this.jj_nt.kind)
/*      */       {
/*      */       case 2: 
/*      */       case 3: 
/*      */         break;
/*      */       default: 
/*  557 */         this.jj_la1[8] = this.jj_gen;
/*  558 */         break;
/*      */       }
/*  560 */       LocationStep(steps);
/*      */     }
/*  562 */     return this.compiler.locationPath(false, steps.toArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void LocationStep(ArrayList steps)
/*      */     throws ParseException
/*      */   {
/*  578 */     switch (this.jj_nt.kind) {
/*      */     case 2: 
/*  580 */       jj_consume_token(2);
/*  581 */       break;
/*      */     case 3: 
/*  583 */       jj_consume_token(3);
/*      */       
/*  585 */       Object t = this.compiler.nodeTypeTest(1);
/*  586 */       steps.add(this.compiler.step(13, t, null));
/*  587 */       break;
/*      */     default: 
/*  589 */       this.jj_la1[9] = this.jj_gen;
/*  590 */       jj_consume_token(-1);
/*  591 */       throw new ParseException();
/*      */     }
/*  593 */     NodeTest(steps);
/*      */   }
/*      */   
/*      */   public final void NodeTest(ArrayList steps)
/*      */     throws ParseException
/*      */   {
/*  599 */     int type = -1;
/*  600 */     String instruction = null;
/*  601 */     Object name = null;
/*      */     
/*      */ 
/*  604 */     ArrayList ps = new ArrayList();
/*  605 */     int axis; switch (this.jj_nt.kind) {
/*      */     case 23: 
/*      */     case 24: 
/*      */     case 25: 
/*      */     case 26: 
/*      */     case 27: 
/*      */     case 28: 
/*      */     case 29: 
/*      */     case 30: 
/*      */     case 31: 
/*      */     case 32: 
/*      */     case 33: 
/*      */     case 34: 
/*      */     case 35: 
/*      */     case 36: 
/*      */     case 37: 
/*      */     case 38: 
/*      */     case 39: 
/*      */     case 40: 
/*      */     case 41: 
/*      */     case 42: 
/*      */     case 43: 
/*      */     case 44: 
/*      */     case 45: 
/*      */     case 46: 
/*      */     case 47: 
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/*      */     case 58: 
/*      */     case 59: 
/*      */     case 60: 
/*      */     case 61: 
/*      */     case 62: 
/*      */     case 63: 
/*      */     case 64: 
/*      */     case 65: 
/*      */     case 66: 
/*      */     case 67: 
/*      */     case 68: 
/*      */     case 69: 
/*      */     case 70: 
/*      */     case 71: 
/*      */     case 72: 
/*      */     case 73: 
/*      */     case 74: 
/*      */     case 82: 
/*      */     case 84: 
/*  660 */       axis = AxisSpecifier();
/*  661 */       if (jj_2_3(Integer.MAX_VALUE)) {
/*  662 */         type = NodeType();
/*  663 */         jj_consume_token(76);
/*  664 */         jj_consume_token(77);
/*  665 */       } else if (jj_2_4(Integer.MAX_VALUE)) {
/*  666 */         jj_consume_token(30);
/*  667 */         jj_consume_token(76);
/*  668 */         jj_consume_token(14);
/*  669 */         instruction = unescape(this.token.image.substring(1, this.token.image.length() - 1));
/*  670 */         jj_consume_token(77);
/*      */       } else {
/*  672 */         switch (this.jj_nt.kind) {
/*      */         case 23: 
/*      */         case 24: 
/*      */         case 25: 
/*      */         case 26: 
/*      */         case 27: 
/*      */         case 28: 
/*      */         case 29: 
/*      */         case 30: 
/*      */         case 44: 
/*      */         case 45: 
/*      */         case 46: 
/*      */         case 47: 
/*      */         case 48: 
/*      */         case 49: 
/*      */         case 50: 
/*      */         case 51: 
/*      */         case 52: 
/*      */         case 53: 
/*      */         case 54: 
/*      */         case 55: 
/*      */         case 56: 
/*      */         case 57: 
/*      */         case 58: 
/*      */         case 59: 
/*      */         case 60: 
/*      */         case 61: 
/*      */         case 62: 
/*      */         case 63: 
/*      */         case 64: 
/*      */         case 65: 
/*      */         case 66: 
/*      */         case 67: 
/*      */         case 68: 
/*      */         case 69: 
/*      */         case 70: 
/*      */         case 71: 
/*      */         case 72: 
/*      */         case 73: 
/*      */         case 74: 
/*      */         case 84: 
/*  713 */           name = WildcardName();
/*  714 */           break;
/*      */         case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39: case 40: case 41: case 42: case 43: case 75: case 76: case 77: case 78: case 79: case 80: case 81: case 82: case 83: default: 
/*  716 */           this.jj_la1[10] = this.jj_gen;
/*  717 */           jj_consume_token(-1);
/*  718 */           throw new ParseException();
/*      */         }
/*      */       }
/*      */       break;
/*      */     case 78: 
/*  723 */       jj_consume_token(78);
/*  724 */       axis = 1;
/*  725 */       type = 1;
/*  726 */       break;
/*      */     case 79: 
/*  728 */       jj_consume_token(79);
/*  729 */       axis = 3;
/*  730 */       type = 1;
/*  731 */       break;
/*      */     case 75: case 76: case 77: case 80: case 81: case 83: default: 
/*  733 */       this.jj_la1[11] = this.jj_gen;
/*  734 */       jj_consume_token(-1);
/*  735 */       throw new ParseException();
/*      */     }
/*      */     for (;;)
/*      */     {
/*  739 */       switch (this.jj_nt.kind)
/*      */       {
/*      */       case 80: 
/*      */         break;
/*      */       default: 
/*  744 */         this.jj_la1[12] = this.jj_gen;
/*  745 */         break;
/*      */       }
/*  747 */       Object p = Predicate();
/*  748 */       ps.add(p); }
/*      */     Object s;
/*  750 */     if (name != null) {
/*  751 */       s = this.compiler.nodeNameTest(name);
/*      */     }
/*  753 */     else if (instruction != null) {
/*  754 */       s = this.compiler.processingInstructionTest(instruction);
/*      */     }
/*      */     else {
/*  757 */       s = this.compiler.nodeTypeTest(type);
/*      */     }
/*  759 */     steps.add(this.compiler.step(axis, s, ps.toArray()));
/*      */   }
/*      */   
/*      */   public final int AxisSpecifier() throws ParseException
/*      */   {
/*      */     int axis;
/*  765 */     switch (this.jj_nt.kind) {
/*      */     case 31: 
/*      */     case 32: 
/*      */     case 33: 
/*      */     case 34: 
/*      */     case 35: 
/*      */     case 36: 
/*      */     case 37: 
/*      */     case 38: 
/*      */     case 39: 
/*      */     case 40: 
/*      */     case 41: 
/*      */     case 42: 
/*      */     case 43: 
/*  779 */       axis = AxisName();
/*  780 */       break;
/*      */     default: 
/*  782 */       this.jj_la1[13] = this.jj_gen;
/*  783 */       axis = AbbreviatedAxisSpecifier();
/*      */     }
/*  785 */     return axis;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int AxisName()
/*      */     throws ParseException
/*      */   {
/*  798 */     int axis = 0;
/*  799 */     switch (this.jj_nt.kind) {
/*      */     case 31: 
/*  801 */       jj_consume_token(31);
/*  802 */       axis = 1;
/*  803 */       break;
/*      */     case 32: 
/*  805 */       jj_consume_token(32);
/*  806 */       axis = 2;
/*  807 */       break;
/*      */     case 33: 
/*  809 */       jj_consume_token(33);
/*  810 */       axis = 3;
/*  811 */       break;
/*      */     case 34: 
/*  813 */       jj_consume_token(34);
/*  814 */       axis = 4;
/*  815 */       break;
/*      */     case 35: 
/*  817 */       jj_consume_token(35);
/*  818 */       axis = 5;
/*  819 */       break;
/*      */     case 36: 
/*  821 */       jj_consume_token(36);
/*  822 */       axis = 6;
/*  823 */       break;
/*      */     case 37: 
/*  825 */       jj_consume_token(37);
/*  826 */       axis = 7;
/*  827 */       break;
/*      */     case 38: 
/*  829 */       jj_consume_token(38);
/*  830 */       axis = 8;
/*  831 */       break;
/*      */     case 39: 
/*  833 */       jj_consume_token(39);
/*  834 */       axis = 9;
/*  835 */       break;
/*      */     case 40: 
/*  837 */       jj_consume_token(40);
/*  838 */       axis = 10;
/*  839 */       break;
/*      */     case 41: 
/*  841 */       jj_consume_token(41);
/*  842 */       axis = 11;
/*  843 */       break;
/*      */     case 42: 
/*  845 */       jj_consume_token(42);
/*  846 */       axis = 12;
/*  847 */       break;
/*      */     case 43: 
/*  849 */       jj_consume_token(43);
/*  850 */       axis = 13;
/*  851 */       break;
/*      */     default: 
/*  853 */       this.jj_la1[14] = this.jj_gen;
/*  854 */       jj_consume_token(-1);
/*  855 */       throw new ParseException();
/*      */     }
/*  857 */     return axis;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Object Predicate()
/*      */     throws ParseException
/*      */   {
/*  873 */     jj_consume_token(80);
/*  874 */     Object ex = Expression();
/*  875 */     jj_consume_token(81);
/*  876 */     return ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final int AbbreviatedAxisSpecifier()
/*      */     throws ParseException
/*      */   {
/*  884 */     int axis = 2;
/*  885 */     switch (this.jj_nt.kind) {
/*      */     case 82: 
/*  887 */       jj_consume_token(82);
/*  888 */       axis = 5;
/*  889 */       break;
/*      */     default: 
/*  891 */       this.jj_la1[15] = this.jj_gen;
/*      */     }
/*      */     
/*  894 */     return axis;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Object Expression()
/*      */     throws ParseException
/*      */   {
/*  919 */     Object ex = OrExpr();
/*  920 */     return ex;
/*      */   }
/*      */   
/*      */   public final Object PrimaryExpr()
/*      */     throws ParseException
/*      */   {
/*  926 */     Object ex = null;
/*  927 */     switch (this.jj_nt.kind) {
/*      */     case 13: 
/*  929 */       ex = VariableReference();
/*  930 */       break;
/*      */     case 76: 
/*  932 */       jj_consume_token(76);
/*  933 */       ex = Expression();
/*  934 */       jj_consume_token(77);
/*  935 */       break;
/*      */     case 14: 
/*  937 */       jj_consume_token(14);
/*  938 */       ex = this.compiler.literal(unescape(this.token.image.substring(1, this.token.image.length() - 1)));
/*  939 */       break;
/*      */     case 16: 
/*  941 */       jj_consume_token(16);
/*  942 */       ex = this.compiler.number(this.token.image);
/*  943 */       break;
/*      */     default: 
/*  945 */       this.jj_la1[16] = this.jj_gen;
/*  946 */       if (jj_2_5(Integer.MAX_VALUE)) {
/*  947 */         ex = CoreFunctionCall();
/*      */       } else
/*  949 */         switch (this.jj_nt.kind) {
/*      */         case 23: 
/*      */         case 24: 
/*      */         case 25: 
/*      */         case 26: 
/*      */         case 27: 
/*      */         case 28: 
/*      */         case 29: 
/*      */         case 30: 
/*      */         case 44: 
/*      */         case 45: 
/*      */         case 46: 
/*      */         case 47: 
/*      */         case 48: 
/*      */         case 49: 
/*      */         case 50: 
/*      */         case 51: 
/*      */         case 52: 
/*      */         case 53: 
/*      */         case 54: 
/*      */         case 55: 
/*      */         case 56: 
/*      */         case 57: 
/*      */         case 58: 
/*      */         case 59: 
/*      */         case 60: 
/*      */         case 61: 
/*      */         case 62: 
/*      */         case 63: 
/*      */         case 64: 
/*      */         case 65: 
/*      */         case 66: 
/*      */         case 67: 
/*      */         case 68: 
/*      */         case 69: 
/*      */         case 70: 
/*      */         case 71: 
/*      */         case 72: 
/*      */         case 73: 
/*      */         case 74: 
/*  989 */           ex = FunctionCall();
/*  990 */           break;
/*      */         case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39: case 40: case 41: case 42: case 43: default: 
/*  992 */           this.jj_la1[17] = this.jj_gen;
/*  993 */           jj_consume_token(-1);
/*  994 */           throw new ParseException();
/*      */         }
/*      */       break;
/*      */     }
/*  998 */     return ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Object FunctionCall()
/*      */     throws ParseException
/*      */   {
/* 1010 */     Object name = FunctionName();
/* 1011 */     ArrayList args = ArgumentList();
/* 1012 */     if (args == null) {
/* 1013 */       return this.compiler.function(name, null);
/*      */     }
/*      */     
/* 1016 */     return this.compiler.function(name, args.toArray());
/*      */   }
/*      */   
/*      */   public final Object CoreFunctionCall()
/*      */     throws ParseException
/*      */   {
/* 1022 */     int code = 0;
/*      */     
/* 1024 */     code = CoreFunctionName();
/* 1025 */     ArrayList args = ArgumentList();
/* 1026 */     if (args == null) {
/* 1027 */       return this.compiler.function(code, null);
/*      */     }
/*      */     
/* 1030 */     return this.compiler.function(code, args.toArray());
/*      */   }
/*      */   
/*      */   public final ArrayList ArgumentList()
/*      */     throws ParseException
/*      */   {
/* 1036 */     ArrayList args = null;
/*      */     
/* 1038 */     jj_consume_token(76);
/* 1039 */     switch (this.jj_nt.kind) {
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 6: 
/*      */     case 13: 
/*      */     case 14: 
/*      */     case 16: 
/*      */     case 23: 
/*      */     case 24: 
/*      */     case 25: 
/*      */     case 26: 
/*      */     case 27: 
/*      */     case 28: 
/*      */     case 29: 
/*      */     case 30: 
/*      */     case 31: 
/*      */     case 32: 
/*      */     case 33: 
/*      */     case 34: 
/*      */     case 35: 
/*      */     case 36: 
/*      */     case 37: 
/*      */     case 38: 
/*      */     case 39: 
/*      */     case 40: 
/*      */     case 41: 
/*      */     case 42: 
/*      */     case 43: 
/*      */     case 44: 
/*      */     case 45: 
/*      */     case 46: 
/*      */     case 47: 
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/*      */     case 58: 
/*      */     case 59: 
/*      */     case 60: 
/*      */     case 61: 
/*      */     case 62: 
/*      */     case 63: 
/*      */     case 64: 
/*      */     case 65: 
/*      */     case 66: 
/*      */     case 67: 
/*      */     case 68: 
/*      */     case 69: 
/*      */     case 70: 
/*      */     case 71: 
/*      */     case 72: 
/*      */     case 73: 
/*      */     case 74: 
/*      */     case 76: 
/*      */     case 78: 
/*      */     case 79: 
/*      */     case 82: 
/*      */     case 84: 
/* 1103 */       Object arg = Argument();
/* 1104 */       args = new ArrayList();args.add(arg);
/*      */       for (;;)
/*      */       {
/* 1107 */         switch (this.jj_nt.kind)
/*      */         {
/*      */         case 83: 
/*      */           break;
/*      */         default: 
/* 1112 */           this.jj_la1[18] = this.jj_gen;
/* 1113 */           break;
/*      */         }
/* 1115 */         jj_consume_token(83);
/* 1116 */         arg = Argument();
/* 1117 */         args.add(arg);
/*      */       }
/*      */     }
/*      */     
/* 1121 */     this.jj_la1[19] = this.jj_gen;
/*      */     
/*      */ 
/* 1124 */     jj_consume_token(77);
/* 1125 */     return args;
/*      */   }
/*      */   
/*      */ 
/*      */   public final Object Argument()
/*      */     throws ParseException
/*      */   {
/* 1132 */     Object ex = Expression();
/* 1133 */     return ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Object UnionExpr()
/*      */     throws ParseException
/*      */   {
/* 1144 */     ArrayList list = null;
/* 1145 */     Object ex = PathExpr();
/*      */     for (;;)
/*      */     {
/* 1148 */       switch (this.jj_nt.kind)
/*      */       {
/*      */       case 4: 
/*      */         break;
/*      */       default: 
/* 1153 */         this.jj_la1[20] = this.jj_gen;
/* 1154 */         break;
/*      */       }
/* 1156 */       jj_consume_token(4);
/* 1157 */       Object r = PathExpr();
/* 1158 */       if (list == null) {
/* 1159 */         list = new ArrayList();
/* 1160 */         list.add(ex);
/*      */       }
/* 1162 */       list.add(r);
/*      */     }
/* 1164 */     if (list != null) {
/* 1165 */       ex = this.compiler.union(list.toArray());
/*      */     }
/* 1167 */     return ex;
/*      */   }
/*      */   
/*      */   public final Object PathExpr()
/*      */     throws ParseException
/*      */   {
/* 1173 */     Object ex = null;
/*      */     
/* 1175 */     if (jj_2_6(Integer.MAX_VALUE)) {
/* 1176 */       ex = FilterExpr();
/*      */     } else {
/* 1178 */       switch (this.jj_nt.kind) {
/*      */       case 2: 
/*      */       case 3: 
/*      */       case 23: 
/*      */       case 24: 
/*      */       case 25: 
/*      */       case 26: 
/*      */       case 27: 
/*      */       case 28: 
/*      */       case 29: 
/*      */       case 30: 
/*      */       case 31: 
/*      */       case 32: 
/*      */       case 33: 
/*      */       case 34: 
/*      */       case 35: 
/*      */       case 36: 
/*      */       case 37: 
/*      */       case 38: 
/*      */       case 39: 
/*      */       case 40: 
/*      */       case 41: 
/*      */       case 42: 
/*      */       case 43: 
/*      */       case 44: 
/*      */       case 45: 
/*      */       case 46: 
/*      */       case 47: 
/*      */       case 48: 
/*      */       case 49: 
/*      */       case 50: 
/*      */       case 51: 
/*      */       case 52: 
/*      */       case 53: 
/*      */       case 54: 
/*      */       case 55: 
/*      */       case 56: 
/*      */       case 57: 
/*      */       case 58: 
/*      */       case 59: 
/*      */       case 60: 
/*      */       case 61: 
/*      */       case 62: 
/*      */       case 63: 
/*      */       case 64: 
/*      */       case 65: 
/*      */       case 66: 
/*      */       case 67: 
/*      */       case 68: 
/*      */       case 69: 
/*      */       case 70: 
/*      */       case 71: 
/*      */       case 72: 
/*      */       case 73: 
/*      */       case 74: 
/*      */       case 78: 
/*      */       case 79: 
/*      */       case 82: 
/*      */       case 84: 
/* 1237 */         ex = LocationPath();
/* 1238 */         break;
/*      */       case 4: case 5: case 6: case 7: case 8: case 9: case 10: case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19: case 20: case 21: case 22: case 75: case 76: case 77: case 80: case 81: case 83: default: 
/* 1240 */         this.jj_la1[21] = this.jj_gen;
/* 1241 */         jj_consume_token(-1);
/* 1242 */         throw new ParseException();
/*      */       }
/*      */     }
/* 1245 */     return ex;
/*      */   }
/*      */   
/*      */ 
/*      */   public final Object FilterExpr()
/*      */     throws ParseException
/*      */   {
/* 1252 */     ArrayList ps = new ArrayList();
/* 1253 */     boolean path = false;
/* 1254 */     ArrayList steps = new ArrayList();
/* 1255 */     Object ex = PrimaryExpr();
/*      */     for (;;)
/*      */     {
/* 1258 */       switch (this.jj_nt.kind)
/*      */       {
/*      */       case 80: 
/*      */         break;
/*      */       default: 
/* 1263 */         this.jj_la1[22] = this.jj_gen;
/* 1264 */         break;
/*      */       }
/* 1266 */       Object p = Predicate();
/* 1267 */       path = true;
/* 1268 */       ps.add(p);
/*      */     }
/*      */     for (;;)
/*      */     {
/* 1272 */       switch (this.jj_nt.kind)
/*      */       {
/*      */       case 2: 
/*      */       case 3: 
/*      */         break;
/*      */       default: 
/* 1278 */         this.jj_la1[23] = this.jj_gen;
/* 1279 */         break;
/*      */       }
/* 1281 */       LocationStep(steps);
/* 1282 */       path = true;
/*      */     }
/* 1284 */     if (path) {
/* 1285 */       return this.compiler.expressionPath(ex, ps.toArray(), steps.toArray());
/*      */     }
/*      */     
/* 1288 */     return ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Object OrExpr()
/*      */     throws ParseException
/*      */   {
/* 1300 */     ArrayList list = null;
/* 1301 */     Object ex = AndExpr();
/*      */     for (;;)
/*      */     {
/* 1304 */       switch (this.jj_nt.kind)
/*      */       {
/*      */       case 23: 
/*      */         break;
/*      */       default: 
/* 1309 */         this.jj_la1[24] = this.jj_gen;
/* 1310 */         break;
/*      */       }
/* 1312 */       jj_consume_token(23);
/* 1313 */       Object r = AndExpr();
/* 1314 */       if (list == null) {
/* 1315 */         list = new ArrayList();
/* 1316 */         list.add(ex);
/*      */       }
/* 1318 */       list.add(r);
/*      */     }
/* 1320 */     if (list != null) {
/* 1321 */       ex = this.compiler.or(list.toArray());
/*      */     }
/* 1323 */     return ex;
/*      */   }
/*      */   
/*      */ 
/*      */   public final Object AndExpr()
/*      */     throws ParseException
/*      */   {
/* 1330 */     ArrayList list = null;
/* 1331 */     Object ex = EqualityExpr();
/*      */     for (;;)
/*      */     {
/* 1334 */       switch (this.jj_nt.kind)
/*      */       {
/*      */       case 24: 
/*      */         break;
/*      */       default: 
/* 1339 */         this.jj_la1[25] = this.jj_gen;
/* 1340 */         break;
/*      */       }
/* 1342 */       jj_consume_token(24);
/* 1343 */       Object r = EqualityExpr();
/* 1344 */       if (list == null) {
/* 1345 */         list = new ArrayList();
/* 1346 */         list.add(ex);
/*      */       }
/* 1348 */       list.add(r);
/*      */     }
/* 1350 */     if (list != null) {
/* 1351 */       ex = this.compiler.and(list.toArray());
/*      */     }
/* 1353 */     return ex;
/*      */   }
/*      */   
/*      */ 
/*      */   public final Object EqualityExpr()
/*      */     throws ParseException
/*      */   {
/* 1360 */     Object ex = RelationalExpr();
/*      */     for (;;)
/*      */     {
/* 1363 */       switch (this.jj_nt.kind)
/*      */       {
/*      */       case 7: 
/*      */       case 8: 
/*      */         break;
/*      */       default: 
/* 1369 */         this.jj_la1[26] = this.jj_gen;
/* 1370 */         break; }
/*      */       Object r;
/* 1372 */       switch (this.jj_nt.kind) {
/*      */       case 7: 
/* 1374 */         jj_consume_token(7);
/* 1375 */         r = RelationalExpr();
/* 1376 */         ex = this.compiler.equal(ex, r);
/* 1377 */         break;
/*      */       case 8: 
/* 1379 */         jj_consume_token(8);
/* 1380 */         r = RelationalExpr();
/* 1381 */         ex = this.compiler.notEqual(ex, r);
/*      */       }
/*      */     }
/* 1384 */     this.jj_la1[27] = this.jj_gen;
/* 1385 */     jj_consume_token(-1);
/* 1386 */     throw new ParseException();
/*      */     
/*      */ 
/* 1389 */     return ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final Object RelationalExpr()
/*      */     throws ParseException
/*      */   {
/* 1397 */     Object ex = AdditiveExpr();
/*      */     for (;;)
/*      */     {
/* 1400 */       switch (this.jj_nt.kind)
/*      */       {
/*      */       case 9: 
/*      */       case 10: 
/*      */       case 11: 
/*      */       case 12: 
/*      */         break;
/*      */       default: 
/* 1408 */         this.jj_la1[28] = this.jj_gen;
/* 1409 */         break; }
/*      */       Object r;
/* 1411 */       switch (this.jj_nt.kind) {
/*      */       case 9: 
/* 1413 */         jj_consume_token(9);
/* 1414 */         r = AdditiveExpr();
/* 1415 */         ex = this.compiler.lessThan(ex, r);
/* 1416 */         break;
/*      */       case 11: 
/* 1418 */         jj_consume_token(11);
/* 1419 */         r = AdditiveExpr();
/* 1420 */         ex = this.compiler.greaterThan(ex, r);
/* 1421 */         break;
/*      */       case 10: 
/* 1423 */         jj_consume_token(10);
/* 1424 */         r = AdditiveExpr();
/* 1425 */         ex = this.compiler.lessThanOrEqual(ex, r);
/* 1426 */         break;
/*      */       case 12: 
/* 1428 */         jj_consume_token(12);
/* 1429 */         r = AdditiveExpr();
/* 1430 */         ex = this.compiler.greaterThanOrEqual(ex, r);
/*      */       }
/*      */     }
/* 1433 */     this.jj_la1[29] = this.jj_gen;
/* 1434 */     jj_consume_token(-1);
/* 1435 */     throw new ParseException();
/*      */     
/*      */ 
/* 1438 */     return ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Object AdditiveExpr()
/*      */     throws ParseException
/*      */   {
/* 1449 */     ArrayList list = null;
/* 1450 */     Object ex = SubtractiveExpr();
/*      */     for (;;)
/*      */     {
/* 1453 */       switch (this.jj_nt.kind)
/*      */       {
/*      */       case 5: 
/*      */         break;
/*      */       default: 
/* 1458 */         this.jj_la1[30] = this.jj_gen;
/* 1459 */         break;
/*      */       }
/* 1461 */       jj_consume_token(5);
/* 1462 */       Object r = SubtractiveExpr();
/* 1463 */       if (list == null) {
/* 1464 */         list = new ArrayList();
/* 1465 */         list.add(ex);
/*      */       }
/* 1467 */       list.add(r);
/*      */     }
/* 1469 */     if (list != null) {
/* 1470 */       ex = this.compiler.sum(list.toArray());
/*      */     }
/* 1472 */     return ex;
/*      */   }
/*      */   
/*      */   public final Object SubtractiveExpr() throws ParseException
/*      */   {
/* 1477 */     Object r = null;
/* 1478 */     Object ex = MultiplicativeExpr();
/*      */     for (;;)
/*      */     {
/* 1481 */       switch (this.jj_nt.kind)
/*      */       {
/*      */       case 6: 
/*      */         break;
/*      */       default: 
/* 1486 */         this.jj_la1[31] = this.jj_gen;
/* 1487 */         break;
/*      */       }
/* 1489 */       jj_consume_token(6);
/* 1490 */       r = MultiplicativeExpr();
/* 1491 */       ex = this.compiler.minus(ex, r);
/*      */     }
/* 1493 */     return ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final Object MultiplicativeExpr()
/*      */     throws ParseException
/*      */   {
/* 1501 */     Object ex = UnaryExpr();
/*      */     for (;;)
/*      */     {
/* 1504 */       switch (this.jj_nt.kind)
/*      */       {
/*      */       case 25: 
/*      */       case 26: 
/*      */       case 84: 
/*      */         break;
/*      */       default: 
/* 1511 */         this.jj_la1[32] = this.jj_gen;
/* 1512 */         break; }
/*      */       Object r;
/* 1514 */       switch (this.jj_nt.kind) {
/*      */       case 84: 
/* 1516 */         jj_consume_token(84);
/* 1517 */         r = UnaryExpr();
/* 1518 */         ex = this.compiler.multiply(ex, r);
/* 1519 */         break;
/*      */       case 26: 
/* 1521 */         jj_consume_token(26);
/* 1522 */         r = UnaryExpr();
/* 1523 */         ex = this.compiler.divide(ex, r);
/* 1524 */         break;
/*      */       case 25: 
/* 1526 */         jj_consume_token(25);
/* 1527 */         r = UnaryExpr();
/* 1528 */         ex = this.compiler.mod(ex, r);
/*      */       }
/*      */     }
/* 1531 */     this.jj_la1[33] = this.jj_gen;
/* 1532 */     jj_consume_token(-1);
/* 1533 */     throw new ParseException();
/*      */     
/*      */ 
/* 1536 */     return ex;
/*      */   }
/*      */   
/*      */   public final Object UnaryExpr()
/*      */     throws ParseException
/*      */   {
/*      */     Object ex;
/* 1543 */     switch (this.jj_nt.kind) {
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 13: 
/*      */     case 14: 
/*      */     case 16: 
/*      */     case 23: 
/*      */     case 24: 
/*      */     case 25: 
/*      */     case 26: 
/*      */     case 27: 
/*      */     case 28: 
/*      */     case 29: 
/*      */     case 30: 
/*      */     case 31: 
/*      */     case 32: 
/*      */     case 33: 
/*      */     case 34: 
/*      */     case 35: 
/*      */     case 36: 
/*      */     case 37: 
/*      */     case 38: 
/*      */     case 39: 
/*      */     case 40: 
/*      */     case 41: 
/*      */     case 42: 
/*      */     case 43: 
/*      */     case 44: 
/*      */     case 45: 
/*      */     case 46: 
/*      */     case 47: 
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/*      */     case 58: 
/*      */     case 59: 
/*      */     case 60: 
/*      */     case 61: 
/*      */     case 62: 
/*      */     case 63: 
/*      */     case 64: 
/*      */     case 65: 
/*      */     case 66: 
/*      */     case 67: 
/*      */     case 68: 
/*      */     case 69: 
/*      */     case 70: 
/*      */     case 71: 
/*      */     case 72: 
/*      */     case 73: 
/*      */     case 74: 
/*      */     case 76: 
/*      */     case 78: 
/*      */     case 79: 
/*      */     case 82: 
/*      */     case 84: 
/* 1606 */       ex = UnionExpr();
/* 1607 */       break;
/*      */     case 6: 
/* 1609 */       jj_consume_token(6);
/* 1610 */       ex = UnaryExpr();
/* 1611 */       ex = this.compiler.minus(ex);
/* 1612 */       break;
/*      */     case 4: case 5: case 7: case 8: case 9: case 10: case 11: case 12: case 15: case 17: case 18: case 19: case 20: case 21: case 22: case 75: case 77: case 80: case 81: case 83: default: 
/* 1614 */       this.jj_la1[34] = this.jj_gen;
/* 1615 */       jj_consume_token(-1);
/* 1616 */       throw new ParseException();
/*      */     }
/* 1618 */     return ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Object FunctionName()
/*      */     throws ParseException
/*      */   {
/* 1658 */     Object qname = QName_Without_CoreFunctions();
/* 1659 */     return qname;
/*      */   }
/*      */   
/*      */ 
/*      */   public final Object VariableReference()
/*      */     throws ParseException
/*      */   {
/* 1666 */     jj_consume_token(13);
/* 1667 */     Object ex = QName();
/* 1668 */     return this.compiler.variableReference(ex);
/*      */   }
/*      */   
/*      */ 
/*      */   public final Object WildcardName()
/*      */     throws ParseException
/*      */   {
/* 1675 */     String nc2 = null;
/* 1676 */     switch (this.jj_nt.kind) {
/*      */     case 84: 
/* 1678 */       jj_consume_token(84);
/* 1679 */       break;
/*      */     case 23: 
/*      */     case 24: 
/*      */     case 25: 
/*      */     case 26: 
/*      */     case 27: 
/*      */     case 28: 
/*      */     case 29: 
/*      */     case 30: 
/*      */     case 44: 
/*      */     case 45: 
/*      */     case 46: 
/*      */     case 47: 
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/*      */     case 58: 
/*      */     case 59: 
/*      */     case 60: 
/*      */     case 61: 
/*      */     case 62: 
/*      */     case 63: 
/*      */     case 64: 
/*      */     case 65: 
/*      */     case 66: 
/*      */     case 67: 
/*      */     case 68: 
/*      */     case 69: 
/*      */     case 70: 
/*      */     case 71: 
/*      */     case 72: 
/*      */     case 73: 
/*      */     case 74: 
/* 1719 */       NCName();
/* 1720 */       break;
/*      */     case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39: case 40: case 41: case 42: case 43: case 75: case 76: case 77: case 78: case 79: case 80: case 81: case 82: case 83: default: 
/* 1722 */       this.jj_la1[35] = this.jj_gen;
/* 1723 */       jj_consume_token(-1);
/* 1724 */       throw new ParseException();
/*      */     }
/* 1726 */     String nc1 = this.token.image;
/* 1727 */     switch (this.jj_nt.kind) {
/*      */     case 75: 
/* 1729 */       jj_consume_token(75);
/* 1730 */       switch (this.jj_nt.kind) {
/*      */       case 84: 
/* 1732 */         jj_consume_token(84);
/* 1733 */         break;
/*      */       case 23: 
/*      */       case 24: 
/*      */       case 25: 
/*      */       case 26: 
/*      */       case 27: 
/*      */       case 28: 
/*      */       case 29: 
/*      */       case 30: 
/*      */       case 44: 
/*      */       case 45: 
/*      */       case 46: 
/*      */       case 47: 
/*      */       case 48: 
/*      */       case 49: 
/*      */       case 50: 
/*      */       case 51: 
/*      */       case 52: 
/*      */       case 53: 
/*      */       case 54: 
/*      */       case 55: 
/*      */       case 56: 
/*      */       case 57: 
/*      */       case 58: 
/*      */       case 59: 
/*      */       case 60: 
/*      */       case 61: 
/*      */       case 62: 
/*      */       case 63: 
/*      */       case 64: 
/*      */       case 65: 
/*      */       case 66: 
/*      */       case 67: 
/*      */       case 68: 
/*      */       case 69: 
/*      */       case 70: 
/*      */       case 71: 
/*      */       case 72: 
/*      */       case 73: 
/*      */       case 74: 
/* 1773 */         NCName();
/* 1774 */         break;
/*      */       case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39: case 40: case 41: case 42: case 43: case 75: case 76: case 77: case 78: case 79: case 80: case 81: case 82: case 83: default: 
/* 1776 */         this.jj_la1[36] = this.jj_gen;
/* 1777 */         jj_consume_token(-1);
/* 1778 */         throw new ParseException();
/*      */       }
/* 1780 */       nc2 = this.token.image;
/* 1781 */       break;
/*      */     default: 
/* 1783 */       this.jj_la1[37] = this.jj_gen;
/*      */     }
/*      */     Object qn;
/* 1786 */     if (nc2 != null) {
/* 1787 */       qn = this.compiler.qname(nc1, nc2);
/*      */     }
/*      */     else {
/* 1790 */       qn = this.compiler.qname(null, nc1);
/*      */     }
/* 1792 */     return qn;
/*      */   }
/*      */   
/*      */   public final int NodeType()
/*      */     throws ParseException
/*      */   {
/*      */     int type;
/* 1799 */     switch (this.jj_nt.kind) {
/*      */     case 28: 
/* 1801 */       jj_consume_token(28);
/* 1802 */       type = 2;
/* 1803 */       break;
/*      */     case 27: 
/* 1805 */       jj_consume_token(27);
/* 1806 */       type = 1;
/* 1807 */       break;
/*      */     case 29: 
/* 1809 */       jj_consume_token(29);
/* 1810 */       type = 3;
/* 1811 */       break;
/*      */     case 30: 
/* 1813 */       jj_consume_token(30);
/* 1814 */       type = 4;
/* 1815 */       break;
/*      */     default: 
/* 1817 */       this.jj_la1[38] = this.jj_gen;
/* 1818 */       jj_consume_token(-1);
/* 1819 */       throw new ParseException();
/*      */     }
/* 1821 */     return type;
/*      */   }
/*      */   
/*      */   private final boolean jj_2_1(int xla)
/*      */   {
/* 1826 */     this.jj_la = xla;this.jj_lastpos = (this.jj_scanpos = this.token);
/* 1827 */     boolean retval = !jj_3_1();
/* 1828 */     jj_save(0, xla);
/* 1829 */     return retval;
/*      */   }
/*      */   
/*      */   private final boolean jj_2_2(int xla) {
/* 1833 */     this.jj_la = xla;this.jj_lastpos = (this.jj_scanpos = this.token);
/* 1834 */     boolean retval = !jj_3_2();
/* 1835 */     jj_save(1, xla);
/* 1836 */     return retval;
/*      */   }
/*      */   
/*      */   private final boolean jj_2_3(int xla) {
/* 1840 */     this.jj_la = xla;this.jj_lastpos = (this.jj_scanpos = this.token);
/* 1841 */     boolean retval = !jj_3_3();
/* 1842 */     jj_save(2, xla);
/* 1843 */     return retval;
/*      */   }
/*      */   
/*      */   private final boolean jj_2_4(int xla) {
/* 1847 */     this.jj_la = xla;this.jj_lastpos = (this.jj_scanpos = this.token);
/* 1848 */     boolean retval = !jj_3_4();
/* 1849 */     jj_save(3, xla);
/* 1850 */     return retval;
/*      */   }
/*      */   
/*      */   private final boolean jj_2_5(int xla) {
/* 1854 */     this.jj_la = xla;this.jj_lastpos = (this.jj_scanpos = this.token);
/* 1855 */     boolean retval = !jj_3_5();
/* 1856 */     jj_save(4, xla);
/* 1857 */     return retval;
/*      */   }
/*      */   
/*      */   private final boolean jj_2_6(int xla) {
/* 1861 */     this.jj_la = xla;this.jj_lastpos = (this.jj_scanpos = this.token);
/* 1862 */     boolean retval = !jj_3_6();
/* 1863 */     jj_save(5, xla);
/* 1864 */     return retval;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_64() {
/* 1868 */     if (jj_scan_token(46)) return true;
/* 1869 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 1870 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_104() {
/* 1874 */     if (jj_3R_118()) return true;
/* 1875 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 1876 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_63() {
/* 1880 */     if (jj_scan_token(45)) return true;
/* 1881 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 1882 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_62() {
/* 1886 */     if (jj_scan_token(44)) return true;
/* 1887 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 1888 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_18()
/*      */   {
/* 1893 */     Token xsp = this.jj_scanpos;
/* 1894 */     if (jj_3R_62()) {
/* 1895 */       this.jj_scanpos = xsp;
/* 1896 */       if (jj_3R_63()) {
/* 1897 */         this.jj_scanpos = xsp;
/* 1898 */         if (jj_3R_64()) {
/* 1899 */           this.jj_scanpos = xsp;
/* 1900 */           if (jj_3R_65()) {
/* 1901 */             this.jj_scanpos = xsp;
/* 1902 */             if (jj_3R_66()) {
/* 1903 */               this.jj_scanpos = xsp;
/* 1904 */               if (jj_3R_67()) {
/* 1905 */                 this.jj_scanpos = xsp;
/* 1906 */                 if (jj_3R_68()) {
/* 1907 */                   this.jj_scanpos = xsp;
/* 1908 */                   if (jj_3R_69()) {
/* 1909 */                     this.jj_scanpos = xsp;
/* 1910 */                     if (jj_3R_70()) {
/* 1911 */                       this.jj_scanpos = xsp;
/* 1912 */                       if (jj_3R_71()) {
/* 1913 */                         this.jj_scanpos = xsp;
/* 1914 */                         if (jj_3R_72()) {
/* 1915 */                           this.jj_scanpos = xsp;
/* 1916 */                           if (jj_3R_73()) {
/* 1917 */                             this.jj_scanpos = xsp;
/* 1918 */                             if (jj_3R_74()) {
/* 1919 */                               this.jj_scanpos = xsp;
/* 1920 */                               if (jj_3R_75()) {
/* 1921 */                                 this.jj_scanpos = xsp;
/* 1922 */                                 if (jj_3R_76()) {
/* 1923 */                                   this.jj_scanpos = xsp;
/* 1924 */                                   if (jj_3R_77()) {
/* 1925 */                                     this.jj_scanpos = xsp;
/* 1926 */                                     if (jj_3R_78()) {
/* 1927 */                                       this.jj_scanpos = xsp;
/* 1928 */                                       if (jj_3R_79()) {
/* 1929 */                                         this.jj_scanpos = xsp;
/* 1930 */                                         if (jj_3R_80()) {
/* 1931 */                                           this.jj_scanpos = xsp;
/* 1932 */                                           if (jj_3R_81()) {
/* 1933 */                                             this.jj_scanpos = xsp;
/* 1934 */                                             if (jj_3R_82()) {
/* 1935 */                                               this.jj_scanpos = xsp;
/* 1936 */                                               if (jj_3R_83()) {
/* 1937 */                                                 this.jj_scanpos = xsp;
/* 1938 */                                                 if (jj_3R_84()) {
/* 1939 */                                                   this.jj_scanpos = xsp;
/* 1940 */                                                   if (jj_3R_85()) {
/* 1941 */                                                     this.jj_scanpos = xsp;
/* 1942 */                                                     if (jj_3R_86()) {
/* 1943 */                                                       this.jj_scanpos = xsp;
/* 1944 */                                                       if (jj_3R_87()) {
/* 1945 */                                                         this.jj_scanpos = xsp;
/* 1946 */                                                         if (jj_3R_88()) {
/* 1947 */                                                           this.jj_scanpos = xsp;
/* 1948 */                                                           if (jj_3R_89()) {
/* 1949 */                                                             this.jj_scanpos = xsp;
/* 1950 */                                                             if (jj_3R_90()) {
/* 1951 */                                                               this.jj_scanpos = xsp;
/* 1952 */                                                               if (jj_3R_91()) return true;
/* 1953 */                                                               if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 1954 */                                                             } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1955 */                                                             } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1956 */                                                           } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1957 */                                                         } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1958 */                                                       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1959 */                                                     } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1960 */                                                   } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1961 */                                                 } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1962 */                                               } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1963 */                                             } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1964 */                                           } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1965 */                                         } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1966 */                                       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1967 */                                     } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1968 */                                   } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1969 */                                 } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1970 */                               } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1971 */                             } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1972 */                           } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1973 */                         } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1974 */                       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1975 */                     } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1976 */                   } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1977 */                 } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1978 */               } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1979 */             } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1980 */           } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1981 */         } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 1982 */       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 1983 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_111() {
/* 1987 */     if (jj_scan_token(26)) return true;
/* 1988 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 1989 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_110() {
/* 1993 */     if (jj_scan_token(25)) return true;
/* 1994 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 1995 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_109() {
/* 1999 */     if (jj_scan_token(24)) return true;
/* 2000 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2001 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_108() {
/* 2005 */     if (jj_scan_token(23)) return true;
/* 2006 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2007 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_107() {
/* 2011 */     if (jj_scan_token(74)) return true;
/* 2012 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2013 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_173() {
/* 2017 */     if (jj_scan_token(6)) return true;
/* 2018 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2019 */     if (jj_3R_170()) return true;
/* 2020 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2021 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_98()
/*      */   {
/* 2026 */     Token xsp = this.jj_scanpos;
/* 2027 */     if (jj_3R_107()) {
/* 2028 */       this.jj_scanpos = xsp;
/* 2029 */       if (jj_3R_108()) {
/* 2030 */         this.jj_scanpos = xsp;
/* 2031 */         if (jj_3R_109()) {
/* 2032 */           this.jj_scanpos = xsp;
/* 2033 */           if (jj_3R_110()) {
/* 2034 */             this.jj_scanpos = xsp;
/* 2035 */             if (jj_3R_111()) return true;
/* 2036 */             if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2037 */           } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2038 */           } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2039 */         } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2040 */       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 2041 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_171()
/*      */   {
/* 2046 */     Token xsp = this.jj_scanpos;
/* 2047 */     if (jj_3R_174()) {
/* 2048 */       this.jj_scanpos = xsp;
/* 2049 */       if (jj_3R_175()) {
/* 2050 */         this.jj_scanpos = xsp;
/* 2051 */         if (jj_3R_176()) return true;
/* 2052 */         if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2053 */       } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2054 */       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 2055 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_172() {
/* 2059 */     if (jj_3R_177()) return true;
/* 2060 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2061 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_153() {
/* 2065 */     if (jj_scan_token(82)) return true;
/* 2066 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2067 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_130()
/*      */   {
/* 2072 */     Token xsp = this.jj_scanpos;
/* 2073 */     if (jj_3R_153()) { this.jj_scanpos = xsp;
/* 2074 */     } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2075 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_54() {
/* 2079 */     if (jj_scan_token(73)) return true;
/* 2080 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2081 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_170()
/*      */   {
/* 2086 */     Token xsp = this.jj_scanpos;
/* 2087 */     if (jj_3R_172()) {
/* 2088 */       this.jj_scanpos = xsp;
/* 2089 */       if (jj_3R_173()) return true;
/* 2090 */       if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2091 */     } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 2092 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_53() {
/* 2096 */     if (jj_scan_token(48)) return true;
/* 2097 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2098 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_52() {
/* 2102 */     if (jj_scan_token(72)) return true;
/* 2103 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2104 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_51() {
/* 2108 */     if (jj_scan_token(71)) return true;
/* 2109 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2110 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_50() {
/* 2114 */     if (jj_scan_token(70)) return true;
/* 2115 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2116 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_49() {
/* 2120 */     if (jj_scan_token(69)) return true;
/* 2121 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2122 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_48() {
/* 2126 */     if (jj_scan_token(68)) return true;
/* 2127 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2128 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_176() {
/* 2132 */     if (jj_scan_token(25)) return true;
/* 2133 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2134 */     if (jj_3R_170()) return true;
/* 2135 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2136 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_47() {
/* 2140 */     if (jj_scan_token(67)) return true;
/* 2141 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2142 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_175() {
/* 2146 */     if (jj_scan_token(26)) return true;
/* 2147 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2148 */     if (jj_3R_170()) return true;
/* 2149 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2150 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_46() {
/* 2154 */     if (jj_scan_token(66)) return true;
/* 2155 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2156 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_174() {
/* 2160 */     if (jj_scan_token(84)) return true;
/* 2161 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2162 */     if (jj_3R_170()) return true;
/* 2163 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2164 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_45() {
/* 2168 */     if (jj_scan_token(65)) return true;
/* 2169 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2170 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_44() {
/* 2174 */     if (jj_scan_token(64)) return true;
/* 2175 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2176 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_43() {
/* 2180 */     if (jj_scan_token(63)) return true;
/* 2181 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2182 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_42() {
/* 2186 */     if (jj_scan_token(62)) return true;
/* 2187 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2188 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_41() {
/* 2192 */     if (jj_scan_token(61)) return true;
/* 2193 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2194 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_116() {
/* 2198 */     if (jj_scan_token(80)) return true;
/* 2199 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2200 */     if (jj_3R_104()) return true;
/* 2201 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2202 */     if (jj_scan_token(81)) return true;
/* 2203 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2204 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_40() {
/* 2208 */     if (jj_scan_token(60)) return true;
/* 2209 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2210 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_39() {
/* 2214 */     if (jj_scan_token(59)) return true;
/* 2215 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2216 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_38() {
/* 2220 */     if (jj_scan_token(58)) return true;
/* 2221 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2222 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_37() {
/* 2226 */     if (jj_scan_token(57)) return true;
/* 2227 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2228 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_36() {
/* 2232 */     if (jj_scan_token(56)) return true;
/* 2233 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2234 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_168() {
/* 2238 */     if (jj_3R_170()) return true;
/* 2239 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/*      */     do
/*      */     {
/* 2242 */       Token xsp = this.jj_scanpos;
/* 2243 */       if (jj_3R_171()) { this.jj_scanpos = xsp; break;
/* 2244 */       } } while ((this.jj_la != 0) || (this.jj_scanpos != this.jj_lastpos)); return false;
/*      */     
/* 2246 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_35() {
/* 2250 */     if (jj_scan_token(55)) return true;
/* 2251 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2252 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_34() {
/* 2256 */     if (jj_scan_token(54)) return true;
/* 2257 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2258 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_33() {
/* 2262 */     if (jj_scan_token(53)) return true;
/* 2263 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2264 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_32() {
/* 2268 */     if (jj_scan_token(52)) return true;
/* 2269 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2270 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_31() {
/* 2274 */     if (jj_scan_token(51)) return true;
/* 2275 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2276 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_30() {
/* 2280 */     if (jj_scan_token(50)) return true;
/* 2281 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2282 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_29() {
/* 2286 */     if (jj_scan_token(49)) return true;
/* 2287 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2288 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_169() {
/* 2292 */     if (jj_scan_token(6)) return true;
/* 2293 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2294 */     if (jj_3R_168()) return true;
/* 2295 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2296 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_28() {
/* 2300 */     if (jj_scan_token(47)) return true;
/* 2301 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2302 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_27() {
/* 2306 */     if (jj_scan_token(46)) return true;
/* 2307 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2308 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_152() {
/* 2312 */     if (jj_scan_token(43)) return true;
/* 2313 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2314 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_26() {
/* 2318 */     if (jj_scan_token(45)) return true;
/* 2319 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2320 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_25() {
/* 2324 */     if (jj_scan_token(44)) return true;
/* 2325 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2326 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_151() {
/* 2330 */     if (jj_scan_token(42)) return true;
/* 2331 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2332 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_24() {
/* 2336 */     if (jj_scan_token(30)) return true;
/* 2337 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2338 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_150() {
/* 2342 */     if (jj_scan_token(41)) return true;
/* 2343 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2344 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_23() {
/* 2348 */     if (jj_scan_token(29)) return true;
/* 2349 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2350 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_149() {
/* 2354 */     if (jj_scan_token(40)) return true;
/* 2355 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2356 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_163() {
/* 2360 */     if (jj_scan_token(5)) return true;
/* 2361 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2362 */     if (jj_3R_162()) return true;
/* 2363 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2364 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_22() {
/* 2368 */     if (jj_scan_token(28)) return true;
/* 2369 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2370 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_148() {
/* 2374 */     if (jj_scan_token(39)) return true;
/* 2375 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2376 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_21() {
/* 2380 */     if (jj_scan_token(27)) return true;
/* 2381 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2382 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_147() {
/* 2386 */     if (jj_scan_token(38)) return true;
/* 2387 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2388 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_20() {
/* 2392 */     if (jj_3R_98()) return true;
/* 2393 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2394 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_146() {
/* 2398 */     if (jj_scan_token(37)) return true;
/* 2399 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2400 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_145() {
/* 2404 */     if (jj_scan_token(36)) return true;
/* 2405 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2406 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_162() {
/* 2410 */     if (jj_3R_168()) return true;
/* 2411 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/*      */     do
/*      */     {
/* 2414 */       Token xsp = this.jj_scanpos;
/* 2415 */       if (jj_3R_169()) { this.jj_scanpos = xsp; break;
/* 2416 */       } } while ((this.jj_la != 0) || (this.jj_scanpos != this.jj_lastpos)); return false;
/*      */     
/* 2418 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_144() {
/* 2422 */     if (jj_scan_token(35)) return true;
/* 2423 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2424 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_143() {
/* 2428 */     if (jj_scan_token(34)) return true;
/* 2429 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2430 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_142() {
/* 2434 */     if (jj_scan_token(33)) return true;
/* 2435 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2436 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_15()
/*      */   {
/* 2441 */     Token xsp = this.jj_scanpos;
/* 2442 */     if (jj_3R_20()) {
/* 2443 */       this.jj_scanpos = xsp;
/* 2444 */       if (jj_3R_21()) {
/* 2445 */         this.jj_scanpos = xsp;
/* 2446 */         if (jj_3R_22()) {
/* 2447 */           this.jj_scanpos = xsp;
/* 2448 */           if (jj_3R_23()) {
/* 2449 */             this.jj_scanpos = xsp;
/* 2450 */             if (jj_3R_24()) {
/* 2451 */               this.jj_scanpos = xsp;
/* 2452 */               if (jj_3R_25()) {
/* 2453 */                 this.jj_scanpos = xsp;
/* 2454 */                 if (jj_3R_26()) {
/* 2455 */                   this.jj_scanpos = xsp;
/* 2456 */                   if (jj_3R_27()) {
/* 2457 */                     this.jj_scanpos = xsp;
/* 2458 */                     if (jj_3R_28()) {
/* 2459 */                       this.jj_scanpos = xsp;
/* 2460 */                       if (jj_3R_29()) {
/* 2461 */                         this.jj_scanpos = xsp;
/* 2462 */                         if (jj_3R_30()) {
/* 2463 */                           this.jj_scanpos = xsp;
/* 2464 */                           if (jj_3R_31()) {
/* 2465 */                             this.jj_scanpos = xsp;
/* 2466 */                             if (jj_3R_32()) {
/* 2467 */                               this.jj_scanpos = xsp;
/* 2468 */                               if (jj_3R_33()) {
/* 2469 */                                 this.jj_scanpos = xsp;
/* 2470 */                                 if (jj_3R_34()) {
/* 2471 */                                   this.jj_scanpos = xsp;
/* 2472 */                                   if (jj_3R_35()) {
/* 2473 */                                     this.jj_scanpos = xsp;
/* 2474 */                                     if (jj_3R_36()) {
/* 2475 */                                       this.jj_scanpos = xsp;
/* 2476 */                                       if (jj_3R_37()) {
/* 2477 */                                         this.jj_scanpos = xsp;
/* 2478 */                                         if (jj_3R_38()) {
/* 2479 */                                           this.jj_scanpos = xsp;
/* 2480 */                                           if (jj_3R_39()) {
/* 2481 */                                             this.jj_scanpos = xsp;
/* 2482 */                                             if (jj_3R_40()) {
/* 2483 */                                               this.jj_scanpos = xsp;
/* 2484 */                                               if (jj_3R_41()) {
/* 2485 */                                                 this.jj_scanpos = xsp;
/* 2486 */                                                 if (jj_3R_42()) {
/* 2487 */                                                   this.jj_scanpos = xsp;
/* 2488 */                                                   if (jj_3R_43()) {
/* 2489 */                                                     this.jj_scanpos = xsp;
/* 2490 */                                                     if (jj_3R_44()) {
/* 2491 */                                                       this.jj_scanpos = xsp;
/* 2492 */                                                       if (jj_3R_45()) {
/* 2493 */                                                         this.jj_scanpos = xsp;
/* 2494 */                                                         if (jj_3R_46()) {
/* 2495 */                                                           this.jj_scanpos = xsp;
/* 2496 */                                                           if (jj_3R_47()) {
/* 2497 */                                                             this.jj_scanpos = xsp;
/* 2498 */                                                             if (jj_3R_48()) {
/* 2499 */                                                               this.jj_scanpos = xsp;
/* 2500 */                                                               if (jj_3R_49()) {
/* 2501 */                                                                 this.jj_scanpos = xsp;
/* 2502 */                                                                 if (jj_3R_50()) {
/* 2503 */                                                                   this.jj_scanpos = xsp;
/* 2504 */                                                                   if (jj_3R_51()) {
/* 2505 */                                                                     this.jj_scanpos = xsp;
/* 2506 */                                                                     if (jj_3R_52()) {
/* 2507 */                                                                       this.jj_scanpos = xsp;
/* 2508 */                                                                       if (jj_3R_53()) {
/* 2509 */                                                                         this.jj_scanpos = xsp;
/* 2510 */                                                                         if (jj_3R_54()) return true;
/* 2511 */                                                                         if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2512 */                                                                       } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2513 */                                                                       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2514 */                                                                     } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2515 */                                                                   } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2516 */                                                                 } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2517 */                                                               } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2518 */                                                             } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2519 */                                                           } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2520 */                                                         } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2521 */                                                       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2522 */                                                     } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2523 */                                                   } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2524 */                                                 } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2525 */                                               } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2526 */                                             } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2527 */                                           } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2528 */                                         } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2529 */                                       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2530 */                                     } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2531 */                                   } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2532 */                                 } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2533 */                               } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2534 */                             } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2535 */                           } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2536 */                         } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2537 */                       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2538 */                     } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2539 */                   } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2540 */                 } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2541 */               } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2542 */             } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2543 */           } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2544 */         } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2545 */       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 2546 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_141() {
/* 2550 */     if (jj_scan_token(32)) return true;
/* 2551 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2552 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_140() {
/* 2556 */     if (jj_scan_token(31)) return true;
/* 2557 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2558 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_129()
/*      */   {
/* 2563 */     Token xsp = this.jj_scanpos;
/* 2564 */     if (jj_3R_140()) {
/* 2565 */       this.jj_scanpos = xsp;
/* 2566 */       if (jj_3R_141()) {
/* 2567 */         this.jj_scanpos = xsp;
/* 2568 */         if (jj_3R_142()) {
/* 2569 */           this.jj_scanpos = xsp;
/* 2570 */           if (jj_3R_143()) {
/* 2571 */             this.jj_scanpos = xsp;
/* 2572 */             if (jj_3R_144()) {
/* 2573 */               this.jj_scanpos = xsp;
/* 2574 */               if (jj_3R_145()) {
/* 2575 */                 this.jj_scanpos = xsp;
/* 2576 */                 if (jj_3R_146()) {
/* 2577 */                   this.jj_scanpos = xsp;
/* 2578 */                   if (jj_3R_147()) {
/* 2579 */                     this.jj_scanpos = xsp;
/* 2580 */                     if (jj_3R_148()) {
/* 2581 */                       this.jj_scanpos = xsp;
/* 2582 */                       if (jj_3R_149()) {
/* 2583 */                         this.jj_scanpos = xsp;
/* 2584 */                         if (jj_3R_150()) {
/* 2585 */                           this.jj_scanpos = xsp;
/* 2586 */                           if (jj_3R_151()) {
/* 2587 */                             this.jj_scanpos = xsp;
/* 2588 */                             if (jj_3R_152()) return true;
/* 2589 */                             if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2590 */                           } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2591 */                           } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2592 */                         } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2593 */                       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2594 */                     } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2595 */                   } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2596 */                 } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2597 */               } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2598 */             } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2599 */           } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2600 */         } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2601 */       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 2602 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_159()
/*      */   {
/* 2607 */     Token xsp = this.jj_scanpos;
/* 2608 */     if (jj_3R_164()) {
/* 2609 */       this.jj_scanpos = xsp;
/* 2610 */       if (jj_3R_165()) {
/* 2611 */         this.jj_scanpos = xsp;
/* 2612 */         if (jj_3R_166()) {
/* 2613 */           this.jj_scanpos = xsp;
/* 2614 */           if (jj_3R_167()) return true;
/* 2615 */           if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2616 */         } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2617 */         } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2618 */       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 2619 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_158() {
/* 2623 */     if (jj_3R_162()) return true;
/* 2624 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/*      */     do
/*      */     {
/* 2627 */       Token xsp = this.jj_scanpos;
/* 2628 */       if (jj_3R_163()) { this.jj_scanpos = xsp; break;
/* 2629 */       } } while ((this.jj_la != 0) || (this.jj_scanpos != this.jj_lastpos)); return false;
/*      */     
/* 2631 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_122() {
/* 2635 */     if (jj_3R_130()) return true;
/* 2636 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2637 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_121() {
/* 2641 */     if (jj_3R_129()) return true;
/* 2642 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2643 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_167() {
/* 2647 */     if (jj_scan_token(12)) return true;
/* 2648 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2649 */     if (jj_3R_158()) return true;
/* 2650 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2651 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_112()
/*      */   {
/* 2656 */     Token xsp = this.jj_scanpos;
/* 2657 */     if (jj_3R_121()) {
/* 2658 */       this.jj_scanpos = xsp;
/* 2659 */       if (jj_3R_122()) return true;
/* 2660 */       if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2661 */     } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 2662 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_166() {
/* 2666 */     if (jj_scan_token(10)) return true;
/* 2667 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2668 */     if (jj_3R_158()) return true;
/* 2669 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2670 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_165() {
/* 2674 */     if (jj_scan_token(11)) return true;
/* 2675 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2676 */     if (jj_3R_158()) return true;
/* 2677 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2678 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_157()
/*      */   {
/* 2683 */     Token xsp = this.jj_scanpos;
/* 2684 */     if (jj_3R_160()) {
/* 2685 */       this.jj_scanpos = xsp;
/* 2686 */       if (jj_3R_161()) return true;
/* 2687 */       if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2688 */     } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 2689 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_164() {
/* 2693 */     if (jj_scan_token(9)) return true;
/* 2694 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2695 */     if (jj_3R_158()) return true;
/* 2696 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2697 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_156() {
/* 2701 */     if (jj_3R_158()) return true;
/* 2702 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/*      */     do
/*      */     {
/* 2705 */       Token xsp = this.jj_scanpos;
/* 2706 */       if (jj_3R_159()) { this.jj_scanpos = xsp; break;
/* 2707 */       } } while ((this.jj_la != 0) || (this.jj_scanpos != this.jj_lastpos)); return false;
/*      */     
/* 2709 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_161() {
/* 2713 */     if (jj_scan_token(8)) return true;
/* 2714 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2715 */     if (jj_3R_156()) return true;
/* 2716 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2717 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_160() {
/* 2721 */     if (jj_scan_token(7)) return true;
/* 2722 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2723 */     if (jj_3R_156()) return true;
/* 2724 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2725 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_102() {
/* 2729 */     if (jj_3R_116()) return true;
/* 2730 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2731 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3_4() {
/* 2735 */     if (jj_scan_token(30)) return true;
/* 2736 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2737 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3_3() {
/* 2741 */     if (jj_3R_17()) return true;
/* 2742 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2743 */     if (jj_scan_token(76)) return true;
/* 2744 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2745 */     if (jj_scan_token(77)) return true;
/* 2746 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2747 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_101() {
/* 2751 */     if (jj_scan_token(79)) return true;
/* 2752 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2753 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_100() {
/* 2757 */     if (jj_scan_token(78)) return true;
/* 2758 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2759 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_115() {
/* 2763 */     if (jj_3R_123()) return true;
/* 2764 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2765 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_134() {
/* 2769 */     if (jj_3R_156()) return true;
/* 2770 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/*      */     do
/*      */     {
/* 2773 */       Token xsp = this.jj_scanpos;
/* 2774 */       if (jj_3R_157()) { this.jj_scanpos = xsp; break;
/* 2775 */       } } while ((this.jj_la != 0) || (this.jj_scanpos != this.jj_lastpos)); return false;
/*      */     
/* 2777 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_114() {
/* 2781 */     if (jj_scan_token(30)) return true;
/* 2782 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2783 */     if (jj_scan_token(76)) return true;
/* 2784 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2785 */     if (jj_scan_token(14)) return true;
/* 2786 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2787 */     if (jj_scan_token(77)) return true;
/* 2788 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2789 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_113() {
/* 2793 */     if (jj_3R_17()) return true;
/* 2794 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2795 */     if (jj_scan_token(76)) return true;
/* 2796 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2797 */     if (jj_scan_token(77)) return true;
/* 2798 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2799 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_99() {
/* 2803 */     if (jj_3R_112()) return true;
/* 2804 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/*      */     }
/* 2806 */     Token xsp = this.jj_scanpos;
/* 2807 */     if (jj_3R_113()) {
/* 2808 */       this.jj_scanpos = xsp;
/* 2809 */       if (jj_3R_114()) {
/* 2810 */         this.jj_scanpos = xsp;
/* 2811 */         if (jj_3R_115()) return true;
/* 2812 */         if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2813 */       } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2814 */       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 2815 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_135() {
/* 2819 */     if (jj_scan_token(24)) return true;
/* 2820 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2821 */     if (jj_3R_134()) return true;
/* 2822 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2823 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_57()
/*      */   {
/* 2828 */     Token xsp = this.jj_scanpos;
/* 2829 */     if (jj_3R_99()) {
/* 2830 */       this.jj_scanpos = xsp;
/* 2831 */       if (jj_3R_100()) {
/* 2832 */         this.jj_scanpos = xsp;
/* 2833 */         if (jj_3R_101()) return true;
/* 2834 */         if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2835 */       } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 2836 */       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/*      */     }
/* 2838 */     do { xsp = this.jj_scanpos;
/* 2839 */       if (jj_3R_102()) { this.jj_scanpos = xsp; break;
/* 2840 */       } } while ((this.jj_la != 0) || (this.jj_scanpos != this.jj_lastpos)); return false;
/*      */     
/* 2842 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_125() {
/* 2846 */     if (jj_3R_134()) return true;
/* 2847 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/*      */     do
/*      */     {
/* 2850 */       Token xsp = this.jj_scanpos;
/* 2851 */       if (jj_3R_135()) { this.jj_scanpos = xsp; break;
/* 2852 */       } } while ((this.jj_la != 0) || (this.jj_scanpos != this.jj_lastpos)); return false;
/*      */     
/* 2854 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_193() {
/* 2858 */     if (jj_3R_16()) return true;
/* 2859 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2860 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_56() {
/* 2864 */     if (jj_scan_token(3)) return true;
/* 2865 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2866 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_55() {
/* 2870 */     if (jj_scan_token(2)) return true;
/* 2871 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2872 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_126() {
/* 2876 */     if (jj_scan_token(23)) return true;
/* 2877 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2878 */     if (jj_3R_125()) return true;
/* 2879 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2880 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_16()
/*      */   {
/* 2885 */     Token xsp = this.jj_scanpos;
/* 2886 */     if (jj_3R_55()) {
/* 2887 */       this.jj_scanpos = xsp;
/* 2888 */       if (jj_3R_56()) return true;
/* 2889 */       if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2890 */     } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 2891 */     if (jj_3R_57()) return true;
/* 2892 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2893 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_190() {
/* 2897 */     if (jj_3R_16()) return true;
/* 2898 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2899 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_118() {
/* 2903 */     if (jj_3R_125()) return true;
/* 2904 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/*      */     do
/*      */     {
/* 2907 */       Token xsp = this.jj_scanpos;
/* 2908 */       if (jj_3R_126()) { this.jj_scanpos = xsp; break;
/* 2909 */       } } while ((this.jj_la != 0) || (this.jj_scanpos != this.jj_lastpos)); return false;
/*      */     
/* 2911 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_188() {
/* 2915 */     if (jj_3R_57()) return true;
/* 2916 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/*      */     do
/*      */     {
/* 2919 */       Token xsp = this.jj_scanpos;
/* 2920 */       if (jj_3R_190()) { this.jj_scanpos = xsp; break;
/* 2921 */       } } while ((this.jj_la != 0) || (this.jj_scanpos != this.jj_lastpos)); return false;
/*      */     
/* 2923 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3_2() {
/* 2927 */     if (jj_3R_16()) return true;
/* 2928 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2929 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_185() {
/* 2933 */     if (jj_3R_16()) return true;
/* 2934 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2935 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_192() {
/* 2939 */     if (jj_scan_token(2)) return true;
/* 2940 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2941 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_191() {
/* 2945 */     if (jj_3R_16()) return true;
/* 2946 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/*      */     do
/*      */     {
/* 2949 */       Token xsp = this.jj_scanpos;
/* 2950 */       if (jj_3R_193()) { this.jj_scanpos = xsp; break;
/* 2951 */       } } while ((this.jj_la != 0) || (this.jj_scanpos != this.jj_lastpos)); return false;
/*      */     
/* 2953 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_184() {
/* 2957 */     if (jj_3R_116()) return true;
/* 2958 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2959 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_189()
/*      */   {
/* 2964 */     Token xsp = this.jj_scanpos;
/* 2965 */     if (jj_3R_191()) {
/* 2966 */       this.jj_scanpos = xsp;
/* 2967 */       if (jj_3R_192()) return true;
/* 2968 */       if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2969 */     } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 2970 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_182() {
/* 2974 */     if (jj_3R_19()) return true;
/* 2975 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/*      */     Token xsp;
/*      */     do {
/* 2978 */       xsp = this.jj_scanpos;
/* 2979 */       if (jj_3R_184()) { this.jj_scanpos = xsp; break;
/* 2980 */       } } while ((this.jj_la != 0) || (this.jj_scanpos != this.jj_lastpos)); return false;
/*      */     do
/*      */     {
/* 2983 */       xsp = this.jj_scanpos;
/* 2984 */       if (jj_3R_185()) { this.jj_scanpos = xsp; break;
/* 2985 */       } } while ((this.jj_la != 0) || (this.jj_scanpos != this.jj_lastpos)); return false;
/*      */     
/* 2987 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3_6() {
/* 2991 */     if (jj_3R_19()) return true;
/* 2992 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2993 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_187() {
/* 2997 */     if (jj_3R_189()) return true;
/* 2998 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 2999 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_186() {
/* 3003 */     if (jj_3R_188()) return true;
/* 3004 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3005 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_183()
/*      */   {
/* 3010 */     Token xsp = this.jj_scanpos;
/* 3011 */     if (jj_3R_186()) {
/* 3012 */       this.jj_scanpos = xsp;
/* 3013 */       if (jj_3R_187()) return true;
/* 3014 */       if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3015 */     } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 3016 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_181() {
/* 3020 */     if (jj_3R_183()) return true;
/* 3021 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3022 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_180() {
/* 3026 */     if (jj_3R_182()) return true;
/* 3027 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3028 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_178()
/*      */   {
/* 3033 */     Token xsp = this.jj_scanpos;
/* 3034 */     if (jj_3R_180()) {
/* 3035 */       this.jj_scanpos = xsp;
/* 3036 */       if (jj_3R_181()) return true;
/* 3037 */       if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3038 */     } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 3039 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_179() {
/* 3043 */     if (jj_scan_token(4)) return true;
/* 3044 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3045 */     if (jj_3R_178()) return true;
/* 3046 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3047 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_177() {
/* 3051 */     if (jj_3R_178()) return true;
/* 3052 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/*      */     do
/*      */     {
/* 3055 */       Token xsp = this.jj_scanpos;
/* 3056 */       if (jj_3R_179()) { this.jj_scanpos = xsp; break;
/* 3057 */       } } while ((this.jj_la != 0) || (this.jj_scanpos != this.jj_lastpos)); return false;
/*      */     
/* 3059 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_136() {
/* 3063 */     if (jj_3R_104()) return true;
/* 3064 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3065 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_137() {
/* 3069 */     if (jj_scan_token(83)) return true;
/* 3070 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3071 */     if (jj_3R_136()) return true;
/* 3072 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3073 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_127() {
/* 3077 */     if (jj_3R_136()) return true;
/* 3078 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/*      */     do
/*      */     {
/* 3081 */       Token xsp = this.jj_scanpos;
/* 3082 */       if (jj_3R_137()) { this.jj_scanpos = xsp; break;
/* 3083 */       } } while ((this.jj_la != 0) || (this.jj_scanpos != this.jj_lastpos)); return false;
/*      */     
/* 3085 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_119() {
/* 3089 */     if (jj_scan_token(76)) return true;
/* 3090 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/*      */     }
/* 3092 */     Token xsp = this.jj_scanpos;
/* 3093 */     if (jj_3R_127()) { this.jj_scanpos = xsp;
/* 3094 */     } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3095 */     if (jj_scan_token(77)) return true;
/* 3096 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3097 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_61() {
/* 3101 */     if (jj_scan_token(30)) return true;
/* 3102 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3103 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_60() {
/* 3107 */     if (jj_scan_token(29)) return true;
/* 3108 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3109 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_59() {
/* 3113 */     if (jj_scan_token(27)) return true;
/* 3114 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3115 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_58() {
/* 3119 */     if (jj_scan_token(28)) return true;
/* 3120 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3121 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3_1() {
/* 3125 */     if (jj_3R_15()) return true;
/* 3126 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3127 */     if (jj_scan_token(75)) return true;
/* 3128 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3129 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_17()
/*      */   {
/* 3134 */     Token xsp = this.jj_scanpos;
/* 3135 */     if (jj_3R_58()) {
/* 3136 */       this.jj_scanpos = xsp;
/* 3137 */       if (jj_3R_59()) {
/* 3138 */         this.jj_scanpos = xsp;
/* 3139 */         if (jj_3R_60()) {
/* 3140 */           this.jj_scanpos = xsp;
/* 3141 */           if (jj_3R_61()) return true;
/* 3142 */           if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3143 */         } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 3144 */         } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 3145 */       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 3146 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_155() {
/* 3150 */     if (jj_3R_15()) return true;
/* 3151 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3152 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_139() {
/* 3156 */     if (jj_3R_98()) return true;
/* 3157 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3158 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_138() {
/* 3162 */     if (jj_3R_15()) return true;
/* 3163 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3164 */     if (jj_scan_token(75)) return true;
/* 3165 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3166 */     if (jj_3R_15()) return true;
/* 3167 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3168 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_154() {
/* 3172 */     if (jj_scan_token(84)) return true;
/* 3173 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3174 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_132() {
/* 3178 */     if (jj_3R_15()) return true;
/* 3179 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3180 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_105() {
/* 3184 */     if (jj_3R_18()) return true;
/* 3185 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3186 */     if (jj_3R_119()) return true;
/* 3187 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3188 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_124() {
/* 3192 */     if (jj_scan_token(75)) return true;
/* 3193 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3194 */     if (jj_3R_15()) return true;
/* 3195 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3196 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_133() {
/* 3200 */     if (jj_scan_token(75)) return true;
/* 3201 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/*      */     }
/* 3203 */     Token xsp = this.jj_scanpos;
/* 3204 */     if (jj_3R_154()) {
/* 3205 */       this.jj_scanpos = xsp;
/* 3206 */       if (jj_3R_155()) return true;
/* 3207 */       if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3208 */     } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 3209 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_128()
/*      */   {
/* 3214 */     Token xsp = this.jj_scanpos;
/* 3215 */     if (jj_3R_138()) {
/* 3216 */       this.jj_scanpos = xsp;
/* 3217 */       if (jj_3R_139()) return true;
/* 3218 */       if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3219 */     } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 3220 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_131() {
/* 3224 */     if (jj_scan_token(84)) return true;
/* 3225 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3226 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_123()
/*      */   {
/* 3231 */     Token xsp = this.jj_scanpos;
/* 3232 */     if (jj_3R_131()) {
/* 3233 */       this.jj_scanpos = xsp;
/* 3234 */       if (jj_3R_132()) return true;
/* 3235 */       if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3236 */     } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 3237 */     xsp = this.jj_scanpos;
/* 3238 */     if (jj_3R_133()) { this.jj_scanpos = xsp;
/* 3239 */     } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3240 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_106() {
/* 3244 */     if (jj_3R_120()) return true;
/* 3245 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3246 */     if (jj_3R_119()) return true;
/* 3247 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3248 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_117() {
/* 3252 */     if (jj_3R_15()) return true;
/* 3253 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/*      */     }
/* 3255 */     Token xsp = this.jj_scanpos;
/* 3256 */     if (jj_3R_124()) { this.jj_scanpos = xsp;
/* 3257 */     } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3258 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3_5() {
/* 3262 */     if (jj_3R_18()) return true;
/* 3263 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3264 */     if (jj_scan_token(76)) return true;
/* 3265 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3266 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_103() {
/* 3270 */     if (jj_scan_token(13)) return true;
/* 3271 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3272 */     if (jj_3R_117()) return true;
/* 3273 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3274 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_91() {
/* 3278 */     if (jj_scan_token(73)) return true;
/* 3279 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3280 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_90() {
/* 3284 */     if (jj_scan_token(48)) return true;
/* 3285 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3286 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_89() {
/* 3290 */     if (jj_scan_token(72)) return true;
/* 3291 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3292 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_88() {
/* 3296 */     if (jj_scan_token(71)) return true;
/* 3297 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3298 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_97() {
/* 3302 */     if (jj_3R_106()) return true;
/* 3303 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3304 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_87() {
/* 3308 */     if (jj_scan_token(70)) return true;
/* 3309 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3310 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_96() {
/* 3314 */     if (jj_3R_105()) return true;
/* 3315 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3316 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_86() {
/* 3320 */     if (jj_scan_token(69)) return true;
/* 3321 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3322 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_95() {
/* 3326 */     if (jj_scan_token(16)) return true;
/* 3327 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3328 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_85() {
/* 3332 */     if (jj_scan_token(68)) return true;
/* 3333 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3334 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_94() {
/* 3338 */     if (jj_scan_token(14)) return true;
/* 3339 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3340 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_84() {
/* 3344 */     if (jj_scan_token(67)) return true;
/* 3345 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3346 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_93() {
/* 3350 */     if (jj_scan_token(76)) return true;
/* 3351 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3352 */     if (jj_3R_104()) return true;
/* 3353 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3354 */     if (jj_scan_token(77)) return true;
/* 3355 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3356 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_83() {
/* 3360 */     if (jj_scan_token(66)) return true;
/* 3361 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3362 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_92() {
/* 3366 */     if (jj_3R_103()) return true;
/* 3367 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3368 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_82() {
/* 3372 */     if (jj_scan_token(65)) return true;
/* 3373 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3374 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_81() {
/* 3378 */     if (jj_scan_token(64)) return true;
/* 3379 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3380 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_120() {
/* 3384 */     if (jj_3R_128()) return true;
/* 3385 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3386 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_80() {
/* 3390 */     if (jj_scan_token(63)) return true;
/* 3391 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3392 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_79() {
/* 3396 */     if (jj_scan_token(62)) return true;
/* 3397 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3398 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_78() {
/* 3402 */     if (jj_scan_token(61)) return true;
/* 3403 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3404 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_77() {
/* 3408 */     if (jj_scan_token(60)) return true;
/* 3409 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3410 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_19()
/*      */   {
/* 3415 */     Token xsp = this.jj_scanpos;
/* 3416 */     if (jj_3R_92()) {
/* 3417 */       this.jj_scanpos = xsp;
/* 3418 */       if (jj_3R_93()) {
/* 3419 */         this.jj_scanpos = xsp;
/* 3420 */         if (jj_3R_94()) {
/* 3421 */           this.jj_scanpos = xsp;
/* 3422 */           if (jj_3R_95()) {
/* 3423 */             this.jj_scanpos = xsp;
/* 3424 */             if (jj_3R_96()) {
/* 3425 */               this.jj_scanpos = xsp;
/* 3426 */               if (jj_3R_97()) return true;
/* 3427 */               if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3428 */             } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 3429 */             } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 3430 */           } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 3431 */         } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false;
/* 3432 */       } } else if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) { return false; }
/* 3433 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_76() {
/* 3437 */     if (jj_scan_token(59)) return true;
/* 3438 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3439 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_75() {
/* 3443 */     if (jj_scan_token(58)) return true;
/* 3444 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3445 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_74() {
/* 3449 */     if (jj_scan_token(57)) return true;
/* 3450 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3451 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_73() {
/* 3455 */     if (jj_scan_token(56)) return true;
/* 3456 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3457 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_72() {
/* 3461 */     if (jj_scan_token(55)) return true;
/* 3462 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3463 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_71() {
/* 3467 */     if (jj_scan_token(54)) return true;
/* 3468 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3469 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_70() {
/* 3473 */     if (jj_scan_token(53)) return true;
/* 3474 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3475 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_69() {
/* 3479 */     if (jj_scan_token(52)) return true;
/* 3480 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3481 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_68() {
/* 3485 */     if (jj_scan_token(51)) return true;
/* 3486 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3487 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_67() {
/* 3491 */     if (jj_scan_token(50)) return true;
/* 3492 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3493 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_66() {
/* 3497 */     if (jj_scan_token(49)) return true;
/* 3498 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3499 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_65() {
/* 3503 */     if (jj_scan_token(47)) return true;
/* 3504 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) return false;
/* 3505 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3513 */   public boolean lookingAhead = false;
/*      */   private boolean jj_semLA;
/*      */   private int jj_gen;
/* 3516 */   private final int[] jj_la1 = new int[39];
/* 3517 */   private final int[] jj_la1_0 = { 2139095040, 125829120, 0, 0, 125829120, -8388596, 12, 4, 12, 12, 2139095040, -8388608, 0, Integer.MIN_VALUE, Integer.MIN_VALUE, 0, 90112, 2139095040, 0, -8298420, 16, -8388596, 0, 12, 8388608, 16777216, 384, 384, 7680, 7680, 32, 64, 100663296, 100663296, -8298420, 2139095040, 2139095040, 0, 2013265920 };
/* 3518 */   private final int[] jj_la1_1 = { 61440, 0, 61440, 0, 0, -1, 0, 0, 0, 0, 61440, -1, 0, 4095, 4095, 0, 0, 61440, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 61440, 61440, 0, 0 };
/* 3519 */   private final int[] jj_la1_2 = { 2047, 1024, 1023, 2048, 1024, 1361919, 0, 0, 0, 0, 1050623, 1361919, 65536, 0, 0, 262144, 4096, 2047, 524288, 1366015, 0, 1361919, 65536, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1048576, 1048576, 1366015, 1050623, 1050623, 2048, 0 };
/* 3520 */   private final JJCalls[] jj_2_rtns = new JJCalls[6];
/* 3521 */   private boolean jj_rescan = false;
/* 3522 */   private int jj_gc = 0;
/*      */   
/*      */   public XPathParser(java.io.InputStream stream) {
/* 3525 */     this.jj_input_stream = new JavaCharStream(stream, 1, 1);
/* 3526 */     this.token_source = new XPathParserTokenManager(this.jj_input_stream);
/* 3527 */     this.token = new Token();
/* 3528 */     this.token.next = (this.jj_nt = this.token_source.getNextToken());
/* 3529 */     this.jj_gen = 0;
/* 3530 */     for (int i = 0; i < 39; i++) this.jj_la1[i] = -1;
/* 3531 */     for (int i = 0; i < this.jj_2_rtns.length; i++) this.jj_2_rtns[i] = new JJCalls();
/*      */   }
/*      */   
/*      */   public void ReInit(java.io.InputStream stream) {
/* 3535 */     this.jj_input_stream.ReInit(stream, 1, 1);
/* 3536 */     this.token_source.ReInit(this.jj_input_stream);
/* 3537 */     this.token = new Token();
/* 3538 */     this.token.next = (this.jj_nt = this.token_source.getNextToken());
/* 3539 */     this.jj_gen = 0;
/* 3540 */     for (int i = 0; i < 39; i++) this.jj_la1[i] = -1;
/* 3541 */     for (int i = 0; i < this.jj_2_rtns.length; i++) this.jj_2_rtns[i] = new JJCalls();
/*      */   }
/*      */   
/*      */   public XPathParser(java.io.Reader stream) {
/* 3545 */     this.jj_input_stream = new JavaCharStream(stream, 1, 1);
/* 3546 */     this.token_source = new XPathParserTokenManager(this.jj_input_stream);
/* 3547 */     this.token = new Token();
/* 3548 */     this.token.next = (this.jj_nt = this.token_source.getNextToken());
/* 3549 */     this.jj_gen = 0;
/* 3550 */     for (int i = 0; i < 39; i++) this.jj_la1[i] = -1;
/* 3551 */     for (int i = 0; i < this.jj_2_rtns.length; i++) this.jj_2_rtns[i] = new JJCalls();
/*      */   }
/*      */   
/*      */   public void ReInit(java.io.Reader stream) {
/* 3555 */     this.jj_input_stream.ReInit(stream, 1, 1);
/* 3556 */     this.token_source.ReInit(this.jj_input_stream);
/* 3557 */     this.token = new Token();
/* 3558 */     this.token.next = (this.jj_nt = this.token_source.getNextToken());
/* 3559 */     this.jj_gen = 0;
/* 3560 */     for (int i = 0; i < 39; i++) this.jj_la1[i] = -1;
/* 3561 */     for (int i = 0; i < this.jj_2_rtns.length; i++) this.jj_2_rtns[i] = new JJCalls();
/*      */   }
/*      */   
/*      */   public XPathParser(XPathParserTokenManager tm) {
/* 3565 */     this.token_source = tm;
/* 3566 */     this.token = new Token();
/* 3567 */     this.token.next = (this.jj_nt = this.token_source.getNextToken());
/* 3568 */     this.jj_gen = 0;
/* 3569 */     for (int i = 0; i < 39; i++) this.jj_la1[i] = -1;
/* 3570 */     for (int i = 0; i < this.jj_2_rtns.length; i++) this.jj_2_rtns[i] = new JJCalls();
/*      */   }
/*      */   
/*      */   public void ReInit(XPathParserTokenManager tm) {
/* 3574 */     this.token_source = tm;
/* 3575 */     this.token = new Token();
/* 3576 */     this.token.next = (this.jj_nt = this.token_source.getNextToken());
/* 3577 */     this.jj_gen = 0;
/* 3578 */     for (int i = 0; i < 39; i++) this.jj_la1[i] = -1;
/* 3579 */     for (int i = 0; i < this.jj_2_rtns.length; i++) this.jj_2_rtns[i] = new JJCalls();
/*      */   }
/*      */   
/*      */   private final Token jj_consume_token(int kind) throws ParseException {
/* 3583 */     Token oldToken = this.token;
/* 3584 */     if ((this.token = this.jj_nt).next != null) this.jj_nt = this.jj_nt.next; else
/* 3585 */       this.jj_nt = (this.jj_nt.next = this.token_source.getNextToken());
/* 3586 */     if (this.token.kind == kind) {
/* 3587 */       this.jj_gen += 1;
/* 3588 */       if (++this.jj_gc > 100) {
/* 3589 */         this.jj_gc = 0;
/* 3590 */         for (int i = 0; i < this.jj_2_rtns.length; i++) {
/* 3591 */           JJCalls c = this.jj_2_rtns[i];
/* 3592 */           while (c != null) {
/* 3593 */             if (c.gen < this.jj_gen) c.first = null;
/* 3594 */             c = c.next;
/*      */           }
/*      */         }
/*      */       }
/* 3598 */       return this.token;
/*      */     }
/* 3600 */     this.jj_nt = this.token;
/* 3601 */     this.token = oldToken;
/* 3602 */     this.jj_kind = kind;
/* 3603 */     throw generateParseException();
/*      */   }
/*      */   
/*      */   private final boolean jj_scan_token(int kind) {
/* 3607 */     if (this.jj_scanpos == this.jj_lastpos) {
/* 3608 */       this.jj_la -= 1;
/* 3609 */       if (this.jj_scanpos.next == null) {
/* 3610 */         this.jj_lastpos = (this.jj_scanpos = this.jj_scanpos.next = this.token_source.getNextToken());
/*      */       } else {
/* 3612 */         this.jj_lastpos = (this.jj_scanpos = this.jj_scanpos.next);
/*      */       }
/*      */     } else {
/* 3615 */       this.jj_scanpos = this.jj_scanpos.next;
/*      */     }
/* 3617 */     if (this.jj_rescan) {
/* 3618 */       int i = 0; for (Token tok = this.token; 
/* 3619 */           (tok != null) && (tok != this.jj_scanpos); tok = tok.next) i++;
/* 3620 */       if (tok != null) jj_add_error_token(kind, i);
/*      */     }
/* 3622 */     return this.jj_scanpos.kind != kind;
/*      */   }
/*      */   
/*      */   public final Token getNextToken() {
/* 3626 */     if ((this.token = this.jj_nt).next != null) this.jj_nt = this.jj_nt.next; else
/* 3627 */       this.jj_nt = (this.jj_nt.next = this.token_source.getNextToken());
/* 3628 */     this.jj_gen += 1;
/* 3629 */     return this.token;
/*      */   }
/*      */   
/*      */   public final Token getToken(int index) {
/* 3633 */     Token t = this.lookingAhead ? this.jj_scanpos : this.token;
/* 3634 */     for (int i = 0; i < index; i++) {
/* 3635 */       if (t.next != null) t = t.next; else
/* 3636 */         t = t.next = this.token_source.getNextToken();
/*      */     }
/* 3638 */     return t;
/*      */   }
/*      */   
/* 3641 */   private java.util.Vector jj_expentries = new java.util.Vector();
/*      */   private int[] jj_expentry;
/* 3643 */   private int jj_kind = -1;
/* 3644 */   private int[] jj_lasttokens = new int[100];
/*      */   private int jj_endpos;
/*      */   
/*      */   private void jj_add_error_token(int kind, int pos) {
/* 3648 */     if (pos >= 100) return;
/* 3649 */     if (pos == this.jj_endpos + 1) {
/* 3650 */       this.jj_lasttokens[(this.jj_endpos++)] = kind;
/* 3651 */     } else if (this.jj_endpos != 0) {
/* 3652 */       this.jj_expentry = new int[this.jj_endpos];
/* 3653 */       for (int i = 0; i < this.jj_endpos; i++) {
/* 3654 */         this.jj_expentry[i] = this.jj_lasttokens[i];
/*      */       }
/* 3656 */       boolean exists = false;
/* 3657 */       for (java.util.Enumeration enum = this.jj_expentries.elements(); enum.hasMoreElements();) {
/* 3658 */         int[] oldentry = (int[])enum.nextElement();
/* 3659 */         if (oldentry.length == this.jj_expentry.length) {
/* 3660 */           exists = true;
/* 3661 */           for (int i = 0; i < this.jj_expentry.length; i++) {
/* 3662 */             if (oldentry[i] != this.jj_expentry[i]) {
/* 3663 */               exists = false;
/* 3664 */               break;
/*      */             }
/*      */           }
/* 3667 */           if (exists) break;
/*      */         }
/*      */       }
/* 3670 */       if (!exists) this.jj_expentries.addElement(this.jj_expentry);
/* 3671 */       if (pos != 0) this.jj_lasttokens[((this.jj_endpos = pos) - 1)] = kind;
/*      */     }
/*      */   }
/*      */   
/*      */   public final ParseException generateParseException() {
/* 3676 */     this.jj_expentries.removeAllElements();
/* 3677 */     boolean[] la1tokens = new boolean[85];
/* 3678 */     for (int i = 0; i < 85; i++) {
/* 3679 */       la1tokens[i] = false;
/*      */     }
/* 3681 */     if (this.jj_kind >= 0) {
/* 3682 */       la1tokens[this.jj_kind] = true;
/* 3683 */       this.jj_kind = -1;
/*      */     }
/* 3685 */     for (int i = 0; i < 39; i++) {
/* 3686 */       if (this.jj_la1[i] == this.jj_gen) {
/* 3687 */         for (int j = 0; j < 32; j++) {
/* 3688 */           if ((this.jj_la1_0[i] & 1 << j) != 0) {
/* 3689 */             la1tokens[j] = true;
/*      */           }
/* 3691 */           if ((this.jj_la1_1[i] & 1 << j) != 0) {
/* 3692 */             la1tokens[(32 + j)] = true;
/*      */           }
/* 3694 */           if ((this.jj_la1_2[i] & 1 << j) != 0) {
/* 3695 */             la1tokens[(64 + j)] = true;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 3700 */     for (int i = 0; i < 85; i++) {
/* 3701 */       if (la1tokens[i] != 0) {
/* 3702 */         this.jj_expentry = new int[1];
/* 3703 */         this.jj_expentry[0] = i;
/* 3704 */         this.jj_expentries.addElement(this.jj_expentry);
/*      */       }
/*      */     }
/* 3707 */     this.jj_endpos = 0;
/* 3708 */     jj_rescan_token();
/* 3709 */     jj_add_error_token(0, 0);
/* 3710 */     int[][] exptokseq = new int[this.jj_expentries.size()][];
/* 3711 */     for (int i = 0; i < this.jj_expentries.size(); i++) {
/* 3712 */       exptokseq[i] = ((int[])this.jj_expentries.elementAt(i));
/*      */     }
/* 3714 */     return new ParseException(this.token, exptokseq, XPathParserConstants.tokenImage);
/*      */   }
/*      */   
/*      */ 
/*      */   public final void enable_tracing() {}
/*      */   
/*      */   public final void disable_tracing() {}
/*      */   
/*      */   private final void jj_rescan_token()
/*      */   {
/* 3724 */     this.jj_rescan = true;
/* 3725 */     for (int i = 0; i < 6; i++) {
/* 3726 */       JJCalls p = this.jj_2_rtns[i];
/*      */       do {
/* 3728 */         if (p.gen > this.jj_gen) {
/* 3729 */           this.jj_la = p.arg;this.jj_lastpos = (this.jj_scanpos = p.first);
/* 3730 */           switch (i) {
/* 3731 */           case 0:  jj_3_1(); break;
/* 3732 */           case 1:  jj_3_2(); break;
/* 3733 */           case 2:  jj_3_3(); break;
/* 3734 */           case 3:  jj_3_4(); break;
/* 3735 */           case 4:  jj_3_5(); break;
/* 3736 */           case 5:  jj_3_6();
/*      */           }
/*      */         }
/* 3739 */         p = p.next;
/* 3740 */       } while (p != null);
/*      */     }
/* 3742 */     this.jj_rescan = false;
/*      */   }
/*      */   
/*      */   private final void jj_save(int index, int xla) {
/* 3746 */     JJCalls p = this.jj_2_rtns[index];
/* 3747 */     while (p.gen > this.jj_gen) {
/* 3748 */       if (p.next == null) { p = p.next = new JJCalls(); break; }
/* 3749 */       p = p.next;
/*      */     }
/* 3751 */     p.gen = (this.jj_gen + xla - this.jj_la);p.first = this.token;p.arg = xla;
/*      */   }
/*      */   
/*      */   static final class JJCalls
/*      */   {
/*      */     int gen;
/*      */     Token first;
/*      */     int arg;
/*      */     JJCalls next;
/*      */   }
/*      */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/parser/XPathParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */