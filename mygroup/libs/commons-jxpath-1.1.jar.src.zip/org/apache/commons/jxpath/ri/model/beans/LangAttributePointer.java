/*     */ package org.apache.commons.jxpath.ri.model.beans;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LangAttributePointer
/*     */   extends NodePointer
/*     */ {
/*     */   public LangAttributePointer(NodePointer parent)
/*     */   {
/*  77 */     super(parent);
/*     */   }
/*     */   
/*     */   public QName getName() {
/*  81 */     return new QName("xml", "lang");
/*     */   }
/*     */   
/*     */   public QName getExpandedName() {
/*  85 */     return getName();
/*     */   }
/*     */   
/*     */   public String getNamespaceURI() {
/*  89 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/*  93 */     return false;
/*     */   }
/*     */   
/*     */   public int getLength() {
/*  97 */     return 1;
/*     */   }
/*     */   
/*     */   public Object getBaseValue() {
/* 101 */     return this.parent.getLocale().toString().replace('_', '-');
/*     */   }
/*     */   
/*     */   public Object getImmediateNode() {
/* 105 */     return getBaseValue();
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 109 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/* 116 */     throw new UnsupportedOperationException("Cannot change locale using the 'lang' attribute");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String asPath()
/*     */   {
/* 123 */     StringBuffer buffer = new StringBuffer();
/* 124 */     if (this.parent != null) {
/* 125 */       buffer.append(this.parent.asPath());
/* 126 */       if ((buffer.length() == 0) || (buffer.charAt(buffer.length() - 1) != '/'))
/*     */       {
/* 128 */         buffer.append('/');
/*     */       }
/*     */     }
/* 131 */     buffer.append("@xml:lang");
/* 132 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 136 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 140 */     if (object == this) {
/* 141 */       return true;
/*     */     }
/*     */     
/* 144 */     if (!(object instanceof LangAttributePointer)) {
/* 145 */       return false;
/*     */     }
/*     */     
/* 148 */     return true;
/*     */   }
/*     */   
/*     */   public boolean testNode(NodeTest test) {
/* 152 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2)
/*     */   {
/* 160 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/beans/LangAttributePointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */