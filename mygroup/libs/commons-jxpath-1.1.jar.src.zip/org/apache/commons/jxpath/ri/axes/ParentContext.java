/*     */ package org.apache.commons.jxpath.ri.axes;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParentContext
/*     */   extends EvalContext
/*     */ {
/*     */   private NodeTest nodeTest;
/*  76 */   private boolean setStarted = false;
/*     */   private NodePointer currentNodePointer;
/*     */   
/*     */   public ParentContext(EvalContext parentContext, NodeTest nodeTest) {
/*  80 */     super(parentContext);
/*  81 */     this.nodeTest = nodeTest;
/*     */   }
/*     */   
/*     */   public NodePointer getCurrentNodePointer() {
/*  85 */     return this.currentNodePointer;
/*     */   }
/*     */   
/*     */   public int getCurrentPosition() {
/*  89 */     return 1;
/*     */   }
/*     */   
/*     */   public int getDocumentOrder() {
/*  93 */     return -1;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  97 */     super.reset();
/*  98 */     this.setStarted = false;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 102 */     super.setPosition(position);
/* 103 */     return position == 1;
/*     */   }
/*     */   
/*     */   public boolean nextNode()
/*     */   {
/* 108 */     if (this.setStarted) {
/* 109 */       return false;
/*     */     }
/* 111 */     this.setStarted = true;
/* 112 */     NodePointer thisLocation = this.parentContext.getCurrentNodePointer();
/* 113 */     this.currentNodePointer = thisLocation.getParent();
/*     */     
/* 115 */     while ((this.currentNodePointer != null) && (this.currentNodePointer.isContainer())) {
/* 116 */       this.currentNodePointer = this.currentNodePointer.getParent();
/*     */     }
/* 118 */     if ((this.currentNodePointer != null) && (this.currentNodePointer.testNode(this.nodeTest)))
/*     */     {
/* 120 */       this.position += 1;
/* 121 */       return true;
/*     */     }
/* 123 */     return false;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/axes/ParentContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */