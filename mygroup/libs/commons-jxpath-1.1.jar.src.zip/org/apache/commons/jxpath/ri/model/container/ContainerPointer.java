/*     */ package org.apache.commons.jxpath.ri.model.container;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.Container;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.util.ValueUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContainerPointer
/*     */   extends NodePointer
/*     */ {
/*     */   private Container container;
/*     */   private NodePointer valuePointer;
/*     */   
/*     */   public ContainerPointer(Container container, Locale locale)
/*     */   {
/*  86 */     super(null, locale);
/*  87 */     this.container = container;
/*     */   }
/*     */   
/*     */   public ContainerPointer(NodePointer parent, Container container) {
/*  91 */     super(parent);
/*  92 */     this.container = container;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isContainer()
/*     */   {
/*  99 */     return true;
/*     */   }
/*     */   
/*     */   public QName getName() {
/* 103 */     return null;
/*     */   }
/*     */   
/*     */   public Object getBaseValue() {
/* 107 */     return this.container.getValue();
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 111 */     Object value = getBaseValue();
/* 112 */     return (value != null) && (ValueUtils.isCollection(value));
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 116 */     Object value = getBaseValue();
/* 117 */     if (value == null) {
/* 118 */       return 1;
/*     */     }
/* 120 */     return ValueUtils.getLength(value);
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 124 */     return getValuePointer().isLeaf();
/*     */   }
/*     */   
/*     */   public Object getImmediateNode() {
/* 128 */     Object value = getBaseValue();
/* 129 */     if (this.index != Integer.MIN_VALUE) {
/* 130 */       if ((this.index >= 0) && (this.index < getLength())) {
/* 131 */         return ValueUtils.getValue(value, this.index);
/*     */       }
/*     */       
/* 134 */       return null;
/*     */     }
/*     */     
/* 137 */     return value;
/*     */   }
/*     */   
/*     */   public void setValue(Object value) {
/* 141 */     this.container.setValue(value);
/*     */   }
/*     */   
/*     */   public NodePointer getImmediateValuePointer() {
/* 145 */     if (this.valuePointer == null) {
/* 146 */       Object value = getImmediateNode();
/* 147 */       this.valuePointer = NodePointer.newChildNodePointer(this, getName(), value);
/*     */     }
/*     */     
/* 150 */     return this.valuePointer;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 154 */     return System.identityHashCode(this.container) + this.index;
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 158 */     if (object == this) {
/* 159 */       return true;
/*     */     }
/*     */     
/* 162 */     if (!(object instanceof ContainerPointer)) {
/* 163 */       return false;
/*     */     }
/*     */     
/* 166 */     ContainerPointer other = (ContainerPointer)object;
/* 167 */     return (this.container == other.container) && (this.index == other.index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodeIterator childIterator(NodeTest test, boolean reverse, NodePointer startWith)
/*     */   {
/* 175 */     return getValuePointer().childIterator(test, reverse, startWith);
/*     */   }
/*     */   
/*     */   public NodeIterator attributeIterator(QName name) {
/* 179 */     return getValuePointer().attributeIterator(name);
/*     */   }
/*     */   
/*     */   public NodeIterator namespaceIterator() {
/* 183 */     return getValuePointer().namespaceIterator();
/*     */   }
/*     */   
/*     */   public NodePointer namespacePointer(String namespace) {
/* 187 */     return getValuePointer().namespacePointer(namespace);
/*     */   }
/*     */   
/*     */   public boolean testNode(NodeTest nodeTest) {
/* 191 */     return getValuePointer().testNode(nodeTest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2)
/*     */   {
/* 198 */     return pointer1.getIndex() - pointer2.getIndex();
/*     */   }
/*     */   
/*     */   public String asPath() {
/* 202 */     if (this.parent != null) {
/* 203 */       return this.parent.asPath();
/*     */     }
/* 205 */     return "/";
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/container/ContainerPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */