/*     */ package org.apache.commons.jxpath.ri.axes;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.InfoSetUtil;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.compiler.Expression;
/*     */ import org.apache.commons.jxpath.ri.compiler.NameAttributeTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.Step;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.LangAttributePointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.NullElementPointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.PropertyOwnerPointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.PropertyPointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimplePathInterpreter
/*     */ {
/* 103 */   private static final QName QNAME_NAME = new QName(null, "name");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int PERFECT_MATCH = 1000;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodePointer interpretSimpleLocationPath(EvalContext context, NodePointer root, Step[] steps)
/*     */   {
/* 122 */     NodePointer pointer = doStep(context, root, steps, 0);
/*     */     
/* 124 */     return pointer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NodePointer interpretSimpleExpressionPath(EvalContext context, NodePointer root, Expression[] predicates, Step[] steps)
/*     */   {
/* 142 */     NodePointer pointer = doPredicate(context, root, steps, -1, predicates, 0);
/*     */     
/*     */ 
/* 145 */     return pointer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NodePointer doStep(EvalContext context, NodePointer parent, Step[] steps, int currentStep)
/*     */   {
/* 159 */     if (parent == null) {
/* 160 */       return null;
/*     */     }
/*     */     
/* 163 */     if (currentStep == steps.length)
/*     */     {
/* 165 */       return parent;
/*     */     }
/*     */     
/*     */ 
/* 169 */     parent = valuePointer(parent);
/*     */     
/* 171 */     Step step = steps[currentStep];
/* 172 */     Expression[] predicates = step.getPredicates();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 185 */     if ((parent instanceof PropertyOwnerPointer)) {
/* 186 */       if ((predicates == null) || (predicates.length == 0)) {
/* 187 */         return doStepNoPredicatesPropertyOwner(context, (PropertyOwnerPointer)parent, steps, currentStep);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */       return doStepPredicatesPropertyOwner(context, (PropertyOwnerPointer)parent, steps, currentStep);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 202 */     if ((predicates == null) || (predicates.length == 0)) {
/* 203 */       return doStepNoPredicatesStandard(context, parent, steps, currentStep);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 210 */     return doStepPredicatesStandard(context, parent, steps, currentStep);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NodePointer doStepNoPredicatesPropertyOwner(EvalContext context, PropertyOwnerPointer parentPointer, Step[] steps, int currentStep)
/*     */   {
/* 232 */     Step step = steps[currentStep];
/* 233 */     NodePointer childPointer = createChildPointerForStep(parentPointer, step);
/*     */     
/*     */ 
/* 236 */     if (!childPointer.isActual())
/*     */     {
/* 238 */       return createNullPointer(context, parentPointer, steps, currentStep);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 244 */     if (currentStep == steps.length - 1)
/*     */     {
/* 246 */       return childPointer;
/*     */     }
/* 248 */     if (childPointer.isCollection())
/*     */     {
/*     */ 
/*     */ 
/* 252 */       int bestQuality = 0;
/* 253 */       NodePointer bestMatch = null;
/* 254 */       int count = childPointer.getLength();
/* 255 */       for (int i = 0; i < count; i++) {
/* 256 */         childPointer.setIndex(i);
/* 257 */         NodePointer pointer = doStep(context, childPointer, steps, currentStep + 1);
/*     */         
/* 259 */         int quality = computeQuality(pointer);
/* 260 */         if (quality == 1000) {
/* 261 */           return pointer;
/*     */         }
/* 263 */         if (quality > bestQuality) {
/* 264 */           bestQuality = quality;
/* 265 */           bestMatch = (NodePointer)pointer.clone();
/*     */         }
/*     */       }
/* 268 */       if (bestMatch != null) {
/* 269 */         return bestMatch;
/*     */       }
/*     */       
/* 272 */       return createNullPointer(context, childPointer, steps, currentStep);
/*     */     }
/*     */     
/*     */ 
/* 276 */     return doStep(context, childPointer, steps, currentStep + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NodePointer doStepNoPredicatesStandard(EvalContext context, NodePointer parentPointer, Step[] steps, int currentStep)
/*     */   {
/* 292 */     Step step = steps[currentStep];
/*     */     
/* 294 */     if (step.getAxis() == 1) {
/* 295 */       return doStep(context, parentPointer, steps, currentStep + 1);
/*     */     }
/*     */     
/* 298 */     int bestQuality = 0;
/* 299 */     NodePointer bestMatch = null;
/* 300 */     NodeIterator it = getNodeIterator(parentPointer, step);
/* 301 */     if (it != null) {
/* 302 */       for (int i = 1; it.setPosition(i); i++) {
/* 303 */         NodePointer childPointer = it.getNodePointer();
/* 304 */         if (steps.length == currentStep + 1)
/*     */         {
/* 306 */           return childPointer;
/*     */         }
/* 308 */         NodePointer pointer = doStep(context, childPointer, steps, currentStep + 1);
/*     */         
/* 310 */         int quality = computeQuality(pointer);
/* 311 */         if (quality == 1000) {
/* 312 */           return pointer;
/*     */         }
/* 314 */         if (quality > bestQuality) {
/* 315 */           bestQuality = quality;
/* 316 */           bestMatch = (NodePointer)pointer.clone();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 321 */     if (bestMatch != null) {
/* 322 */       return bestMatch;
/*     */     }
/*     */     
/* 325 */     return createNullPointer(context, parentPointer, steps, currentStep);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NodePointer doStepPredicatesPropertyOwner(EvalContext context, PropertyOwnerPointer parentPointer, Step[] steps, int currentStep)
/*     */   {
/* 338 */     Step step = steps[currentStep];
/* 339 */     Expression[] predicates = step.getPredicates();
/*     */     
/* 341 */     NodePointer childPointer = createChildPointerForStep(parentPointer, step);
/*     */     
/* 343 */     if (!childPointer.isActual())
/*     */     {
/* 345 */       return createNullPointer(context, parentPointer, steps, currentStep);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 353 */     return doPredicate(context, childPointer, steps, currentStep, predicates, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NodePointer createChildPointerForStep(PropertyOwnerPointer parentPointer, Step step)
/*     */   {
/* 365 */     int axis = step.getAxis();
/* 366 */     if ((axis == 2) || (axis == 5))
/*     */     {
/* 368 */       QName name = ((NodeNameTest)step.getNodeTest()).getNodeName();
/* 369 */       NodePointer childPointer; if ((axis == 5) && (isLangAttribute(name))) {
/* 370 */         childPointer = new LangAttributePointer(parentPointer);
/*     */       }
/*     */       else {
/* 373 */         childPointer = parentPointer.getPropertyPointer();
/* 374 */         ((PropertyPointer)childPointer).setPropertyName(name.toString());
/*     */         
/* 376 */         childPointer.setAttribute(axis == 5);
/*     */       }
/* 378 */       return childPointer;
/*     */     }
/*     */     
/* 381 */     return parentPointer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NodePointer doStepPredicatesStandard(EvalContext context, NodePointer parent, Step[] steps, int currentStep)
/*     */   {
/* 394 */     Step step = steps[currentStep];
/* 395 */     Expression[] predicates = step.getPredicates();
/*     */     
/* 397 */     int axis = step.getAxis();
/* 398 */     if (axis == 1) {
/* 399 */       return doPredicate(context, parent, steps, currentStep, predicates, 0);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 408 */     Expression predicate = predicates[0];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 415 */     if (predicates.length == 1) {
/* 416 */       NodeIterator it = getNodeIterator(parent, step);
/* 417 */       NodePointer pointer = null;
/* 418 */       if (it != null) {
/* 419 */         if ((predicate instanceof NameAttributeTest)) {
/* 420 */           String key = keyFromPredicate(context, predicate);
/* 421 */           for (int i = 1; it.setPosition(i); i++) {
/* 422 */             NodePointer ptr = it.getNodePointer();
/* 423 */             if (isNameAttributeEqual(ptr, key)) {
/* 424 */               pointer = ptr;
/* 425 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */         else {
/* 430 */           int index = indexFromPredicate(context, predicate);
/* 431 */           if (it.setPosition(index + 1)) {
/* 432 */             pointer = it.getNodePointer();
/*     */           }
/*     */         }
/*     */       }
/* 436 */       if (pointer != null) {
/* 437 */         return doStep(context, pointer, steps, currentStep + 1);
/*     */       }
/*     */     }
/*     */     else {
/* 441 */       NodeIterator it = getNodeIterator(parent, step);
/* 442 */       if (it != null) {
/* 443 */         List list = new ArrayList();
/* 444 */         for (int i = 1; it.setPosition(i); i++) {
/* 445 */           list.add(it.getNodePointer());
/*     */         }
/* 447 */         NodePointer pointer = doPredicatesStandard(context, list, steps, currentStep, predicates, 0);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 455 */         if (pointer != null) {
/* 456 */           return pointer;
/*     */         }
/*     */       }
/*     */     }
/* 460 */     return createNullPointer(context, parent, steps, currentStep);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NodePointer doPredicate(EvalContext context, NodePointer parent, Step[] steps, int currentStep, Expression[] predicates, int currentPredicate)
/*     */   {
/* 472 */     if (currentPredicate == predicates.length) {
/* 473 */       return doStep(context, parent, steps, currentStep + 1);
/*     */     }
/*     */     
/* 476 */     Expression predicate = predicates[currentPredicate];
/* 477 */     if ((predicate instanceof NameAttributeTest)) {
/* 478 */       return doPredicateName(context, parent, steps, currentStep, predicates, currentPredicate);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 487 */     return doPredicateIndex(context, parent, steps, currentStep, predicates, currentPredicate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NodePointer doPredicateName(EvalContext context, NodePointer parent, Step[] steps, int currentStep, Expression[] predicates, int currentPredicate)
/*     */   {
/* 502 */     Expression predicate = predicates[currentPredicate];
/* 503 */     String key = keyFromPredicate(context, predicate);
/* 504 */     NodePointer child = valuePointer(parent);
/* 505 */     if ((child instanceof PropertyOwnerPointer)) {
/* 506 */       PropertyPointer pointer = ((PropertyOwnerPointer)child).getPropertyPointer();
/*     */       
/* 508 */       pointer.setPropertyName(key);
/* 509 */       if (pointer.isActual()) {
/* 510 */         return doPredicate(context, pointer, steps, currentStep, predicates, currentPredicate + 1);
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 519 */     else if (child.isCollection())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 526 */       NodePointer bestMatch = null;
/* 527 */       int bestQuality = 0;
/* 528 */       int count = child.getLength();
/* 529 */       for (int i = 0; i < count; i++) {
/* 530 */         child.setIndex(i);
/* 531 */         NodePointer valuePointer = valuePointer(child);
/* 532 */         if (valuePointer == child) {
/* 533 */           valuePointer = (NodePointer)child.clone();
/*     */         }
/*     */         NodePointer pointer;
/* 536 */         if (((valuePointer instanceof PropertyOwnerPointer)) || (valuePointer.isCollection()))
/*     */         {
/* 538 */           pointer = doPredicateName(context, valuePointer, steps, currentStep, predicates, currentPredicate);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 547 */         else if (isNameAttributeEqual(valuePointer, key)) {
/* 548 */           pointer = doPredicate(context, valuePointer, steps, currentStep, predicates, currentPredicate + 1);
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 558 */           pointer = null;
/*     */         }
/* 560 */         if (pointer != null) {
/* 561 */           int quality = computeQuality(pointer);
/* 562 */           if (quality == 1000) {
/* 563 */             return pointer;
/*     */           }
/* 565 */           if (quality > bestQuality) {
/* 566 */             bestMatch = (NodePointer)pointer.clone();
/* 567 */             bestQuality = quality;
/*     */           }
/*     */         }
/*     */       }
/* 571 */       if (bestMatch != null) {
/* 572 */         return bestMatch;
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 579 */       NodePointer found = doPredicatesStandard(context, Collections.singletonList(child), steps, currentStep, predicates, currentPredicate);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 587 */       if (found != null) {
/* 588 */         return found;
/*     */       }
/*     */     }
/*     */     
/* 592 */     return createNullPointerForPredicates(context, child, steps, currentStep, predicates, currentPredicate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NodePointer doPredicatesStandard(EvalContext context, List parents, Step[] steps, int currentStep, Expression[] predicates, int currentPredicate)
/*     */   {
/* 610 */     if (parents.size() == 0) {
/* 611 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 617 */     if (currentPredicate == predicates.length) {
/* 618 */       NodePointer pointer = (NodePointer)parents.get(0);
/* 619 */       return doStep(context, pointer, steps, currentStep + 1);
/*     */     }
/*     */     
/* 622 */     Expression predicate = predicates[currentPredicate];
/* 623 */     if ((predicate instanceof NameAttributeTest)) {
/* 624 */       String key = keyFromPredicate(context, predicate);
/* 625 */       List newList = new ArrayList();
/* 626 */       for (int i = 0; i < parents.size(); i++) {
/* 627 */         NodePointer pointer = (NodePointer)parents.get(i);
/* 628 */         if (isNameAttributeEqual(pointer, key)) {
/* 629 */           newList.add(pointer);
/*     */         }
/*     */       }
/* 632 */       if (newList.size() == 0) {
/* 633 */         return null;
/*     */       }
/* 635 */       return doPredicatesStandard(context, newList, steps, currentStep, predicates, currentPredicate + 1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 647 */     int index = indexFromPredicate(context, predicate);
/* 648 */     if ((index < 0) || (index >= parents.size())) {
/* 649 */       return null;
/*     */     }
/* 651 */     NodePointer ptr = (NodePointer)parents.get(index);
/* 652 */     return doPredicate(context, ptr, steps, currentStep, predicates, currentPredicate + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NodePointer doPredicateIndex(EvalContext context, NodePointer parent, Step[] steps, int currentStep, Expression[] predicates, int currentPredicate)
/*     */   {
/* 671 */     Expression predicate = predicates[currentPredicate];
/* 672 */     int index = indexFromPredicate(context, predicate);
/* 673 */     NodePointer pointer = parent;
/* 674 */     if (isCollectionElement(pointer, index)) {
/* 675 */       pointer.setIndex(index);
/* 676 */       return doPredicate(context, pointer, steps, currentStep, predicates, currentPredicate + 1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 684 */     return createNullPointerForPredicates(context, parent, steps, currentStep, predicates, currentPredicate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int indexFromPredicate(EvalContext context, Expression predicate)
/*     */   {
/* 701 */     Object value = predicate.computeValue(context);
/* 702 */     if ((value instanceof EvalContext)) {
/* 703 */       value = ((EvalContext)value).getSingleNodePointer();
/*     */     }
/* 705 */     if ((value instanceof NodePointer)) {
/* 706 */       value = ((NodePointer)value).getValue();
/*     */     }
/* 708 */     if (value == null) {
/* 709 */       throw new JXPathException("Predicate value is null");
/*     */     }
/*     */     
/* 712 */     if ((value instanceof Number)) {
/* 713 */       return (int)(InfoSetUtil.doubleValue(value) + 0.5D) - 1;
/*     */     }
/* 715 */     if (InfoSetUtil.booleanValue(value)) {
/* 716 */       return 0;
/*     */     }
/*     */     
/* 719 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String keyFromPredicate(EvalContext context, Expression predicate)
/*     */   {
/* 729 */     Expression expr = ((NameAttributeTest)predicate).getNameTestExpression();
/*     */     
/* 731 */     return InfoSetUtil.stringValue(expr.computeValue(context));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int computeQuality(NodePointer pointer)
/*     */   {
/* 740 */     int quality = 1000;
/* 741 */     while ((pointer != null) && (!pointer.isActual())) {
/* 742 */       quality--;
/* 743 */       pointer = pointer.getParent();
/*     */     }
/* 745 */     return quality;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isNameAttributeEqual(NodePointer pointer, String name)
/*     */   {
/* 756 */     NodeIterator it = pointer.attributeIterator(QNAME_NAME);
/* 757 */     return (it != null) && (it.setPosition(1)) && (name.equals(it.getNodePointer().getValue()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isCollectionElement(NodePointer pointer, int index)
/*     */   {
/* 770 */     return (pointer.isActual()) && ((index == 0) || ((pointer.isCollection()) && (index >= 0) && (index < pointer.getLength())));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NodePointer valuePointer(NodePointer pointer)
/*     */   {
/* 782 */     return pointer == null ? null : pointer.getValuePointer();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NodePointer createNullPointer(EvalContext context, NodePointer parent, Step[] steps, int currentStep)
/*     */   {
/* 794 */     if (currentStep == steps.length) {
/* 795 */       return parent;
/*     */     }
/*     */     
/* 798 */     parent = valuePointer(parent);
/*     */     
/* 800 */     Step step = steps[currentStep];
/*     */     
/* 802 */     int axis = step.getAxis();
/* 803 */     if ((axis == 2) || (axis == 5)) {
/* 804 */       NullPropertyPointer pointer = new NullPropertyPointer(parent);
/* 805 */       QName name = ((NodeNameTest)step.getNodeTest()).getNodeName();
/* 806 */       pointer.setPropertyName(name.toString());
/* 807 */       pointer.setAttribute(axis == 5);
/* 808 */       parent = pointer;
/*     */     }
/*     */     
/*     */ 
/* 812 */     Expression[] predicates = step.getPredicates();
/* 813 */     return createNullPointerForPredicates(context, parent, steps, currentStep, predicates, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NodePointer createNullPointerForPredicates(EvalContext context, NodePointer parent, Step[] steps, int currentStep, Expression[] predicates, int currentPredicate)
/*     */   {
/* 830 */     for (int i = currentPredicate; i < predicates.length; i++) {
/* 831 */       Expression predicate = predicates[i];
/* 832 */       if ((predicate instanceof NameAttributeTest)) {
/* 833 */         String key = keyFromPredicate(context, predicate);
/* 834 */         parent = valuePointer(parent);
/* 835 */         NullPropertyPointer pointer = new NullPropertyPointer(parent);
/* 836 */         pointer.setNameAttributeValue(key);
/* 837 */         parent = pointer;
/*     */       }
/*     */       else {
/* 840 */         int index = indexFromPredicate(context, predicate);
/* 841 */         if ((parent instanceof NullPropertyPointer)) {
/* 842 */           parent.setIndex(index);
/*     */         }
/*     */         else {
/* 845 */           parent = new NullElementPointer(parent, index);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 850 */     return createNullPointer(context, parent, steps, currentStep + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static NodeIterator getNodeIterator(NodePointer pointer, Step step)
/*     */   {
/* 858 */     if (step.getAxis() == 2) {
/* 859 */       return pointer.childIterator(step.getNodeTest(), false, null);
/*     */     }
/*     */     
/* 862 */     if (!(step.getNodeTest() instanceof NodeNameTest)) {
/* 863 */       throw new UnsupportedOperationException("Not supported node test for attributes: " + step.getNodeTest());
/*     */     }
/*     */     
/*     */ 
/* 867 */     return pointer.attributeIterator(((NodeNameTest)step.getNodeTest()).getNodeName());
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean isLangAttribute(QName name)
/*     */   {
/* 873 */     return (name.getPrefix() != null) && (name.getPrefix().equals("xml")) && (name.getName().equals("lang"));
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/axes/SimplePathInterpreter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */