/*     */ package org.apache.commons.jxpath.ri.model.beans;
/*     */ 
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NullPropertyPointer
/*     */   extends PropertyPointer
/*     */ {
/*  75 */   private String propertyName = "*";
/*  76 */   private boolean byNameAttribute = false;
/*     */   
/*     */ 
/*     */   public NullPropertyPointer(NodePointer parent)
/*     */   {
/*  81 */     super(parent);
/*     */   }
/*     */   
/*     */   public QName getName() {
/*  85 */     return new QName(this.propertyName);
/*     */   }
/*     */   
/*     */   public void setPropertyIndex(int index) {}
/*     */   
/*     */   public int getLength()
/*     */   {
/*  92 */     return 0;
/*     */   }
/*     */   
/*     */   public Object getBaseValue() {
/*  96 */     return null;
/*     */   }
/*     */   
/*     */   public Object getImmediateNode() {
/* 100 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 104 */     return true;
/*     */   }
/*     */   
/*     */   public NodePointer getValuePointer() {
/* 108 */     return new NullPointer(this, new QName(getPropertyName()));
/*     */   }
/*     */   
/*     */   protected boolean isActualProperty() {
/* 112 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isActual() {
/* 116 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isContainer() {
/* 120 */     return true;
/*     */   }
/*     */   
/*     */   public void setValue(Object value) {
/* 124 */     if ((this.parent == null) || (this.parent.isContainer())) {
/* 125 */       throw new JXPathException("Cannot set property " + asPath() + ", the target object is null");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 131 */     throw new JXPathException("Cannot set property " + asPath() + ", path does not match a changeable location");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createPath(JXPathContext context)
/*     */   {
/* 139 */     if (isAttribute()) {
/* 140 */       return this.parent.createAttribute(context, getName());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */     NodePointer newParent = this.parent.createPath(context);
/* 158 */     if ((newParent instanceof PropertyOwnerPointer)) {
/* 159 */       PropertyOwnerPointer pop = (PropertyOwnerPointer)newParent;
/* 160 */       newParent = pop.getPropertyPointer();
/*     */     }
/* 162 */     return newParent.createChild(context, getName(), getIndex());
/*     */   }
/*     */   
/*     */   public NodePointer createPath(JXPathContext context, Object value)
/*     */   {
/* 167 */     if (isAttribute()) {
/* 168 */       NodePointer pointer = this.parent.createAttribute(context, getName());
/* 169 */       pointer.setValue(value);
/* 170 */       return pointer;
/*     */     }
/*     */     
/* 173 */     NodePointer newParent = this.parent.createPath(context);
/* 174 */     if ((newParent instanceof PropertyOwnerPointer)) {
/* 175 */       PropertyOwnerPointer pop = (PropertyOwnerPointer)newParent;
/* 176 */       newParent = pop.getPropertyPointer();
/*     */     }
/* 178 */     return newParent.createChild(context, getName(), this.index, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index)
/*     */   {
/* 187 */     return createPath(context).createChild(context, name, index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index, Object value)
/*     */   {
/* 196 */     return createPath(context).createChild(context, name, index, value);
/*     */   }
/*     */   
/*     */   public String getPropertyName() {
/* 200 */     return this.propertyName;
/*     */   }
/*     */   
/*     */   public void setPropertyName(String propertyName) {
/* 204 */     this.propertyName = propertyName;
/*     */   }
/*     */   
/*     */   public void setNameAttributeValue(String attributeValue) {
/* 208 */     this.propertyName = attributeValue;
/* 209 */     this.byNameAttribute = true;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 213 */     return getIndex() != Integer.MIN_VALUE;
/*     */   }
/*     */   
/*     */   public int getPropertyCount() {
/* 217 */     return 0;
/*     */   }
/*     */   
/*     */   public String[] getPropertyNames() {
/* 221 */     return new String[0];
/*     */   }
/*     */   
/*     */   public String asPath() {
/* 225 */     if (!this.byNameAttribute) {
/* 226 */       return super.asPath();
/*     */     }
/*     */     
/* 229 */     StringBuffer buffer = new StringBuffer();
/* 230 */     buffer.append(getParent().asPath());
/* 231 */     buffer.append("[@name='");
/* 232 */     buffer.append(escape(getPropertyName()));
/* 233 */     buffer.append("']");
/* 234 */     if (this.index != Integer.MIN_VALUE) {
/* 235 */       buffer.append('[').append(this.index + 1).append(']');
/*     */     }
/* 237 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private String escape(String string)
/*     */   {
/* 242 */     int index = string.indexOf('\'');
/* 243 */     while (index != -1) {
/* 244 */       string = string.substring(0, index) + "&apos;" + string.substring(index + 1);
/*     */       
/*     */ 
/*     */ 
/* 248 */       index = string.indexOf('\'');
/*     */     }
/* 250 */     index = string.indexOf('"');
/* 251 */     while (index != -1) {
/* 252 */       string = string.substring(0, index) + "&quot;" + string.substring(index + 1);
/*     */       
/*     */ 
/*     */ 
/* 256 */       index = string.indexOf('"');
/*     */     }
/* 258 */     return string;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/beans/NullPropertyPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */