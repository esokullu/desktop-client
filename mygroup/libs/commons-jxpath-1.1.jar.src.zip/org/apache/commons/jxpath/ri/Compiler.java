package org.apache.commons.jxpath.ri;

public abstract interface Compiler
{
  public static final int NODE_TYPE_NODE = 1;
  public static final int NODE_TYPE_TEXT = 2;
  public static final int NODE_TYPE_COMMENT = 3;
  public static final int NODE_TYPE_PI = 4;
  public static final int AXIS_SELF = 1;
  public static final int AXIS_CHILD = 2;
  public static final int AXIS_PARENT = 3;
  public static final int AXIS_ANCESTOR = 4;
  public static final int AXIS_ATTRIBUTE = 5;
  public static final int AXIS_NAMESPACE = 6;
  public static final int AXIS_PRECEDING = 7;
  public static final int AXIS_FOLLOWING = 8;
  public static final int AXIS_DESCENDANT = 9;
  public static final int AXIS_ANCESTOR_OR_SELF = 10;
  public static final int AXIS_FOLLOWING_SIBLING = 11;
  public static final int AXIS_PRECEDING_SIBLING = 12;
  public static final int AXIS_DESCENDANT_OR_SELF = 13;
  public static final int FUNCTION_LAST = 1;
  public static final int FUNCTION_POSITION = 2;
  public static final int FUNCTION_COUNT = 3;
  public static final int FUNCTION_ID = 4;
  public static final int FUNCTION_LOCAL_NAME = 5;
  public static final int FUNCTION_NAMESPACE_URI = 6;
  public static final int FUNCTION_NAME = 7;
  public static final int FUNCTION_STRING = 8;
  public static final int FUNCTION_CONCAT = 9;
  public static final int FUNCTION_STARTS_WITH = 10;
  public static final int FUNCTION_CONTAINS = 11;
  public static final int FUNCTION_SUBSTRING_BEFORE = 12;
  public static final int FUNCTION_SUBSTRING_AFTER = 13;
  public static final int FUNCTION_SUBSTRING = 14;
  public static final int FUNCTION_STRING_LENGTH = 15;
  public static final int FUNCTION_NORMALIZE_SPACE = 16;
  public static final int FUNCTION_TRANSLATE = 17;
  public static final int FUNCTION_BOOLEAN = 18;
  public static final int FUNCTION_NOT = 19;
  public static final int FUNCTION_TRUE = 20;
  public static final int FUNCTION_FALSE = 21;
  public static final int FUNCTION_LANG = 22;
  public static final int FUNCTION_NUMBER = 23;
  public static final int FUNCTION_SUM = 24;
  public static final int FUNCTION_FLOOR = 25;
  public static final int FUNCTION_CEILING = 26;
  public static final int FUNCTION_ROUND = 27;
  public static final int FUNCTION_NULL = 28;
  public static final int FUNCTION_KEY = 29;
  public static final int FUNCTION_FORMAT_NUMBER = 30;
  
  public abstract Object number(String paramString);
  
  public abstract Object literal(String paramString);
  
  public abstract Object qname(String paramString1, String paramString2);
  
  public abstract Object sum(Object[] paramArrayOfObject);
  
  public abstract Object minus(Object paramObject1, Object paramObject2);
  
  public abstract Object multiply(Object paramObject1, Object paramObject2);
  
  public abstract Object divide(Object paramObject1, Object paramObject2);
  
  public abstract Object mod(Object paramObject1, Object paramObject2);
  
  public abstract Object lessThan(Object paramObject1, Object paramObject2);
  
  public abstract Object lessThanOrEqual(Object paramObject1, Object paramObject2);
  
  public abstract Object greaterThan(Object paramObject1, Object paramObject2);
  
  public abstract Object greaterThanOrEqual(Object paramObject1, Object paramObject2);
  
  public abstract Object equal(Object paramObject1, Object paramObject2);
  
  public abstract Object notEqual(Object paramObject1, Object paramObject2);
  
  public abstract Object minus(Object paramObject);
  
  public abstract Object variableReference(Object paramObject);
  
  public abstract Object function(int paramInt, Object[] paramArrayOfObject);
  
  public abstract Object function(Object paramObject, Object[] paramArrayOfObject);
  
  public abstract Object and(Object[] paramArrayOfObject);
  
  public abstract Object or(Object[] paramArrayOfObject);
  
  public abstract Object union(Object[] paramArrayOfObject);
  
  public abstract Object nodeNameTest(Object paramObject);
  
  public abstract Object nodeTypeTest(int paramInt);
  
  public abstract Object processingInstructionTest(String paramString);
  
  public abstract Object step(int paramInt, Object paramObject, Object[] paramArrayOfObject);
  
  public abstract Object locationPath(boolean paramBoolean, Object[] paramArrayOfObject);
  
  public abstract Object expressionPath(Object paramObject, Object[] paramArrayOfObject1, Object[] paramArrayOfObject2);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/Compiler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */