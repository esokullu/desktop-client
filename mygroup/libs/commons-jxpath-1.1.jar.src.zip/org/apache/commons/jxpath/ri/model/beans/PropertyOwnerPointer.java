/*     */ package org.apache.commons.jxpath.ri.model.beans;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.util.ValueUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PropertyOwnerPointer
/*     */   extends NodePointer
/*     */ {
/*     */   public NodeIterator childIterator(NodeTest test, boolean reverse, NodePointer startWith)
/*     */   {
/*  90 */     if (test == null) {
/*  91 */       return createNodeIterator(null, reverse, startWith);
/*     */     }
/*  93 */     if ((test instanceof NodeNameTest)) {
/*  94 */       QName testName = ((NodeNameTest)test).getNodeName();
/*     */       
/*  96 */       if (!isDefaultNamespace(testName.getPrefix()))
/*  97 */         return null;
/*     */       String property;
/*  99 */       if (testName.getName().equals("*")) {
/* 100 */         property = null;
/*     */       }
/*     */       else {
/* 103 */         property = testName.getName();
/*     */       }
/* 105 */       return createNodeIterator(property, reverse, startWith);
/*     */     }
/* 107 */     if (((test instanceof NodeTypeTest)) && 
/* 108 */       (((NodeTypeTest)test).getNodeType() == 1))
/*     */     {
/* 110 */       return createNodeIterator(null, reverse, startWith);
/*     */     }
/*     */     
/* 113 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodeIterator createNodeIterator(String property, boolean reverse, NodePointer startWith)
/*     */   {
/* 121 */     return new PropertyIterator(this, property, reverse, startWith);
/*     */   }
/*     */   
/*     */   public NodeIterator attributeIterator(QName name) {
/* 125 */     return new BeanAttributeIterator(this, name);
/*     */   }
/*     */   
/*     */   protected PropertyOwnerPointer(NodePointer parent, Locale locale) {
/* 129 */     super(parent, locale);
/*     */   }
/*     */   
/*     */   protected PropertyOwnerPointer(NodePointer parent) {
/* 133 */     super(parent);
/*     */   }
/*     */   
/*     */   public void setIndex(int index) {
/* 137 */     if (this.index != index) {
/* 138 */       super.setIndex(index);
/* 139 */       this.value = UNINITIALIZED;
/*     */     }
/*     */   }
/*     */   
/* 143 */   private static final Object UNINITIALIZED = new Object();
/*     */   
/* 145 */   private Object value = UNINITIALIZED;
/*     */   
/* 147 */   public Object getImmediateNode() { if (this.value == UNINITIALIZED) {
/* 148 */       if (this.index == Integer.MIN_VALUE) {
/* 149 */         this.value = getBaseValue();
/*     */       }
/*     */       else {
/* 152 */         this.value = ValueUtils.getValue(getBaseValue(), this.index);
/*     */       }
/*     */     }
/* 155 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract QName getName();
/*     */   
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/* 165 */     this.value = value;
/* 166 */     if (this.parent.isContainer()) {
/* 167 */       this.parent.setValue(value);
/*     */     } else {
/* 169 */       if (this.parent != null) {
/* 170 */         if (this.index == Integer.MIN_VALUE) {
/* 171 */           throw new UnsupportedOperationException("Cannot setValue of an object that is not some other object's property");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 176 */         throw new JXPathException("The specified collection element does not exist: " + this);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 181 */       throw new UnsupportedOperationException("Cannot replace the root object");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void remove()
/*     */   {
/* 191 */     this.value = null;
/* 192 */     if (this.parent != null) {
/* 193 */       this.parent.remove();
/*     */     }
/*     */     else {
/* 196 */       throw new UnsupportedOperationException("Cannot remove an object that is not some other object's property or a collection element");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract PropertyPointer getPropertyPointer();
/*     */   
/*     */ 
/*     */ 
/*     */   public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2)
/*     */   {
/* 208 */     int r = pointer1.getName().toString().compareTo(pointer2.getName().toString());
/*     */     
/*     */ 
/* 211 */     if (r != 0) {
/* 212 */       return r;
/*     */     }
/* 214 */     return pointer1.getIndex() - pointer2.getIndex();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/beans/PropertyOwnerPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */