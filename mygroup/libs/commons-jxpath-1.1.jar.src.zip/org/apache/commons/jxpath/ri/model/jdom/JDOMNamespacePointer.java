/*     */ package org.apache.commons.jxpath.ri.model.jdom;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDOMNamespacePointer
/*     */   extends NodePointer
/*     */ {
/*     */   private String prefix;
/*     */   private String namespaceURI;
/*     */   
/*     */   public JDOMNamespacePointer(NodePointer parent, String prefix)
/*     */   {
/*  78 */     super(parent);
/*  79 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JDOMNamespacePointer(NodePointer parent, String prefix, String namespaceURI)
/*     */   {
/*  87 */     super(parent);
/*  88 */     this.prefix = prefix;
/*  89 */     this.namespaceURI = namespaceURI;
/*     */   }
/*     */   
/*     */   public QName getName() {
/*  93 */     return new QName(getNamespaceURI(), this.prefix);
/*     */   }
/*     */   
/*     */   public Object getBaseValue() {
/*  97 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 101 */     return false;
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 105 */     return 1;
/*     */   }
/*     */   
/*     */   public Object getImmediateNode() {
/* 109 */     return getNamespaceURI();
/*     */   }
/*     */   
/*     */   public String getNamespaceURI() {
/* 113 */     if (this.namespaceURI == null) {
/* 114 */       this.namespaceURI = this.parent.getNamespaceURI(this.prefix);
/*     */     }
/* 116 */     return this.namespaceURI;
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 120 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/* 127 */     throw new UnsupportedOperationException("Cannot modify a namespace");
/*     */   }
/*     */   
/*     */   public String asPath() {
/* 131 */     StringBuffer buffer = new StringBuffer();
/* 132 */     if (this.parent != null) {
/* 133 */       buffer.append(this.parent.asPath());
/* 134 */       if ((buffer.length() == 0) || (buffer.charAt(buffer.length() - 1) != '/'))
/*     */       {
/* 136 */         buffer.append('/');
/*     */       }
/*     */     }
/* 139 */     buffer.append("namespace::");
/* 140 */     buffer.append(this.prefix);
/* 141 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 145 */     return this.prefix.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 149 */     if (object == this) {
/* 150 */       return true;
/*     */     }
/*     */     
/* 153 */     if (!(object instanceof JDOMNamespacePointer)) {
/* 154 */       return false;
/*     */     }
/*     */     
/* 157 */     JDOMNamespacePointer other = (JDOMNamespacePointer)object;
/* 158 */     return this.prefix.equals(other.prefix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2)
/*     */   {
/* 166 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/jdom/JDOMNamespacePointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */