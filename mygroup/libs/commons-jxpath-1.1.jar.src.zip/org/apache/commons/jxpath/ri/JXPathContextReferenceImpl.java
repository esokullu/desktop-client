/*     */ package org.apache.commons.jxpath.ri;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.jxpath.CompiledExpression;
/*     */ import org.apache.commons.jxpath.Function;
/*     */ import org.apache.commons.jxpath.Functions;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.PackageFunctions;
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ import org.apache.commons.jxpath.Variables;
/*     */ import org.apache.commons.jxpath.ri.axes.InitialContext;
/*     */ import org.apache.commons.jxpath.ri.axes.RootContext;
/*     */ import org.apache.commons.jxpath.ri.compiler.Expression;
/*     */ import org.apache.commons.jxpath.ri.compiler.LocationPath;
/*     */ import org.apache.commons.jxpath.ri.compiler.Path;
/*     */ import org.apache.commons.jxpath.ri.compiler.TreeCompiler;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointerFactory;
/*     */ import org.apache.commons.jxpath.ri.model.VariablePointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.BeanPointerFactory;
/*     */ import org.apache.commons.jxpath.ri.model.beans.CollectionPointerFactory;
/*     */ import org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory;
/*     */ import org.apache.commons.jxpath.ri.model.dynamic.DynamicPointerFactory;
/*     */ import org.apache.commons.jxpath.util.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JXPathContextReferenceImpl
/*     */   extends JXPathContext
/*     */ {
/*     */   public static final boolean USE_SOFT_CACHE = true;
/* 110 */   private static final Compiler COMPILER = new TreeCompiler();
/* 111 */   private static Map compiled = new HashMap();
/* 112 */   private static final PackageFunctions GENERIC_FUNCTIONS = new PackageFunctions("", null);
/*     */   
/* 114 */   private static int cleanupCount = 0;
/*     */   
/* 116 */   private static Vector nodeFactories = new Vector();
/* 117 */   private static NodePointerFactory[] nodeFactoryArray = null;
/*     */   
/* 119 */   static { nodeFactories.add(new CollectionPointerFactory());
/* 120 */     nodeFactories.add(new BeanPointerFactory());
/* 121 */     nodeFactories.add(new DynamicPointerFactory());
/*     */     
/*     */ 
/* 124 */     Object domFactory = allocateConditionally("org.apache.commons.jxpath.ri.model.dom.DOMPointerFactory", "org.w3c.dom.Node");
/*     */     
/*     */ 
/* 127 */     if (domFactory != null) {
/* 128 */       nodeFactories.add(domFactory);
/*     */     }
/*     */     
/*     */ 
/* 132 */     Object jdomFactory = allocateConditionally("org.apache.commons.jxpath.ri.model.jdom.JDOMPointerFactory", "org.jdom.Document");
/*     */     
/*     */ 
/* 135 */     if (jdomFactory != null) {
/* 136 */       nodeFactories.add(jdomFactory);
/*     */     }
/*     */     
/*     */ 
/* 140 */     Object dynaBeanFactory = allocateConditionally("org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointerFactory", "org.apache.commons.beanutils.DynaBean");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 145 */     if (dynaBeanFactory != null) {
/* 146 */       nodeFactories.add(dynaBeanFactory);
/*     */     }
/*     */     
/* 149 */     nodeFactories.add(new ContainerPointerFactory());
/* 150 */     createNodeFactoryArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Pointer rootPointer;
/*     */   
/*     */ 
/*     */ 
/*     */   protected JXPathContextReferenceImpl(JXPathContext parentContext, Object contextBean)
/*     */   {
/* 162 */     this(parentContext, contextBean, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JXPathContextReferenceImpl(JXPathContext parentContext, Object contextBean, Pointer contextPointer)
/*     */   {
/* 170 */     super(parentContext, contextBean);
/*     */     
/* 172 */     synchronized (nodeFactories) {
/* 173 */       createNodeFactoryArray();
/*     */     }
/*     */     
/* 176 */     if (contextPointer != null) {
/* 177 */       this.contextPointer = contextPointer;
/* 178 */       this.rootPointer = NodePointer.newNodePointer(new QName(null, "root"), contextPointer.getRootNode(), getLocale());
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 185 */       this.contextPointer = NodePointer.newNodePointer(new QName(null, "root"), contextBean, getLocale());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 190 */       this.rootPointer = this.contextPointer;
/*     */     }
/*     */   }
/*     */   
/*     */   private static void createNodeFactoryArray() {
/* 195 */     if (nodeFactoryArray == null) {
/* 196 */       nodeFactoryArray = (NodePointerFactory[])nodeFactories.toArray(new NodePointerFactory[0]);
/*     */       
/*     */ 
/* 199 */       Arrays.sort(nodeFactoryArray, new Comparator() {
/*     */         public int compare(Object a, Object b) {
/* 201 */           int orderA = ((NodePointerFactory)a).getOrder();
/* 202 */           int orderB = ((NodePointerFactory)b).getOrder();
/* 203 */           return orderA - orderB;
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addNodePointerFactory(NodePointerFactory factory)
/*     */   {
/* 215 */     synchronized (nodeFactories) {
/* 216 */       nodeFactories.add(factory);
/* 217 */       nodeFactoryArray = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static NodePointerFactory[] getNodePointerFactories() {
/* 222 */     return nodeFactoryArray;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Compiler getCompiler()
/*     */   {
/* 231 */     return COMPILER;
/*     */   }
/*     */   
/*     */   protected CompiledExpression compilePath(String xpath)
/*     */   {
/* 236 */     return new JXPathCompiledExpression(xpath, compileExpression(xpath));
/*     */   }
/*     */   
/*     */ 
/*     */   private Expression compileExpression(String xpath)
/*     */   {
/* 242 */     Expression expr = null;
/* 243 */     SoftReference ref = (SoftReference)compiled.get(xpath);
/* 244 */     if (ref != null) {
/* 245 */       expr = (Expression)ref.get();
/*     */     }
/* 247 */     if (expr == null) {
/* 248 */       expr = (Expression)Parser.parseExpression(xpath, getCompiler());
/*     */       
/* 250 */       compiled.put(xpath, new SoftReference(expr));
/* 251 */       if (cleanupCount++ >= 500) {
/* 252 */         cleanupCache();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 264 */     return expr;
/*     */   }
/*     */   
/*     */   private static void cleanupCache() {
/* 268 */     Iterator it = compiled.entrySet().iterator();
/* 269 */     while (it.hasNext()) {
/* 270 */       Map.Entry me = (Map.Entry)it.next();
/* 271 */       if (((SoftReference)me.getValue()).get() == null) {
/* 272 */         it.remove();
/*     */       }
/*     */     }
/* 275 */     cleanupCount = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValue(String xpath)
/*     */   {
/* 283 */     return getValue(xpath, compileExpression(xpath));
/*     */   }
/*     */   
/*     */   public Object getValue(String xpath, Expression expr) {
/* 287 */     Object result = expr.computeValue(getEvalContext());
/* 288 */     if ((result instanceof EvalContext)) {
/* 289 */       EvalContext ctx = (EvalContext)result;
/* 290 */       result = ctx.getSingleNodePointer();
/* 291 */       if ((!this.lenient) && (result == null)) {
/* 292 */         throw new JXPathException("No value for xpath: " + xpath);
/*     */       }
/*     */     }
/* 295 */     if ((result instanceof NodePointer)) {
/* 296 */       result = ((NodePointer)result).getValuePointer();
/* 297 */       if ((!this.lenient) && (!((NodePointer)result).isActual()))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 304 */         NodePointer parent = ((NodePointer)result).getParent();
/* 305 */         if ((parent == null) || (!parent.isContainer()) || (!parent.isActual()))
/*     */         {
/*     */ 
/* 308 */           throw new JXPathException("No value for xpath: " + xpath);
/*     */         }
/*     */       }
/* 311 */       result = ((NodePointer)result).getValue();
/*     */     }
/* 313 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValue(String xpath, Class requiredType)
/*     */   {
/* 321 */     Expression expr = compileExpression(xpath);
/* 322 */     return getValue(xpath, expr, requiredType);
/*     */   }
/*     */   
/*     */   public Object getValue(String xpath, Expression expr, Class requiredType) {
/* 326 */     Object value = getValue(xpath, expr);
/* 327 */     if ((value != null) && (requiredType != null)) {
/* 328 */       if (!TypeUtils.canConvert(value, requiredType)) {
/* 329 */         throw new JXPathException("Invalid expression type. '" + xpath + "' returns " + value.getClass().getName() + ". It cannot be converted to " + requiredType.getName());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 337 */       value = TypeUtils.convert(value, requiredType);
/*     */     }
/* 339 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator iterate(String xpath)
/*     */   {
/* 348 */     return iterate(xpath, compileExpression(xpath));
/*     */   }
/*     */   
/*     */   public Iterator iterate(String xpath, Expression expr) {
/* 352 */     return expr.iterate(getEvalContext());
/*     */   }
/*     */   
/*     */   public Pointer getPointer(String xpath) {
/* 356 */     return getPointer(xpath, compileExpression(xpath));
/*     */   }
/*     */   
/*     */   public Pointer getPointer(String xpath, Expression expr) {
/* 360 */     Object result = expr.computeValue(getEvalContext());
/* 361 */     if ((result instanceof EvalContext)) {
/* 362 */       result = ((EvalContext)result).getSingleNodePointer();
/*     */     }
/* 364 */     if ((result instanceof Pointer)) {
/* 365 */       if ((!this.lenient) && (!((NodePointer)result).isActual())) {
/* 366 */         throw new JXPathException("No pointer for xpath: " + xpath);
/*     */       }
/* 368 */       return (Pointer)result;
/*     */     }
/*     */     
/* 371 */     return NodePointer.newNodePointer(null, result, getLocale());
/*     */   }
/*     */   
/*     */   public void setValue(String xpath, Object value)
/*     */   {
/* 376 */     setValue(xpath, compileExpression(xpath), value);
/*     */   }
/*     */   
/*     */   public void setValue(String xpath, Expression expr, Object value)
/*     */   {
/*     */     try {
/* 382 */       setValue(xpath, expr, value, false);
/*     */     }
/*     */     catch (Throwable ex) {
/* 385 */       throw new JXPathException("Exception trying to set value with xpath " + xpath, ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public Pointer createPath(String xpath)
/*     */   {
/* 391 */     return createPath(xpath, compileExpression(xpath));
/*     */   }
/*     */   
/*     */   public Pointer createPath(String xpath, Expression expr) {
/*     */     try {
/* 396 */       Object result = expr.computeValue(getEvalContext());
/* 397 */       Pointer pointer = null;
/*     */       
/* 399 */       if ((result instanceof Pointer)) {
/* 400 */         pointer = (Pointer)result;
/*     */       }
/* 402 */       else if ((result instanceof EvalContext)) {
/* 403 */         EvalContext ctx = (EvalContext)result;
/* 404 */         pointer = ctx.getSingleNodePointer();
/*     */       }
/*     */       else {
/* 407 */         checkSimplePath(expr);
/*     */         
/* 409 */         throw new JXPathException("Cannot create path:" + xpath);
/*     */       }
/* 411 */       return ((NodePointer)pointer).createPath(this);
/*     */     }
/*     */     catch (Throwable ex) {
/* 414 */       throw new JXPathException("Exception trying to create xpath " + xpath, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Pointer createPathAndSetValue(String xpath, Object value)
/*     */   {
/* 421 */     return createPathAndSetValue(xpath, compileExpression(xpath), value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Pointer createPathAndSetValue(String xpath, Expression expr, Object value)
/*     */   {
/*     */     try
/*     */     {
/* 430 */       return setValue(xpath, expr, value, true);
/*     */     }
/*     */     catch (Throwable ex) {
/* 433 */       throw new JXPathException("Exception trying to create xpath " + xpath, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Pointer setValue(String xpath, Expression expr, Object value, boolean create)
/*     */   {
/* 445 */     Object result = expr.computeValue(getEvalContext());
/* 446 */     Pointer pointer = null;
/*     */     
/* 448 */     if ((result instanceof Pointer)) {
/* 449 */       pointer = (Pointer)result;
/*     */     }
/* 451 */     else if ((result instanceof EvalContext)) {
/* 452 */       EvalContext ctx = (EvalContext)result;
/* 453 */       pointer = ctx.getSingleNodePointer();
/*     */     }
/*     */     else {
/* 456 */       if (create) {
/* 457 */         checkSimplePath(expr);
/*     */       }
/*     */       
/*     */ 
/* 461 */       throw new JXPathException("Cannot set value for xpath: " + xpath);
/*     */     }
/* 463 */     if (create) {
/* 464 */       pointer = ((NodePointer)pointer).createPath(this, value);
/*     */     }
/*     */     else {
/* 467 */       pointer.setValue(value);
/*     */     }
/* 469 */     return pointer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkSimplePath(Expression expr)
/*     */   {
/* 477 */     if ((!(expr instanceof LocationPath)) || (!((LocationPath)expr).isSimplePath()))
/*     */     {
/* 479 */       throw new JXPathException("JXPath can only create a path if it uses exclusively the child:: and attribute:: axes and has no context-dependent predicates");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Pointer contextPointer;
/*     */   
/*     */ 
/*     */   private static final int CLEANUP_THRESHOLD = 500;
/*     */   
/*     */ 
/*     */   public Iterator iteratePointers(String xpath)
/*     */   {
/* 493 */     return iteratePointers(xpath, compileExpression(xpath));
/*     */   }
/*     */   
/*     */   public Iterator iteratePointers(String xpath, Expression expr) {
/* 497 */     return expr.iteratePointers(getEvalContext());
/*     */   }
/*     */   
/*     */   public void removePath(String xpath) {
/* 501 */     removePath(xpath, compileExpression(xpath));
/*     */   }
/*     */   
/*     */   public void removePath(String xpath, Expression expr) {
/*     */     try {
/* 506 */       NodePointer pointer = (NodePointer)getPointer(xpath, expr);
/* 507 */       if (pointer != null) {
/* 508 */         pointer.remove();
/*     */       }
/*     */     }
/*     */     catch (Throwable ex) {
/* 512 */       throw new JXPathException("Exception trying to remove xpath " + xpath, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeAll(String xpath)
/*     */   {
/* 519 */     removeAll(xpath, compileExpression(xpath));
/*     */   }
/*     */   
/*     */   public void removeAll(String xpath, Expression expr) {
/*     */     try {
/* 524 */       ArrayList list = new ArrayList();
/* 525 */       Iterator it = expr.iteratePointers(getEvalContext());
/* 526 */       while (it.hasNext()) {
/* 527 */         list.add(it.next());
/*     */       }
/* 529 */       Collections.sort(list);
/* 530 */       for (int i = list.size() - 1; i >= 0; i--) {
/* 531 */         NodePointer pointer = (NodePointer)list.get(i);
/* 532 */         pointer.remove();
/*     */       }
/*     */     }
/*     */     catch (Throwable ex) {
/* 536 */       throw new JXPathException("Exception trying to remove all for xpath " + xpath, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public JXPathContext getRelativeContext(Pointer pointer)
/*     */   {
/* 543 */     Object contextBean = pointer.getNode();
/* 544 */     if (contextBean == null) {
/* 545 */       throw new JXPathException("Cannot create a relative context for a non-existent node: " + pointer);
/*     */     }
/*     */     
/*     */ 
/* 549 */     return new JXPathContextReferenceImpl(this, contextBean, pointer);
/*     */   }
/*     */   
/*     */   public synchronized Pointer getContextPointer() {
/* 553 */     return (Pointer)this.contextPointer.clone();
/*     */   }
/*     */   
/*     */   private synchronized NodePointer getAbsoluteRootPointer() {
/* 557 */     return (NodePointer)this.rootPointer.clone();
/*     */   }
/*     */   
/*     */   private EvalContext getEvalContext() {
/* 561 */     return new InitialContext(new RootContext(this, (NodePointer)getContextPointer()));
/*     */   }
/*     */   
/*     */   public EvalContext getAbsoluteRootContext()
/*     */   {
/* 566 */     return new InitialContext(new RootContext(this, getAbsoluteRootPointer()));
/*     */   }
/*     */   
/*     */   public NodePointer getVariablePointer(QName name)
/*     */   {
/* 571 */     String varName = name.toString();
/* 572 */     JXPathContext varCtx = this;
/* 573 */     Variables vars = null;
/* 574 */     while (varCtx != null) {
/* 575 */       vars = varCtx.getVariables();
/* 576 */       if (vars.isDeclaredVariable(varName)) {
/*     */         break;
/*     */       }
/* 579 */       varCtx = varCtx.getParentContext();
/* 580 */       vars = null;
/*     */     }
/* 582 */     if (vars != null) {
/* 583 */       return new VariablePointer(vars, name);
/*     */     }
/*     */     
/* 586 */     return new VariablePointer(name);
/*     */   }
/*     */   
/*     */   public Function getFunction(QName functionName, Object[] parameters)
/*     */   {
/* 591 */     String namespace = functionName.getPrefix();
/* 592 */     String name = functionName.getName();
/* 593 */     JXPathContext funcCtx = this;
/* 594 */     Function func = null;
/*     */     
/* 596 */     while (funcCtx != null) {
/* 597 */       Functions funcs = funcCtx.getFunctions();
/* 598 */       if (funcs == null) break;
/* 599 */       func = funcs.getFunction(namespace, name, parameters);
/* 600 */       if (func != null) {
/* 601 */         return func;
/*     */       }
/*     */       
/* 604 */       funcCtx = funcCtx.getParentContext();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 610 */     func = GENERIC_FUNCTIONS.getFunction(namespace, name, parameters);
/* 611 */     if (func != null) {
/* 612 */       return func;
/*     */     }
/* 614 */     throw new JXPathException("Undefined function: " + functionName.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object allocateConditionally(String className, String existenceCheckClassName)
/*     */   {
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/* 629 */         Class.forName(existenceCheckClassName);
/*     */       }
/*     */       catch (ClassNotFoundException ex) {
/* 632 */         return null;
/*     */       }
/*     */       
/* 635 */       Class cls = Class.forName(className);
/* 636 */       return cls.newInstance();
/*     */     }
/*     */     catch (Exception ex) {
/* 639 */       throw new JXPathException("Cannot allocate " + className, ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/JXPathContextReferenceImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */