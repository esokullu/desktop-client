/*     */ package org.apache.commons.jxpath.ri.compiler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Step
/*     */ {
/*     */   private int axis;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private NodeTest nodeTest;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Expression[] predicates;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Step(int axis, NodeTest nodeTest, Expression[] predicates)
/*     */   {
/*  76 */     this.axis = axis;
/*  77 */     this.nodeTest = nodeTest;
/*  78 */     this.predicates = predicates;
/*     */   }
/*     */   
/*     */   public int getAxis() {
/*  82 */     return this.axis;
/*     */   }
/*     */   
/*     */   public NodeTest getNodeTest() {
/*  86 */     return this.nodeTest;
/*     */   }
/*     */   
/*     */   public Expression[] getPredicates() {
/*  90 */     return this.predicates;
/*     */   }
/*     */   
/*     */   public boolean isContextDependent() {
/*  94 */     if (this.predicates != null) {
/*  95 */       for (int i = 0; i < this.predicates.length; i++) {
/*  96 */         if (this.predicates[i].isContextDependent()) {
/*  97 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 101 */     return false;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 105 */     StringBuffer buffer = new StringBuffer();
/* 106 */     int axis = getAxis();
/* 107 */     if (axis == 2) {
/* 108 */       buffer.append(this.nodeTest);
/*     */     }
/* 110 */     else if (axis == 5) {
/* 111 */       buffer.append('@');
/* 112 */       buffer.append(this.nodeTest);
/*     */     }
/* 114 */     else if ((axis == 1) && ((this.nodeTest instanceof NodeTypeTest)) && (((NodeTypeTest)this.nodeTest).getNodeType() == 1))
/*     */     {
/*     */ 
/*     */ 
/* 118 */       buffer.append(".");
/*     */     }
/* 120 */     else if ((axis == 3) && ((this.nodeTest instanceof NodeTypeTest)) && (((NodeTypeTest)this.nodeTest).getNodeType() == 1))
/*     */     {
/*     */ 
/*     */ 
/* 124 */       buffer.append("..");
/*     */     }
/* 126 */     else if ((axis == 13) && ((this.nodeTest instanceof NodeTypeTest)) && (((NodeTypeTest)this.nodeTest).getNodeType() == 1) && ((this.predicates == null) || (this.predicates.length == 0)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 131 */       buffer.append("");
/*     */     }
/*     */     else {
/* 134 */       buffer.append(axisToString(axis));
/* 135 */       buffer.append("::");
/* 136 */       buffer.append(this.nodeTest);
/*     */     }
/* 138 */     Expression[] predicates = getPredicates();
/* 139 */     if (predicates != null) {
/* 140 */       for (int i = 0; i < predicates.length; i++) {
/* 141 */         buffer.append('[');
/* 142 */         buffer.append(predicates[i]);
/* 143 */         buffer.append(']');
/*     */       }
/*     */     }
/* 146 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public static String axisToString(int axis) {
/* 150 */     switch (axis) {
/*     */     case 1: 
/* 152 */       return "self";
/*     */     case 2: 
/* 154 */       return "child";
/*     */     case 3: 
/* 156 */       return "parent";
/*     */     case 4: 
/* 158 */       return "ancestor";
/*     */     case 5: 
/* 160 */       return "attribute";
/*     */     case 6: 
/* 162 */       return "namespace";
/*     */     case 7: 
/* 164 */       return "preceding";
/*     */     case 8: 
/* 166 */       return "following";
/*     */     case 9: 
/* 168 */       return "descendant";
/*     */     case 10: 
/* 170 */       return "ancestor-or-self";
/*     */     case 11: 
/* 172 */       return "following-sibling";
/*     */     case 12: 
/* 174 */       return "preceding-sibling";
/*     */     case 13: 
/* 176 */       return "descendant-or-self";
/*     */     }
/* 178 */     return "UNKNOWN";
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/Step.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */