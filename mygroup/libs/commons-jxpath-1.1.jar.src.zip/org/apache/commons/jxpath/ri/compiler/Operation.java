/*    */ package org.apache.commons.jxpath.ri.compiler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Operation
/*    */   extends Expression
/*    */ {
/*    */   protected Expression[] args;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Operation(Expression[] args)
/*    */   {
/* 73 */     this.args = args;
/*    */   }
/*    */   
/*    */   public Expression[] getArguments() {
/* 77 */     return this.args;
/*    */   }
/*    */   
/*    */   public boolean computeContextDependent() {
/* 81 */     if (this.args != null) {
/* 82 */       for (int i = 0; i < this.args.length; i++) {
/* 83 */         if (this.args[i].isContextDependent()) {
/* 84 */           return true;
/*    */         }
/*    */       }
/*    */     }
/* 88 */     return false;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/Operation.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */