/*     */ package org.apache.commons.jxpath.ri.model.beans;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.JXPathBeanInfo;
/*     */ import org.apache.commons.jxpath.JXPathIntrospector;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanPointer
/*     */   extends PropertyOwnerPointer
/*     */ {
/*     */   private QName name;
/*     */   private Object bean;
/*     */   private JXPathBeanInfo beanInfo;
/*     */   
/*     */   public BeanPointer(QName name, Object bean, JXPathBeanInfo beanInfo, Locale locale)
/*     */   {
/*  91 */     super(null, locale);
/*  92 */     this.name = name;
/*  93 */     this.bean = bean;
/*  94 */     this.beanInfo = beanInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BeanPointer(NodePointer parent, QName name, Object bean, JXPathBeanInfo beanInfo)
/*     */   {
/* 106 */     super(parent);
/* 107 */     this.name = name;
/* 108 */     this.bean = bean;
/* 109 */     this.beanInfo = beanInfo;
/*     */   }
/*     */   
/*     */   public PropertyPointer getPropertyPointer() {
/* 113 */     return new BeanPropertyPointer(this, this.beanInfo);
/*     */   }
/*     */   
/*     */   public QName getName() {
/* 117 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getBaseValue()
/*     */   {
/* 124 */     return this.bean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isCollection()
/*     */   {
/* 131 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 138 */     return 1;
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 142 */     Object value = getNode();
/* 143 */     return (value == null) || (JXPathIntrospector.getBeanInfo(value.getClass()).isAtomic());
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 148 */     return this.name == null ? 0 : this.name.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 152 */     if (object == this) {
/* 153 */       return true;
/*     */     }
/*     */     
/* 156 */     if (!(object instanceof BeanPointer)) {
/* 157 */       return false;
/*     */     }
/*     */     
/* 160 */     BeanPointer other = (BeanPointer)object;
/* 161 */     if ((this.parent != other.parent) && (
/* 162 */       (this.parent == null) || (!this.parent.equals(other.parent)))) {
/* 163 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 167 */     if (((this.name == null) && (other.name != null)) || ((this.name != null) && (!this.name.equals(other.name))))
/*     */     {
/* 169 */       return false;
/*     */     }
/*     */     
/* 172 */     int iThis = this.index == Integer.MIN_VALUE ? 0 : this.index;
/* 173 */     int iOther = other.index == Integer.MIN_VALUE ? 0 : other.index;
/* 174 */     if (iThis != iOther) {
/* 175 */       return false;
/*     */     }
/*     */     
/* 178 */     if (((this.bean instanceof Number)) || ((this.bean instanceof String)) || ((this.bean instanceof Boolean)))
/*     */     {
/*     */ 
/* 181 */       return this.bean.equals(other.bean);
/*     */     }
/* 183 */     return this.bean == other.bean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String asPath()
/*     */   {
/* 193 */     if (this.parent != null) {
/* 194 */       return super.asPath();
/*     */     }
/* 196 */     if (this.bean == null) {
/* 197 */       return "null()";
/*     */     }
/* 199 */     if ((this.bean instanceof Number)) {
/* 200 */       String string = this.bean.toString();
/* 201 */       if (string.endsWith(".0")) {
/* 202 */         string = string.substring(0, string.length() - 2);
/*     */       }
/* 204 */       return string;
/*     */     }
/* 206 */     if ((this.bean instanceof Boolean)) {
/* 207 */       return ((Boolean)this.bean).booleanValue() ? "true()" : "false()";
/*     */     }
/* 209 */     if ((this.bean instanceof String)) {
/* 210 */       return "'" + this.bean + "'";
/*     */     }
/* 212 */     return "/";
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/beans/BeanPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */