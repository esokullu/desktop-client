/*     */ package org.apache.commons.jxpath.ri.axes;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamespaceContext
/*     */   extends EvalContext
/*     */ {
/*     */   private NodeTest nodeTest;
/*  79 */   private boolean setStarted = false;
/*     */   
/*     */   private NodeIterator iterator;
/*     */   
/*     */   private NodePointer currentNodePointer;
/*     */   
/*     */ 
/*     */   public NamespaceContext(EvalContext parentContext, NodeTest nodeTest)
/*     */   {
/*  88 */     super(parentContext);
/*  89 */     this.nodeTest = nodeTest;
/*     */   }
/*     */   
/*     */   public NodePointer getCurrentNodePointer() {
/*  93 */     return this.currentNodePointer;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  97 */     this.setStarted = false;
/*  98 */     this.iterator = null;
/*  99 */     super.reset();
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 103 */     if (position < getCurrentPosition()) {
/* 104 */       reset();
/*     */     }
/*     */     
/* 107 */     while (getCurrentPosition() < position) {
/* 108 */       if (!nextNode()) {
/* 109 */         return false;
/*     */       }
/*     */     }
/* 112 */     return true;
/*     */   }
/*     */   
/*     */   public boolean nextNode() {
/* 116 */     super.setPosition(getCurrentPosition() + 1);
/* 117 */     if (!this.setStarted) {
/* 118 */       this.setStarted = true;
/* 119 */       if (!(this.nodeTest instanceof NodeNameTest)) {
/* 120 */         return false;
/*     */       }
/*     */       
/* 123 */       QName testName = ((NodeNameTest)this.nodeTest).getNodeName();
/* 124 */       if (testName.getPrefix() != null) {
/* 125 */         return false;
/*     */       }
/* 127 */       String testLocalName = testName.getName();
/* 128 */       if (testLocalName.equals("*")) {
/* 129 */         this.iterator = this.parentContext.getCurrentNodePointer().namespaceIterator();
/*     */       }
/*     */       else
/*     */       {
/* 133 */         this.currentNodePointer = this.parentContext.getCurrentNodePointer().namespacePointer(testLocalName);
/*     */         
/*     */ 
/* 136 */         return this.currentNodePointer != null;
/*     */       }
/*     */     }
/*     */     
/* 140 */     if (this.iterator == null) {
/* 141 */       return false;
/*     */     }
/* 143 */     if (!this.iterator.setPosition(this.iterator.getPosition() + 1)) {
/* 144 */       return false;
/*     */     }
/* 146 */     this.currentNodePointer = this.iterator.getNodePointer();
/* 147 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/axes/NamespaceContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */