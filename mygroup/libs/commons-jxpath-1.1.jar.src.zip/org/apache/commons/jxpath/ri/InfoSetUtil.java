/*     */ package org.apache.commons.jxpath.ri;
/*     */ 
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InfoSetUtil
/*     */ {
/*  75 */   private static final Double ZERO = new Double(0.0D);
/*  76 */   private static final Double ONE = new Double(1.0D);
/*  77 */   private static final Double NOT_A_NUMBER = new Double(NaN.0D);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String stringValue(Object object)
/*     */   {
/*  84 */     if ((object instanceof String)) {
/*  85 */       return (String)object;
/*     */     }
/*  87 */     if ((object instanceof Number)) {
/*  88 */       double d = ((Number)object).doubleValue();
/*  89 */       long l = ((Number)object).longValue();
/*  90 */       if (d == l) {
/*  91 */         return String.valueOf(l);
/*     */       }
/*  93 */       return String.valueOf(d);
/*     */     }
/*  95 */     if ((object instanceof Boolean)) {
/*  96 */       return ((Boolean)object).booleanValue() ? "true" : "false";
/*     */     }
/*  98 */     if (object == null) {
/*  99 */       return "";
/*     */     }
/* 101 */     if ((object instanceof NodePointer)) {
/* 102 */       return stringValue(((NodePointer)object).getValue());
/*     */     }
/* 104 */     if ((object instanceof EvalContext)) {
/* 105 */       EvalContext ctx = (EvalContext)object;
/* 106 */       Pointer ptr = ctx.getSingleNodePointer();
/* 107 */       if (ptr != null) {
/* 108 */         return stringValue(ptr);
/*     */       }
/* 110 */       return "";
/*     */     }
/* 112 */     return String.valueOf(object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Number number(Object object)
/*     */   {
/* 119 */     if ((object instanceof Number)) {
/* 120 */       return (Number)object;
/*     */     }
/* 122 */     if ((object instanceof Boolean)) {
/* 123 */       return ((Boolean)object).booleanValue() ? ONE : ZERO;
/*     */     }
/* 125 */     if ((object instanceof String)) {
/*     */       Double value;
/*     */       try {
/* 128 */         value = new Double((String)object);
/*     */       }
/*     */       catch (NumberFormatException ex) {
/* 131 */         value = NOT_A_NUMBER;
/*     */       }
/* 133 */       return value;
/*     */     }
/* 135 */     if ((object instanceof EvalContext)) {
/* 136 */       return number(stringValue(object));
/*     */     }
/* 138 */     if ((object instanceof NodePointer)) {
/* 139 */       return number(((NodePointer)object).getValue());
/*     */     }
/* 141 */     return number(stringValue(object));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static double doubleValue(Object object)
/*     */   {
/* 148 */     if ((object instanceof Number)) {
/* 149 */       return ((Number)object).doubleValue();
/*     */     }
/* 151 */     if ((object instanceof Boolean)) {
/* 152 */       return ((Boolean)object).booleanValue() ? 0.0D : 1.0D;
/*     */     }
/* 154 */     if ((object instanceof String)) {
/* 155 */       if (object.equals("")) {
/* 156 */         return 0.0D;
/*     */       }
/*     */       double value;
/*     */       try
/*     */       {
/* 161 */         value = Double.parseDouble((String)object);
/*     */       }
/*     */       catch (NumberFormatException ex) {
/* 164 */         value = NaN.0D;
/*     */       }
/* 166 */       return value;
/*     */     }
/* 168 */     if ((object instanceof NodePointer)) {
/* 169 */       return doubleValue(((NodePointer)object).getValue());
/*     */     }
/* 171 */     if ((object instanceof EvalContext)) {
/* 172 */       return doubleValue(stringValue(object));
/*     */     }
/* 174 */     return doubleValue(stringValue(object));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean booleanValue(Object object)
/*     */   {
/* 181 */     if ((object instanceof Number)) {
/* 182 */       double value = ((Number)object).doubleValue();
/* 183 */       return (value != 0.0D) && (value != 0.0D) && (!Double.isNaN(value));
/*     */     }
/* 185 */     if ((object instanceof Boolean)) {
/* 186 */       return ((Boolean)object).booleanValue();
/*     */     }
/* 188 */     if ((object instanceof EvalContext)) {
/* 189 */       EvalContext ctx = (EvalContext)object;
/* 190 */       return (ctx.nextSet()) && (ctx.nextNode());
/*     */     }
/* 192 */     if ((object instanceof String)) {
/* 193 */       return ((String)object).length() != 0;
/*     */     }
/* 195 */     if ((object instanceof NodePointer)) {
/* 196 */       return ((NodePointer)object).isActual();
/*     */     }
/* 198 */     if (object == null) {
/* 199 */       return false;
/*     */     }
/* 201 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/InfoSetUtil.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */