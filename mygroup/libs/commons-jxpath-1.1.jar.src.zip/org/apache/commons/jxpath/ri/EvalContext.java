/*     */ package org.apache.commons.jxpath.ri;
/*     */ 
/*     */ import java.util.AbstractList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.apache.commons.jxpath.ExpressionContext;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.NodeSet;
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ import org.apache.commons.jxpath.ri.axes.RootContext;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EvalContext
/*     */   implements ExpressionContext, Iterator
/*     */ {
/*     */   protected EvalContext parentContext;
/*     */   protected RootContext rootContext;
/*  93 */   protected int position = 0;
/*  94 */   private boolean startedSetIteration = false;
/*  95 */   private boolean done = false;
/*  96 */   private boolean hasPerformedIteratorStep = false;
/*     */   
/*     */ 
/*     */   private Iterator pointerIterator;
/*     */   
/* 101 */   private static final Comparator REVERSE_COMPARATOR = new Comparator() {
/*     */     public int compare(Object o1, Object o2) {
/* 103 */       return ((Comparable)o2).compareTo(o1);
/*     */     }
/*     */   };
/*     */   
/*     */   public EvalContext(EvalContext parentContext) {
/* 108 */     this.parentContext = parentContext;
/*     */   }
/*     */   
/*     */   public Pointer getContextNodePointer() {
/* 112 */     return getCurrentNodePointer();
/*     */   }
/*     */   
/*     */   public JXPathContext getJXPathContext() {
/* 116 */     return getRootContext().getJXPathContext();
/*     */   }
/*     */   
/*     */   public int getPosition() {
/* 120 */     return this.position;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDocumentOrder()
/*     */   {
/* 132 */     if ((this.parentContext != null) && (this.parentContext.getDocumentOrder() != 0)) {
/* 133 */       return 1;
/*     */     }
/* 135 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/* 142 */     if (this.pointerIterator != null) {
/* 143 */       return this.pointerIterator.hasNext();
/*     */     }
/*     */     
/* 146 */     if (getDocumentOrder() != 0) {
/* 147 */       return constructIterator();
/*     */     }
/*     */     
/* 150 */     if ((!this.done) && (!this.hasPerformedIteratorStep)) {
/* 151 */       performIteratorStep();
/*     */     }
/* 153 */     return !this.done;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object next()
/*     */   {
/* 161 */     if (this.pointerIterator != null) {
/* 162 */       return this.pointerIterator.next();
/*     */     }
/*     */     
/* 165 */     if (getDocumentOrder() != 0) {
/* 166 */       if (!constructIterator()) {
/* 167 */         throw new NoSuchElementException();
/*     */       }
/* 169 */       return this.pointerIterator.next();
/*     */     }
/*     */     
/* 172 */     if ((!this.done) && (!this.hasPerformedIteratorStep)) {
/* 173 */       performIteratorStep();
/*     */     }
/* 175 */     if (this.done) {
/* 176 */       throw new NoSuchElementException();
/*     */     }
/* 178 */     this.hasPerformedIteratorStep = false;
/* 179 */     return (NodePointer)getCurrentNodePointer().clone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void performIteratorStep()
/*     */   {
/* 187 */     this.done = true;
/* 188 */     if ((this.position != 0) && (nextNode())) {
/* 189 */       this.done = false;
/*     */     }
/*     */     else {
/* 192 */       while (nextSet()) {
/* 193 */         if (nextNode()) {
/* 194 */           this.done = false;
/* 195 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 199 */     this.hasPerformedIteratorStep = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void remove()
/*     */   {
/* 206 */     throw new UnsupportedOperationException("JXPath iterators cannot remove nodes");
/*     */   }
/*     */   
/*     */   private boolean constructIterator()
/*     */   {
/* 211 */     HashSet set = new HashSet();
/* 212 */     ArrayList list = new ArrayList();
/* 213 */     for (goto 65; nextSet(); 
/* 214 */         nextNode()) {
/* 215 */       continue;NodePointer pointer = getCurrentNodePointer();
/* 216 */       if (!set.contains(pointer)) {
/* 217 */         Pointer cln = (Pointer)pointer.clone();
/* 218 */         set.add(cln);
/* 219 */         list.add(cln);
/*     */       }
/*     */     }
/*     */     
/* 223 */     if (list.isEmpty()) {
/* 224 */       return false;
/*     */     }
/*     */     
/* 227 */     if (getDocumentOrder() == 1) {
/* 228 */       Collections.sort(list);
/*     */     }
/*     */     else {
/* 231 */       Collections.sort(list, REVERSE_COMPARATOR);
/*     */     }
/* 233 */     this.pointerIterator = list.iterator();
/* 234 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getContextNodeList()
/*     */   {
/* 242 */     int pos = this.position;
/* 243 */     if (pos != 0) {
/* 244 */       reset();
/*     */     }
/* 246 */     List list = new ArrayList();
/* 247 */     while (nextNode()) {
/* 248 */       list.add(getCurrentNodePointer());
/*     */     }
/* 250 */     if (pos != 0) {
/* 251 */       setPosition(pos);
/*     */     }
/*     */     else {
/* 254 */       reset();
/*     */     }
/* 256 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodeSet getNodeSet()
/*     */   {
/* 265 */     if (this.position != 0) {
/* 266 */       throw new JXPathException("Simultaneous operations: should not request pointer list while iterating over an EvalContext");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 272 */     return new SimpleNodeSet();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 276 */     Pointer ptr = getContextNodePointer();
/* 277 */     if (ptr == null) {
/* 278 */       return "Empty expression context";
/*     */     }
/*     */     
/* 281 */     return "Expression context [" + getPosition() + "] " + ptr.asPath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RootContext getRootContext()
/*     */   {
/* 290 */     if (this.rootContext == null) {
/* 291 */       this.rootContext = this.parentContext.getRootContext();
/*     */     }
/* 293 */     return this.rootContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 300 */     this.position = 0;
/*     */   }
/*     */   
/*     */   public int getCurrentPosition() {
/* 304 */     return this.position;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pointer getSingleNodePointer()
/*     */   {
/* 312 */     reset();
/* 313 */     while (nextSet()) {
/* 314 */       if (nextNode()) {
/* 315 */         return getCurrentNodePointer();
/*     */       }
/*     */     }
/* 318 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract NodePointer getCurrentNodePointer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean nextSet()
/*     */   {
/* 332 */     reset();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 337 */     if (!this.startedSetIteration) {
/* 338 */       this.startedSetIteration = true;
/* 339 */       while (this.parentContext.nextSet()) {
/* 340 */         if (this.parentContext.nextNode()) {
/* 341 */           return true;
/*     */         }
/*     */       }
/* 344 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 349 */     if (this.parentContext.nextNode()) {
/* 350 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 355 */     while (this.parentContext.nextSet()) {
/* 356 */       if (this.parentContext.nextNode()) {
/* 357 */         return true;
/*     */       }
/*     */     }
/* 360 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean nextNode();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setPosition(int position)
/*     */   {
/* 376 */     this.position = position;
/* 377 */     return true;
/*     */   }
/*     */   
/*     */   class SimpleNodeSet implements NodeSet {
/*     */     private List pointers;
/*     */     private List nodes;
/*     */     private List values;
/*     */     
/*     */     public SimpleNodeSet() {
/* 386 */       this.pointers = new ArrayList();
/* 387 */       for (goto 47; EvalContext.this.nextSet(); 
/* 388 */           EvalContext.this.nextNode()) {
/* 389 */         continue;this.pointers.add(EvalContext.this.getCurrentNodePointer());
/*     */       }
/*     */     }
/*     */     
/*     */     public List getPointers()
/*     */     {
/* 395 */       return Collections.unmodifiableList(this.pointers);
/*     */     }
/*     */     
/*     */     public List getNodes() {
/* 399 */       if (this.nodes == null) {
/* 400 */         List pointers = getPointers();
/* 401 */         this.nodes = new ArrayList();
/* 402 */         for (int i = 0; i < pointers.size(); i++) {
/* 403 */           Pointer pointer = (Pointer)pointers.get(i);
/* 404 */           this.nodes.add(pointer.getValue());
/*     */         }
/* 406 */         this.nodes = Collections.unmodifiableList(this.nodes);
/*     */       }
/* 408 */       return this.nodes;
/*     */     }
/*     */     
/*     */     public List getValues() {
/* 412 */       if (this.values == null) {
/* 413 */         List pointers = getPointers();
/* 414 */         this.values = new ArrayList();
/* 415 */         for (int i = 0; i < pointers.size(); i++) {
/* 416 */           Pointer pointer = (Pointer)pointers.get(i);
/* 417 */           this.values.add(pointer.getValue());
/*     */         }
/* 419 */         this.values = Collections.unmodifiableList(this.values);
/*     */       }
/* 421 */       return this.values;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/EvalContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */