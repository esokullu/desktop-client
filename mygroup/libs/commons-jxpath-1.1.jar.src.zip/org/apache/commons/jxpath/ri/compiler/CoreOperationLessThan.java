/*    */ package org.apache.commons.jxpath.ri.compiler;
/*    */ 
/*    */ import org.apache.commons.jxpath.ri.EvalContext;
/*    */ import org.apache.commons.jxpath.ri.InfoSetUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoreOperationLessThan
/*    */   extends CoreOperation
/*    */ {
/*    */   public CoreOperationLessThan(Expression arg1, Expression arg2)
/*    */   {
/* 68 */     super(new Expression[] { arg1, arg2 });
/*    */   }
/*    */   
/*    */   public Object computeValue(EvalContext context) {
/* 72 */     double l = InfoSetUtil.doubleValue(this.args[0].computeValue(context));
/* 73 */     double r = InfoSetUtil.doubleValue(this.args[1].computeValue(context));
/* 74 */     return l < r ? Boolean.TRUE : Boolean.FALSE;
/*    */   }
/*    */   
/*    */   protected int getPrecedence() {
/* 78 */     return 3;
/*    */   }
/*    */   
/*    */   protected boolean isSymmetric() {
/* 82 */     return false;
/*    */   }
/*    */   
/*    */   public String getSymbol() {
/* 86 */     return "<";
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/CoreOperationLessThan.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */