/*     */ package org.apache.commons.jxpath.ri.axes;
/*     */ 
/*     */ import org.apache.commons.jxpath.Function;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.JXPathContextReferenceImpl;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RootContext
/*     */   extends EvalContext
/*     */ {
/*     */   private JXPathContextReferenceImpl jxpathContext;
/*     */   private NodePointer pointer;
/*     */   private Object[] registers;
/*  81 */   private int availableRegister = 0;
/*  82 */   public static final Object UNKNOWN_VALUE = new Object();
/*     */   
/*     */   private static final int MAX_REGISTER = 4;
/*     */   
/*     */ 
/*     */   public RootContext(JXPathContextReferenceImpl jxpathContext, NodePointer pointer)
/*     */   {
/*  89 */     super(null);
/*  90 */     this.jxpathContext = jxpathContext;
/*  91 */     this.pointer = pointer;
/*     */   }
/*     */   
/*     */   public JXPathContext getJXPathContext() {
/*  95 */     return this.jxpathContext;
/*     */   }
/*     */   
/*     */   public RootContext getRootContext() {
/*  99 */     return this;
/*     */   }
/*     */   
/*     */   public EvalContext getAbsoluteRootContext() {
/* 103 */     return this.jxpathContext.getAbsoluteRootContext();
/*     */   }
/*     */   
/*     */   public NodePointer getCurrentNodePointer() {
/* 107 */     return this.pointer;
/*     */   }
/*     */   
/*     */   public int getCurrentPosition() {
/* 111 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean nextNode() {
/* 115 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean nextSet() {
/* 119 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 123 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public EvalContext getConstantContext(Object constant) {
/*     */     NodePointer pointer;
/* 128 */     if ((constant instanceof NodePointer)) {
/* 129 */       pointer = (NodePointer)constant;
/*     */     }
/*     */     else {
/* 132 */       pointer = NodePointer.newNodePointer(new QName(null, ""), constant, null);
/*     */     }
/*     */     
/* 135 */     return new InitialContext(new RootContext(this.jxpathContext, pointer));
/*     */   }
/*     */   
/*     */   public EvalContext getVariableContext(QName variableName) {
/* 139 */     return new InitialContext(new RootContext(this.jxpathContext, this.jxpathContext.getVariablePointer(variableName)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Function getFunction(QName functionName, Object[] parameters)
/*     */   {
/* 146 */     return this.jxpathContext.getFunction(functionName, parameters);
/*     */   }
/*     */   
/*     */   public Object getRegisteredValue(int id) {
/* 150 */     if ((this.registers == null) || (id >= 4) || (id == -1)) {
/* 151 */       return UNKNOWN_VALUE;
/*     */     }
/* 153 */     return this.registers[id];
/*     */   }
/*     */   
/*     */   public int setRegisteredValue(Object value) {
/* 157 */     if (this.registers == null) {
/* 158 */       this.registers = new Object[4];
/* 159 */       for (int i = 0; i < 4; i++) {
/* 160 */         this.registers[i] = UNKNOWN_VALUE;
/*     */       }
/*     */     }
/* 163 */     if (this.availableRegister >= 4) {
/* 164 */       return -1;
/*     */     }
/* 166 */     this.registers[this.availableRegister] = value;
/* 167 */     this.availableRegister += 1;
/* 168 */     return this.availableRegister - 1;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 172 */     return super.toString() + ":" + this.pointer.asPath();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/axes/RootContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */