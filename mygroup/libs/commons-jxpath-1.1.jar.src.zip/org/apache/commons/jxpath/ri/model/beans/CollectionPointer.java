/*     */ package org.apache.commons.jxpath.ri.model.beans;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.JXPathBeanInfo;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathIntrospector;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.util.ValueUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollectionPointer
/*     */   extends NodePointer
/*     */ {
/*     */   private Object collection;
/*     */   private NodePointer valuePointer;
/*     */   
/*     */   public CollectionPointer(Object collection, Locale locale)
/*     */   {
/*  85 */     super(null, locale);
/*  86 */     this.collection = collection;
/*     */   }
/*     */   
/*     */   public CollectionPointer(NodePointer parent, Object collection) {
/*  90 */     super(parent);
/*  91 */     this.collection = collection;
/*     */   }
/*     */   
/*     */   public QName getName() {
/*  95 */     return null;
/*     */   }
/*     */   
/*     */   public Object getBaseValue() {
/*  99 */     return this.collection;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 103 */     return true;
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 107 */     return ValueUtils.getLength(getBaseValue());
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 111 */     Object value = getNode();
/* 112 */     return (value == null) || (JXPathIntrospector.getBeanInfo(value.getClass()).isAtomic());
/*     */   }
/*     */   
/*     */   public boolean isContainer()
/*     */   {
/* 117 */     return this.index != Integer.MIN_VALUE;
/*     */   }
/*     */   
/*     */   public Object getImmediateNode() {
/* 121 */     if (this.index != Integer.MIN_VALUE) {
/* 122 */       return ValueUtils.getValue(this.collection, this.index);
/*     */     }
/* 124 */     return this.collection;
/*     */   }
/*     */   
/*     */   public void setValue(Object value) {
/* 128 */     if (this.index == Integer.MIN_VALUE) {
/* 129 */       this.parent.setValue(value);
/*     */     }
/*     */     else {
/* 132 */       ValueUtils.setValue(this.collection, this.index, value);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setIndex(int index) {
/* 137 */     super.setIndex(index);
/* 138 */     this.valuePointer = null;
/*     */   }
/*     */   
/*     */   public NodePointer getValuePointer() {
/* 142 */     if (this.valuePointer == null) {
/* 143 */       if (this.index == Integer.MIN_VALUE) {
/* 144 */         this.valuePointer = this;
/*     */       }
/*     */       else {
/* 147 */         Object value = getImmediateNode();
/* 148 */         this.valuePointer = NodePointer.newChildNodePointer(this, getName(), value);
/*     */       }
/*     */     }
/*     */     
/* 152 */     return this.valuePointer;
/*     */   }
/*     */   
/*     */   public NodePointer createPath(JXPathContext context) {
/* 156 */     Object collection = getBaseValue();
/* 157 */     if (ValueUtils.getLength(collection) <= this.index) {
/* 158 */       collection = ValueUtils.expandCollection(getNode(), this.index + 1);
/*     */     }
/* 160 */     return this;
/*     */   }
/*     */   
/*     */   public NodePointer createPath(JXPathContext context, Object value) {
/* 164 */     NodePointer ptr = createPath(context);
/* 165 */     ptr.setValue(value);
/* 166 */     return ptr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index, Object value)
/*     */   {
/* 175 */     NodePointer ptr = (NodePointer)clone();
/* 176 */     ptr.setIndex(index);
/* 177 */     return ptr.createPath(context, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index)
/*     */   {
/* 185 */     NodePointer ptr = (NodePointer)clone();
/* 186 */     ptr.setIndex(index);
/* 187 */     return ptr.createPath(context);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 191 */     return System.identityHashCode(this.collection) + this.index;
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 195 */     if (object == this) {
/* 196 */       return true;
/*     */     }
/*     */     
/* 199 */     if (!(object instanceof CollectionPointer)) {
/* 200 */       return false;
/*     */     }
/*     */     
/* 203 */     CollectionPointer other = (CollectionPointer)object;
/* 204 */     return (this.collection == other.collection) && (this.index == other.index);
/*     */   }
/*     */   
/*     */ 
/*     */   public NodeIterator childIterator(NodeTest test, boolean reverse, NodePointer startWith)
/*     */   {
/* 210 */     if (this.index == Integer.MIN_VALUE) {
/* 211 */       return null;
/*     */     }
/* 213 */     return getValuePointer().childIterator(test, reverse, startWith);
/*     */   }
/*     */   
/*     */   public NodeIterator attributeIterator(QName name) {
/* 217 */     if (this.index == Integer.MIN_VALUE) {
/* 218 */       return null;
/*     */     }
/* 220 */     return getValuePointer().attributeIterator(name);
/*     */   }
/*     */   
/*     */   public NodeIterator namespaceIterator() {
/* 224 */     if (this.index == Integer.MIN_VALUE) {
/* 225 */       return null;
/*     */     }
/* 227 */     return getValuePointer().namespaceIterator();
/*     */   }
/*     */   
/*     */   public NodePointer namespacePointer(String namespace) {
/* 231 */     if (this.index == Integer.MIN_VALUE) {
/* 232 */       return null;
/*     */     }
/* 234 */     return getValuePointer().namespacePointer(namespace);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean testNode(NodeTest nodeTest)
/*     */   {
/* 240 */     return getValuePointer().testNode(nodeTest);
/*     */   }
/*     */   
/*     */ 
/*     */   public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2)
/*     */   {
/* 246 */     return pointer1.getIndex() - pointer2.getIndex();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String asPath()
/*     */   {
/* 253 */     StringBuffer buffer = new StringBuffer();
/* 254 */     NodePointer parent = getParent();
/* 255 */     if (parent != null) {
/* 256 */       buffer.append(parent.asPath());
/* 257 */       if (this.index != Integer.MIN_VALUE)
/*     */       {
/* 259 */         if (parent.getIndex() != Integer.MIN_VALUE) {
/* 260 */           buffer.append("/.");
/*     */         }
/* 262 */         buffer.append("[").append(this.index + 1).append(']');
/*     */       }
/*     */       
/*     */     }
/* 266 */     else if (this.index != Integer.MIN_VALUE) {
/* 267 */       buffer.append("/.[").append(this.index + 1).append(']');
/*     */     }
/*     */     else {
/* 270 */       buffer.append("/");
/*     */     }
/*     */     
/*     */ 
/* 274 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/beans/CollectionPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */