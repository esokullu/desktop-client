/*     */ package org.apache.commons.jxpath.ri.axes;
/*     */ 
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelfContext
/*     */   extends EvalContext
/*     */ {
/*     */   private NodeTest nodeTest;
/*  78 */   private boolean startedSet = false;
/*     */   private NodePointer nodePointer;
/*     */   
/*     */   public SelfContext(EvalContext parentContext, NodeTest nodeTest) {
/*  82 */     super(parentContext);
/*  83 */     this.nodeTest = nodeTest;
/*     */   }
/*     */   
/*     */   public Pointer getSingleNodePointer() {
/*  87 */     return this.parentContext.getSingleNodePointer();
/*     */   }
/*     */   
/*     */   public NodePointer getCurrentNodePointer() {
/*  91 */     if ((this.position == 0) && 
/*  92 */       (!setPosition(1))) {
/*  93 */       return null;
/*     */     }
/*     */     
/*  96 */     return this.nodePointer;
/*     */   }
/*     */   
/*     */   public boolean nextNode() {
/* 100 */     return setPosition(getCurrentPosition() + 1);
/*     */   }
/*     */   
/*     */   public void reset() {
/* 104 */     super.reset();
/* 105 */     this.startedSet = false;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 109 */     if (position != 1) {
/* 110 */       return false;
/*     */     }
/* 112 */     super.setPosition(position);
/* 113 */     if (!this.startedSet) {
/* 114 */       this.startedSet = true;
/* 115 */       this.nodePointer = this.parentContext.getCurrentNodePointer();
/*     */     }
/*     */     
/* 118 */     if (this.nodePointer == null) {
/* 119 */       return false;
/*     */     }
/*     */     
/* 122 */     return (this.nodeTest == null) || (this.nodePointer.testNode(this.nodeTest));
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/axes/SelfContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */