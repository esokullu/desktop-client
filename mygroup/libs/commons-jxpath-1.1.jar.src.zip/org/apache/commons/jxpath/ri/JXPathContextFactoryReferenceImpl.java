/*    */ package org.apache.commons.jxpath.ri;
/*    */ 
/*    */ import org.apache.commons.jxpath.JXPathContext;
/*    */ import org.apache.commons.jxpath.JXPathContextFactory;
/*    */ import org.apache.commons.jxpath.JXPathContextFactoryConfigurationError;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JXPathContextFactoryReferenceImpl
/*    */   extends JXPathContextFactory
/*    */ {
/*    */   public JXPathContext newContext(JXPathContext parentContext, Object contextBean)
/*    */     throws JXPathContextFactoryConfigurationError
/*    */   {
/* 84 */     return new JXPathContextReferenceImpl(parentContext, contextBean);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/JXPathContextFactoryReferenceImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */