/*     */ package org.apache.commons.jxpath.ri.model.jdom;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDOMNodeIterator
/*     */   implements NodeIterator
/*     */ {
/*     */   private NodePointer parent;
/*     */   private NodeTest nodeTest;
/*     */   private boolean reverse;
/*  84 */   private int position = 0;
/*  85 */   private int index = 0;
/*     */   
/*     */   private List children;
/*     */   
/*     */   private Object child;
/*     */   
/*     */   public JDOMNodeIterator(NodePointer parent, NodeTest nodeTest, boolean reverse, NodePointer startWith)
/*     */   {
/*  93 */     this.parent = parent;
/*  94 */     if (startWith != null) {
/*  95 */       this.child = startWith.getNode();
/*     */     }
/*     */     
/*  98 */     Object node = parent.getNode();
/*  99 */     if ((node instanceof Document)) {
/* 100 */       this.children = ((Document)node).getContent();
/*     */     }
/* 102 */     else if ((node instanceof Element)) {
/* 103 */       this.children = ((Element)node).getContent();
/*     */     }
/*     */     else {
/* 106 */       this.children = Collections.EMPTY_LIST;
/*     */     }
/* 108 */     this.nodeTest = nodeTest;
/* 109 */     this.reverse = reverse;
/*     */   }
/*     */   
/*     */   public NodePointer getNodePointer() {
/* 113 */     if (this.child == null) {
/* 114 */       if (!setPosition(1)) {
/* 115 */         return null;
/*     */       }
/* 117 */       this.position = 0;
/*     */     }
/*     */     
/* 120 */     return new JDOMNodePointer(this.parent, this.child);
/*     */   }
/*     */   
/*     */   public int getPosition() {
/* 124 */     return this.position;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 128 */     while (this.position < position) {
/* 129 */       if (!next()) {
/* 130 */         return false;
/*     */       }
/*     */     }
/* 133 */     while (this.position > position) {
/* 134 */       if (!previous()) {
/* 135 */         return false;
/*     */       }
/*     */     }
/* 138 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean previous()
/*     */   {
/* 148 */     this.position -= 1;
/* 149 */     if (!this.reverse) {
/* 150 */       while (--this.index >= 0) {
/* 151 */         this.child = this.children.get(this.index);
/* 152 */         if (testChild()) {
/* 153 */           return true;
/*     */         }
/*     */       }
/*     */     } else {
/* 158 */       for (; 
/* 158 */           this.index < this.children.size(); this.index += 1) {
/* 159 */         this.child = this.children.get(this.index);
/* 160 */         if (testChild()) {
/* 161 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 165 */     return false;
/*     */   }
/*     */   
/*     */   private boolean next() {
/* 169 */     this.position += 1;
/* 170 */     if (!this.reverse) {
/* 171 */       if (this.position == 1) {
/* 172 */         this.index = 0;
/* 173 */         if (this.child == null) break label108;
/* 174 */         this.index = (this.children.indexOf(this.child) + 1);
/*     */       }
/*     */       
/*     */       label108:
/* 178 */       for (this.index += 1; 
/*     */           
/* 180 */           this.index < this.children.size(); this.index += 1) {
/* 181 */         this.child = this.children.get(this.index);
/* 182 */         if (testChild()) {
/* 183 */           return true;
/*     */         }
/*     */       }
/* 186 */       return false;
/*     */     }
/*     */     
/* 189 */     if (this.position == 1) {
/* 190 */       this.index = (this.children.size() - 1);
/* 191 */       if (this.child == null) break label227;
/* 192 */       this.index = (this.children.indexOf(this.child) - 1);
/*     */     }
/*     */     
/*     */     label227:
/* 196 */     for (this.index -= 1; 
/*     */         
/* 198 */         this.index >= 0; this.index -= 1) {
/* 199 */       this.child = this.children.get(this.index);
/* 200 */       if (testChild()) {
/* 201 */         return true;
/*     */       }
/*     */     }
/* 204 */     return false;
/*     */   }
/*     */   
/*     */   private boolean testChild()
/*     */   {
/* 209 */     return JDOMNodePointer.testNode(this.parent, this.child, this.nodeTest);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/jdom/JDOMNodeIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */