/*     */ package org.apache.commons.jxpath.ri.model.dynabeans;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.beanutils.DynaBean;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DynaBeanPointerFactory
/*     */   implements NodePointerFactory
/*     */ {
/*     */   public static final int DYNA_BEAN_POINTER_FACTORY_ORDER = 700;
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  85 */     return 700;
/*     */   }
/*     */   
/*     */ 
/*     */   public NodePointer createNodePointer(QName name, Object bean, Locale locale)
/*     */   {
/*  91 */     if ((bean instanceof DynaBean)) {
/*  92 */       return new DynaBeanPointer(name, (DynaBean)bean, locale);
/*     */     }
/*  94 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public NodePointer createNodePointer(NodePointer parent, QName name, Object bean)
/*     */   {
/* 100 */     if ((bean instanceof DynaBean)) {
/* 101 */       return new DynaBeanPointer(parent, name, (DynaBean)bean);
/*     */     }
/* 103 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dynabeans/DynaBeanPointerFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */