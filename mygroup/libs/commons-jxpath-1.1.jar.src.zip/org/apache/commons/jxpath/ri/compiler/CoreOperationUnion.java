/*    */ package org.apache.commons.jxpath.ri.compiler;
/*    */ 
/*    */ import org.apache.commons.jxpath.ri.EvalContext;
/*    */ import org.apache.commons.jxpath.ri.axes.RootContext;
/*    */ import org.apache.commons.jxpath.ri.axes.UnionContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoreOperationUnion
/*    */   extends CoreOperation
/*    */ {
/*    */   public CoreOperationUnion(Expression[] args)
/*    */   {
/* 68 */     super(args);
/*    */   }
/*    */   
/*    */   public Object computeValue(EvalContext context) {
/* 72 */     EvalContext[] argCtxs = new EvalContext[this.args.length];
/* 73 */     for (int i = 0; i < this.args.length; i++) {
/* 74 */       Object value = this.args[i].compute(context);
/* 75 */       if ((value instanceof EvalContext)) {
/* 76 */         argCtxs[i] = ((EvalContext)value);
/*    */       }
/*    */       else {
/* 79 */         argCtxs[i] = context.getRootContext().getConstantContext(value);
/*    */       }
/*    */     }
/* 82 */     return new UnionContext(context.getRootContext(), argCtxs);
/*    */   }
/*    */   
/*    */   protected int getPrecedence() {
/* 86 */     return 7;
/*    */   }
/*    */   
/*    */   protected boolean isSymmetric() {
/* 90 */     return true;
/*    */   }
/*    */   
/*    */   public String getSymbol() {
/* 94 */     return "|";
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/CoreOperationUnion.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */