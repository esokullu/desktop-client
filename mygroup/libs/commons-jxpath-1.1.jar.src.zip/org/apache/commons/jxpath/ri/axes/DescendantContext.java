/*     */ package org.apache.commons.jxpath.ri.axes;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DescendantContext
/*     */   extends EvalContext
/*     */ {
/*     */   private NodeTest nodeTest;
/*  82 */   private boolean setStarted = false;
/*     */   private Stack stack;
/*     */   private NodePointer currentNodePointer;
/*     */   private boolean includeSelf;
/*  86 */   private static final NodeTest ELEMENT_NODE_TEST = new NodeTypeTest(1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DescendantContext(EvalContext parentContext, boolean includeSelf, NodeTest nodeTest)
/*     */   {
/*  94 */     super(parentContext);
/*  95 */     this.includeSelf = includeSelf;
/*  96 */     this.nodeTest = nodeTest;
/*     */   }
/*     */   
/*     */   public NodePointer getCurrentNodePointer() {
/* 100 */     if ((this.position == 0) && 
/* 101 */       (!setPosition(1))) {
/* 102 */       return null;
/*     */     }
/*     */     
/* 105 */     return this.currentNodePointer;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 109 */     super.reset();
/* 110 */     this.setStarted = false;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 114 */     if (position < this.position) {
/* 115 */       reset();
/*     */     }
/*     */     
/* 118 */     while (this.position < position) {
/* 119 */       if (!nextNode()) {
/* 120 */         return false;
/*     */       }
/*     */     }
/* 123 */     return true;
/*     */   }
/*     */   
/*     */   public boolean nextNode() {
/* 127 */     if (!this.setStarted) {
/* 128 */       this.setStarted = true;
/* 129 */       this.stack = new Stack();
/* 130 */       this.currentNodePointer = this.parentContext.getCurrentNodePointer();
/* 131 */       if (this.currentNodePointer != null) {
/* 132 */         if (!this.currentNodePointer.isLeaf()) {
/* 133 */           this.stack.push(this.currentNodePointer.childIterator(ELEMENT_NODE_TEST, false, null));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 139 */         if ((this.includeSelf) && 
/* 140 */           (this.currentNodePointer.testNode(this.nodeTest))) {
/* 141 */           this.position += 1;
/* 142 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 148 */     while (!this.stack.isEmpty()) {
/* 149 */       NodeIterator it = (NodeIterator)this.stack.peek();
/* 150 */       if (it.setPosition(it.getPosition() + 1)) {
/* 151 */         this.currentNodePointer = it.getNodePointer();
/* 152 */         if (!this.currentNodePointer.isLeaf()) {
/* 153 */           this.stack.push(this.currentNodePointer.childIterator(ELEMENT_NODE_TEST, false, null));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 159 */         if (this.currentNodePointer.testNode(this.nodeTest)) {
/* 160 */           this.position += 1;
/* 161 */           return true;
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 167 */         this.stack.pop();
/*     */       }
/*     */     }
/* 170 */     return false;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/axes/DescendantContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */