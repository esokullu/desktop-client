/*     */ package org.apache.commons.jxpath.ri.compiler;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Constant
/*     */   extends Expression
/*     */ {
/*     */   private Object value;
/*     */   
/*     */   public Constant(Number number)
/*     */   {
/*  77 */     this.value = number;
/*     */   }
/*     */   
/*     */   public Constant(String string) {
/*  81 */     this.value = string;
/*     */   }
/*     */   
/*     */   public Object compute(EvalContext context) {
/*  85 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object computeValue(EvalContext context)
/*     */   {
/*  92 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isContextDependent()
/*     */   {
/*  99 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean computeContextDependent()
/*     */   {
/* 106 */     return false;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 110 */     if ((this.value instanceof Number)) {
/* 111 */       double doubleValue = ((Number)this.value).doubleValue();
/* 112 */       long longValue = ((Number)this.value).longValue();
/* 113 */       if (doubleValue == longValue) {
/* 114 */         return String.valueOf(longValue);
/*     */       }
/*     */       
/* 117 */       return String.valueOf(doubleValue);
/*     */     }
/*     */     
/*     */ 
/* 121 */     return "'" + this.value + "'";
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/Constant.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */