/*     */ package org.apache.commons.jxpath.ri.axes;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttributeContext
/*     */   extends EvalContext
/*     */ {
/*     */   private NodeTest nodeTest;
/*  79 */   private boolean setStarted = false;
/*     */   
/*     */   private NodeIterator iterator;
/*     */   
/*     */   private NodePointer currentNodePointer;
/*     */   
/*     */ 
/*     */   public AttributeContext(EvalContext parentContext, NodeTest nodeTest)
/*     */   {
/*  88 */     super(parentContext);
/*  89 */     this.nodeTest = nodeTest;
/*     */   }
/*     */   
/*     */   public NodePointer getCurrentNodePointer() {
/*  93 */     return this.currentNodePointer;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  97 */     this.setStarted = false;
/*  98 */     this.iterator = null;
/*  99 */     super.reset();
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 103 */     if (position < getCurrentPosition()) {
/* 104 */       reset();
/*     */     }
/*     */     
/* 107 */     while (getCurrentPosition() < position) {
/* 108 */       if (!nextNode()) {
/* 109 */         return false;
/*     */       }
/*     */     }
/* 112 */     return true;
/*     */   }
/*     */   
/*     */   public boolean nextNode() {
/* 116 */     super.setPosition(getCurrentPosition() + 1);
/* 117 */     if (!this.setStarted) {
/* 118 */       this.setStarted = true;
/* 119 */       if (!(this.nodeTest instanceof NodeNameTest)) {
/* 120 */         return false;
/*     */       }
/* 122 */       QName name = ((NodeNameTest)this.nodeTest).getNodeName();
/* 123 */       this.iterator = this.parentContext.getCurrentNodePointer().attributeIterator(name);
/*     */     }
/*     */     
/*     */ 
/* 127 */     if (this.iterator == null) {
/* 128 */       return false;
/*     */     }
/* 130 */     if (!this.iterator.setPosition(this.iterator.getPosition() + 1)) {
/* 131 */       return false;
/*     */     }
/* 133 */     this.currentNodePointer = this.iterator.getNodePointer();
/* 134 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/axes/AttributeContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */