/*     */ package org.apache.commons.jxpath.ri.model.jdom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.jdom.Attribute;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.Namespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDOMAttributeIterator
/*     */   implements NodeIterator
/*     */ {
/*     */   private NodePointer parent;
/*     */   private QName name;
/*     */   private List attributes;
/*  85 */   private int position = 0;
/*     */   
/*     */   public JDOMAttributeIterator(NodePointer parent, QName name) {
/*  88 */     this.parent = parent;
/*  89 */     this.name = name;
/*  90 */     if ((parent.getNode() instanceof Element)) {
/*  91 */       Element element = (Element)parent.getNode();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */       String prefix = name.getPrefix();
/*     */       Namespace ns;
/* 101 */       if (prefix != null) {
/* 102 */         if (prefix.equals("xml")) {
/* 103 */           ns = Namespace.XML_NAMESPACE;
/*     */         }
/*     */         else {
/* 106 */           ns = element.getNamespace(prefix);
/* 107 */           if (ns == null)
/*     */           {
/* 109 */             this.attributes = Collections.EMPTY_LIST;
/*     */           }
/*     */           
/*     */         }
/*     */       }
/*     */       else {
/* 115 */         ns = Namespace.NO_NAMESPACE;
/*     */       }
/*     */       
/* 118 */       String lname = name.getName();
/* 119 */       if (!lname.equals("*")) {
/* 120 */         this.attributes = new ArrayList();
/* 121 */         if (ns != null) {
/* 122 */           Attribute attr = element.getAttribute(lname, ns);
/*     */           
/* 124 */           if (attr != null) {
/* 125 */             this.attributes.add(attr);
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 130 */         this.attributes = new ArrayList();
/* 131 */         List allAttributes = element.getAttributes();
/* 132 */         for (int i = 0; i < allAttributes.size(); i++) {
/* 133 */           Attribute attr = (Attribute)allAttributes.get(i);
/* 134 */           if (attr.getNamespace().equals(ns)) {
/* 135 */             this.attributes.add(attr);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer getNodePointer()
/*     */   {
/* 217 */     if (this.position == 0) {
/* 218 */       if (!setPosition(1)) {
/* 219 */         return null;
/*     */       }
/* 221 */       this.position = 0;
/*     */     }
/* 223 */     int index = this.position - 1;
/* 224 */     if (index < 0) {
/* 225 */       index = 0;
/*     */     }
/* 227 */     return new JDOMAttributePointer(this.parent, (Attribute)this.attributes.get(index));
/*     */   }
/*     */   
/*     */ 
/*     */   public int getPosition()
/*     */   {
/* 233 */     return this.position;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 237 */     if (this.attributes == null) {
/* 238 */       return false;
/*     */     }
/* 240 */     this.position = position;
/* 241 */     return (position >= 1) && (position <= this.attributes.size());
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/jdom/JDOMAttributeIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */