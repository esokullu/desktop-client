/*     */ package org.apache.commons.jxpath.ri.model.jdom;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.jxpath.AbstractFactory;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.util.TypeUtils;
/*     */ import org.jdom.Attribute;
/*     */ import org.jdom.CDATA;
/*     */ import org.jdom.Comment;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.Namespace;
/*     */ import org.jdom.ProcessingInstruction;
/*     */ import org.jdom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDOMNodePointer
/*     */   extends NodePointer
/*     */ {
/*     */   private Object node;
/*     */   private Map namespaces;
/*     */   private String defaultNamespace;
/*     */   private String id;
/*     */   public static final String XML_NAMESPACE_URI = "http://www.w3.org/XML/1998/namespace";
/*     */   public static final String XMLNS_NAMESPACE_URI = "http://www.w3.org/2000/xmlns/";
/*     */   
/*     */   public JDOMNodePointer(Object node, Locale locale)
/*     */   {
/* 107 */     super(null, locale);
/* 108 */     this.node = node;
/*     */   }
/*     */   
/*     */   public JDOMNodePointer(Object node, Locale locale, String id) {
/* 112 */     super(null, locale);
/* 113 */     this.node = node;
/* 114 */     this.id = id;
/*     */   }
/*     */   
/*     */   public JDOMNodePointer(NodePointer parent, Object node) {
/* 118 */     super(parent);
/* 119 */     this.node = node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodeIterator childIterator(NodeTest test, boolean reverse, NodePointer startWith)
/*     */   {
/* 127 */     return new JDOMNodeIterator(this, test, reverse, startWith);
/*     */   }
/*     */   
/*     */   public NodeIterator attributeIterator(QName name) {
/* 131 */     return new JDOMAttributeIterator(this, name);
/*     */   }
/*     */   
/*     */   public NodeIterator namespaceIterator() {
/* 135 */     return new JDOMNamespaceIterator(this);
/*     */   }
/*     */   
/*     */   public NodePointer namespacePointer(String prefix) {
/* 139 */     return new JDOMNamespacePointer(this, prefix);
/*     */   }
/*     */   
/*     */   public String getNamespaceURI() {
/* 143 */     if ((this.node instanceof Element)) {
/* 144 */       Element element = (Element)this.node;
/* 145 */       String ns = element.getNamespaceURI();
/* 146 */       if ((ns != null) && (ns.equals(""))) {
/* 147 */         ns = null;
/*     */       }
/* 149 */       return ns;
/*     */     }
/* 151 */     return null;
/*     */   }
/*     */   
/*     */   public String getNamespaceURI(String prefix) {
/* 155 */     if ((this.node instanceof Element)) {
/* 156 */       Element element = (Element)this.node;
/* 157 */       Namespace ns = element.getNamespace(prefix);
/* 158 */       if (ns == null) {
/* 159 */         return null;
/*     */       }
/* 161 */       return ns.getURI();
/*     */     }
/* 163 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2)
/*     */   {
/* 170 */     Object node1 = pointer1.getBaseValue();
/* 171 */     Object node2 = pointer2.getBaseValue();
/* 172 */     if (node1 == node2) {
/* 173 */       return 0;
/*     */     }
/*     */     
/* 176 */     if (((node1 instanceof Attribute)) && (!(node2 instanceof Attribute))) {
/* 177 */       return -1;
/*     */     }
/* 179 */     if ((!(node1 instanceof Attribute)) && ((node2 instanceof Attribute)))
/*     */     {
/* 181 */       return 1;
/*     */     }
/* 183 */     if (((node1 instanceof Attribute)) && ((node2 instanceof Attribute)))
/*     */     {
/* 185 */       List list = ((Element)getNode()).getAttributes();
/* 186 */       int length = list.size();
/* 187 */       for (int i = 0; i < length; i++) {
/* 188 */         Object n = list.get(i);
/* 189 */         if (n == node1) {
/* 190 */           return -1;
/*     */         }
/* 192 */         if (n == node2) {
/* 193 */           return 1;
/*     */         }
/*     */       }
/* 196 */       return 0;
/*     */     }
/*     */     
/* 199 */     if (!(this.node instanceof Element)) {
/* 200 */       throw new RuntimeException("JXPath internal error: compareChildNodes called for " + this.node);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 206 */     List children = ((Element)this.node).getContent();
/* 207 */     int length = children.size();
/* 208 */     for (int i = 0; i < length; i++) {
/* 209 */       Object n = children.get(i);
/* 210 */       if (n == node1) {
/* 211 */         return -1;
/*     */       }
/* 213 */       if (n == node2) {
/* 214 */         return 1;
/*     */       }
/*     */     }
/*     */     
/* 218 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getBaseValue()
/*     */   {
/* 226 */     return this.node;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 230 */     return false;
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 234 */     return 1;
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 238 */     if ((this.node instanceof Element)) {
/* 239 */       return ((Element)this.node).getContent().size() == 0;
/*     */     }
/* 241 */     if ((this.node instanceof Document)) {
/* 242 */       return ((Document)this.node).getContent().size() == 0;
/*     */     }
/* 244 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public QName getName()
/*     */   {
/* 251 */     String ns = null;
/* 252 */     String ln = null;
/* 253 */     if ((this.node instanceof Element)) {
/* 254 */       ns = ((Element)this.node).getNamespacePrefix();
/* 255 */       if ((ns != null) && (ns.equals(""))) {
/* 256 */         ns = null;
/*     */       }
/* 258 */       ln = ((Element)this.node).getName();
/*     */     }
/* 260 */     else if ((this.node instanceof ProcessingInstruction)) {
/* 261 */       ln = ((ProcessingInstruction)this.node).getTarget();
/*     */     }
/* 263 */     return new QName(ns, ln);
/*     */   }
/*     */   
/*     */   public QName getExpandedName() {
/* 267 */     return new QName(getNamespaceURI(), getName().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getImmediateNode()
/*     */   {
/* 274 */     return this.node;
/*     */   }
/*     */   
/*     */   public Object getValue() {
/* 278 */     if ((this.node instanceof Element)) {
/* 279 */       return ((Element)this.node).getTextTrim();
/*     */     }
/* 281 */     if ((this.node instanceof Comment)) {
/* 282 */       String text = ((Comment)this.node).getText();
/* 283 */       if (text != null) {
/* 284 */         text = text.trim();
/*     */       }
/* 286 */       return text;
/*     */     }
/* 288 */     if ((this.node instanceof Text)) {
/* 289 */       return ((Text)this.node).getTextTrim();
/*     */     }
/* 291 */     if ((this.node instanceof CDATA)) {
/* 292 */       return ((CDATA)this.node).getTextTrim();
/*     */     }
/* 294 */     if ((this.node instanceof ProcessingInstruction)) {
/* 295 */       String text = ((ProcessingInstruction)this.node).getData();
/* 296 */       if (text != null) {
/* 297 */         text = text.trim();
/*     */       }
/* 299 */       return text;
/*     */     }
/* 301 */     return null;
/*     */   }
/*     */   
/*     */   public void setValue(Object value) {
/* 305 */     if ((this.node instanceof Text)) {
/* 306 */       String string = (String)TypeUtils.convert(value, String.class);
/* 307 */       if ((string != null) && (!string.equals(""))) {
/* 308 */         ((Text)this.node).setText(string);
/*     */       }
/*     */       else {
/* 311 */         nodeParent(this.node).removeContent((Text)this.node);
/*     */       }
/*     */     }
/*     */     else {
/* 315 */       Element element = (Element)this.node;
/* 316 */       element.getContent().clear();
/*     */       
/* 318 */       if ((value instanceof Element)) {
/* 319 */         Element valueElement = (Element)value;
/* 320 */         addContent(valueElement.getContent());
/*     */       }
/* 322 */       else if ((value instanceof Document)) {
/* 323 */         Document valueDocument = (Document)value;
/* 324 */         addContent(valueDocument.getContent());
/*     */       }
/* 326 */       else if (((value instanceof Text)) || ((value instanceof CDATA))) {
/* 327 */         String string = ((Text)value).getText();
/* 328 */         element.addContent(new Text(string));
/*     */       }
/* 330 */       else if ((value instanceof ProcessingInstruction)) {
/* 331 */         ProcessingInstruction pi = (ProcessingInstruction)((ProcessingInstruction)value).clone();
/*     */         
/*     */ 
/* 334 */         element.addContent(pi);
/*     */       }
/* 336 */       else if ((value instanceof Comment)) {
/* 337 */         Comment comment = (Comment)((Comment)value).clone();
/* 338 */         element.addContent(comment);
/*     */       }
/*     */       else {
/* 341 */         String string = (String)TypeUtils.convert(value, String.class);
/* 342 */         if ((string != null) && (!string.equals(""))) {
/* 343 */           element.addContent(new Text(string));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addContent(List content) {
/* 350 */     Element element = (Element)this.node;
/* 351 */     int count = content.size();
/*     */     
/* 353 */     for (int i = 0; i < count; i++) {
/* 354 */       Object child = content.get(i);
/* 355 */       if ((child instanceof Element)) {
/* 356 */         child = ((Element)child).clone();
/* 357 */         element.addContent((Element)child);
/*     */       }
/* 359 */       else if ((child instanceof Text)) {
/* 360 */         child = ((Text)child).clone();
/* 361 */         element.addContent((Text)child);
/*     */       }
/* 363 */       else if ((this.node instanceof CDATA)) {
/* 364 */         child = ((CDATA)child).clone();
/* 365 */         element.addContent((CDATA)child);
/*     */       }
/* 367 */       else if ((this.node instanceof ProcessingInstruction)) {
/* 368 */         child = ((ProcessingInstruction)child).clone();
/* 369 */         element.addContent((ProcessingInstruction)child);
/*     */       }
/* 371 */       else if ((this.node instanceof Comment)) {
/* 372 */         child = ((Comment)child).clone();
/* 373 */         element.addContent((Comment)child);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean testNode(NodeTest test) {
/* 379 */     return testNode(this, this.node, test);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean testNode(NodePointer pointer, Object node, NodeTest test)
/*     */   {
/* 387 */     if (test == null) {
/* 388 */       return true;
/*     */     }
/* 390 */     if ((test instanceof NodeNameTest)) {
/* 391 */       if (!(node instanceof Element)) {
/* 392 */         return false;
/*     */       }
/*     */       
/* 395 */       QName testName = ((NodeNameTest)test).getNodeName();
/* 396 */       String testLocalName = testName.getName();
/* 397 */       boolean wildcard = testLocalName.equals("*");
/* 398 */       if ((wildcard) && (testName.getPrefix() == null)) {
/* 399 */         return true;
/*     */       }
/*     */       
/* 402 */       if ((wildcard) || (testLocalName.equals(getLocalName((Element)node))))
/*     */       {
/*     */ 
/* 405 */         String testPrefix = testName.getPrefix();
/* 406 */         String nodePrefix = getPrefix((Element)node);
/* 407 */         if (equalStrings(testPrefix, nodePrefix)) {
/* 408 */           return true;
/*     */         }
/*     */         
/* 411 */         String testNS = pointer.getNamespaceURI(testPrefix);
/* 412 */         if (testNS == null) {
/* 413 */           return false;
/*     */         }
/* 415 */         String nodeNS = pointer.getNamespaceURI(nodePrefix);
/* 416 */         return equalStrings(testNS, nodeNS);
/*     */       }
/*     */     } else {
/* 419 */       if ((test instanceof NodeTypeTest)) {
/* 420 */         switch (((NodeTypeTest)test).getNodeType()) {
/*     */         case 1: 
/* 422 */           return node instanceof Element;
/*     */         case 2: 
/* 424 */           return ((node instanceof Text)) || ((node instanceof CDATA));
/*     */         case 3: 
/* 426 */           return node instanceof Comment;
/*     */         case 4: 
/* 428 */           return node instanceof ProcessingInstruction;
/*     */         }
/* 430 */         return false;
/*     */       }
/* 432 */       if (((test instanceof ProcessingInstructionTest)) && 
/* 433 */         ((node instanceof ProcessingInstruction))) {
/* 434 */         String testPI = ((ProcessingInstructionTest)test).getTarget();
/* 435 */         String nodePI = ((ProcessingInstruction)node).getTarget();
/* 436 */         return testPI.equals(nodePI);
/*     */       }
/*     */     }
/*     */     
/* 440 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean equalStrings(String s1, String s2) {
/* 444 */     if ((s1 == null) && (s2 != null)) {
/* 445 */       return false;
/*     */     }
/* 447 */     if ((s1 != null) && (s2 == null)) {
/* 448 */       return false;
/*     */     }
/*     */     
/* 451 */     if ((s1 != null) && (!s1.trim().equals(s2.trim()))) {
/* 452 */       return false;
/*     */     }
/*     */     
/* 455 */     return true;
/*     */   }
/*     */   
/*     */   public static String getPrefix(Object node) {
/* 459 */     if ((node instanceof Element)) {
/* 460 */       String prefix = ((Element)node).getNamespacePrefix();
/* 461 */       return (prefix == null) || (prefix.equals("")) ? null : prefix;
/*     */     }
/* 463 */     if ((node instanceof Attribute)) {
/* 464 */       String prefix = ((Attribute)node).getNamespacePrefix();
/* 465 */       return (prefix == null) || (prefix.equals("")) ? null : prefix;
/*     */     }
/* 467 */     return null;
/*     */   }
/*     */   
/*     */   public static String getLocalName(Object node) {
/* 471 */     if ((node instanceof Element)) {
/* 472 */       return ((Element)node).getName();
/*     */     }
/* 474 */     if ((node instanceof Attribute)) {
/* 475 */       return ((Attribute)node).getName();
/*     */     }
/* 477 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLanguage(String lang)
/*     */   {
/* 486 */     String current = getLanguage();
/* 487 */     if (current == null) {
/* 488 */       return super.isLanguage(lang);
/*     */     }
/* 490 */     return current.toUpperCase().startsWith(lang.toUpperCase());
/*     */   }
/*     */   
/*     */   protected String getLanguage() {
/* 494 */     Object n = this.node;
/* 495 */     while (n != null) {
/* 496 */       if ((n instanceof Element)) {
/* 497 */         Element e = (Element)n;
/* 498 */         String attr = e.getAttributeValue("lang", Namespace.XML_NAMESPACE);
/*     */         
/* 500 */         if ((attr != null) && (!attr.equals(""))) {
/* 501 */           return attr;
/*     */         }
/*     */       }
/* 504 */       n = nodeParent(n);
/*     */     }
/* 506 */     return null;
/*     */   }
/*     */   
/*     */   private Element nodeParent(Object node) {
/* 510 */     if ((node instanceof Element)) {
/* 511 */       return ((Element)node).getParent();
/*     */     }
/* 513 */     if ((node instanceof Text)) {
/* 514 */       return ((Text)node).getParent();
/*     */     }
/* 516 */     if ((node instanceof CDATA)) {
/* 517 */       return ((CDATA)node).getParent();
/*     */     }
/* 519 */     if ((node instanceof ProcessingInstruction)) {
/* 520 */       return ((ProcessingInstruction)node).getParent();
/*     */     }
/* 522 */     if ((node instanceof Comment)) {
/* 523 */       return ((Comment)node).getParent();
/*     */     }
/* 525 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index)
/*     */   {
/* 533 */     if (index == Integer.MIN_VALUE) {
/* 534 */       index = 0;
/*     */     }
/* 536 */     boolean success = getAbstractFactory(context).createObject(context, this, this.node, name.toString(), index);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 543 */     if (success) {
/* 544 */       NodeIterator it = childIterator(new NodeNameTest(name), false, null);
/*     */       
/* 546 */       if ((it != null) && (it.setPosition(index + 1))) {
/* 547 */         return it.getNodePointer();
/*     */       }
/*     */     }
/* 550 */     throw new JXPathException("Factory could not create a child node for path: " + asPath() + "/" + name + "[" + (index + 1) + "]");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index, Object value)
/*     */   {
/* 564 */     NodePointer ptr = createChild(context, name, index);
/* 565 */     ptr.setValue(value);
/* 566 */     return ptr;
/*     */   }
/*     */   
/*     */   public NodePointer createAttribute(JXPathContext context, QName name) {
/* 570 */     if (!(this.node instanceof Element)) {
/* 571 */       return super.createAttribute(context, name);
/*     */     }
/*     */     
/* 574 */     Element element = (Element)this.node;
/* 575 */     String prefix = name.getPrefix();
/* 576 */     if (prefix != null) {
/* 577 */       Namespace ns = element.getNamespace(prefix);
/* 578 */       if (ns == null) {
/* 579 */         throw new JXPathException("Unknown namespace prefix: " + prefix);
/*     */       }
/*     */       
/* 582 */       Attribute attr = element.getAttribute(name.getName(), ns);
/* 583 */       if (attr == null) {
/* 584 */         element.setAttribute(name.getName(), "", ns);
/*     */       }
/*     */     }
/*     */     else {
/* 588 */       Attribute attr = element.getAttribute(name.getName());
/* 589 */       if (attr == null) {
/* 590 */         element.setAttribute(name.getName(), "");
/*     */       }
/*     */     }
/* 593 */     NodeIterator it = attributeIterator(name);
/* 594 */     it.setPosition(1);
/* 595 */     return it.getNodePointer();
/*     */   }
/*     */   
/*     */   public void remove() {
/* 599 */     Element parent = nodeParent(this.node);
/* 600 */     if (parent == null) {
/* 601 */       throw new JXPathException("Cannot remove root JDOM node");
/*     */     }
/* 603 */     parent.getContent().remove(this.node);
/*     */   }
/*     */   
/*     */   public String asPath() {
/* 607 */     if (this.id != null) {
/* 608 */       return "id('" + escape(this.id) + "')";
/*     */     }
/*     */     
/* 611 */     StringBuffer buffer = new StringBuffer();
/* 612 */     if (this.parent != null) {
/* 613 */       buffer.append(this.parent.asPath());
/*     */     }
/* 615 */     if ((this.node instanceof Element))
/*     */     {
/*     */ 
/*     */ 
/* 619 */       if ((this.parent instanceof JDOMNodePointer)) {
/* 620 */         if ((buffer.length() == 0) || (buffer.charAt(buffer.length() - 1) != '/'))
/*     */         {
/* 622 */           buffer.append('/');
/*     */         }
/* 624 */         buffer.append(getName());
/* 625 */         buffer.append('[');
/* 626 */         buffer.append(getRelativePositionByName());
/* 627 */         buffer.append(']');
/*     */       }
/*     */     }
/* 630 */     else if (((this.node instanceof Text)) || ((this.node instanceof CDATA))) {
/* 631 */       buffer.append("/text()");
/* 632 */       buffer.append('[').append(getRelativePositionOfTextNode()).append(']');
/*     */ 
/*     */     }
/* 635 */     else if ((this.node instanceof ProcessingInstruction)) {
/* 636 */       String target = ((ProcessingInstruction)this.node).getTarget();
/* 637 */       buffer.append("/processing-instruction('").append(target).append("')");
/*     */       
/* 639 */       buffer.append('[').append(getRelativePositionOfPI(target)).append(']');
/*     */     }
/*     */     
/* 642 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private String escape(String string) {
/* 646 */     int index = string.indexOf('\'');
/* 647 */     while (index != -1) {
/* 648 */       string = string.substring(0, index) + "&apos;" + string.substring(index + 1);
/*     */       
/*     */ 
/*     */ 
/* 652 */       index = string.indexOf('\'');
/*     */     }
/* 654 */     index = string.indexOf('"');
/* 655 */     while (index != -1) {
/* 656 */       string = string.substring(0, index) + "&quot;" + string.substring(index + 1);
/*     */       
/*     */ 
/*     */ 
/* 660 */       index = string.indexOf('"');
/*     */     }
/* 662 */     return string;
/*     */   }
/*     */   
/*     */   private int getRelativePositionByName() {
/* 666 */     if ((this.node instanceof Element)) {
/* 667 */       Element parent = ((Element)this.node).getParent();
/* 668 */       if (parent == null) {
/* 669 */         return 1;
/*     */       }
/* 671 */       List children = parent.getContent();
/* 672 */       int count = 0;
/* 673 */       String name = ((Element)this.node).getQualifiedName();
/* 674 */       for (int i = 0; i < children.size(); i++) {
/* 675 */         Object child = children.get(i);
/* 676 */         if (((child instanceof Element)) && (((Element)child).getQualifiedName().equals(name)))
/*     */         {
/* 678 */           count++;
/*     */         }
/* 680 */         if (child == this.node) {
/*     */           break;
/*     */         }
/*     */       }
/* 684 */       return count;
/*     */     }
/* 686 */     return 1;
/*     */   }
/*     */   
/*     */   private int getRelativePositionOfTextNode() {
/*     */     Element parent;
/* 691 */     if ((this.node instanceof Text)) {
/* 692 */       parent = ((Text)this.node).getParent();
/*     */     }
/*     */     else {
/* 695 */       parent = ((CDATA)this.node).getParent();
/*     */     }
/* 697 */     if (parent == null) {
/* 698 */       return 1;
/*     */     }
/* 700 */     List children = parent.getContent();
/* 701 */     int count = 0;
/* 702 */     for (int i = 0; i < children.size(); i++) {
/* 703 */       Object child = children.get(i);
/* 704 */       if (((child instanceof Text)) || ((child instanceof CDATA))) {
/* 705 */         count++;
/*     */       }
/* 707 */       if (child == this.node) {
/*     */         break;
/*     */       }
/*     */     }
/* 711 */     return count;
/*     */   }
/*     */   
/*     */   private int getRelativePositionOfPI(String target) {
/* 715 */     Element parent = ((ProcessingInstruction)this.node).getParent();
/* 716 */     if (parent == null) {
/* 717 */       return 1;
/*     */     }
/* 719 */     List children = parent.getContent();
/* 720 */     int count = 0;
/* 721 */     for (int i = 0; i < children.size(); i++) {
/* 722 */       Object child = children.get(i);
/* 723 */       if (((child instanceof ProcessingInstruction)) && ((target == null) || (target.equals(((ProcessingInstruction)child).getTarget()))))
/*     */       {
/*     */ 
/*     */ 
/* 727 */         count++;
/*     */       }
/* 729 */       if (child == this.node) {
/*     */         break;
/*     */       }
/*     */     }
/* 733 */     return count;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 737 */     return System.identityHashCode(this.node);
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 741 */     if (object == this) {
/* 742 */       return true;
/*     */     }
/*     */     
/* 745 */     if (!(object instanceof JDOMNodePointer)) {
/* 746 */       return false;
/*     */     }
/*     */     
/* 749 */     JDOMNodePointer other = (JDOMNodePointer)object;
/* 750 */     return this.node == other.node;
/*     */   }
/*     */   
/* 753 */   private AbstractFactory getAbstractFactory(JXPathContext context) { AbstractFactory factory = context.getFactory();
/* 754 */     if (factory == null) {
/* 755 */       throw new JXPathException("Factory is not set on the JXPathContext - cannot create path: " + asPath());
/*     */     }
/*     */     
/*     */ 
/* 759 */     return factory;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/jdom/JDOMNodePointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */