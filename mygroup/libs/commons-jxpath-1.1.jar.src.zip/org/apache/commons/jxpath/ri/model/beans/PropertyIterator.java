/*     */ package org.apache.commons.jxpath.ri.model.beans;
/*     */ 
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyIterator
/*     */   implements NodeIterator
/*     */ {
/*  76 */   private boolean empty = false;
/*     */   private boolean reverse;
/*     */   private String name;
/*  79 */   private int startIndex = 0;
/*  80 */   private boolean targetReady = false;
/*  81 */   private int position = 0;
/*     */   
/*     */   private PropertyPointer propertyNodePointer;
/*     */   private int startPropertyIndex;
/*  85 */   private boolean ready = false;
/*  86 */   private boolean includeStart = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertyIterator(PropertyOwnerPointer pointer, String name, boolean reverse, NodePointer startWith)
/*     */   {
/*  94 */     this.propertyNodePointer = pointer.getPropertyPointer();
/*  95 */     this.name = name;
/*  96 */     this.reverse = reverse;
/*  97 */     this.includeStart = true;
/*  98 */     if (reverse) {
/*  99 */       this.startPropertyIndex = Integer.MIN_VALUE;
/* 100 */       this.startIndex = -1;
/*     */     }
/* 102 */     if (startWith != null) {
/* 103 */       while ((startWith != null) && (startWith.getParent() != pointer)) {
/* 104 */         startWith = startWith.getParent();
/*     */       }
/* 106 */       if (startWith == null) {
/* 107 */         throw new JXPathException("PropertyIerator startWith parameter is not a child of the supplied parent");
/*     */       }
/*     */       
/*     */ 
/* 111 */       this.startPropertyIndex = ((PropertyPointer)startWith).getPropertyIndex();
/*     */       
/* 113 */       this.startIndex = startWith.getIndex();
/* 114 */       if (this.startIndex == Integer.MIN_VALUE) {
/* 115 */         this.startIndex = 0;
/*     */       }
/* 117 */       this.includeStart = false;
/* 118 */       if ((reverse) && (this.startIndex == -1)) {
/* 119 */         this.includeStart = true;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected NodePointer getPropertyPointer() {
/* 125 */     return this.propertyNodePointer;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 129 */     this.position = 0;
/* 130 */     this.targetReady = false;
/*     */   }
/*     */   
/*     */   public NodePointer getNodePointer() {
/* 134 */     if (this.position == 0) {
/* 135 */       if (this.name != null) {
/* 136 */         if (!this.targetReady) {
/* 137 */           prepareForIndividualProperty(this.name);
/*     */         }
/*     */         
/* 140 */         if (this.empty) {
/* 141 */           return null;
/*     */         }
/*     */       }
/*     */       else {
/* 145 */         if (!setPosition(1)) {
/* 146 */           return null;
/*     */         }
/* 148 */         reset();
/*     */       }
/*     */     }
/*     */     try {
/* 152 */       NodePointer clone = (NodePointer)this.propertyNodePointer.clone();
/* 153 */       return clone.getValuePointer();
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 157 */       NullPropertyPointer npp = new NullPropertyPointer(this.propertyNodePointer.getParent());
/*     */       
/* 159 */       npp.setPropertyName(this.propertyNodePointer.getPropertyName());
/* 160 */       npp.setIndex(this.propertyNodePointer.getIndex());
/* 161 */       return npp.getValuePointer();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getPosition() {
/* 166 */     return this.position;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 170 */     if (this.name != null) {
/* 171 */       return setPositionIndividualProperty(position);
/*     */     }
/*     */     
/* 174 */     return setPositionAllProperties(position);
/*     */   }
/*     */   
/*     */   private boolean setPositionIndividualProperty(int position)
/*     */   {
/* 179 */     this.position = position;
/* 180 */     if (position < 1) {
/* 181 */       return false;
/*     */     }
/*     */     
/* 184 */     if (!this.targetReady) {
/* 185 */       prepareForIndividualProperty(this.name);
/*     */     }
/*     */     
/* 188 */     if (this.empty) {
/* 189 */       return false;
/*     */     }
/*     */     
/* 192 */     int length = getLength();
/*     */     int index;
/* 194 */     if (!this.reverse) {
/* 195 */       index = position + this.startIndex;
/* 196 */       if (!this.includeStart) {
/* 197 */         index++;
/*     */       }
/* 199 */       if (index > length) {
/* 200 */         return false;
/*     */       }
/*     */     }
/*     */     else {
/* 204 */       int end = this.startIndex;
/* 205 */       if (end == -1) {
/* 206 */         end = length - 1;
/*     */       }
/* 208 */       index = end - position + 2;
/* 209 */       if (!this.includeStart) {
/* 210 */         index--;
/*     */       }
/* 212 */       if (index < 1) {
/* 213 */         return false;
/*     */       }
/*     */     }
/* 216 */     this.propertyNodePointer.setIndex(index - 1);
/* 217 */     return true;
/*     */   }
/*     */   
/*     */   private boolean setPositionAllProperties(int position) {
/* 221 */     this.position = position;
/* 222 */     if (position < 1) {
/* 223 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 227 */     int count = this.propertyNodePointer.getPropertyCount();
/* 228 */     int offset; if (!this.reverse) {
/* 229 */       int index = 1;
/* 230 */       for (int i = this.startPropertyIndex; i < count; i++) {
/* 231 */         this.propertyNodePointer.setPropertyIndex(i);
/* 232 */         int length = getLength();
/* 233 */         if (i == this.startPropertyIndex) {
/* 234 */           length -= this.startIndex;
/* 235 */           if (!this.includeStart) {
/* 236 */             length--;
/*     */           }
/* 238 */           offset = this.startIndex + position - index;
/* 239 */           if (!this.includeStart) {
/* 240 */             offset++;
/*     */           }
/*     */         }
/*     */         else {
/* 244 */           offset = position - index;
/*     */         }
/* 246 */         if ((index <= position) && (position < index + length)) {
/* 247 */           this.propertyNodePointer.setIndex(offset);
/* 248 */           return true;
/*     */         }
/* 250 */         index += length;
/*     */       }
/*     */     }
/*     */     else {
/* 254 */       int index = 1;
/* 255 */       int start = this.startPropertyIndex;
/* 256 */       if (start == Integer.MIN_VALUE) {
/* 257 */         start = count - 1;
/*     */       }
/* 259 */       for (int i = start; i >= 0; i--) {
/* 260 */         this.propertyNodePointer.setPropertyIndex(i);
/* 261 */         int length = getLength();
/* 262 */         if (i == this.startPropertyIndex) {
/* 263 */           int end = this.startIndex;
/* 264 */           if (end == -1) {
/* 265 */             end = length - 1;
/*     */           }
/* 267 */           length = end + 1;
/* 268 */           offset = end - position + 1;
/* 269 */           if (!this.includeStart) {
/* 270 */             offset--;
/* 271 */             length--;
/*     */           }
/*     */         }
/*     */         else {
/* 275 */           offset = length - (position - index) - 1;
/*     */         }
/*     */         
/* 278 */         if ((index <= position) && (position < index + length)) {
/* 279 */           this.propertyNodePointer.setIndex(offset);
/* 280 */           return true;
/*     */         }
/* 282 */         index += length;
/*     */       }
/*     */     }
/* 285 */     return false;
/*     */   }
/*     */   
/*     */   protected void prepareForIndividualProperty(String name) {
/* 289 */     this.targetReady = true;
/* 290 */     this.empty = true;
/*     */     
/* 292 */     String[] names = this.propertyNodePointer.getPropertyNames();
/* 293 */     if (!this.reverse) {
/* 294 */       if (this.startPropertyIndex == Integer.MIN_VALUE) {
/* 295 */         this.startPropertyIndex = 0;
/*     */       }
/* 297 */       if (this.startIndex == Integer.MIN_VALUE) {
/* 298 */         this.startIndex = 0;
/*     */       }
/* 300 */       for (int i = this.startPropertyIndex; i < names.length; i++) {
/* 301 */         if (names[i].equals(name)) {
/* 302 */           this.propertyNodePointer.setPropertyIndex(i);
/* 303 */           if (i != this.startPropertyIndex) {
/* 304 */             this.startIndex = 0;
/* 305 */             this.includeStart = true;
/*     */           }
/* 307 */           this.empty = false;
/* 308 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 313 */       if (this.startPropertyIndex == Integer.MIN_VALUE) {
/* 314 */         this.startPropertyIndex = (names.length - 1);
/*     */       }
/* 316 */       if (this.startIndex == Integer.MIN_VALUE) {
/* 317 */         this.startIndex = -1;
/*     */       }
/* 319 */       for (int i = this.startPropertyIndex; i >= 0; i--) {
/* 320 */         if (names[i].equals(name)) {
/* 321 */           this.propertyNodePointer.setPropertyIndex(i);
/* 322 */           if (i != this.startPropertyIndex) {
/* 323 */             this.startIndex = -1;
/* 324 */             this.includeStart = true;
/*     */           }
/* 326 */           this.empty = false;
/* 327 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private int getLength()
/*     */   {
/*     */     int length;
/*     */     try
/*     */     {
/* 339 */       length = this.propertyNodePointer.getLength();
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 343 */       length = 0;
/*     */     }
/* 345 */     return length;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/beans/PropertyIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */