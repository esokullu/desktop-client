/*    */ package org.apache.commons.jxpath.ri.compiler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NameAttributeTest
/*    */   extends CoreOperationEqual
/*    */ {
/*    */   public NameAttributeTest(Expression namePath, Expression nameValue)
/*    */   {
/* 15 */     super(namePath, nameValue);
/*    */   }
/*    */   
/*    */   public Expression getNameTestExpression() {
/* 19 */     return this.args[1];
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean computeContextDependent()
/*    */   {
/* 26 */     return true;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/NameAttributeTest.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */