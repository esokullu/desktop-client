/*     */ package org.apache.commons.jxpath.ri.axes;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AncestorContext
/*     */   extends EvalContext
/*     */ {
/*     */   private NodeTest nodeTest;
/*  76 */   private boolean setStarted = false;
/*     */   
/*     */ 
/*     */ 
/*     */   private NodePointer currentNodePointer;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean includeSelf;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AncestorContext(EvalContext parentContext, boolean includeSelf, NodeTest nodeTest)
/*     */   {
/*  91 */     super(parentContext);
/*  92 */     this.includeSelf = includeSelf;
/*  93 */     this.nodeTest = nodeTest;
/*     */   }
/*     */   
/*     */   public NodePointer getCurrentNodePointer() {
/*  97 */     return this.currentNodePointer;
/*     */   }
/*     */   
/*     */   public int getDocumentOrder() {
/* 101 */     return -1;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 105 */     super.reset();
/* 106 */     this.setStarted = false;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 110 */     if (position < getCurrentPosition()) {
/* 111 */       reset();
/*     */     }
/*     */     
/* 114 */     while (getCurrentPosition() < position) {
/* 115 */       if (!nextNode()) {
/* 116 */         return false;
/*     */       }
/*     */     }
/* 119 */     return true;
/*     */   }
/*     */   
/*     */   public boolean nextNode() {
/* 123 */     if (!this.setStarted) {
/* 124 */       this.setStarted = true;
/* 125 */       this.currentNodePointer = this.parentContext.getCurrentNodePointer();
/* 126 */       if ((this.includeSelf) && 
/* 127 */         (this.currentNodePointer.testNode(this.nodeTest))) {
/* 128 */         this.position += 1;
/* 129 */         return true;
/*     */       }
/*     */     }
/*     */     
/*     */     do
/*     */     {
/* 135 */       this.currentNodePointer = this.currentNodePointer.getParent();
/*     */       
/* 137 */       if (this.currentNodePointer == null) {
/* 138 */         return false;
/*     */       }
/*     */       
/* 141 */     } while (!this.currentNodePointer.testNode(this.nodeTest));
/* 142 */     this.position += 1;
/* 143 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/axes/AncestorContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */