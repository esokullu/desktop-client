/*     */ package org.apache.commons.jxpath.ri.model.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMAttributeIterator
/*     */   implements NodeIterator
/*     */ {
/*     */   private NodePointer parent;
/*     */   private QName name;
/*     */   private List attributes;
/*  85 */   private int position = 0;
/*     */   
/*     */   public DOMAttributeIterator(NodePointer parent, QName name) {
/*  88 */     this.parent = parent;
/*  89 */     this.name = name;
/*  90 */     this.attributes = new ArrayList();
/*  91 */     Node node = (Node)parent.getNode();
/*  92 */     if (node.getNodeType() == 1) {
/*  93 */       String lname = name.getName();
/*  94 */       if (!lname.equals("*")) {
/*  95 */         Attr attr = getAttribute((Element)node, name);
/*  96 */         if (attr != null) {
/*  97 */           this.attributes.add(attr);
/*     */         }
/*     */       }
/*     */       else {
/* 101 */         NamedNodeMap map = node.getAttributes();
/* 102 */         int count = map.getLength();
/* 103 */         for (int i = 0; i < count; i++) {
/* 104 */           Attr attr = (Attr)map.item(i);
/* 105 */           if (testAttr(attr, name)) {
/* 106 */             this.attributes.add(attr);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean testAttr(Attr attr, QName testName) {
/* 114 */     String nodePrefix = DOMNodePointer.getPrefix(attr);
/* 115 */     String nodeLocalName = DOMNodePointer.getLocalName(attr);
/*     */     
/* 117 */     if ((nodePrefix != null) && (nodePrefix.equals("xmlns"))) {
/* 118 */       return false;
/*     */     }
/*     */     
/* 121 */     if ((nodePrefix == null) && (nodeLocalName.equals("xmlns"))) {
/* 122 */       return false;
/*     */     }
/*     */     
/* 125 */     String testLocalName = this.name.getName();
/* 126 */     if ((testLocalName.equals("*")) || (testLocalName.equals(nodeLocalName))) {
/* 127 */       String testPrefix = testName.getPrefix();
/*     */       
/* 129 */       if (equalStrings(testPrefix, nodePrefix)) {
/* 130 */         return true;
/*     */       }
/*     */       
/* 133 */       String testNS = null;
/* 134 */       if (testPrefix != null) {
/* 135 */         testNS = this.parent.getNamespaceURI(testPrefix);
/*     */       }
/*     */       
/* 138 */       String nodeNS = null;
/* 139 */       if (nodePrefix != null) {
/* 140 */         nodeNS = this.parent.getNamespaceURI(nodePrefix);
/*     */       }
/* 142 */       return equalStrings(testNS, nodeNS);
/*     */     }
/* 144 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean equalStrings(String s1, String s2) {
/* 148 */     if ((s1 == null) && (s2 != null)) {
/* 149 */       return false;
/*     */     }
/* 151 */     if ((s1 != null) && (!s1.equals(s2))) {
/* 152 */       return false;
/*     */     }
/* 154 */     return true;
/*     */   }
/*     */   
/*     */   private Attr getAttribute(Element element, QName name) {
/* 158 */     String testPrefix = name.getPrefix();
/* 159 */     String testNS = null;
/*     */     
/* 161 */     if (testPrefix != null) {
/* 162 */       testNS = this.parent.getNamespaceURI(testPrefix);
/*     */     }
/*     */     
/* 165 */     if (testNS != null) {
/* 166 */       Attr attr = element.getAttributeNodeNS(testNS, name.getName());
/* 167 */       if (attr != null) {
/* 168 */         return attr;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 174 */       NamedNodeMap nnm = element.getAttributes();
/* 175 */       for (int i = 0; i < nnm.getLength(); i++) {
/* 176 */         attr = (Attr)nnm.item(i);
/* 177 */         if (testAttr(attr, name)) {
/* 178 */           return attr;
/*     */         }
/*     */       }
/* 181 */       return null;
/*     */     }
/*     */     
/* 184 */     return element.getAttributeNode(name.getName());
/*     */   }
/*     */   
/*     */   public NodePointer getNodePointer()
/*     */   {
/* 189 */     if (this.position == 0) {
/* 190 */       if (!setPosition(1)) {
/* 191 */         return null;
/*     */       }
/* 193 */       this.position = 0;
/*     */     }
/* 195 */     int index = this.position - 1;
/* 196 */     if (index < 0) {
/* 197 */       index = 0;
/*     */     }
/* 199 */     return new DOMAttributePointer(this.parent, (Attr)this.attributes.get(index));
/*     */   }
/*     */   
/*     */   public int getPosition() {
/* 203 */     return this.position;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 207 */     this.position = position;
/* 208 */     return (position >= 1) && (position <= this.attributes.size());
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dom/DOMAttributeIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */