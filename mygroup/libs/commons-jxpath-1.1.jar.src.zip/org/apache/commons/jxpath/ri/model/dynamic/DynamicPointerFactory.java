/*     */ package org.apache.commons.jxpath.ri.model.dynamic;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.DynamicPropertyHandler;
/*     */ import org.apache.commons.jxpath.JXPathBeanInfo;
/*     */ import org.apache.commons.jxpath.JXPathIntrospector;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointerFactory;
/*     */ import org.apache.commons.jxpath.ri.model.beans.NullPointer;
/*     */ import org.apache.commons.jxpath.util.ValueUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DynamicPointerFactory
/*     */   implements NodePointerFactory
/*     */ {
/*     */   public static final int DYNAMIC_POINTER_FACTORY_ORDER = 800;
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  86 */     return 800;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createNodePointer(QName name, Object bean, Locale locale)
/*     */   {
/*  94 */     JXPathBeanInfo bi = JXPathIntrospector.getBeanInfo(bean.getClass());
/*  95 */     if (bi.isDynamic()) {
/*  96 */       DynamicPropertyHandler handler = ValueUtils.getDynamicPropertyHandler(bi.getDynamicPropertyHandlerClass());
/*     */       
/*     */ 
/*  99 */       return new DynamicPointer(name, bean, handler, locale);
/*     */     }
/* 101 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createNodePointer(NodePointer parent, QName name, Object bean)
/*     */   {
/* 109 */     if (bean == null) {
/* 110 */       return new NullPointer(parent, name);
/*     */     }
/*     */     
/* 113 */     JXPathBeanInfo bi = JXPathIntrospector.getBeanInfo(bean.getClass());
/* 114 */     if (bi.isDynamic()) {
/* 115 */       DynamicPropertyHandler handler = ValueUtils.getDynamicPropertyHandler(bi.getDynamicPropertyHandlerClass());
/*     */       
/*     */ 
/* 118 */       return new DynamicPointer(parent, name, bean, handler);
/*     */     }
/* 120 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dynamic/DynamicPointerFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */