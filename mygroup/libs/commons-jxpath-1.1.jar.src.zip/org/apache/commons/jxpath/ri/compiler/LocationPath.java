/*     */ package org.apache.commons.jxpath.ri.compiler;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.axes.InitialContext;
/*     */ import org.apache.commons.jxpath.ri.axes.RootContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocationPath
/*     */   extends Path
/*     */ {
/*     */   private boolean absolute;
/*     */   
/*     */   public LocationPath(boolean absolute, Step[] steps)
/*     */   {
/*  76 */     super(steps);
/*  77 */     this.absolute = absolute;
/*     */   }
/*     */   
/*     */   public boolean isAbsolute() {
/*  81 */     return this.absolute;
/*     */   }
/*     */   
/*     */   public boolean computeContextDependent() {
/*  85 */     if (!this.absolute) {
/*  86 */       return true;
/*     */     }
/*     */     
/*  89 */     return super.computeContextDependent();
/*     */   }
/*     */   
/*     */   public String toString() {
/*  93 */     StringBuffer buffer = new StringBuffer();
/*  94 */     Step[] steps = getSteps();
/*  95 */     if (steps != null) {
/*  96 */       for (int i = 0; i < steps.length; i++) {
/*  97 */         if ((i > 0) || (this.absolute)) {
/*  98 */           buffer.append('/');
/*     */         }
/* 100 */         buffer.append(steps[i]);
/*     */       }
/*     */     }
/* 103 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public Object compute(EvalContext context)
/*     */   {
/*     */     EvalContext rootContext;
/* 109 */     if (isAbsolute()) {
/* 110 */       rootContext = context.getRootContext().getAbsoluteRootContext();
/*     */     }
/*     */     else {
/* 113 */       rootContext = new InitialContext(context);
/*     */     }
/* 115 */     return evalSteps(rootContext);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object computeValue(EvalContext context)
/*     */   {
/*     */     EvalContext rootContext;
/* 122 */     if (isAbsolute()) {
/* 123 */       rootContext = context.getRootContext().getAbsoluteRootContext();
/*     */     }
/*     */     else {
/* 126 */       rootContext = new InitialContext(context);
/*     */     }
/* 128 */     return getSingleNodePointerForSteps(rootContext);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/LocationPath.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */