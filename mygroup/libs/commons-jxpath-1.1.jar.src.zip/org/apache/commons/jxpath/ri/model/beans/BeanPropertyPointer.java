/*     */ package org.apache.commons.jxpath.ri.model.beans;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import org.apache.commons.jxpath.JXPathBeanInfo;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.util.ValueUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanPropertyPointer
/*     */   extends PropertyPointer
/*     */ {
/*     */   private String propertyName;
/*     */   private JXPathBeanInfo beanInfo;
/*     */   private PropertyDescriptor[] propertyDescriptors;
/*     */   private PropertyDescriptor propertyDescriptor;
/*     */   private String[] names;
/*  84 */   private static final Object UNINITIALIZED = new Object();
/*  85 */   private Object baseValue = UNINITIALIZED;
/*  86 */   private Object value = UNINITIALIZED;
/*     */   
/*     */   public BeanPropertyPointer(NodePointer parent, JXPathBeanInfo beanInfo) {
/*  89 */     super(parent);
/*  90 */     this.beanInfo = beanInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isContainer()
/*     */   {
/*  97 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPropertyCount()
/*     */   {
/* 104 */     return getPropertyDescriptors().length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getPropertyNames()
/*     */   {
/* 111 */     if (this.names == null) {
/* 112 */       PropertyDescriptor[] pds = getPropertyDescriptors();
/* 113 */       this.names = new String[pds.length];
/* 114 */       for (int i = 0; i < this.names.length; i++) {
/* 115 */         this.names[i] = pds[i].getName();
/*     */       }
/*     */     }
/* 118 */     return this.names;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPropertyName(String propertyName)
/*     */   {
/* 125 */     setPropertyIndex(Integer.MIN_VALUE);
/* 126 */     this.propertyName = propertyName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPropertyIndex(int index)
/*     */   {
/* 133 */     if (this.propertyIndex != index) {
/* 134 */       super.setPropertyIndex(index);
/* 135 */       this.propertyName = null;
/* 136 */       this.propertyDescriptor = null;
/* 137 */       this.baseValue = UNINITIALIZED;
/* 138 */       this.value = UNINITIALIZED;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getBaseValue()
/*     */   {
/* 146 */     if (this.baseValue == UNINITIALIZED) {
/* 147 */       PropertyDescriptor pd = getPropertyDescriptor();
/* 148 */       if (pd == null) {
/* 149 */         return null;
/*     */       }
/* 151 */       this.baseValue = ValueUtils.getValue(getBean(), pd);
/*     */     }
/* 153 */     return this.baseValue;
/*     */   }
/*     */   
/*     */   public void setIndex(int index) {
/* 157 */     if (this.index != index)
/*     */     {
/*     */ 
/* 160 */       if ((this.index != Integer.MIN_VALUE) || (index != 0) || (isCollection()))
/*     */       {
/*     */ 
/* 163 */         super.setIndex(index);
/* 164 */         this.value = UNINITIALIZED;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getImmediateNode()
/*     */   {
/* 176 */     if (this.value == UNINITIALIZED) {
/* 177 */       Object baseValue = getBaseValue();
/* 178 */       if (this.index == Integer.MIN_VALUE) {
/* 179 */         this.value = baseValue;
/*     */       }
/* 181 */       else if ((this.value != null) && (this.index >= 0) && (this.index < getLength())) {
/* 182 */         this.value = ValueUtils.getValue(baseValue, this.index);
/*     */       }
/*     */       else {
/* 185 */         this.value = null;
/*     */       }
/*     */     }
/* 188 */     return this.value;
/*     */   }
/*     */   
/*     */   protected boolean isActualProperty() {
/* 192 */     return getPropertyDescriptor() != null;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 196 */     PropertyDescriptor pd = getPropertyDescriptor();
/* 197 */     if (pd == null) {
/* 198 */       return false;
/*     */     }
/*     */     
/* 201 */     int hint = ValueUtils.getCollectionHint(pd.getPropertyType());
/* 202 */     if (hint == -1) {
/* 203 */       return false;
/*     */     }
/* 205 */     if (hint == 1) {
/* 206 */       return true;
/*     */     }
/*     */     
/* 209 */     Object value = getBaseValue();
/* 210 */     return (value != null) && (ValueUtils.isCollection(value));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 218 */     PropertyDescriptor pd = getPropertyDescriptor();
/* 219 */     if (pd == null) {
/* 220 */       return 1;
/*     */     }
/*     */     
/* 223 */     int hint = ValueUtils.getCollectionHint(pd.getPropertyType());
/* 224 */     if (hint == -1) {
/* 225 */       return 1;
/*     */     }
/* 227 */     return ValueUtils.getLength(getBaseValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/* 236 */     PropertyDescriptor pd = getPropertyDescriptor();
/* 237 */     if (pd == null) {
/* 238 */       throw new JXPathException("Cannot set property: " + asPath() + " - no such property");
/*     */     }
/*     */     
/*     */ 
/* 242 */     if (this.index == Integer.MIN_VALUE) {
/* 243 */       ValueUtils.setValue(getBean(), pd, value);
/*     */     }
/*     */     else {
/* 246 */       ValueUtils.setValue(getBean(), pd, this.index, value);
/*     */     }
/* 248 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public NodePointer createPath(JXPathContext context)
/*     */   {
/* 255 */     if (getImmediateNode() == null) {
/* 256 */       super.createPath(context);
/* 257 */       this.baseValue = UNINITIALIZED;
/* 258 */       this.value = UNINITIALIZED;
/*     */     }
/* 260 */     return this;
/*     */   }
/*     */   
/*     */   public void remove() {
/* 264 */     if (this.index == Integer.MIN_VALUE) {
/* 265 */       setValue(null);
/*     */     }
/* 267 */     else if (isCollection()) {
/* 268 */       Object collection = ValueUtils.remove(getBaseValue(), this.index);
/* 269 */       ValueUtils.setValue(getBean(), getPropertyDescriptor(), collection);
/*     */     }
/* 271 */     else if (this.index == 0) {
/* 272 */       this.index = Integer.MIN_VALUE;
/* 273 */       setValue(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getPropertyName()
/*     */   {
/* 281 */     if (this.propertyName == null) {
/* 282 */       PropertyDescriptor pd = getPropertyDescriptor();
/* 283 */       if (pd != null) {
/* 284 */         this.propertyName = pd.getName();
/*     */       }
/*     */     }
/* 287 */     return this.propertyName != null ? this.propertyName : "*";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private PropertyDescriptor getPropertyDescriptor()
/*     */   {
/* 295 */     if (this.propertyDescriptor == null) {
/* 296 */       int inx = getPropertyIndex();
/* 297 */       if (inx == Integer.MIN_VALUE) {
/* 298 */         this.propertyDescriptor = this.beanInfo.getPropertyDescriptor(this.propertyName);
/*     */       }
/*     */       else
/*     */       {
/* 302 */         PropertyDescriptor[] propertyDescriptors = getPropertyDescriptors();
/*     */         
/* 304 */         if ((inx >= 0) && (inx < propertyDescriptors.length)) {
/* 305 */           this.propertyDescriptor = propertyDescriptors[inx];
/*     */         }
/*     */         else {
/* 308 */           this.propertyDescriptor = null;
/*     */         }
/*     */       }
/*     */     }
/* 312 */     return this.propertyDescriptor;
/*     */   }
/*     */   
/*     */   protected PropertyDescriptor[] getPropertyDescriptors() {
/* 316 */     if (this.propertyDescriptors == null) {
/* 317 */       this.propertyDescriptors = this.beanInfo.getPropertyDescriptors();
/*     */     }
/* 319 */     return this.propertyDescriptors;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/beans/BeanPropertyPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */