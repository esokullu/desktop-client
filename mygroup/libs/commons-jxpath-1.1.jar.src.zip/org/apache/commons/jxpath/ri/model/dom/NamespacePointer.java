/*     */ package org.apache.commons.jxpath.ri.model.dom;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamespacePointer
/*     */   extends NodePointer
/*     */ {
/*     */   private String prefix;
/*     */   private String namespaceURI;
/*     */   
/*     */   public NamespacePointer(NodePointer parent, String prefix)
/*     */   {
/*  81 */     super(parent);
/*  82 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamespacePointer(NodePointer parent, String prefix, String namespaceURI)
/*     */   {
/*  90 */     super(parent);
/*  91 */     this.prefix = prefix;
/*  92 */     this.namespaceURI = namespaceURI;
/*     */   }
/*     */   
/*     */   public QName getName() {
/*  96 */     return new QName(getNamespaceURI(), this.prefix);
/*     */   }
/*     */   
/*     */   public Object getBaseValue() {
/* 100 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 104 */     return false;
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 108 */     return 1;
/*     */   }
/*     */   
/*     */   public Object getImmediateNode() {
/* 112 */     return getNamespaceURI();
/*     */   }
/*     */   
/*     */   public String getNamespaceURI() {
/* 116 */     if (this.namespaceURI == null) {
/* 117 */       this.namespaceURI = this.parent.getNamespaceURI(this.prefix);
/*     */     }
/* 119 */     return this.namespaceURI;
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 123 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/* 130 */     throw new UnsupportedOperationException("Cannot modify DOM trees");
/*     */   }
/*     */   
/*     */   public boolean testNode(NodeTest nodeTest) {
/* 134 */     return (nodeTest == null) || (((nodeTest instanceof NodeTypeTest)) && (((NodeTypeTest)nodeTest).getNodeType() == 1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String asPath()
/*     */   {
/* 141 */     StringBuffer buffer = new StringBuffer();
/* 142 */     if (this.parent != null) {
/* 143 */       buffer.append(this.parent.asPath());
/* 144 */       if ((buffer.length() == 0) || (buffer.charAt(buffer.length() - 1) != '/'))
/*     */       {
/* 146 */         buffer.append('/');
/*     */       }
/*     */     }
/* 149 */     buffer.append("namespace::");
/* 150 */     buffer.append(this.prefix);
/* 151 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 155 */     return this.prefix.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 159 */     if (object == this) {
/* 160 */       return true;
/*     */     }
/*     */     
/* 163 */     if (!(object instanceof NamespacePointer)) {
/* 164 */       return false;
/*     */     }
/*     */     
/* 167 */     NamespacePointer other = (NamespacePointer)object;
/* 168 */     return this.prefix.equals(other.prefix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2)
/*     */   {
/* 176 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dom/NamespacePointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */