/*     */ package org.apache.commons.jxpath.ri.model.beans;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanAttributeIterator
/*     */   extends PropertyIterator
/*     */ {
/*     */   private NodePointer parent;
/*  76 */   private int position = 0;
/*     */   private boolean includeXmlLang;
/*     */   
/*     */   public BeanAttributeIterator(PropertyOwnerPointer parent, QName name) {
/*  80 */     super(parent, (name.getPrefix() == null) && ((name.getName() == null) || (name.getName().equals("*"))) ? null : name.toString(), false, null);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */     this.parent = parent;
/*  89 */     this.includeXmlLang = ((name.getPrefix() != null) && (name.getPrefix().equals("xml")) && ((name.getName().equals("lang")) || (name.getName().equals("*"))));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public NodePointer getNodePointer()
/*     */   {
/*  96 */     if ((this.includeXmlLang) && (this.position == 1)) {
/*  97 */       return new LangAttributePointer(this.parent);
/*     */     }
/*     */     
/* 100 */     return super.getNodePointer();
/*     */   }
/*     */   
/*     */   public int getPosition()
/*     */   {
/* 105 */     return this.position;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 109 */     this.position = position;
/* 110 */     if (this.includeXmlLang) {
/* 111 */       if (position == 1) {
/* 112 */         return true;
/*     */       }
/*     */       
/* 115 */       return super.setPosition(position - 1);
/*     */     }
/*     */     
/*     */ 
/* 119 */     this.position = position;
/* 120 */     return super.setPosition(position);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/beans/BeanAttributeIterator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */