package org.apache.commons.jxpath.ri.model;

import java.util.Locale;
import org.apache.commons.jxpath.ri.QName;

public abstract interface NodePointerFactory
{
  public abstract int getOrder();
  
  public abstract NodePointer createNodePointer(QName paramQName, Object paramObject, Locale paramLocale);
  
  public abstract NodePointer createNodePointer(NodePointer paramNodePointer, QName paramQName, Object paramObject);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/NodePointerFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */