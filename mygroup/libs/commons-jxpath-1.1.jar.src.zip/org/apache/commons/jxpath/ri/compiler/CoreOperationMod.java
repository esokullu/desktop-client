/*    */ package org.apache.commons.jxpath.ri.compiler;
/*    */ 
/*    */ import org.apache.commons.jxpath.ri.EvalContext;
/*    */ import org.apache.commons.jxpath.ri.InfoSetUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoreOperationMod
/*    */   extends CoreOperation
/*    */ {
/*    */   public CoreOperationMod(Expression arg1, Expression arg2)
/*    */   {
/* 68 */     super(new Expression[] { arg1, arg2 });
/*    */   }
/*    */   
/*    */   public Object computeValue(EvalContext context) {
/* 72 */     long l = InfoSetUtil.doubleValue(this.args[0].computeValue(context));
/* 73 */     long r = InfoSetUtil.doubleValue(this.args[1].computeValue(context));
/* 74 */     return new Double(l % r);
/*    */   }
/*    */   
/*    */   protected int getPrecedence() {
/* 78 */     return 5;
/*    */   }
/*    */   
/*    */   protected boolean isSymmetric() {
/* 82 */     return false;
/*    */   }
/*    */   
/*    */   public String getSymbol() {
/* 86 */     return "mod";
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/CoreOperationMod.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */