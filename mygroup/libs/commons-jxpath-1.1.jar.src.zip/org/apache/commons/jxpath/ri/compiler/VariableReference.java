/*     */ package org.apache.commons.jxpath.ri.compiler;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.axes.RootContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariableReference
/*     */   extends Expression
/*     */ {
/*     */   private QName varName;
/*     */   
/*     */   public VariableReference(QName varName)
/*     */   {
/*  78 */     this.varName = varName;
/*     */   }
/*     */   
/*     */   public QName getVariableName() {
/*  82 */     return this.varName;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  86 */     return "$" + this.varName;
/*     */   }
/*     */   
/*     */   public boolean isContextDependent() {
/*  90 */     return false;
/*     */   }
/*     */   
/*     */   public boolean computeContextDependent() {
/*  94 */     return false;
/*     */   }
/*     */   
/*     */   public Object compute(EvalContext context) {
/*  98 */     return computeValue(context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object computeValue(EvalContext context)
/*     */   {
/* 105 */     return context.getRootContext().getVariableContext(this.varName);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/VariableReference.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */