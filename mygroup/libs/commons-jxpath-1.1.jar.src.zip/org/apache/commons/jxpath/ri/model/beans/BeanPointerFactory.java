/*     */ package org.apache.commons.jxpath.ri.model.beans;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.JXPathBeanInfo;
/*     */ import org.apache.commons.jxpath.JXPathIntrospector;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanPointerFactory
/*     */   implements NodePointerFactory
/*     */ {
/*     */   public static final int BEAN_POINTER_FACTORY_ORDER = 900;
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  83 */     return 900;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createNodePointer(QName name, Object bean, Locale locale)
/*     */   {
/*  91 */     JXPathBeanInfo bi = JXPathIntrospector.getBeanInfo(bean.getClass());
/*  92 */     return new BeanPointer(name, bean, bi, locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createNodePointer(NodePointer parent, QName name, Object bean)
/*     */   {
/* 100 */     if (bean == null) {
/* 101 */       return new NullPointer(parent, name);
/*     */     }
/*     */     
/* 104 */     JXPathBeanInfo bi = JXPathIntrospector.getBeanInfo(bean.getClass());
/* 105 */     return new BeanPointer(parent, name, bean, bi);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/beans/BeanPointerFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */