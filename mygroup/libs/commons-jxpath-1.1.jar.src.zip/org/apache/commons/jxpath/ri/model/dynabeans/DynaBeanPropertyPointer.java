/*     */ package org.apache.commons.jxpath.ri.model.dynabeans;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.beanutils.DynaBean;
/*     */ import org.apache.commons.beanutils.DynaClass;
/*     */ import org.apache.commons.beanutils.DynaProperty;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.PropertyPointer;
/*     */ import org.apache.commons.jxpath.util.TypeUtils;
/*     */ import org.apache.commons.jxpath.util.ValueUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DynaBeanPropertyPointer
/*     */   extends PropertyPointer
/*     */ {
/*     */   private DynaBean dynaBean;
/*     */   private String name;
/*     */   private String[] names;
/*     */   
/*     */   public DynaBeanPropertyPointer(NodePointer parent, DynaBean dynaBean)
/*     */   {
/*  87 */     super(parent);
/*  88 */     this.dynaBean = dynaBean;
/*     */   }
/*     */   
/*     */   public Object getBaseValue() {
/*  92 */     return this.dynaBean.get(getPropertyName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isContainer()
/*     */   {
/*  99 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPropertyCount()
/*     */   {
/* 106 */     return getPropertyNames().length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getPropertyNames()
/*     */   {
/* 115 */     if (this.names == null) {
/* 116 */       DynaClass dynaClass = this.dynaBean.getDynaClass();
/* 117 */       DynaProperty[] properties = dynaClass.getDynaProperties();
/* 118 */       int count = properties.length;
/* 119 */       boolean hasClass = dynaClass.getDynaProperty("class") != null;
/* 120 */       if (hasClass) {
/* 121 */         count--;
/*     */       }
/* 123 */       this.names = new String[count];
/* 124 */       int i = 0; for (int j = 0; i < properties.length; i++) {
/* 125 */         String name = properties[i].getName();
/* 126 */         if ((!hasClass) || (!name.equals("class"))) {
/* 127 */           this.names[(j++)] = name;
/*     */         }
/*     */       }
/* 130 */       Arrays.sort(this.names);
/*     */     }
/* 132 */     return this.names;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPropertyName()
/*     */   {
/* 140 */     if (this.name == null) {
/* 141 */       String[] names = getPropertyNames();
/* 142 */       if ((this.propertyIndex >= 0) && (this.propertyIndex < names.length)) {
/* 143 */         this.name = names[this.propertyIndex];
/*     */       }
/*     */       else {
/* 146 */         this.name = "*";
/*     */       }
/*     */     }
/* 149 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPropertyName(String propertyName)
/*     */   {
/* 156 */     setPropertyIndex(Integer.MIN_VALUE);
/* 157 */     this.name = propertyName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPropertyIndex()
/*     */   {
/* 165 */     if (this.propertyIndex == Integer.MIN_VALUE) {
/* 166 */       String[] names = getPropertyNames();
/* 167 */       for (int i = 0; i < names.length; i++) {
/* 168 */         if (names[i].equals(this.name)) {
/* 169 */           setPropertyIndex(i);
/* 170 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 174 */     return super.getPropertyIndex();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPropertyIndex(int index)
/*     */   {
/* 182 */     if (this.propertyIndex != index) {
/* 183 */       super.setPropertyIndex(index);
/* 184 */       this.name = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getImmediateNode()
/*     */   {
/* 195 */     String name = getPropertyName();
/* 196 */     if (name.equals("*")) {
/* 197 */       return null;
/*     */     }
/*     */     
/*     */     Object value;
/* 201 */     if (this.index == Integer.MIN_VALUE) {
/* 202 */       value = this.dynaBean.get(name);
/*     */     }
/* 204 */     else if (isIndexedProperty())
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/*     */ 
/* 210 */         value = this.dynaBean.get(name, this.index);
/*     */       }
/*     */       catch (ArrayIndexOutOfBoundsException ex) {
/* 213 */         value = null;
/*     */       }
/*     */       catch (IllegalArgumentException ex) {
/* 216 */         value = this.dynaBean.get(name);
/* 217 */         value = ValueUtils.getValue(value, this.index);
/*     */       }
/*     */     }
/*     */     else {
/* 221 */       value = this.dynaBean.get(name);
/* 222 */       if (ValueUtils.isCollection(value)) {
/* 223 */         value = ValueUtils.getValue(value, this.index);
/*     */       }
/* 225 */       else if (this.index != 0) {
/* 226 */         value = null;
/*     */       }
/*     */     }
/* 229 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isActualProperty()
/*     */   {
/* 236 */     DynaClass dynaClass = this.dynaBean.getDynaClass();
/* 237 */     return dynaClass.getDynaProperty(getPropertyName()) != null;
/*     */   }
/*     */   
/*     */   protected boolean isIndexedProperty() {
/* 241 */     DynaClass dynaClass = this.dynaBean.getDynaClass();
/* 242 */     DynaProperty property = dynaClass.getDynaProperty(this.name);
/* 243 */     return property.isIndexed();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/* 252 */     setValue(this.index, value);
/*     */   }
/*     */   
/*     */   public void remove() {
/* 256 */     if (this.index == Integer.MIN_VALUE) {
/* 257 */       this.dynaBean.set(getPropertyName(), null);
/*     */     }
/* 259 */     else if (isIndexedProperty()) {
/* 260 */       this.dynaBean.set(getPropertyName(), this.index, null);
/*     */     }
/* 262 */     else if (isCollection()) {
/* 263 */       Object collection = ValueUtils.remove(getBaseValue(), this.index);
/* 264 */       this.dynaBean.set(getPropertyName(), collection);
/*     */     }
/* 266 */     else if (this.index == 0) {
/* 267 */       this.dynaBean.set(getPropertyName(), null);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setValue(int index, Object value) {
/* 272 */     if (index == Integer.MIN_VALUE) {
/* 273 */       this.dynaBean.set(getPropertyName(), convert(value, false));
/*     */     }
/* 275 */     else if (isIndexedProperty()) {
/* 276 */       this.dynaBean.set(getPropertyName(), index, convert(value, true));
/*     */     }
/*     */     else {
/* 279 */       Object baseValue = this.dynaBean.get(getPropertyName());
/* 280 */       ValueUtils.setValue(baseValue, index, value);
/*     */     }
/*     */   }
/*     */   
/*     */   private Object convert(Object value, boolean element)
/*     */   {
/* 286 */     DynaClass dynaClass = this.dynaBean.getDynaClass();
/* 287 */     DynaProperty property = dynaClass.getDynaProperty(getPropertyName());
/* 288 */     Class type = property.getType();
/* 289 */     if (element) {
/* 290 */       if (type.isArray()) {
/* 291 */         type = type.getComponentType();
/*     */       }
/*     */       else {
/* 294 */         return value;
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 299 */       return TypeUtils.convert(value, type);
/*     */     }
/*     */     catch (Exception ex) {
/* 302 */       ex.printStackTrace();
/* 303 */       throw new JXPathException("Cannot convert value of class " + (value == null ? "null" : value.getClass().getName()) + " to type " + type, ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dynabeans/DynaBeanPropertyPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */