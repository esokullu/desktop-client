/*     */ package org.apache.commons.jxpath.ri.compiler;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.InfoSetUtil;
/*     */ import org.apache.commons.jxpath.ri.axes.InitialContext;
/*     */ import org.apache.commons.jxpath.ri.axes.SelfContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CoreOperationCompare
/*     */   extends CoreOperation
/*     */ {
/*     */   public CoreOperationCompare(Expression arg1, Expression arg2)
/*     */   {
/*  76 */     super(new Expression[] { arg1, arg2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean equal(EvalContext context, Expression left, Expression right)
/*     */   {
/*  87 */     Object l = left.compute(context);
/*  88 */     Object r = right.compute(context);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */     if (((l instanceof InitialContext)) || ((l instanceof SelfContext))) {
/*  95 */       l = ((EvalContext)l).getSingleNodePointer();
/*     */     }
/*     */     
/*  98 */     if (((r instanceof InitialContext)) || ((r instanceof SelfContext))) {
/*  99 */       r = ((EvalContext)r).getSingleNodePointer();
/*     */     }
/*     */     
/* 102 */     if ((l instanceof Collection)) {
/* 103 */       l = ((Collection)l).iterator();
/*     */     }
/*     */     
/* 106 */     if ((r instanceof Collection)) {
/* 107 */       r = ((Collection)r).iterator();
/*     */     }
/*     */     
/* 110 */     if (((l instanceof Iterator)) && (!(r instanceof Iterator))) {
/* 111 */       return contains((Iterator)l, r);
/*     */     }
/* 113 */     if ((!(l instanceof Iterator)) && ((r instanceof Iterator))) {
/* 114 */       return contains((Iterator)r, l);
/*     */     }
/* 116 */     if (((l instanceof Iterator)) && ((r instanceof Iterator))) {
/* 117 */       return findMatch((Iterator)l, (Iterator)r);
/*     */     }
/*     */     
/* 120 */     return equal(l, r);
/*     */   }
/*     */   
/*     */   protected boolean contains(Iterator it, Object value) {
/* 124 */     while (it.hasNext()) {
/* 125 */       Object element = it.next();
/* 126 */       if (equal(element, value)) {
/* 127 */         return true;
/*     */       }
/*     */     }
/* 130 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean findMatch(Iterator lit, Iterator rit) {
/* 134 */     HashSet left = new HashSet();
/* 135 */     while (lit.hasNext()) {
/* 136 */       left.add(lit.next());
/*     */     }
/* 138 */     while (rit.hasNext()) {
/* 139 */       if (contains(left.iterator(), rit.next())) {
/* 140 */         return true;
/*     */       }
/*     */     }
/* 143 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean equal(Object l, Object r) {
/* 147 */     if (((l instanceof Pointer)) && ((r instanceof Pointer)) && 
/* 148 */       (l.equals(r))) {
/* 149 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 153 */     if ((l instanceof Pointer)) {
/* 154 */       l = ((Pointer)l).getValue();
/*     */     }
/*     */     
/* 157 */     if ((r instanceof Pointer)) {
/* 158 */       r = ((Pointer)r).getValue();
/*     */     }
/*     */     
/* 161 */     if (l == r) {
/* 162 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 166 */     if (((l instanceof Boolean)) || ((r instanceof Boolean))) {
/* 167 */       return InfoSetUtil.booleanValue(l) == InfoSetUtil.booleanValue(r);
/*     */     }
/* 169 */     if (((l instanceof Number)) || ((r instanceof Number))) {
/* 170 */       return InfoSetUtil.doubleValue(l) == InfoSetUtil.doubleValue(r);
/*     */     }
/* 172 */     if (((l instanceof String)) || ((r instanceof String))) {
/* 173 */       return InfoSetUtil.stringValue(l).equals(InfoSetUtil.stringValue(r));
/*     */     }
/*     */     
/* 176 */     if (l == null) {
/* 177 */       return r == null;
/*     */     }
/* 179 */     return l.equals(r);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/CoreOperationCompare.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */