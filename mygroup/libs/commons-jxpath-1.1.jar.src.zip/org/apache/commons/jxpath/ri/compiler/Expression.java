/*     */ package org.apache.commons.jxpath.ri.compiler;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.axes.RootContext;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.util.ValueUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Expression
/*     */ {
/*  86 */   protected static final Double ZERO = new Double(0.0D);
/*  87 */   protected static final Double ONE = new Double(1.0D);
/*  88 */   protected static final Double NOT_A_NUMBER = new Double(NaN.0D);
/*     */   
/*  90 */   private boolean contextDependencyKnown = false;
/*     */   
/*     */ 
/*     */   private boolean contextDependent;
/*     */   
/*     */ 
/*     */   public boolean isContextDependent()
/*     */   {
/*  98 */     if (!this.contextDependencyKnown) {
/*  99 */       this.contextDependent = computeContextDependent();
/* 100 */       this.contextDependencyKnown = true;
/*     */     }
/* 102 */     return this.contextDependent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract boolean computeContextDependent();
/*     */   
/*     */ 
/*     */   public abstract Object computeValue(EvalContext paramEvalContext);
/*     */   
/*     */ 
/*     */   public abstract Object compute(EvalContext paramEvalContext);
/*     */   
/*     */ 
/*     */   public Iterator iterate(EvalContext context)
/*     */   {
/* 118 */     Object result = compute(context);
/* 119 */     if ((result instanceof EvalContext)) {
/* 120 */       return new ValueIterator((EvalContext)result);
/*     */     }
/* 122 */     return ValueUtils.iterate(result);
/*     */   }
/*     */   
/*     */   public Iterator iteratePointers(EvalContext context) {
/* 126 */     Object result = compute(context);
/* 127 */     if (result == null) {
/* 128 */       return Collections.EMPTY_LIST.iterator();
/*     */     }
/* 130 */     if ((result instanceof EvalContext)) {
/* 131 */       return (EvalContext)result;
/*     */     }
/* 133 */     return new PointerIterator(ValueUtils.iterate(result), new QName(null, "value"), context.getRootContext().getCurrentNodePointer().getLocale());
/*     */   }
/*     */   
/*     */   public static class PointerIterator implements Iterator
/*     */   {
/*     */     private Iterator iterator;
/*     */     private QName qname;
/*     */     private Locale locale;
/*     */     
/*     */     public PointerIterator(Iterator it, QName qname, Locale locale)
/*     */     {
/* 144 */       this.iterator = it;
/* 145 */       this.qname = qname;
/* 146 */       this.locale = locale;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 150 */       return this.iterator.hasNext();
/*     */     }
/*     */     
/*     */     public Object next() {
/* 154 */       Object o = this.iterator.next();
/* 155 */       return NodePointer.newNodePointer(this.qname, o, this.locale);
/*     */     }
/*     */     
/*     */     public void remove() {
/* 159 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ValueIterator implements Iterator {
/*     */     private Iterator iterator;
/*     */     
/*     */     public ValueIterator(Iterator it) {
/* 167 */       this.iterator = it;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 171 */       return this.iterator.hasNext();
/*     */     }
/*     */     
/*     */     public Object next() {
/* 175 */       Object o = this.iterator.next();
/* 176 */       if ((o instanceof Pointer)) {
/* 177 */         return ((Pointer)o).getValue();
/*     */       }
/* 179 */       return o;
/*     */     }
/*     */     
/*     */     public void remove() {
/* 183 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/Expression.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */