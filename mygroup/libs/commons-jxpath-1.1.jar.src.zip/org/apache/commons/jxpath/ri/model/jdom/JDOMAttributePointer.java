/*     */ package org.apache.commons.jxpath.ri.model.jdom;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.util.TypeUtils;
/*     */ import org.jdom.Attribute;
/*     */ import org.jdom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDOMAttributePointer
/*     */   extends NodePointer
/*     */ {
/*     */   private Attribute attr;
/*     */   
/*     */   public JDOMAttributePointer(NodePointer parent, Attribute attr)
/*     */   {
/*  79 */     super(parent);
/*  80 */     this.attr = attr;
/*     */   }
/*     */   
/*     */   public QName getName() {
/*  84 */     return new QName(JDOMNodePointer.getPrefix(this.attr), JDOMNodePointer.getLocalName(this.attr));
/*     */   }
/*     */   
/*     */ 
/*     */   public QName getExpandedName()
/*     */   {
/*  90 */     return new QName(getNamespaceURI(), this.attr.getName());
/*     */   }
/*     */   
/*     */   public String getNamespaceURI() {
/*  94 */     String uri = this.attr.getNamespaceURI();
/*  95 */     if ((uri != null) && (uri.equals(""))) {
/*  96 */       uri = null;
/*     */     }
/*  98 */     return uri;
/*     */   }
/*     */   
/*     */   public Object getBaseValue() {
/* 102 */     return this.attr;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 106 */     return false;
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 110 */     return 1;
/*     */   }
/*     */   
/*     */   public Object getImmediateNode() {
/* 114 */     String value = this.attr.getValue();
/* 115 */     if (value == null) {
/* 116 */       return null;
/*     */     }
/* 118 */     return value;
/*     */   }
/*     */   
/*     */   public boolean isActual() {
/* 122 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 126 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/* 133 */     this.attr.setValue((String)TypeUtils.convert(value, String.class));
/*     */   }
/*     */   
/*     */   public void remove() {
/* 137 */     this.attr.getParent().removeAttribute(this.attr);
/*     */   }
/*     */   
/*     */ 
/*     */   public String asPath()
/*     */   {
/* 143 */     StringBuffer buffer = new StringBuffer();
/* 144 */     if (this.parent != null) {
/* 145 */       buffer.append(this.parent.asPath());
/* 146 */       if ((buffer.length() == 0) || (buffer.charAt(buffer.length() - 1) != '/'))
/*     */       {
/* 148 */         buffer.append('/');
/*     */       }
/*     */     }
/* 151 */     buffer.append('@');
/* 152 */     buffer.append(getName());
/* 153 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 157 */     return System.identityHashCode(this.attr);
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 161 */     if (object == this) {
/* 162 */       return true;
/*     */     }
/*     */     
/* 165 */     if (!(object instanceof JDOMAttributePointer)) {
/* 166 */       return false;
/*     */     }
/*     */     
/* 169 */     JDOMAttributePointer other = (JDOMAttributePointer)object;
/* 170 */     return this.attr == other.attr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2)
/*     */   {
/* 178 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/jdom/JDOMAttributePointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */