/*     */ package org.apache.commons.jxpath.ri.model.dynabeans;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.beanutils.DynaBean;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.PropertyOwnerPointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.PropertyPointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DynaBeanPointer
/*     */   extends PropertyOwnerPointer
/*     */ {
/*     */   private QName name;
/*     */   private DynaBean dynaBean;
/*     */   
/*     */   public DynaBeanPointer(QName name, DynaBean dynaBean, Locale locale)
/*     */   {
/*  84 */     super(null, locale);
/*  85 */     this.name = name;
/*  86 */     this.dynaBean = dynaBean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public DynaBeanPointer(NodePointer parent, QName name, DynaBean dynaBean)
/*     */   {
/*  93 */     super(parent);
/*  94 */     this.name = name;
/*  95 */     this.dynaBean = dynaBean;
/*     */   }
/*     */   
/*     */   public PropertyPointer getPropertyPointer() {
/*  99 */     return new DynaBeanPropertyPointer(this, this.dynaBean);
/*     */   }
/*     */   
/*     */   public QName getName() {
/* 103 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getBaseValue()
/*     */   {
/* 110 */     return this.dynaBean;
/*     */   }
/*     */   
/*     */   public Object getImmediateNode() {
/* 114 */     return this.dynaBean;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 118 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 125 */     return 1;
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 129 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 133 */     return this.name == null ? 0 : this.name.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 137 */     if (object == this) {
/* 138 */       return true;
/*     */     }
/*     */     
/* 141 */     if (!(object instanceof DynaBeanPointer)) {
/* 142 */       return false;
/*     */     }
/*     */     
/* 145 */     DynaBeanPointer other = (DynaBeanPointer)object;
/* 146 */     if ((this.parent != other.parent) && (
/* 147 */       (this.parent == null) || (!this.parent.equals(other.parent)))) {
/* 148 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 152 */     if (((this.name == null) && (other.name != null)) || ((this.name != null) && (!this.name.equals(other.name))))
/*     */     {
/* 154 */       return false;
/*     */     }
/*     */     
/* 157 */     int iThis = this.index == Integer.MIN_VALUE ? 0 : this.index;
/* 158 */     int iOther = other.index == Integer.MIN_VALUE ? 0 : other.index;
/* 159 */     if (iThis != iOther) {
/* 160 */       return false;
/*     */     }
/*     */     
/* 163 */     return this.dynaBean == other.dynaBean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String asPath()
/*     */   {
/* 170 */     if (this.parent != null) {
/* 171 */       return super.asPath();
/*     */     }
/* 173 */     return "/";
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dynabeans/DynaBeanPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */