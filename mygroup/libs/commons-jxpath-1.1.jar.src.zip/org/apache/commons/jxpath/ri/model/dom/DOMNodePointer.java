/*     */ package org.apache.commons.jxpath.ri.model.dom;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.jxpath.AbstractFactory;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.Pointer;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
/*     */ import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodeIterator;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.NullPointer;
/*     */ import org.apache.commons.jxpath.util.TypeUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.CharacterData;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMNodePointer
/*     */   extends NodePointer
/*     */ {
/*     */   private Node node;
/*     */   private Map namespaces;
/*     */   private String defaultNamespace;
/*     */   private String id;
/*     */   public static final String XML_NAMESPACE_URI = "http://www.w3.org/XML/1998/namespace";
/*     */   public static final String XMLNS_NAMESPACE_URI = "http://www.w3.org/2000/xmlns/";
/*     */   
/*     */   public DOMNodePointer(Node node, Locale locale)
/*     */   {
/* 109 */     super(null, locale);
/* 110 */     this.node = node;
/*     */   }
/*     */   
/*     */   public DOMNodePointer(Node node, Locale locale, String id) {
/* 114 */     super(null, locale);
/* 115 */     this.node = node;
/* 116 */     this.id = id;
/*     */   }
/*     */   
/*     */   public DOMNodePointer(NodePointer parent, Node node) {
/* 120 */     super(parent);
/* 121 */     this.node = node;
/*     */   }
/*     */   
/*     */   public boolean testNode(NodeTest test) {
/* 125 */     return testNode(this, this.node, test);
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean testNode(NodePointer pointer, Node node, NodeTest test)
/*     */   {
/* 131 */     if (test == null) {
/* 132 */       return true;
/*     */     }
/* 134 */     if ((test instanceof NodeNameTest)) {
/* 135 */       if (node.getNodeType() != 1) {
/* 136 */         return false;
/*     */       }
/*     */       
/* 139 */       QName testName = ((NodeNameTest)test).getNodeName();
/* 140 */       String testLocalName = testName.getName();
/* 141 */       boolean wildcard = testLocalName.equals("*");
/* 142 */       String testPrefix = testName.getPrefix();
/* 143 */       if ((wildcard) && (testPrefix == null)) {
/* 144 */         return true;
/*     */       }
/*     */       
/* 147 */       if ((wildcard) || (testLocalName.equals(getLocalName(node))))
/*     */       {
/* 149 */         String nodePrefix = getPrefix(node);
/* 150 */         if (equalStrings(testPrefix, nodePrefix)) {
/* 151 */           return true;
/*     */         }
/*     */         
/* 154 */         String testNS = pointer.getNamespaceURI(testPrefix);
/* 155 */         String nodeNS = pointer.getNamespaceURI(nodePrefix);
/* 156 */         return equalStrings(testNS, nodeNS);
/*     */       }
/*     */     } else {
/* 159 */       if ((test instanceof NodeTypeTest)) {
/* 160 */         int nodeType = node.getNodeType();
/* 161 */         switch (((NodeTypeTest)test).getNodeType()) {
/*     */         case 1: 
/* 163 */           return nodeType == 1;
/*     */         case 2: 
/* 165 */           return (nodeType == 4) || (nodeType == 3);
/*     */         
/*     */         case 3: 
/* 168 */           return nodeType == 8;
/*     */         case 4: 
/* 170 */           return nodeType == 7;
/*     */         }
/* 172 */         return false;
/*     */       }
/* 174 */       if (((test instanceof ProcessingInstructionTest)) && 
/* 175 */         (node.getNodeType() == 7)) {
/* 176 */         String testPI = ((ProcessingInstructionTest)test).getTarget();
/* 177 */         String nodePI = ((ProcessingInstruction)node).getTarget();
/* 178 */         return testPI.equals(nodePI);
/*     */       }
/*     */     }
/* 181 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean equalStrings(String s1, String s2) {
/* 185 */     if ((s1 == null) && (s2 != null)) {
/* 186 */       return false;
/*     */     }
/* 188 */     if ((s1 != null) && (s2 == null)) {
/* 189 */       return false;
/*     */     }
/*     */     
/* 192 */     if ((s1 != null) && (!s1.trim().equals(s2.trim()))) {
/* 193 */       return false;
/*     */     }
/*     */     
/* 196 */     return true;
/*     */   }
/*     */   
/*     */   public QName getName() {
/* 200 */     String ln = null;
/* 201 */     String ns = null;
/* 202 */     int type = this.node.getNodeType();
/* 203 */     if (type == 1) {
/* 204 */       ns = getPrefix(this.node);
/* 205 */       ln = getLocalName(this.node);
/*     */     }
/* 207 */     else if (type == 7) {
/* 208 */       ln = ((ProcessingInstruction)this.node).getTarget();
/*     */     }
/* 210 */     return new QName(ns, ln);
/*     */   }
/*     */   
/*     */   public String getNamespaceURI() {
/* 214 */     if (this.node.getNodeType() == 1) {
/* 215 */       return getNamespaceURI(getName().getPrefix());
/*     */     }
/* 217 */     return null;
/*     */   }
/*     */   
/*     */   public QName getExpandedName() {
/* 221 */     return new QName(getNamespaceURI(), getName().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodeIterator childIterator(NodeTest test, boolean reverse, NodePointer startWith)
/*     */   {
/* 229 */     return new DOMNodeIterator(this, test, reverse, startWith);
/*     */   }
/*     */   
/*     */   public NodeIterator attributeIterator(QName name) {
/* 233 */     return new DOMAttributeIterator(this, name);
/*     */   }
/*     */   
/*     */   public NodePointer namespacePointer(String prefix) {
/* 237 */     return new NamespacePointer(this, prefix);
/*     */   }
/*     */   
/*     */   public NodeIterator namespaceIterator() {
/* 241 */     return new DOMNamespaceIterator(this);
/*     */   }
/*     */   
/*     */   public String getNamespaceURI(String prefix) {
/* 245 */     if ((prefix == null) || (prefix.equals(""))) {
/* 246 */       return getDefaultNamespaceURI();
/*     */     }
/*     */     
/* 249 */     if (prefix.equals("xml")) {
/* 250 */       return "http://www.w3.org/XML/1998/namespace";
/*     */     }
/*     */     
/* 253 */     if (prefix.equals("xmlns")) {
/* 254 */       return "http://www.w3.org/2000/xmlns/";
/*     */     }
/*     */     
/* 257 */     String namespace = null;
/* 258 */     if (this.namespaces == null) {
/* 259 */       this.namespaces = new HashMap();
/*     */     }
/*     */     else {
/* 262 */       namespace = (String)this.namespaces.get(prefix);
/*     */     }
/*     */     
/* 265 */     if (namespace == null) {
/* 266 */       String qname = "xmlns:" + prefix;
/* 267 */       Node aNode = this.node;
/* 268 */       while (aNode != null) {
/* 269 */         if (aNode.getNodeType() == 1) {
/* 270 */           Attr attr = ((Element)aNode).getAttributeNode(qname);
/* 271 */           if (attr != null) {
/* 272 */             namespace = attr.getValue();
/* 273 */             break;
/*     */           }
/*     */         }
/* 276 */         aNode = aNode.getParentNode();
/*     */       }
/* 278 */       if ((namespace == null) || (namespace.equals(""))) {
/* 279 */         namespace = "<<unknown namespace>>";
/*     */       }
/*     */     }
/*     */     
/* 283 */     this.namespaces.put(prefix, namespace);
/*     */     
/* 285 */     return namespace;
/*     */   }
/*     */   
/*     */   public String getDefaultNamespaceURI() {
/* 289 */     if (this.defaultNamespace == null) {
/* 290 */       Node aNode = this.node;
/* 291 */       while (aNode != null) {
/* 292 */         if (aNode.getNodeType() == 1) {
/* 293 */           Attr attr = ((Element)aNode).getAttributeNode("xmlns");
/* 294 */           if (attr != null) {
/* 295 */             this.defaultNamespace = attr.getValue();
/* 296 */             break;
/*     */           }
/*     */         }
/* 299 */         aNode = aNode.getParentNode();
/*     */       }
/*     */     }
/* 302 */     if (this.defaultNamespace == null) {
/* 303 */       this.defaultNamespace = "";
/*     */     }
/*     */     
/* 306 */     return this.defaultNamespace.equals("") ? null : this.defaultNamespace;
/*     */   }
/*     */   
/*     */   public Object getBaseValue() {
/* 310 */     return this.node;
/*     */   }
/*     */   
/*     */   public Object getImmediateNode() {
/* 314 */     return this.node;
/*     */   }
/*     */   
/*     */   public boolean isActual() {
/* 318 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isCollection() {
/* 322 */     return false;
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 326 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLeaf()
/*     */   {
/* 334 */     return (!(this.node instanceof Element)) || (!this.node.hasChildNodes());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLanguage(String lang)
/*     */   {
/* 343 */     String current = getLanguage();
/* 344 */     if (current == null) {
/* 345 */       return super.isLanguage(lang);
/*     */     }
/* 347 */     return current.toUpperCase().startsWith(lang.toUpperCase());
/*     */   }
/*     */   
/*     */   protected String getLanguage() {
/* 351 */     Node n = this.node;
/* 352 */     while (n != null) {
/* 353 */       if (n.getNodeType() == 1) {
/* 354 */         Element e = (Element)n;
/* 355 */         String attr = e.getAttribute("xml:lang");
/* 356 */         if ((attr != null) && (!attr.equals(""))) {
/* 357 */           return attr;
/*     */         }
/*     */       }
/* 360 */       n = n.getParentNode();
/*     */     }
/* 362 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/* 372 */     if ((this.node.getNodeType() == 3) || (this.node.getNodeType() == 4))
/*     */     {
/* 374 */       String string = (String)TypeUtils.convert(value, String.class);
/* 375 */       if ((string != null) && (!string.equals(""))) {
/* 376 */         this.node.setNodeValue(string);
/*     */       }
/*     */       else {
/* 379 */         this.node.getParentNode().removeChild(this.node);
/*     */       }
/*     */     }
/*     */     else {
/* 383 */       NodeList children = this.node.getChildNodes();
/* 384 */       int count = children.getLength();
/* 385 */       int i = count;
/* 386 */       do { Node child = children.item(i);
/* 387 */         this.node.removeChild(child);i--;
/* 385 */       } while (i >= 0);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 390 */       if ((value instanceof Node)) {
/* 391 */         Node valueNode = (Node)value;
/* 392 */         if (((valueNode instanceof Element)) || ((valueNode instanceof Document)))
/*     */         {
/* 394 */           children = valueNode.getChildNodes();
/* 395 */           for (int i = 0; i < children.getLength(); i++) {
/* 396 */             Node child = children.item(i);
/* 397 */             this.node.appendChild(child.cloneNode(true));
/*     */           }
/*     */         }
/*     */         else {
/* 401 */           this.node.appendChild(valueNode.cloneNode(true));
/*     */         }
/*     */       }
/*     */       else {
/* 405 */         String string = (String)TypeUtils.convert(value, String.class);
/* 406 */         if ((string != null) && (!string.equals(""))) {
/* 407 */           Node textNode = this.node.getOwnerDocument().createTextNode(string);
/*     */           
/* 409 */           this.node.appendChild(textNode);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index)
/*     */   {
/* 420 */     if (index == Integer.MIN_VALUE) {
/* 421 */       index = 0;
/*     */     }
/* 423 */     boolean success = getAbstractFactory(context).createObject(context, this, this.node, name.toString(), index);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 430 */     if (success) {
/* 431 */       NodeIterator it = childIterator(new NodeNameTest(name), false, null);
/*     */       
/* 433 */       if ((it != null) && (it.setPosition(index + 1))) {
/* 434 */         return it.getNodePointer();
/*     */       }
/*     */     }
/* 437 */     throw new JXPathException("Factory could not create a child node for path: " + asPath() + "/" + name + "[" + (index + 1) + "]");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index, Object value)
/*     */   {
/* 450 */     NodePointer ptr = createChild(context, name, index);
/* 451 */     ptr.setValue(value);
/* 452 */     return ptr;
/*     */   }
/*     */   
/*     */   public NodePointer createAttribute(JXPathContext context, QName name) {
/* 456 */     if (!(this.node instanceof Element)) {
/* 457 */       return super.createAttribute(context, name);
/*     */     }
/* 459 */     Element element = (Element)this.node;
/* 460 */     String prefix = name.getPrefix();
/* 461 */     if (prefix != null) {
/* 462 */       String ns = getNamespaceURI(prefix);
/* 463 */       if (ns == null) {
/* 464 */         throw new JXPathException("Unknown namespace prefix: " + prefix);
/*     */       }
/*     */       
/* 467 */       element.setAttributeNS(ns, name.toString(), "");
/*     */ 
/*     */     }
/* 470 */     else if (!element.hasAttribute(name.getName())) {
/* 471 */       element.setAttribute(name.getName(), "");
/*     */     }
/*     */     
/* 474 */     NodeIterator it = attributeIterator(name);
/* 475 */     it.setPosition(1);
/* 476 */     return it.getNodePointer();
/*     */   }
/*     */   
/*     */   public void remove() {
/* 480 */     Node parent = this.node.getParentNode();
/* 481 */     if (parent == null) {
/* 482 */       throw new JXPathException("Cannot remove root DOM node");
/*     */     }
/* 484 */     parent.removeChild(this.node);
/*     */   }
/*     */   
/*     */   public String asPath() {
/* 488 */     if (this.id != null) {
/* 489 */       return "id('" + escape(this.id) + "')";
/*     */     }
/*     */     
/* 492 */     StringBuffer buffer = new StringBuffer();
/* 493 */     if (this.parent != null) {
/* 494 */       buffer.append(this.parent.asPath());
/*     */     }
/* 496 */     switch (this.node.getNodeType())
/*     */     {
/*     */ 
/*     */ 
/*     */     case 1: 
/* 501 */       if ((this.parent instanceof DOMNodePointer)) {
/* 502 */         if ((buffer.length() == 0) || (buffer.charAt(buffer.length() - 1) != '/'))
/*     */         {
/* 504 */           buffer.append('/');
/*     */         }
/* 506 */         buffer.append(getName());
/* 507 */         buffer.append('[');
/* 508 */         buffer.append(getRelativePositionByName()).append(']');
/*     */       }
/*     */       break;
/*     */     case 3: 
/*     */     case 4: 
/* 513 */       buffer.append("/text()");
/* 514 */       buffer.append('[');
/* 515 */       buffer.append(getRelativePositionOfTextNode()).append(']');
/* 516 */       break;
/*     */     case 7: 
/* 518 */       String target = ((ProcessingInstruction)this.node).getTarget();
/* 519 */       buffer.append("/processing-instruction('");
/* 520 */       buffer.append(target).append("')");
/* 521 */       buffer.append('[');
/* 522 */       buffer.append(getRelativePositionOfPI(target)).append(']');
/* 523 */       break;
/*     */     }
/*     */     
/*     */     
/* 527 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private String escape(String string) {
/* 531 */     int index = string.indexOf('\'');
/* 532 */     while (index != -1) {
/* 533 */       string = string.substring(0, index) + "&apos;" + string.substring(index + 1);
/*     */       
/*     */ 
/*     */ 
/* 537 */       index = string.indexOf('\'');
/*     */     }
/* 539 */     index = string.indexOf('"');
/* 540 */     while (index != -1) {
/* 541 */       string = string.substring(0, index) + "&quot;" + string.substring(index + 1);
/*     */       
/*     */ 
/*     */ 
/* 545 */       index = string.indexOf('"');
/*     */     }
/* 547 */     return string;
/*     */   }
/*     */   
/*     */   private int getRelativePositionByName() {
/* 551 */     int count = 1;
/* 552 */     Node n = this.node.getPreviousSibling();
/* 553 */     while (n != null) {
/* 554 */       if (n.getNodeType() == 1) {
/* 555 */         String nm = n.getNodeName();
/* 556 */         if (nm.equals(this.node.getNodeName())) {
/* 557 */           count++;
/*     */         }
/*     */       }
/* 560 */       n = n.getPreviousSibling();
/*     */     }
/* 562 */     return count;
/*     */   }
/*     */   
/*     */   private int getRelativePositionOfTextNode() {
/* 566 */     int count = 1;
/* 567 */     Node n = this.node.getPreviousSibling();
/* 568 */     while (n != null) {
/* 569 */       if ((n.getNodeType() == 3) || (n.getNodeType() == 4))
/*     */       {
/* 571 */         count++;
/*     */       }
/* 573 */       n = n.getPreviousSibling();
/*     */     }
/* 575 */     return count;
/*     */   }
/*     */   
/*     */   private int getRelativePositionOfPI(String target) {
/* 579 */     int count = 1;
/* 580 */     Node n = this.node.getPreviousSibling();
/* 581 */     while (n != null) {
/* 582 */       if ((n.getNodeType() == 7) && (((ProcessingInstruction)n).getTarget().equals(target)))
/*     */       {
/* 584 */         count++;
/*     */       }
/* 586 */       n = n.getPreviousSibling();
/*     */     }
/* 588 */     return count;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 592 */     return System.identityHashCode(this.node);
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 596 */     if (object == this) {
/* 597 */       return true;
/*     */     }
/*     */     
/* 600 */     if (!(object instanceof DOMNodePointer)) {
/* 601 */       return false;
/*     */     }
/*     */     
/* 604 */     DOMNodePointer other = (DOMNodePointer)object;
/* 605 */     return this.node == other.node;
/*     */   }
/*     */   
/*     */   public static String getPrefix(Node node) {
/* 609 */     String prefix = node.getPrefix();
/* 610 */     if (prefix != null) {
/* 611 */       return prefix;
/*     */     }
/*     */     
/* 614 */     String name = node.getNodeName();
/* 615 */     int index = name.lastIndexOf(':');
/* 616 */     if (index == -1) {
/* 617 */       return null;
/*     */     }
/*     */     
/* 620 */     return name.substring(0, index);
/*     */   }
/*     */   
/*     */   public static String getLocalName(Node node) {
/* 624 */     String localName = node.getLocalName();
/* 625 */     if (localName != null) {
/* 626 */       return localName;
/*     */     }
/*     */     
/* 629 */     String name = node.getNodeName();
/* 630 */     int index = name.lastIndexOf(':');
/* 631 */     if (index == -1) {
/* 632 */       return name;
/*     */     }
/*     */     
/* 635 */     return name.substring(index + 1);
/*     */   }
/*     */   
/*     */   public Object getValue() {
/* 639 */     return stringValue(this.node);
/*     */   }
/*     */   
/*     */   private String stringValue(Node node) {
/* 643 */     int nodeType = node.getNodeType();
/* 644 */     if (nodeType == 8) {
/* 645 */       String text = ((Comment)node).getData();
/* 646 */       return text == null ? "" : text.trim();
/*     */     }
/* 648 */     if ((nodeType == 3) || (nodeType == 4))
/*     */     {
/*     */ 
/* 651 */       String text = node.getNodeValue();
/* 652 */       return text == null ? "" : text.trim();
/*     */     }
/* 654 */     if (nodeType == 7) {
/* 655 */       String text = ((ProcessingInstruction)node).getData();
/* 656 */       return text == null ? "" : text.trim();
/*     */     }
/*     */     
/* 659 */     NodeList list = node.getChildNodes();
/* 660 */     StringBuffer buf = new StringBuffer(16);
/* 661 */     for (int i = 0; i < list.getLength(); i++) {
/* 662 */       Node child = list.item(i);
/* 663 */       if (child.getNodeType() == 3) {
/* 664 */         buf.append(child.getNodeValue());
/*     */       }
/*     */       else {
/* 667 */         buf.append(stringValue(child));
/*     */       }
/*     */     }
/* 670 */     return buf.toString().trim();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Pointer getPointerByID(JXPathContext context, String id)
/*     */   {
/*     */     Document document;
/*     */     
/* 679 */     if (this.node.getNodeType() == 9) {
/* 680 */       document = (Document)this.node;
/*     */     }
/*     */     else {
/* 683 */       document = this.node.getOwnerDocument();
/*     */     }
/* 685 */     Element element = document.getElementById(id);
/* 686 */     if (element != null) {
/* 687 */       return new DOMNodePointer(element, getLocale(), id);
/*     */     }
/*     */     
/* 690 */     return new NullPointer(getLocale(), id);
/*     */   }
/*     */   
/*     */   private AbstractFactory getAbstractFactory(JXPathContext context)
/*     */   {
/* 695 */     AbstractFactory factory = context.getFactory();
/* 696 */     if (factory == null) {
/* 697 */       throw new JXPathException("Factory is not set on the JXPathContext - cannot create path: " + asPath());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 702 */     return factory;
/*     */   }
/*     */   
/*     */ 
/*     */   public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2)
/*     */   {
/* 708 */     Node node1 = (Node)pointer1.getBaseValue();
/* 709 */     Node node2 = (Node)pointer2.getBaseValue();
/* 710 */     if (node1 == node2) {
/* 711 */       return 0;
/*     */     }
/*     */     
/* 714 */     int t1 = node1.getNodeType();
/* 715 */     int t2 = node2.getNodeType();
/* 716 */     if ((t1 == 2) && (t2 != 2)) {
/* 717 */       return -1;
/*     */     }
/* 719 */     if ((t1 != 2) && (t2 == 2)) {
/* 720 */       return 1;
/*     */     }
/* 722 */     if ((t1 == 2) && (t2 == 2)) {
/* 723 */       NamedNodeMap map = ((Node)getNode()).getAttributes();
/* 724 */       int length = map.getLength();
/* 725 */       for (int i = 0; i < length; i++) {
/* 726 */         Node n = map.item(i);
/* 727 */         if (n == node1) {
/* 728 */           return -1;
/*     */         }
/* 730 */         if (n == node2) {
/* 731 */           return 1;
/*     */         }
/*     */       }
/* 734 */       return 0;
/*     */     }
/*     */     
/* 737 */     Node current = this.node.getFirstChild();
/* 738 */     while (current != null) {
/* 739 */       if (current == node1) {
/* 740 */         return -1;
/*     */       }
/* 742 */       if (current == node2) {
/* 743 */         return 1;
/*     */       }
/* 745 */       current = current.getNextSibling();
/*     */     }
/*     */     
/* 748 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dom/DOMNodePointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */