/*     */ package org.apache.commons.jxpath.ri.axes;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ import org.apache.commons.jxpath.ri.InfoSetUtil;
/*     */ import org.apache.commons.jxpath.ri.compiler.Expression;
/*     */ import org.apache.commons.jxpath.ri.compiler.NameAttributeTest;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.PropertyOwnerPointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.PropertyPointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PredicateContext
/*     */   extends EvalContext
/*     */ {
/*     */   private Expression expression;
/*  82 */   private boolean done = false;
/*     */   private Expression nameTestExpression;
/*     */   private PropertyPointer dynamicPropertyPointer;
/*     */   
/*     */   public PredicateContext(EvalContext parentContext, Expression expression) {
/*  87 */     super(parentContext);
/*  88 */     this.expression = expression;
/*  89 */     if ((expression instanceof NameAttributeTest)) {
/*  90 */       this.nameTestExpression = ((NameAttributeTest)expression).getNameTestExpression();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean nextNode()
/*     */   {
/*  96 */     if (this.done) {
/*  97 */       return false;
/*     */     }
/*  99 */     while (this.parentContext.nextNode()) {
/* 100 */       if (setupDynamicPropertyPointer()) {
/* 101 */         Object pred = this.nameTestExpression.computeValue(this.parentContext);
/* 102 */         if ((pred instanceof NodePointer)) {
/* 103 */           pred = ((NodePointer)pred).getValue();
/*     */         }
/* 105 */         this.dynamicPropertyPointer.setPropertyName(InfoSetUtil.stringValue(pred));
/*     */         
/* 107 */         this.position = 1;
/* 108 */         this.done = true;
/* 109 */         return true;
/*     */       }
/*     */       
/* 112 */       Object pred = this.expression.computeValue(this.parentContext);
/* 113 */       if ((pred instanceof Iterator)) {
/* 114 */         if (!((Iterator)pred).hasNext()) {
/* 115 */           return false;
/*     */         }
/* 117 */         pred = ((Iterator)pred).next();
/*     */       }
/*     */       
/* 120 */       if ((pred instanceof NodePointer)) {
/* 121 */         pred = ((NodePointer)pred).getNode();
/*     */       }
/*     */       
/* 124 */       if ((pred instanceof Number)) {
/* 125 */         int pos = (int)InfoSetUtil.doubleValue(pred);
/* 126 */         this.position += 1;
/* 127 */         this.done = true;
/* 128 */         return this.parentContext.setPosition(pos);
/*     */       }
/* 130 */       if (InfoSetUtil.booleanValue(pred)) {
/* 131 */         this.position += 1;
/* 132 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 136 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean setupDynamicPropertyPointer()
/*     */   {
/* 144 */     if (this.nameTestExpression == null) {
/* 145 */       return false;
/*     */     }
/*     */     
/* 148 */     NodePointer parent = this.parentContext.getCurrentNodePointer();
/* 149 */     if (parent == null) {
/* 150 */       return false;
/*     */     }
/* 152 */     parent = parent.getValuePointer();
/* 153 */     if (!(parent instanceof PropertyOwnerPointer)) {
/* 154 */       return false;
/*     */     }
/* 156 */     this.dynamicPropertyPointer = ((PropertyOwnerPointer)parent).getPropertyPointer();
/*     */     
/* 158 */     return true;
/*     */   }
/*     */   
/*     */   public boolean setPosition(int position) {
/* 162 */     if (this.nameTestExpression == null) {
/* 163 */       return setPositionStandard(position);
/*     */     }
/*     */     
/* 166 */     if ((this.dynamicPropertyPointer == null) && 
/* 167 */       (!setupDynamicPropertyPointer())) {
/* 168 */       return setPositionStandard(position);
/*     */     }
/*     */     
/* 171 */     if ((position < 1) || (position > this.dynamicPropertyPointer.getLength()))
/*     */     {
/* 173 */       return false;
/*     */     }
/* 175 */     this.dynamicPropertyPointer.setIndex(position - 1);
/* 176 */     return true;
/*     */   }
/*     */   
/*     */   public NodePointer getCurrentNodePointer()
/*     */   {
/* 181 */     if ((this.position == 0) && 
/* 182 */       (!setPosition(1))) {
/* 183 */       return null;
/*     */     }
/*     */     
/* 186 */     if (this.dynamicPropertyPointer != null) {
/* 187 */       return this.dynamicPropertyPointer.getValuePointer();
/*     */     }
/*     */     
/* 190 */     return this.parentContext.getCurrentNodePointer();
/*     */   }
/*     */   
/*     */   public void reset()
/*     */   {
/* 195 */     super.reset();
/* 196 */     this.done = false;
/*     */   }
/*     */   
/*     */   public boolean nextSet() {
/* 200 */     reset();
/* 201 */     return this.parentContext.nextSet();
/*     */   }
/*     */   
/*     */   private boolean setPositionStandard(int position) {
/* 205 */     if (this.position > position) {
/* 206 */       reset();
/*     */     }
/*     */     
/* 209 */     while (this.position < position) {
/* 210 */       if (!nextNode()) {
/* 211 */         return false;
/*     */       }
/*     */     }
/* 214 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/axes/PredicateContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */