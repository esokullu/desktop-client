/*    */ package org.apache.commons.jxpath.ri.compiler;
/*    */ 
/*    */ import org.apache.commons.jxpath.ri.EvalContext;
/*    */ import org.apache.commons.jxpath.ri.InfoSetUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoreOperationOr
/*    */   extends CoreOperation
/*    */ {
/*    */   public CoreOperationOr(Expression[] args)
/*    */   {
/* 68 */     super(args);
/*    */   }
/*    */   
/*    */   public Object computeValue(EvalContext context) {
/* 72 */     for (int i = 0; i < this.args.length; i++) {
/* 73 */       if (InfoSetUtil.booleanValue(this.args[i].computeValue(context))) {
/* 74 */         return Boolean.TRUE;
/*    */       }
/*    */     }
/* 77 */     return Boolean.FALSE;
/*    */   }
/*    */   
/*    */   protected int getPrecedence() {
/* 81 */     return 0;
/*    */   }
/*    */   
/*    */   protected boolean isSymmetric() {
/* 85 */     return true;
/*    */   }
/*    */   
/*    */   public String getSymbol() {
/* 89 */     return "or";
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/CoreOperationOr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */