/*     */ package org.apache.commons.jxpath.ri.model.dynamic;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.jxpath.AbstractFactory;
/*     */ import org.apache.commons.jxpath.DynamicPropertyHandler;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.beans.PropertyPointer;
/*     */ import org.apache.commons.jxpath.util.ValueUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DynamicPropertyPointer
/*     */   extends PropertyPointer
/*     */ {
/*     */   private DynamicPropertyHandler handler;
/*     */   private String name;
/*     */   private String[] names;
/*     */   private String requiredPropertyName;
/*     */   
/*     */   public DynamicPropertyPointer(NodePointer parent, DynamicPropertyHandler handler)
/*     */   {
/*  91 */     super(parent);
/*  92 */     this.handler = handler;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isContainer()
/*     */   {
/*  98 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPropertyCount()
/*     */   {
/* 105 */     return getPropertyNames().length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getPropertyNames()
/*     */   {
/* 112 */     if (this.names == null) {
/* 113 */       String[] allNames = this.handler.getPropertyNames(getBean());
/* 114 */       this.names = new String[allNames.length];
/* 115 */       for (int i = 0; i < this.names.length; i++) {
/* 116 */         this.names[i] = allNames[i];
/*     */       }
/* 118 */       Arrays.sort(this.names);
/* 119 */       if (this.requiredPropertyName != null) {
/* 120 */         int inx = Arrays.binarySearch(this.names, this.requiredPropertyName);
/* 121 */         if (inx < 0) {
/* 122 */           allNames = this.names;
/* 123 */           this.names = new String[allNames.length + 1];
/* 124 */           this.names[0] = this.requiredPropertyName;
/* 125 */           System.arraycopy(allNames, 0, this.names, 1, allNames.length);
/* 126 */           Arrays.sort(this.names);
/*     */         }
/*     */       }
/*     */     }
/* 130 */     return this.names;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPropertyName()
/*     */   {
/* 138 */     if (this.name == null) {
/* 139 */       String[] names = getPropertyNames();
/* 140 */       if ((this.propertyIndex >= 0) && (this.propertyIndex < names.length)) {
/* 141 */         this.name = names[this.propertyIndex];
/*     */       }
/*     */       else {
/* 144 */         this.name = "*";
/*     */       }
/*     */     }
/* 147 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPropertyName(String propertyName)
/*     */   {
/* 158 */     setPropertyIndex(Integer.MIN_VALUE);
/* 159 */     this.name = propertyName;
/* 160 */     this.requiredPropertyName = propertyName;
/* 161 */     if ((this.names != null) && (Arrays.binarySearch(this.names, propertyName) < 0)) {
/* 162 */       this.names = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPropertyIndex()
/*     */   {
/* 171 */     if (this.propertyIndex == Integer.MIN_VALUE) {
/* 172 */       String[] names = getPropertyNames();
/* 173 */       for (int i = 0; i < names.length; i++) {
/* 174 */         if (names[i].equals(this.name)) {
/* 175 */           setPropertyIndex(i);
/* 176 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 180 */     return super.getPropertyIndex();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPropertyIndex(int index)
/*     */   {
/* 188 */     if (this.propertyIndex != index) {
/* 189 */       super.setPropertyIndex(index);
/* 190 */       this.name = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getBaseValue()
/*     */   {
/* 199 */     return this.handler.getProperty(getBean(), getPropertyName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getImmediateNode()
/*     */   {
/*     */     Object value;
/*     */     
/*     */ 
/* 210 */     if (this.index == Integer.MIN_VALUE) {
/* 211 */       value = this.handler.getProperty(getBean(), getPropertyName());
/*     */     }
/*     */     else {
/* 214 */       value = ValueUtils.getValue(this.handler.getProperty(getBean(), getPropertyName()), this.index);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 219 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isActualProperty()
/*     */   {
/* 227 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/* 236 */     if (this.index == Integer.MIN_VALUE) {
/* 237 */       this.handler.setProperty(getBean(), getPropertyName(), value);
/*     */     }
/*     */     else {
/* 240 */       ValueUtils.setValue(this.handler.getProperty(getBean(), getPropertyName()), this.index, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createPath(JXPathContext context)
/*     */   {
/* 249 */     Object collection = getBaseValue();
/* 250 */     if (collection == null) {
/* 251 */       AbstractFactory factory = getAbstractFactory(context);
/* 252 */       boolean success = factory.createObject(context, this, getBean(), getPropertyName(), 0);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 259 */       if (!success) {
/* 260 */         throw new JXPathException("Factory could not create an object for path: " + asPath());
/*     */       }
/*     */       
/* 263 */       collection = getBaseValue();
/*     */     }
/*     */     
/* 266 */     if (this.index != Integer.MIN_VALUE) {
/* 267 */       if (this.index < 0) {
/* 268 */         throw new JXPathException("Index is less than 1: " + asPath());
/*     */       }
/*     */       
/* 271 */       if (this.index >= getLength()) {
/* 272 */         collection = ValueUtils.expandCollection(collection, this.index + 1);
/* 273 */         this.handler.setProperty(getBean(), getPropertyName(), collection);
/*     */       }
/*     */     }
/*     */     
/* 277 */     return this;
/*     */   }
/*     */   
/*     */   public NodePointer createPath(JXPathContext context, Object value) {
/* 281 */     if (this.index == Integer.MIN_VALUE) {
/* 282 */       this.handler.setProperty(getBean(), getPropertyName(), value);
/*     */     }
/*     */     else {
/* 285 */       createPath(context);
/* 286 */       ValueUtils.setValue(getBaseValue(), this.index, value);
/*     */     }
/* 288 */     return this;
/*     */   }
/*     */   
/*     */   public void remove() {
/* 292 */     if (this.index == Integer.MIN_VALUE) {
/* 293 */       removeKey();
/*     */     }
/* 295 */     else if (isCollection()) {
/* 296 */       Object collection = ValueUtils.remove(getBaseValue(), this.index);
/* 297 */       this.handler.setProperty(getBean(), getPropertyName(), collection);
/*     */     }
/* 299 */     else if (this.index == 0) {
/* 300 */       removeKey();
/*     */     }
/*     */   }
/*     */   
/*     */   private void removeKey() {
/* 305 */     Object bean = getBean();
/* 306 */     if ((bean instanceof Map)) {
/* 307 */       ((Map)bean).remove(getPropertyName());
/*     */     }
/*     */     else {
/* 310 */       this.handler.setProperty(bean, getPropertyName(), null);
/*     */     }
/*     */   }
/*     */   
/*     */   public String asPath() {
/* 315 */     StringBuffer buffer = new StringBuffer();
/* 316 */     buffer.append(getParent().asPath());
/* 317 */     if (buffer.length() == 0) {
/* 318 */       buffer.append("/.");
/*     */     }
/* 320 */     else if (buffer.charAt(buffer.length() - 1) == '/') {
/* 321 */       buffer.append('.');
/*     */     }
/* 323 */     buffer.append("[@name='");
/* 324 */     buffer.append(escape(getPropertyName()));
/* 325 */     buffer.append("']");
/* 326 */     if ((this.index != Integer.MIN_VALUE) && (isCollection())) {
/* 327 */       buffer.append('[').append(this.index + 1).append(']');
/*     */     }
/* 329 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private String escape(String string) {
/* 333 */     int index = string.indexOf('\'');
/* 334 */     while (index != -1) {
/* 335 */       string = string.substring(0, index) + "&apos;" + string.substring(index + 1);
/*     */       
/*     */ 
/*     */ 
/* 339 */       index = string.indexOf('\'');
/*     */     }
/* 341 */     index = string.indexOf('"');
/* 342 */     while (index != -1) {
/* 343 */       string = string.substring(0, index) + "&quot;" + string.substring(index + 1);
/*     */       
/*     */ 
/*     */ 
/* 347 */       index = string.indexOf('"');
/*     */     }
/* 349 */     return string;
/*     */   }
/*     */   
/*     */   private AbstractFactory getAbstractFactory(JXPathContext context) {
/* 353 */     AbstractFactory factory = context.getFactory();
/* 354 */     if (factory == null) {
/* 355 */       throw new JXPathException("Factory is not set on the JXPathContext - cannot create path: " + asPath());
/*     */     }
/*     */     
/*     */ 
/* 359 */     return factory;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/dynamic/DynamicPropertyPointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */