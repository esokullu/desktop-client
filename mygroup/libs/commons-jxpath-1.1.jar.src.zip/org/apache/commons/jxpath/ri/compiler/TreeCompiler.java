/*     */ package org.apache.commons.jxpath.ri.compiler;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.Compiler;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeCompiler
/*     */   implements Compiler
/*     */ {
/*  73 */   private static final QName QNAME_NAME = new QName(null, "name");
/*     */   
/*     */   public Object number(String value) {
/*  76 */     return new Constant(new Double(value));
/*     */   }
/*     */   
/*     */   public Object literal(String value) {
/*  80 */     return new Constant(value);
/*     */   }
/*     */   
/*     */   public Object qname(String prefix, String name) {
/*  84 */     return new QName(prefix, name);
/*     */   }
/*     */   
/*     */   public Object sum(Object[] arguments) {
/*  88 */     return new CoreOperationAdd(toExpressionArray(arguments));
/*     */   }
/*     */   
/*     */   public Object minus(Object left, Object right) {
/*  92 */     return new CoreOperationSubtract((Expression)left, (Expression)right);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object multiply(Object left, Object right)
/*     */   {
/*  98 */     return new CoreOperationMultiply((Expression)left, (Expression)right);
/*     */   }
/*     */   
/*     */   public Object divide(Object left, Object right) {
/* 102 */     return new CoreOperationDivide((Expression)left, (Expression)right);
/*     */   }
/*     */   
/*     */   public Object mod(Object left, Object right) {
/* 106 */     return new CoreOperationMod((Expression)left, (Expression)right);
/*     */   }
/*     */   
/*     */   public Object lessThan(Object left, Object right) {
/* 110 */     return new CoreOperationLessThan((Expression)left, (Expression)right);
/*     */   }
/*     */   
/*     */   public Object lessThanOrEqual(Object left, Object right) {
/* 114 */     return new CoreOperationLessThanOrEqual((Expression)left, (Expression)right);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object greaterThan(Object left, Object right)
/*     */   {
/* 120 */     return new CoreOperationGreaterThan((Expression)left, (Expression)right);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object greaterThanOrEqual(Object left, Object right)
/*     */   {
/* 126 */     return new CoreOperationGreaterThanOrEqual((Expression)left, (Expression)right);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object equal(Object left, Object right)
/*     */   {
/* 132 */     if (isNameAttributeTest((Expression)left)) {
/* 133 */       return new NameAttributeTest((Expression)left, (Expression)right);
/*     */     }
/*     */     
/* 136 */     return new CoreOperationEqual((Expression)left, (Expression)right);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object notEqual(Object left, Object right)
/*     */   {
/* 143 */     return new CoreOperationNotEqual((Expression)left, (Expression)right);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object minus(Object argument)
/*     */   {
/* 149 */     return new CoreOperationNegate((Expression)argument);
/*     */   }
/*     */   
/*     */   public Object variableReference(Object qName) {
/* 153 */     return new VariableReference((QName)qName);
/*     */   }
/*     */   
/*     */   public Object function(int code, Object[] args) {
/* 157 */     return new CoreFunction(code, toExpressionArray(args));
/*     */   }
/*     */   
/*     */   public Object function(Object name, Object[] args) {
/* 161 */     return new ExtensionFunction((QName)name, toExpressionArray(args));
/*     */   }
/*     */   
/*     */   public Object and(Object[] arguments) {
/* 165 */     return new CoreOperationAnd(toExpressionArray(arguments));
/*     */   }
/*     */   
/*     */   public Object or(Object[] arguments)
/*     */   {
/* 170 */     return new CoreOperationOr(toExpressionArray(arguments));
/*     */   }
/*     */   
/*     */   public Object union(Object[] arguments)
/*     */   {
/* 175 */     return new CoreOperationUnion(toExpressionArray(arguments));
/*     */   }
/*     */   
/*     */   public Object locationPath(boolean absolute, Object[] steps)
/*     */   {
/* 180 */     return new LocationPath(absolute, toStepArray(steps));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object expressionPath(Object expression, Object[] predicates, Object[] steps)
/*     */   {
/* 188 */     return new ExpressionPath((Expression)expression, toExpressionArray(predicates), toStepArray(steps));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object nodeNameTest(Object qname)
/*     */   {
/* 195 */     return new NodeNameTest((QName)qname);
/*     */   }
/*     */   
/*     */   public Object nodeTypeTest(int nodeType) {
/* 199 */     return new NodeTypeTest(nodeType);
/*     */   }
/*     */   
/*     */   public Object processingInstructionTest(String instruction) {
/* 203 */     return new ProcessingInstructionTest(instruction);
/*     */   }
/*     */   
/*     */   public Object step(int axis, Object nodeTest, Object[] predicates) {
/* 207 */     return new Step(axis, (NodeTest)nodeTest, toExpressionArray(predicates));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Expression[] toExpressionArray(Object[] array)
/*     */   {
/* 214 */     Expression[] expArray = null;
/* 215 */     if (array != null) {
/* 216 */       expArray = new Expression[array.length];
/* 217 */       for (int i = 0; i < expArray.length; i++) {
/* 218 */         expArray[i] = ((Expression)array[i]);
/*     */       }
/*     */     }
/* 221 */     return expArray;
/*     */   }
/*     */   
/*     */   private Step[] toStepArray(Object[] array) {
/* 225 */     Step[] stepArray = null;
/* 226 */     if (array != null) {
/* 227 */       stepArray = new Step[array.length];
/* 228 */       for (int i = 0; i < stepArray.length; i++) {
/* 229 */         stepArray[i] = ((Step)array[i]);
/*     */       }
/*     */     }
/* 232 */     return stepArray;
/*     */   }
/*     */   
/*     */   private boolean isNameAttributeTest(Expression arg) {
/* 236 */     if (!(arg instanceof LocationPath)) {
/* 237 */       return false;
/*     */     }
/*     */     
/* 240 */     Step[] steps = ((LocationPath)arg).getSteps();
/* 241 */     if (steps.length != 1) {
/* 242 */       return false;
/*     */     }
/* 244 */     if (steps[0].getAxis() != 5) {
/* 245 */       return false;
/*     */     }
/* 247 */     NodeTest test = steps[0].getNodeTest();
/* 248 */     if (!(test instanceof NodeNameTest)) {
/* 249 */       return false;
/*     */     }
/* 251 */     if (!((NodeNameTest)test).getNodeName().equals(QNAME_NAME)) {
/* 252 */       return false;
/*     */     }
/* 254 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/TreeCompiler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */