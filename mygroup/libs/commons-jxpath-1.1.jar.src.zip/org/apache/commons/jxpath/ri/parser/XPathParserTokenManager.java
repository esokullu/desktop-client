/*      */ package org.apache.commons.jxpath.ri.parser;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ 
/*      */ public class XPathParserTokenManager implements XPathParserConstants
/*      */ {
/*    8 */   public PrintStream debugStream = System.out;
/*    9 */   public void setDebugStream(PrintStream ds) { this.debugStream = ds; }
/*      */   
/*      */   private final int jjStopStringLiteralDfa_0(int pos, long active0, long active1) {
/*   12 */     switch (pos)
/*      */     {
/*      */     case 0: 
/*   15 */       if (((active0 & 0xFFFFFFFFFF800000) != 0L) || ((active1 & 0x3FF) != 0L))
/*      */       {
/*   17 */         this.jjmatchedKind = 74;
/*   18 */         return 13;
/*      */       }
/*   20 */       if ((active1 & 0xC000) != 0L)
/*   21 */         return 11;
/*   22 */       return -1;
/*      */     case 1: 
/*   24 */       if ((active0 & 0x800000800000) != 0L)
/*   25 */         return 13;
/*   26 */       if (((active0 & 0xFFFF7FFFFF000000) != 0L) || ((active1 & 0x3FF) != 0L))
/*      */       {
/*   28 */         this.jjmatchedKind = 74;
/*   29 */         this.jjmatchedPos = 1;
/*   30 */         return 13;
/*      */       }
/*   32 */       return -1;
/*      */     case 2: 
/*   34 */       if (((active0 & 0x7FFE7FFFF8000000) != 0L) || ((active1 & 0x3DF) != 0L))
/*      */       {
/*   36 */         this.jjmatchedKind = 74;
/*   37 */         this.jjmatchedPos = 2;
/*   38 */         return 13;
/*      */       }
/*   40 */       if (((active0 & 0x8001000007000000) != 0L) || ((active1 & 0x20) != 0L))
/*   41 */         return 13;
/*   42 */       return -1;
/*      */     case 3: 
/*   44 */       if (((active0 & 0x7FF26FEFE0000000) != 0L) || ((active1 & 0x3D2) != 0L))
/*      */       {
/*   46 */         if (this.jjmatchedPos != 3)
/*      */         {
/*   48 */           this.jjmatchedKind = 74;
/*   49 */           this.jjmatchedPos = 3;
/*      */         }
/*   51 */         return 13;
/*      */       }
/*   53 */       if (((active0 & 0xC101018000000) != 0L) || ((active1 & 0xD) != 0L))
/*   54 */         return 13;
/*   55 */       return -1;
/*      */     case 4: 
/*   57 */       if ((active0 & 0x80000000) != 0L)
/*      */       {
/*   59 */         if (this.jjmatchedPos < 3)
/*      */         {
/*   61 */           this.jjmatchedKind = 74;
/*   62 */           this.jjmatchedPos = 3;
/*      */         }
/*   64 */         return -1;
/*      */       }
/*   66 */       if (((active0 & 0x400000000000) != 0L) || ((active1 & 0x142) != 0L))
/*   67 */         return 13;
/*   68 */       if (((active0 & 0x7FF62FFF60000000) != 0L) || ((active1 & 0x290) != 0L))
/*      */       {
/*   70 */         this.jjmatchedKind = 74;
/*   71 */         this.jjmatchedPos = 4;
/*   72 */         return 13;
/*      */       }
/*   74 */       return -1;
/*      */     case 5: 
/*   76 */       if (((active0 & 0x77C62FFE60000000) != 0L) || ((active1 & 0x280) != 0L))
/*      */       {
/*   78 */         if (this.jjmatchedPos != 5)
/*      */         {
/*   80 */           this.jjmatchedKind = 74;
/*   81 */           this.jjmatchedPos = 5;
/*      */         }
/*   83 */         return 13;
/*      */       }
/*   85 */       if ((active0 & 0x100000000) != 0L)
/*      */       {
/*   87 */         if (this.jjmatchedPos < 4)
/*      */         {
/*   89 */           this.jjmatchedKind = 74;
/*   90 */           this.jjmatchedPos = 4;
/*      */         }
/*   92 */         return -1;
/*      */       }
/*   94 */       if ((active0 & 0x80000000) != 0L)
/*      */       {
/*   96 */         if (this.jjmatchedPos < 3)
/*      */         {
/*   98 */           this.jjmatchedKind = 74;
/*   99 */           this.jjmatchedPos = 3;
/*      */         }
/*  101 */         return -1;
/*      */       }
/*  103 */       if (((active0 & 0x830000000000000) != 0L) || ((active1 & 0x10) != 0L))
/*  104 */         return 13;
/*  105 */       return -1;
/*      */     case 6: 
/*  107 */       if ((active0 & 0x200000000) != 0L)
/*      */       {
/*  109 */         if (this.jjmatchedPos < 5)
/*      */         {
/*  111 */           this.jjmatchedKind = 74;
/*  112 */           this.jjmatchedPos = 5;
/*      */         }
/*  114 */         return -1;
/*      */       }
/*  116 */       if ((active0 & 0x100000000) != 0L)
/*      */       {
/*  118 */         if (this.jjmatchedPos < 4)
/*      */         {
/*  120 */           this.jjmatchedKind = 74;
/*  121 */           this.jjmatchedPos = 4;
/*      */         }
/*  123 */         return -1;
/*      */       }
/*  125 */       if (((active0 & 0x3FC62FFC40000000) != 0L) || ((active1 & 0x200) != 0L))
/*      */       {
/*  127 */         this.jjmatchedKind = 74;
/*  128 */         this.jjmatchedPos = 6;
/*  129 */         return 13;
/*      */       }
/*  131 */       if (((active0 & 0x4000000020000000) != 0L) || ((active1 & 0x80) != 0L))
/*  132 */         return 13;
/*  133 */       return -1;
/*      */     case 7: 
/*  135 */       if ((active0 & 0x200000000) != 0L)
/*      */       {
/*  137 */         if (this.jjmatchedPos < 5)
/*      */         {
/*  139 */           this.jjmatchedKind = 74;
/*  140 */           this.jjmatchedPos = 5;
/*      */         }
/*  142 */         return -1;
/*      */       }
/*  144 */       if ((active0 & 0x80200000000000) != 0L)
/*  145 */         return 13;
/*  146 */       if (((active0 & 0x3F460FFC40000000) != 0L) || ((active1 & 0x200) != 0L))
/*      */       {
/*  148 */         this.jjmatchedKind = 74;
/*  149 */         this.jjmatchedPos = 7;
/*  150 */         return 13;
/*      */       }
/*  152 */       return -1;
/*      */     case 8: 
/*  154 */       if (((active0 & 0x18460FF840000000) != 0L) || ((active1 & 0x200) != 0L))
/*      */       {
/*  156 */         if (this.jjmatchedPos != 8)
/*      */         {
/*  158 */           this.jjmatchedKind = 74;
/*  159 */           this.jjmatchedPos = 8;
/*      */         }
/*  161 */         return 13;
/*      */       }
/*  163 */       if ((active0 & 0x400000000) != 0L)
/*      */       {
/*  165 */         if (this.jjmatchedPos < 7)
/*      */         {
/*  167 */           this.jjmatchedKind = 74;
/*  168 */           this.jjmatchedPos = 7;
/*      */         }
/*  170 */         return -1;
/*      */       }
/*  172 */       if ((active0 & 0x2700000000000000) != 0L)
/*  173 */         return 13;
/*  174 */       return -1;
/*      */     case 9: 
/*  176 */       if ((active0 & 0x7800000000) != 0L)
/*      */       {
/*  178 */         if (this.jjmatchedPos < 8)
/*      */         {
/*  180 */           this.jjmatchedKind = 74;
/*  181 */           this.jjmatchedPos = 8;
/*      */         }
/*  183 */         return -1;
/*      */       }
/*  185 */       if ((active0 & 0x400000000) != 0L)
/*      */       {
/*  187 */         if (this.jjmatchedPos < 7)
/*      */         {
/*  189 */           this.jjmatchedKind = 74;
/*  190 */           this.jjmatchedPos = 7;
/*      */         }
/*  192 */         return -1;
/*      */       }
/*  194 */       if (((active0 & 0x1B440F8040000000) != 0L) || ((active1 & 0x200) != 0L))
/*      */       {
/*  196 */         this.jjmatchedKind = 74;
/*  197 */         this.jjmatchedPos = 9;
/*  198 */         return 13;
/*      */       }
/*  200 */       if ((active0 & 0x2000000000000) != 0L)
/*  201 */         return 13;
/*  202 */       return -1;
/*      */     case 10: 
/*  204 */       if ((active0 & 0x8000000000) != 0L)
/*      */       {
/*  206 */         if (this.jjmatchedPos < 9)
/*      */         {
/*  208 */           this.jjmatchedKind = 74;
/*  209 */           this.jjmatchedPos = 9;
/*      */         }
/*  211 */         return -1;
/*      */       }
/*  213 */       if ((active0 & 0x7800000000) != 0L)
/*      */       {
/*  215 */         if (this.jjmatchedPos < 8)
/*      */         {
/*  217 */           this.jjmatchedKind = 74;
/*  218 */           this.jjmatchedPos = 8;
/*      */         }
/*  220 */         return -1;
/*      */       }
/*  222 */       if (((active0 & 0x1B040F0040000000) != 0L) || ((active1 & 0x200) != 0L))
/*      */       {
/*  224 */         this.jjmatchedKind = 74;
/*  225 */         this.jjmatchedPos = 10;
/*  226 */         return 13;
/*      */       }
/*  228 */       if ((active0 & 0x40000000000000) != 0L)
/*  229 */         return 13;
/*  230 */       return -1;
/*      */     case 11: 
/*  232 */       if ((active0 & 0x8000000000) != 0L)
/*      */       {
/*  234 */         if (this.jjmatchedPos < 9)
/*      */         {
/*  236 */           this.jjmatchedKind = 74;
/*  237 */           this.jjmatchedPos = 9;
/*      */         }
/*  239 */         return -1;
/*      */       }
/*  241 */       if (((active0 & 0x1B040F0040000000) != 0L) || ((active1 & 0x200) != 0L))
/*      */       {
/*  243 */         this.jjmatchedKind = 74;
/*  244 */         this.jjmatchedPos = 11;
/*  245 */         return 13;
/*      */       }
/*  247 */       return -1;
/*      */     case 12: 
/*  249 */       if ((active0 & 0x13000F0040000000) != 0L)
/*      */       {
/*  251 */         this.jjmatchedKind = 74;
/*  252 */         this.jjmatchedPos = 12;
/*  253 */         return 13;
/*      */       }
/*  255 */       if (((active0 & 0x804000000000000) != 0L) || ((active1 & 0x200) != 0L))
/*  256 */         return 13;
/*  257 */       return -1;
/*      */     case 13: 
/*  259 */       if ((active0 & 0x13000F0040000000) != 0L)
/*      */       {
/*  261 */         this.jjmatchedKind = 74;
/*  262 */         this.jjmatchedPos = 13;
/*  263 */         return 13;
/*      */       }
/*  265 */       return -1;
/*      */     case 14: 
/*  267 */       if ((active0 & 0x1200000000000000) != 0L)
/*  268 */         return 13;
/*  269 */       if ((active0 & 0x1000F0040000000) != 0L)
/*      */       {
/*  271 */         this.jjmatchedKind = 74;
/*  272 */         this.jjmatchedPos = 14;
/*  273 */         return 13;
/*      */       }
/*  275 */       return -1;
/*      */     case 15: 
/*  277 */       if ((active0 & 0xF0040000000) != 0L)
/*      */       {
/*  279 */         this.jjmatchedKind = 74;
/*  280 */         this.jjmatchedPos = 15;
/*  281 */         return 13;
/*      */       }
/*  283 */       if ((active0 & 0x100000000000000) != 0L)
/*  284 */         return 13;
/*  285 */       return -1;
/*      */     case 16: 
/*  287 */       if ((active0 & 0x10000000000) != 0L)
/*      */       {
/*  289 */         if (this.jjmatchedPos < 15)
/*      */         {
/*  291 */           this.jjmatchedKind = 74;
/*  292 */           this.jjmatchedPos = 15;
/*      */         }
/*  294 */         return -1;
/*      */       }
/*  296 */       if ((active0 & 0xE0040000000) != 0L)
/*      */       {
/*  298 */         this.jjmatchedKind = 74;
/*  299 */         this.jjmatchedPos = 16;
/*  300 */         return 13;
/*      */       }
/*  302 */       return -1;
/*      */     case 17: 
/*  304 */       if ((active0 & 0x60000000000) != 0L)
/*      */       {
/*  306 */         if (this.jjmatchedPos < 16)
/*      */         {
/*  308 */           this.jjmatchedKind = 74;
/*  309 */           this.jjmatchedPos = 16;
/*      */         }
/*  311 */         return -1;
/*      */       }
/*  313 */       if ((active0 & 0x10000000000) != 0L)
/*      */       {
/*  315 */         if (this.jjmatchedPos < 15)
/*      */         {
/*  317 */           this.jjmatchedKind = 74;
/*  318 */           this.jjmatchedPos = 15;
/*      */         }
/*  320 */         return -1;
/*      */       }
/*  322 */       if ((active0 & 0x80040000000) != 0L)
/*      */       {
/*  324 */         this.jjmatchedKind = 74;
/*  325 */         this.jjmatchedPos = 17;
/*  326 */         return 13;
/*      */       }
/*  328 */       return -1;
/*      */     case 18: 
/*  330 */       if ((active0 & 0x80000000000) != 0L)
/*      */       {
/*  332 */         if (this.jjmatchedPos < 17)
/*      */         {
/*  334 */           this.jjmatchedKind = 74;
/*  335 */           this.jjmatchedPos = 17;
/*      */         }
/*  337 */         return -1;
/*      */       }
/*  339 */       if ((active0 & 0x60000000000) != 0L)
/*      */       {
/*  341 */         if (this.jjmatchedPos < 16)
/*      */         {
/*  343 */           this.jjmatchedKind = 74;
/*  344 */           this.jjmatchedPos = 16;
/*      */         }
/*  346 */         return -1;
/*      */       }
/*  348 */       if ((active0 & 0x40000000) != 0L)
/*      */       {
/*  350 */         this.jjmatchedKind = 74;
/*  351 */         this.jjmatchedPos = 18;
/*  352 */         return 13;
/*      */       }
/*  354 */       return -1;
/*      */     case 19: 
/*  356 */       if ((active0 & 0x80000000000) != 0L)
/*      */       {
/*  358 */         if (this.jjmatchedPos < 17)
/*      */         {
/*  360 */           this.jjmatchedKind = 74;
/*  361 */           this.jjmatchedPos = 17;
/*      */         }
/*  363 */         return -1;
/*      */       }
/*  365 */       if ((active0 & 0x40000000) != 0L)
/*      */       {
/*  367 */         this.jjmatchedKind = 74;
/*  368 */         this.jjmatchedPos = 19;
/*  369 */         return 13;
/*      */       }
/*  371 */       return -1;
/*      */     case 20: 
/*  373 */       if ((active0 & 0x40000000) != 0L)
/*      */       {
/*  375 */         this.jjmatchedKind = 74;
/*  376 */         this.jjmatchedPos = 20;
/*  377 */         return 13;
/*      */       }
/*  379 */       return -1;
/*      */     }
/*  381 */     return -1;
/*      */   }
/*      */   
/*      */   private final int jjStartNfa_0(int pos, long active0, long active1)
/*      */   {
/*  386 */     return jjMoveNfa_0(jjStopStringLiteralDfa_0(pos, active0, active1), pos + 1);
/*      */   }
/*      */   
/*      */   private final int jjStopAtPos(int pos, int kind) {
/*  390 */     this.jjmatchedKind = kind;
/*  391 */     this.jjmatchedPos = pos;
/*  392 */     return pos + 1;
/*      */   }
/*      */   
/*      */   private final int jjStartNfaWithStates_0(int pos, int kind, int state) {
/*  396 */     this.jjmatchedKind = kind;
/*  397 */     this.jjmatchedPos = pos;
/*  398 */     try { this.curChar = this.input_stream.readChar();
/*  399 */     } catch (IOException e) { return pos + 1; }
/*  400 */     return jjMoveNfa_0(state, pos + 1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa0_0() {
/*  404 */     switch (this.curChar)
/*      */     {
/*      */     case '!': 
/*  407 */       return jjMoveStringLiteralDfa1_0(256L, 0L);
/*      */     case '$': 
/*  409 */       return jjStopAtPos(0, 13);
/*      */     case '(': 
/*  411 */       return jjStopAtPos(0, 76);
/*      */     case ')': 
/*  413 */       return jjStopAtPos(0, 77);
/*      */     case '*': 
/*  415 */       return jjStopAtPos(0, 84);
/*      */     case '+': 
/*  417 */       return jjStopAtPos(0, 5);
/*      */     case ',': 
/*  419 */       return jjStopAtPos(0, 83);
/*      */     case '-': 
/*  421 */       return jjStopAtPos(0, 6);
/*      */     case '.': 
/*  423 */       this.jjmatchedKind = 78;
/*  424 */       return jjMoveStringLiteralDfa1_0(0L, 32768L);
/*      */     case '/': 
/*  426 */       this.jjmatchedKind = 2;
/*  427 */       return jjMoveStringLiteralDfa1_0(8L, 0L);
/*      */     case ':': 
/*  429 */       return jjStopAtPos(0, 75);
/*      */     case '<': 
/*  431 */       this.jjmatchedKind = 9;
/*  432 */       return jjMoveStringLiteralDfa1_0(1024L, 0L);
/*      */     case '=': 
/*  434 */       return jjStopAtPos(0, 7);
/*      */     case '>': 
/*  436 */       this.jjmatchedKind = 11;
/*  437 */       return jjMoveStringLiteralDfa1_0(4096L, 0L);
/*      */     case '@': 
/*  439 */       return jjStopAtPos(0, 82);
/*      */     case '[': 
/*  441 */       return jjStopAtPos(0, 80);
/*      */     case ']': 
/*  443 */       return jjStopAtPos(0, 81);
/*      */     case 'a': 
/*  445 */       return jjMoveStringLiteralDfa1_0(1151068012544L, 0L);
/*      */     case 'b': 
/*  447 */       return jjMoveStringLiteralDfa1_0(4611686018427387904L, 0L);
/*      */     case 'c': 
/*  449 */       return jjMoveStringLiteralDfa1_0(45106369849720832L, 128L);
/*      */     case 'd': 
/*  451 */       return jjMoveStringLiteralDfa1_0(9345915944960L, 0L);
/*      */     case 'f': 
/*  453 */       return jjMoveStringLiteralDfa1_0(2473901162496L, 578L);
/*      */     case 'i': 
/*  455 */       return jjMoveStringLiteralDfa1_0(140737488355328L, 0L);
/*      */     case 'k': 
/*  457 */       return jjMoveStringLiteralDfa1_0(281474976710656L, 0L);
/*      */     case 'l': 
/*  459 */       return jjMoveStringLiteralDfa1_0(580542139465728L, 8L);
/*      */     case 'm': 
/*  461 */       return jjMoveStringLiteralDfa1_0(33554432L, 0L);
/*      */     case 'n': 
/*  463 */       return jjMoveStringLiteralDfa1_0(-8067072763673706496L, 20L);
/*      */     case 'o': 
/*  465 */       return jjMoveStringLiteralDfa1_0(8388608L, 0L);
/*      */     case 'p': 
/*  467 */       return jjMoveStringLiteralDfa1_0(39729521229824L, 0L);
/*      */     case 'r': 
/*  469 */       return jjMoveStringLiteralDfa1_0(0L, 256L);
/*      */     case 's': 
/*  471 */       return jjMoveStringLiteralDfa1_0(1103381910853255168L, 32L);
/*      */     case 't': 
/*  473 */       return jjMoveStringLiteralDfa1_0(2305843009482129408L, 1L);
/*      */     case '|': 
/*  475 */       return jjStopAtPos(0, 4);
/*      */     }
/*  477 */     return jjMoveNfa_0(1, 0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa1_0(long active0, long active1) {
/*      */     try {
/*  482 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  484 */       jjStopStringLiteralDfa_0(0, active0, active1);
/*  485 */       return 1;
/*      */     }
/*  487 */     switch (this.curChar)
/*      */     {
/*      */     case '.': 
/*  490 */       if ((active1 & 0x8000) != 0L)
/*  491 */         return jjStopAtPos(1, 79);
/*      */       break;
/*      */     case '/': 
/*  494 */       if ((active0 & 0x8) != 0L)
/*  495 */         return jjStopAtPos(1, 3);
/*      */       break;
/*      */     case '=': 
/*  498 */       if ((active0 & 0x100) != 0L)
/*  499 */         return jjStopAtPos(1, 8);
/*  500 */       if ((active0 & 0x400) != 0L)
/*  501 */         return jjStopAtPos(1, 10);
/*  502 */       if ((active0 & 0x1000) != 0L)
/*  503 */         return jjStopAtPos(1, 12);
/*      */       break;
/*      */     case 'a': 
/*  506 */       return jjMoveStringLiteralDfa2_0(active0, 3395369215983616L, active1, 10L);
/*      */     case 'd': 
/*  508 */       if ((active0 & 0x800000000000) != 0L)
/*  509 */         return jjStartNfaWithStates_0(1, 47, 13);
/*      */       break;
/*      */     case 'e': 
/*  512 */       return jjMoveStringLiteralDfa2_0(active0, 290823241465856L, active1, 128L);
/*      */     case 'h': 
/*  514 */       return jjMoveStringLiteralDfa2_0(active0, 4294967296L, active1, 0L);
/*      */     case 'i': 
/*  516 */       return jjMoveStringLiteralDfa2_0(active0, 67108864L, active1, 0L);
/*      */     case 'l': 
/*  518 */       return jjMoveStringLiteralDfa2_0(active0, 0L, active1, 64L);
/*      */     case 'n': 
/*  520 */       return jjMoveStringLiteralDfa2_0(active0, 1116708274176L, active1, 0L);
/*      */     case 'o': 
/*  522 */       return jjMoveStringLiteralDfa2_0(active0, -3413057539871342592L, active1, 768L);
/*      */     case 'r': 
/*  524 */       if ((active0 & 0x800000) != 0L)
/*  525 */         return jjStartNfaWithStates_0(1, 23, 13);
/*  526 */       return jjMoveStringLiteralDfa2_0(active0, 2305847545772900352L, active1, 1L);
/*      */     case 't': 
/*  528 */       return jjMoveStringLiteralDfa2_0(active0, 598978784800014336L, active1, 0L);
/*      */     case 'u': 
/*  530 */       return jjMoveStringLiteralDfa2_0(active0, 504403158265495552L, active1, 52L);
/*      */     }
/*      */     
/*      */     
/*  534 */     return jjStartNfa_0(0, active0, active1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa2_0(long old0, long active0, long old1, long active1) {
/*  538 */     if ((active0 &= old0 | active1 &= old1) == 0L)
/*  539 */       return jjStartNfa_0(0, old0, old1);
/*  540 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  542 */       jjStopStringLiteralDfa_0(1, active0, active1);
/*  543 */       return 2;
/*      */     }
/*  545 */     switch (this.curChar)
/*      */     {
/*      */     case 'a': 
/*  548 */       return jjMoveStringLiteralDfa3_0(active0, 2323857407723175936L, active1, 0L);
/*      */     case 'b': 
/*  550 */       return jjMoveStringLiteralDfa3_0(active0, 504403158265495552L, active1, 0L);
/*      */     case 'c': 
/*  552 */       return jjMoveStringLiteralDfa3_0(active0, 564066644918272L, active1, 0L);
/*      */     case 'd': 
/*  554 */       if ((active0 & 0x1000000) != 0L)
/*  555 */         return jjStartNfaWithStates_0(2, 24, 13);
/*  556 */       if ((active0 & 0x2000000) != 0L)
/*  557 */         return jjStartNfaWithStates_0(2, 25, 13);
/*  558 */       return jjMoveStringLiteralDfa3_0(active0, 134217728L, active1, 0L);
/*      */     case 'e': 
/*  560 */       return jjMoveStringLiteralDfa3_0(active0, 4535485464576L, active1, 0L);
/*      */     case 'i': 
/*  562 */       return jjMoveStringLiteralDfa3_0(active0, 4294967296L, active1, 128L);
/*      */     case 'l': 
/*  564 */       return jjMoveStringLiteralDfa3_0(active0, 2476048646144L, active1, 6L);
/*      */     case 'm': 
/*  566 */       if ((active1 & 0x20) != 0L)
/*  567 */         return jjStartNfaWithStates_0(2, 69, 13);
/*  568 */       return jjMoveStringLiteralDfa3_0(active0, 3377768976875520L, active1, 16L);
/*      */     case 'n': 
/*  570 */       return jjMoveStringLiteralDfa3_0(active0, 45035996273704960L, active1, 8L);
/*      */     case 'o': 
/*  572 */       return jjMoveStringLiteralDfa3_0(active0, 4611686019501129728L, active1, 64L);
/*      */     case 'r': 
/*  574 */       return jjMoveStringLiteralDfa3_0(active0, 1733885865127575552L, active1, 512L);
/*      */     case 's': 
/*  576 */       return jjMoveStringLiteralDfa3_0(active0, 62122406969344L, active1, 0L);
/*      */     case 't': 
/*  578 */       if ((active0 & 0x8000000000000000) != 0L)
/*  579 */         return jjStartNfaWithStates_0(2, 63, 13);
/*  580 */       return jjMoveStringLiteralDfa3_0(active0, 34359738368L, active1, 0L);
/*      */     case 'u': 
/*  582 */       return jjMoveStringLiteralDfa3_0(active0, 70368744177664L, active1, 257L);
/*      */     case 'v': 
/*  584 */       if ((active0 & 0x4000000) != 0L)
/*  585 */         return jjStartNfaWithStates_0(2, 26, 13);
/*      */       break;
/*      */     case 'x': 
/*  588 */       return jjMoveStringLiteralDfa3_0(active0, 268435456L, active1, 0L);
/*      */     case 'y': 
/*  590 */       if ((active0 & 0x1000000000000) != 0L) {
/*  591 */         return jjStartNfaWithStates_0(2, 48, 13);
/*      */       }
/*      */       break;
/*      */     }
/*      */     
/*  596 */     return jjStartNfa_0(1, active0, active1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa3_0(long old0, long active0, long old1, long active1) {
/*  600 */     if ((active0 &= old0 | active1 &= old1) == 0L)
/*  601 */       return jjStartNfa_0(1, old0, old1);
/*  602 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  604 */       jjStopStringLiteralDfa_0(2, active0, active1);
/*  605 */       return 3;
/*      */     }
/*  607 */     switch (this.curChar)
/*      */     {
/*      */     case 'a': 
/*  610 */       return jjMoveStringLiteralDfa4_0(active0, 562949953421312L, active1, 0L);
/*      */     case 'b': 
/*  612 */       return jjMoveStringLiteralDfa4_0(active0, 0L, active1, 16L);
/*      */     case 'c': 
/*  614 */       return jjMoveStringLiteralDfa4_0(active0, 9021081662783488L, active1, 0L);
/*      */     case 'e': 
/*  616 */       if ((active0 & 0x8000000) != 0L)
/*  617 */         return jjStartNfaWithStates_0(3, 27, 13);
/*  618 */       if ((active0 & 0x8000000000000) != 0L)
/*      */       {
/*  620 */         this.jjmatchedKind = 51;
/*  621 */         this.jjmatchedPos = 3;
/*      */       }
/*  623 */       else if ((active1 & 1L) != 0L) {
/*  624 */         return jjStartNfaWithStates_0(3, 64, 13); }
/*  625 */       return jjMoveStringLiteralDfa4_0(active0, 1127093907750912L, active1, 0L);
/*      */     case 'f': 
/*  627 */       return jjMoveStringLiteralDfa4_0(active0, 2147483648L, active1, 0L);
/*      */     case 'g': 
/*  629 */       if ((active1 & 0x8) != 0L)
/*  630 */         return jjStartNfaWithStates_0(3, 67, 13);
/*      */       break;
/*      */     case 'i': 
/*  633 */       return jjMoveStringLiteralDfa4_0(active0, 580999536302882816L, active1, 0L);
/*      */     case 'l': 
/*  635 */       if ((active1 & 0x4) != 0L)
/*  636 */         return jjStartNfaWithStates_0(3, 66, 13);
/*  637 */       return jjMoveStringLiteralDfa4_0(active0, 4611688496623517696L, active1, 128L);
/*      */     case 'm': 
/*  639 */       return jjMoveStringLiteralDfa4_0(active0, 1152921505143717888L, active1, 512L);
/*      */     case 'n': 
/*  641 */       return jjMoveStringLiteralDfa4_0(active0, 2305913377957871616L, active1, 256L);
/*      */     case 'o': 
/*  643 */       return jjMoveStringLiteralDfa4_0(active0, 0L, active1, 64L);
/*      */     case 'r': 
/*  645 */       return jjMoveStringLiteralDfa4_0(active0, 18014432869220352L, active1, 0L);
/*      */     case 's': 
/*  647 */       return jjMoveStringLiteralDfa4_0(active0, 504403158265495552L, active1, 2L);
/*      */     case 't': 
/*  649 */       if ((active0 & 0x10000000) != 0L)
/*  650 */         return jjStartNfaWithStates_0(3, 28, 13);
/*  651 */       if ((active0 & 0x100000000000) != 0L)
/*  652 */         return jjStartNfaWithStates_0(3, 44, 13);
/*  653 */       return jjMoveStringLiteralDfa4_0(active0, 36028797018963968L, active1, 0L);
/*      */     }
/*      */     
/*      */     
/*  657 */     return jjStartNfa_0(2, active0, active1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa4_0(long old0, long active0, long old1, long active1) {
/*  661 */     if ((active0 &= old0 | active1 &= old1) == 0L)
/*  662 */       return jjStartNfa_0(2, old0, old1);
/*  663 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  665 */       jjStopStringLiteralDfa_0(3, active0, active1);
/*  666 */       return 4;
/*      */     }
/*  668 */     switch (this.curChar)
/*      */     {
/*      */     case ':': 
/*  671 */       return jjMoveStringLiteralDfa5_0(active0, 2147483648L, active1, 0L);
/*      */     case 'a': 
/*  673 */       return jjMoveStringLiteralDfa5_0(active0, 1197957500880551936L, active1, 512L);
/*      */     case 'd': 
/*  675 */       if ((active1 & 0x100) != 0L)
/*  676 */         return jjStartNfaWithStates_0(4, 72, 13);
/*  677 */       return jjMoveStringLiteralDfa5_0(active0, 4294967296L, active1, 0L);
/*      */     case 'e': 
/*  679 */       if ((active1 & 0x2) != 0L)
/*  680 */         return jjStartNfaWithStates_0(4, 65, 13);
/*  681 */       return jjMoveStringLiteralDfa5_0(active0, 4611699901372301312L, active1, 16L);
/*      */     case 'i': 
/*  683 */       return jjMoveStringLiteralDfa5_0(active0, 34359738368L, active1, 128L);
/*      */     case 'l': 
/*  685 */       return jjMoveStringLiteralDfa5_0(active0, 562949953421312L, active1, 0L);
/*      */     case 'n': 
/*  687 */       return jjMoveStringLiteralDfa5_0(active0, 580964360520728576L, active1, 0L);
/*      */     case 'o': 
/*  689 */       return jjMoveStringLiteralDfa5_0(active0, 2473901162496L, active1, 0L);
/*      */     case 'r': 
/*  691 */       if ((active1 & 0x40) != 0L)
/*  692 */         return jjStartNfaWithStates_0(4, 70, 13);
/*      */       break;
/*      */     case 's': 
/*  695 */       return jjMoveStringLiteralDfa5_0(active0, 2306970094531510272L, active1, 0L);
/*      */     case 't': 
/*  697 */       if ((active0 & 0x400000000000) != 0L)
/*  698 */         return jjStartNfaWithStates_0(4, 46, 13);
/*  699 */       return jjMoveStringLiteralDfa5_0(active0, 522452741147066368L, active1, 0L);
/*      */     }
/*      */     
/*      */     
/*  703 */     return jjStartNfa_0(3, active0, active1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa5_0(long old0, long active0, long old1, long active1) {
/*  707 */     if ((active0 &= old0 | active1 &= old1) == 0L)
/*  708 */       return jjStartNfa_0(3, old0, old1);
/*  709 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  711 */       jjStopStringLiteralDfa_0(4, active0, active1);
/*  712 */       return 5;
/*      */     }
/*  714 */     switch (this.curChar)
/*      */     {
/*      */     case '-': 
/*  717 */       return jjMoveStringLiteralDfa6_0(active0, 562949953421312L, active1, 0L);
/*      */     case ':': 
/*  719 */       if ((active0 & 0x80000000) != 0L)
/*  720 */         return jjStopAtPos(5, 31);
/*  721 */       return jjMoveStringLiteralDfa6_0(active0, 4294967296L, active1, 0L);
/*      */     case 'a': 
/*  723 */       return jjMoveStringLiteralDfa6_0(active0, 4611686018427387904L, active1, 0L);
/*      */     case 'b': 
/*  725 */       return jjMoveStringLiteralDfa6_0(active0, 34359738368L, active1, 0L);
/*      */     case 'd': 
/*  727 */       return jjMoveStringLiteralDfa6_0(active0, 4535485464576L, active1, 0L);
/*      */     case 'g': 
/*  729 */       if ((active0 & 0x10000000000000) != 0L)
/*      */       {
/*  731 */         this.jjmatchedKind = 52;
/*  732 */         this.jjmatchedPos = 5;
/*      */       }
/*  734 */       return jjMoveStringLiteralDfa6_0(active0, 576460752303423488L, active1, 0L);
/*      */     case 'i': 
/*  736 */       return jjMoveStringLiteralDfa6_0(active0, 36063981391052800L, active1, 0L);
/*      */     case 'l': 
/*  738 */       return jjMoveStringLiteralDfa6_0(active0, 3458764513820540928L, active1, 0L);
/*      */     case 'n': 
/*  740 */       return jjMoveStringLiteralDfa6_0(active0, 9346385707008L, active1, 128L);
/*      */     case 'p': 
/*  742 */       return jjMoveStringLiteralDfa6_0(active0, 1125968626319360L, active1, 0L);
/*      */     case 'r': 
/*  744 */       if ((active1 & 0x10) != 0L)
/*  745 */         return jjStartNfaWithStates_0(5, 68, 13);
/*  746 */       return jjMoveStringLiteralDfa6_0(active0, 504403158265495552L, active1, 0L);
/*      */     case 's': 
/*  748 */       return jjMoveStringLiteralDfa6_0(active0, 18014399583223808L, active1, 0L);
/*      */     case 't': 
/*  750 */       if ((active0 & 0x20000000000000) != 0L)
/*  751 */         return jjStartNfaWithStates_0(5, 53, 13);
/*  752 */       return jjMoveStringLiteralDfa6_0(active0, 1125281431552L, active1, 512L);
/*      */     case 'w': 
/*  754 */       return jjMoveStringLiteralDfa6_0(active0, 2473901162496L, active1, 0L);
/*      */     }
/*      */     
/*      */     
/*  758 */     return jjStartNfa_0(4, active0, active1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa6_0(long old0, long active0, long old1, long active1) {
/*  762 */     if ((active0 &= old0 | active1 &= old1) == 0L)
/*  763 */       return jjStartNfa_0(4, old0, old1);
/*  764 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  766 */       jjStopStringLiteralDfa_0(5, active0, active1);
/*  767 */       return 6;
/*      */     }
/*  769 */     switch (this.curChar)
/*      */     {
/*      */     case '-': 
/*  772 */       return jjMoveStringLiteralDfa7_0(active0, 594475150812905472L, active1, 512L);
/*      */     case ':': 
/*  774 */       if ((active0 & 0x100000000) != 0L)
/*  775 */         return jjStopAtPos(6, 32);
/*  776 */       return jjMoveStringLiteralDfa7_0(active0, 8589934592L, active1, 0L);
/*      */     case 'a': 
/*  778 */       return jjMoveStringLiteralDfa7_0(active0, 2306968977840013312L, active1, 0L);
/*      */     case 'd': 
/*  780 */       return jjMoveStringLiteralDfa7_0(active0, 9345848836096L, active1, 0L);
/*      */     case 'g': 
/*  782 */       if ((active1 & 0x80) != 0L)
/*  783 */         return jjStartNfaWithStates_0(6, 71, 13);
/*      */       break;
/*      */     case 'i': 
/*  786 */       return jjMoveStringLiteralDfa7_0(active0, 1657331672258969600L, active1, 0L);
/*      */     case 'n': 
/*  788 */       if ((active0 & 0x4000000000000000) != 0L)
/*  789 */         return jjStartNfaWithStates_0(6, 62, 13);
/*  790 */       return jjMoveStringLiteralDfa7_0(active0, 36591746972385280L, active1, 0L);
/*      */     case 'o': 
/*  792 */       return jjMoveStringLiteralDfa7_0(active0, 36301063585792L, active1, 0L);
/*      */     case 's': 
/*  794 */       return jjMoveStringLiteralDfa7_0(active0, 1073741824L, active1, 0L);
/*      */     case 't': 
/*  796 */       if ((active0 & 0x20000000) != 0L)
/*  797 */         return jjStartNfaWithStates_0(6, 29, 13);
/*      */       break;
/*      */     case 'u': 
/*  800 */       return jjMoveStringLiteralDfa7_0(active0, 34359738368L, active1, 0L);
/*      */     }
/*      */     
/*      */     
/*  804 */     return jjStartNfa_0(5, active0, active1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa7_0(long old0, long active0, long old1, long active1) {
/*  808 */     if ((active0 &= old0 | active1 &= old1) == 0L)
/*  809 */       return jjStartNfa_0(5, old0, old1);
/*  810 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  812 */       jjStopStringLiteralDfa_0(6, active0, active1);
/*  813 */       return 7;
/*      */     }
/*  815 */     switch (this.curChar)
/*      */     {
/*      */     case ':': 
/*  818 */       if ((active0 & 0x200000000) != 0L)
/*  819 */         return jjStopAtPos(7, 33);
/*      */       break;
/*      */     case 'a': 
/*  822 */       return jjMoveStringLiteralDfa8_0(active0, 572295802257408L, active1, 0L);
/*      */     case 'c': 
/*  824 */       return jjMoveStringLiteralDfa8_0(active0, 1125968626319360L, active1, 0L);
/*      */     case 'i': 
/*  826 */       return jjMoveStringLiteralDfa8_0(active0, 1073741824L, active1, 0L);
/*      */     case 'l': 
/*  828 */       return jjMoveStringLiteralDfa8_0(active0, 576460752303423488L, active1, 0L);
/*      */     case 'n': 
/*  830 */       if ((active0 & 0x200000000000) != 0L)
/*  831 */         return jjStartNfaWithStates_0(7, 45, 13);
/*  832 */       return jjMoveStringLiteralDfa8_0(active0, 504410167652122624L, active1, 512L);
/*      */     case 'r': 
/*  834 */       return jjMoveStringLiteralDfa8_0(active0, 1116691496960L, active1, 0L);
/*      */     case 's': 
/*  836 */       if ((active0 & 0x80000000000000) != 0L)
/*  837 */         return jjStartNfaWithStates_0(7, 55, 13);
/*      */       break;
/*      */     case 't': 
/*  840 */       return jjMoveStringLiteralDfa8_0(active0, 2305843043573432320L, active1, 0L);
/*      */     case 'w': 
/*  842 */       return jjMoveStringLiteralDfa8_0(active0, 18014398509481984L, active1, 0L);
/*      */     case 'z': 
/*  844 */       return jjMoveStringLiteralDfa8_0(active0, 1152921504606846976L, active1, 0L);
/*      */     }
/*      */     
/*      */     
/*  848 */     return jjStartNfa_0(6, active0, active1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa8_0(long old0, long active0, long old1, long active1) {
/*  852 */     if ((active0 &= old0 | active1 &= old1) == 0L)
/*  853 */       return jjStartNfa_0(6, old0, old1);
/*  854 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  856 */       jjStopStringLiteralDfa_0(7, active0, active1);
/*  857 */       return 8;
/*      */     }
/*  859 */     switch (this.curChar)
/*      */     {
/*      */     case '-': 
/*  862 */       return jjMoveStringLiteralDfa9_0(active0, 1099511627776L, active1, 0L);
/*      */     case ':': 
/*  864 */       return jjMoveStringLiteralDfa9_0(active0, 17179869184L, active1, 0L);
/*      */     case 'e': 
/*  866 */       if ((active0 & 0x2000000000000000) != 0L)
/*  867 */         return jjStartNfaWithStates_0(8, 61, 13);
/*  868 */       return jjMoveStringLiteralDfa9_0(active0, 1730508259896328192L, active1, 0L);
/*      */     case 'g': 
/*  870 */       if ((active0 & 0x400000000000000) != 0L)
/*      */       {
/*  872 */         this.jjmatchedKind = 58;
/*  873 */         this.jjmatchedPos = 8;
/*      */       }
/*  875 */       return jjMoveStringLiteralDfa9_0(active0, 216179791500410880L, active1, 0L);
/*      */     case 'i': 
/*  877 */       return jjMoveStringLiteralDfa9_0(active0, 18014398509481984L, active1, 0L);
/*      */     case 'm': 
/*  879 */       return jjMoveStringLiteralDfa9_0(active0, 562949953421312L, active1, 0L);
/*      */     case 'n': 
/*  881 */       return jjMoveStringLiteralDfa9_0(active0, 9346922577920L, active1, 0L);
/*      */     case 'u': 
/*  883 */       return jjMoveStringLiteralDfa9_0(active0, 0L, active1, 512L);
/*      */     }
/*      */     
/*      */     
/*  887 */     return jjStartNfa_0(7, active0, active1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa9_0(long old0, long active0, long old1, long active1) {
/*  891 */     if ((active0 &= old0 | active1 &= old1) == 0L)
/*  892 */       return jjStartNfa_0(7, old0, old1);
/*  893 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  895 */       jjStopStringLiteralDfa_0(8, active0, active1);
/*  896 */       return 9;
/*      */     }
/*  898 */     switch (this.curChar)
/*      */     {
/*      */     case '-': 
/*  901 */       return jjMoveStringLiteralDfa10_0(active0, 1370226783697240064L, active1, 0L);
/*      */     case ':': 
/*  903 */       if ((active0 & 0x400000000) != 0L)
/*  904 */         return jjStopAtPos(9, 34);
/*  905 */       return jjMoveStringLiteralDfa10_0(active0, 515396075520L, active1, 0L);
/*      */     case 'e': 
/*  907 */       if ((active0 & 0x2000000000000) != 0L)
/*  908 */         return jjStartNfaWithStates_0(9, 49, 13);
/*      */       break;
/*      */     case 'g': 
/*  911 */       return jjMoveStringLiteralDfa10_0(active0, 1073741824L, active1, 0L);
/*      */     case 'm': 
/*  913 */       return jjMoveStringLiteralDfa10_0(active0, 0L, active1, 512L);
/*      */     case 'n': 
/*  915 */       return jjMoveStringLiteralDfa10_0(active0, 576460752303423488L, active1, 0L);
/*      */     case 'o': 
/*  917 */       return jjMoveStringLiteralDfa10_0(active0, 1099511627776L, active1, 0L);
/*      */     case 't': 
/*  919 */       return jjMoveStringLiteralDfa10_0(active0, 18023744358318080L, active1, 0L);
/*      */     }
/*      */     
/*      */     
/*  923 */     return jjStartNfa_0(8, active0, active1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa10_0(long old0, long active0, long old1, long active1) {
/*  927 */     if ((active0 &= old0 | active1 &= old1) == 0L)
/*  928 */       return jjStartNfa_0(8, old0, old1);
/*  929 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  931 */       jjStopStringLiteralDfa_0(9, active0, active1);
/*  932 */       return 10;
/*      */     }
/*  934 */     switch (this.curChar)
/*      */     {
/*      */     case '-': 
/*  937 */       return jjMoveStringLiteralDfa11_0(active0, 8797166764032L, active1, 0L);
/*      */     case ':': 
/*  939 */       if ((active0 & 0x800000000) != 0L)
/*  940 */         return jjStopAtPos(10, 35);
/*  941 */       if ((active0 & 0x1000000000) != 0L)
/*  942 */         return jjStopAtPos(10, 36);
/*  943 */       if ((active0 & 0x2000000000) != 0L)
/*  944 */         return jjStopAtPos(10, 37);
/*  945 */       if ((active0 & 0x4000000000) != 0L)
/*  946 */         return jjStopAtPos(10, 38);
/*  947 */       return jjMoveStringLiteralDfa11_0(active0, 549755813888L, active1, 0L);
/*      */     case 'a': 
/*  949 */       return jjMoveStringLiteralDfa11_0(active0, 144115188075855872L, active1, 0L);
/*      */     case 'b': 
/*  951 */       return jjMoveStringLiteralDfa11_0(active0, 72057594037927936L, active1, 512L);
/*      */     case 'g': 
/*  953 */       return jjMoveStringLiteralDfa11_0(active0, 576460752303423488L, active1, 0L);
/*      */     case 'h': 
/*  955 */       if ((active0 & 0x40000000000000) != 0L)
/*  956 */         return jjStartNfaWithStates_0(10, 54, 13);
/*      */       break;
/*      */     case 'r': 
/*  959 */       return jjMoveStringLiteralDfa11_0(active0, 1099511627776L, active1, 0L);
/*      */     case 's': 
/*  961 */       return jjMoveStringLiteralDfa11_0(active0, 1152928101676613632L, active1, 0L);
/*      */     case 'u': 
/*  963 */       return jjMoveStringLiteralDfa11_0(active0, 1125899906842624L, active1, 0L);
/*      */     }
/*      */     
/*      */     
/*  967 */     return jjStartNfa_0(9, active0, active1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa11_0(long old0, long active0, long old1, long active1) {
/*  971 */     if ((active0 &= old0 | active1 &= old1) == 0L)
/*  972 */       return jjStartNfa_0(9, old0, old1);
/*  973 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  975 */       jjStopStringLiteralDfa_0(10, active0, active1);
/*  976 */       return 11;
/*      */     }
/*  978 */     switch (this.curChar)
/*      */     {
/*      */     case '-': 
/*  981 */       return jjMoveStringLiteralDfa12_0(active0, 1099511627776L, active1, 0L);
/*      */     case ':': 
/*  983 */       if ((active0 & 0x8000000000) != 0L)
/*  984 */         return jjStopAtPos(11, 39);
/*      */       break;
/*      */     case 'e': 
/*  987 */       return jjMoveStringLiteralDfa12_0(active0, 72057594037927936L, active1, 512L);
/*      */     case 'f': 
/*  989 */       return jjMoveStringLiteralDfa12_0(active0, 144115188075855872L, active1, 0L);
/*      */     case 'i': 
/*  991 */       return jjMoveStringLiteralDfa12_0(active0, 6598143508480L, active1, 0L);
/*      */     case 'o': 
/*  993 */       return jjMoveStringLiteralDfa12_0(active0, 8796093022208L, active1, 0L);
/*      */     case 'p': 
/*  995 */       return jjMoveStringLiteralDfa12_0(active0, 1152921504606846976L, active1, 0L);
/*      */     case 'r': 
/*  997 */       return jjMoveStringLiteralDfa12_0(active0, 1125899906842624L, active1, 0L);
/*      */     case 't': 
/*  999 */       return jjMoveStringLiteralDfa12_0(active0, 576460752303423488L, active1, 0L);
/*      */     }
/*      */     
/*      */     
/* 1003 */     return jjStartNfa_0(10, active0, active1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa12_0(long old0, long active0, long old1, long active1) {
/* 1007 */     if ((active0 &= old0 | active1 &= old1) == 0L)
/* 1008 */       return jjStartNfa_0(10, old0, old1);
/* 1009 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1011 */       jjStopStringLiteralDfa_0(11, active0, active1);
/* 1012 */       return 12;
/*      */     }
/* 1014 */     switch (this.curChar)
/*      */     {
/*      */     case 'a': 
/* 1017 */       return jjMoveStringLiteralDfa13_0(active0, 1152921504606846976L, active1, 0L);
/*      */     case 'b': 
/* 1019 */       return jjMoveStringLiteralDfa13_0(active0, 6597069766656L, active1, 0L);
/*      */     case 'f': 
/* 1021 */       return jjMoveStringLiteralDfa13_0(active0, 72057594037927936L, active1, 0L);
/*      */     case 'h': 
/* 1023 */       if ((active0 & 0x800000000000000) != 0L)
/* 1024 */         return jjStartNfaWithStates_0(12, 59, 13);
/*      */       break;
/*      */     case 'i': 
/* 1027 */       if ((active0 & 0x4000000000000) != 0L)
/* 1028 */         return jjStartNfaWithStates_0(12, 50, 13);
/*      */       break;
/*      */     case 'n': 
/* 1031 */       return jjMoveStringLiteralDfa13_0(active0, 1073741824L, active1, 0L);
/*      */     case 'r': 
/* 1033 */       if ((active1 & 0x200) != 0L)
/* 1034 */         return jjStartNfaWithStates_0(12, 73, 13);
/* 1035 */       return jjMoveStringLiteralDfa13_0(active0, 8796093022208L, active1, 0L);
/*      */     case 's': 
/* 1037 */       return jjMoveStringLiteralDfa13_0(active0, 1099511627776L, active1, 0L);
/*      */     case 't': 
/* 1039 */       return jjMoveStringLiteralDfa13_0(active0, 144115188075855872L, active1, 0L);
/*      */     }
/*      */     
/*      */     
/* 1043 */     return jjStartNfa_0(11, active0, active1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa13_0(long old0, long active0, long old1, long active1) {
/* 1047 */     if ((active0 &= old0 | active1 &= old1) == 0L)
/* 1048 */       return jjStartNfa_0(11, old0, old1);
/* 1049 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1051 */       jjStopStringLiteralDfa_0(12, active0, 0L);
/* 1052 */       return 13;
/*      */     }
/* 1054 */     switch (this.curChar)
/*      */     {
/*      */     case '-': 
/* 1057 */       return jjMoveStringLiteralDfa14_0(active0, 8796093022208L);
/*      */     case 'c': 
/* 1059 */       return jjMoveStringLiteralDfa14_0(active0, 1152921504606846976L);
/*      */     case 'e': 
/* 1061 */       return jjMoveStringLiteralDfa14_0(active0, 144116287587483648L);
/*      */     case 'l': 
/* 1063 */       return jjMoveStringLiteralDfa14_0(active0, 6597069766656L);
/*      */     case 'o': 
/* 1065 */       return jjMoveStringLiteralDfa14_0(active0, 72057594037927936L);
/*      */     case 's': 
/* 1067 */       return jjMoveStringLiteralDfa14_0(active0, 1073741824L);
/*      */     }
/*      */     
/*      */     
/* 1071 */     return jjStartNfa_0(12, active0, 0L);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa14_0(long old0, long active0) {
/* 1075 */     if ((active0 &= old0) == 0L)
/* 1076 */       return jjStartNfa_0(12, old0, 0L);
/* 1077 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1079 */       jjStopStringLiteralDfa_0(13, active0, 0L);
/* 1080 */       return 14;
/*      */     }
/* 1082 */     switch (this.curChar)
/*      */     {
/*      */     case 'e': 
/* 1085 */       if ((active0 & 0x1000000000000000) != 0L)
/* 1086 */         return jjStartNfaWithStates_0(14, 60, 13);
/*      */       break;
/*      */     case 'i': 
/* 1089 */       return jjMoveStringLiteralDfa15_0(active0, 6597069766656L);
/*      */     case 'l': 
/* 1091 */       return jjMoveStringLiteralDfa15_0(active0, 1099511627776L);
/*      */     case 'r': 
/* 1093 */       if ((active0 & 0x200000000000000) != 0L)
/* 1094 */         return jjStartNfaWithStates_0(14, 57, 13);
/* 1095 */       return jjMoveStringLiteralDfa15_0(active0, 72057594037927936L);
/*      */     case 's': 
/* 1097 */       return jjMoveStringLiteralDfa15_0(active0, 8796093022208L);
/*      */     case 't': 
/* 1099 */       return jjMoveStringLiteralDfa15_0(active0, 1073741824L);
/*      */     }
/*      */     
/*      */     
/* 1103 */     return jjStartNfa_0(13, active0, 0L);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa15_0(long old0, long active0) {
/* 1107 */     if ((active0 &= old0) == 0L)
/* 1108 */       return jjStartNfa_0(13, old0, 0L);
/* 1109 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1111 */       jjStopStringLiteralDfa_0(14, active0, 0L);
/* 1112 */       return 15;
/*      */     }
/* 1114 */     switch (this.curChar)
/*      */     {
/*      */     case 'e': 
/* 1117 */       if ((active0 & 0x100000000000000) != 0L)
/* 1118 */         return jjStartNfaWithStates_0(15, 56, 13);
/* 1119 */       return jjMoveStringLiteralDfa16_0(active0, 8796093022208L);
/*      */     case 'f': 
/* 1121 */       return jjMoveStringLiteralDfa16_0(active0, 1099511627776L);
/*      */     case 'n': 
/* 1123 */       return jjMoveStringLiteralDfa16_0(active0, 6597069766656L);
/*      */     case 'r': 
/* 1125 */       return jjMoveStringLiteralDfa16_0(active0, 1073741824L);
/*      */     }
/*      */     
/*      */     
/* 1129 */     return jjStartNfa_0(14, active0, 0L);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa16_0(long old0, long active0) {
/* 1133 */     if ((active0 &= old0) == 0L)
/* 1134 */       return jjStartNfa_0(14, old0, 0L);
/* 1135 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1137 */       jjStopStringLiteralDfa_0(15, active0, 0L);
/* 1138 */       return 16;
/*      */     }
/* 1140 */     switch (this.curChar)
/*      */     {
/*      */     case ':': 
/* 1143 */       return jjMoveStringLiteralDfa17_0(active0, 1099511627776L);
/*      */     case 'g': 
/* 1145 */       return jjMoveStringLiteralDfa17_0(active0, 6597069766656L);
/*      */     case 'l': 
/* 1147 */       return jjMoveStringLiteralDfa17_0(active0, 8796093022208L);
/*      */     case 'u': 
/* 1149 */       return jjMoveStringLiteralDfa17_0(active0, 1073741824L);
/*      */     }
/*      */     
/*      */     
/* 1153 */     return jjStartNfa_0(15, active0, 0L);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa17_0(long old0, long active0) {
/* 1157 */     if ((active0 &= old0) == 0L)
/* 1158 */       return jjStartNfa_0(15, old0, 0L);
/* 1159 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1161 */       jjStopStringLiteralDfa_0(16, active0, 0L);
/* 1162 */       return 17;
/*      */     }
/* 1164 */     switch (this.curChar)
/*      */     {
/*      */     case ':': 
/* 1167 */       if ((active0 & 0x10000000000) != 0L)
/* 1168 */         return jjStopAtPos(17, 40);
/* 1169 */       return jjMoveStringLiteralDfa18_0(active0, 6597069766656L);
/*      */     case 'c': 
/* 1171 */       return jjMoveStringLiteralDfa18_0(active0, 1073741824L);
/*      */     case 'f': 
/* 1173 */       return jjMoveStringLiteralDfa18_0(active0, 8796093022208L);
/*      */     }
/*      */     
/*      */     
/* 1177 */     return jjStartNfa_0(16, active0, 0L);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa18_0(long old0, long active0) {
/* 1181 */     if ((active0 &= old0) == 0L)
/* 1182 */       return jjStartNfa_0(16, old0, 0L);
/* 1183 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1185 */       jjStopStringLiteralDfa_0(17, active0, 0L);
/* 1186 */       return 18;
/*      */     }
/* 1188 */     switch (this.curChar)
/*      */     {
/*      */     case ':': 
/* 1191 */       if ((active0 & 0x20000000000) != 0L)
/* 1192 */         return jjStopAtPos(18, 41);
/* 1193 */       if ((active0 & 0x40000000000) != 0L)
/* 1194 */         return jjStopAtPos(18, 42);
/* 1195 */       return jjMoveStringLiteralDfa19_0(active0, 8796093022208L);
/*      */     case 't': 
/* 1197 */       return jjMoveStringLiteralDfa19_0(active0, 1073741824L);
/*      */     }
/*      */     
/*      */     
/* 1201 */     return jjStartNfa_0(17, active0, 0L);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa19_0(long old0, long active0) {
/* 1205 */     if ((active0 &= old0) == 0L)
/* 1206 */       return jjStartNfa_0(17, old0, 0L);
/* 1207 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1209 */       jjStopStringLiteralDfa_0(18, active0, 0L);
/* 1210 */       return 19;
/*      */     }
/* 1212 */     switch (this.curChar)
/*      */     {
/*      */     case ':': 
/* 1215 */       if ((active0 & 0x80000000000) != 0L)
/* 1216 */         return jjStopAtPos(19, 43);
/*      */       break;
/*      */     case 'i': 
/* 1219 */       return jjMoveStringLiteralDfa20_0(active0, 1073741824L);
/*      */     }
/*      */     
/*      */     
/* 1223 */     return jjStartNfa_0(18, active0, 0L);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa20_0(long old0, long active0) {
/* 1227 */     if ((active0 &= old0) == 0L)
/* 1228 */       return jjStartNfa_0(18, old0, 0L);
/* 1229 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1231 */       jjStopStringLiteralDfa_0(19, active0, 0L);
/* 1232 */       return 20;
/*      */     }
/* 1234 */     switch (this.curChar)
/*      */     {
/*      */     case 'o': 
/* 1237 */       return jjMoveStringLiteralDfa21_0(active0, 1073741824L);
/*      */     }
/*      */     
/*      */     
/* 1241 */     return jjStartNfa_0(19, active0, 0L);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa21_0(long old0, long active0) {
/* 1245 */     if ((active0 &= old0) == 0L)
/* 1246 */       return jjStartNfa_0(19, old0, 0L);
/* 1247 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1249 */       jjStopStringLiteralDfa_0(20, active0, 0L);
/* 1250 */       return 21;
/*      */     }
/* 1252 */     switch (this.curChar)
/*      */     {
/*      */     case 'n': 
/* 1255 */       if ((active0 & 0x40000000) != 0L) {
/* 1256 */         return jjStartNfaWithStates_0(21, 30, 13);
/*      */       }
/*      */       break;
/*      */     }
/*      */     
/* 1261 */     return jjStartNfa_0(20, active0, 0L);
/*      */   }
/*      */   
/*      */   private final void jjCheckNAdd(int state) {
/* 1265 */     if (this.jjrounds[state] != this.jjround)
/*      */     {
/* 1267 */       this.jjstateSet[(this.jjnewStateCnt++)] = state;
/* 1268 */       this.jjrounds[state] = this.jjround;
/*      */     }
/*      */   }
/*      */   
/*      */   private final void jjAddStates(int start, int end) {
/*      */     do {
/* 1274 */       this.jjstateSet[(this.jjnewStateCnt++)] = jjnextStates[start];
/* 1275 */     } while (start++ != end);
/*      */   }
/*      */   
/*      */   private final void jjCheckNAddTwoStates(int state1, int state2) {
/* 1279 */     jjCheckNAdd(state1);
/* 1280 */     jjCheckNAdd(state2);
/*      */   }
/*      */   
/*      */   private final void jjCheckNAddStates(int start, int end) {
/*      */     do {
/* 1285 */       jjCheckNAdd(jjnextStates[start]);
/* 1286 */     } while (start++ != end);
/*      */   }
/*      */   
/*      */   private final void jjCheckNAddStates(int start) {
/* 1290 */     jjCheckNAdd(jjnextStates[start]);
/* 1291 */     jjCheckNAdd(jjnextStates[(start + 1)]); }
/*      */   
/* 1293 */   static final long[] jjbitVec0 = { -2L, -1L, -1L, -1L };
/*      */   
/*      */ 
/* 1296 */   static final long[] jjbitVec2 = { 0L, 0L, -1L, -1L };
/*      */   
/*      */ 
/* 1299 */   static final long[] jjbitVec3 = { 0L, -16384L, -17590038560769L, 8388607L };
/*      */   
/*      */ 
/* 1302 */   static final long[] jjbitVec4 = { 0L, 0L, 0L, -36028797027352577L };
/*      */   
/*      */ 
/* 1305 */   static final long[] jjbitVec5 = { 9219994337134247935L, 9223372036854775294L, -1L, -274156627316187121L };
/*      */   
/*      */ 
/* 1308 */   static final long[] jjbitVec6 = { 16777215L, -65536L, -576458553280167937L, 3L };
/*      */   
/*      */ 
/* 1311 */   static final long[] jjbitVec7 = { 0L, 0L, -17179879616L, 4503588160110591L };
/*      */   
/*      */ 
/* 1314 */   static final long[] jjbitVec8 = { -8194L, -536936449L, -65533L, 234134404065073567L };
/*      */   
/*      */ 
/* 1317 */   static final long[] jjbitVec9 = { -562949953421312L, -8547991553L, 127L, 1979120929931264L };
/*      */   
/*      */ 
/* 1320 */   static final long[] jjbitVec10 = { 576460743713488896L, -562949953419266L, 9007199254740991999L, 412319973375L };
/*      */   
/*      */ 
/* 1323 */   static final long[] jjbitVec11 = { 2594073385365405664L, 17163091968L, 271902628478820320L, 844440767823872L };
/*      */   
/*      */ 
/* 1326 */   static final long[] jjbitVec12 = { 247132830528276448L, 7881300924956672L, 2589004636761075680L, 4294967296L };
/*      */   
/*      */ 
/* 1329 */   static final long[] jjbitVec13 = { 2579997437506199520L, 15837691904L, 270153412153034720L, 0L };
/*      */   
/*      */ 
/* 1332 */   static final long[] jjbitVec14 = { 283724577500946400L, 12884901888L, 283724577500946400L, 13958643712L };
/*      */   
/*      */ 
/* 1335 */   static final long[] jjbitVec15 = { 288228177128316896L, 12884901888L, 0L, 0L };
/*      */   
/*      */ 
/* 1338 */   static final long[] jjbitVec16 = { 3799912185593854L, 63L, 2309621682768192918L, 31L };
/*      */   
/*      */ 
/* 1341 */   static final long[] jjbitVec17 = { 0L, 4398046510847L, 0L, 0L };
/*      */   
/*      */ 
/* 1344 */   static final long[] jjbitVec18 = { 0L, 0L, -4294967296L, 36028797018898495L };
/*      */   
/*      */ 
/* 1347 */   static final long[] jjbitVec19 = { 5764607523034749677L, 12493387738468353L, -756383734487318528L, 144405459145588743L };
/*      */   
/*      */ 
/* 1350 */   static final long[] jjbitVec20 = { -1L, -1L, -4026531841L, 288230376151711743L };
/*      */   
/*      */ 
/* 1353 */   static final long[] jjbitVec21 = { -3233808385L, 4611686017001275199L, 6908521828386340863L, 2295745090394464220L };
/*      */   
/*      */ 
/* 1356 */   static final long[] jjbitVec22 = { 83837761617920L, 0L, 7L, 0L };
/*      */   
/*      */ 
/* 1359 */   static final long[] jjbitVec23 = { 4389456576640L, -2L, -8587837441L, 576460752303423487L };
/*      */   
/*      */ 
/* 1362 */   static final long[] jjbitVec24 = { 35184372088800L, 0L, 0L, 0L };
/*      */   
/*      */ 
/* 1365 */   static final long[] jjbitVec25 = { -1L, -1L, 274877906943L, 0L };
/*      */   
/*      */ 
/* 1368 */   static final long[] jjbitVec26 = { -1L, -1L, 68719476735L, 0L };
/*      */   
/*      */ 
/* 1371 */   static final long[] jjbitVec27 = { 0L, 0L, 36028797018963968L, -36028797027352577L };
/*      */   
/*      */ 
/* 1374 */   static final long[] jjbitVec28 = { 16777215L, -65536L, -576458553280167937L, 196611L };
/*      */   
/*      */ 
/* 1377 */   static final long[] jjbitVec29 = { -1L, 12884901951L, -17179879488L, 4503588160110591L };
/*      */   
/*      */ 
/* 1380 */   static final long[] jjbitVec30 = { -8194L, -536936449L, -65413L, 234134404065073567L };
/*      */   
/*      */ 
/* 1383 */   static final long[] jjbitVec31 = { -562949953421312L, -8547991553L, -4899916411759099777L, 1979120929931286L };
/*      */   
/*      */ 
/* 1386 */   static final long[] jjbitVec32 = { 576460743713488896L, -277081224642561L, 9007199254740991999L, 288017070894841855L };
/*      */   
/*      */ 
/* 1389 */   static final long[] jjbitVec33 = { -864691128455135250L, 281268803485695L, -3186861885341720594L, 1125692414638495L };
/*      */   
/*      */ 
/* 1392 */   static final long[] jjbitVec34 = { -3211631683292264476L, 9006925953907079L, -869759877059465234L, 281204393786303L };
/*      */   
/*      */ 
/* 1395 */   static final long[] jjbitVec35 = { -878767076314341394L, 281215949093263L, -4341532606274353172L, 280925229301191L };
/*      */   
/*      */ 
/* 1398 */   static final long[] jjbitVec36 = { -4327961440926441490L, 281212990012895L, -4327961440926441492L, 281214063754719L };
/*      */   
/*      */ 
/* 1401 */   static final long[] jjbitVec37 = { -4323457841299070996L, 281212992110031L, 0L, 0L };
/*      */   
/*      */ 
/* 1404 */   static final long[] jjbitVec38 = { 576320014815068158L, 67076095L, 4323293666156225942L, 67059551L };
/*      */   
/*      */ 
/* 1407 */   static final long[] jjbitVec39 = { -4422530440275951616L, -558551906910465L, 215680200883507167L, 0L };
/*      */   
/*      */ 
/* 1410 */   static final long[] jjbitVec40 = { 0L, 0L, 0L, 9126739968L };
/*      */   
/*      */ 
/* 1413 */   static final long[] jjbitVec41 = { 17732914942836896L, -2L, -6876561409L, 8646911284551352319L };
/*      */   
/*      */ 
/*      */ 
/*      */   private final int jjMoveNfa_0(int startState, int curPos)
/*      */   {
/* 1419 */     int startsAt = 0;
/* 1420 */     this.jjnewStateCnt = 14;
/* 1421 */     int i = 1;
/* 1422 */     this.jjstateSet[0] = startState;
/* 1423 */     int kind = Integer.MAX_VALUE;
/*      */     for (;;)
/*      */     {
/* 1426 */       if (++this.jjround == Integer.MAX_VALUE)
/* 1427 */         ReInitRounds();
/* 1428 */       if (this.curChar < '@')
/*      */       {
/* 1430 */         long l = 1L << this.curChar;
/*      */         do
/*      */         {
/* 1433 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 1: 
/* 1436 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/* 1438 */               if (kind > 16)
/* 1439 */                 kind = 16;
/* 1440 */               jjCheckNAddTwoStates(7, 8);
/*      */             }
/* 1442 */             else if ((0x100002600 & l) != 0L)
/*      */             {
/* 1444 */               if (kind > 1)
/* 1445 */                 kind = 1;
/* 1446 */               jjCheckNAdd(0);
/*      */             }
/* 1448 */             else if (this.curChar == '.') {
/* 1449 */               jjCheckNAdd(11);
/* 1450 */             } else if (this.curChar == '\'') {
/* 1451 */               jjCheckNAddTwoStates(5, 6);
/* 1452 */             } else if (this.curChar == '"') {
/* 1453 */               jjCheckNAddTwoStates(2, 3);
/*      */             }
/*      */             break;
/* 1456 */           case 0:  if ((0x100002600 & l) != 0L)
/*      */             {
/* 1458 */               if (kind > 1)
/* 1459 */                 kind = 1;
/* 1460 */               jjCheckNAdd(0); }
/* 1461 */             break;
/*      */           case 2: 
/* 1463 */             if ((0xFFFFFFFBFFFFFFFF & l) != 0L)
/* 1464 */               jjCheckNAddTwoStates(2, 3);
/*      */             break;
/*      */           case 3: 
/* 1467 */             if ((this.curChar == '"') && (kind > 14))
/* 1468 */               kind = 14;
/*      */             break;
/*      */           case 4: 
/* 1471 */             if (this.curChar == '\'')
/* 1472 */               jjCheckNAddTwoStates(5, 6);
/*      */             break;
/*      */           case 5: 
/* 1475 */             if ((0xFFFFFF7FFFFFFFFF & l) != 0L)
/* 1476 */               jjCheckNAddTwoStates(5, 6);
/*      */             break;
/*      */           case 6: 
/* 1479 */             if ((this.curChar == '\'') && (kind > 14))
/* 1480 */               kind = 14;
/*      */             break;
/*      */           case 7: 
/* 1483 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/* 1485 */               if (kind > 16)
/* 1486 */                 kind = 16;
/* 1487 */               jjCheckNAddTwoStates(7, 8); }
/* 1488 */             break;
/*      */           case 8: 
/* 1490 */             if (this.curChar == '.')
/*      */             {
/* 1492 */               if (kind > 16)
/* 1493 */                 kind = 16;
/* 1494 */               jjCheckNAdd(9); }
/* 1495 */             break;
/*      */           case 9: 
/* 1497 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/* 1499 */               if (kind > 16)
/* 1500 */                 kind = 16;
/* 1501 */               jjCheckNAdd(9); }
/* 1502 */             break;
/*      */           case 10: 
/* 1504 */             if (this.curChar == '.')
/* 1505 */               jjCheckNAdd(11);
/*      */             break;
/*      */           case 11: 
/* 1508 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/* 1510 */               if (kind > 16)
/* 1511 */                 kind = 16;
/* 1512 */               jjCheckNAdd(11); }
/* 1513 */             break;
/*      */           case 13: 
/* 1515 */             if ((0x3FF600000000000 & l) != 0L)
/*      */             {
/* 1517 */               if (kind > 74)
/* 1518 */                 kind = 74;
/* 1519 */               this.jjstateSet[(this.jjnewStateCnt++)] = 13;
/*      */             }
/*      */             break;
/*      */           }
/* 1523 */         } while (i != startsAt);
/*      */       }
/* 1525 */       else if (this.curChar < '')
/*      */       {
/* 1527 */         long l = 1L << (this.curChar & 0x3F);
/*      */         do
/*      */         {
/* 1530 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 1: 
/*      */           case 13: 
/* 1534 */             if ((0x7FFFFFE87FFFFFE & l) != 0L)
/*      */             {
/* 1536 */               if (kind > 74)
/* 1537 */                 kind = 74;
/* 1538 */               jjCheckNAdd(13); }
/* 1539 */             break;
/*      */           case 2: 
/* 1541 */             jjAddStates(0, 1);
/* 1542 */             break;
/*      */           case 5: 
/* 1544 */             jjAddStates(2, 3);
/*      */           
/*      */           }
/*      */           
/* 1548 */         } while (i != startsAt);
/*      */       }
/*      */       else
/*      */       {
/* 1552 */         int hiByte = this.curChar >> '\b';
/* 1553 */         int i1 = hiByte >> 6;
/* 1554 */         long l1 = 1L << (hiByte & 0x3F);
/* 1555 */         int i2 = (this.curChar & 0xFF) >> '\006';
/* 1556 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         do
/*      */         {
/* 1559 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 1: 
/* 1562 */             if (jjCanMove_1(hiByte, i1, i2, l1, l2))
/*      */             {
/* 1564 */               if (kind > 74)
/* 1565 */                 kind = 74;
/* 1566 */               jjCheckNAdd(13); }
/* 1567 */             break;
/*      */           case 2: 
/* 1569 */             if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/* 1570 */               jjAddStates(0, 1);
/*      */             break;
/*      */           case 5: 
/* 1573 */             if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/* 1574 */               jjAddStates(2, 3);
/*      */             break;
/*      */           case 13: 
/* 1577 */             if (jjCanMove_2(hiByte, i1, i2, l1, l2))
/*      */             {
/* 1579 */               if (kind > 74)
/* 1580 */                 kind = 74;
/* 1581 */               jjCheckNAdd(13);
/*      */             }
/*      */             break;
/*      */           }
/* 1585 */         } while (i != startsAt);
/*      */       }
/* 1587 */       if (kind != Integer.MAX_VALUE)
/*      */       {
/* 1589 */         this.jjmatchedKind = kind;
/* 1590 */         this.jjmatchedPos = curPos;
/* 1591 */         kind = Integer.MAX_VALUE;
/*      */       }
/* 1593 */       curPos++;
/* 1594 */       if ((i = this.jjnewStateCnt) == (startsAt = 14 - (this.jjnewStateCnt = startsAt)))
/* 1595 */         return curPos;
/* 1596 */       try { this.curChar = this.input_stream.readChar();
/* 1597 */       } catch (IOException e) { return curPos;
/*      */       } } }
/*      */   
/* 1600 */   static final int[] jjnextStates = { 2, 3, 5, 6 };
/*      */   
/*      */ 
/*      */   private static final boolean jjCanMove_0(int hiByte, int i1, int i2, long l1, long l2)
/*      */   {
/* 1605 */     switch (hiByte)
/*      */     {
/*      */     case 0: 
/* 1608 */       return (jjbitVec2[i2] & l2) != 0L;
/*      */     }
/* 1610 */     if ((jjbitVec0[i1] & l1) != 0L)
/* 1611 */       return true;
/* 1612 */     return false;
/*      */   }
/*      */   
/*      */   private static final boolean jjCanMove_1(int hiByte, int i1, int i2, long l1, long l2)
/*      */   {
/* 1617 */     switch (hiByte)
/*      */     {
/*      */     case 0: 
/* 1620 */       return (jjbitVec4[i2] & l2) != 0L;
/*      */     case 1: 
/* 1622 */       return (jjbitVec5[i2] & l2) != 0L;
/*      */     case 2: 
/* 1624 */       return (jjbitVec6[i2] & l2) != 0L;
/*      */     case 3: 
/* 1626 */       return (jjbitVec7[i2] & l2) != 0L;
/*      */     case 4: 
/* 1628 */       return (jjbitVec8[i2] & l2) != 0L;
/*      */     case 5: 
/* 1630 */       return (jjbitVec9[i2] & l2) != 0L;
/*      */     case 6: 
/* 1632 */       return (jjbitVec10[i2] & l2) != 0L;
/*      */     case 9: 
/* 1634 */       return (jjbitVec11[i2] & l2) != 0L;
/*      */     case 10: 
/* 1636 */       return (jjbitVec12[i2] & l2) != 0L;
/*      */     case 11: 
/* 1638 */       return (jjbitVec13[i2] & l2) != 0L;
/*      */     case 12: 
/* 1640 */       return (jjbitVec14[i2] & l2) != 0L;
/*      */     case 13: 
/* 1642 */       return (jjbitVec15[i2] & l2) != 0L;
/*      */     case 14: 
/* 1644 */       return (jjbitVec16[i2] & l2) != 0L;
/*      */     case 15: 
/* 1646 */       return (jjbitVec17[i2] & l2) != 0L;
/*      */     case 16: 
/* 1648 */       return (jjbitVec18[i2] & l2) != 0L;
/*      */     case 17: 
/* 1650 */       return (jjbitVec19[i2] & l2) != 0L;
/*      */     case 30: 
/* 1652 */       return (jjbitVec20[i2] & l2) != 0L;
/*      */     case 31: 
/* 1654 */       return (jjbitVec21[i2] & l2) != 0L;
/*      */     case 33: 
/* 1656 */       return (jjbitVec22[i2] & l2) != 0L;
/*      */     case 48: 
/* 1658 */       return (jjbitVec23[i2] & l2) != 0L;
/*      */     case 49: 
/* 1660 */       return (jjbitVec24[i2] & l2) != 0L;
/*      */     case 159: 
/* 1662 */       return (jjbitVec25[i2] & l2) != 0L;
/*      */     case 215: 
/* 1664 */       return (jjbitVec26[i2] & l2) != 0L;
/*      */     }
/* 1666 */     if ((jjbitVec3[i1] & l1) != 0L)
/* 1667 */       return true;
/* 1668 */     return false;
/*      */   }
/*      */   
/*      */   private static final boolean jjCanMove_2(int hiByte, int i1, int i2, long l1, long l2)
/*      */   {
/* 1673 */     switch (hiByte)
/*      */     {
/*      */     case 0: 
/* 1676 */       return (jjbitVec27[i2] & l2) != 0L;
/*      */     case 1: 
/* 1678 */       return (jjbitVec5[i2] & l2) != 0L;
/*      */     case 2: 
/* 1680 */       return (jjbitVec28[i2] & l2) != 0L;
/*      */     case 3: 
/* 1682 */       return (jjbitVec29[i2] & l2) != 0L;
/*      */     case 4: 
/* 1684 */       return (jjbitVec30[i2] & l2) != 0L;
/*      */     case 5: 
/* 1686 */       return (jjbitVec31[i2] & l2) != 0L;
/*      */     case 6: 
/* 1688 */       return (jjbitVec32[i2] & l2) != 0L;
/*      */     case 9: 
/* 1690 */       return (jjbitVec33[i2] & l2) != 0L;
/*      */     case 10: 
/* 1692 */       return (jjbitVec34[i2] & l2) != 0L;
/*      */     case 11: 
/* 1694 */       return (jjbitVec35[i2] & l2) != 0L;
/*      */     case 12: 
/* 1696 */       return (jjbitVec36[i2] & l2) != 0L;
/*      */     case 13: 
/* 1698 */       return (jjbitVec37[i2] & l2) != 0L;
/*      */     case 14: 
/* 1700 */       return (jjbitVec38[i2] & l2) != 0L;
/*      */     case 15: 
/* 1702 */       return (jjbitVec39[i2] & l2) != 0L;
/*      */     case 16: 
/* 1704 */       return (jjbitVec18[i2] & l2) != 0L;
/*      */     case 17: 
/* 1706 */       return (jjbitVec19[i2] & l2) != 0L;
/*      */     case 30: 
/* 1708 */       return (jjbitVec20[i2] & l2) != 0L;
/*      */     case 31: 
/* 1710 */       return (jjbitVec21[i2] & l2) != 0L;
/*      */     case 32: 
/* 1712 */       return (jjbitVec40[i2] & l2) != 0L;
/*      */     case 33: 
/* 1714 */       return (jjbitVec22[i2] & l2) != 0L;
/*      */     case 48: 
/* 1716 */       return (jjbitVec41[i2] & l2) != 0L;
/*      */     case 49: 
/* 1718 */       return (jjbitVec24[i2] & l2) != 0L;
/*      */     case 159: 
/* 1720 */       return (jjbitVec25[i2] & l2) != 0L;
/*      */     case 215: 
/* 1722 */       return (jjbitVec26[i2] & l2) != 0L;
/*      */     }
/* 1724 */     if ((jjbitVec3[i1] & l1) != 0L)
/* 1725 */       return true;
/* 1726 */     return false;
/*      */   }
/*      */   
/* 1729 */   public static final String[] jjstrLiteralImages = { "", null, "/", "//", "|", "+", "-", "=", "!=", "<", "<=", ">", ">=", "$", null, null, null, null, null, null, null, null, null, "or", "and", "mod", "div", "node", "text", "comment", "processing-instruction", "self::", "child::", "parent::", "ancestor::", "attribute::", "namespace::", "preceding::", "following::", "descendant::", "ancestor-or-self::", "following-sibling::", "preceding-sibling::", "descendant-or-self::", "last", "position", "count", "id", "key", "local-name", "namespace-uri", "name", "string", "concat", "starts-with", "contains", "substring-before", "substring-after", "substring", "string-length", "normalize-space", "translate", "boolean", "not", "true", "false", "null", "lang", "number", "sum", "floor", "ceiling", "round", "format-number", null, ":", "(", ")", ".", "..", "[", "]", "@", ",", "*" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1751 */   public static final String[] lexStateNames = { "DEFAULT" };
/*      */   
/*      */ 
/* 1754 */   static final long[] jjtoToken = { -8290307L, 2097151L };
/*      */   
/*      */ 
/* 1757 */   static final long[] jjtoSkip = { 2L, 0L };
/*      */   
/*      */ 
/* 1760 */   static final long[] jjtoSpecial = { 2L, 0L };
/*      */   
/*      */   private JavaCharStream input_stream;
/*      */   
/* 1764 */   private final int[] jjrounds = new int[14];
/* 1765 */   private final int[] jjstateSet = new int[28];
/*      */   
/*      */   protected char curChar;
/*      */   
/*      */   public XPathParserTokenManager(JavaCharStream stream)
/*      */   {
/* 1771 */     this.input_stream = stream;
/*      */   }
/*      */   
/*      */   public XPathParserTokenManager(JavaCharStream stream, int lexState) {
/* 1775 */     this(stream);
/* 1776 */     SwitchTo(lexState);
/*      */   }
/*      */   
/*      */   public void ReInit(JavaCharStream stream) {
/* 1780 */     this.jjmatchedPos = (this.jjnewStateCnt = 0);
/* 1781 */     this.curLexState = this.defaultLexState;
/* 1782 */     this.input_stream = stream;
/* 1783 */     ReInitRounds();
/*      */   }
/*      */   
/*      */   private final void ReInitRounds()
/*      */   {
/* 1788 */     this.jjround = -2147483647;
/* 1789 */     for (int i = 14; i-- > 0;)
/* 1790 */       this.jjrounds[i] = Integer.MIN_VALUE;
/*      */   }
/*      */   
/*      */   public void ReInit(JavaCharStream stream, int lexState) {
/* 1794 */     ReInit(stream);
/* 1795 */     SwitchTo(lexState);
/*      */   }
/*      */   
/*      */   public void SwitchTo(int lexState) {
/* 1799 */     if ((lexState >= 1) || (lexState < 0)) {
/* 1800 */       throw new TokenMgrError("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2);
/*      */     }
/* 1802 */     this.curLexState = lexState;
/*      */   }
/*      */   
/*      */   private final Token jjFillToken()
/*      */   {
/* 1807 */     Token t = Token.newToken(this.jjmatchedKind);
/* 1808 */     t.kind = this.jjmatchedKind;
/* 1809 */     String im = jjstrLiteralImages[this.jjmatchedKind];
/* 1810 */     t.image = (im == null ? this.input_stream.GetImage() : im);
/* 1811 */     t.beginLine = this.input_stream.getBeginLine();
/* 1812 */     t.beginColumn = this.input_stream.getBeginColumn();
/* 1813 */     t.endLine = this.input_stream.getEndLine();
/* 1814 */     t.endColumn = this.input_stream.getEndColumn();
/* 1815 */     return t;
/*      */   }
/*      */   
/* 1818 */   int curLexState = 0;
/* 1819 */   int defaultLexState = 0;
/*      */   
/*      */   int jjnewStateCnt;
/*      */   int jjround;
/*      */   int jjmatchedPos;
/*      */   int jjmatchedKind;
/*      */   
/*      */   public final Token getNextToken()
/*      */   {
/* 1828 */     Token specialToken = null;
/*      */     
/* 1830 */     int curPos = 0;
/*      */     
/*      */     for (;;)
/*      */     {
/*      */       Token matchedToken;
/*      */       try
/*      */       {
/* 1837 */         this.curChar = this.input_stream.BeginToken();
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/* 1841 */         this.jjmatchedKind = 0;
/* 1842 */         matchedToken = jjFillToken();
/* 1843 */         matchedToken.specialToken = specialToken;
/* 1844 */         return matchedToken;
/*      */       }
/*      */       
/* 1847 */       this.jjmatchedKind = Integer.MAX_VALUE;
/* 1848 */       this.jjmatchedPos = 0;
/* 1849 */       curPos = jjMoveStringLiteralDfa0_0();
/* 1850 */       if (this.jjmatchedKind == Integer.MAX_VALUE)
/*      */         break;
/* 1852 */       if (this.jjmatchedPos + 1 < curPos)
/* 1853 */         this.input_stream.backup(curPos - this.jjmatchedPos - 1);
/* 1854 */       if ((jjtoToken[(this.jjmatchedKind >> 6)] & 1L << (this.jjmatchedKind & 0x3F)) != 0L)
/*      */       {
/* 1856 */         matchedToken = jjFillToken();
/* 1857 */         matchedToken.specialToken = specialToken;
/* 1858 */         return matchedToken;
/*      */       }
/*      */       
/*      */ 
/* 1862 */       if ((jjtoSpecial[(this.jjmatchedKind >> 6)] & 1L << (this.jjmatchedKind & 0x3F)) != 0L)
/*      */       {
/* 1864 */         matchedToken = jjFillToken();
/* 1865 */         if (specialToken == null) {
/* 1866 */           specialToken = matchedToken;
/*      */         }
/*      */         else {
/* 1869 */           matchedToken.specialToken = specialToken;
/* 1870 */           specialToken = specialToken.next = matchedToken;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1876 */     int error_line = this.input_stream.getEndLine();
/* 1877 */     int error_column = this.input_stream.getEndColumn();
/* 1878 */     String error_after = null;
/* 1879 */     boolean EOFSeen = false;
/* 1880 */     try { this.input_stream.readChar();this.input_stream.backup(1);
/*      */     } catch (IOException e1) {
/* 1882 */       EOFSeen = true;
/* 1883 */       error_after = curPos <= 1 ? "" : this.input_stream.GetImage();
/* 1884 */       if ((this.curChar == '\n') || (this.curChar == '\r')) {
/* 1885 */         error_line++;
/* 1886 */         error_column = 0;
/*      */       }
/*      */       else {
/* 1889 */         error_column++;
/*      */       } }
/* 1891 */     if (!EOFSeen) {
/* 1892 */       this.input_stream.backup(1);
/* 1893 */       error_after = curPos <= 1 ? "" : this.input_stream.GetImage();
/*      */     }
/* 1895 */     throw new TokenMgrError(EOFSeen, this.curLexState, error_line, error_column, error_after, this.curChar, 0);
/*      */   }
/*      */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/parser/XPathParserTokenManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */