/*     */ package org.apache.commons.jxpath.ri;
/*     */ 
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QName
/*     */ {
/*     */   private String prefix;
/*     */   private String name;
/*     */   
/*     */   public QName(String qualifiedName)
/*     */   {
/*  78 */     int index = qualifiedName.indexOf(':');
/*  79 */     if (index == -1) {
/*  80 */       this.prefix = null;
/*  81 */       this.name = qualifiedName;
/*     */     }
/*     */     else {
/*  84 */       this.prefix = qualifiedName.substring(0, index);
/*  85 */       this.name = qualifiedName.substring(index + 1);
/*     */     }
/*     */   }
/*     */   
/*     */   public QName(String prefix, String localName) {
/*  90 */     if (localName.indexOf(':') != -1) {
/*  91 */       throw new JXPathException("The 'localName' part of a QName cannot contain colons");
/*     */     }
/*     */     
/*  94 */     this.prefix = prefix;
/*  95 */     this.name = localName;
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/*  99 */     return this.prefix;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 103 */     return this.name;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 107 */     if (this.prefix != null) {
/* 108 */       return this.prefix + ':' + this.name;
/*     */     }
/* 110 */     return this.name;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 114 */     return this.name.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 118 */     if (!(object instanceof QName)) {
/* 119 */       return false;
/*     */     }
/* 121 */     if (this == object) {
/* 122 */       return true;
/*     */     }
/* 124 */     QName that = (QName)object;
/* 125 */     if (!this.name.equals(that.name)) {
/* 126 */       return false;
/*     */     }
/*     */     
/* 129 */     if (((this.prefix == null) && (that.prefix != null)) || ((this.prefix != null) && (!this.prefix.equals(that.prefix))))
/*     */     {
/* 131 */       return false;
/*     */     }
/*     */     
/* 134 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/QName.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */