/*     */ package org.apache.commons.jxpath.ri.model;
/*     */ 
/*     */ import org.apache.commons.jxpath.AbstractFactory;
/*     */ import org.apache.commons.jxpath.JXPathBeanInfo;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.JXPathIntrospector;
/*     */ import org.apache.commons.jxpath.Variables;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.compiler.NodeTest;
/*     */ import org.apache.commons.jxpath.ri.model.beans.NullPointer;
/*     */ import org.apache.commons.jxpath.util.ValueUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariablePointer
/*     */   extends NodePointer
/*     */ {
/*     */   private Variables variables;
/*     */   private QName name;
/*     */   private NodePointer valuePointer;
/*     */   private boolean actual;
/*     */   
/*     */   public VariablePointer(Variables variables, QName name)
/*     */   {
/*  87 */     super(null);
/*  88 */     this.variables = variables;
/*  89 */     this.name = name;
/*  90 */     this.actual = true;
/*     */   }
/*     */   
/*     */   public VariablePointer(QName name) {
/*  94 */     super(null);
/*  95 */     this.name = name;
/*  96 */     this.actual = false;
/*     */   }
/*     */   
/*     */   public boolean isContainer() {
/* 100 */     return true;
/*     */   }
/*     */   
/*     */   public QName getName() {
/* 104 */     return this.name;
/*     */   }
/*     */   
/*     */   public Object getBaseValue() {
/* 108 */     if (!this.actual) {
/* 109 */       throw new JXPathException("Undefined variable: " + this.name);
/*     */     }
/* 111 */     return this.variables.getVariable(this.name.toString());
/*     */   }
/*     */   
/*     */   public boolean isLeaf() {
/* 115 */     Object value = getNode();
/* 116 */     return (value == null) || (JXPathIntrospector.getBeanInfo(value.getClass()).isAtomic());
/*     */   }
/*     */   
/*     */   public boolean isCollection()
/*     */   {
/* 121 */     Object value = getBaseValue();
/* 122 */     return (value != null) && (ValueUtils.isCollection(value));
/*     */   }
/*     */   
/*     */   public Object getImmediateNode() {
/* 126 */     Object value = getBaseValue();
/* 127 */     if (this.index != Integer.MIN_VALUE) {
/* 128 */       return ValueUtils.getValue(value, this.index);
/*     */     }
/* 130 */     return value;
/*     */   }
/*     */   
/*     */   public void setValue(Object value) {
/* 134 */     if (!this.actual) {
/* 135 */       throw new JXPathException("Cannot set undefined variable: " + this.name);
/*     */     }
/* 137 */     this.valuePointer = null;
/* 138 */     if (this.index != Integer.MIN_VALUE) {
/* 139 */       Object collection = getBaseValue();
/* 140 */       ValueUtils.setValue(collection, this.index, value);
/*     */     }
/*     */     else {
/* 143 */       this.variables.declareVariable(this.name.toString(), value);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isActual() {
/* 148 */     return this.actual;
/*     */   }
/*     */   
/*     */   public void setIndex(int index) {
/* 152 */     super.setIndex(index);
/* 153 */     this.valuePointer = null;
/*     */   }
/*     */   
/*     */   public NodePointer getImmediateValuePointer() {
/* 157 */     if (this.valuePointer == null) {
/* 158 */       Object value = null;
/* 159 */       if (this.actual) {
/* 160 */         value = getImmediateNode();
/* 161 */         this.valuePointer = NodePointer.newChildNodePointer(this, null, value);
/*     */       }
/*     */       else
/*     */       {
/* 165 */         new NullPointer(this, getName()) {
/*     */           public Object getImmediateNode() {
/* 167 */             throw new JXPathException("Undefined variable: " + VariablePointer.this.name);
/*     */           }
/*     */         };
/*     */       }
/*     */     }
/*     */     
/* 173 */     return this.valuePointer;
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 177 */     if (this.actual) {
/* 178 */       Object value = getBaseValue();
/* 179 */       if (value == null) {
/* 180 */         return 1;
/*     */       }
/* 182 */       return ValueUtils.getLength(value);
/*     */     }
/* 184 */     return 0;
/*     */   }
/*     */   
/*     */   public NodePointer createPath(JXPathContext context, Object value) {
/* 188 */     if (this.actual) {
/* 189 */       setValue(value);
/* 190 */       return this;
/*     */     }
/* 192 */     NodePointer ptr = createPath(context);
/* 193 */     ptr.setValue(value);
/* 194 */     return ptr;
/*     */   }
/*     */   
/*     */   public NodePointer createPath(JXPathContext context) {
/* 198 */     if (!this.actual) {
/* 199 */       AbstractFactory factory = getAbstractFactory(context);
/* 200 */       if (!factory.declareVariable(context, this.name.toString())) {
/* 201 */         throw new JXPathException("Factory cannot define variable '" + this.name + "' for path: " + asPath());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 207 */       findVariables(context);
/*     */     }
/*     */     
/* 210 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index)
/*     */   {
/* 218 */     Object collection = createCollection(context, index);
/* 219 */     if ((!isActual()) || ((index != 0) && (index != Integer.MIN_VALUE))) {
/* 220 */       AbstractFactory factory = getAbstractFactory(context);
/* 221 */       boolean success = factory.createObject(context, this, collection, getName().toString(), index);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 228 */       if (!success) {
/* 229 */         throw new JXPathException("Factory could not create object path: " + asPath());
/*     */       }
/*     */       
/* 232 */       setIndex(index);
/*     */     }
/* 234 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createChild(JXPathContext context, QName name, int index, Object value)
/*     */   {
/* 243 */     Object collection = createCollection(context, index);
/* 244 */     ValueUtils.setValue(collection, index, value);
/* 245 */     NodePointer cl = (NodePointer)clone();
/* 246 */     cl.setIndex(index);
/* 247 */     return cl;
/*     */   }
/*     */   
/*     */   private Object createCollection(JXPathContext context, int index) {
/* 251 */     createPath(context);
/*     */     
/* 253 */     Object collection = getBaseValue();
/* 254 */     if (collection == null) {
/* 255 */       throw new JXPathException("Factory did not assign a collection to variable '" + this.name + "' for path: " + asPath());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 262 */     if (index == Integer.MIN_VALUE) {
/* 263 */       index = 0;
/*     */     }
/* 265 */     else if (index < 0) {
/* 266 */       throw new JXPathException("Index is less than 1: " + asPath());
/*     */     }
/*     */     
/* 269 */     if (index >= getLength()) {
/* 270 */       collection = ValueUtils.expandCollection(collection, index + 1);
/* 271 */       this.variables.declareVariable(this.name.toString(), collection);
/*     */     }
/*     */     
/* 274 */     return collection;
/*     */   }
/*     */   
/*     */   public void remove() {
/* 278 */     if (this.actual) {
/* 279 */       if (this.index == Integer.MIN_VALUE) {
/* 280 */         this.variables.undeclareVariable(this.name.toString());
/*     */       }
/*     */       else {
/* 283 */         if (this.index < 0) {
/* 284 */           throw new JXPathException("Index is less than 1: " + asPath());
/*     */         }
/*     */         
/*     */ 
/* 288 */         Object collection = getBaseValue();
/* 289 */         if ((collection != null) && (this.index < getLength())) {
/* 290 */           collection = ValueUtils.remove(collection, this.index);
/* 291 */           this.variables.declareVariable(this.name.toString(), collection);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void findVariables(JXPathContext context) {
/* 298 */     this.valuePointer = null;
/* 299 */     JXPathContext varCtx = context;
/* 300 */     while (varCtx != null) {
/* 301 */       this.variables = varCtx.getVariables();
/* 302 */       if (this.variables.isDeclaredVariable(this.name.toString())) {
/* 303 */         this.actual = true;
/* 304 */         break;
/*     */       }
/* 306 */       varCtx = varCtx.getParentContext();
/* 307 */       this.variables = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 312 */     return (this.actual ? System.identityHashCode(this.variables) : 0) + this.name.hashCode() + this.index;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 318 */     if (object == this) {
/* 319 */       return true;
/*     */     }
/*     */     
/* 322 */     if (!(object instanceof VariablePointer)) {
/* 323 */       return false;
/*     */     }
/*     */     
/* 326 */     VariablePointer other = (VariablePointer)object;
/* 327 */     return (this.variables == other.variables) && (this.name.equals(other.name)) && (this.index == other.index);
/*     */   }
/*     */   
/*     */ 
/*     */   public String asPath()
/*     */   {
/* 333 */     StringBuffer buffer = new StringBuffer();
/* 334 */     buffer.append('$');
/* 335 */     buffer.append(this.name);
/* 336 */     if (!this.actual) {
/* 337 */       if (this.index != Integer.MIN_VALUE) {
/* 338 */         buffer.append('[').append(this.index + 1).append(']');
/*     */       }
/*     */     }
/* 341 */     else if ((this.index != Integer.MIN_VALUE) && ((getNode() == null) || (isCollection())))
/*     */     {
/*     */ 
/* 344 */       buffer.append('[').append(this.index + 1).append(']');
/*     */     }
/* 346 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodeIterator childIterator(NodeTest test, boolean reverse, NodePointer startWith)
/*     */   {
/* 354 */     return getValuePointer().childIterator(test, reverse, startWith);
/*     */   }
/*     */   
/*     */   public NodeIterator attributeIterator(QName name) {
/* 358 */     return getValuePointer().attributeIterator(name);
/*     */   }
/*     */   
/*     */   public NodeIterator namespaceIterator() {
/* 362 */     return getValuePointer().namespaceIterator();
/*     */   }
/*     */   
/*     */   public NodePointer namespacePointer(String name) {
/* 366 */     return getValuePointer().namespacePointer(name);
/*     */   }
/*     */   
/*     */   public boolean testNode(NodeTest nodeTest) {
/* 370 */     return getValuePointer().testNode(nodeTest);
/*     */   }
/*     */   
/*     */   private AbstractFactory getAbstractFactory(JXPathContext context) {
/* 374 */     AbstractFactory factory = context.getFactory();
/* 375 */     if (factory == null) {
/* 376 */       throw new JXPathException("Factory is not set on the JXPathContext - cannot create path: " + asPath());
/*     */     }
/*     */     
/*     */ 
/* 380 */     return factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int compareChildNodePointers(NodePointer pointer1, NodePointer pointer2)
/*     */   {
/* 387 */     return pointer1.getIndex() - pointer2.getIndex();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/VariablePointer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */