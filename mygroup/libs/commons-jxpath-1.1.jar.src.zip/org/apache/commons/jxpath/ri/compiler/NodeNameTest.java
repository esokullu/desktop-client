/*    */ package org.apache.commons.jxpath.ri.compiler;
/*    */ 
/*    */ import org.apache.commons.jxpath.ri.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NodeNameTest
/*    */   extends NodeTest
/*    */ {
/*    */   private QName qname;
/*    */   
/*    */   public NodeNameTest(QName qname)
/*    */   {
/* 74 */     this.qname = qname;
/*    */   }
/*    */   
/*    */   public QName getNodeName() {
/* 78 */     return this.qname;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 82 */     return this.qname.toString();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/NodeNameTest.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */