/*     */ package org.apache.commons.jxpath.ri.compiler;
/*     */ 
/*     */ import org.apache.commons.jxpath.ri.EvalContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CoreOperation
/*     */   extends Operation
/*     */ {
/*     */   public CoreOperation(Expression[] args)
/*     */   {
/*  76 */     super(args);
/*     */   }
/*     */   
/*     */   public Object compute(EvalContext context) {
/*  80 */     return computeValue(context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract Object computeValue(EvalContext paramEvalContext);
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getSymbol();
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract boolean isSymmetric();
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract int getPrecedence();
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 102 */     if (this.args.length == 1) {
/* 103 */       return getSymbol() + parenthesize(this.args[0], false);
/*     */     }
/*     */     
/* 106 */     StringBuffer buffer = new StringBuffer();
/* 107 */     for (int i = 0; i < this.args.length; i++) {
/* 108 */       if (i > 0) {
/* 109 */         buffer.append(' ');
/* 110 */         buffer.append(getSymbol());
/* 111 */         buffer.append(' ');
/*     */       }
/* 113 */       buffer.append(parenthesize(this.args[i], i == 0));
/*     */     }
/* 115 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private String parenthesize(Expression expression, boolean left)
/*     */   {
/* 120 */     if (!(expression instanceof CoreOperation)) {
/* 121 */       return expression.toString();
/*     */     }
/* 123 */     CoreOperation op = (CoreOperation)expression;
/* 124 */     int myPrecedence = getPrecedence();
/* 125 */     int thePrecedence = op.getPrecedence();
/*     */     
/* 127 */     boolean needParens = true;
/* 128 */     if (myPrecedence < thePrecedence) {
/* 129 */       needParens = false;
/*     */     }
/* 131 */     else if (myPrecedence == thePrecedence) {
/* 132 */       if (isSymmetric()) {
/* 133 */         needParens = false;
/*     */       }
/*     */       else {
/* 136 */         needParens = !left;
/*     */       }
/*     */     }
/*     */     
/* 140 */     if (needParens) {
/* 141 */       return "(" + expression.toString() + ")";
/*     */     }
/*     */     
/* 144 */     return expression.toString();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/compiler/CoreOperation.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */