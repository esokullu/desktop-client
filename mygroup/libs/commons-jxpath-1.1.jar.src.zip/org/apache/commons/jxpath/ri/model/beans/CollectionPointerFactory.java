/*     */ package org.apache.commons.jxpath.ri.model.beans;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.jxpath.ri.QName;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointer;
/*     */ import org.apache.commons.jxpath.ri.model.NodePointerFactory;
/*     */ import org.apache.commons.jxpath.util.ValueUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollectionPointerFactory
/*     */   implements NodePointerFactory
/*     */ {
/*     */   public static final int COLLECTION_POINTER_FACTORY_ORDER = 10;
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  82 */     return 10;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createNodePointer(QName name, Object bean, Locale locale)
/*     */   {
/*  90 */     if (ValueUtils.isCollection(bean)) {
/*  91 */       return new CollectionPointer(bean, locale);
/*     */     }
/*  93 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NodePointer createNodePointer(NodePointer parent, QName name, Object bean)
/*     */   {
/* 101 */     if (ValueUtils.isCollection(bean)) {
/* 102 */       return new CollectionPointer(parent, bean);
/*     */     }
/* 104 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/ri/model/beans/CollectionPointerFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */