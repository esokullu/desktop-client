package org.apache.commons.jxpath;

public abstract interface Variables
{
  public abstract boolean isDeclaredVariable(String paramString);
  
  public abstract Object getVariable(String paramString);
  
  public abstract void declareVariable(String paramString, Object paramObject);
  
  public abstract void undeclareVariable(String paramString);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/Variables.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */