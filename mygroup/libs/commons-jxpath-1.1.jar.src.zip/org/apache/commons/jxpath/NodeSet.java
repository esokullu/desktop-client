package org.apache.commons.jxpath;

import java.util.List;

public abstract interface NodeSet
{
  public abstract List getNodes();
  
  public abstract List getPointers();
  
  public abstract List getValues();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/NodeSet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */