package org.apache.commons.jxpath;

import java.beans.PropertyDescriptor;

public abstract interface JXPathBeanInfo
{
  public abstract boolean isAtomic();
  
  public abstract boolean isDynamic();
  
  public abstract PropertyDescriptor[] getPropertyDescriptors();
  
  public abstract PropertyDescriptor getPropertyDescriptor(String paramString);
  
  public abstract Class getDynamicPropertyHandlerClass();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/JXPathBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */