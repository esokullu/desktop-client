/*     */ package org.apache.commons.jxpath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JXPathException
/*     */   extends RuntimeException
/*     */ {
/*     */   private Throwable exception;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JXPathException()
/*     */   {
/*  83 */     this.exception = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JXPathException(String msg)
/*     */   {
/*  93 */     super(msg);
/*  94 */     this.exception = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JXPathException(Throwable e)
/*     */   {
/* 106 */     super(e.toString());
/* 107 */     this.exception = e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JXPathException(String msg, Throwable e)
/*     */   {
/* 119 */     super(msg);
/* 120 */     this.exception = e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 132 */     String message = super.getMessage();
/*     */     
/* 134 */     if (this.exception != null) {
/* 135 */       if (message == null) {
/* 136 */         if (this.exception.getMessage() != null) {
/* 137 */           return this.exception.getMessage();
/*     */         }
/*     */         
/* 140 */         return this.exception.getClass().getName();
/*     */       }
/*     */       
/*     */ 
/* 144 */       if (this.exception.getMessage() != null) {
/* 145 */         return message + "; " + this.exception.getMessage();
/*     */       }
/*     */       
/* 148 */       return message + "; " + this.exception.getClass().getName();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 153 */     return message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getException()
/*     */   {
/* 163 */     return this.exception;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/JXPathException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */