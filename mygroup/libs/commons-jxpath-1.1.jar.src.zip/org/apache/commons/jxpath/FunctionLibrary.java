/*     */ package org.apache.commons.jxpath;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionLibrary
/*     */   implements Functions
/*     */ {
/*  80 */   private List allFunctions = new ArrayList();
/*  81 */   private HashMap byNamespace = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public void addFunctions(Functions functions)
/*     */   {
/*  87 */     this.allFunctions.add(functions);
/*  88 */     this.byNamespace = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void removeFunctions(Functions functions)
/*     */   {
/*  95 */     this.allFunctions.remove(functions);
/*  96 */     this.byNamespace = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set getUsedNamespaces()
/*     */   {
/* 104 */     if (this.byNamespace == null) {
/* 105 */       prepareCache();
/*     */     }
/* 107 */     return this.byNamespace.keySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Function getFunction(String namespace, String name, Object[] parameters)
/*     */   {
/* 119 */     if (this.byNamespace == null) {
/* 120 */       prepareCache();
/*     */     }
/* 122 */     Object candidates = this.byNamespace.get(namespace);
/* 123 */     if ((candidates instanceof Functions)) {
/* 124 */       return ((Functions)candidates).getFunction(namespace, name, parameters);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 129 */     if ((candidates instanceof List)) {
/* 130 */       List list = (List)candidates;
/* 131 */       int count = list.size();
/* 132 */       for (int i = 0; i < count; i++) {
/* 133 */         Function function = ((Functions)list.get(i)).getFunction(namespace, name, parameters);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 138 */         if (function != null) {
/* 139 */           return function;
/*     */         }
/*     */       }
/*     */     }
/* 143 */     return null;
/*     */   }
/*     */   
/*     */   private void prepareCache() {
/* 147 */     this.byNamespace = new HashMap();
/* 148 */     int count = this.allFunctions.size();
/* 149 */     for (int i = 0; i < count; i++) {
/* 150 */       Functions funcs = (Functions)this.allFunctions.get(i);
/* 151 */       Set namespaces = funcs.getUsedNamespaces();
/* 152 */       for (Iterator it = namespaces.iterator(); it.hasNext();) {
/* 153 */         String ns = (String)it.next();
/* 154 */         Object candidates = this.byNamespace.get(ns);
/* 155 */         if (candidates == null) {
/* 156 */           this.byNamespace.put(ns, funcs);
/*     */         }
/* 158 */         else if ((candidates instanceof Functions)) {
/* 159 */           List lst = new ArrayList();
/* 160 */           lst.add(candidates);
/* 161 */           lst.add(funcs);
/* 162 */           this.byNamespace.put(ns, lst);
/*     */         }
/*     */         else {
/* 165 */           ((List)candidates).add(funcs);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/FunctionLibrary.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */