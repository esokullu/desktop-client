/*    */ package org.apache.commons.jxpath.servlet;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import org.apache.commons.jxpath.DynamicPropertyHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpSessionHandler
/*    */   implements DynamicPropertyHandler
/*    */ {
/*    */   public String[] getPropertyNames(Object session)
/*    */   {
/* 73 */     Enumeration e = ((HttpSession)session).getAttributeNames();
/* 74 */     return Util.toStrings(e);
/*    */   }
/*    */   
/*    */   public Object getProperty(Object session, String property) {
/* 78 */     return ((HttpSession)session).getAttribute(property);
/*    */   }
/*    */   
/*    */   public void setProperty(Object session, String property, Object value) {
/* 82 */     ((HttpSession)session).setAttribute(property, value);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/servlet/HttpSessionHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */