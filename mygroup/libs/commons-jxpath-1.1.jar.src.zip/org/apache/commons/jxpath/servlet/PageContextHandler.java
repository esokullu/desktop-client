/*     */ package org.apache.commons.jxpath.servlet;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.apache.commons.jxpath.DynamicPropertyHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PageContextHandler
/*     */   implements DynamicPropertyHandler
/*     */ {
/*     */   public String[] getPropertyNames(Object pageContext)
/*     */   {
/*  74 */     ArrayList list = new ArrayList();
/*  75 */     Enumeration e = ((PageContext)pageContext).getAttributeNamesInScope(1);
/*     */     
/*     */ 
/*  78 */     while (e.hasMoreElements()) {
/*  79 */       list.add(e.nextElement());
/*     */     }
/*  81 */     e = ((PageContext)pageContext).getAttributeNamesInScope(2);
/*     */     
/*     */ 
/*  84 */     while (e.hasMoreElements()) {
/*  85 */       list.add(e.nextElement());
/*     */     }
/*  87 */     e = ((PageContext)pageContext).getAttributeNamesInScope(3);
/*     */     
/*     */ 
/*  90 */     while (e.hasMoreElements()) {
/*  91 */       list.add(e.nextElement());
/*     */     }
/*  93 */     e = ((PageContext)pageContext).getAttributeNamesInScope(4);
/*     */     
/*     */ 
/*  96 */     while (e.hasMoreElements()) {
/*  97 */       list.add(e.nextElement());
/*     */     }
/*  99 */     return (String[])list.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getProperty(Object pageContext, String property)
/*     */   {
/* 106 */     return ((PageContext)pageContext).findAttribute(property);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProperty(Object pageContext, String property, Object value)
/*     */   {
/* 114 */     ((PageContext)pageContext).setAttribute(property, value, 1);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/servlet/PageContextHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */