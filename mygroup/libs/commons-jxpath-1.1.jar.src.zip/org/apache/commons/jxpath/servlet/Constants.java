package org.apache.commons.jxpath.servlet;

public final class Constants
{
  public static final String APPLICATION_SCOPE = "application";
  public static final String SESSION_SCOPE = "session";
  public static final String REQUEST_SCOPE = "request";
  public static final String PAGE_SCOPE = "page";
  public static final String JXPATH_CONTEXT = "org.apache.commons.jxpath.JXPATH_CONTEXT";
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/servlet/Constants.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */