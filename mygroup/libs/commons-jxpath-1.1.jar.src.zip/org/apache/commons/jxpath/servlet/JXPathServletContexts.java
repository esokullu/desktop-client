/*     */ package org.apache.commons.jxpath.servlet;
/*     */ 
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.apache.commons.jxpath.JXPathContext;
/*     */ import org.apache.commons.jxpath.JXPathContextFactory;
/*     */ import org.apache.commons.jxpath.JXPathIntrospector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JXPathServletContexts
/*     */ {
/*     */   static
/*     */   {
/* 111 */     JXPathIntrospector.registerDynamicClass(PageScopeContext.class, PageScopeContextHandler.class);
/*     */   }
/*     */   
/* 114 */   private static JXPathContextFactory factory = JXPathContextFactory.newInstance();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JXPathContext getPageContext(PageContext pageContext)
/*     */   {
/* 122 */     JXPathContext context = (JXPathContext)pageContext.getAttribute("org.apache.commons.jxpath.JXPATH_CONTEXT");
/*     */     
/* 124 */     if (context == null) {
/* 125 */       JXPathIntrospector.registerDynamicClass(pageContext.getClass(), PageContextHandler.class);
/*     */       
/*     */ 
/* 128 */       JXPathContext parentContext = getRequestContext(pageContext.getRequest(), pageContext.getServletContext());
/*     */       
/*     */ 
/*     */ 
/* 132 */       context = factory.newContext(parentContext, pageContext);
/* 133 */       context.setVariables(new KeywordVariables("page", new PageScopeContext(pageContext)));
/*     */       
/*     */ 
/*     */ 
/* 137 */       pageContext.setAttribute("org.apache.commons.jxpath.JXPATH_CONTEXT", context);
/*     */     }
/* 139 */     return context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JXPathContext getRequestContext(ServletRequest request, ServletContext servletContext)
/*     */   {
/* 150 */     JXPathContext context = (JXPathContext)request.getAttribute("org.apache.commons.jxpath.JXPATH_CONTEXT");
/*     */     
/* 152 */     if (context == null) {
/* 153 */       JXPathContext parentContext = null;
/* 154 */       if ((request instanceof HttpServletRequest)) {
/* 155 */         HttpSession session = ((HttpServletRequest)request).getSession(false);
/*     */         
/* 157 */         if (session != null) {
/* 158 */           parentContext = getSessionContext(session, servletContext);
/*     */         }
/*     */         else {
/* 161 */           parentContext = getApplicationContext(servletContext);
/*     */         }
/*     */       }
/* 164 */       JXPathIntrospector.registerDynamicClass(request.getClass(), ServletRequestHandler.class);
/*     */       
/*     */ 
/* 167 */       context = factory.newContext(parentContext, request);
/* 168 */       context.setVariables(new KeywordVariables("request", request));
/*     */       
/* 170 */       request.setAttribute("org.apache.commons.jxpath.JXPATH_CONTEXT", context);
/*     */     }
/* 172 */     return context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JXPathContext getSessionContext(HttpSession session, ServletContext servletContext)
/*     */   {
/* 183 */     JXPathContext context = (JXPathContext)session.getAttribute("org.apache.commons.jxpath.JXPATH_CONTEXT");
/*     */     
/* 185 */     if (context == null) {
/* 186 */       JXPathIntrospector.registerDynamicClass(session.getClass(), HttpSessionHandler.class);
/*     */       
/*     */ 
/* 189 */       JXPathContext parentContext = getApplicationContext(servletContext);
/* 190 */       context = factory.newContext(parentContext, session);
/* 191 */       context.setVariables(new KeywordVariables("session", session));
/*     */       
/* 193 */       session.setAttribute("org.apache.commons.jxpath.JXPATH_CONTEXT", context);
/*     */     }
/* 195 */     return context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JXPathContext getApplicationContext(ServletContext servletContext)
/*     */   {
/* 205 */     JXPathContext context = (JXPathContext)servletContext.getAttribute("org.apache.commons.jxpath.JXPATH_CONTEXT");
/*     */     
/*     */ 
/* 208 */     if (context == null) {
/* 209 */       JXPathIntrospector.registerDynamicClass(servletContext.getClass(), ServletContextHandler.class);
/*     */       
/*     */ 
/* 212 */       context = factory.newContext(null, servletContext);
/* 213 */       context.setVariables(new KeywordVariables("application", servletContext));
/*     */       
/*     */ 
/*     */ 
/* 217 */       servletContext.setAttribute("org.apache.commons.jxpath.JXPATH_CONTEXT", context);
/*     */     }
/* 219 */     return context;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/servlet/JXPathServletContexts.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */