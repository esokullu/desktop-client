/*    */ package org.apache.commons.jxpath.servlet;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.apache.commons.jxpath.DynamicPropertyHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletContextHandler
/*    */   implements DynamicPropertyHandler
/*    */ {
/*    */   public String[] getPropertyNames(Object context)
/*    */   {
/* 73 */     Enumeration e = ((ServletContext)context).getAttributeNames();
/* 74 */     return Util.toStrings(e);
/*    */   }
/*    */   
/*    */   public Object getProperty(Object context, String property) {
/* 78 */     return ((ServletContext)context).getAttribute(property);
/*    */   }
/*    */   
/*    */   public void setProperty(Object context, String property, Object value) {
/* 82 */     ((ServletContext)context).setAttribute(property, value);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/servlet/ServletContextHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */