/*    */ package org.apache.commons.jxpath.servlet;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.jsp.PageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PageScopeContext
/*    */ {
/*    */   private PageContext pageContext;
/*    */   
/*    */   public PageScopeContext(PageContext pageContext)
/*    */   {
/* 75 */     this.pageContext = pageContext;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Enumeration getAttributeNames()
/*    */   {
/* 82 */     return this.pageContext.getAttributeNamesInScope(1);
/*    */   }
/*    */   
/*    */   public Object getAttribute(String attribute) {
/* 86 */     return this.pageContext.getAttribute(attribute, 1);
/*    */   }
/*    */   
/*    */   public void setAttribute(String attribute, Object value) {
/* 90 */     this.pageContext.setAttribute(attribute, value, 1);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/servlet/PageScopeContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */