/*    */ package org.apache.commons.jxpath.servlet;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import org.apache.commons.jxpath.DynamicPropertyHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PageScopeContextHandler
/*    */   implements DynamicPropertyHandler
/*    */ {
/*    */   public String[] getPropertyNames(Object pageScope)
/*    */   {
/* 72 */     Enumeration e = ((PageScopeContext)pageScope).getAttributeNames();
/* 73 */     return Util.toStrings(e);
/*    */   }
/*    */   
/*    */   public Object getProperty(Object pageScope, String property) {
/* 77 */     return ((PageScopeContext)pageScope).getAttribute(property);
/*    */   }
/*    */   
/*    */   public void setProperty(Object pageScope, String property, Object value) {
/* 81 */     ((PageScopeContext)pageScope).setAttribute(property, value);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/servlet/PageScopeContextHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */