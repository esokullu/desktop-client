/*    */ package org.apache.commons.jxpath.servlet;
/*    */ 
/*    */ import org.apache.commons.jxpath.Variables;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeywordVariables
/*    */   implements Variables
/*    */ {
/*    */   private String keyword;
/*    */   private Object object;
/*    */   
/*    */   public KeywordVariables(String keyword, Object object)
/*    */   {
/* 73 */     this.keyword = keyword;
/* 74 */     this.object = object;
/*    */   }
/*    */   
/*    */   public boolean isDeclaredVariable(String variable) {
/* 78 */     return variable.equals(this.keyword);
/*    */   }
/*    */   
/*    */   public Object getVariable(String variable) {
/* 82 */     if (variable.equals(this.keyword)) {
/* 83 */       return this.object;
/*    */     }
/* 85 */     return null;
/*    */   }
/*    */   
/*    */   public void declareVariable(String variable, Object value) {
/* 89 */     throw new UnsupportedOperationException("Cannot declare new keyword variables.");
/*    */   }
/*    */   
/*    */   public void undeclareVariable(String variable)
/*    */   {
/* 94 */     throw new UnsupportedOperationException("Cannot declare new keyword variables.");
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/servlet/KeywordVariables.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */