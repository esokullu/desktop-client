/*    */ package org.apache.commons.jxpath.servlet;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.ServletRequest;
/*    */ import org.apache.commons.jxpath.DynamicPropertyHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletRequestHandler
/*    */   implements DynamicPropertyHandler
/*    */ {
/*    */   public String[] getPropertyNames(Object request)
/*    */   {
/* 73 */     Enumeration e = ((ServletRequest)request).getAttributeNames();
/* 74 */     return Util.toStrings(e);
/*    */   }
/*    */   
/*    */   public Object getProperty(Object request, String property) {
/* 78 */     return ((ServletRequest)request).getAttribute(property);
/*    */   }
/*    */   
/*    */   public void setProperty(Object request, String property, Object value) {
/* 82 */     ((ServletRequest)request).setAttribute(property, value);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/servlet/ServletRequestHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */