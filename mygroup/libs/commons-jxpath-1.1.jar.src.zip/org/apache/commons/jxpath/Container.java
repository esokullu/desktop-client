package org.apache.commons.jxpath;

public abstract interface Container
{
  public abstract Object getValue();
  
  public abstract void setValue(Object paramObject);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/Container.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */