/*     */ package org.apache.commons.jxpath;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JXPathBasicBeanInfo
/*     */   implements JXPathBeanInfo
/*     */ {
/*  82 */   private boolean atomic = false;
/*     */   private Class clazz;
/*     */   private PropertyDescriptor[] propertyDescriptors;
/*     */   private String[] propertyNames;
/*     */   private Class dynamicPropertyHandlerClass;
/*     */   
/*     */   public JXPathBasicBeanInfo(Class clazz) {
/*  89 */     this.clazz = clazz;
/*     */   }
/*     */   
/*     */   public JXPathBasicBeanInfo(Class clazz, boolean atomic) {
/*  93 */     this.clazz = clazz;
/*  94 */     this.atomic = atomic;
/*     */   }
/*     */   
/*     */   public JXPathBasicBeanInfo(Class clazz, Class dynamicPropertyHandlerClass) {
/*  98 */     this.clazz = clazz;
/*  99 */     this.atomic = false;
/* 100 */     this.dynamicPropertyHandlerClass = dynamicPropertyHandlerClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAtomic()
/*     */   {
/* 108 */     return this.atomic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isDynamic()
/*     */   {
/* 115 */     return this.dynamicPropertyHandlerClass != null;
/*     */   }
/*     */   
/*     */   public PropertyDescriptor[] getPropertyDescriptors() {
/* 119 */     if (this.propertyDescriptors == null) {
/*     */       try {
/* 121 */         BeanInfo bi = null;
/* 122 */         if (this.clazz.isInterface()) {
/* 123 */           bi = Introspector.getBeanInfo(this.clazz);
/*     */         }
/*     */         else {
/* 126 */           bi = Introspector.getBeanInfo(this.clazz, Object.class);
/*     */         }
/* 128 */         PropertyDescriptor[] pds = bi.getPropertyDescriptors();
/* 129 */         this.propertyDescriptors = new PropertyDescriptor[pds.length];
/* 130 */         System.arraycopy(pds, 0, this.propertyDescriptors, 0, pds.length);
/* 131 */         Arrays.sort(this.propertyDescriptors, new Comparator() {
/*     */           public int compare(Object left, Object right) {
/* 133 */             return ((PropertyDescriptor)left).getName().compareTo(((PropertyDescriptor)right).getName());
/*     */           }
/*     */         });
/*     */       }
/*     */       catch (IntrospectionException ex)
/*     */       {
/* 139 */         ex.printStackTrace();
/*     */       }
/*     */     }
/* 142 */     return this.propertyDescriptors;
/*     */   }
/*     */   
/*     */   public PropertyDescriptor getPropertyDescriptor(String propertyName) {
/* 146 */     if (this.propertyNames == null) {
/* 147 */       PropertyDescriptor[] pds = getPropertyDescriptors();
/* 148 */       this.propertyNames = new String[pds.length];
/* 149 */       for (int i = 0; i < pds.length; i++) {
/* 150 */         this.propertyNames[i] = pds[i].getName();
/*     */       }
/*     */     }
/*     */     
/* 154 */     for (int i = 0; i < this.propertyNames.length; i++) {
/* 155 */       if (this.propertyNames[i] == propertyName) {
/* 156 */         return this.propertyDescriptors[i];
/*     */       }
/*     */     }
/*     */     
/* 160 */     for (int i = 0; i < this.propertyNames.length; i++) {
/* 161 */       if (this.propertyNames[i].equals(propertyName)) {
/* 162 */         return this.propertyDescriptors[i];
/*     */       }
/*     */     }
/* 165 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class getDynamicPropertyHandlerClass()
/*     */   {
/* 173 */     return this.dynamicPropertyHandlerClass;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 177 */     StringBuffer buffer = new StringBuffer();
/* 178 */     buffer.append("BeanInfo [class = ");
/* 179 */     buffer.append(this.clazz.getName());
/* 180 */     buffer.append(", properties = ");
/* 181 */     PropertyDescriptor[] jpds = getPropertyDescriptors();
/* 182 */     for (int i = 0; i < jpds.length; i++) {
/* 183 */       buffer.append("\n    ");
/* 184 */       buffer.append(jpds[i].getPropertyType());
/* 185 */       buffer.append(": ");
/* 186 */       buffer.append(jpds[i].getName());
/*     */     }
/* 188 */     buffer.append("]");
/* 189 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/JXPathBasicBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */