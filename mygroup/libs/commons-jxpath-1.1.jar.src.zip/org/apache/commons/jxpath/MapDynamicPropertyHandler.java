/*     */ package org.apache.commons.jxpath;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapDynamicPropertyHandler
/*     */   implements DynamicPropertyHandler
/*     */ {
/*  75 */   private static final String[] STRING_ARRAY = new String[0];
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getPropertyNames(Object object)
/*     */   {
/*  81 */     Map map = (Map)object;
/*  82 */     String[] names = new String[map.size()];
/*  83 */     Iterator it = map.keySet().iterator();
/*  84 */     for (int i = 0; i < names.length; i++) {
/*  85 */       names[i] = String.valueOf(it.next());
/*     */     }
/*  87 */     return names;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getProperty(Object object, String propertyName)
/*     */   {
/*  94 */     return ((Map)object).get(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setProperty(Object object, String propertyName, Object value)
/*     */   {
/* 101 */     ((Map)object).put(propertyName, value);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/MapDynamicPropertyHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */