/*     */ package org.apache.commons.jxpath;
/*     */ 
/*     */ import java.text.DecimalFormatSymbols;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JXPathContext
/*     */ {
/*     */   protected JXPathContext parentContext;
/*     */   protected Object contextBean;
/*     */   protected Variables vars;
/*     */   protected Functions functions;
/*     */   protected AbstractFactory factory;
/*     */   protected Locale locale;
/* 430 */   protected boolean lenient = false;
/*     */   
/*     */   protected IdentityManager idManager;
/*     */   
/*     */   protected KeyManager keyManager;
/*     */   
/*     */   protected HashMap decimalFormats;
/*     */   private static JXPathContext compilationContext;
/*     */   
/*     */   public static JXPathContext newContext(Object contextBean)
/*     */   {
/* 441 */     return JXPathContextFactory.newInstance().newContext(null, contextBean);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JXPathContext newContext(JXPathContext parentContext, Object contextBean)
/*     */   {
/* 453 */     return JXPathContextFactory.newInstance().newContext(parentContext, contextBean);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JXPathContext(JXPathContext parentContext, Object contextBean)
/*     */   {
/* 463 */     this.parentContext = parentContext;
/* 464 */     this.contextBean = contextBean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JXPathContext getParentContext()
/*     */   {
/* 471 */     return this.parentContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getContextBean()
/*     */   {
/* 478 */     return this.contextBean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Pointer getContextPointer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JXPathContext getRelativeContext(Pointer paramPointer);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVariables(Variables vars)
/*     */   {
/* 498 */     this.vars = vars;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Variables getVariables()
/*     */   {
/* 508 */     if (this.vars == null) {
/* 509 */       this.vars = new BasicVariables();
/*     */     }
/* 511 */     return this.vars;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFunctions(Functions functions)
/*     */   {
/* 520 */     this.functions = functions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Functions getFunctions()
/*     */   {
/* 527 */     return this.functions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFactory(AbstractFactory factory)
/*     */   {
/* 536 */     this.factory = factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFactory getFactory()
/*     */   {
/* 545 */     if ((this.factory == null) && (this.parentContext != null)) {
/* 546 */       return this.parentContext.getFactory();
/*     */     }
/* 548 */     return this.factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocale(Locale locale)
/*     */   {
/* 558 */     this.locale = locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Locale getLocale()
/*     */   {
/* 567 */     if (this.locale == null) {
/* 568 */       if (this.parentContext != null) {
/* 569 */         return this.parentContext.getLocale();
/*     */       }
/*     */       
/* 572 */       this.locale = Locale.getDefault();
/*     */     }
/*     */     
/* 575 */     return this.locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDecimalFormatSymbols(String name, DecimalFormatSymbols symbols)
/*     */   {
/* 590 */     if (this.decimalFormats == null) {
/* 591 */       this.decimalFormats = new HashMap();
/*     */     }
/* 593 */     this.decimalFormats.put(name, symbols);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public DecimalFormatSymbols getDecimalFormatSymbols(String name)
/*     */   {
/* 600 */     if (this.decimalFormats == null) {
/* 601 */       return null;
/*     */     }
/* 603 */     return (DecimalFormatSymbols)this.decimalFormats.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLenient(boolean lenient)
/*     */   {
/* 616 */     this.lenient = lenient;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isLenient()
/*     */   {
/* 623 */     return this.lenient;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CompiledExpression compile(String xpath)
/*     */   {
/* 634 */     if (compilationContext == null) {
/* 635 */       compilationContext = newContext(null);
/*     */     }
/* 637 */     return compilationContext.compilePath(xpath);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract CompiledExpression compilePath(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Object getValue(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Object getValue(String paramString, Class paramClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setValue(String paramString, Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Pointer createPath(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Pointer createPathAndSetValue(String paramString, Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void removePath(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void removeAll(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Iterator iterate(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Pointer getPointer(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Iterator iteratePointers(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIdentityManager(IdentityManager idManager)
/*     */   {
/* 731 */     this.idManager = idManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IdentityManager getIdentityManager()
/*     */   {
/* 739 */     if ((this.idManager == null) && (this.parentContext != null)) {
/* 740 */       return this.parentContext.getIdentityManager();
/*     */     }
/* 742 */     return this.idManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pointer getPointerByID(String id)
/*     */   {
/* 751 */     IdentityManager manager = getIdentityManager();
/* 752 */     if (manager != null) {
/* 753 */       return manager.getPointerByID(this, id);
/*     */     }
/*     */     
/* 756 */     throw new JXPathException("Cannot find an element by ID - no IdentityManager has been specified");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKeyManager(KeyManager keyManager)
/*     */   {
/* 767 */     this.keyManager = keyManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyManager getKeyManager()
/*     */   {
/* 775 */     if ((this.keyManager == null) && (this.parentContext != null)) {
/* 776 */       return this.parentContext.getKeyManager();
/*     */     }
/* 778 */     return this.keyManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Pointer getPointerByKey(String key, String value)
/*     */   {
/* 785 */     KeyManager manager = getKeyManager();
/* 786 */     if (manager != null) {
/* 787 */       return manager.getPointerByKey(this, key, value);
/*     */     }
/*     */     
/* 790 */     throw new JXPathException("Cannot find an element by key - no KeyManager has been specified");
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/JXPathContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */