/*     */ package org.apache.commons.jxpath.functions;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import org.apache.commons.jxpath.ExpressionContext;
/*     */ import org.apache.commons.jxpath.Function;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.util.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstructorFunction
/*     */   implements Function
/*     */ {
/*     */   private Constructor constructor;
/*  81 */   private static final Object[] EMPTY_ARRAY = new Object[0];
/*     */   
/*     */   public ConstructorFunction(Constructor constructor) {
/*  84 */     this.constructor = constructor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object invoke(ExpressionContext context, Object[] parameters)
/*     */   {
/*     */     try
/*     */     {
/*  93 */       if (parameters == null) {
/*  94 */         parameters = EMPTY_ARRAY;
/*     */       }
/*  96 */       int pi = 0;
/*  97 */       Class[] types = this.constructor.getParameterTypes();
/*  98 */       if ((types.length > 0) && (ExpressionContext.class.isAssignableFrom(types[0])))
/*     */       {
/* 100 */         pi = 1;
/*     */       }
/* 102 */       Object[] args = new Object[parameters.length + pi];
/* 103 */       if (pi == 1) {
/* 104 */         args[0] = context;
/*     */       }
/* 106 */       for (int i = 0; i < parameters.length; i++) {
/* 107 */         args[(i + pi)] = TypeUtils.convert(parameters[i], types[(i + pi)]);
/*     */       }
/* 109 */       return this.constructor.newInstance(args);
/*     */     }
/*     */     catch (Throwable ex) {
/* 112 */       if ((ex instanceof InvocationTargetException)) {
/* 113 */         ex = ((InvocationTargetException)ex).getTargetException();
/*     */       }
/* 115 */       throw new JXPathException("Cannot invoke constructor " + this.constructor, ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/functions/ConstructorFunction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */