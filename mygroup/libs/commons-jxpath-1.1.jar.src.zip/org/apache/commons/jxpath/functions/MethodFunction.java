/*     */ package org.apache.commons.jxpath.functions;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.apache.commons.jxpath.ExpressionContext;
/*     */ import org.apache.commons.jxpath.Function;
/*     */ import org.apache.commons.jxpath.JXPathException;
/*     */ import org.apache.commons.jxpath.util.TypeUtils;
/*     */ import org.apache.commons.jxpath.util.ValueUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodFunction
/*     */   implements Function
/*     */ {
/*     */   private Method method;
/*  83 */   private static final Object[] EMPTY_ARRAY = new Object[0];
/*     */   
/*     */   public MethodFunction(Method method) {
/*  86 */     this.method = ValueUtils.getAccessibleMethod(method);
/*     */   }
/*     */   
/*     */   public Object invoke(ExpressionContext context, Object[] parameters) {
/*     */     try {
/*     */       Object target;
/*     */       Object[] args;
/*  93 */       if (Modifier.isStatic(this.method.getModifiers())) {
/*  94 */         target = null;
/*  95 */         if (parameters == null) {
/*  96 */           parameters = EMPTY_ARRAY;
/*     */         }
/*  98 */         int pi = 0;
/*  99 */         Class[] types = this.method.getParameterTypes();
/* 100 */         if ((types.length >= 1) && (ExpressionContext.class.isAssignableFrom(types[0])))
/*     */         {
/* 102 */           pi = 1;
/*     */         }
/* 104 */         args = new Object[parameters.length + pi];
/* 105 */         if (pi == 1) {
/* 106 */           args[0] = context;
/*     */         }
/* 108 */         for (int i = 0; i < parameters.length; i++) {
/* 109 */           args[(i + pi)] = TypeUtils.convert(parameters[i], types[(i + pi)]);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 114 */         int pi = 0;
/* 115 */         Class[] types = this.method.getParameterTypes();
/* 116 */         if ((types.length >= 1) && (ExpressionContext.class.isAssignableFrom(types[0])))
/*     */         {
/* 118 */           pi = 1;
/*     */         }
/* 120 */         target = TypeUtils.convert(parameters[0], this.method.getDeclaringClass());
/*     */         
/*     */ 
/*     */ 
/* 124 */         args = new Object[parameters.length - 1 + pi];
/* 125 */         if (pi == 1) {
/* 126 */           args[0] = context;
/*     */         }
/* 128 */         for (int i = 1; i < parameters.length; i++) {
/* 129 */           args[(pi + i - 1)] = TypeUtils.convert(parameters[i], types[(i + pi - 1)]);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 134 */       return this.method.invoke(target, args);
/*     */     }
/*     */     catch (Throwable ex) {
/* 137 */       if ((ex instanceof InvocationTargetException)) {
/* 138 */         ex = ((InvocationTargetException)ex).getTargetException();
/*     */       }
/* 140 */       throw new JXPathException("Cannot invoke " + this.method, ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 145 */     return this.method.toString();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/commons-jxpath-1.1.jar!/org/apache/commons/jxpath/functions/MethodFunction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */