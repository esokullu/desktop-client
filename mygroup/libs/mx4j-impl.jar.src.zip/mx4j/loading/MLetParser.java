/*     */ package mx4j.loading;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.loading.MLet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MLetParser
/*     */ {
/*     */   public static final String OPEN_COMMENT = "<!--";
/*     */   public static final String CLOSE_COMMENT = "-->";
/*     */   public static final String OPEN_BRACKET = "<";
/*     */   public static final String CLOSE_BRACKET = ">";
/*     */   public static final String MLET_TAG = "MLET";
/*     */   public static final String CODE_ATTR = "CODE";
/*     */   public static final String OBJECT_ATTR = "OBJECT";
/*     */   public static final String ARCHIVE_ATTR = "ARCHIVE";
/*     */   public static final String CODEBASE_ATTR = "CODEBASE";
/*     */   public static final String NAME_ATTR = "NAME";
/*     */   public static final String VERSION_ATTR = "VERSION";
/*     */   public static final String ARG_TAG = "ARG";
/*     */   public static final String TYPE_ATTR = "TYPE";
/*     */   public static final String VALUE_ATTR = "VALUE";
/*     */   private MLet mlet;
/*     */   
/*     */   public MLetParser() {}
/*     */   
/*     */   public MLetParser(MLet mlet)
/*     */   {
/*  61 */     this.mlet = mlet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List parse(String content)
/*     */     throws MLetParseException
/*     */   {
/*  73 */     if (content == null) { throw new MLetParseException("MLet file content cannot be null");
/*     */     }
/*     */     
/*  76 */     content = stripComments(content.trim());
/*  77 */     content = convertToUpperCase(content);
/*     */     
/*  79 */     ArrayList mlets = parseMLets(content);
/*  80 */     if (mlets.size() < 1) { throw new MLetParseException("MLet file is empty");
/*     */     }
/*  82 */     ArrayList mletTags = new ArrayList();
/*  83 */     for (int i = 0; i < mlets.size(); i++)
/*     */     {
/*  85 */       String mletTag = (String)mlets.get(i);
/*     */       
/*  87 */       MLetTag tag = parseMLet(mletTag);
/*  88 */       mletTags.add(tag);
/*     */     }
/*     */     
/*  91 */     return mletTags;
/*     */   }
/*     */   
/*     */   private MLetTag parseMLet(String content) throws MLetParseException
/*     */   {
/*  96 */     MLetTag tag = new MLetTag();
/*  97 */     parseMLetAttributes(tag, content);
/*  98 */     parseMLetArguments(tag, content);
/*  99 */     return tag;
/*     */   }
/*     */   
/*     */   private ArrayList parseMLets(String content) throws MLetParseException
/*     */   {
/* 104 */     ArrayList list = new ArrayList();
/* 105 */     int start = 0;
/* 106 */     int current = -1;
/* 107 */     while ((current = findOpenTag(content, start, "MLET")) >= 0)
/*     */     {
/* 109 */       int end = findCloseTag(content, current + 1, "MLET", true);
/* 110 */       if (end < 0) { throw new MLetParseException("MLET tag not closed at index: " + current);
/*     */       }
/* 112 */       String mlet = content.substring(current, end);
/* 113 */       list.add(mlet);
/*     */       
/* 115 */       start = end + 1;
/*     */     }
/* 117 */     return list;
/*     */   }
/*     */   
/*     */   private void parseMLetArguments(MLetTag tag, String content) throws MLetParseException
/*     */   {
/* 122 */     int start = 0;
/* 123 */     int current = -1;
/* 124 */     while ((current = findOpenTag(content, start, "ARG")) >= 0)
/*     */     {
/* 126 */       int end = findCloseTag(content, current + 1, "ARG", false);
/* 127 */       if (end < 0) { throw new MLetParseException("ARG tag not closed");
/*     */       }
/* 129 */       String arg = content.substring(current, end);
/*     */       
/* 131 */       int type = arg.indexOf("TYPE");
/* 132 */       if (type < 0) { throw new MLetParseException("Missing TYPE attribute");
/*     */       }
/* 134 */       int value = arg.indexOf("VALUE");
/* 135 */       if (value < 0) { throw new MLetParseException("Missing VALUE attribute");
/*     */       }
/* 137 */       String className = findAttributeValue(arg, type, "TYPE");
/* 138 */       tag.addArg(className, convertToObject(className, findAttributeValue(arg, value, "VALUE")));
/*     */       
/* 140 */       start = end + 1;
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseMLetAttributes(MLetTag tag, String content) throws MLetParseException
/*     */   {
/* 146 */     int end = content.indexOf(">");
/* 147 */     String attributes = content.substring(0, end);
/*     */     
/*     */ 
/* 150 */     int archive = -1;
/* 151 */     int object = -1;
/* 152 */     int code = -1;
/*     */     
/* 154 */     archive = attributes.indexOf("ARCHIVE");
/* 155 */     if (archive < 0) { throw new MLetParseException("Missing ARCHIVE attribute");
/*     */     }
/* 157 */     code = attributes.indexOf("CODE");
/* 158 */     object = attributes.indexOf("OBJECT");
/* 159 */     if ((code < 0) && (object < 0)) throw new MLetParseException("Missing CODE or OBJECT attribute");
/* 160 */     if ((code > 0) && (object > 0)) { throw new MLetParseException("CODE and OBJECT attributes cannot be both present");
/*     */     }
/* 162 */     if (code >= 0) {
/* 163 */       tag.setCode(findAttributeValue(attributes, code, "CODE"));
/*     */     } else {
/* 165 */       tag.setObject(findAttributeValue(attributes, object, "OBJECT"));
/*     */     }
/* 167 */     tag.setArchive(findAttributeValue(attributes, archive, "ARCHIVE"));
/*     */     
/*     */ 
/* 170 */     int codebase = attributes.indexOf("CODEBASE");
/* 171 */     if (codebase >= 0) { tag.setCodeBase(findAttributeValue(attributes, codebase, "CODEBASE"));
/*     */     }
/* 173 */     int name = attributes.indexOf("NAME");
/* 174 */     if (name >= 0)
/*     */     {
/* 176 */       String objectName = findAttributeValue(attributes, name, "NAME");
/*     */       try
/*     */       {
/* 179 */         tag.setName(new ObjectName(objectName));
/*     */       }
/*     */       catch (MalformedObjectNameException x)
/*     */       {
/* 183 */         throw new MLetParseException("Invalid ObjectName: " + objectName);
/*     */       }
/*     */     }
/*     */     
/* 187 */     int version = attributes.indexOf("VERSION");
/* 188 */     if (version >= 0) tag.setVersion(findAttributeValue(attributes, version, "VERSION"));
/*     */   }
/*     */   
/*     */   private String findAttributeValue(String content, int start, String attribute) throws MLetParseException
/*     */   {
/* 193 */     int equal = content.indexOf('=', start);
/* 194 */     if (equal < 0) { throw new MLetParseException("Missing '=' for attribute");
/*     */     }
/*     */     
/* 197 */     if (!attribute.equals(content.substring(start, equal).trim())) { throw new MLetParseException("Invalid attribute");
/*     */     }
/* 199 */     int begin = content.indexOf('"', equal + 1);
/* 200 */     if (begin < 0) { throw new MLetParseException("Missing quotes for attribute value");
/*     */     }
/*     */     
/* 203 */     if (content.substring(equal + 1, begin).trim().length() != 0) { throw new MLetParseException("Invalid attribute value");
/*     */     }
/* 205 */     int end = content.indexOf('"', begin + 1);
/* 206 */     if (end < 0) { throw new MLetParseException("Missing quote for attribute value");
/*     */     }
/* 208 */     return content.substring(begin + 1, end).trim();
/*     */   }
/*     */   
/*     */   private int findOpenTag(String content, int start, String tag)
/*     */   {
/* 213 */     String opening = "<" + tag;
/* 214 */     return content.indexOf(opening, start);
/*     */   }
/*     */   
/*     */   private int findCloseTag(String content, int start, String tag, boolean strictSyntax)
/*     */   {
/* 219 */     int count = 1;
/*     */     
/*     */     for (;;)
/*     */     {
/* 223 */       int close = content.indexOf(">", start);
/* 224 */       if (close < 0)
/*     */       {
/* 226 */         return -1;
/*     */       }
/* 228 */       int open = content.indexOf("<", start);
/* 229 */       if ((open >= 0) && (close > open))
/*     */       {
/* 231 */         count++;
/*     */       }
/*     */       else
/*     */       {
/* 235 */         count--;
/* 236 */         if (count == 0)
/*     */         {
/*     */ 
/*     */ 
/* 240 */           if ((!strictSyntax) || ((strictSyntax) && (content.charAt(close - 1) == '/')))
/*     */           {
/*     */ 
/* 243 */             return close + 1;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 248 */           String closing = "<" + "/" + tag + ">";
/* 249 */           close = content.indexOf(closing, start);
/* 250 */           if (close < 0) {
/* 251 */             return -1;
/*     */           }
/* 253 */           return close + closing.length();
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 258 */       start = close + 1;
/*     */     }
/*     */   }
/*     */   
/*     */   private String stripComments(String content)
/*     */     throws MLetParseException
/*     */   {
/* 265 */     StringBuffer buffer = new StringBuffer();
/* 266 */     int start = 0;
/* 267 */     int current = -1;
/* 268 */     while ((current = content.indexOf("<!--", start)) >= 0)
/*     */     {
/* 270 */       int end = content.indexOf("-->", current + 1);
/*     */       
/* 272 */       if (end < 0) { throw new MLetParseException("Missing close comment tag at index: " + current);
/*     */       }
/* 274 */       String stripped = content.substring(start, current);
/* 275 */       buffer.append(stripped);
/* 276 */       start = end + "-->".length();
/*     */     }
/* 278 */     String stripped = content.substring(start, content.length());
/* 279 */     buffer.append(stripped);
/* 280 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private String convertToUpperCase(String content) throws MLetParseException
/*     */   {
/* 285 */     StringBuffer buffer = new StringBuffer();
/* 286 */     int start = 0;
/* 287 */     int current = -1;
/* 288 */     while ((current = content.indexOf("\"", start)) >= 0)
/*     */     {
/* 290 */       int end = content.indexOf("\"", current + 1);
/*     */       
/* 292 */       if (end < 0) { throw new MLetParseException("Missing closing quote at index: " + current);
/*     */       }
/* 294 */       String converted = content.substring(start, current).toUpperCase();
/* 295 */       buffer.append(converted);
/* 296 */       String quoted = content.substring(current, end + 1);
/* 297 */       buffer.append(quoted);
/* 298 */       start = end + 1;
/*     */     }
/* 300 */     String converted = content.substring(start, content.length()).toUpperCase();
/* 301 */     buffer.append(converted);
/* 302 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private Object convertToObject(String clsName, String value) throws MLetParseException
/*     */   {
/*     */     try
/*     */     {
/* 309 */       if ((clsName.equals("boolean")) || (clsName.equals("java.lang.Boolean")))
/* 310 */         return Boolean.valueOf(value);
/* 311 */       if ((clsName.equals("byte")) || (clsName.equals("java.lang.Byte")))
/* 312 */         return Byte.valueOf(value);
/* 313 */       if ((clsName.equals("char")) || (clsName.equals("java.lang.Character")))
/*     */       {
/* 315 */         char ch = '\000';
/* 316 */         if (value.length() > 0) ch = value.charAt(0);
/* 317 */         return new Character(ch);
/*     */       }
/* 319 */       if ((clsName.equals("short")) || (clsName.equals("java.lang.Short")))
/* 320 */         return Short.valueOf(value);
/* 321 */       if ((clsName.equals("int")) || (clsName.equals("java.lang.Integer")))
/* 322 */         return Integer.valueOf(value);
/* 323 */       if ((clsName.equals("long")) || (clsName.equals("java.lang.Long")))
/* 324 */         return Long.valueOf(value);
/* 325 */       if ((clsName.equals("float")) || (clsName.equals("java.lang.Float")))
/* 326 */         return Float.valueOf(value);
/* 327 */       if ((clsName.equals("double")) || (clsName.equals("java.lang.Double")))
/* 328 */         return Double.valueOf(value);
/* 329 */       if (clsName.equals("java.lang.String"))
/* 330 */         return value;
/* 331 */       if (this.mlet != null)
/*     */       {
/*     */         try
/*     */         {
/* 335 */           Class cls = this.mlet.loadClass(clsName);
/* 336 */           Constructor ctor = cls.getConstructor(new Class[] { String.class });
/* 337 */           return ctor.newInstance(new Object[] { value });
/*     */ 
/*     */         }
/*     */         catch (Exception ignored) {}
/*     */       }
/*     */       
/*     */     }
/*     */     catch (NumberFormatException x)
/*     */     {
/* 346 */       throw new MLetParseException("Invalid value: " + value);
/*     */     }
/* 348 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/loading/MLetParser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */