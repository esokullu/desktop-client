/*    */ package mx4j.loading;
/*    */ 
/*    */ import java.security.SecureClassLoader;
/*    */ import javax.management.loading.ClassLoaderRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RepositoryClassLoader
/*    */   extends SecureClassLoader
/*    */ {
/*    */   private ClassLoaderRepository repository;
/*    */   
/*    */   public RepositoryClassLoader(ClassLoaderRepository repository)
/*    */   {
/* 25 */     this.repository = repository;
/*    */   }
/*    */   
/*    */   public Class loadClass(String name) throws ClassNotFoundException
/*    */   {
/* 30 */     return this.repository.loadClass(name);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/loading/RepositoryClassLoader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */