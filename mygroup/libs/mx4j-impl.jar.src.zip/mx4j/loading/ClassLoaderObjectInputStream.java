/*    */ package mx4j.loading;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectStreamClass;
/*    */ import java.io.StreamCorruptedException;
/*    */ import java.lang.reflect.Proxy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassLoaderObjectInputStream
/*    */   extends ObjectInputStream
/*    */ {
/*    */   private ClassLoader classLoader;
/*    */   
/*    */   public ClassLoaderObjectInputStream(InputStream stream, ClassLoader classLoader)
/*    */     throws IOException, StreamCorruptedException
/*    */   {
/* 36 */     super(stream);
/* 37 */     if (classLoader == null) throw new IllegalArgumentException("Classloader cannot be null");
/* 38 */     this.classLoader = classLoader;
/*    */   }
/*    */   
/*    */   protected Class resolveClass(ObjectStreamClass osc) throws IOException, ClassNotFoundException
/*    */   {
/* 43 */     String name = osc.getName();
/* 44 */     return loadClass(name);
/*    */   }
/*    */   
/*    */   protected Class resolveProxyClass(String[] interfaces) throws IOException, ClassNotFoundException
/*    */   {
/* 49 */     Class[] classes = new Class[interfaces.length];
/* 50 */     for (int i = 0; i < interfaces.length; i++) { classes[i] = loadClass(interfaces[i]);
/*    */     }
/* 52 */     return Proxy.getProxyClass(this.classLoader, classes);
/*    */   }
/*    */   
/*    */   private Class loadClass(String name) throws ClassNotFoundException
/*    */   {
/* 57 */     return this.classLoader.loadClass(name);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/loading/ClassLoaderObjectInputStream.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */