/*     */ package mx4j.loading;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MLetTag
/*     */ {
/*     */   private String code;
/*     */   private String object;
/*     */   private String archive;
/*     */   private String codebase;
/*     */   private ObjectName objectName;
/*     */   private String version;
/*  30 */   private ArrayList signature = new ArrayList();
/*  31 */   private ArrayList arguments = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL normalizeCodeBase(URL mletFileURL)
/*     */   {
/*  50 */     URL codebaseURL = null;
/*  51 */     String codebase = getCodeBase();
/*  52 */     if (codebase != null)
/*     */     {
/*     */       try
/*     */       {
/*     */ 
/*  57 */         codebaseURL = new URL(codebase);
/*     */ 
/*     */       }
/*     */       catch (MalformedURLException ignored)
/*     */       {
/*     */         try
/*     */         {
/*  64 */           codebaseURL = new URL(mletFileURL, codebase);
/*     */         }
/*     */         catch (MalformedURLException alsoIgnored) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  73 */     if (codebaseURL == null)
/*     */     {
/*  75 */       String path = mletFileURL.getPath();
/*  76 */       int index = path.lastIndexOf('/');
/*     */       
/*     */       try
/*     */       {
/*  80 */         codebaseURL = new URL(mletFileURL, path.substring(0, index + 1));
/*     */       }
/*     */       catch (MalformedURLException ignored) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  88 */     return codebaseURL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] parseArchive()
/*     */   {
/*  96 */     String archive = getArchive();
/*  97 */     ArrayList archives = new ArrayList();
/*  98 */     StringTokenizer tokenizer = new StringTokenizer(archive, ",");
/*  99 */     while (tokenizer.hasMoreTokens())
/*     */     {
/* 101 */       String token = tokenizer.nextToken().trim();
/* 102 */       if (token.length() > 0)
/*     */       {
/* 104 */         token = token.replace('\\', '/');
/* 105 */         archives.add(token);
/*     */       }
/*     */     }
/* 108 */     return (String[])archives.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL createArchiveURL(URL codebase, String archive)
/*     */   {
/*     */     try
/*     */     {
/* 119 */       return new URL(codebase, archive);
/*     */     }
/*     */     catch (MalformedURLException ignored) {}
/*     */     
/*     */ 
/* 124 */     return null;
/*     */   }
/*     */   
/*     */   public String getVersion()
/*     */   {
/* 129 */     return this.version;
/*     */   }
/*     */   
/*     */   public String getCodeBase()
/*     */   {
/* 134 */     return this.codebase;
/*     */   }
/*     */   
/*     */   public String getArchive()
/*     */   {
/* 139 */     return this.archive;
/*     */   }
/*     */   
/*     */   public String getCode()
/*     */   {
/* 144 */     return this.code;
/*     */   }
/*     */   
/*     */   public ObjectName getObjectName()
/*     */   {
/* 149 */     return this.objectName;
/*     */   }
/*     */   
/*     */   public String getObject()
/*     */   {
/* 154 */     return this.object;
/*     */   }
/*     */   
/*     */   public String[] getSignature()
/*     */   {
/* 159 */     return this.signature == null ? new String[0] : (String[])this.signature.toArray(new String[this.signature.size()]);
/*     */   }
/*     */   
/*     */   public Object[] getArguments()
/*     */   {
/* 164 */     return this.arguments == null ? new Object[0] : (Object[])this.arguments.toArray(new Object[this.arguments.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setArchive(String archive)
/*     */   {
/* 173 */     this.archive = archive;
/*     */   }
/*     */   
/*     */   void setCode(String code)
/*     */   {
/* 178 */     this.code = code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void setCodeBase(String codebase)
/*     */   {
/* 185 */     codebase = codebase.replace('\\', '/');
/* 186 */     if (!codebase.endsWith("/")) codebase = codebase + "/";
/* 187 */     this.codebase = codebase;
/*     */   }
/*     */   
/*     */   void setName(ObjectName name)
/*     */   {
/* 192 */     this.objectName = name;
/*     */   }
/*     */   
/*     */   void setObject(String object)
/*     */   {
/* 197 */     this.object = object;
/*     */   }
/*     */   
/*     */   void setVersion(String version)
/*     */   {
/* 202 */     this.version = version;
/*     */   }
/*     */   
/*     */   void addArg(String type, Object value)
/*     */   {
/* 207 */     this.signature.add(type);
/* 208 */     this.arguments.add(value);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/loading/MLetTag.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */