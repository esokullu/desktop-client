/*    */ package mx4j.loading;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MLetParseException
/*    */   extends Exception
/*    */ {
/*    */   public MLetParseException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MLetParseException(String message)
/*    */   {
/* 24 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/loading/MLetParseException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */