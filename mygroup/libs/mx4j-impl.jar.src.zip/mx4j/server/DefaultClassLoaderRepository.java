/*     */ package mx4j.server;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import javax.management.loading.MLet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultClassLoaderRepository
/*     */   extends ModifiableClassLoaderRepository
/*     */ {
/*     */   private static final int WITHOUT = 1;
/*     */   private static final int BEFORE = 2;
/*  24 */   private ArrayList classLoaders = new ArrayList();
/*     */   
/*     */   public Class loadClass(String className) throws ClassNotFoundException
/*     */   {
/*  28 */     return loadClassWithout(null, className);
/*     */   }
/*     */   
/*     */   public Class loadClassWithout(ClassLoader loader, String className) throws ClassNotFoundException
/*     */   {
/*  33 */     return loadClassFromRepository(loader, className, 1);
/*     */   }
/*     */   
/*     */   public Class loadClassBefore(ClassLoader loader, String className) throws ClassNotFoundException
/*     */   {
/*  38 */     return loadClassFromRepository(loader, className, 2);
/*     */   }
/*     */   
/*     */   protected void addClassLoader(ClassLoader cl)
/*     */   {
/*  43 */     if (cl == null) { return;
/*     */     }
/*  45 */     ArrayList loaders = getClassLoaders();
/*  46 */     synchronized (loaders)
/*     */     {
/*  48 */       if (!loaders.contains(cl)) loaders.add(cl);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void removeClassLoader(ClassLoader cl)
/*     */   {
/*  54 */     if (cl == null) { return;
/*     */     }
/*  56 */     ArrayList loaders = getClassLoaders();
/*  57 */     synchronized (loaders)
/*     */     {
/*  59 */       loaders.remove(cl);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected ArrayList cloneClassLoaders()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokevirtual 12	mx4j/server/DefaultClassLoaderRepository:getClassLoaders	()Ljava/util/ArrayList;
/*     */     //   4: astore_1
/*     */     //   5: aload_1
/*     */     //   6: dup
/*     */     //   7: astore_2
/*     */     //   8: monitorenter
/*     */     //   9: aload_1
/*     */     //   10: invokevirtual 16	java/util/ArrayList:clone	()Ljava/lang/Object;
/*     */     //   13: checkcast 7	java/util/ArrayList
/*     */     //   16: aload_2
/*     */     //   17: monitorexit
/*     */     //   18: areturn
/*     */     //   19: astore_3
/*     */     //   20: aload_2
/*     */     //   21: monitorexit
/*     */     //   22: aload_3
/*     */     //   23: athrow
/*     */     // Line number table:
/*     */     //   Java source line #65	-> byte code offset #0
/*     */     //   Java source line #66	-> byte code offset #5
/*     */     //   Java source line #68	-> byte code offset #9
/*     */     //   Java source line #69	-> byte code offset #19
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	24	0	this	DefaultClassLoaderRepository
/*     */     //   4	6	1	loaders	ArrayList
/*     */     //   7	14	2	Ljava/lang/Object;	Object
/*     */     //   19	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   9	18	19	finally
/*     */     //   19	22	19	finally
/*     */   }
/*     */   
/*     */   protected ArrayList getClassLoaders()
/*     */   {
/*  74 */     return this.classLoaders;
/*     */   }
/*     */   
/*     */   private Class loadClassFromRepository(ClassLoader loader, String className, int algorithm) throws ClassNotFoundException
/*     */   {
/*  79 */     ArrayList copy = cloneClassLoaders();
/*  80 */     for (int i = 0; i < copy.size(); i++)
/*     */     {
/*     */       try
/*     */       {
/*  84 */         ClassLoader cl = (ClassLoader)copy.get(i);
/*  85 */         if (cl.equals(loader))
/*     */         {
/*  87 */           if (algorithm == 2) {
/*     */             break;
/*     */           }
/*     */           
/*     */         }
/*     */         else {
/*  93 */           return loadClass(cl, className);
/*     */         }
/*     */       }
/*     */       catch (ClassNotFoundException ignored) {}
/*     */     }
/*     */     
/*  99 */     throw new ClassNotFoundException(className);
/*     */   }
/*     */   
/*     */ 
/*     */   private Class loadClass(ClassLoader loader, String className)
/*     */     throws ClassNotFoundException
/*     */   {
/* 106 */     if (loader.getClass() == MLet.class) return ((MLet)loader).loadClass(className, null);
/* 107 */     return loader.loadClass(className);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private int getSize()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokevirtual 12	mx4j/server/DefaultClassLoaderRepository:getClassLoaders	()Ljava/util/ArrayList;
/*     */     //   4: astore_1
/*     */     //   5: aload_1
/*     */     //   6: dup
/*     */     //   7: astore_2
/*     */     //   8: monitorenter
/*     */     //   9: aload_1
/*     */     //   10: invokevirtual 18	java/util/ArrayList:size	()I
/*     */     //   13: aload_2
/*     */     //   14: monitorexit
/*     */     //   15: ireturn
/*     */     //   16: astore_3
/*     */     //   17: aload_2
/*     */     //   18: monitorexit
/*     */     //   19: aload_3
/*     */     //   20: athrow
/*     */     // Line number table:
/*     */     //   Java source line #112	-> byte code offset #0
/*     */     //   Java source line #113	-> byte code offset #5
/*     */     //   Java source line #115	-> byte code offset #9
/*     */     //   Java source line #116	-> byte code offset #16
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	21	0	this	DefaultClassLoaderRepository
/*     */     //   4	6	1	loaders	ArrayList
/*     */     //   7	11	2	Ljava/lang/Object;	Object
/*     */     //   16	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   9	15	16	finally
/*     */     //   16	19	16	finally
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/DefaultClassLoaderRepository.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */