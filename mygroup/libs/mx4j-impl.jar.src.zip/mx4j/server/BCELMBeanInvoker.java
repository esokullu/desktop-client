/*     */ package mx4j.server;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.security.SecureClassLoader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import org.apache.bcel.classfile.JavaClass;
/*     */ import org.apache.bcel.generic.ARRAYLENGTH;
/*     */ import org.apache.bcel.generic.ArrayType;
/*     */ import org.apache.bcel.generic.BranchInstruction;
/*     */ import org.apache.bcel.generic.ClassGen;
/*     */ import org.apache.bcel.generic.InstructionConstants;
/*     */ import org.apache.bcel.generic.InstructionFactory;
/*     */ import org.apache.bcel.generic.InstructionHandle;
/*     */ import org.apache.bcel.generic.InstructionList;
/*     */ import org.apache.bcel.generic.LocalVariableGen;
/*     */ import org.apache.bcel.generic.MethodGen;
/*     */ import org.apache.bcel.generic.ObjectType;
/*     */ import org.apache.bcel.generic.PUSH;
/*     */ import org.apache.bcel.generic.ReferenceType;
/*     */ import org.apache.bcel.generic.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BCELMBeanInvoker
/*     */   extends CachingReflectionMBeanInvoker
/*     */ {
/*  87 */   private static final String LOGGER_CATEGORY = BCELMBeanInvoker.class.getName();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized MBeanInvoker create(MBeanMetaData metadata)
/*     */   {
/* 123 */     String parentName = BCELMBeanInvoker.class.getName();
/* 124 */     String name = parentName + "Generated";
/* 125 */     ClassGen classGen = new ClassGen(name, parentName, "<generated-on-the-fly>", 49, null);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */     classGen.addEmptyConstructor(1);
/* 132 */     classGen.addMethod(createInvokeImpl(metadata, classGen, name));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 137 */     byte[] bytes = classGen.getJavaClass().getBytes();
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 142 */       (BCELMBeanInvoker)AccessController.doPrivileged(new PrivilegedExceptionAction() { private final MBeanMetaData val$metadata;
/*     */         private final byte[] val$bytes;
/*     */         private final String val$name;
/*     */         
/* 146 */         public Object run() throws Exception { Class cls = new BCELMBeanInvoker.BCELClassLoader(this.val$metadata.getClassLoader(), this.val$bytes, null).loadClass(this.val$name);
/* 147 */           return cls.newInstance();
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (Throwable x)
/*     */     {
/* 153 */       Logger logger = Log.getLogger(LOGGER_CATEGORY);
/* 154 */       if (logger.isEnabledFor(20)) logger.info("Cannot create on-the-fly MBeanInvoker class, going with reflection MBeanInvoker", x); }
/* 155 */     return new CachingReflectionMBeanInvoker();
/*     */   }
/*     */   
/*     */ 
/*     */   private static org.apache.bcel.classfile.Method createInvokeImpl(MBeanMetaData metadata, ClassGen classGen, String clsName)
/*     */   {
/* 161 */     InstructionList implementation = new InstructionList();
/*     */     
/* 163 */     ObjectType metadataType = new ObjectType(MBeanMetaData.class.getName());
/* 164 */     Type[] signature = { metadataType, Type.STRING, new ArrayType(Type.STRING, 1), new ArrayType(Type.OBJECT, 1) };
/*     */     
/*     */ 
/* 167 */     MethodGen mthd = new MethodGen(4, Type.OBJECT, signature, new String[] { "metadata", "method", "params", "args" }, "invokeImpl", clsName, implementation, classGen.getConstantPool());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 175 */     mthd.addException("java.lang.Throwable");
/*     */     
/*     */ 
/* 178 */     InstructionFactory factory = new InstructionFactory(classGen);
/*     */     
/* 180 */     java.lang.reflect.Method[] methods = metadata.getMBeanInterface().getMethods();
/* 181 */     List tests = new ArrayList();
/* 182 */     List catches = new ArrayList();
/* 183 */     for (int i = 0; i < methods.length; i++)
/*     */     {
/* 185 */       java.lang.reflect.Method method = methods[i];
/* 186 */       catches.addAll(generateDirectInvokeBranch(classGen, mthd, implementation, factory, metadata.getMBeanInterface().getName(), method, tests));
/*     */     }
/*     */     
/*     */ 
/* 190 */     InstructionHandle invokeSuper = implementation.append(InstructionFactory.createThis());
/* 191 */     for (int i = 0; i < tests.size(); i++)
/*     */     {
/* 193 */       BranchInstruction branch = (BranchInstruction)tests.get(i);
/* 194 */       branch.setTarget(invokeSuper);
/*     */     }
/* 196 */     tests.clear();
/* 197 */     for (int i = 0; i < catches.size(); i++)
/*     */     {
/* 199 */       BranchInstruction branch = (BranchInstruction)catches.get(i);
/* 200 */       branch.setTarget(invokeSuper);
/*     */     }
/* 202 */     catches.clear();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 210 */     implementation.append(InstructionFactory.createLoad(metadataType, 1));
/* 211 */     implementation.append(InstructionFactory.createLoad(Type.STRING, 2));
/* 212 */     implementation.append(InstructionFactory.createLoad(new ArrayType(Type.STRING, 1), 3));
/* 213 */     implementation.append(InstructionFactory.createLoad(new ArrayType(Type.OBJECT, 1), 4));
/* 214 */     implementation.append(factory.createInvoke(BCELMBeanInvoker.class.getName(), "invokeImpl", Type.OBJECT, signature, (short)183));
/* 215 */     implementation.append(InstructionFactory.createReturn(Type.OBJECT));
/*     */     
/* 217 */     mthd.setMaxStack();
/*     */     
/* 219 */     org.apache.bcel.classfile.Method method = mthd.getMethod();
/*     */     
/*     */ 
/* 222 */     implementation.dispose();
/*     */     
/* 224 */     return method;
/*     */   }
/*     */   
/*     */   private static List generateDirectInvokeBranch(ClassGen classGen, MethodGen methodGen, InstructionList implementation, InstructionFactory factory, String management, java.lang.reflect.Method method, List tests)
/*     */   {
/* 229 */     ArrayList catches = new ArrayList();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 235 */     InstructionHandle startTest = implementation.append(InstructionFactory.createLoad(Type.STRING, 2));
/*     */     
/*     */ 
/* 238 */     for (int i = 0; i < tests.size(); i++)
/*     */     {
/* 240 */       BranchInstruction branch = (BranchInstruction)tests.get(i);
/*     */       
/* 242 */       branch.setTarget(startTest);
/*     */     }
/* 244 */     tests.clear();
/*     */     
/* 246 */     implementation.append(new PUSH(classGen.getConstantPool(), method.getName()));
/* 247 */     implementation.append(factory.createInvoke(class$java$lang$String.getName(), "equals", Type.BOOLEAN, new Type[] { Type.OBJECT }, (short)182));
/*     */     
/* 249 */     BranchInstruction test1 = InstructionFactory.createBranchInstruction((short)153, null);
/* 250 */     tests.add(test1);
/* 251 */     implementation.append(test1);
/*     */     
/* 253 */     implementation.append(InstructionFactory.createLoad(new ArrayType(Type.OBJECT, 1), 4));
/* 254 */     implementation.append(new ARRAYLENGTH());
/* 255 */     implementation.append(new PUSH(classGen.getConstantPool(), method.getParameterTypes().length));
/*     */     
/*     */ 
/* 258 */     BranchInstruction test2 = InstructionFactory.createBranchInstruction((short)160, null);
/* 259 */     tests.add(test2);
/* 260 */     implementation.append(test2);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 269 */     InstructionHandle tryStart = implementation.append(InstructionFactory.createLoad(new ObjectType(MBeanMetaData.class.getName()), 1));
/* 270 */     implementation.append(factory.createInvoke(MBeanMetaData.class.getName(), "getMBean", Type.OBJECT, new Type[0], (short)182));
/*     */     
/* 272 */     implementation.append(factory.createCheckCast(new ObjectType(management)));
/*     */     
/*     */ 
/* 275 */     Class[] signature = method.getParameterTypes();
/* 276 */     Type[] invokeSignature = new Type[signature.length];
/* 277 */     for (int i = 0; i < signature.length; i++)
/*     */     {
/* 279 */       Class param = signature[i];
/*     */       
/*     */ 
/* 282 */       implementation.append(InstructionFactory.createLoad(new ArrayType(Type.OBJECT, 1), 4));
/*     */       
/* 284 */       implementation.append(new PUSH(classGen.getConstantPool(), i));
/*     */       
/* 286 */       implementation.append(InstructionFactory.createArrayLoad(Type.OBJECT));
/*     */       
/*     */ 
/* 289 */       invokeSignature[i] = convertClassToType(param);
/*     */       
/* 291 */       if (param.isPrimitive())
/*     */       {
/*     */ 
/* 294 */         replaceObjectWithPrimitive(param, implementation, factory);
/*     */       }
/* 296 */       else if (param.isArray())
/*     */       {
/*     */ 
/* 299 */         implementation.append(factory.createCheckCast((ReferenceType)invokeSignature[i]));
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 304 */         implementation.append(factory.createCheckCast((ReferenceType)invokeSignature[i]));
/*     */       }
/*     */     }
/*     */     
/* 308 */     Class returnClass = method.getReturnType();
/* 309 */     Type returnType = convertClassToType(returnClass);
/*     */     
/*     */ 
/* 312 */     implementation.append(factory.createInvoke(management, method.getName(), returnType, invokeSignature, (short)185));
/*     */     
/* 314 */     if (returnClass == Void.TYPE)
/*     */     {
/* 316 */       implementation.append(InstructionConstants.ACONST_NULL);
/*     */     }
/* 318 */     else if (!returnClass.isArray())
/*     */     {
/*     */ 
/*     */ 
/* 322 */       if (returnClass.isPrimitive())
/*     */       {
/* 324 */         replacePrimitiveWithObject(returnClass, methodGen, implementation, factory);
/*     */       }
/*     */     }
/* 327 */     InstructionHandle tryEnd = implementation.append(InstructionFactory.createReturn(Type.OBJECT));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 332 */     ObjectType exceptionTypeCCE = new ObjectType("java.lang.ClassCastException");
/* 333 */     LocalVariableGen x = methodGen.addLocalVariable("x", exceptionTypeCCE, null, null);
/* 334 */     InstructionHandle handler = implementation.append(InstructionFactory.createStore(exceptionTypeCCE, x.getIndex()));
/* 335 */     x.setStart(handler);
/* 336 */     x.setEnd(handler);
/* 337 */     methodGen.addExceptionHandler(tryStart, tryEnd, handler, exceptionTypeCCE);
/*     */     
/* 339 */     BranchInstruction skip = InstructionFactory.createBranchInstruction((short)167, null);
/* 340 */     catches.add(skip);
/* 341 */     implementation.append(skip);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 346 */     ObjectType errorTypeIAE = new ObjectType("java.lang.IllegalAccessError");
/* 347 */     x = methodGen.addLocalVariable("x", errorTypeIAE, null, null);
/* 348 */     handler = implementation.append(InstructionFactory.createStore(errorTypeIAE, x.getIndex()));
/* 349 */     x.setStart(handler);
/* 350 */     x.setEnd(handler);
/* 351 */     methodGen.addExceptionHandler(tryStart, tryEnd, handler, errorTypeIAE);
/*     */     
/* 353 */     skip = InstructionFactory.createBranchInstruction((short)167, null);
/* 354 */     catches.add(skip);
/* 355 */     implementation.append(skip);
/*     */     
/* 357 */     return catches;
/*     */   }
/*     */   
/*     */   private static Type convertClassToType(Class cls)
/*     */   {
/* 362 */     if (cls == Void.TYPE) return Type.VOID;
/* 363 */     if (cls == Boolean.TYPE) return Type.BOOLEAN;
/* 364 */     if (cls == Byte.TYPE) return Type.BYTE;
/* 365 */     if (cls == Character.TYPE) return Type.CHAR;
/* 366 */     if (cls == Short.TYPE) return Type.SHORT;
/* 367 */     if (cls == Integer.TYPE) return Type.INT;
/* 368 */     if (cls == Long.TYPE) return Type.LONG;
/* 369 */     if (cls == Float.TYPE) return Type.FLOAT;
/* 370 */     if (cls == Double.TYPE) return Type.DOUBLE;
/* 371 */     if (cls == Object.class) return Type.OBJECT;
/* 372 */     if (cls == String.class) return Type.STRING;
/* 373 */     if (cls.isArray())
/*     */     {
/* 375 */       int dimensions = 0;
/* 376 */       Class c = null;
/* 377 */       while ((c = cls.getComponentType()) != null)
/*     */       {
/* 379 */         dimensions++;
/* 380 */         cls = c;
/*     */       }
/* 382 */       Type t = convertClassToType(cls);
/* 383 */       return new ArrayType(t, dimensions);
/*     */     }
/* 385 */     return new ObjectType(cls.getName());
/*     */   }
/*     */   
/*     */ 
/*     */   private static void replaceObjectWithPrimitive(Class type, InstructionList implementation, InstructionFactory factory)
/*     */   {
/* 391 */     if (type == Integer.TYPE)
/*     */     {
/*     */ 
/* 394 */       implementation.append(factory.createCheckCast(new ObjectType(Integer.class.getName())));
/* 395 */       implementation.append(factory.createInvoke(Integer.class.getName(), "intValue", Type.INT, Type.NO_ARGS, (short)182));
/*     */     }
/* 397 */     else if (type == Boolean.TYPE)
/*     */     {
/*     */ 
/* 400 */       implementation.append(factory.createCheckCast(new ObjectType(Boolean.class.getName())));
/* 401 */       implementation.append(factory.createInvoke(Boolean.class.getName(), "booleanValue", Type.BOOLEAN, Type.NO_ARGS, (short)182));
/*     */     }
/* 403 */     else if (type == Long.TYPE)
/*     */     {
/*     */ 
/* 406 */       implementation.append(factory.createCheckCast(new ObjectType(Long.class.getName())));
/* 407 */       implementation.append(factory.createInvoke(Long.class.getName(), "longValue", Type.LONG, Type.NO_ARGS, (short)182));
/*     */     }
/* 409 */     else if (type == Byte.TYPE)
/*     */     {
/*     */ 
/* 412 */       implementation.append(factory.createCheckCast(new ObjectType(Byte.class.getName())));
/* 413 */       implementation.append(factory.createInvoke(Byte.class.getName(), "byteValue", Type.BYTE, Type.NO_ARGS, (short)182));
/*     */     }
/* 415 */     else if (type == Character.TYPE)
/*     */     {
/*     */ 
/* 418 */       implementation.append(factory.createCheckCast(new ObjectType(Character.class.getName())));
/* 419 */       implementation.append(factory.createInvoke(Character.class.getName(), "charValue", Type.CHAR, Type.NO_ARGS, (short)182));
/*     */     }
/* 421 */     else if (type == Short.TYPE)
/*     */     {
/*     */ 
/* 424 */       implementation.append(factory.createCheckCast(new ObjectType(Short.class.getName())));
/* 425 */       implementation.append(factory.createInvoke(Short.class.getName(), "shortValue", Type.SHORT, Type.NO_ARGS, (short)182));
/*     */     }
/* 427 */     else if (type == Float.TYPE)
/*     */     {
/*     */ 
/* 430 */       implementation.append(factory.createCheckCast(new ObjectType(Float.class.getName())));
/* 431 */       implementation.append(factory.createInvoke(Float.class.getName(), "floatValue", Type.FLOAT, Type.NO_ARGS, (short)182));
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 436 */       implementation.append(factory.createCheckCast(new ObjectType(Double.class.getName())));
/* 437 */       implementation.append(factory.createInvoke(Double.class.getName(), "doubleValue", Type.DOUBLE, Type.NO_ARGS, (short)182));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static void replacePrimitiveWithObject(Class type, MethodGen methodGen, InstructionList implementation, InstructionFactory factory)
/*     */   {
/* 444 */     if (type == Integer.TYPE)
/*     */     {
/*     */ 
/* 447 */       LocalVariableGen i = methodGen.addLocalVariable("i", Type.INT, null, null);
/* 448 */       i.setStart(implementation.append(InstructionFactory.createStore(Type.INT, i.getIndex())));
/* 449 */       implementation.append(factory.createNew(new ObjectType(Integer.class.getName())));
/* 450 */       implementation.append(InstructionConstants.DUP);
/* 451 */       implementation.append(InstructionFactory.createLoad(Type.INT, i.getIndex()));
/* 452 */       i.setEnd(implementation.append(factory.createInvoke(class$java$lang$Integer.getName(), "<init>", Type.VOID, new Type[] { Type.INT }, (short)183)));
/*     */     }
/* 454 */     else if (type == Boolean.TYPE)
/*     */     {
/*     */ 
/* 457 */       LocalVariableGen b = methodGen.addLocalVariable("b", Type.BOOLEAN, null, null);
/* 458 */       b.setStart(implementation.append(InstructionFactory.createStore(Type.BOOLEAN, b.getIndex())));
/* 459 */       implementation.append(factory.createNew(new ObjectType(Boolean.class.getName())));
/* 460 */       implementation.append(InstructionConstants.DUP);
/* 461 */       implementation.append(InstructionFactory.createLoad(Type.BOOLEAN, b.getIndex()));
/* 462 */       b.setEnd(implementation.append(factory.createInvoke(class$java$lang$Boolean.getName(), "<init>", Type.VOID, new Type[] { Type.BOOLEAN }, (short)183)));
/*     */     }
/* 464 */     else if (type == Long.TYPE)
/*     */     {
/*     */ 
/* 467 */       LocalVariableGen l = methodGen.addLocalVariable("l", Type.LONG, null, null);
/* 468 */       l.setStart(implementation.append(InstructionFactory.createStore(Type.LONG, l.getIndex())));
/* 469 */       implementation.append(factory.createNew(new ObjectType(Long.class.getName())));
/* 470 */       implementation.append(InstructionConstants.DUP);
/* 471 */       implementation.append(InstructionFactory.createLoad(Type.LONG, l.getIndex()));
/* 472 */       l.setEnd(implementation.append(factory.createInvoke(class$java$lang$Long.getName(), "<init>", Type.VOID, new Type[] { Type.LONG }, (short)183)));
/*     */     }
/* 474 */     else if (type == Byte.TYPE)
/*     */     {
/*     */ 
/* 477 */       LocalVariableGen b = methodGen.addLocalVariable("b", Type.BYTE, null, null);
/* 478 */       b.setStart(implementation.append(InstructionFactory.createStore(Type.BYTE, b.getIndex())));
/* 479 */       implementation.append(factory.createNew(new ObjectType(Byte.class.getName())));
/* 480 */       implementation.append(InstructionConstants.DUP);
/* 481 */       implementation.append(InstructionFactory.createLoad(Type.BYTE, b.getIndex()));
/* 482 */       b.setEnd(implementation.append(factory.createInvoke(class$java$lang$Byte.getName(), "<init>", Type.VOID, new Type[] { Type.BYTE }, (short)183)));
/*     */     }
/* 484 */     else if (type == Character.TYPE)
/*     */     {
/*     */ 
/* 487 */       LocalVariableGen c = methodGen.addLocalVariable("c", Type.CHAR, null, null);
/* 488 */       c.setStart(implementation.append(InstructionFactory.createStore(Type.CHAR, c.getIndex())));
/* 489 */       implementation.append(factory.createNew(new ObjectType(Character.class.getName())));
/* 490 */       implementation.append(InstructionConstants.DUP);
/* 491 */       implementation.append(InstructionFactory.createLoad(Type.CHAR, c.getIndex()));
/* 492 */       c.setEnd(implementation.append(factory.createInvoke(class$java$lang$Character.getName(), "<init>", Type.VOID, new Type[] { Type.CHAR }, (short)183)));
/*     */     }
/* 494 */     else if (type == Short.TYPE)
/*     */     {
/*     */ 
/* 497 */       LocalVariableGen s = methodGen.addLocalVariable("s", Type.SHORT, null, null);
/* 498 */       s.setStart(implementation.append(InstructionFactory.createStore(Type.SHORT, s.getIndex())));
/* 499 */       implementation.append(factory.createNew(new ObjectType(Short.class.getName())));
/* 500 */       implementation.append(InstructionConstants.DUP);
/* 501 */       implementation.append(InstructionFactory.createLoad(Type.SHORT, s.getIndex()));
/* 502 */       s.setEnd(implementation.append(factory.createInvoke(class$java$lang$Short.getName(), "<init>", Type.VOID, new Type[] { Type.SHORT }, (short)183)));
/*     */     }
/* 504 */     else if (type == Float.TYPE)
/*     */     {
/*     */ 
/* 507 */       LocalVariableGen f = methodGen.addLocalVariable("f", Type.FLOAT, null, null);
/* 508 */       f.setStart(implementation.append(InstructionFactory.createStore(Type.FLOAT, f.getIndex())));
/* 509 */       implementation.append(factory.createNew(new ObjectType(Float.class.getName())));
/* 510 */       implementation.append(InstructionConstants.DUP);
/* 511 */       implementation.append(InstructionFactory.createLoad(Type.FLOAT, f.getIndex()));
/* 512 */       f.setEnd(implementation.append(factory.createInvoke(class$java$lang$Float.getName(), "<init>", Type.VOID, new Type[] { Type.FLOAT }, (short)183)));
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 517 */       LocalVariableGen d = methodGen.addLocalVariable("d", Type.DOUBLE, null, null);
/* 518 */       d.setStart(implementation.append(InstructionFactory.createStore(Type.DOUBLE, d.getIndex())));
/* 519 */       implementation.append(factory.createNew(new ObjectType(Double.class.getName())));
/* 520 */       implementation.append(InstructionConstants.DUP);
/* 521 */       implementation.append(InstructionFactory.createLoad(Type.DOUBLE, d.getIndex()));
/* 522 */       d.setEnd(implementation.append(factory.createInvoke(class$java$lang$Double.getName(), "<init>", Type.VOID, new Type[] { Type.DOUBLE }, (short)183)));
/*     */     }
/*     */   }
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/* 528 */     return Log.getLogger(LOGGER_CATEGORY);
/*     */   }
/*     */   
/*     */   protected Object invokeImpl(MBeanMetaData metadata, String method, String[] signature, Object[] args) throws Throwable
/*     */   {
/* 533 */     Logger logger = getLogger();
/* 534 */     if (logger.isEnabledFor(20))
/*     */     {
/* 536 */       logger.info("BCEL invocation failed for method " + method + "" + Arrays.asList(signature) + ", using reflection");
/*     */     }
/* 538 */     return super.invokeImpl(metadata, method, signature, args);
/*     */   }
/*     */   
/* 541 */   private static class BCELClassLoader extends SecureClassLoader { BCELClassLoader(ClassLoader x0, byte[] x1, BCELMBeanInvoker.1 x2) { this(x0, x1); }
/*     */     
/*     */ 
/*     */     private byte[] m_bytes;
/*     */     private BCELClassLoader(ClassLoader parent, byte[] bytecode)
/*     */     {
/* 547 */       super();
/* 548 */       this.m_bytes = bytecode;
/*     */     }
/*     */     
/*     */     protected Class findClass(String name) throws ClassNotFoundException
/*     */     {
/*     */       try
/*     */       {
/* 555 */         return (Class)AccessController.doPrivileged(new BCELMBeanInvoker.2(this, name), null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (PrivilegedActionException x)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 572 */         throw ((ClassNotFoundException)x.getException());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/BCELMBeanInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */