/*    */ package mx4j.server;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import javax.management.ObjectName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultMBeanRepository
/*    */   implements MBeanRepository
/*    */ {
/* 22 */   private HashMap m_map = new HashMap();
/*    */   
/*    */   public MBeanMetaData get(ObjectName name)
/*    */   {
/* 26 */     return (MBeanMetaData)this.m_map.get(name);
/*    */   }
/*    */   
/*    */   public void put(ObjectName name, MBeanMetaData metadata)
/*    */   {
/* 31 */     this.m_map.put(name, metadata);
/*    */   }
/*    */   
/*    */   public void remove(ObjectName name)
/*    */   {
/* 36 */     this.m_map.remove(name);
/*    */   }
/*    */   
/*    */   public int size()
/*    */   {
/* 41 */     return this.m_map.size();
/*    */   }
/*    */   
/*    */   public Iterator iterator()
/*    */   {
/* 46 */     return this.m_map.values().iterator();
/*    */   }
/*    */   
/*    */   public Object clone()
/*    */   {
/*    */     try
/*    */     {
/* 53 */       DefaultMBeanRepository repository = (DefaultMBeanRepository)super.clone();
/* 54 */       repository.m_map = ((HashMap)this.m_map.clone());
/* 55 */       return repository;
/*    */     }
/*    */     catch (CloneNotSupportedException ignored) {}
/*    */     
/* 59 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/DefaultMBeanRepository.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */