/*    */ package mx4j.server;
/*    */ 
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.MBeanServerBuilder;
/*    */ import javax.management.MBeanServerDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MX4JMBeanServerBuilder
/*    */   extends MBeanServerBuilder
/*    */ {
/*    */   public MBeanServerDelegate newMBeanServerDelegate()
/*    */   {
/* 39 */     return new MX4JMBeanServerDelegate();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MBeanServer newMBeanServer(String defaultDomain, MBeanServer outer, MBeanServerDelegate delegate)
/*    */   {
/* 53 */     return new MX4JMBeanServer(defaultDomain, outer, delegate);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/MX4JMBeanServerBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */