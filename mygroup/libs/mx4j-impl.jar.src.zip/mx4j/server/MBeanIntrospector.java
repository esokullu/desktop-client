/*     */ package mx4j.server;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.management.DynamicMBean;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanConstructorInfo;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.NotificationBroadcaster;
/*     */ import javax.management.loading.MLet;
/*     */ import mx4j.MBeanDescription;
/*     */ import mx4j.MBeanDescriptionAdapter;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import mx4j.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanIntrospector
/*     */ {
/*  60 */   private static final MBeanDescriptionAdapter DEFAULT_DESCRIPTION = new MBeanDescriptionAdapter();
/*  61 */   private static final MBeanConstructorInfo[] EMPTY_CONSTRUCTORS = new MBeanConstructorInfo[0];
/*  62 */   private static final MBeanParameterInfo[] EMPTY_PARAMETERS = new MBeanParameterInfo[0];
/*  63 */   private static final MBeanAttributeInfo[] EMPTY_ATTRIBUTES = new MBeanAttributeInfo[0];
/*  64 */   private static final MBeanNotificationInfo[] EMPTY_NOTIFICATIONS = new MBeanNotificationInfo[0];
/*  65 */   private static final MBeanOperationInfo[] EMPTY_OPERATIONS = new MBeanOperationInfo[0];
/*     */   
/*  67 */   private boolean extendedMBeanInterfaces = false;
/*  68 */   private boolean bcelAvailable = false;
/*  69 */   private String mbeanInvokerClass = null;
/*     */   
/*  71 */   private final WeakHashMap mbeanInfoCache = new WeakHashMap();
/*  72 */   private final WeakHashMap mbeanInvokerCache = new WeakHashMap();
/*     */   
/*     */   public MBeanIntrospector()
/*     */   {
/*  76 */     String strict = (String)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public Object run()
/*     */       {
/*  80 */         return System.getProperty("mx4j.strict.mbean.interface");
/*     */       }
/*     */     });
/*  83 */     if ((strict != null) && (!Boolean.valueOf(strict).booleanValue()))
/*     */     {
/*  85 */       this.extendedMBeanInterfaces = true;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  91 */       getClass().getClassLoader().loadClass("org.apache.bcelAvailable.generic.Type");
/*  92 */       this.bcelAvailable = true;
/*     */     }
/*     */     catch (Throwable ignored) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  99 */     this.mbeanInvokerClass = ((String)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public Object run()
/*     */       {
/* 103 */         return System.getProperty("mx4j.mbean.invoker");
/*     */       }
/*     */     }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void introspect(MBeanMetaData metadata)
/*     */   {
/* 116 */     introspectType(metadata);
/* 117 */     introspectMBeanInfo(metadata);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMBeanCompliant(MBeanMetaData metadata)
/*     */   {
/* 126 */     return (isMBeanClassCompliant(metadata)) && (isMBeanTypeCompliant(metadata)) && (isMBeanInfoCompliant(metadata));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean testCompliance(MBeanMetaData metadata)
/*     */   {
/* 135 */     introspect(metadata);
/* 136 */     return isMBeanCompliant(metadata);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean isMBeanClassCompliant(MBeanMetaData metadata)
/*     */   {
/* 143 */     Logger logger = getLogger();
/* 144 */     if (metadata.getMBeanInterface() != null)
/*     */     {
/* 146 */       boolean isPublic = Modifier.isPublic(metadata.getMBeanInterface().getModifiers());
/* 147 */       if ((!isPublic) && (logger.isEnabledFor(10))) logger.debug("MBean interface is not public");
/* 148 */       return isPublic;
/*     */     }
/* 150 */     return true;
/*     */   }
/*     */   
/*     */   private boolean isMBeanTypeCompliant(MBeanMetaData metadata)
/*     */   {
/* 155 */     Logger logger = getLogger();
/*     */     
/* 157 */     if ((metadata.isMBeanStandard()) && (metadata.isMBeanDynamic()))
/*     */     {
/* 159 */       if (logger.isEnabledFor(10)) logger.debug("MBean is both standard and dynamic");
/* 160 */       return false;
/*     */     }
/* 162 */     if ((!metadata.isMBeanStandard()) && (!metadata.isMBeanDynamic()))
/*     */     {
/* 164 */       if (logger.isEnabledFor(10)) logger.debug("MBean is not standard nor dynamic");
/* 165 */       return false;
/*     */     }
/*     */     
/* 168 */     return true;
/*     */   }
/*     */   
/*     */   private boolean isMBeanInfoCompliant(MBeanMetaData metadata)
/*     */   {
/* 173 */     Logger logger = getLogger();
/*     */     
/* 175 */     if (metadata.getMBeanInfo() == null)
/*     */     {
/* 177 */       if (logger.isEnabledFor(10)) logger.debug("MBeanInfo is null");
/* 178 */       return false;
/*     */     }
/* 180 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   private void introspectType(MBeanMetaData metadata)
/*     */   {
/* 186 */     if (metadata.isMBeanStandard())
/*     */     {
/* 188 */       introspectStandardMBean(metadata);
/* 189 */       return;
/*     */     }
/*     */     
/* 192 */     if ((metadata.getMBean() instanceof DynamicMBean))
/*     */     {
/* 194 */       metadata.setMBeanDynamic(true);
/* 195 */       return;
/*     */     }
/*     */     
/*     */ 
/* 199 */     metadata.setMBeanDynamic(false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 204 */     introspectStandardMBean(metadata);
/*     */   }
/*     */   
/*     */   private void introspectStandardMBean(MBeanMetaData metadata)
/*     */   {
/* 209 */     Class management = metadata.getMBeanInterface();
/* 210 */     if (management != null)
/*     */     {
/*     */ 
/* 213 */       if (management.isInstance(metadata.getMBean()))
/*     */       {
/* 215 */         metadata.setMBeanInvoker(createInvoker(metadata));
/* 216 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 221 */       metadata.setMBeanStandard(false);
/* 222 */       metadata.setMBeanInterface(null);
/* 223 */       metadata.setMBeanInvoker(null);
/* 224 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 229 */     Class cls = metadata.getMBean().getClass();
/* 230 */     for (Class c = cls; c != null; c = c.getSuperclass())
/*     */     {
/* 232 */       Class[] intfs = c.getInterfaces();
/* 233 */       for (int i = 0; i < intfs.length; i++)
/*     */       {
/* 235 */         Class intf = intfs[i];
/*     */         
/* 237 */         if (implementsMBean(c.getName(), intf.getName()))
/*     */         {
/*     */ 
/* 240 */           metadata.setMBeanStandard(true);
/* 241 */           metadata.setMBeanInterface(intf);
/* 242 */           metadata.setMBeanInvoker(createInvoker(metadata));
/* 243 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 249 */     metadata.setMBeanStandard(false);
/* 250 */     metadata.setMBeanInterface(null);
/* 251 */     metadata.setMBeanInvoker(null);
/*     */   }
/*     */   
/*     */ 
/*     */   private void introspectMBeanInfo(MBeanMetaData metadata)
/*     */   {
/* 257 */     if (metadata.isMBeanDynamic())
/*     */     {
/* 259 */       metadata.setMBeanInfo(getDynamicMBeanInfo(metadata));
/*     */     }
/* 261 */     else if (metadata.isMBeanStandard())
/*     */     {
/* 263 */       metadata.setMBeanInfo(createStandardMBeanInfo(metadata));
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 268 */       metadata.setMBeanInfo(null);
/*     */     }
/*     */   }
/*     */   
/*     */   private MBeanInfo getDynamicMBeanInfo(MBeanMetaData metadata)
/*     */   {
/* 274 */     Logger logger = getLogger();
/*     */     
/* 276 */     MBeanInfo info = null;
/*     */     
/*     */     try
/*     */     {
/* 280 */       info = ((DynamicMBean)metadata.getMBean()).getMBeanInfo();
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/* 284 */       if (logger.isEnabledFor(10)) { logger.debug("getMBeanInfo threw: " + x.toString());
/*     */       }
/*     */     }
/* 287 */     if (logger.isEnabledFor(0)) { logger.trace("Dynamic MBeanInfo is: " + info);
/*     */     }
/* 289 */     if (info == null)
/*     */     {
/* 291 */       if (logger.isEnabledFor(10)) logger.debug("MBeanInfo cannot be null");
/* 292 */       return null;
/*     */     }
/*     */     
/* 295 */     return info;
/*     */   }
/*     */   
/*     */   private MBeanInfo createStandardMBeanInfo(MBeanMetaData metadata)
/*     */   {
/* 300 */     synchronized (this.mbeanInfoCache)
/*     */     {
/* 302 */       MBeanInfo info = (MBeanInfo)this.mbeanInfoCache.get(metadata.getMBean().getClass());
/* 303 */       if (info != null) { return info;
/*     */       }
/*     */     }
/*     */     
/* 307 */     MBeanDescription description = createMBeanDescription(metadata);
/*     */     
/* 309 */     MBeanConstructorInfo[] ctors = createMBeanConstructorInfo(metadata, description);
/* 310 */     if (ctors == null) return null;
/* 311 */     MBeanAttributeInfo[] attrs = createMBeanAttributeInfo(metadata, description);
/* 312 */     if (attrs == null) return null;
/* 313 */     MBeanOperationInfo[] opers = createMBeanOperationInfo(metadata, description);
/* 314 */     if (opers == null) return null;
/* 315 */     MBeanNotificationInfo[] notifs = createMBeanNotificationInfo(metadata);
/* 316 */     if (notifs == null) { return null;
/*     */     }
/* 318 */     MBeanInfo info = new MBeanInfo(metadata.getMBean().getClass().getName(), description.getMBeanDescription(), attrs, ctors, opers, notifs);
/* 319 */     synchronized (this.mbeanInfoCache)
/*     */     {
/*     */ 
/* 322 */       this.mbeanInfoCache.put(metadata.getMBean().getClass(), info);
/*     */     }
/* 324 */     return info;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MBeanDescription createMBeanDescription(MBeanMetaData metadata)
/*     */   {
/* 335 */     Logger logger = getLogger();
/* 336 */     if (logger.isEnabledFor(0)) { logger.trace("Looking for standard MBean description...");
/*     */     }
/*     */     
/* 339 */     String descrClassName = metadata.getMBeanInterface().getName() + "Description";
/*     */     
/*     */     try
/*     */     {
/* 343 */       Class descrClass = null;
/* 344 */       ClassLoader loader = metadata.getClassLoader();
/* 345 */       if (loader == null) { loader = Thread.currentThread().getContextClassLoader();
/*     */       }
/*     */       
/* 348 */       if (loader.getClass() == MLet.class) {
/* 349 */         descrClass = ((MLet)loader).loadClass(descrClassName, null);
/*     */       } else {
/* 351 */         descrClass = loader.loadClass(descrClassName);
/*     */       }
/* 353 */       Object descrInstance = descrClass.newInstance();
/* 354 */       if ((descrInstance instanceof MBeanDescription))
/*     */       {
/* 356 */         MBeanDescription description = (MBeanDescription)descrInstance;
/* 357 */         if (logger.isEnabledFor(0)) logger.trace("Found provided standard MBean description: " + description);
/* 358 */         return description;
/*     */       }
/*     */     }
/*     */     catch (ClassNotFoundException ignored) {}catch (InstantiationException ignored) {}catch (IllegalAccessException ignored) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 371 */     MBeanDescription description = DEFAULT_DESCRIPTION;
/* 372 */     if (logger.isEnabledFor(0)) logger.trace("Cannot find standard MBean description, using default: " + description);
/* 373 */     return description;
/*     */   }
/*     */   
/*     */   private MBeanOperationInfo[] createMBeanOperationInfo(MBeanMetaData metadata, MBeanDescription description)
/*     */   {
/* 378 */     ArrayList operations = new ArrayList();
/*     */     
/* 380 */     Method[] methods = metadata.getMBeanInterface().getMethods();
/* 381 */     for (int j = 0; j < methods.length; j++)
/*     */     {
/* 383 */       Method method = methods[j];
/* 384 */       if ((!Utils.isAttributeGetter(method)) && (!Utils.isAttributeSetter(method)))
/*     */       {
/* 386 */         String descr = description == null ? null : description.getOperationDescription(method);
/* 387 */         Class[] params = method.getParameterTypes();
/* 388 */         int paramsNumber = params.length;
/* 389 */         MBeanParameterInfo[] paramsInfo = paramsNumber == 0 ? EMPTY_PARAMETERS : new MBeanParameterInfo[paramsNumber];
/* 390 */         for (int k = 0; k < paramsNumber; k++)
/*     */         {
/* 392 */           Class param = params[k];
/* 393 */           String paramName = description == null ? null : description.getOperationParameterName(method, k);
/* 394 */           String paramDescr = description == null ? null : description.getOperationParameterDescription(method, k);
/* 395 */           paramsInfo[k] = new MBeanParameterInfo(paramName, param.getName(), paramDescr);
/*     */         }
/* 397 */         MBeanOperationInfo info = new MBeanOperationInfo(method.getName(), descr, paramsInfo, method.getReturnType().getName(), 3);
/* 398 */         operations.add(info);
/*     */       }
/*     */     }
/*     */     
/* 402 */     int opersNumber = operations.size();
/* 403 */     return opersNumber == 0 ? EMPTY_OPERATIONS : (MBeanOperationInfo[])operations.toArray(new MBeanOperationInfo[opersNumber]);
/*     */   }
/*     */   
/*     */   private MBeanAttributeInfo[] createMBeanAttributeInfo(MBeanMetaData metadata, MBeanDescription description)
/*     */   {
/* 408 */     Logger logger = getLogger();
/*     */     
/* 410 */     HashMap attributes = new HashMap();
/* 411 */     HashMap getterNames = new HashMap();
/*     */     
/* 413 */     Method[] methods = metadata.getMBeanInterface().getMethods();
/* 414 */     for (int j = 0; j < methods.length; j++)
/*     */     {
/* 416 */       Method method = methods[j];
/* 417 */       if (Utils.isAttributeGetter(method))
/*     */       {
/* 419 */         String name = method.getName();
/* 420 */         boolean isIs = name.startsWith("is");
/*     */         
/* 422 */         String attribute = null;
/* 423 */         if (isIs) {
/* 424 */           attribute = name.substring(2);
/*     */         } else {
/* 426 */           attribute = name.substring(3);
/*     */         }
/* 428 */         String descr = description == null ? null : description.getAttributeDescription(attribute);
/*     */         
/* 430 */         MBeanAttributeInfo info = (MBeanAttributeInfo)attributes.get(attribute);
/*     */         
/* 432 */         if (info != null)
/*     */         {
/*     */ 
/*     */ 
/* 436 */           if (!info.getType().equals(method.getReturnType().getName()))
/*     */           {
/* 438 */             if (logger.isEnabledFor(10)) logger.debug("MBean is not compliant: has overloaded attribute " + attribute);
/* 439 */             return null;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 444 */           if (getterNames.get(name) != null) {
/*     */             continue;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 453 */           if (info.isReadable())
/*     */           {
/* 455 */             if (logger.isEnabledFor(10)) logger.debug("MBean is not compliant: has overloaded attribute " + attribute);
/* 456 */             return null;
/*     */           }
/*     */           
/*     */ 
/* 460 */           info = new MBeanAttributeInfo(attribute, info.getType(), info.getDescription(), true, info.isWritable(), isIs);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 465 */           info = new MBeanAttributeInfo(attribute, method.getReturnType().getName(), descr, true, false, isIs);
/*     */         }
/*     */         
/*     */ 
/* 469 */         attributes.put(attribute, info);
/* 470 */         getterNames.put(name, method);
/*     */       }
/* 472 */       else if (Utils.isAttributeSetter(method))
/*     */       {
/* 474 */         String name = method.getName();
/* 475 */         String attribute = name.substring(3);
/*     */         
/* 477 */         String descr = description == null ? null : description.getAttributeDescription(attribute);
/*     */         
/* 479 */         MBeanAttributeInfo info = (MBeanAttributeInfo)attributes.get(attribute);
/*     */         
/* 481 */         if (info != null)
/*     */         {
/*     */ 
/*     */ 
/* 485 */           if (!info.getType().equals(method.getParameterTypes()[0].getName()))
/*     */           {
/* 487 */             if (logger.isEnabledFor(10)) logger.debug("MBean is not compliant: has overloaded attribute " + attribute);
/* 488 */             return null;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 493 */           info = new MBeanAttributeInfo(info.getName(), info.getType(), info.getDescription(), info.isReadable(), true, info.isIs());
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 498 */           info = new MBeanAttributeInfo(attribute, method.getParameterTypes()[0].getName(), descr, false, true, false);
/*     */         }
/*     */         
/*     */ 
/* 502 */         attributes.put(attribute, info);
/*     */       }
/*     */     }
/*     */     
/* 506 */     int size = attributes.size();
/* 507 */     return size == 0 ? EMPTY_ATTRIBUTES : (MBeanAttributeInfo[])attributes.values().toArray(new MBeanAttributeInfo[size]);
/*     */   }
/*     */   
/*     */   private MBeanNotificationInfo[] createMBeanNotificationInfo(MBeanMetaData metadata)
/*     */   {
/* 512 */     MBeanNotificationInfo[] notifs = null;
/* 513 */     Object mbean = metadata.getMBean();
/* 514 */     if ((mbean instanceof NotificationBroadcaster))
/*     */     {
/* 516 */       notifs = ((NotificationBroadcaster)mbean).getNotificationInfo();
/*     */     }
/* 518 */     if ((notifs == null) || (notifs.length == 0)) notifs = EMPTY_NOTIFICATIONS;
/* 519 */     return notifs;
/*     */   }
/*     */   
/*     */   private MBeanConstructorInfo[] createMBeanConstructorInfo(MBeanMetaData metadata, MBeanDescription descrs)
/*     */   {
/* 524 */     Class mbeanClass = metadata.getMBean().getClass();
/*     */     
/* 526 */     Constructor[] ctors = mbeanClass.getConstructors();
/*     */     
/* 528 */     int ctorsNumber = ctors.length;
/* 529 */     MBeanConstructorInfo[] constructors = ctorsNumber == 0 ? EMPTY_CONSTRUCTORS : new MBeanConstructorInfo[ctorsNumber];
/* 530 */     for (int i = 0; i < ctorsNumber; i++)
/*     */     {
/* 532 */       Constructor constructor = ctors[i];
/* 533 */       String descr = descrs == null ? null : descrs.getConstructorDescription(constructor);
/* 534 */       Class[] params = constructor.getParameterTypes();
/* 535 */       int paramsNumber = params.length;
/* 536 */       MBeanParameterInfo[] paramsInfo = paramsNumber == 0 ? EMPTY_PARAMETERS : new MBeanParameterInfo[paramsNumber];
/* 537 */       for (int j = 0; j < paramsNumber; j++)
/*     */       {
/* 539 */         Class param = params[j];
/* 540 */         String paramName = descrs == null ? null : descrs.getConstructorParameterName(constructor, j);
/* 541 */         String paramDescr = descrs == null ? null : descrs.getConstructorParameterDescription(constructor, j);
/* 542 */         paramsInfo[j] = new MBeanParameterInfo(paramName, param.getName(), paramDescr);
/*     */       }
/*     */       
/* 545 */       String ctorName = constructor.getName();
/* 546 */       MBeanConstructorInfo info = new MBeanConstructorInfo(ctorName.substring(ctorName.lastIndexOf('.') + 1), descr, paramsInfo);
/* 547 */       constructors[i] = info;
/*     */     }
/* 549 */     return constructors;
/*     */   }
/*     */   
/*     */   private boolean implementsMBean(String clsName, String intfName)
/*     */   {
/* 554 */     if (intfName.equals(clsName + "MBean")) { return true;
/*     */     }
/* 556 */     if (this.extendedMBeanInterfaces)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 561 */       int clsDot = clsName.lastIndexOf('.');
/* 562 */       if (clsDot > 0) clsName = clsName.substring(clsDot + 1);
/* 563 */       int intfDot = intfName.lastIndexOf('.');
/* 564 */       if (intfDot > 0) { intfName = intfName.substring(intfDot + 1);
/*     */       }
/* 566 */       if (intfName.equals(clsName + "MBean")) { return true;
/*     */       }
/*     */       
/* 569 */       int clsDollar = clsName.lastIndexOf('$');
/* 570 */       if (clsDollar > 0) clsName = clsName.substring(clsDollar + 1);
/* 571 */       int intfDollar = intfName.lastIndexOf('$');
/* 572 */       if (intfDollar > 0) { intfName = intfName.substring(intfDollar + 1);
/*     */       }
/* 574 */       if (intfName.equals(clsName + "MBean")) { return true;
/*     */       }
/*     */     }
/*     */     
/* 578 */     return false;
/*     */   }
/*     */   
/*     */   private MBeanInvoker createInvoker(MBeanMetaData metadata)
/*     */   {
/* 583 */     MBeanInvoker invoker = null;
/*     */     
/* 585 */     synchronized (this.mbeanInvokerCache)
/*     */     {
/* 587 */       invoker = (MBeanInvoker)this.mbeanInvokerCache.get(metadata.getMBeanInterface());
/* 588 */       if (invoker != null) { return invoker;
/*     */       }
/*     */     }
/* 591 */     Logger logger = getLogger();
/*     */     
/* 593 */     if (this.mbeanInvokerClass != null)
/*     */     {
/* 595 */       if (logger.isEnabledFor(0)) logger.trace("Custom MBeanInvoker class is: " + this.mbeanInvokerClass);
/*     */       try
/*     */       {
/* 598 */         invoker = (MBeanInvoker)Thread.currentThread().getContextClassLoader().loadClass(this.mbeanInvokerClass).newInstance();
/* 599 */         if (logger.isEnabledFor(0)) logger.trace("Using custom MBeanInvoker: " + invoker);
/*     */       }
/*     */       catch (Exception x)
/*     */       {
/* 603 */         if (logger.isEnabledFor(10)) { logger.debug("Cannot instantiate custom MBeanInvoker, using default", x);
/*     */         }
/*     */       }
/*     */     }
/* 607 */     if (invoker == null)
/*     */     {
/* 609 */       if (this.bcelAvailable)
/*     */       {
/* 611 */         invoker = BCELMBeanInvoker.create(metadata);
/* 612 */         if (logger.isEnabledFor(0)) logger.trace("Using default BCEL MBeanInvoker for MBean " + metadata.getObjectName() + ", " + invoker);
/*     */       }
/*     */       else
/*     */       {
/* 616 */         invoker = new CachingReflectionMBeanInvoker();
/* 617 */         if (logger.isEnabledFor(0)) { logger.trace("Using default Reflection MBeanInvoker for MBean " + metadata.getObjectName() + ", " + invoker);
/*     */         }
/*     */       }
/*     */     }
/* 621 */     synchronized (this.mbeanInvokerCache)
/*     */     {
/*     */ 
/* 624 */       this.mbeanInvokerCache.put(metadata.getMBeanInterface(), invoker);
/*     */     }
/* 626 */     return invoker;
/*     */   }
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/* 631 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/MBeanIntrospector.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */