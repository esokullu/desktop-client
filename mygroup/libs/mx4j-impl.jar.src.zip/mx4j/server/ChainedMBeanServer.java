/*     */ package mx4j.server;
/*     */ 
/*     */ import java.io.ObjectInputStream;
/*     */ import java.util.Set;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.OperationsException;
/*     */ import javax.management.QueryExp;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.loading.ClassLoaderRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChainedMBeanServer
/*     */   implements MBeanServer
/*     */ {
/*     */   private MBeanServer m_server;
/*     */   
/*     */   public ChainedMBeanServer()
/*     */   {
/*  52 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ChainedMBeanServer(MBeanServer server)
/*     */   {
/*  60 */     setMBeanServer(server);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized MBeanServer getMBeanServer()
/*     */   {
/*  68 */     return this.m_server;
/*     */   }
/*     */   
/*     */   protected synchronized void setMBeanServer(MBeanServer server)
/*     */   {
/*  73 */     this.m_server = server;
/*     */   }
/*     */   
/*     */   public void addNotificationListener(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback)
/*     */     throws InstanceNotFoundException
/*     */   {
/*  79 */     getMBeanServer().addNotificationListener(observed, listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void addNotificationListener(ObjectName observed, ObjectName listener, NotificationFilter filter, Object handback)
/*     */     throws InstanceNotFoundException
/*     */   {
/*  85 */     getMBeanServer().addNotificationListener(observed, listener, filter, handback);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException
/*     */   {
/*  91 */     return getMBeanServer().createMBean(className, objectName);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName, Object[] args, String[] parameters)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException
/*     */   {
/*  97 */     return getMBeanServer().createMBean(className, objectName, args, parameters);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName, ObjectName loaderName)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException
/*     */   {
/* 103 */     return getMBeanServer().createMBean(className, objectName, loaderName);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName, ObjectName loaderName, Object[] args, String[] parameters)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException
/*     */   {
/* 109 */     return getMBeanServer().createMBean(className, objectName, loaderName, args, parameters);
/*     */   }
/*     */   
/*     */   public ObjectInputStream deserialize(String className, byte[] bytes)
/*     */     throws OperationsException, ReflectionException
/*     */   {
/* 115 */     return getMBeanServer().deserialize(className, bytes);
/*     */   }
/*     */   
/*     */   public ObjectInputStream deserialize(String className, ObjectName loaderName, byte[] bytes)
/*     */     throws InstanceNotFoundException, OperationsException, ReflectionException
/*     */   {
/* 121 */     return getMBeanServer().deserialize(className, loaderName, bytes);
/*     */   }
/*     */   
/*     */   public ObjectInputStream deserialize(ObjectName objectName, byte[] bytes)
/*     */     throws InstanceNotFoundException, OperationsException
/*     */   {
/* 127 */     return getMBeanServer().deserialize(objectName, bytes);
/*     */   }
/*     */   
/*     */   public Object getAttribute(ObjectName objectName, String attribute)
/*     */     throws MBeanException, AttributeNotFoundException, InstanceNotFoundException, ReflectionException
/*     */   {
/* 133 */     return getMBeanServer().getAttribute(objectName, attribute);
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(ObjectName objectName, String[] attributes)
/*     */     throws InstanceNotFoundException, ReflectionException
/*     */   {
/* 139 */     return getMBeanServer().getAttributes(objectName, attributes);
/*     */   }
/*     */   
/*     */   public String getDefaultDomain()
/*     */   {
/* 144 */     return getMBeanServer().getDefaultDomain();
/*     */   }
/*     */   
/*     */   public String[] getDomains()
/*     */   {
/* 149 */     return getMBeanServer().getDomains();
/*     */   }
/*     */   
/*     */   public Integer getMBeanCount()
/*     */   {
/* 154 */     return getMBeanServer().getMBeanCount();
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo(ObjectName objectName)
/*     */     throws InstanceNotFoundException, IntrospectionException, ReflectionException
/*     */   {
/* 160 */     return getMBeanServer().getMBeanInfo(objectName);
/*     */   }
/*     */   
/*     */   public ObjectInstance getObjectInstance(ObjectName objectName)
/*     */     throws InstanceNotFoundException
/*     */   {
/* 166 */     return getMBeanServer().getObjectInstance(objectName);
/*     */   }
/*     */   
/*     */   public Object instantiate(String className)
/*     */     throws ReflectionException, MBeanException
/*     */   {
/* 172 */     return getMBeanServer().instantiate(className);
/*     */   }
/*     */   
/*     */   public Object instantiate(String className, Object[] args, String[] parameters)
/*     */     throws ReflectionException, MBeanException
/*     */   {
/* 178 */     return getMBeanServer().instantiate(className, args, parameters);
/*     */   }
/*     */   
/*     */   public Object instantiate(String className, ObjectName loaderName)
/*     */     throws ReflectionException, MBeanException, InstanceNotFoundException
/*     */   {
/* 184 */     return getMBeanServer().instantiate(className, loaderName);
/*     */   }
/*     */   
/*     */   public Object instantiate(String className, ObjectName loaderName, Object[] args, String[] parameters)
/*     */     throws ReflectionException, MBeanException, InstanceNotFoundException
/*     */   {
/* 190 */     return getMBeanServer().instantiate(className, loaderName, args, parameters);
/*     */   }
/*     */   
/*     */   public Object invoke(ObjectName objectName, String methodName, Object[] args, String[] parameters)
/*     */     throws InstanceNotFoundException, MBeanException, ReflectionException
/*     */   {
/* 196 */     return getMBeanServer().invoke(objectName, methodName, args, parameters);
/*     */   }
/*     */   
/*     */   public boolean isInstanceOf(ObjectName objectName, String className)
/*     */     throws InstanceNotFoundException
/*     */   {
/* 202 */     return getMBeanServer().isInstanceOf(objectName, className);
/*     */   }
/*     */   
/*     */   public boolean isRegistered(ObjectName objectname)
/*     */   {
/* 207 */     return getMBeanServer().isRegistered(objectname);
/*     */   }
/*     */   
/*     */   public Set queryMBeans(ObjectName patternName, QueryExp filter)
/*     */   {
/* 212 */     return getMBeanServer().queryMBeans(patternName, filter);
/*     */   }
/*     */   
/*     */   public Set queryNames(ObjectName patternName, QueryExp filter)
/*     */   {
/* 217 */     return getMBeanServer().queryNames(patternName, filter);
/*     */   }
/*     */   
/*     */   public ObjectInstance registerMBean(Object mbean, ObjectName objectName)
/*     */     throws InstanceAlreadyExistsException, MBeanRegistrationException, NotCompliantMBeanException
/*     */   {
/* 223 */     return getMBeanServer().registerMBean(mbean, objectName);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName observed, NotificationListener listener)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException
/*     */   {
/* 229 */     getMBeanServer().removeNotificationListener(observed, listener);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName observed, ObjectName listener)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException
/*     */   {
/* 235 */     getMBeanServer().removeNotificationListener(observed, listener);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName observed, ObjectName listener, NotificationFilter filter, Object handback)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException
/*     */   {
/* 241 */     getMBeanServer().removeNotificationListener(observed, listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException
/*     */   {
/* 247 */     getMBeanServer().removeNotificationListener(observed, listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void setAttribute(ObjectName objectName, Attribute attribute)
/*     */     throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException
/*     */   {
/* 253 */     getMBeanServer().setAttribute(objectName, attribute);
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(ObjectName objectName, AttributeList attributes)
/*     */     throws InstanceNotFoundException, ReflectionException
/*     */   {
/* 259 */     return getMBeanServer().setAttributes(objectName, attributes);
/*     */   }
/*     */   
/*     */   public void unregisterMBean(ObjectName objectName)
/*     */     throws InstanceNotFoundException, MBeanRegistrationException
/*     */   {
/* 265 */     getMBeanServer().unregisterMBean(objectName);
/*     */   }
/*     */   
/*     */   public ClassLoader getClassLoaderFor(ObjectName mbeanName)
/*     */     throws InstanceNotFoundException
/*     */   {
/* 271 */     return getMBeanServer().getClassLoaderFor(mbeanName);
/*     */   }
/*     */   
/*     */   public ClassLoader getClassLoader(ObjectName loaderName)
/*     */     throws InstanceNotFoundException
/*     */   {
/* 277 */     return getMBeanServer().getClassLoader(loaderName);
/*     */   }
/*     */   
/*     */   public ClassLoaderRepository getClassLoaderRepository()
/*     */   {
/* 282 */     return getMBeanServer().getClassLoaderRepository();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/ChainedMBeanServer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */