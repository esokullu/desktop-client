/*     */ package mx4j.server;
/*     */ 
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MX4JMBeanMetaData
/*     */   implements MBeanMetaData
/*     */ {
/*     */   private Object mbean;
/*     */   private ClassLoader classloader;
/*     */   private ObjectInstance instance;
/*     */   private ObjectName name;
/*     */   private MBeanInfo info;
/*     */   private boolean dynamic;
/*     */   private boolean standard;
/*     */   private Class management;
/*     */   private MBeanInvoker invoker;
/*     */   
/*     */   public Object getMBean()
/*     */   {
/*  34 */     return this.mbean;
/*     */   }
/*     */   
/*     */   public void setMBean(Object mbean)
/*     */   {
/*  39 */     this.mbean = mbean;
/*     */   }
/*     */   
/*     */   public ClassLoader getClassLoader()
/*     */   {
/*  44 */     return this.classloader;
/*     */   }
/*     */   
/*     */   public void setClassLoader(ClassLoader classloader)
/*     */   {
/*  49 */     this.classloader = classloader;
/*     */   }
/*     */   
/*     */   public ObjectName getObjectName()
/*     */   {
/*  54 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setObjectName(ObjectName name)
/*     */   {
/*  59 */     this.name = name;
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo()
/*     */   {
/*  64 */     return this.info;
/*     */   }
/*     */   
/*     */   public void setMBeanInfo(MBeanInfo info)
/*     */   {
/*  69 */     this.info = info;
/*     */   }
/*     */   
/*     */   public boolean isMBeanDynamic()
/*     */   {
/*  74 */     return this.dynamic;
/*     */   }
/*     */   
/*     */   public void setMBeanDynamic(boolean dynamic)
/*     */   {
/*  79 */     this.dynamic = dynamic;
/*     */   }
/*     */   
/*     */   public boolean isMBeanStandard()
/*     */   {
/*  84 */     return this.standard;
/*     */   }
/*     */   
/*     */   public void setMBeanStandard(boolean standard)
/*     */   {
/*  89 */     this.standard = standard;
/*     */   }
/*     */   
/*     */   public Class getMBeanInterface()
/*     */   {
/*  94 */     return this.management;
/*     */   }
/*     */   
/*     */   public void setMBeanInterface(Class management)
/*     */   {
/*  99 */     this.management = management;
/*     */   }
/*     */   
/*     */   public MBeanInvoker getMBeanInvoker()
/*     */   {
/* 104 */     return this.invoker;
/*     */   }
/*     */   
/*     */   public void setMBeanInvoker(MBeanInvoker invoker)
/*     */   {
/* 109 */     this.invoker = invoker;
/*     */   }
/*     */   
/*     */   public ObjectInstance getObjectInstance()
/*     */   {
/* 114 */     if (this.instance == null)
/*     */     {
/* 116 */       this.instance = new ObjectInstance(getObjectName(), getMBeanInfo().getClassName());
/* 117 */       return this.instance;
/*     */     }
/*     */     
/* 120 */     if (isMBeanDynamic())
/*     */     {
/* 122 */       String clsName = getMBeanInfo().getClassName();
/* 123 */       if (!this.instance.getClassName().equals(clsName)) { this.instance = new ObjectInstance(getObjectName(), clsName);
/*     */       }
/*     */     }
/* 126 */     return this.instance;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/MX4JMBeanMetaData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */