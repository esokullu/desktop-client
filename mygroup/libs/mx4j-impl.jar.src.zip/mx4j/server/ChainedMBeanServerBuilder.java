/*    */ package mx4j.server;
/*    */ 
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.MBeanServerBuilder;
/*    */ import javax.management.MBeanServerDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChainedMBeanServerBuilder
/*    */   extends MBeanServerBuilder
/*    */ {
/*    */   private final MBeanServerBuilder builder;
/*    */   
/*    */   public ChainedMBeanServerBuilder(MBeanServerBuilder builder)
/*    */   {
/* 70 */     if (builder == null) throw new IllegalArgumentException();
/* 71 */     this.builder = builder;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MBeanServerDelegate newMBeanServerDelegate()
/*    */   {
/* 81 */     return getMBeanServerBuilder().newMBeanServerDelegate();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MBeanServer newMBeanServer(String defaultDomain, MBeanServer outer, MBeanServerDelegate delegate)
/*    */   {
/* 91 */     return getMBeanServerBuilder().newMBeanServer(defaultDomain, outer, delegate);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected MBeanServerBuilder getMBeanServerBuilder()
/*    */   {
/* 99 */     return this.builder;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/ChainedMBeanServerBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */