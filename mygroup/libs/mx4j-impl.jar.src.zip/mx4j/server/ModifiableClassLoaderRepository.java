package mx4j.server;

import javax.management.loading.ClassLoaderRepository;

public abstract class ModifiableClassLoaderRepository
  implements ClassLoaderRepository
{
  protected abstract void addClassLoader(ClassLoader paramClassLoader);
  
  protected abstract void removeClassLoader(ClassLoader paramClassLoader);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/ModifiableClassLoaderRepository.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */