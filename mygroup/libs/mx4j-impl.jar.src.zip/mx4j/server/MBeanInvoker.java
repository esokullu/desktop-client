package mx4j.server;

import javax.management.Attribute;
import javax.management.AttributeNotFoundException;
import javax.management.InvalidAttributeValueException;
import javax.management.MBeanException;
import javax.management.ReflectionException;

public abstract interface MBeanInvoker
{
  public abstract Object invoke(MBeanMetaData paramMBeanMetaData, String paramString, String[] paramArrayOfString, Object[] paramArrayOfObject)
    throws MBeanException, ReflectionException;
  
  public abstract Object getAttribute(MBeanMetaData paramMBeanMetaData, String paramString)
    throws MBeanException, AttributeNotFoundException, ReflectionException;
  
  public abstract void setAttribute(MBeanMetaData paramMBeanMetaData, Attribute paramAttribute)
    throws MBeanException, AttributeNotFoundException, InvalidAttributeValueException, ReflectionException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/MBeanInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */