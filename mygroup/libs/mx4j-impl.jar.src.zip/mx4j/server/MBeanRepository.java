package mx4j.server;

import java.util.Iterator;
import javax.management.ObjectName;

public abstract interface MBeanRepository
  extends Cloneable
{
  public abstract MBeanMetaData get(ObjectName paramObjectName);
  
  public abstract void put(ObjectName paramObjectName, MBeanMetaData paramMBeanMetaData);
  
  public abstract void remove(ObjectName paramObjectName);
  
  public abstract int size();
  
  public abstract Iterator iterator();
  
  public abstract Object clone();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/MBeanRepository.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */