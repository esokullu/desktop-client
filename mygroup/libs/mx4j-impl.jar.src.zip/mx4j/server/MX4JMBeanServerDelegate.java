/*    */ package mx4j.server;
/*    */ 
/*    */ import javax.management.MBeanServerDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MX4JMBeanServerDelegate
/*    */   extends MBeanServerDelegate
/*    */ {
/*    */   public String getImplementationName()
/*    */   {
/* 23 */     return "MX4J";
/*    */   }
/*    */   
/*    */   public String getImplementationVendor()
/*    */   {
/* 28 */     return "The MX4J Team";
/*    */   }
/*    */   
/*    */   public String getImplementationVersion()
/*    */   {
/* 33 */     return "2.1.0";
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/MX4JMBeanServerDelegate.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */