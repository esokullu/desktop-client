/*     */ package mx4j.server;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.ReflectionException;
/*     */ import mx4j.util.MethodTernaryTree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachingReflectionMBeanInvoker
/*     */   extends ReflectionMBeanInvoker
/*     */ {
/*     */   private final Map attributes;
/*     */   private final Map attributeNames;
/*     */   private final MethodTernaryTree operations;
/*     */   private final MethodTernaryTree methods;
/*     */   
/*     */   public CachingReflectionMBeanInvoker()
/*     */   {
/*  28 */     this.attributes = new HashMap();
/*  29 */     this.attributeNames = new HashMap();
/*  30 */     this.operations = new MethodTernaryTree();
/*  31 */     this.methods = new MethodTernaryTree();
/*     */   }
/*     */   
/*     */   protected MBeanOperationInfo getStandardOperationInfo(MBeanMetaData metadata, String method, String[] signature) {
/*  35 */     MBeanOperationInfo oper = null;
/*  36 */     synchronized (this.operations)
/*     */     {
/*  38 */       oper = (MBeanOperationInfo)this.operations.get(method, signature);
/*     */     }
/*  40 */     if (oper != null) { return oper;
/*     */     }
/*     */     
/*  43 */     MBeanOperationInfo info = super.getStandardOperationInfo(metadata, method, signature);
/*  44 */     if (info != null)
/*     */     {
/*  46 */       synchronized (this.operations)
/*     */       {
/*  48 */         this.operations.put(method, signature, oper);
/*     */       }
/*     */     }
/*  51 */     return info;
/*     */   }
/*     */   
/*     */   protected MBeanAttributeInfo getStandardAttributeInfo(MBeanMetaData metadata, String attribute, boolean forWrite)
/*     */   {
/*  56 */     MBeanAttributeInfo attr = null;
/*  57 */     synchronized (this.attributes)
/*     */     {
/*  59 */       attr = (MBeanAttributeInfo)this.attributes.get(attribute);
/*     */     }
/*     */     
/*  62 */     if (attr == null)
/*     */     {
/*  64 */       attr = super.getStandardAttributeInfo(metadata, attribute, forWrite);
/*  65 */       if (attr == null) { return null;
/*     */       }
/*  67 */       synchronized (this.attributes)
/*     */       {
/*  69 */         this.attributes.put(attribute, attr);
/*     */       }
/*     */     }
/*     */     
/*  73 */     if ((forWrite) && (attr.isWritable())) return attr;
/*  74 */     if ((!forWrite) && (attr.isReadable())) { return attr;
/*     */     }
/*  76 */     return null;
/*     */   }
/*     */   
/*     */   protected String getMethodForAttribute(MBeanAttributeInfo attribute, boolean getter)
/*     */   {
/*  81 */     AttributeName attributeName = null;
/*  82 */     String name = attribute.getName();
/*  83 */     synchronized (this.attributeNames)
/*     */     {
/*  85 */       attributeName = (AttributeName)this.attributeNames.get(name);
/*     */     }
/*  87 */     if (attributeName == null)
/*     */     {
/*  89 */       attributeName = new AttributeName(super.getMethodForAttribute(attribute, true), super.getMethodForAttribute(attribute, false));
/*  90 */       synchronized (this.attributeNames)
/*     */       {
/*  92 */         this.attributeNames.put(name, attributeName);
/*     */       }
/*     */     }
/*     */     
/*  96 */     if (getter) return attributeName.getter;
/*  97 */     return attributeName.setter;
/*     */   }
/*     */   
/*     */   protected Method getStandardManagementMethod(MBeanMetaData metadata, String name, String[] signature) throws ReflectionException
/*     */   {
/* 102 */     Method method = null;
/* 103 */     synchronized (this.methods)
/*     */     {
/* 105 */       method = (Method)this.methods.get(name, signature);
/*     */     }
/* 107 */     if (method != null) { return method;
/*     */     }
/*     */     
/* 110 */     method = super.getStandardManagementMethod(metadata, name, signature);
/* 111 */     synchronized (this.methods)
/*     */     {
/* 113 */       this.methods.put(name, signature, method);
/*     */     }
/* 115 */     return method;
/*     */   }
/*     */   
/*     */   private static class AttributeName
/*     */   {
/*     */     private final String getter;
/*     */     private final String setter;
/*     */     
/*     */     public AttributeName(String getter, String setter)
/*     */     {
/* 125 */       this.getter = getter;
/* 126 */       this.setter = setter;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/CachingReflectionMBeanInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */