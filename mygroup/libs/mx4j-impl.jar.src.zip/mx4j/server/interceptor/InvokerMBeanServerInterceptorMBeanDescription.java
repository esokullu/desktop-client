/*    */ package mx4j.server.interceptor;
/*    */ 
/*    */ import mx4j.MBeanDescriptionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvokerMBeanServerInterceptorMBeanDescription
/*    */   extends MBeanDescriptionAdapter
/*    */ {
/*    */   public String getMBeanDescription()
/*    */   {
/* 22 */     return "The interceptor that invokes on the MBean instance";
/*    */   }
/*    */   
/*    */   public String getAttributeDescription(String attribute)
/*    */   {
/* 27 */     if (attribute.equals("Type"))
/*    */     {
/* 29 */       return "The type of this interceptor";
/*    */     }
/* 31 */     if (attribute.equals("Enabled"))
/*    */     {
/* 33 */       return "This interceptor is always enabled and cannot be disabled";
/*    */     }
/* 35 */     return super.getAttributeDescription(attribute);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/interceptor/InvokerMBeanServerInterceptorMBeanDescription.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */