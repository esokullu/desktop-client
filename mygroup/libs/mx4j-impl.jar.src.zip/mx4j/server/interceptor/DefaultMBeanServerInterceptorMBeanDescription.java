/*    */ package mx4j.server.interceptor;
/*    */ 
/*    */ import mx4j.MBeanDescriptionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultMBeanServerInterceptorMBeanDescription
/*    */   extends MBeanDescriptionAdapter
/*    */ {
/*    */   public String getMBeanDescription()
/*    */   {
/* 22 */     return "MBeanServer interceptor";
/*    */   }
/*    */   
/*    */   public String getAttributeDescription(String attribute)
/*    */   {
/* 27 */     if (attribute.equals("Enabled"))
/*    */     {
/* 29 */       return "The enable status of this interceptor";
/*    */     }
/* 31 */     if (attribute.equals("Type"))
/*    */     {
/* 33 */       return "The type of this interceptor";
/*    */     }
/* 35 */     return super.getAttributeDescription(attribute);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/interceptor/DefaultMBeanServerInterceptorMBeanDescription.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */