/*     */ package mx4j.server.interceptor;
/*     */ 
/*     */ import java.security.AccessControlException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.ArrayList;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanPermission;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.MBeanTrustPermission;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ReflectionException;
/*     */ import mx4j.server.MBeanMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurityMBeanServerInterceptor
/*     */   extends DefaultMBeanServerInterceptor
/*     */   implements SecurityMBeanServerInterceptorMBean
/*     */ {
/*     */   public String getType()
/*     */   {
/*  43 */     return "security";
/*     */   }
/*     */   
/*     */   public boolean isEnabled()
/*     */   {
/*  48 */     return true;
/*     */   }
/*     */   
/*     */   public void addNotificationListener(MBeanMetaData metadata, NotificationListener listener, NotificationFilter filter, Object handback)
/*     */   {
/*  53 */     checkPermission(metadata.getMBeanInfo().getClassName(), null, metadata.getObjectName(), "addNotificationListener");
/*  54 */     super.addNotificationListener(metadata, listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(MBeanMetaData metadata, NotificationListener listener) throws ListenerNotFoundException
/*     */   {
/*  59 */     checkPermission(metadata.getMBeanInfo().getClassName(), null, metadata.getObjectName(), "removeNotificationListener");
/*  60 */     super.removeNotificationListener(metadata, listener);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(MBeanMetaData metadata, NotificationListener listener, NotificationFilter filter, Object handback) throws ListenerNotFoundException
/*     */   {
/*  65 */     checkPermission(metadata.getMBeanInfo().getClassName(), null, metadata.getObjectName(), "removeNotificationListener");
/*  66 */     super.removeNotificationListener(metadata, listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void instantiate(MBeanMetaData metadata, String className, String[] params, Object[] args) throws ReflectionException, MBeanException
/*     */   {
/*  71 */     checkPermission(className, null, metadata.getObjectName(), "instantiate");
/*  72 */     super.instantiate(metadata, className, params, args);
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo(MBeanMetaData metadata)
/*     */   {
/*  77 */     checkPermission(metadata.getMBeanInfo().getClassName(), null, metadata.getObjectName(), "getMBeanInfo");
/*  78 */     return super.getMBeanInfo(metadata);
/*     */   }
/*     */   
/*     */   public Object invoke(MBeanMetaData metadata, String method, String[] params, Object[] args) throws MBeanException, ReflectionException
/*     */   {
/*  83 */     checkPermission(metadata.getMBeanInfo().getClassName(), method, metadata.getObjectName(), "invoke");
/*  84 */     return super.invoke(metadata, method, params, args);
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(MBeanMetaData metadata, String[] attributes)
/*     */   {
/*  89 */     Object[] secured = filterAttributes(metadata.getMBeanInfo().getClassName(), metadata.getObjectName(), attributes, true);
/*  90 */     String[] array = new String[secured.length];
/*  91 */     for (int i = 0; i < array.length; i++) array[i] = ((String)secured[i]);
/*  92 */     return super.getAttributes(metadata, array);
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(MBeanMetaData metadata, AttributeList attributes)
/*     */   {
/*  97 */     Object[] secured = filterAttributes(metadata.getMBeanInfo().getClassName(), metadata.getObjectName(), attributes.toArray(), false);
/*  98 */     AttributeList list = new AttributeList();
/*  99 */     for (int i = 0; i < secured.length; i++) list.add(secured[i]);
/* 100 */     return super.setAttributes(metadata, list);
/*     */   }
/*     */   
/*     */   public Object getAttribute(MBeanMetaData metadata, String attribute) throws MBeanException, AttributeNotFoundException, ReflectionException
/*     */   {
/* 105 */     checkPermission(metadata.getMBeanInfo().getClassName(), attribute, metadata.getObjectName(), "getAttribute");
/* 106 */     return super.getAttribute(metadata, attribute);
/*     */   }
/*     */   
/*     */   public void setAttribute(MBeanMetaData metadata, Attribute attribute) throws MBeanException, AttributeNotFoundException, InvalidAttributeValueException, ReflectionException
/*     */   {
/* 111 */     checkPermission(metadata.getMBeanInfo().getClassName(), attribute.getName(), metadata.getObjectName(), "setAttribute");
/* 112 */     super.setAttribute(metadata, attribute);
/*     */   }
/*     */   
/*     */   public void registration(MBeanMetaData metadata, int operation) throws MBeanRegistrationException
/*     */   {
/* 117 */     switch (operation)
/*     */     {
/*     */     case 1: 
/* 120 */       checkPermission(metadata.getMBeanInfo().getClassName(), null, metadata.getObjectName(), "registerMBean");
/* 121 */       checkTrustRegistration(metadata.getMBean().getClass());
/* 122 */       break;
/*     */     
/*     */     case 2: 
/* 125 */       checkPermission(metadata.getMBeanInfo().getClassName(), null, metadata.getObjectName(), "registerMBean");
/* 126 */       break;
/*     */     case 4: 
/* 128 */       checkPermission(metadata.getMBeanInfo().getClassName(), null, metadata.getObjectName(), "unregisterMBean");
/* 129 */       break;
/*     */     }
/*     */     
/*     */     
/* 133 */     super.registration(metadata, operation);
/*     */   }
/*     */   
/*     */   private void checkPermission(String className, String methodName, ObjectName objectname, String action)
/*     */   {
/* 138 */     SecurityManager sm = System.getSecurityManager();
/* 139 */     if (sm != null)
/*     */     {
/* 141 */       sm.checkPermission(new MBeanPermission(className, methodName, objectname, action));
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkTrustRegistration(Class cls)
/*     */   {
/* 147 */     SecurityManager sm = System.getSecurityManager();
/* 148 */     if (sm != null)
/*     */     {
/* 150 */       ProtectionDomain domain = (ProtectionDomain)AccessController.doPrivileged(new PrivilegedAction() {
/*     */         private final Class val$cls;
/*     */         
/*     */         public Object run() {
/* 154 */           return this.val$cls.getProtectionDomain();
/*     */         }
/*     */         
/* 157 */       });
/* 158 */       MBeanTrustPermission permission = new MBeanTrustPermission("register");
/* 159 */       if (!domain.implies(permission))
/*     */       {
/* 161 */         throw new AccessControlException("Access denied " + permission + ": MBean class " + cls.getName() + " is not trusted for registration");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Object[] filterAttributes(String className, ObjectName objectName, Object[] attributes, boolean isGet)
/*     */   {
/* 168 */     SecurityManager sm = System.getSecurityManager();
/* 169 */     if (sm == null) { return attributes;
/*     */     }
/* 171 */     ArrayList list = new ArrayList();
/*     */     
/* 173 */     for (int i = 0; i < attributes.length; i++)
/*     */     {
/* 175 */       Object attribute = attributes[i];
/* 176 */       String name = isGet ? (String)attribute : ((Attribute)attribute).getName();
/*     */       
/*     */       try
/*     */       {
/* 180 */         checkPermission(className, name, objectName, isGet ? "getAttribute" : "setAttribute");
/* 181 */         list.add(attribute);
/*     */       }
/*     */       catch (SecurityException ignore) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 189 */     return list.toArray();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/interceptor/SecurityMBeanServerInterceptor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */