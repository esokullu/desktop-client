/*     */ package mx4j.server.interceptor;
/*     */ 
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.server.MBeanMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NotificationListenerMBeanServerInterceptor
/*     */   extends DefaultMBeanServerInterceptor
/*     */ {
/*     */   private static class ListenerWrapper
/*     */     implements NotificationListener
/*     */   {
/*     */     private final NotificationListener listener;
/*     */     private final ObjectName objectName;
/*     */     
/*     */     ListenerWrapper(NotificationListener x0, ObjectName x1, NotificationListenerMBeanServerInterceptor.1 x2)
/*     */     {
/*  27 */       this(x0, x1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private ListenerWrapper(NotificationListener listener, ObjectName name)
/*     */     {
/*  34 */       this.listener = listener;
/*  35 */       this.objectName = name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void handleNotification(Notification notification, Object handback)
/*     */     {
/*  46 */       Object src = notification.getSource();
/*  47 */       if (!(src instanceof ObjectName))
/*     */       {
/*     */ 
/*     */ 
/*  51 */         notification.setSource(this.objectName);
/*     */       }
/*     */       
/*     */ 
/*  55 */       NotificationListener listener = getTargetListener();
/*  56 */       listener.handleNotification(notification, handback);
/*     */     }
/*     */     
/*     */     private NotificationListener getTargetListener()
/*     */     {
/*  61 */       return this.listener;
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/*  66 */       return getTargetListener().hashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/*  71 */       if (obj == null) return false;
/*  72 */       if (obj == this) { return true;
/*     */       }
/*     */       try
/*     */       {
/*  76 */         ListenerWrapper other = (ListenerWrapper)obj;
/*  77 */         return getTargetListener().equals(other.getTargetListener());
/*     */       }
/*     */       catch (ClassCastException ignored) {}
/*     */       
/*     */ 
/*  82 */       return false;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/*  87 */       return getTargetListener().toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getType()
/*     */   {
/*  93 */     return "notificationlistener";
/*     */   }
/*     */   
/*     */   public void addNotificationListener(MBeanMetaData metadata, NotificationListener listener, NotificationFilter filter, Object handback)
/*     */   {
/*  98 */     if (isEnabled())
/*     */     {
/* 100 */       ListenerWrapper wrapper = new ListenerWrapper(listener, metadata.getObjectName(), null);
/* 101 */       super.addNotificationListener(metadata, wrapper, filter, handback);
/*     */     }
/*     */     else
/*     */     {
/* 105 */       super.addNotificationListener(metadata, listener, filter, handback);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(MBeanMetaData metadata, NotificationListener listener) throws ListenerNotFoundException
/*     */   {
/* 111 */     if (isEnabled())
/*     */     {
/* 113 */       ListenerWrapper wrapper = new ListenerWrapper(listener, metadata.getObjectName(), null);
/* 114 */       super.removeNotificationListener(metadata, wrapper);
/*     */     }
/*     */     else
/*     */     {
/* 118 */       super.removeNotificationListener(metadata, listener);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(MBeanMetaData metadata, NotificationListener listener, NotificationFilter filter, Object handback) throws ListenerNotFoundException
/*     */   {
/* 124 */     if (isEnabled())
/*     */     {
/* 126 */       ListenerWrapper wrapper = new ListenerWrapper(listener, metadata.getObjectName(), null);
/* 127 */       super.removeNotificationListener(metadata, wrapper, filter, handback);
/*     */     }
/*     */     else
/*     */     {
/* 131 */       super.removeNotificationListener(metadata, listener, filter, handback);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/interceptor/NotificationListenerMBeanServerInterceptor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */