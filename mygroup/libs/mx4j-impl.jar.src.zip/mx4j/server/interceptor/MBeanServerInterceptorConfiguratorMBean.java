package mx4j.server.interceptor;

import javax.management.MBeanException;
import javax.management.ObjectName;

public abstract interface MBeanServerInterceptorConfiguratorMBean
{
  public abstract void addInterceptor(MBeanServerInterceptor paramMBeanServerInterceptor);
  
  public abstract void registerInterceptor(MBeanServerInterceptor paramMBeanServerInterceptor, ObjectName paramObjectName)
    throws MBeanException;
  
  public abstract void clearInterceptors();
  
  public abstract void start();
  
  public abstract void stop();
  
  public abstract boolean isRunning();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/interceptor/MBeanServerInterceptorConfiguratorMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */