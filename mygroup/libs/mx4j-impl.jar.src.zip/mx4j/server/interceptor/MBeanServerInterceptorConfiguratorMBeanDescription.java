/*     */ package mx4j.server.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import mx4j.MBeanDescriptionAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanServerInterceptorConfiguratorMBeanDescription
/*     */   extends MBeanDescriptionAdapter
/*     */ {
/*     */   public String getMBeanDescription()
/*     */   {
/*  25 */     return "Configurator for MBeanServer to MBean interceptors";
/*     */   }
/*     */   
/*     */   public String getConstructorDescription(Constructor ctor)
/*     */   {
/*  30 */     if (ctor.toString().equals("public mx4j.server.interceptor.MBeanServerInterceptorConfigurator(javax.management.MBeanServer)"))
/*     */     {
/*  32 */       return "Creates a new instance of MBeanServer to MBean interceptor configurator";
/*     */     }
/*  34 */     return super.getConstructorDescription(ctor);
/*     */   }
/*     */   
/*     */   public String getConstructorParameterName(Constructor ctor, int index)
/*     */   {
/*  39 */     if (ctor.toString().equals("public mx4j.server.interceptor.MBeanServerInterceptorConfigurator(javax.management.MBeanServer)"))
/*     */     {
/*  41 */       switch (index)
/*     */       {
/*     */       case 0: 
/*  44 */         return "server";
/*     */       }
/*     */     }
/*  47 */     return super.getConstructorParameterName(ctor, index);
/*     */   }
/*     */   
/*     */   public String getConstructorParameterDescription(Constructor ctor, int index)
/*     */   {
/*  52 */     if (ctor.toString().equals("public mx4j.server.interceptor.MBeanServerInterceptorConfigurator(javax.management.MBeanServer)"))
/*     */     {
/*  54 */       switch (index)
/*     */       {
/*     */       case 0: 
/*  57 */         return "The MBeanServer that uses this configurator";
/*     */       }
/*     */     }
/*  60 */     return super.getConstructorParameterDescription(ctor, index);
/*     */   }
/*     */   
/*     */   public String getAttributeDescription(String attribute)
/*     */   {
/*  65 */     if (attribute.equals("Running"))
/*     */     {
/*  67 */       return "The running status of the configurator";
/*     */     }
/*  69 */     return super.getAttributeDescription(attribute);
/*     */   }
/*     */   
/*     */   public String getOperationDescription(Method operation)
/*     */   {
/*  74 */     String name = operation.getName();
/*  75 */     if (name.equals("addInterceptor"))
/*     */     {
/*  77 */       return "Appends an interceptor to the interceptor chain";
/*     */     }
/*  79 */     if (name.equals("registerInterceptor"))
/*     */     {
/*  81 */       return "Appends an MBean interceptor to the interceptor chain and registers it";
/*     */     }
/*  83 */     if (name.equals("clearInterceptors"))
/*     */     {
/*  85 */       return "Removes all the interceptors added via addInterceptor(MBeanServerInterceptor interceptor)";
/*     */     }
/*  87 */     if (name.equals("start"))
/*     */     {
/*  89 */       return "Starts the configurator so that the MBeanServer can accept incoming calls";
/*     */     }
/*  91 */     if (name.equals("stop"))
/*     */     {
/*  93 */       return "Stops the configurator so that the MBeanServer cannot accept incoming calls";
/*     */     }
/*  95 */     return super.getOperationDescription(operation);
/*     */   }
/*     */   
/*     */   public String getOperationParameterName(Method method, int index)
/*     */   {
/* 100 */     String name = method.getName();
/* 101 */     if (name.equals("addInterceptor"))
/*     */     {
/* 103 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 106 */         return "interceptor";
/*     */       }
/*     */     }
/* 109 */     if (name.equals("registerInterceptor"))
/*     */     {
/* 111 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 114 */         return "interceptor";
/*     */       case 1: 
/* 116 */         return "name";
/*     */       }
/*     */     }
/* 119 */     return super.getOperationParameterName(method, index);
/*     */   }
/*     */   
/*     */   public String getOperationParameterDescription(Method method, int index)
/*     */   {
/* 124 */     String name = method.getName();
/* 125 */     if (name.equals("addInterceptor"))
/*     */     {
/* 127 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 130 */         return "The interceptor to be appended to the interceptor chain";
/*     */       }
/*     */     }
/* 133 */     if (name.equals("registerInterceptor"))
/*     */     {
/* 135 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 138 */         return "The interceptor to be appended to the interceptor chain";
/*     */       case 1: 
/* 140 */         return "The ObjectName under which register the interceptor";
/*     */       }
/*     */     }
/* 143 */     return super.getOperationParameterDescription(method, index);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/interceptor/MBeanServerInterceptorConfiguratorMBeanDescription.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */