package mx4j.server.interceptor;

public abstract interface DefaultMBeanServerInterceptorMBean
{
  public abstract boolean isEnabled();
  
  public abstract void setEnabled(boolean paramBoolean);
  
  public abstract String getType();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/interceptor/DefaultMBeanServerInterceptorMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */