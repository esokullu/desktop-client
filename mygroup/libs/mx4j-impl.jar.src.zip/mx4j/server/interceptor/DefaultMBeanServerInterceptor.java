/*     */ package mx4j.server.interceptor;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ReflectionException;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import mx4j.server.MBeanMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DefaultMBeanServerInterceptor
/*     */   implements MBeanServerInterceptor, DefaultMBeanServerInterceptorMBean
/*     */ {
/*  35 */   private boolean enabled = true;
/*     */   
/*     */   private String logCategory;
/*     */   private List chain;
/*     */   
/*     */   protected DefaultMBeanServerInterceptor()
/*     */   {
/*  42 */     this.logCategory = (getClass().getName() + "." + getType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEnabled()
/*     */   {
/*  52 */     return this.enabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnabled(boolean enabled)
/*     */   {
/*  62 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract String getType();
/*     */   
/*     */ 
/*     */   protected synchronized MBeanServerInterceptor getNext()
/*     */   {
/*  72 */     int index = this.chain.indexOf(this);
/*  73 */     MBeanServerInterceptor next = (MBeanServerInterceptor)this.chain.get(index + 1);
/*  74 */     next.setChain(this.chain);
/*  75 */     return next;
/*     */   }
/*     */   
/*     */   public synchronized void setChain(List chain)
/*     */   {
/*  80 */     this.chain = chain;
/*     */   }
/*     */   
/*     */   protected Logger getLogger()
/*     */   {
/*  85 */     return Log.getLogger(this.logCategory);
/*     */   }
/*     */   
/*     */   public void addNotificationListener(MBeanMetaData metadata, NotificationListener listener, NotificationFilter filter, Object handback)
/*     */   {
/*  90 */     getNext().addNotificationListener(metadata, listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(MBeanMetaData metadata, NotificationListener listener) throws ListenerNotFoundException
/*     */   {
/*  95 */     getNext().removeNotificationListener(metadata, listener);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(MBeanMetaData metadata, NotificationListener listener, NotificationFilter filter, Object handback) throws ListenerNotFoundException
/*     */   {
/* 100 */     getNext().removeNotificationListener(metadata, listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void instantiate(MBeanMetaData metadata, String className, String[] params, Object[] args) throws ReflectionException, MBeanException
/*     */   {
/* 105 */     getNext().instantiate(metadata, className, params, args);
/*     */   }
/*     */   
/*     */   public void registration(MBeanMetaData metadata, int operation) throws MBeanRegistrationException
/*     */   {
/* 110 */     getNext().registration(metadata, operation);
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo(MBeanMetaData metadata)
/*     */   {
/* 115 */     return getNext().getMBeanInfo(metadata);
/*     */   }
/*     */   
/*     */   public Object invoke(MBeanMetaData metadata, String method, String[] params, Object[] args) throws MBeanException, ReflectionException
/*     */   {
/* 120 */     return getNext().invoke(metadata, method, params, args);
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(MBeanMetaData metadata, String[] attributes)
/*     */   {
/* 125 */     return getNext().getAttributes(metadata, attributes);
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(MBeanMetaData metadata, AttributeList attributes)
/*     */   {
/* 130 */     return getNext().setAttributes(metadata, attributes);
/*     */   }
/*     */   
/*     */   public Object getAttribute(MBeanMetaData metadata, String attribute) throws MBeanException, AttributeNotFoundException, ReflectionException
/*     */   {
/* 135 */     return getNext().getAttribute(metadata, attribute);
/*     */   }
/*     */   
/*     */   public void setAttribute(MBeanMetaData metadata, Attribute attribute) throws MBeanException, AttributeNotFoundException, InvalidAttributeValueException, ReflectionException
/*     */   {
/* 140 */     getNext().setAttribute(metadata, attribute);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/interceptor/DefaultMBeanServerInterceptor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */