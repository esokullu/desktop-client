/*     */ package mx4j.server.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.DynamicMBean;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.JMRuntimeException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanRegistration;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.NotificationBroadcaster;
/*     */ import javax.management.NotificationEmitter;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.RuntimeErrorException;
/*     */ import javax.management.RuntimeMBeanException;
/*     */ import mx4j.ImplementationException;
/*     */ import mx4j.log.Logger;
/*     */ import mx4j.server.MBeanInvoker;
/*     */ import mx4j.server.MBeanMetaData;
/*     */ import mx4j.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InvokerMBeanServerInterceptor
/*     */   extends DefaultMBeanServerInterceptor
/*     */   implements InvokerMBeanServerInterceptorMBean
/*     */ {
/*     */   private MBeanServer outerServer;
/*     */   
/*     */   public InvokerMBeanServerInterceptor(MBeanServer outerServer)
/*     */   {
/*  58 */     this.outerServer = outerServer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getType()
/*     */   {
/*  66 */     return "invoker";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEnabled()
/*     */   {
/*  74 */     return true;
/*     */   }
/*     */   
/*     */   public void addNotificationListener(MBeanMetaData metadata, NotificationListener listener, NotificationFilter filter, Object handback)
/*     */   {
/*  79 */     ((NotificationBroadcaster)metadata.getMBean()).addNotificationListener(listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(MBeanMetaData metadata, NotificationListener listener) throws ListenerNotFoundException
/*     */   {
/*  84 */     ((NotificationBroadcaster)metadata.getMBean()).removeNotificationListener(listener);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(MBeanMetaData metadata, NotificationListener listener, NotificationFilter filter, Object handback)
/*     */     throws ListenerNotFoundException
/*     */   {
/*  90 */     ((NotificationEmitter)metadata.getMBean()).removeNotificationListener(listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void instantiate(MBeanMetaData metadata, String className, String[] params, Object[] args) throws ReflectionException, MBeanException
/*     */   {
/*     */     try
/*     */     {
/*  97 */       ClassLoader loader = metadata.getClassLoader();
/*  98 */       if (loader == null) loader = Thread.currentThread().getContextClassLoader();
/*  99 */       Class cls = loader.loadClass(className);
/*     */       
/* 101 */       Class[] signature = Utils.loadClasses(loader, params);
/*     */       
/* 103 */       Constructor ctor = cls.getConstructor(signature);
/*     */       
/* 105 */       metadata.setMBean(ctor.newInstance(args));
/*     */     }
/*     */     catch (ClassNotFoundException x)
/*     */     {
/* 109 */       throw new ReflectionException(x);
/*     */     }
/*     */     catch (NoSuchMethodException x)
/*     */     {
/* 113 */       throw new ReflectionException(x);
/*     */     }
/*     */     catch (InstantiationException x)
/*     */     {
/* 117 */       throw new ReflectionException(x);
/*     */     }
/*     */     catch (IllegalAccessException x)
/*     */     {
/* 121 */       throw new ReflectionException(x);
/*     */     }
/*     */     catch (IllegalArgumentException x)
/*     */     {
/* 125 */       throw new ReflectionException(x);
/*     */     }
/*     */     catch (InvocationTargetException x)
/*     */     {
/* 129 */       Throwable t = x.getTargetException();
/* 130 */       if ((t instanceof Error))
/*     */       {
/* 132 */         throw new RuntimeErrorException((Error)t);
/*     */       }
/* 134 */       if ((t instanceof RuntimeException))
/*     */       {
/* 136 */         throw new RuntimeMBeanException((RuntimeException)t);
/*     */       }
/*     */       
/*     */ 
/* 140 */       throw new MBeanException((Exception)t);
/*     */     }
/*     */   }
/*     */   
/*     */   public void registration(MBeanMetaData metadata, int operation)
/*     */     throws MBeanRegistrationException
/*     */   {
/* 147 */     Object mbean = metadata.getMBean();
/* 148 */     if (!(mbean instanceof MBeanRegistration)) { return;
/*     */     }
/* 150 */     MBeanRegistration registrable = (MBeanRegistration)mbean;
/*     */     
/*     */     try
/*     */     {
/* 154 */       switch (operation)
/*     */       {
/*     */       case 1: 
/* 157 */         ObjectName objName = registrable.preRegister(this.outerServer, metadata.getObjectName());
/* 158 */         metadata.setObjectName(objName);
/* 159 */         break;
/*     */       case 2: 
/* 161 */         registrable.postRegister(Boolean.TRUE);
/* 162 */         break;
/*     */       case 3: 
/* 164 */         registrable.postRegister(Boolean.FALSE);
/* 165 */         break;
/*     */       case 4: 
/* 167 */         registrable.preDeregister();
/* 168 */         break;
/*     */       case 5: 
/* 170 */         registrable.postDeregister();
/* 171 */         break;
/*     */       default: 
/* 173 */         throw new ImplementationException();
/*     */       }
/*     */     }
/*     */     catch (RuntimeException x)
/*     */     {
/* 178 */       throw new RuntimeMBeanException(x);
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/* 182 */       if ((x instanceof MBeanRegistrationException))
/*     */       {
/* 184 */         throw ((MBeanRegistrationException)x);
/*     */       }
/* 186 */       throw new MBeanRegistrationException(x);
/*     */     }
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo(MBeanMetaData metadata)
/*     */   {
/* 192 */     if (metadata.isMBeanDynamic())
/*     */     {
/*     */ 
/* 195 */       MBeanInfo info = null;
/*     */       try
/*     */       {
/* 198 */         info = ((DynamicMBean)metadata.getMBean()).getMBeanInfo();
/*     */       }
/*     */       catch (RuntimeException x)
/*     */       {
/* 202 */         throw new RuntimeMBeanException(x);
/*     */       }
/* 204 */       if (info == null) return null;
/* 205 */       metadata.setMBeanInfo(info);
/*     */     }
/*     */     
/* 208 */     return (MBeanInfo)metadata.getMBeanInfo().clone();
/*     */   }
/*     */   
/*     */   public Object invoke(MBeanMetaData metadata, String method, String[] params, Object[] args) throws MBeanException, ReflectionException
/*     */   {
/* 213 */     if (metadata.isMBeanDynamic())
/*     */     {
/*     */       try
/*     */       {
/* 217 */         return ((DynamicMBean)metadata.getMBean()).invoke(method, args, params);
/*     */       }
/*     */       catch (JMRuntimeException x)
/*     */       {
/* 221 */         throw x;
/*     */       }
/*     */       catch (RuntimeException x)
/*     */       {
/* 225 */         throw new RuntimeMBeanException(x);
/*     */       }
/*     */       catch (Error x)
/*     */       {
/* 229 */         throw new RuntimeErrorException(x);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 234 */     return metadata.getMBeanInvoker().invoke(metadata, method, params, args);
/*     */   }
/*     */   
/*     */   public Object getAttribute(MBeanMetaData metadata, String attribute)
/*     */     throws MBeanException, AttributeNotFoundException, ReflectionException
/*     */   {
/* 240 */     if (metadata.isMBeanDynamic())
/*     */     {
/*     */       try
/*     */       {
/* 244 */         return ((DynamicMBean)metadata.getMBean()).getAttribute(attribute);
/*     */       }
/*     */       catch (JMRuntimeException x)
/*     */       {
/* 248 */         throw x;
/*     */       }
/*     */       catch (RuntimeException x)
/*     */       {
/* 252 */         throw new RuntimeMBeanException(x);
/*     */       }
/*     */       catch (Error x)
/*     */       {
/* 256 */         throw new RuntimeErrorException(x);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 261 */     return metadata.getMBeanInvoker().getAttribute(metadata, attribute);
/*     */   }
/*     */   
/*     */   public void setAttribute(MBeanMetaData metadata, Attribute attribute)
/*     */     throws MBeanException, AttributeNotFoundException, InvalidAttributeValueException, ReflectionException
/*     */   {
/* 267 */     if (metadata.isMBeanDynamic())
/*     */     {
/*     */       try
/*     */       {
/* 271 */         ((DynamicMBean)metadata.getMBean()).setAttribute(attribute);
/*     */       }
/*     */       catch (JMRuntimeException x)
/*     */       {
/* 275 */         throw x;
/*     */       }
/*     */       catch (RuntimeException x)
/*     */       {
/* 279 */         throw new RuntimeMBeanException(x);
/*     */       }
/*     */       catch (Error x)
/*     */       {
/* 283 */         throw new RuntimeErrorException(x);
/*     */       }
/*     */       
/*     */     }
/*     */     else {
/* 288 */       metadata.getMBeanInvoker().setAttribute(metadata, attribute);
/*     */     }
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(MBeanMetaData metadata, String[] attributes)
/*     */   {
/* 294 */     if (metadata.isMBeanDynamic())
/*     */     {
/*     */       try
/*     */       {
/* 298 */         return ((DynamicMBean)metadata.getMBean()).getAttributes(attributes);
/*     */       }
/*     */       catch (JMRuntimeException x)
/*     */       {
/* 302 */         throw x;
/*     */       }
/*     */       catch (RuntimeException x)
/*     */       {
/* 306 */         throw new RuntimeMBeanException(x);
/*     */       }
/*     */       catch (Error x)
/*     */       {
/* 310 */         throw new RuntimeErrorException(x);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 315 */     AttributeList list = new AttributeList();
/* 316 */     for (int i = 0; i < attributes.length; i++)
/*     */     {
/* 318 */       String name = attributes[i];
/*     */       try
/*     */       {
/* 321 */         Object value = getAttribute(metadata, name);
/* 322 */         Attribute attr = new Attribute(name, value);
/* 323 */         list.add(attr);
/*     */       }
/*     */       catch (Exception ignored)
/*     */       {
/* 327 */         Logger logger = getLogger();
/* 328 */         if (logger.isEnabledFor(10)) logger.debug("Exception caught from getAttributes(), ignoring attribute " + name);
/*     */       }
/*     */     }
/* 331 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */   public AttributeList setAttributes(MBeanMetaData metadata, AttributeList attributes)
/*     */   {
/* 337 */     if (metadata.isMBeanDynamic())
/*     */     {
/*     */       try
/*     */       {
/* 341 */         return ((DynamicMBean)metadata.getMBean()).setAttributes(attributes);
/*     */       }
/*     */       catch (JMRuntimeException x)
/*     */       {
/* 345 */         throw x;
/*     */       }
/*     */       catch (RuntimeException x)
/*     */       {
/* 349 */         throw new RuntimeMBeanException(x);
/*     */       }
/*     */       catch (Error x)
/*     */       {
/* 353 */         throw new RuntimeErrorException(x);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 358 */     AttributeList list = new AttributeList();
/* 359 */     for (int i = 0; i < attributes.size(); i++)
/*     */     {
/* 361 */       Attribute attr = (Attribute)attributes.get(i);
/*     */       try
/*     */       {
/* 364 */         setAttribute(metadata, attr);
/* 365 */         list.add(attr);
/*     */       }
/*     */       catch (Exception ignored)
/*     */       {
/* 369 */         Logger logger = getLogger();
/* 370 */         if (logger.isEnabledFor(10)) logger.debug("Exception caught from setAttributes(), ignoring attribute " + attr, ignored);
/*     */       }
/*     */     }
/* 373 */     return list;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/interceptor/InvokerMBeanServerInterceptor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */