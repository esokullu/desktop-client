/*     */ package mx4j.server.interceptor;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.ImplementationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanServerInterceptorConfigurator
/*     */   implements MBeanServerInterceptorConfiguratorMBean
/*     */ {
/*     */   public static final String OBJECT_NAME = "JMImplementation:type=MBeanServerInterceptorConfigurator";
/*     */   private final MBeanServer server;
/*  28 */   private final ArrayList preInterceptors = new ArrayList();
/*  29 */   private final ArrayList postInterceptors = new ArrayList();
/*  30 */   private final ArrayList clientInterceptors = new ArrayList();
/*     */   
/*     */   private volatile boolean running;
/*     */   
/*     */   private boolean chainModified;
/*     */   
/*     */   private MBeanServerInterceptor head;
/*     */   
/*     */   public MBeanServerInterceptorConfigurator(MBeanServer server)
/*     */   {
/*  40 */     this.server = server;
/*  41 */     this.chainModified = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addInterceptor(MBeanServerInterceptor interceptor)
/*     */   {
/*  51 */     synchronized (this.clientInterceptors)
/*     */     {
/*  53 */       this.clientInterceptors.add(interceptor);
/*  54 */       this.chainModified = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerInterceptor(MBeanServerInterceptor interceptor, ObjectName name)
/*     */     throws MBeanException
/*     */   {
/*     */     try
/*     */     {
/*  68 */       this.server.registerMBean(interceptor, name);
/*  69 */       addInterceptor(interceptor);
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/*  73 */       throw new MBeanException(x, "Could not register interceptor with name " + name);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearInterceptors()
/*     */   {
/*  84 */     synchronized (this.clientInterceptors)
/*     */     {
/*  86 */       this.clientInterceptors.clear();
/*  87 */       this.chainModified = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPreInterceptor(MBeanServerInterceptor interceptor)
/*     */   {
/*  98 */     if (isRunning()) throw new ImplementationException();
/*  99 */     this.preInterceptors.add(interceptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPostInterceptor(MBeanServerInterceptor interceptor)
/*     */   {
/* 109 */     if (isRunning()) throw new ImplementationException();
/* 110 */     this.postInterceptors.add(interceptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MBeanServerInterceptor getHeadInterceptor()
/*     */   {
/* 119 */     if (!isRunning()) { return null;
/*     */     }
/* 121 */     if (this.chainModified) { setupChain();
/*     */     }
/* 123 */     return this.head;
/*     */   }
/*     */   
/*     */   private void setupChain()
/*     */   {
/* 128 */     this.chainModified = false;
/*     */     
/* 130 */     int size = this.clientInterceptors.size();
/* 131 */     ArrayList chain = new ArrayList(this.preInterceptors.size() + size + this.postInterceptors.size());
/* 132 */     chain.addAll(this.preInterceptors);
/* 133 */     if (size > 0)
/*     */     {
/* 135 */       synchronized (this.clientInterceptors)
/*     */       {
/* 137 */         chain.addAll(this.clientInterceptors);
/*     */       }
/*     */     }
/* 140 */     chain.addAll(this.postInterceptors);
/*     */     
/*     */ 
/* 143 */     MBeanServerInterceptor first = (MBeanServerInterceptor)chain.get(0);
/* 144 */     first.setChain(chain);
/*     */     
/* 146 */     this.head = first;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/* 157 */     if (!isRunning())
/*     */     {
/* 159 */       this.running = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/* 170 */     if (isRunning())
/*     */     {
/* 172 */       this.running = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRunning()
/*     */   {
/* 183 */     return this.running;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/interceptor/MBeanServerInterceptorConfigurator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */