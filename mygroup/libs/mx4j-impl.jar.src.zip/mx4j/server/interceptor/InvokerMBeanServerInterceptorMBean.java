package mx4j.server.interceptor;

public abstract interface InvokerMBeanServerInterceptorMBean
{
  public abstract String getType();
  
  public abstract boolean isEnabled();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/interceptor/InvokerMBeanServerInterceptorMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */