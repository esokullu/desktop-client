package mx4j.server.interceptor;

import java.util.List;
import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.AttributeNotFoundException;
import javax.management.InvalidAttributeValueException;
import javax.management.ListenerNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanInfo;
import javax.management.MBeanRegistrationException;
import javax.management.NotificationFilter;
import javax.management.NotificationListener;
import javax.management.ReflectionException;
import mx4j.server.MBeanMetaData;

public abstract interface MBeanServerInterceptor
{
  public static final int PRE_REGISTER = 1;
  public static final int POST_REGISTER_TRUE = 2;
  public static final int POST_REGISTER_FALSE = 3;
  public static final int PRE_DEREGISTER = 4;
  public static final int POST_DEREGISTER = 5;
  
  public abstract String getType();
  
  public abstract void setChain(List paramList);
  
  public abstract void addNotificationListener(MBeanMetaData paramMBeanMetaData, NotificationListener paramNotificationListener, NotificationFilter paramNotificationFilter, Object paramObject);
  
  public abstract void removeNotificationListener(MBeanMetaData paramMBeanMetaData, NotificationListener paramNotificationListener)
    throws ListenerNotFoundException;
  
  public abstract void removeNotificationListener(MBeanMetaData paramMBeanMetaData, NotificationListener paramNotificationListener, NotificationFilter paramNotificationFilter, Object paramObject)
    throws ListenerNotFoundException;
  
  public abstract void instantiate(MBeanMetaData paramMBeanMetaData, String paramString, String[] paramArrayOfString, Object[] paramArrayOfObject)
    throws ReflectionException, MBeanException;
  
  public abstract void registration(MBeanMetaData paramMBeanMetaData, int paramInt)
    throws MBeanRegistrationException;
  
  public abstract MBeanInfo getMBeanInfo(MBeanMetaData paramMBeanMetaData);
  
  public abstract Object invoke(MBeanMetaData paramMBeanMetaData, String paramString, String[] paramArrayOfString, Object[] paramArrayOfObject)
    throws MBeanException, ReflectionException;
  
  public abstract AttributeList getAttributes(MBeanMetaData paramMBeanMetaData, String[] paramArrayOfString);
  
  public abstract AttributeList setAttributes(MBeanMetaData paramMBeanMetaData, AttributeList paramAttributeList);
  
  public abstract Object getAttribute(MBeanMetaData paramMBeanMetaData, String paramString)
    throws MBeanException, AttributeNotFoundException, ReflectionException;
  
  public abstract void setAttribute(MBeanMetaData paramMBeanMetaData, Attribute paramAttribute)
    throws MBeanException, AttributeNotFoundException, InvalidAttributeValueException, ReflectionException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/interceptor/MBeanServerInterceptor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */