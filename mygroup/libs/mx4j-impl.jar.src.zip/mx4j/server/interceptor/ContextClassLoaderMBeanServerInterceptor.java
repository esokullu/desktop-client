/*     */ package mx4j.server.interceptor;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ReflectionException;
/*     */ import mx4j.server.MBeanMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextClassLoaderMBeanServerInterceptor
/*     */   extends DefaultMBeanServerInterceptor
/*     */ {
/*     */   public ContextClassLoaderMBeanServerInterceptor()
/*     */   {
/*  39 */     setEnabled(false);
/*     */   }
/*     */   
/*     */   public String getType()
/*     */   {
/*  44 */     return "contextclassloader";
/*     */   }
/*     */   
/*     */   public void addNotificationListener(MBeanMetaData metadata, NotificationListener listener, NotificationFilter filter, Object handback)
/*     */   {
/*  49 */     if (isEnabled())
/*     */     {
/*  51 */       ClassLoader context = getContextClassLoader();
/*  52 */       if (metadata.getClassLoader() != context)
/*     */       {
/*     */         try
/*     */         {
/*  56 */           setContextClassLoader(metadata.getClassLoader());
/*  57 */           super.addNotificationListener(metadata, listener, filter, handback); return;
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*  62 */           setContextClassLoader(context);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  67 */     super.addNotificationListener(metadata, listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(MBeanMetaData metadata, NotificationListener listener) throws ListenerNotFoundException
/*     */   {
/*  72 */     if (isEnabled())
/*     */     {
/*  74 */       ClassLoader context = getContextClassLoader();
/*  75 */       if (metadata.getClassLoader() != context)
/*     */       {
/*     */         try
/*     */         {
/*  79 */           setContextClassLoader(metadata.getClassLoader());
/*  80 */           super.removeNotificationListener(metadata, listener); return;
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*  85 */           setContextClassLoader(context);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  90 */     super.removeNotificationListener(metadata, listener);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(MBeanMetaData metadata, NotificationListener listener, NotificationFilter filter, Object handback) throws ListenerNotFoundException
/*     */   {
/*  95 */     if (isEnabled())
/*     */     {
/*  97 */       ClassLoader context = getContextClassLoader();
/*  98 */       if (metadata.getClassLoader() != context)
/*     */       {
/*     */         try
/*     */         {
/* 102 */           setContextClassLoader(metadata.getClassLoader());
/* 103 */           super.removeNotificationListener(metadata, listener, filter, handback); return;
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/* 108 */           setContextClassLoader(context);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 113 */     super.removeNotificationListener(metadata, listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void instantiate(MBeanMetaData metadata, String className, String[] params, Object[] args) throws ReflectionException, MBeanException
/*     */   {
/* 118 */     if (isEnabled())
/*     */     {
/* 120 */       ClassLoader context = getContextClassLoader();
/* 121 */       if (metadata.getClassLoader() != context)
/*     */       {
/*     */         try
/*     */         {
/* 125 */           setContextClassLoader(metadata.getClassLoader());
/* 126 */           super.instantiate(metadata, className, params, args); return;
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/* 131 */           setContextClassLoader(context);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 136 */     super.instantiate(metadata, className, params, args);
/*     */   }
/*     */   
/*     */   public void registration(MBeanMetaData metadata, int operation) throws MBeanRegistrationException
/*     */   {
/* 141 */     if (isEnabled())
/*     */     {
/* 143 */       ClassLoader context = getContextClassLoader();
/* 144 */       if (metadata.getClassLoader() != context)
/*     */       {
/*     */         try
/*     */         {
/* 148 */           setContextClassLoader(metadata.getClassLoader());
/* 149 */           super.registration(metadata, operation); return;
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/* 154 */           setContextClassLoader(context);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 159 */     super.registration(metadata, operation);
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo(MBeanMetaData metadata)
/*     */   {
/* 164 */     if (isEnabled())
/*     */     {
/* 166 */       ClassLoader context = getContextClassLoader();
/* 167 */       if (metadata.getClassLoader() != context)
/*     */       {
/*     */         try
/*     */         {
/* 171 */           setContextClassLoader(metadata.getClassLoader());
/* 172 */           return super.getMBeanInfo(metadata);
/*     */         }
/*     */         finally
/*     */         {
/* 176 */           setContextClassLoader(context);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 181 */     return super.getMBeanInfo(metadata);
/*     */   }
/*     */   
/*     */   public Object invoke(MBeanMetaData metadata, String method, String[] params, Object[] args) throws MBeanException, ReflectionException
/*     */   {
/* 186 */     if (isEnabled())
/*     */     {
/* 188 */       ClassLoader context = getContextClassLoader();
/* 189 */       if (metadata.getClassLoader() != context)
/*     */       {
/*     */         try
/*     */         {
/* 193 */           setContextClassLoader(metadata.getClassLoader());
/* 194 */           return super.invoke(metadata, method, params, args);
/*     */         }
/*     */         finally
/*     */         {
/* 198 */           setContextClassLoader(context);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 203 */     return super.invoke(metadata, method, params, args);
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(MBeanMetaData metadata, String[] attributes)
/*     */   {
/* 208 */     if (isEnabled())
/*     */     {
/* 210 */       ClassLoader context = getContextClassLoader();
/* 211 */       if (metadata.getClassLoader() != context)
/*     */       {
/*     */         try
/*     */         {
/* 215 */           setContextClassLoader(metadata.getClassLoader());
/* 216 */           return super.getAttributes(metadata, attributes);
/*     */         }
/*     */         finally
/*     */         {
/* 220 */           setContextClassLoader(context);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 225 */     return super.getAttributes(metadata, attributes);
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(MBeanMetaData metadata, AttributeList attributes)
/*     */   {
/* 230 */     if (isEnabled())
/*     */     {
/* 232 */       ClassLoader context = getContextClassLoader();
/* 233 */       if (metadata.getClassLoader() != context)
/*     */       {
/*     */         try
/*     */         {
/* 237 */           setContextClassLoader(metadata.getClassLoader());
/* 238 */           return super.setAttributes(metadata, attributes);
/*     */         }
/*     */         finally
/*     */         {
/* 242 */           setContextClassLoader(context);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 247 */     return super.setAttributes(metadata, attributes);
/*     */   }
/*     */   
/*     */   public Object getAttribute(MBeanMetaData metadata, String attribute) throws MBeanException, AttributeNotFoundException, ReflectionException
/*     */   {
/* 252 */     if (isEnabled())
/*     */     {
/* 254 */       ClassLoader context = getContextClassLoader();
/* 255 */       if (metadata.getClassLoader() != context)
/*     */       {
/*     */         try
/*     */         {
/* 259 */           setContextClassLoader(metadata.getClassLoader());
/* 260 */           return super.getAttribute(metadata, attribute);
/*     */         }
/*     */         finally
/*     */         {
/* 264 */           setContextClassLoader(context);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 269 */     return super.getAttribute(metadata, attribute);
/*     */   }
/*     */   
/*     */   public void setAttribute(MBeanMetaData metadata, Attribute attribute) throws MBeanException, AttributeNotFoundException, InvalidAttributeValueException, ReflectionException
/*     */   {
/* 274 */     if (isEnabled())
/*     */     {
/* 276 */       ClassLoader context = getContextClassLoader();
/* 277 */       if (metadata.getClassLoader() != context)
/*     */       {
/*     */         try
/*     */         {
/* 281 */           setContextClassLoader(metadata.getClassLoader());
/* 282 */           super.setAttribute(metadata, attribute); return;
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/* 287 */           setContextClassLoader(context);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 292 */     super.setAttribute(metadata, attribute);
/*     */   }
/*     */   
/*     */   private ClassLoader getContextClassLoader()
/*     */   {
/* 297 */     return Thread.currentThread().getContextClassLoader();
/*     */   }
/*     */   
/*     */   private void setContextClassLoader(ClassLoader cl)
/*     */   {
/* 302 */     AccessController.doPrivileged(new PrivilegedAction() {
/*     */       private final ClassLoader val$cl;
/*     */       
/*     */       public Object run() {
/* 306 */         Thread.currentThread().setContextClassLoader(this.val$cl);
/* 307 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/interceptor/ContextClassLoaderMBeanServerInterceptor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */