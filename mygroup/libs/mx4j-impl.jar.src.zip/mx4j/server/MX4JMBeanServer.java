/*      */ package mx4j.server;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import javax.management.Attribute;
/*      */ import javax.management.AttributeList;
/*      */ import javax.management.AttributeNotFoundException;
/*      */ import javax.management.BadAttributeValueExpException;
/*      */ import javax.management.BadBinaryOpValueExpException;
/*      */ import javax.management.BadStringOperationException;
/*      */ import javax.management.InstanceAlreadyExistsException;
/*      */ import javax.management.InstanceNotFoundException;
/*      */ import javax.management.IntrospectionException;
/*      */ import javax.management.InvalidApplicationException;
/*      */ import javax.management.InvalidAttributeValueException;
/*      */ import javax.management.JMRuntimeException;
/*      */ import javax.management.ListenerNotFoundException;
/*      */ import javax.management.MBeanException;
/*      */ import javax.management.MBeanInfo;
/*      */ import javax.management.MBeanPermission;
/*      */ import javax.management.MBeanRegistrationException;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.MBeanServerDelegate;
/*      */ import javax.management.MBeanServerNotification;
/*      */ import javax.management.MBeanServerPermission;
/*      */ import javax.management.MalformedObjectNameException;
/*      */ import javax.management.NotCompliantMBeanException;
/*      */ import javax.management.NotificationBroadcaster;
/*      */ import javax.management.NotificationEmitter;
/*      */ import javax.management.NotificationFilter;
/*      */ import javax.management.NotificationListener;
/*      */ import javax.management.ObjectInstance;
/*      */ import javax.management.ObjectName;
/*      */ import javax.management.OperationsException;
/*      */ import javax.management.QueryExp;
/*      */ import javax.management.ReflectionException;
/*      */ import javax.management.RuntimeErrorException;
/*      */ import javax.management.RuntimeOperationsException;
/*      */ import javax.management.StandardMBean;
/*      */ import javax.management.loading.ClassLoaderRepository;
/*      */ import javax.management.loading.PrivateClassLoader;
/*      */ import mx4j.ImplementationException;
/*      */ import mx4j.loading.ClassLoaderObjectInputStream;
/*      */ import mx4j.log.Log;
/*      */ import mx4j.log.Logger;
/*      */ import mx4j.server.interceptor.ContextClassLoaderMBeanServerInterceptor;
/*      */ import mx4j.server.interceptor.InvokerMBeanServerInterceptor;
/*      */ import mx4j.server.interceptor.MBeanServerInterceptor;
/*      */ import mx4j.server.interceptor.MBeanServerInterceptorConfigurator;
/*      */ import mx4j.server.interceptor.NotificationListenerMBeanServerInterceptor;
/*      */ import mx4j.server.interceptor.SecurityMBeanServerInterceptor;
/*      */ import mx4j.util.Utils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MX4JMBeanServer
/*      */   implements MBeanServer
/*      */ {
/*      */   private String defaultDomain;
/*      */   private MBeanRepository mbeanRepository;
/*      */   private MBeanServerDelegate delegate;
/*      */   private ObjectName delegateName;
/*      */   private MBeanIntrospector introspector;
/*      */   private MBeanServerInterceptorConfigurator invoker;
/*      */   private static long notifications;
/*      */   private ModifiableClassLoaderRepository classLoaderRepository;
/*  108 */   private Map domains = new HashMap();
/*      */   
/*  110 */   private static final String[] EMPTY_PARAMS = new String[0];
/*  111 */   private static final Object[] EMPTY_ARGS = new Object[0];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MX4JMBeanServer(String defaultDomain, MBeanServer outer, MBeanServerDelegate delegate)
/*      */   {
/*  122 */     Logger logger = getLogger();
/*  123 */     if (logger.isEnabledFor(0)) { logger.trace("Creating MBeanServer instance...");
/*      */     }
/*  125 */     SecurityManager sm = System.getSecurityManager();
/*  126 */     if (sm != null)
/*      */     {
/*  128 */       if (logger.isEnabledFor(0)) logger.trace("Checking permission to create MBeanServer...");
/*  129 */       sm.checkPermission(new MBeanServerPermission("newMBeanServer"));
/*      */     }
/*      */     
/*  132 */     if (defaultDomain == null) defaultDomain = "";
/*  133 */     this.defaultDomain = defaultDomain;
/*      */     
/*  135 */     if (delegate == null) throw new JMRuntimeException("Delegate can't be null");
/*  136 */     this.delegate = delegate;
/*      */     
/*  138 */     if (logger.isEnabledFor(0)) { logger.trace("MBeanServer default domain is: '" + this.defaultDomain + "'");
/*      */     }
/*  140 */     this.mbeanRepository = createMBeanRepository();
/*      */     
/*  142 */     this.classLoaderRepository = createClassLoaderRepository();
/*      */     
/*  144 */     this.classLoaderRepository.addClassLoader(getClass().getClassLoader());
/*      */     
/*  146 */     this.introspector = new MBeanIntrospector();
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  151 */       this.delegateName = new ObjectName("JMImplementation", "type", "MBeanServerDelegate");
/*      */     }
/*      */     catch (MalformedObjectNameException ignored) {}
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  159 */       ObjectName invokerName = new ObjectName("JMImplementation:type=MBeanServerInterceptorConfigurator");
/*  160 */       this.invoker = new MBeanServerInterceptorConfigurator(this);
/*      */       
/*  162 */       ContextClassLoaderMBeanServerInterceptor ccl = new ContextClassLoaderMBeanServerInterceptor();
/*  163 */       NotificationListenerMBeanServerInterceptor notif = new NotificationListenerMBeanServerInterceptor();
/*  164 */       SecurityMBeanServerInterceptor sec = new SecurityMBeanServerInterceptor();
/*  165 */       InvokerMBeanServerInterceptor inv = new InvokerMBeanServerInterceptor(outer == null ? this : outer);
/*      */       
/*  167 */       this.invoker.addPreInterceptor(ccl);
/*  168 */       this.invoker.addPreInterceptor(notif);
/*  169 */       this.invoker.addPreInterceptor(sec);
/*  170 */       this.invoker.addPostInterceptor(inv);
/*  171 */       this.invoker.start();
/*      */       
/*      */ 
/*  174 */       privilegedRegisterMBean(this.invoker, invokerName);
/*      */       
/*  176 */       ObjectName cclName = new ObjectName("JMImplementation", "interceptor", "contextclassloader");
/*  177 */       ObjectName notifName = new ObjectName("JMImplementation", "interceptor", "notificationwrapper");
/*  178 */       ObjectName secName = new ObjectName("JMImplementation", "interceptor", "security");
/*  179 */       ObjectName invName = new ObjectName("JMImplementation", "interceptor", "invoker");
/*      */       
/*  181 */       privilegedRegisterMBean(ccl, cclName);
/*  182 */       privilegedRegisterMBean(notif, notifName);
/*  183 */       privilegedRegisterMBean(sec, secName);
/*  184 */       privilegedRegisterMBean(inv, invName);
/*      */     }
/*      */     catch (Exception x)
/*      */     {
/*  188 */       logger.error("MBeanServerInterceptorConfigurator cannot be registered", x);
/*  189 */       throw new ImplementationException();
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  195 */       privilegedRegisterMBean(delegate, this.delegateName);
/*      */     }
/*      */     catch (Exception x)
/*      */     {
/*  199 */       logger.error("MBeanServerDelegate cannot be registered", x);
/*  200 */       throw new ImplementationException(x.toString());
/*      */     }
/*      */     
/*  203 */     if (logger.isEnabledFor(0)) { logger.trace("MBeanServer instance created successfully");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassLoaderRepository getClassLoaderRepository()
/*      */   {
/*  215 */     SecurityManager sm = System.getSecurityManager();
/*  216 */     if (sm != null)
/*      */     {
/*  218 */       sm.checkPermission(new MBeanPermission("-#-[-]", "getClassLoaderRepository"));
/*      */     }
/*      */     
/*  221 */     return getModifiableClassLoaderRepository();
/*      */   }
/*      */   
/*      */   private ModifiableClassLoaderRepository getModifiableClassLoaderRepository()
/*      */   {
/*  226 */     return this.classLoaderRepository;
/*      */   }
/*      */   
/*      */   public ClassLoader getClassLoader(ObjectName name) throws InstanceNotFoundException
/*      */   {
/*  231 */     SecurityManager sm = System.getSecurityManager();
/*  232 */     if (sm != null)
/*      */     {
/*  234 */       name = secureObjectName(name);
/*      */       
/*  236 */       if (name == null)
/*      */       {
/*  238 */         sm.checkPermission(new MBeanPermission("-#-[-]", "getClassLoader"));
/*      */       }
/*      */       else
/*      */       {
/*  242 */         MBeanMetaData metadata = findMBeanMetaData(name);
/*  243 */         sm.checkPermission(new MBeanPermission(metadata.getMBeanInfo().getClassName(), "-", name, "getClassLoader"));
/*      */       }
/*      */     }
/*      */     
/*  247 */     return getClassLoaderImpl(name);
/*      */   }
/*      */   
/*      */   public ClassLoader getClassLoaderFor(ObjectName name) throws InstanceNotFoundException
/*      */   {
/*  252 */     SecurityManager sm = System.getSecurityManager();
/*  253 */     if (sm != null)
/*      */     {
/*  255 */       name = secureObjectName(name);
/*      */     }
/*      */     
/*      */ 
/*  259 */     MBeanMetaData metadata = findMBeanMetaData(name);
/*      */     
/*  261 */     if (sm != null)
/*      */     {
/*  263 */       sm.checkPermission(new MBeanPermission(metadata.getMBeanInfo().getClassName(), "-", name, "getClassLoaderFor"));
/*      */     }
/*      */     
/*  266 */     return metadata.getMBean().getClass().getClassLoader();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ClassLoader getClassLoaderImpl(ObjectName name)
/*      */     throws InstanceNotFoundException
/*      */   {
/*  275 */     if (name == null)
/*      */     {
/*  277 */       return getClass().getClassLoader();
/*      */     }
/*      */     
/*      */ 
/*  281 */     MBeanMetaData metadata = findMBeanMetaData(name);
/*  282 */     if ((metadata.getMBean() instanceof ClassLoader))
/*      */     {
/*  284 */       return (ClassLoader)metadata.getMBean();
/*      */     }
/*      */     
/*      */ 
/*  288 */     throw new InstanceNotFoundException(name.getCanonicalName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectInputStream deserialize(String className, ObjectName loaderName, byte[] bytes)
/*      */     throws InstanceNotFoundException, OperationsException, ReflectionException
/*      */   {
/*  296 */     if ((className == null) || (className.trim().length() == 0))
/*      */     {
/*  298 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid class name '" + className + "'"));
/*      */     }
/*      */     
/*  301 */     ClassLoader cl = getClassLoader(loaderName);
/*      */     
/*      */     try
/*      */     {
/*  305 */       Class cls = cl.loadClass(className);
/*  306 */       return deserializeImpl(cls.getClassLoader(), bytes);
/*      */     }
/*      */     catch (ClassNotFoundException x)
/*      */     {
/*  310 */       throw new ReflectionException(x);
/*      */     }
/*      */   }
/*      */   
/*      */   public ObjectInputStream deserialize(String className, byte[] bytes)
/*      */     throws OperationsException, ReflectionException
/*      */   {
/*  317 */     if ((className == null) || (className.trim().length() == 0))
/*      */     {
/*  319 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid class name '" + className + "'"));
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  325 */       Class cls = getClassLoaderRepository().loadClass(className);
/*  326 */       return deserializeImpl(cls.getClassLoader(), bytes);
/*      */     }
/*      */     catch (ClassNotFoundException x)
/*      */     {
/*  330 */       throw new ReflectionException(x);
/*      */     }
/*      */   }
/*      */   
/*      */   public ObjectInputStream deserialize(ObjectName objectName, byte[] bytes)
/*      */     throws InstanceNotFoundException, OperationsException
/*      */   {
/*  337 */     ClassLoader cl = getClassLoaderFor(objectName);
/*  338 */     return deserializeImpl(cl, bytes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private ObjectInputStream deserializeImpl(ClassLoader classloader, byte[] bytes)
/*      */     throws OperationsException
/*      */   {
/*  346 */     if ((bytes == null) || (bytes.length == 0))
/*      */     {
/*  348 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid byte array " + bytes));
/*      */     }
/*      */     
/*  351 */     ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
/*      */     try
/*      */     {
/*  354 */       return new ClassLoaderObjectInputStream(bais, classloader);
/*      */     }
/*      */     catch (IOException x)
/*      */     {
/*  358 */       throw new OperationsException(x.toString());
/*      */     }
/*      */   }
/*      */   
/*      */   private MBeanServerInterceptor getHeadInterceptor()
/*      */   {
/*  364 */     MBeanServerInterceptor head = this.invoker.getHeadInterceptor();
/*      */     
/*  366 */     if (head == null) { throw new IllegalStateException("No MBeanServer interceptor, probably the configurator has been stopped");
/*      */     }
/*  368 */     return head;
/*      */   }
/*      */   
/*      */   private Logger getLogger()
/*      */   {
/*  373 */     return Log.getLogger(getClass().getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private MBeanRepository createMBeanRepository()
/*      */   {
/*  385 */     Logger logger = getLogger();
/*      */     
/*  387 */     if (logger.isEnabledFor(0)) { logger.trace("Checking for system property mx4j.mbeanserver.repository");
/*      */     }
/*  389 */     String value = (String)AccessController.doPrivileged(new PrivilegedAction()
/*      */     {
/*      */       public Object run()
/*      */       {
/*  393 */         return System.getProperty("mx4j.mbeanserver.repository");
/*      */       }
/*      */     });
/*      */     
/*  397 */     if (value != null)
/*      */     {
/*  399 */       if (logger.isEnabledFor(10)) { logger.debug("Property found for custom MBeanServer registry; class is: " + value);
/*      */       }
/*      */       try
/*      */       {
/*  403 */         MBeanRepository registry = (MBeanRepository)Thread.currentThread().getContextClassLoader().loadClass(value).newInstance();
/*  404 */         if (logger.isEnabledFor(0))
/*      */         {
/*  406 */           logger.trace("Custom MBeanServer registry created successfully");
/*      */         }
/*  408 */         return registry;
/*      */       }
/*      */       catch (Exception x)
/*      */       {
/*  412 */         if (logger.isEnabledFor(0))
/*      */         {
/*  414 */           logger.trace("Custom MBeanServer registry could not be created", x);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  419 */     return new DefaultMBeanRepository();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ModifiableClassLoaderRepository createClassLoaderRepository()
/*      */   {
/*  432 */     Logger logger = getLogger();
/*      */     
/*  434 */     if (logger.isEnabledFor(0)) { logger.trace("Checking for system property mx4j.mbeanserver.classloader.repository");
/*      */     }
/*  436 */     String value = (String)AccessController.doPrivileged(new PrivilegedAction()
/*      */     {
/*      */       public Object run()
/*      */       {
/*  440 */         return System.getProperty("mx4j.mbeanserver.classloader.repository");
/*      */       }
/*      */     });
/*      */     
/*  444 */     if (value != null)
/*      */     {
/*  446 */       if (logger.isEnabledFor(10)) { logger.debug("Property found for custom ClassLoaderRepository; class is: " + value);
/*      */       }
/*      */       try
/*      */       {
/*  450 */         ModifiableClassLoaderRepository repository = (ModifiableClassLoaderRepository)Thread.currentThread().getContextClassLoader().loadClass(value).newInstance();
/*  451 */         if (logger.isEnabledFor(0)) logger.trace("Custom ClassLoaderRepository created successfully " + repository);
/*  452 */         return repository;
/*      */       }
/*      */       catch (Exception x)
/*      */       {
/*  456 */         if (logger.isEnabledFor(0)) logger.trace("Custom ClassLoaderRepository could not be created", x);
/*      */       }
/*      */     }
/*  459 */     return new DefaultClassLoaderRepository();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private MBeanRepository getMBeanRepository()
/*      */   {
/*  467 */     return this.mbeanRepository;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private MBeanMetaData findMBeanMetaData(ObjectName objectName)
/*      */     throws InstanceNotFoundException
/*      */   {
/*  477 */     MBeanMetaData metadata = null;
/*  478 */     if (objectName != null)
/*      */     {
/*  480 */       objectName = normalizeObjectName(objectName);
/*      */       
/*  482 */       MBeanRepository repository = getMBeanRepository();
/*  483 */       synchronized (repository)
/*      */       {
/*  485 */         metadata = repository.get(objectName);
/*      */       }
/*      */     }
/*  488 */     if (metadata == null)
/*      */     {
/*  490 */       throw new InstanceNotFoundException("MBeanServer cannot find MBean with ObjectName " + objectName);
/*      */     }
/*  492 */     return metadata;
/*      */   }
/*      */   
/*      */   public void addNotificationListener(ObjectName observed, ObjectName listener, NotificationFilter filter, Object handback)
/*      */     throws InstanceNotFoundException
/*      */   {
/*  498 */     listener = secureObjectName(listener);
/*      */     
/*  500 */     Object mbean = findMBeanMetaData(listener).getMBean();
/*  501 */     if (!(mbean instanceof NotificationListener))
/*      */     {
/*  503 */       throw new RuntimeOperationsException(new IllegalArgumentException("MBean " + listener + " is not a NotificationListener"));
/*      */     }
/*  505 */     addNotificationListener(observed, (NotificationListener)mbean, filter, handback);
/*      */   }
/*      */   
/*      */   public void addNotificationListener(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback)
/*      */     throws InstanceNotFoundException
/*      */   {
/*  511 */     if (listener == null)
/*      */     {
/*  513 */       throw new RuntimeOperationsException(new IllegalArgumentException("NotificationListener cannot be null"));
/*      */     }
/*      */     
/*  516 */     observed = secureObjectName(observed);
/*      */     
/*  518 */     MBeanMetaData metadata = findMBeanMetaData(observed);
/*      */     
/*  520 */     Object mbean = metadata.getMBean();
/*      */     
/*  522 */     if (!(mbean instanceof NotificationBroadcaster))
/*      */     {
/*  524 */       throw new RuntimeOperationsException(new IllegalArgumentException("MBean " + observed + " is not a NotificationBroadcaster"));
/*      */     }
/*      */     
/*  527 */     addNotificationListenerImpl(metadata, listener, filter, handback);
/*      */   }
/*      */   
/*      */   private void addNotificationListenerImpl(MBeanMetaData metadata, NotificationListener listener, NotificationFilter filter, Object handback)
/*      */   {
/*  532 */     getHeadInterceptor().addNotificationListener(metadata, listener, filter, handback);
/*      */   }
/*      */   
/*      */   public void removeNotificationListener(ObjectName observed, ObjectName listener)
/*      */     throws InstanceNotFoundException, ListenerNotFoundException
/*      */   {
/*  538 */     listener = secureObjectName(listener);
/*      */     
/*  540 */     Object mbean = findMBeanMetaData(listener).getMBean();
/*  541 */     if (!(mbean instanceof NotificationListener))
/*      */     {
/*  543 */       throw new RuntimeOperationsException(new IllegalArgumentException("MBean " + listener + " is not a NotificationListener"));
/*      */     }
/*  545 */     removeNotificationListener(observed, (NotificationListener)mbean);
/*      */   }
/*      */   
/*      */   public void removeNotificationListener(ObjectName observed, NotificationListener listener)
/*      */     throws InstanceNotFoundException, ListenerNotFoundException
/*      */   {
/*  551 */     if (listener == null)
/*      */     {
/*  553 */       throw new ListenerNotFoundException("NotificationListener cannot be null");
/*      */     }
/*      */     
/*  556 */     observed = secureObjectName(observed);
/*      */     
/*  558 */     MBeanMetaData metadata = findMBeanMetaData(observed);
/*  559 */     Object mbean = metadata.getMBean();
/*      */     
/*  561 */     if (!(mbean instanceof NotificationBroadcaster))
/*      */     {
/*  563 */       throw new RuntimeOperationsException(new IllegalArgumentException("MBean " + observed + " is not a NotificationBroadcaster"));
/*      */     }
/*      */     
/*  566 */     removeNotificationListenerImpl(metadata, listener);
/*      */   }
/*      */   
/*      */   public void removeNotificationListener(ObjectName observed, ObjectName listener, NotificationFilter filter, Object handback)
/*      */     throws InstanceNotFoundException, ListenerNotFoundException
/*      */   {
/*  572 */     listener = secureObjectName(listener);
/*      */     
/*  574 */     Object mbean = findMBeanMetaData(listener).getMBean();
/*  575 */     if (!(mbean instanceof NotificationListener))
/*      */     {
/*  577 */       throw new RuntimeOperationsException(new IllegalArgumentException("MBean " + listener + " is not a NotificationListener"));
/*      */     }
/*  579 */     removeNotificationListener(observed, (NotificationListener)mbean, filter, handback);
/*      */   }
/*      */   
/*      */   public void removeNotificationListener(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback)
/*      */     throws InstanceNotFoundException, ListenerNotFoundException
/*      */   {
/*  585 */     if (listener == null)
/*      */     {
/*  587 */       throw new ListenerNotFoundException("NotificationListener cannot be null");
/*      */     }
/*      */     
/*  590 */     observed = secureObjectName(observed);
/*      */     
/*  592 */     MBeanMetaData metadata = findMBeanMetaData(observed);
/*  593 */     Object mbean = metadata.getMBean();
/*      */     
/*  595 */     if (!(mbean instanceof NotificationEmitter))
/*      */     {
/*  597 */       throw new RuntimeOperationsException(new IllegalArgumentException("MBean " + observed + " is not a NotificationEmitter"));
/*      */     }
/*      */     
/*  600 */     removeNotificationListenerImpl(metadata, listener, filter, handback);
/*      */   }
/*      */   
/*      */   private void removeNotificationListenerImpl(MBeanMetaData metadata, NotificationListener listener)
/*      */     throws ListenerNotFoundException
/*      */   {
/*  606 */     getHeadInterceptor().removeNotificationListener(metadata, listener);
/*      */   }
/*      */   
/*      */   private void removeNotificationListenerImpl(MBeanMetaData metadata, NotificationListener listener, NotificationFilter filter, Object handback)
/*      */     throws ListenerNotFoundException
/*      */   {
/*  612 */     getHeadInterceptor().removeNotificationListener(metadata, listener, filter, handback);
/*      */   }
/*      */   
/*      */   public Object instantiate(String className)
/*      */     throws ReflectionException, MBeanException
/*      */   {
/*  618 */     return instantiate(className, null, null);
/*      */   }
/*      */   
/*      */   public Object instantiate(String className, Object[] args, String[] parameters)
/*      */     throws ReflectionException, MBeanException
/*      */   {
/*  624 */     if ((className == null) || (className.trim().length() == 0))
/*      */     {
/*  626 */       throw new RuntimeOperationsException(new IllegalArgumentException("Class name cannot be null or empty"));
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  631 */       Class cls = getModifiableClassLoaderRepository().loadClass(className);
/*  632 */       return instantiateImpl(className, cls.getClassLoader(), null, parameters, args).getMBean();
/*      */     }
/*      */     catch (ClassNotFoundException x)
/*      */     {
/*  636 */       throw new ReflectionException(x);
/*      */     }
/*      */   }
/*      */   
/*      */   public Object instantiate(String className, ObjectName loaderName)
/*      */     throws ReflectionException, MBeanException, InstanceNotFoundException
/*      */   {
/*  643 */     return instantiate(className, loaderName, null, null);
/*      */   }
/*      */   
/*      */   public Object instantiate(String className, ObjectName loaderName, Object[] args, String[] parameters)
/*      */     throws ReflectionException, MBeanException, InstanceNotFoundException
/*      */   {
/*  649 */     if ((className == null) || (className.trim().length() == 0))
/*      */     {
/*  651 */       throw new RuntimeOperationsException(new IllegalArgumentException("Class name cannot be null or empty"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  656 */     loaderName = secureObjectName(loaderName);
/*  657 */     if ((loaderName != null) && (loaderName.isPattern()))
/*      */     {
/*  659 */       throw new RuntimeOperationsException(new IllegalArgumentException("ObjectName for the ClassLoader cannot be a pattern ObjectName: " + loaderName));
/*      */     }
/*      */     
/*  662 */     ClassLoader cl = getClassLoaderImpl(loaderName);
/*  663 */     return instantiateImpl(className, cl, null, parameters, args).getMBean();
/*      */   }
/*      */   
/*      */   private MBeanMetaData instantiateImpl(String className, ClassLoader classloader, ObjectName name, String[] params, Object[] args)
/*      */     throws ReflectionException, MBeanException
/*      */   {
/*  669 */     if (params == null) params = EMPTY_PARAMS;
/*  670 */     if (args == null) { args = EMPTY_ARGS;
/*      */     }
/*  672 */     MBeanMetaData metadata = createMBeanMetaData();
/*  673 */     metadata.setClassLoader(classloader);
/*  674 */     metadata.setObjectName(secureObjectName(name));
/*      */     
/*  676 */     getHeadInterceptor().instantiate(metadata, className, params, args);
/*      */     
/*  678 */     return metadata;
/*      */   }
/*      */   
/*      */   public ObjectInstance createMBean(String className, ObjectName objectName)
/*      */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException
/*      */   {
/*  684 */     return createMBean(className, objectName, null, null);
/*      */   }
/*      */   
/*      */   public ObjectInstance createMBean(String className, ObjectName objectName, Object[] args, String[] parameters)
/*      */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException
/*      */   {
/*      */     try
/*      */     {
/*  692 */       Class cls = getModifiableClassLoaderRepository().loadClass(className);
/*  693 */       MBeanMetaData metadata = instantiateImpl(className, cls.getClassLoader(), objectName, parameters, args);
/*      */       
/*  695 */       registerImpl(metadata, false);
/*      */       
/*  697 */       return metadata.getObjectInstance();
/*      */     }
/*      */     catch (ClassNotFoundException x)
/*      */     {
/*  701 */       throw new ReflectionException(x);
/*      */     }
/*      */   }
/*      */   
/*      */   public ObjectInstance createMBean(String className, ObjectName objectName, ObjectName loaderName)
/*      */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException
/*      */   {
/*  708 */     return createMBean(className, objectName, loaderName, null, null);
/*      */   }
/*      */   
/*      */   public ObjectInstance createMBean(String className, ObjectName objectName, ObjectName loaderName, Object[] args, String[] parameters)
/*      */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException
/*      */   {
/*  714 */     loaderName = secureObjectName(loaderName);
/*      */     
/*  716 */     ClassLoader cl = getClassLoaderImpl(loaderName);
/*      */     
/*  718 */     MBeanMetaData metadata = instantiateImpl(className, cl, objectName, parameters, args);
/*      */     
/*  720 */     registerImpl(metadata, false);
/*      */     
/*  722 */     return metadata.getObjectInstance();
/*      */   }
/*      */   
/*      */   public ObjectInstance registerMBean(Object mbean, ObjectName objectName)
/*      */     throws InstanceAlreadyExistsException, MBeanRegistrationException, NotCompliantMBeanException
/*      */   {
/*  728 */     return registerMBeanImpl(mbean, objectName, false);
/*      */   }
/*      */   
/*      */   private ObjectInstance registerMBeanImpl(Object mbean, ObjectName objectName, boolean privileged)
/*      */     throws InstanceAlreadyExistsException, MBeanRegistrationException, NotCompliantMBeanException
/*      */   {
/*  734 */     if (mbean == null)
/*      */     {
/*  736 */       throw new RuntimeOperationsException(new IllegalArgumentException("MBean instance cannot be null"));
/*      */     }
/*      */     
/*  739 */     MBeanMetaData metadata = createMBeanMetaData();
/*  740 */     metadata.setMBean(mbean);
/*  741 */     metadata.setClassLoader(mbean.getClass().getClassLoader());
/*  742 */     metadata.setObjectName(secureObjectName(objectName));
/*      */     
/*  744 */     registerImpl(metadata, privileged);
/*      */     
/*  746 */     return metadata.getObjectInstance();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private MBeanMetaData createMBeanMetaData()
/*      */   {
/*  754 */     return MBeanMetaData.Factory.create();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ObjectInstance privilegedRegisterMBean(Object mbean, ObjectName name)
/*      */     throws InstanceAlreadyExistsException, MBeanRegistrationException, NotCompliantMBeanException
/*      */   {
/*      */     try
/*      */     {
/*  767 */       (ObjectInstance)AccessController.doPrivileged(new PrivilegedExceptionAction() {
/*      */         private final Object val$mbean;
/*      */         private final ObjectName val$name;
/*      */         
/*  771 */         public Object run() throws Exception { return MX4JMBeanServer.this.registerMBeanImpl(this.val$mbean, this.val$name, true);
/*      */         }
/*      */       });
/*      */     }
/*      */     catch (PrivilegedActionException x)
/*      */     {
/*  777 */       Exception xx = x.getException();
/*  778 */       if ((xx instanceof InstanceAlreadyExistsException))
/*  779 */         throw ((InstanceAlreadyExistsException)xx);
/*  780 */       if ((xx instanceof MBeanRegistrationException))
/*  781 */         throw ((MBeanRegistrationException)xx);
/*  782 */       if ((xx instanceof NotCompliantMBeanException)) {
/*  783 */         throw ((NotCompliantMBeanException)xx);
/*      */       }
/*  785 */       throw new MBeanRegistrationException(xx);
/*      */     }
/*      */   }
/*      */   
/*      */   private void registerImpl(MBeanMetaData metadata, boolean privileged) throws InstanceAlreadyExistsException, MBeanRegistrationException, NotCompliantMBeanException
/*      */   {
/*  791 */     this.introspector.introspect(metadata);
/*      */     
/*  793 */     if (!this.introspector.isMBeanCompliant(metadata)) { throw new NotCompliantMBeanException("MBean is not compliant");
/*      */     }
/*  795 */     MBeanServerInterceptor head = getHeadInterceptor();
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  800 */       head.registration(metadata, 1);
/*  801 */       metadata.setObjectName(secureObjectName(metadata.getObjectName()));
/*      */       
/*      */ 
/*      */ 
/*  805 */       register(metadata, privileged);
/*      */       
/*  807 */       head.registration(metadata, 2);
/*      */     }
/*      */     catch (Throwable x)
/*      */     {
/*      */       try
/*      */       {
/*  813 */         head.registration(metadata, 3);
/*      */       }
/*      */       catch (MBeanRegistrationException ignored) {}
/*      */       
/*      */ 
/*      */ 
/*  819 */       if ((x instanceof SecurityException))
/*      */       {
/*  821 */         throw ((SecurityException)x);
/*      */       }
/*  823 */       if ((x instanceof InstanceAlreadyExistsException))
/*      */       {
/*  825 */         throw ((InstanceAlreadyExistsException)x);
/*      */       }
/*  827 */       if ((x instanceof MBeanRegistrationException))
/*      */       {
/*  829 */         throw ((MBeanRegistrationException)x);
/*      */       }
/*  831 */       if ((x instanceof RuntimeOperationsException))
/*      */       {
/*  833 */         throw ((RuntimeOperationsException)x);
/*      */       }
/*  835 */       if ((x instanceof JMRuntimeException))
/*      */       {
/*  837 */         throw ((JMRuntimeException)x);
/*      */       }
/*  839 */       if ((x instanceof Exception))
/*      */       {
/*  841 */         throw new MBeanRegistrationException((Exception)x);
/*      */       }
/*  843 */       if ((x instanceof Error))
/*      */       {
/*  845 */         throw new MBeanRegistrationException(new RuntimeErrorException((Error)x));
/*      */       }
/*      */       
/*      */ 
/*  849 */       throw new ImplementationException();
/*      */     }
/*      */     
/*      */ 
/*  853 */     Object mbean = metadata.getMBean();
/*  854 */     if (((mbean instanceof ClassLoader)) && (!(mbean instanceof PrivateClassLoader)))
/*      */     {
/*  856 */       ClassLoader cl = (ClassLoader)mbean;
/*  857 */       getModifiableClassLoaderRepository().addClassLoader(cl);
/*      */     }
/*      */   }
/*      */   
/*      */   private void register(MBeanMetaData metadata, boolean privileged) throws InstanceAlreadyExistsException
/*      */   {
/*  863 */     metadata.setObjectName(normalizeObjectName(metadata.getObjectName()));
/*      */     
/*  865 */     ObjectName objectName = metadata.getObjectName();
/*  866 */     if ((objectName == null) || (objectName.isPattern()))
/*      */     {
/*  868 */       throw new RuntimeOperationsException(new IllegalArgumentException("ObjectName cannot be null or a pattern ObjectName"));
/*      */     }
/*  870 */     if ((objectName.getDomain().equals("JMImplementation")) && (!privileged))
/*      */     {
/*  872 */       throw new JMRuntimeException("Domain 'JMImplementation' is reserved for the JMX Agent");
/*      */     }
/*      */     
/*  875 */     MBeanRepository repository = getMBeanRepository();
/*  876 */     synchronized (repository)
/*      */     {
/*  878 */       if (repository.get(objectName) != null) { throw new InstanceAlreadyExistsException(objectName.toString());
/*      */       }
/*  880 */       repository.put(objectName, metadata);
/*      */     }
/*  882 */     addDomain(objectName.getDomain());
/*      */     
/*  884 */     notify(objectName, "JMX.mbean.registered");
/*      */   }
/*      */   
/*      */   private void notify(ObjectName objectName, String notificationType)
/*      */   {
/*  889 */     long sequenceNumber = 0L;
/*  890 */     synchronized (MX4JMBeanServer.class)
/*      */     {
/*  892 */       sequenceNumber = notifications;
/*  893 */       notifications += 1L;
/*      */     }
/*      */     
/*  896 */     this.delegate.sendNotification(new MBeanServerNotification(notificationType, this.delegateName, sequenceNumber, objectName));
/*      */   }
/*      */   
/*      */   private void addDomain(String domain)
/*      */   {
/*  901 */     synchronized (this.domains)
/*      */     {
/*  903 */       Integer count = (Integer)this.domains.get(domain);
/*  904 */       if (count == null) {
/*  905 */         this.domains.put(domain, new Integer(1));
/*      */       } else {
/*  907 */         this.domains.put(domain, new Integer(count.intValue() + 1));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void removeDomain(String domain) {
/*  913 */     synchronized (this.domains)
/*      */     {
/*  915 */       Integer count = (Integer)this.domains.get(domain);
/*  916 */       if (count == null) throw new ImplementationException();
/*  917 */       if (count.intValue() < 2) {
/*  918 */         this.domains.remove(domain);
/*      */       } else {
/*  920 */         this.domains.put(domain, new Integer(count.intValue() - 1));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void unregisterMBean(ObjectName objectName) throws InstanceNotFoundException, MBeanRegistrationException
/*      */   {
/*  927 */     objectName = secureObjectName(objectName);
/*      */     
/*  929 */     if ((objectName == null) || (objectName.isPattern()))
/*      */     {
/*  931 */       throw new RuntimeOperationsException(new IllegalArgumentException("ObjectName cannot be null or a pattern ObjectName"));
/*      */     }
/*      */     
/*  934 */     if (objectName.getDomain().equals("JMImplementation"))
/*      */     {
/*  936 */       throw new RuntimeOperationsException(new IllegalArgumentException("Domain 'JMImplementation' is reserved for the JMX Agent"));
/*      */     }
/*      */     
/*  939 */     MBeanMetaData metadata = findMBeanMetaData(objectName);
/*      */     
/*      */     try
/*      */     {
/*  943 */       MBeanServerInterceptor head = getHeadInterceptor();
/*  944 */       head.registration(metadata, 4);
/*      */       
/*  946 */       unregister(metadata);
/*      */       
/*  948 */       getHeadInterceptor().registration(metadata, 5);
/*      */       
/*  950 */       Object mbean = metadata.getMBean();
/*  951 */       if (((mbean instanceof ClassLoader)) && (!(mbean instanceof PrivateClassLoader)))
/*      */       {
/*  953 */         getModifiableClassLoaderRepository().removeClassLoader((ClassLoader)mbean);
/*      */       }
/*      */     }
/*      */     catch (MBeanRegistrationException x)
/*      */     {
/*  958 */       throw x;
/*      */     }
/*      */     catch (SecurityException x)
/*      */     {
/*  962 */       throw x;
/*      */     }
/*      */     catch (Exception x)
/*      */     {
/*  966 */       throw new MBeanRegistrationException(x);
/*      */     }
/*      */     catch (Error x)
/*      */     {
/*  970 */       throw new MBeanRegistrationException(new RuntimeErrorException(x));
/*      */     }
/*      */   }
/*      */   
/*      */   private void unregister(MBeanMetaData metadata)
/*      */   {
/*  976 */     ObjectName objectName = metadata.getObjectName();
/*      */     
/*  978 */     MBeanRepository repository = getMBeanRepository();
/*  979 */     synchronized (repository)
/*      */     {
/*  981 */       repository.remove(objectName);
/*      */     }
/*  983 */     removeDomain(objectName.getDomain());
/*      */     
/*  985 */     notify(objectName, "JMX.mbean.unregistered");
/*      */   }
/*      */   
/*      */   public Object getAttribute(ObjectName objectName, String attribute)
/*      */     throws InstanceNotFoundException, MBeanException, AttributeNotFoundException, ReflectionException
/*      */   {
/*  991 */     if ((attribute == null) || (attribute.trim().length() == 0))
/*      */     {
/*  993 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid attribute"));
/*      */     }
/*      */     
/*  996 */     objectName = secureObjectName(objectName);
/*      */     
/*  998 */     MBeanMetaData metadata = findMBeanMetaData(objectName);
/*      */     
/* 1000 */     return getHeadInterceptor().getAttribute(metadata, attribute);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setAttribute(ObjectName objectName, Attribute attribute)
/*      */     throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException
/*      */   {
/* 1007 */     if ((attribute == null) || (attribute.getName().trim().length() == 0))
/*      */     {
/* 1009 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid attribute"));
/*      */     }
/*      */     
/* 1012 */     objectName = secureObjectName(objectName);
/*      */     
/* 1014 */     MBeanMetaData metadata = findMBeanMetaData(objectName);
/*      */     
/* 1016 */     getHeadInterceptor().setAttribute(metadata, attribute);
/*      */   }
/*      */   
/*      */   public AttributeList getAttributes(ObjectName objectName, String[] attributes)
/*      */     throws InstanceNotFoundException, ReflectionException
/*      */   {
/* 1022 */     if (attributes == null)
/*      */     {
/* 1024 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid attribute list"));
/*      */     }
/*      */     
/* 1027 */     objectName = secureObjectName(objectName);
/*      */     
/* 1029 */     MBeanMetaData metadata = findMBeanMetaData(objectName);
/*      */     
/* 1031 */     SecurityManager sm = System.getSecurityManager();
/* 1032 */     if (sm != null)
/*      */     {
/*      */ 
/* 1035 */       sm.checkPermission(new MBeanPermission(metadata.getMBeanInfo().getClassName(), "-", objectName, "getAttribute"));
/*      */     }
/*      */     
/* 1038 */     return getHeadInterceptor().getAttributes(metadata, attributes);
/*      */   }
/*      */   
/*      */   public AttributeList setAttributes(ObjectName objectName, AttributeList attributes)
/*      */     throws InstanceNotFoundException, ReflectionException
/*      */   {
/* 1044 */     if (attributes == null)
/*      */     {
/* 1046 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid attribute list"));
/*      */     }
/*      */     
/* 1049 */     objectName = secureObjectName(objectName);
/*      */     
/* 1051 */     MBeanMetaData metadata = findMBeanMetaData(objectName);
/*      */     
/* 1053 */     SecurityManager sm = System.getSecurityManager();
/* 1054 */     if (sm != null)
/*      */     {
/*      */ 
/* 1057 */       sm.checkPermission(new MBeanPermission(metadata.getMBeanInfo().getClassName(), "-", objectName, "setAttribute"));
/*      */     }
/*      */     
/* 1060 */     return getHeadInterceptor().setAttributes(metadata, attributes);
/*      */   }
/*      */   
/*      */   public Object invoke(ObjectName objectName, String methodName, Object[] args, String[] parameters)
/*      */     throws InstanceNotFoundException, MBeanException, ReflectionException
/*      */   {
/* 1066 */     if ((methodName == null) || (methodName.trim().length() == 0))
/*      */     {
/* 1068 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid operation name '" + methodName + "'"));
/*      */     }
/*      */     
/* 1071 */     if (args == null) args = EMPTY_ARGS;
/* 1072 */     if (parameters == null) { parameters = EMPTY_PARAMS;
/*      */     }
/* 1074 */     objectName = secureObjectName(objectName);
/*      */     
/* 1076 */     MBeanMetaData metadata = findMBeanMetaData(objectName);
/*      */     
/* 1078 */     return getHeadInterceptor().invoke(metadata, methodName, parameters, args);
/*      */   }
/*      */   
/*      */   public String getDefaultDomain()
/*      */   {
/* 1083 */     return this.defaultDomain;
/*      */   }
/*      */   
/*      */   public String[] getDomains()
/*      */   {
/* 1088 */     synchronized (this.domains)
/*      */     {
/* 1090 */       Set keys = this.domains.keySet();
/* 1091 */       return (String[])keys.toArray(new String[keys.size()]);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public Integer getMBeanCount()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokespecial 157	mx4j/server/MX4JMBeanServer:getMBeanRepository	()Lmx4j/server/MBeanRepository;
/*      */     //   4: astore_1
/*      */     //   5: aload_1
/*      */     //   6: dup
/*      */     //   7: astore_2
/*      */     //   8: monitorenter
/*      */     //   9: new 241	java/lang/Integer
/*      */     //   12: dup
/*      */     //   13: aload_1
/*      */     //   14: invokeinterface 266 1 0
/*      */     //   19: invokespecial 242	java/lang/Integer:<init>	(I)V
/*      */     //   22: aload_2
/*      */     //   23: monitorexit
/*      */     //   24: areturn
/*      */     //   25: astore_3
/*      */     //   26: aload_2
/*      */     //   27: monitorexit
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1097	-> byte code offset #0
/*      */     //   Java source line #1098	-> byte code offset #5
/*      */     //   Java source line #1100	-> byte code offset #9
/*      */     //   Java source line #1101	-> byte code offset #25
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	this	MX4JMBeanServer
/*      */     //   4	10	1	repository	MBeanRepository
/*      */     //   7	20	2	Ljava/lang/Object;	Object
/*      */     //   25	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   9	24	25	finally
/*      */     //   25	28	25	finally
/*      */   }
/*      */   
/*      */   public boolean isRegistered(ObjectName objectName)
/*      */   {
/*      */     try
/*      */     {
/* 1108 */       return findMBeanMetaData(objectName) != null;
/*      */     }
/*      */     catch (InstanceNotFoundException x) {}
/*      */     
/* 1112 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public MBeanInfo getMBeanInfo(ObjectName objectName)
/*      */     throws InstanceNotFoundException, IntrospectionException, ReflectionException
/*      */   {
/* 1119 */     objectName = secureObjectName(objectName);
/*      */     
/* 1121 */     MBeanMetaData metadata = findMBeanMetaData(objectName);
/*      */     
/* 1123 */     MBeanInfo info = getHeadInterceptor().getMBeanInfo(metadata);
/* 1124 */     if (info == null) throw new JMRuntimeException("MBeanInfo returned for MBean " + objectName + " is null");
/* 1125 */     return info;
/*      */   }
/*      */   
/*      */   public ObjectInstance getObjectInstance(ObjectName objectName)
/*      */     throws InstanceNotFoundException
/*      */   {
/* 1131 */     SecurityManager sm = System.getSecurityManager();
/* 1132 */     if (sm != null)
/*      */     {
/* 1134 */       objectName = secureObjectName(objectName);
/*      */     }
/*      */     
/* 1137 */     MBeanMetaData metadata = findMBeanMetaData(objectName);
/*      */     
/* 1139 */     if (sm != null)
/*      */     {
/* 1141 */       sm.checkPermission(new MBeanPermission(metadata.getMBeanInfo().getClassName(), "-", objectName, "getObjectInstance"));
/*      */     }
/*      */     
/* 1144 */     return metadata.getObjectInstance();
/*      */   }
/*      */   
/*      */   public boolean isInstanceOf(ObjectName objectName, String className)
/*      */     throws InstanceNotFoundException
/*      */   {
/* 1150 */     if ((className == null) || (className.trim().length() == 0))
/*      */     {
/* 1152 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid class name"));
/*      */     }
/*      */     
/* 1155 */     objectName = secureObjectName(objectName);
/*      */     
/* 1157 */     MBeanMetaData metadata = findMBeanMetaData(objectName);
/*      */     
/* 1159 */     SecurityManager sm = System.getSecurityManager();
/* 1160 */     if (sm != null)
/*      */     {
/* 1162 */       sm.checkPermission(new MBeanPermission(metadata.getMBeanInfo().getClassName(), "-", objectName, "isInstanceOf"));
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1167 */       ClassLoader loader = metadata.getClassLoader();
/* 1168 */       if (loader == null) loader = Thread.currentThread().getContextClassLoader();
/* 1169 */       Class cls = loader.loadClass(className);
/*      */       
/* 1171 */       Object mbean = metadata.getMBean();
/* 1172 */       if ((mbean instanceof StandardMBean))
/*      */       {
/* 1174 */         Object impl = ((StandardMBean)mbean).getImplementation();
/* 1175 */         return cls.isInstance(impl);
/*      */       }
/*      */       
/*      */ 
/* 1179 */       return cls.isInstance(mbean);
/*      */     }
/*      */     catch (ClassNotFoundException x) {}
/*      */     
/*      */ 
/* 1184 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public Set queryMBeans(ObjectName patternName, QueryExp filter)
/*      */   {
/* 1190 */     SecurityManager sm = System.getSecurityManager();
/* 1191 */     if (sm != null)
/*      */     {
/* 1193 */       patternName = secureObjectName(patternName);
/*      */       
/*      */ 
/* 1196 */       sm.checkPermission(new MBeanPermission("-#-[-]", "queryMBeans"));
/*      */     }
/*      */     
/* 1199 */     Set match = queryObjectNames(patternName, filter, true);
/*      */     
/* 1201 */     Set set = new HashSet();
/* 1202 */     for (Iterator i = match.iterator(); i.hasNext();)
/*      */     {
/* 1204 */       ObjectName name = (ObjectName)i.next();
/*      */       try
/*      */       {
/* 1207 */         MBeanMetaData metadata = findMBeanMetaData(name);
/* 1208 */         set.add(metadata.getObjectInstance());
/*      */       }
/*      */       catch (InstanceNotFoundException ignored) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1215 */     return set;
/*      */   }
/*      */   
/*      */   public Set queryNames(ObjectName patternName, QueryExp filter)
/*      */   {
/* 1220 */     SecurityManager sm = System.getSecurityManager();
/* 1221 */     if (sm != null)
/*      */     {
/* 1223 */       patternName = secureObjectName(patternName);
/*      */       
/*      */ 
/* 1226 */       sm.checkPermission(new MBeanPermission("-#-[-]", "queryNames"));
/*      */     }
/*      */     
/* 1229 */     return queryObjectNames(patternName, filter, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Set queryObjectNames(ObjectName patternName, QueryExp filter, boolean instances)
/*      */   {
/* 1243 */     Set scope = findMBeansByPattern(patternName);
/*      */     
/*      */ 
/* 1246 */     Set secureScope = filterMBeansBySecurity(scope, instances);
/*      */     
/*      */ 
/* 1249 */     Set match = filterMBeansByQuery(secureScope, filter);
/*      */     
/* 1251 */     return match;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Set findMBeansByPattern(ObjectName pattern)
/*      */   {
/* 1259 */     if (pattern == null)
/*      */     {
/*      */       try
/*      */       {
/* 1263 */         pattern = new ObjectName("*:*");
/*      */       }
/*      */       catch (MalformedObjectNameException ignored) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1270 */     pattern = normalizeObjectName(pattern);
/*      */     
/* 1272 */     String patternDomain = pattern.getDomain();
/* 1273 */     Hashtable patternProps = pattern.getKeyPropertyList();
/*      */     
/* 1275 */     Set set = new HashSet();
/*      */     
/*      */ 
/* 1278 */     MBeanRepository repository = null;
/* 1279 */     MBeanRepository original = getMBeanRepository();
/* 1280 */     synchronized (original)
/*      */     {
/* 1282 */       repository = (MBeanRepository)original.clone();
/*      */     }
/*      */     
/* 1285 */     for (Iterator i = repository.iterator(); i.hasNext();)
/*      */     {
/* 1287 */       MBeanMetaData metadata = (MBeanMetaData)i.next();
/* 1288 */       ObjectName name = metadata.getObjectName();
/* 1289 */       Hashtable props = name.getKeyPropertyList();
/*      */       
/* 1291 */       String domain = name.getDomain();
/* 1292 */       if (Utils.wildcardMatch(patternDomain, domain))
/*      */       {
/*      */ 
/* 1295 */         if (pattern.isPropertyPattern())
/*      */         {
/*      */ 
/* 1298 */           if (patternProps.size() == 0)
/*      */           {
/*      */ 
/* 1301 */             set.add(name);
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 1307 */             boolean found = true;
/* 1308 */             for (Iterator j = patternProps.entrySet().iterator(); j.hasNext();)
/*      */             {
/* 1310 */               Map.Entry entry = (Map.Entry)j.next();
/* 1311 */               Object patternKey = entry.getKey();
/* 1312 */               Object patternValue = entry.getValue();
/* 1313 */               if (!patternKey.equals("*"))
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1319 */                 if (!props.containsKey(patternKey))
/*      */                 {
/*      */ 
/* 1322 */                   found = false;
/*      */ 
/*      */                 }
/*      */                 else
/*      */                 {
/*      */ 
/* 1328 */                   Object value = props.get(patternKey);
/* 1329 */                   if (((value != null) || (patternValue != null)) && (
/*      */                   
/*      */ 
/*      */ 
/*      */ 
/* 1334 */                     (value == null) || (!value.equals(patternValue))))
/*      */                   {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1340 */                     found = false; }
/*      */                 }
/*      */               }
/*      */             }
/* 1344 */             if (found) { set.add(name);
/*      */             }
/*      */             
/*      */           }
/*      */         }
/* 1349 */         else if (props.entrySet().equals(patternProps.entrySet())) { set.add(name);
/*      */         }
/*      */       }
/*      */     }
/* 1353 */     return set;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Set filterMBeansBySecurity(Set mbeans, boolean instances)
/*      */   {
/* 1362 */     SecurityManager sm = System.getSecurityManager();
/* 1363 */     if (sm == null) { return mbeans;
/*      */     }
/* 1365 */     HashSet set = new HashSet();
/* 1366 */     for (Iterator i = mbeans.iterator(); i.hasNext();)
/*      */     {
/* 1368 */       ObjectName name = (ObjectName)i.next();
/*      */       try
/*      */       {
/* 1371 */         MBeanMetaData metadata = findMBeanMetaData(name);
/* 1372 */         String className = metadata.getMBeanInfo().getClassName();
/* 1373 */         sm.checkPermission(new MBeanPermission(className, "-", name, instances ? "queryMBeans" : "queryNames"));
/* 1374 */         set.add(name);
/*      */       }
/*      */       catch (InstanceNotFoundException ignored) {}catch (SecurityException ignored) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1386 */     return set;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Set filterMBeansByQuery(Set scope, QueryExp filter)
/*      */   {
/* 1395 */     if (filter == null) { return scope;
/*      */     }
/* 1397 */     Set set = new HashSet();
/* 1398 */     for (Iterator i = scope.iterator(); i.hasNext();)
/*      */     {
/* 1400 */       ObjectName name = (ObjectName)i.next();
/* 1401 */       filter.setMBeanServer(this);
/*      */       try
/*      */       {
/* 1404 */         if (filter.apply(name)) { set.add(name);
/*      */         }
/*      */       }
/*      */       catch (BadStringOperationException ignored) {}catch (BadBinaryOpValueExpException ignored) {}catch (BadAttributeValueExpException x) {}catch (InvalidApplicationException x) {}catch (SecurityException x) {}catch (Exception x) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1426 */     return set;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ObjectName normalizeObjectName(ObjectName name)
/*      */   {
/* 1437 */     if (name == null) { return null;
/*      */     }
/* 1439 */     String defaultDomain = getDefaultDomain();
/* 1440 */     String domain = name.getDomain();
/*      */     
/* 1442 */     if ((domain.length() == 0) && (defaultDomain.length() > 0))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1447 */       StringBuffer buffer = new StringBuffer(defaultDomain).append(":").append(name.getKeyPropertyListString());
/* 1448 */       if (name.isPropertyPattern())
/*      */       {
/* 1450 */         if (name.getKeyPropertyList().size() > 0) {
/* 1451 */           buffer.append(",*");
/*      */         } else {
/* 1453 */           buffer.append("*");
/*      */         }
/*      */       }
/*      */       try {
/* 1457 */         name = new ObjectName(buffer.toString());
/*      */       }
/*      */       catch (MalformedObjectNameException ignored) {}
/*      */     }
/*      */     
/*      */ 
/* 1463 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ObjectName secureObjectName(ObjectName name)
/*      */   {
/* 1476 */     if (name == null) return null;
/* 1477 */     return ObjectName.getInstance(name);
/*      */   }
/*      */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/MX4JMBeanServer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */