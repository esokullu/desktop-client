/*     */ package mx4j.server;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.JMRuntimeException;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.RuntimeErrorException;
/*     */ import javax.management.RuntimeMBeanException;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ import mx4j.ImplementationException;
/*     */ import mx4j.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectionMBeanInvoker
/*     */   implements MBeanInvoker
/*     */ {
/*  39 */   protected static final String[] EMPTY_PARAMS = new String[0];
/*     */   
/*     */ 
/*     */ 
/*  43 */   protected static final Object[] EMPTY_ARGS = new Object[0];
/*     */   
/*     */   public Object invoke(MBeanMetaData metadata, String method, String[] params, Object[] args) throws MBeanException, ReflectionException
/*     */   {
/*  47 */     MBeanOperationInfo oper = getStandardOperationInfo(metadata, method, params);
/*  48 */     if (oper != null)
/*     */     {
/*     */       try
/*     */       {
/*  52 */         return doInvoke(metadata, method, params, args);
/*     */       }
/*     */       catch (BadArgumentException x)
/*     */       {
/*  56 */         throw new RuntimeOperationsException(x.nested);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  61 */     throw new ReflectionException(new NoSuchMethodException("Operation " + method + " does not belong to the management interface"));
/*     */   }
/*     */   
/*     */   public Object getAttribute(MBeanMetaData metadata, String attribute)
/*     */     throws MBeanException, AttributeNotFoundException, ReflectionException
/*     */   {
/*  67 */     MBeanAttributeInfo attr = getStandardAttributeInfo(metadata, attribute, false);
/*  68 */     if (attr != null)
/*     */     {
/*  70 */       String methodName = getMethodForAttribute(attr, true);
/*     */       try
/*     */       {
/*  73 */         return doInvoke(metadata, methodName, EMPTY_PARAMS, EMPTY_ARGS);
/*     */ 
/*     */       }
/*     */       catch (BadArgumentException x)
/*     */       {
/*  78 */         throw new ImplementationException();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  83 */     throw new AttributeNotFoundException(attribute);
/*     */   }
/*     */   
/*     */   public void setAttribute(MBeanMetaData metadata, Attribute attribute)
/*     */     throws MBeanException, AttributeNotFoundException, InvalidAttributeValueException, ReflectionException
/*     */   {
/*  89 */     String name = attribute.getName();
/*  90 */     MBeanAttributeInfo attr = getStandardAttributeInfo(metadata, name, true);
/*  91 */     if (attr != null)
/*     */     {
/*  93 */       String methodName = getMethodForAttribute(attr, false);
/*     */       try
/*     */       {
/*  96 */         doInvoke(metadata, methodName, new String[] { attr.getType() }, new Object[] { attribute.getValue() });
/*     */       }
/*     */       catch (BadArgumentException x)
/*     */       {
/* 100 */         throw new InvalidAttributeValueException("Invalid value for attribute " + name + ": " + attribute.getValue());
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 105 */       throw new AttributeNotFoundException(name);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object doInvoke(MBeanMetaData metadata, String method, String[] signature, Object[] args)
/*     */     throws ReflectionException, MBeanException, ReflectionMBeanInvoker.BadArgumentException
/*     */   {
/*     */     try
/*     */     {
/* 117 */       return invokeImpl(metadata, method, signature, args);
/*     */     }
/*     */     catch (ReflectionException x)
/*     */     {
/* 121 */       throw x;
/*     */     }
/*     */     catch (MBeanException x)
/*     */     {
/* 125 */       throw x;
/*     */     }
/*     */     catch (BadArgumentException x)
/*     */     {
/* 129 */       throw x;
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 133 */       if ((t instanceof Error)) throw new RuntimeErrorException((Error)t);
/* 134 */       if ((t instanceof JMRuntimeException)) throw ((JMRuntimeException)t);
/* 135 */       if ((t instanceof RuntimeException)) throw new RuntimeMBeanException((RuntimeException)t);
/* 136 */       throw new MBeanException((Exception)t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object invokeImpl(MBeanMetaData metadata, String method, String[] signature, Object[] args)
/*     */     throws Throwable
/*     */   {
/* 147 */     Method m = getStandardManagementMethod(metadata, method, signature);
/*     */     try
/*     */     {
/* 150 */       return m.invoke(metadata.getMBean(), args);
/*     */     }
/*     */     catch (IllegalAccessException x)
/*     */     {
/* 154 */       throw new ReflectionException(x);
/*     */     }
/*     */     catch (IllegalArgumentException x)
/*     */     {
/* 158 */       throw new BadArgumentException(x, null);
/*     */     }
/*     */     catch (InvocationTargetException x)
/*     */     {
/* 162 */       throw x.getTargetException();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanOperationInfo getStandardOperationInfo(MBeanMetaData metadata, String method, String[] signature)
/*     */   {
/* 172 */     MBeanOperationInfo[] opers = metadata.getMBeanInfo().getOperations();
/* 173 */     if (opers != null)
/*     */     {
/* 175 */       for (int i = 0; i < opers.length; i++)
/*     */       {
/* 177 */         MBeanOperationInfo oper = opers[i];
/* 178 */         String name = oper.getName();
/* 179 */         if (method.equals(name))
/*     */         {
/*     */ 
/* 182 */           MBeanParameterInfo[] params = oper.getSignature();
/* 183 */           if (signature.length == params.length)
/*     */           {
/* 185 */             boolean match = true;
/* 186 */             for (int j = 0; j < params.length; j++)
/*     */             {
/* 188 */               MBeanParameterInfo param = params[j];
/* 189 */               if (!signature[j].equals(param.getType()))
/*     */               {
/* 191 */                 match = false;
/* 192 */                 break;
/*     */               }
/*     */             }
/* 195 */             if (match) return oper;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 200 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanAttributeInfo getStandardAttributeInfo(MBeanMetaData metadata, String attribute, boolean forWrite)
/*     */   {
/* 209 */     MBeanAttributeInfo[] attrs = metadata.getMBeanInfo().getAttributes();
/* 210 */     if (attrs != null)
/*     */     {
/* 212 */       for (int i = 0; i < attrs.length; i++)
/*     */       {
/* 214 */         MBeanAttributeInfo attr = attrs[i];
/* 215 */         String name = attr.getName();
/* 216 */         if (attribute.equals(name))
/*     */         {
/* 218 */           if ((forWrite) && (attr.isWritable())) return attr;
/* 219 */           if ((!forWrite) && (attr.isReadable())) return attr;
/*     */         }
/*     */       }
/*     */     }
/* 223 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getMethodForAttribute(MBeanAttributeInfo attribute, boolean forRead)
/*     */   {
/* 231 */     String name = attribute.getName();
/* 232 */     String attributeName = null;
/* 233 */     if (forRead)
/*     */     {
/* 235 */       String prefix = attribute.isIs() ? "is" : "get";
/* 236 */       attributeName = prefix + name;
/*     */     }
/*     */     else
/*     */     {
/* 240 */       attributeName = "set" + name;
/*     */     }
/* 242 */     return attributeName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Method getStandardManagementMethod(MBeanMetaData metadata, String name, String[] signature)
/*     */     throws ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 252 */       Class[] params = Utils.loadClasses(metadata.getClassLoader(), signature);
/* 253 */       return metadata.getMBeanInterface().getMethod(name, params);
/*     */ 
/*     */     }
/*     */     catch (ClassNotFoundException x)
/*     */     {
/* 258 */       throw new ReflectionException(x);
/*     */     }
/*     */     catch (NoSuchMethodException x)
/*     */     {
/* 262 */       throw new ReflectionException(x); } }
/*     */   
/*     */   private static class BadArgumentException extends Exception { private final IllegalArgumentException nested;
/*     */     
/* 266 */     BadArgumentException(IllegalArgumentException x0, ReflectionMBeanInvoker.1 x1) { this(x0); }
/*     */     
/*     */ 
/*     */ 
/*     */     private BadArgumentException(IllegalArgumentException nested)
/*     */     {
/* 272 */       this.nested = nested;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/ReflectionMBeanInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */