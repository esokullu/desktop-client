/*     */ package mx4j.server;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface MBeanMetaData
/*     */ {
/*     */   public abstract void setMBean(Object paramObject);
/*     */   
/*     */   public abstract Object getMBean();
/*     */   
/*     */   public abstract void setClassLoader(ClassLoader paramClassLoader);
/*     */   
/*     */   public abstract ClassLoader getClassLoader();
/*     */   
/*     */   public abstract void setObjectName(ObjectName paramObjectName);
/*     */   
/*     */   public abstract ObjectName getObjectName();
/*     */   
/*     */   public abstract void setMBeanInfo(MBeanInfo paramMBeanInfo);
/*     */   
/*     */   public abstract MBeanInfo getMBeanInfo();
/*     */   
/*     */   public abstract void setMBeanInterface(Class paramClass);
/*     */   
/*     */   public abstract Class getMBeanInterface();
/*     */   
/*     */   public abstract void setMBeanStandard(boolean paramBoolean);
/*     */   
/*     */   public abstract boolean isMBeanStandard();
/*     */   
/*     */   public abstract void setMBeanDynamic(boolean paramBoolean);
/*     */   
/*     */   public abstract boolean isMBeanDynamic();
/*     */   
/*     */   public abstract void setMBeanInvoker(MBeanInvoker paramMBeanInvoker);
/*     */   
/*     */   public abstract MBeanInvoker getMBeanInvoker();
/*     */   
/*     */   public abstract ObjectInstance getObjectInstance();
/*     */   
/*     */   public static class Factory
/*     */   {
/*     */     public static MBeanMetaData create()
/*     */     {
/* 156 */       String className = (String)AccessController.doPrivileged(new MBeanMetaData.1());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 163 */       if (className == null) { className = "mx4j.server.MX4JMBeanMetaData";
/*     */       }
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 169 */         return (MBeanMetaData)(MBeanMetaData.2.class$mx4j$server$MBeanMetaData == null ? (MBeanMetaData.2.class$mx4j$server$MBeanMetaData = MBeanMetaData.2.class$("mx4j.server.MBeanMetaData")) : MBeanMetaData.2.class$mx4j$server$MBeanMetaData).getClassLoader().loadClass(className).newInstance();
/*     */ 
/*     */       }
/*     */       catch (ClassNotFoundException x)
/*     */       {
/* 174 */         return (MBeanMetaData)Thread.currentThread().getContextClassLoader().loadClass(className).newInstance();
/*     */ 
/*     */       }
/*     */       catch (Exception x)
/*     */       {
/* 179 */         throw new Error(x.toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/server/MBeanMetaData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */