package mx4j.persist;

public abstract class Persister
  implements PersisterMBean
{}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/persist/Persister.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */