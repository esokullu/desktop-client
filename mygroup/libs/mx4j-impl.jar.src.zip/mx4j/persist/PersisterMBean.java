package mx4j.persist;

import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.RuntimeOperationsException;

public abstract interface PersisterMBean
{
  public abstract Object load()
    throws MBeanException, RuntimeOperationsException, InstanceNotFoundException;
  
  public abstract void store(Object paramObject)
    throws MBeanException, RuntimeOperationsException, InstanceNotFoundException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/persist/PersisterMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */