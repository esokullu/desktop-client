/*     */ package mx4j.persist;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.NotSerializableException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ import mx4j.loading.ClassLoaderObjectInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilePersister
/*     */   extends Persister
/*     */ {
/*     */   private File m_store;
/*     */   
/*     */   public FilePersister(String location, String name)
/*     */     throws MBeanException
/*     */   {
/*  44 */     if (name == null)
/*     */     {
/*  46 */       throw new MBeanException(new IllegalArgumentException("Persist name cannot be null"));
/*     */     }
/*     */     
/*  49 */     if (location != null)
/*     */     {
/*  51 */       File dir = new File(location);
/*  52 */       if (!dir.exists())
/*     */       {
/*  54 */         throw new MBeanException(new FileNotFoundException(location));
/*     */       }
/*  56 */       this.m_store = new File(dir, name);
/*     */     }
/*     */     else
/*     */     {
/*  60 */       this.m_store = new File(name);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFileName()
/*     */   {
/*  69 */     return this.m_store.getAbsolutePath();
/*     */   }
/*     */   
/*     */   public Object load() throws MBeanException, RuntimeOperationsException, InstanceNotFoundException
/*     */   {
/*  74 */     FileInputStream fin = null;
/*  75 */     ObjectInputStream clois = null;
/*  76 */     Object result = null;
/*     */     
/*  78 */     synchronized (this)
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/*  83 */         fin = new FileInputStream(this.m_store);
/*     */         
/*     */ 
/*  86 */         clois = new ClassLoaderObjectInputStream(fin, Thread.currentThread().getContextClassLoader());
/*     */         
/*     */         try
/*     */         {
/*  90 */           result = clois.readObject();
/*     */ 
/*     */         }
/*     */         catch (ClassNotFoundException ex)
/*     */         {
/*     */ 
/*     */           try
/*     */           {
/*  98 */             clois.close();
/*     */           }
/*     */           catch (IOException ignored) {}
/*     */           
/*     */ 
/*     */ 
/* 104 */           throw new MBeanException(ex);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */         throw new MBeanException(ex);
/*     */       }
/*     */       finally
/*     */       {
/*     */         try
/*     */         {
/* 128 */           if (clois != null) { clois.close();
/*     */           }
/*     */         }
/*     */         catch (IOException ignored) {}
/*     */       }
/*     */     }
/*     */     
/* 135 */     return result;
/*     */   }
/*     */   
/*     */   public void store(Object data) throws MBeanException, RuntimeOperationsException, InstanceNotFoundException
/*     */   {
/* 140 */     if (data == null) throw new RuntimeOperationsException(new IllegalArgumentException("Cannot store a null object."));
/* 141 */     if (!(data instanceof Serializable)) { throw new MBeanException(new NotSerializableException(data.getClass().getName() + " must implement java.io.Serializable"));
/*     */     }
/* 143 */     FileOutputStream fos = null;
/* 144 */     ObjectOutputStream oos = null;
/* 145 */     synchronized (this)
/*     */     {
/*     */       try
/*     */       {
/* 149 */         fos = new FileOutputStream(this.m_store);
/* 150 */         oos = new ObjectOutputStream(fos);
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 154 */         throw new MBeanException(ex);
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 159 */         oos.writeObject(data);
/*     */         
/* 161 */         oos.flush();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 171 */           oos.close();
/*     */         }
/*     */         catch (IOException ex) {}
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 165 */         throw new MBeanException(ex);
/*     */       }
/*     */       finally
/*     */       {
/*     */         try
/*     */         {
/* 171 */           oos.close();
/*     */         }
/*     */         catch (IOException ex) {}
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/persist/FilePersister.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */