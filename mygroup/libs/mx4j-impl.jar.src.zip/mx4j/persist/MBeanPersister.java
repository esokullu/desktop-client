/*    */ package mx4j.persist;
/*    */ 
/*    */ import javax.management.InstanceNotFoundException;
/*    */ import javax.management.MBeanException;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.MBeanServerInvocationHandler;
/*    */ import javax.management.ObjectName;
/*    */ import javax.management.RuntimeOperationsException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanPersister
/*    */   extends Persister
/*    */ {
/*    */   private MBeanServer m_server;
/*    */   private ObjectName m_name;
/*    */   private PersisterMBean m_proxy;
/*    */   
/*    */   public MBeanPersister(MBeanServer server, ObjectName name)
/*    */   {
/* 35 */     this.m_server = server;
/* 36 */     this.m_name = name;
/* 37 */     this.m_proxy = ((PersisterMBean)MBeanServerInvocationHandler.newProxyInstance(server, name, PersisterMBean.class, false));
/*    */   }
/*    */   
/*    */   public Object load() throws MBeanException, RuntimeOperationsException, InstanceNotFoundException
/*    */   {
/* 42 */     return this.m_proxy.load();
/*    */   }
/*    */   
/*    */   public void store(Object data) throws MBeanException, RuntimeOperationsException, InstanceNotFoundException
/*    */   {
/* 47 */     this.m_proxy.store(data);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/persist/MBeanPersister.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */