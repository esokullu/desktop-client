/*     */ package mx4j.monitor;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanRegistration;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationBroadcasterSupport;
/*     */ import javax.management.NotificationEmitter;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.StandardMBean;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import mx4j.timer.TimeQueue;
/*     */ import mx4j.timer.TimeTask;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MX4JMonitor
/*     */   extends StandardMBean
/*     */   implements MX4JMonitorMBean, MBeanRegistration, NotificationEmitter
/*     */ {
/*  50 */   private static TimeQueue queue = new TimeQueue();
/*     */   
/*     */   private static int sequenceNumber;
/*     */   private NotificationBroadcasterSupport emitter;
/*     */   private MBeanServer server;
/*     */   private boolean active;
/*  56 */   private List observeds = new ArrayList();
/*     */   private volatile String attribute;
/*  58 */   private volatile long granularity = 10000L;
/*     */   private boolean errorNotified;
/*     */   
/*     */   static
/*     */   {
/*  63 */     queue.start();
/*     */   }
/*     */   
/*  66 */   private final TimeTask task = new MonitorTask(null);
/*  67 */   private final Map infos = new HashMap();
/*     */   
/*     */   protected MX4JMonitor(Class management) throws NotCompliantMBeanException
/*     */   {
/*  71 */     super(management);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ObjectName preRegister(MBeanServer server, ObjectName name)
/*     */   {
/*  78 */     this.server = server;
/*  79 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void preDeregister()
/*     */   {
/*  88 */     stop();
/*     */   }
/*     */   
/*     */   public void postDeregister()
/*     */   {
/*  93 */     this.server = null;
/*     */   }
/*     */   
/*     */   protected NotificationBroadcasterSupport createNotificationEmitter()
/*     */   {
/*  98 */     return new NotificationBroadcasterSupport();
/*     */   }
/*     */   
/*     */   public void addNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback) throws IllegalArgumentException
/*     */   {
/* 103 */     this.emitter.addNotificationListener(listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(NotificationListener listener) throws ListenerNotFoundException
/*     */   {
/* 108 */     this.emitter.removeNotificationListener(listener);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback) throws ListenerNotFoundException
/*     */   {
/* 113 */     this.emitter.removeNotificationListener(listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void sendNotification(Notification notification)
/*     */   {
/* 118 */     this.emitter.sendNotification(notification);
/*     */   }
/*     */   
/*     */   public synchronized void start()
/*     */   {
/* 123 */     if (isActive()) return;
/* 124 */     this.active = true;
/* 125 */     startMonitor();
/*     */   }
/*     */   
/*     */   public synchronized void stop()
/*     */   {
/* 130 */     if (!isActive()) return;
/* 131 */     this.active = false;
/* 132 */     stopMonitor();
/*     */   }
/*     */   
/*     */   public synchronized boolean isActive()
/*     */   {
/* 137 */     return this.active;
/*     */   }
/*     */   
/*     */   public synchronized void addObservedObject(ObjectName name) throws IllegalArgumentException
/*     */   {
/* 142 */     if (name == null) throw new IllegalArgumentException("Observed ObjectName cannot be null");
/* 143 */     if (!containsObservedObject(name))
/*     */     {
/* 145 */       this.observeds.add(name);
/* 146 */       putMonitorInfo(name, createMonitorInfo());
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void removeObservedObject(ObjectName name)
/*     */   {
/* 152 */     this.observeds.remove(name);
/* 153 */     removeMonitorInfo(name);
/*     */   }
/*     */   
/*     */   public synchronized boolean containsObservedObject(ObjectName name)
/*     */   {
/* 158 */     return this.observeds.contains(name);
/*     */   }
/*     */   
/*     */   public synchronized ObjectName[] getObservedObjects()
/*     */   {
/* 163 */     return (ObjectName[])this.observeds.toArray(new ObjectName[this.observeds.size()]);
/*     */   }
/*     */   
/*     */   public synchronized void clearObservedObjects()
/*     */   {
/* 168 */     this.observeds.clear();
/*     */   }
/*     */   
/*     */   public synchronized String getObservedAttribute()
/*     */   {
/* 173 */     return this.attribute;
/*     */   }
/*     */   
/*     */   public synchronized void setObservedAttribute(String attribute)
/*     */   {
/* 178 */     this.attribute = attribute;
/*     */   }
/*     */   
/*     */   public synchronized long getGranularityPeriod()
/*     */   {
/* 183 */     return this.granularity;
/*     */   }
/*     */   
/*     */   public synchronized void setGranularityPeriod(long granularity) throws IllegalArgumentException
/*     */   {
/* 188 */     if (granularity <= 0L) throw new IllegalArgumentException("Granularity must be greater than zero");
/* 189 */     this.granularity = granularity;
/*     */   }
/*     */   
/*     */   protected void startMonitor()
/*     */   {
/* 194 */     if (this.emitter == null) this.emitter = createNotificationEmitter();
/* 195 */     queue.schedule(this.task);
/*     */   }
/*     */   
/*     */   protected void stopMonitor()
/*     */   {
/* 200 */     queue.unschedule(this.task);
/*     */   }
/*     */   
/*     */   protected Logger getLogger()
/*     */   {
/* 205 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */   
/*     */   protected void sendNotification(String type, String message, ObjectName name, String attribute, Object gauge, Object trigger)
/*     */   {
/* 210 */     int sequence = 0;
/* 211 */     synchronized (MX4JMonitor.class)
/*     */     {
/* 213 */       sequence = ++sequenceNumber;
/*     */     }
/*     */     
/* 216 */     Notification notification = createMonitorNotification(type, sequence, message, name, attribute, gauge, trigger);
/* 217 */     sendNotification(notification);
/*     */   }
/*     */   
/*     */   protected Notification createMonitorNotification(String type, long sequence, String message, ObjectName observed, String attribute, Object gauge, Object trigger)
/*     */   {
/* 222 */     return new MX4JMonitorNotification(type, this, sequence, System.currentTimeMillis(), message, observed, attribute, gauge, trigger);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized MonitorInfo getMonitorInfo(ObjectName name)
/*     */   {
/* 231 */     return (MonitorInfo)this.infos.get(name);
/*     */   }
/*     */   
/*     */   protected synchronized void putMonitorInfo(ObjectName name, MonitorInfo info)
/*     */   {
/* 236 */     this.infos.put(name, info);
/*     */   }
/*     */   
/*     */   protected synchronized void removeMonitorInfo(ObjectName name)
/*     */   {
/* 241 */     this.infos.remove(name);
/*     */   }
/*     */   
/*     */   protected void sendErrorNotification(MonitorInfo info, String type, String message, ObjectName observed, String attribute)
/*     */   {
/* 246 */     if (!info.isErrorNotified())
/*     */     {
/* 248 */       info.setErrorNotified(true);
/* 249 */       sendNotification(type, message, observed, attribute, null, null); } }
/*     */   
/*     */   public void postRegister(Boolean registrationDone) {}
/*     */   
/* 253 */   private class MonitorTask extends TimeTask { MonitorTask(MX4JMonitor.1 x1) { this(); }
/*     */     
/*     */     protected boolean isPeriodic()
/*     */     {
/* 257 */       return true;
/*     */     }
/*     */     
/*     */     protected long getPeriod()
/*     */     {
/* 262 */       return MX4JMonitor.this.getGranularityPeriod();
/*     */     }
/*     */     
/*     */     public boolean getFixedRate()
/*     */     {
/* 267 */       return true;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 272 */       if (!MX4JMonitor.this.isActive()) { return;
/*     */       }
/* 274 */       long start = System.currentTimeMillis();
/*     */       
/* 276 */       String attribute = MX4JMonitor.this.getObservedAttribute();
/*     */       
/* 278 */       if (MX4JMonitor.this.server == null)
/*     */       {
/* 280 */         if (!MX4JMonitor.this.errorNotified)
/*     */         {
/* 282 */           MX4JMonitor.this.errorNotified = true;
/* 283 */           MX4JMonitor.this.sendNotification("jmx.monitor.error.runtime", "Monitors must be registered in the MBeanServer", null, attribute, null, null);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 288 */         MX4JMonitor.this.errorNotified = false;
/*     */         
/*     */ 
/* 291 */         if (attribute != null)
/*     */         {
/* 293 */           ObjectName[] names = MX4JMonitor.this.getObservedObjects();
/*     */           
/* 295 */           for (int i = 0; i < names.length; i++)
/*     */           {
/* 297 */             ObjectName name = names[i];
/* 298 */             MX4JMonitor.MonitorInfo info = MX4JMonitor.this.getMonitorInfo(name);
/* 299 */             if (info != null) {
/*     */               try
/*     */               {
/* 302 */                 Object value = MX4JMonitor.this.server.getAttribute(name, attribute);
/*     */                 
/* 304 */                 if (value != null)
/*     */                 {
/* 306 */                   MX4JMonitor.this.monitor(name, attribute, value, info);
/*     */                 }
/*     */               }
/*     */               catch (InstanceNotFoundException x)
/*     */               {
/* 311 */                 MX4JMonitor.this.sendErrorNotification(info, "jmx.monitor.error.mbean", "Could not find observed MBean", name, attribute);
/*     */               }
/*     */               catch (AttributeNotFoundException x)
/*     */               {
/* 315 */                 MX4JMonitor.this.sendErrorNotification(info, "jmx.monitor.error.attribute", "Could not find observed attribute " + attribute, name, attribute);
/*     */               }
/*     */               catch (MBeanException x)
/*     */               {
/* 319 */                 MX4JMonitor.this.sendErrorNotification(info, "jmx.monitor.error.runtime", x.toString(), name, attribute);
/*     */               }
/*     */               catch (ReflectionException x)
/*     */               {
/* 323 */                 MX4JMonitor.this.sendErrorNotification(info, "jmx.monitor.error.runtime", x.toString(), name, attribute);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 329 */       long end = System.currentTimeMillis();
/* 330 */       long elapsed = end - start;
/* 331 */       Logger logger = MX4JMonitor.this.getLogger();
/* 332 */       if (logger.isEnabledFor(10)) logger.debug("Monitored attribute " + attribute + " in " + elapsed + " ms"); }
/*     */     
/*     */     private MonitorTask() {} }
/*     */   
/*     */   protected abstract void monitor(ObjectName paramObjectName, String paramString, Object paramObject, MonitorInfo paramMonitorInfo);
/*     */   
/*     */   protected abstract MonitorInfo createMonitorInfo();
/*     */   
/*     */   protected class MonitorInfo { protected MonitorInfo() {}
/*     */     
/* 342 */     public boolean isErrorNotified() { return this.errorNotified; }
/*     */     
/*     */     private boolean errorNotified;
/*     */     public void setErrorNotified(boolean errorNotified)
/*     */     {
/* 347 */       this.errorNotified = errorNotified;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 352 */       return "errorNotified=" + isErrorNotified();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/monitor/MX4JMonitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */