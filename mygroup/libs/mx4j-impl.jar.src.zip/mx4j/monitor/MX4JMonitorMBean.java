package mx4j.monitor;

import javax.management.ObjectName;

public abstract interface MX4JMonitorMBean
{
  public abstract void start();
  
  public abstract void stop();
  
  public abstract boolean isActive();
  
  public abstract void addObservedObject(ObjectName paramObjectName)
    throws IllegalArgumentException;
  
  public abstract void removeObservedObject(ObjectName paramObjectName);
  
  public abstract boolean containsObservedObject(ObjectName paramObjectName);
  
  public abstract ObjectName[] getObservedObjects();
  
  public abstract String getObservedAttribute();
  
  public abstract void setObservedAttribute(String paramString);
  
  public abstract long getGranularityPeriod();
  
  public abstract void setGranularityPeriod(long paramLong)
    throws IllegalArgumentException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/monitor/MX4JMonitorMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */