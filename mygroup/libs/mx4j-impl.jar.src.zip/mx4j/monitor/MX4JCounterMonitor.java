/*     */ package mx4j.monitor;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MX4JCounterMonitor
/*     */   extends MX4JMonitor
/*     */   implements MX4JCounterMonitorMBean
/*     */ {
/*  24 */   private static Integer ZERO = new Integer(0);
/*     */   
/*  26 */   private Number threshold = ZERO;
/*  27 */   private Number offset = ZERO;
/*  28 */   private Number modulus = ZERO;
/*     */   private boolean notify;
/*     */   private boolean differenceMode;
/*     */   
/*     */   public MX4JCounterMonitor() throws NotCompliantMBeanException
/*     */   {
/*  34 */     super(MX4JCounterMonitorMBean.class);
/*     */   }
/*     */   
/*     */   protected MX4JCounterMonitor(Class management) throws NotCompliantMBeanException
/*     */   {
/*  39 */     super(management);
/*     */   }
/*     */   
/*     */ 
/*     */   public MBeanNotificationInfo[] getNotificationInfo()
/*     */   {
/*  45 */     return new MBeanNotificationInfo[0];
/*     */   }
/*     */   
/*     */   public synchronized Number getInitThreshold()
/*     */   {
/*  50 */     return this.threshold;
/*     */   }
/*     */   
/*     */   public void setInitThreshold(Number threshold) throws IllegalArgumentException
/*     */   {
/*  55 */     if ((threshold == null) || (compare(threshold, ZERO) < 0)) throw new IllegalArgumentException("Threshold cannot be " + threshold);
/*  56 */     this.threshold = threshold;
/*     */   }
/*     */   
/*     */   public synchronized Number getOffset()
/*     */   {
/*  61 */     return this.offset;
/*     */   }
/*     */   
/*     */   public void setOffset(Number offset) throws IllegalArgumentException
/*     */   {
/*  66 */     if ((offset == null) || (compare(offset, ZERO) < 0)) throw new IllegalArgumentException("Offset cannot be " + offset);
/*  67 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public Number getModulus()
/*     */   {
/*  72 */     return this.modulus;
/*     */   }
/*     */   
/*     */   public void setModulus(Number modulus) throws IllegalArgumentException
/*     */   {
/*  77 */     if ((modulus == null) || (compare(modulus, ZERO) < 0)) throw new IllegalArgumentException("Modulus cannot be " + modulus);
/*  78 */     this.modulus = modulus;
/*     */   }
/*     */   
/*     */   public boolean getNotify()
/*     */   {
/*  83 */     return this.notify;
/*     */   }
/*     */   
/*     */   public void setNotify(boolean notify)
/*     */   {
/*  88 */     this.notify = notify;
/*     */   }
/*     */   
/*     */   public boolean getDifferenceMode()
/*     */   {
/*  93 */     return this.differenceMode;
/*     */   }
/*     */   
/*     */   public void setDifferenceMode(boolean mode)
/*     */   {
/*  98 */     this.differenceMode = mode;
/*     */   }
/*     */   
/*     */   public Number getDerivedGauge(ObjectName name)
/*     */   {
/* 103 */     CounterMonitorInfo info = (CounterMonitorInfo)getMonitorInfo(name);
/* 104 */     return info.getGauge();
/*     */   }
/*     */   
/*     */   public long getDerivedGaugeTimeStamp(ObjectName name)
/*     */   {
/* 109 */     CounterMonitorInfo info = (CounterMonitorInfo)getMonitorInfo(name);
/* 110 */     return info.getTimestamp();
/*     */   }
/*     */   
/*     */   public Number getThreshold(ObjectName name)
/*     */   {
/* 115 */     CounterMonitorInfo info = (CounterMonitorInfo)getMonitorInfo(name);
/* 116 */     return info.getThreshold();
/*     */   }
/*     */   
/*     */   protected int compare(Number left, Number right)
/*     */   {
/* 121 */     if (((left instanceof BigInteger)) && ((right instanceof BigInteger))) return ((BigInteger)left).compareTo((BigInteger)right);
/* 122 */     if (left.longValue() == right.longValue()) return 0;
/* 123 */     return left.longValue() > right.longValue() ? 1 : -1;
/*     */   }
/*     */   
/*     */   protected Number sum(Number left, Number right)
/*     */   {
/* 128 */     if (((left instanceof BigInteger)) && ((right instanceof BigInteger))) return ((BigInteger)left).add((BigInteger)right);
/* 129 */     if ((left instanceof BigInteger)) return ((BigInteger)left).add(BigInteger.valueOf(right.longValue()));
/* 130 */     if ((right instanceof BigInteger)) return ((BigInteger)right).add(BigInteger.valueOf(left.longValue()));
/* 131 */     if (((left instanceof Long)) || ((right instanceof Long))) return new Long(left.longValue() + right.longValue());
/* 132 */     if (((left instanceof Integer)) || ((right instanceof Integer))) return new Integer(left.intValue() + right.intValue());
/* 133 */     if (((left instanceof Short)) || ((right instanceof Short))) return new Short((short)(left.shortValue() + right.shortValue()));
/* 134 */     if (((left instanceof Byte)) || ((right instanceof Byte))) return new Byte((byte)(left.byteValue() + right.byteValue()));
/* 135 */     return null;
/*     */   }
/*     */   
/*     */   protected Number sub(Number left, Number right)
/*     */   {
/* 140 */     if (((left instanceof BigInteger)) && ((right instanceof BigInteger))) return ((BigInteger)left).subtract((BigInteger)right);
/* 141 */     if ((left instanceof BigInteger)) return ((BigInteger)left).subtract(BigInteger.valueOf(right.longValue()));
/* 142 */     if (((left instanceof Long)) || ((right instanceof Long))) return new Long(left.longValue() - right.longValue());
/* 143 */     if (((left instanceof Integer)) || ((right instanceof Integer))) return new Integer(left.intValue() - right.intValue());
/* 144 */     if (((left instanceof Short)) || ((right instanceof Short))) return new Short((short)(left.shortValue() - right.shortValue()));
/* 145 */     if (((left instanceof Byte)) || ((right instanceof Byte))) return new Byte((byte)(left.byteValue() - right.byteValue()));
/* 146 */     return null;
/*     */   }
/*     */   
/*     */   protected void monitor(ObjectName name, String attribute, Object value, MX4JMonitor.MonitorInfo monitorInfo)
/*     */   {
/* 151 */     if (!(value instanceof Number))
/*     */     {
/* 153 */       sendErrorNotification(monitorInfo, "jmx.monitor.error.type", "Attribute type must be a Number, not " + value.getClass(), name, attribute);
/* 154 */       return;
/*     */     }
/*     */     
/* 157 */     Number gauge = (Number)value;
/*     */     
/* 159 */     if (compare(gauge, ZERO) < 0)
/*     */     {
/*     */ 
/* 162 */       sendErrorNotification(monitorInfo, "jmx.monitor.error.threshold", "Attribute value cannot be negative " + gauge, name, attribute);
/* 163 */       return;
/*     */     }
/*     */     
/*     */ 
/* 167 */     Number threshold = null;
/* 168 */     Number offset = null;
/* 169 */     Number modulus = null;
/* 170 */     synchronized (this)
/*     */     {
/* 172 */       threshold = getThreshold(name);
/* 173 */       offset = getOffset();
/* 174 */       modulus = getModulus();
/*     */     }
/* 176 */     Class gaugeClass = gauge.getClass();
/* 177 */     if ((threshold != ZERO) && (threshold.getClass() != gaugeClass))
/*     */     {
/* 179 */       sendErrorNotification(monitorInfo, "jmx.monitor.error.threshold", "Threshold type " + threshold.getClass() + " must be of same type of the attribute " + gaugeClass, name, attribute);
/* 180 */       return;
/*     */     }
/* 182 */     if ((offset != ZERO) && (offset.getClass() != gaugeClass))
/*     */     {
/* 184 */       sendErrorNotification(monitorInfo, "jmx.monitor.error.threshold", "Offset type " + offset.getClass() + " must be of same type of the attribute " + gaugeClass, name, attribute);
/* 185 */       return;
/*     */     }
/* 187 */     if ((modulus != ZERO) && (modulus.getClass() != gaugeClass))
/*     */     {
/* 189 */       sendErrorNotification(monitorInfo, "jmx.monitor.error.threshold", "Modulus type " + modulus.getClass() + " must be of same type of the attribute " + gaugeClass, name, attribute);
/* 190 */       return;
/*     */     }
/*     */     
/* 193 */     Logger logger = getLogger();
/*     */     
/* 195 */     CounterMonitorInfo info = (CounterMonitorInfo)monitorInfo;
/* 196 */     if (logger.isEnabledFor(10))
/*     */     {
/* 198 */       logger.debug("Computing gauge, previous values are: " + info);
/* 199 */       logger.debug("Current values are: threshold=" + threshold + ", offset=" + offset + ", modulus=" + modulus);
/*     */     }
/*     */     
/* 202 */     boolean updateThreshold = false;
/* 203 */     if (getDifferenceMode())
/*     */     {
/* 205 */       Number diffGauge = sub(gauge, info.getGauge());
/* 206 */       if (compare(diffGauge, ZERO) < 0) diffGauge = sum(diffGauge, getModulus());
/* 207 */       if (logger.isEnabledFor(10)) logger.debug("CounterMonitor in difference mode, difference gauge=" + diffGauge);
/* 208 */       updateThreshold = compareAndSendNotification(diffGauge, threshold, info, name, attribute);
/*     */     }
/*     */     else
/*     */     {
/* 212 */       if (logger.isEnabledFor(10)) logger.debug("CounterMonitor in absolute mode, gauge=" + gauge);
/* 213 */       updateThreshold = compareAndSendNotification(gauge, threshold, info, name, attribute);
/*     */     }
/*     */     
/* 216 */     if (updateThreshold)
/*     */     {
/* 218 */       if (logger.isEnabledFor(10)) { logger.debug("Updating threshold, old value = " + threshold);
/*     */       }
/*     */       
/* 221 */       if (compare(offset, ZERO) != 0) {
/* 222 */         while (compare(threshold, gauge) <= 0) threshold = sum(threshold, offset);
/*     */       }
/* 224 */       if (logger.isEnabledFor(10)) { logger.debug("Threshold has been offset, new value = " + threshold);
/*     */       }
/*     */       
/* 227 */       if ((getModulus() != ZERO) && (compare(threshold, getModulus()) > 0)) { threshold = getInitThreshold();
/*     */       }
/* 229 */       if (logger.isEnabledFor(10)) { logger.debug("Threshold has been rolled over, new value = " + threshold);
/*     */       }
/*     */       
/*     */     }
/* 233 */     else if (logger.isEnabledFor(10)) { logger.debug("No need to update the threshold, value remains = " + threshold);
/*     */     }
/*     */     
/* 236 */     CounterMonitorInfo newInfo = (CounterMonitorInfo)createMonitorInfo();
/* 237 */     newInfo.setThresholdNotified(info.isThresholdNotified());
/* 238 */     newInfo.setGauge(gauge);
/* 239 */     newInfo.setTimestamp(System.currentTimeMillis());
/* 240 */     newInfo.setThreshold(threshold);
/* 241 */     putMonitorInfo(name, newInfo);
/*     */   }
/*     */   
/*     */   private boolean compareAndSendNotification(Number gauge, Number threshold, CounterMonitorInfo info, ObjectName name, String attribute)
/*     */   {
/* 246 */     Logger logger = getLogger();
/*     */     
/* 248 */     if ((info.isThresholdNotified()) && (compare(gauge, info.getGauge()) == 0))
/*     */     {
/* 250 */       if (logger.isEnabledFor(10)) logger.debug("Threshold exceeded already notified, gauge did not change: " + gauge);
/* 251 */       return false;
/*     */     }
/*     */     
/* 254 */     if (compare(gauge, threshold) >= 0)
/*     */     {
/* 256 */       if (logger.isEnabledFor(10)) logger.debug("Gauge above threshold: gauge=" + gauge + ", threshold=" + threshold);
/* 257 */       if (getNotify())
/*     */       {
/* 259 */         if (logger.isEnabledFor(10)) logger.debug("Sending threshold exceeded notification");
/* 260 */         info.setThresholdNotified(true);
/* 261 */         sendNotification("jmx.monitor.counter.threshold", "Threshold " + threshold + " exceeded: " + gauge, name, attribute, gauge, threshold);
/*     */       }
/*     */       else
/*     */       {
/* 265 */         info.setThresholdNotified(false);
/* 266 */         if (logger.isEnabledFor(10)) logger.debug("CounterMonitor is configured in non-notification mode");
/*     */       }
/* 268 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 272 */     info.setThresholdNotified(false);
/* 273 */     if (logger.isEnabledFor(10)) logger.debug("Gauge below threshold: gauge=" + gauge + ", threshold=" + threshold);
/* 274 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 280 */   protected MX4JMonitor.MonitorInfo createMonitorInfo() { return new CounterMonitorInfo(); }
/*     */   
/*     */   protected class CounterMonitorInfo extends MX4JMonitor.MonitorInfo {
/* 283 */     protected CounterMonitorInfo() { super(); }
/*     */     
/*     */     private boolean thresholdNotified;
/* 286 */     private Number gauge = MX4JCounterMonitor.ZERO;
/*     */     private long timestamp;
/* 288 */     private Number threshold = MX4JCounterMonitor.ZERO;
/*     */     
/*     */     public void setThresholdNotified(boolean thresholdNotified)
/*     */     {
/* 292 */       this.thresholdNotified = thresholdNotified;
/*     */     }
/*     */     
/*     */     public void setGauge(Number gauge)
/*     */     {
/* 297 */       this.gauge = gauge;
/*     */     }
/*     */     
/*     */     public void setTimestamp(long timestamp)
/*     */     {
/* 302 */       this.timestamp = timestamp;
/*     */     }
/*     */     
/*     */     public void setThreshold(Number threshold)
/*     */     {
/* 307 */       this.threshold = threshold;
/*     */     }
/*     */     
/*     */     public boolean isThresholdNotified()
/*     */     {
/* 312 */       return this.thresholdNotified;
/*     */     }
/*     */     
/*     */     public Number getGauge()
/*     */     {
/* 317 */       return this.gauge;
/*     */     }
/*     */     
/*     */     public long getTimestamp()
/*     */     {
/* 322 */       return this.timestamp;
/*     */     }
/*     */     
/*     */     public Number getThreshold()
/*     */     {
/* 327 */       if (this.threshold == MX4JCounterMonitor.ZERO) return MX4JCounterMonitor.this.getInitThreshold();
/* 328 */       return this.threshold;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 333 */       StringBuffer buffer = new StringBuffer(super.toString());
/* 334 */       buffer.append(", thresholdNotified=").append(isThresholdNotified());
/* 335 */       buffer.append(", gauge=").append(getGauge());
/* 336 */       buffer.append(", threshold=").append(this.threshold);
/* 337 */       return buffer.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/monitor/MX4JCounterMonitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */