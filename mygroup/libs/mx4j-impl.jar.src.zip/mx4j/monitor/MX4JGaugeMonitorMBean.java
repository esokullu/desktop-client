package mx4j.monitor;

import javax.management.ObjectName;

public abstract interface MX4JGaugeMonitorMBean
  extends MX4JMonitorMBean
{
  public abstract Number getDerivedGauge(ObjectName paramObjectName);
  
  public abstract long getDerivedGaugeTimeStamp(ObjectName paramObjectName);
  
  public abstract Number getHighThreshold();
  
  public abstract Number getLowThreshold();
  
  public abstract void setThresholds(Number paramNumber1, Number paramNumber2)
    throws IllegalArgumentException;
  
  public abstract boolean getNotifyHigh();
  
  public abstract void setNotifyHigh(boolean paramBoolean);
  
  public abstract boolean getNotifyLow();
  
  public abstract void setNotifyLow(boolean paramBoolean);
  
  public abstract boolean getDifferenceMode();
  
  public abstract void setDifferenceMode(boolean paramBoolean);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/monitor/MX4JGaugeMonitorMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */