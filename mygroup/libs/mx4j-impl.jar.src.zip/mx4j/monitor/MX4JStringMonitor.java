/*     */ package mx4j.monitor;
/*     */ 
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MX4JStringMonitor
/*     */   extends MX4JMonitor
/*     */   implements MX4JStringMonitorMBean
/*     */ {
/*     */   private static final String EMPTY = "";
/*  25 */   private String stringToCompare = "";
/*     */   private boolean notifyMatch;
/*     */   private boolean notifyDiffer;
/*     */   
/*     */   public MX4JStringMonitor() throws NotCompliantMBeanException
/*     */   {
/*  31 */     super(MX4JStringMonitorMBean.class);
/*     */   }
/*     */   
/*     */   public MX4JStringMonitor(Class management) throws NotCompliantMBeanException
/*     */   {
/*  36 */     super(management);
/*     */   }
/*     */   
/*     */ 
/*     */   public MBeanNotificationInfo[] getNotificationInfo()
/*     */   {
/*  42 */     return new MBeanNotificationInfo[0];
/*     */   }
/*     */   
/*     */   public synchronized String getStringToCompare()
/*     */   {
/*  47 */     return this.stringToCompare;
/*     */   }
/*     */   
/*     */   public synchronized void setStringToCompare(String value) throws IllegalArgumentException
/*     */   {
/*  52 */     if (value == null) throw new IllegalArgumentException("String to compare cannot be null");
/*  53 */     this.stringToCompare = value;
/*     */   }
/*     */   
/*     */   public synchronized boolean getNotifyMatch()
/*     */   {
/*  58 */     return this.notifyMatch;
/*     */   }
/*     */   
/*     */   public synchronized void setNotifyMatch(boolean notifyMatch)
/*     */   {
/*  63 */     this.notifyMatch = notifyMatch;
/*     */   }
/*     */   
/*     */   public synchronized boolean getNotifyDiffer()
/*     */   {
/*  68 */     return this.notifyDiffer;
/*     */   }
/*     */   
/*     */   public synchronized void setNotifyDiffer(boolean notifyDiffer)
/*     */   {
/*  73 */     this.notifyDiffer = notifyDiffer;
/*     */   }
/*     */   
/*     */   public String getDerivedGauge(ObjectName objectName)
/*     */   {
/*  78 */     StringMonitorInfo info = (StringMonitorInfo)getMonitorInfo(objectName);
/*  79 */     return info.getGauge();
/*     */   }
/*     */   
/*     */   public long getDerivedGaugeTimeStamp(ObjectName objectName)
/*     */   {
/*  84 */     StringMonitorInfo info = (StringMonitorInfo)getMonitorInfo(objectName);
/*  85 */     return info.getTimestamp();
/*     */   }
/*     */   
/*     */   protected MX4JMonitor.MonitorInfo createMonitorInfo()
/*     */   {
/*  90 */     return new StringMonitorInfo();
/*     */   }
/*     */   
/*     */   protected int compare(String left, String right)
/*     */   {
/*  95 */     return right == null ? 1 : left == null ? -1 : right == null ? 0 : left.compareTo(right);
/*     */   }
/*     */   
/*     */   protected void monitor(ObjectName name, String attribute, Object value, MX4JMonitor.MonitorInfo monitorInfo)
/*     */   {
/* 100 */     if (!(value instanceof String))
/*     */     {
/* 102 */       sendErrorNotification(monitorInfo, "jmx.monitor.error.type", "Attribute type must be a String, not " + value.getClass(), name, attribute);
/* 103 */       return;
/*     */     }
/*     */     
/* 106 */     String gauge = (String)value;
/*     */     
/* 108 */     String reference = null;
/* 109 */     synchronized (this)
/*     */     {
/* 111 */       reference = getStringToCompare();
/*     */     }
/*     */     
/* 114 */     Logger logger = getLogger();
/*     */     
/* 116 */     StringMonitorInfo info = (StringMonitorInfo)monitorInfo;
/* 117 */     if (logger.isEnabledFor(10))
/*     */     {
/* 119 */       logger.debug("Computing gauge, previous values are: " + info);
/* 120 */       logger.debug("Current values are: gauge=" + gauge + ", stringToCompare=" + reference);
/*     */     }
/*     */     
/* 123 */     compareAndSendNotification(gauge, reference, info, name, attribute);
/*     */     
/* 125 */     info.setGauge(gauge);
/* 126 */     info.setTimestamp(System.currentTimeMillis());
/*     */   }
/*     */   
/*     */   private void compareAndSendNotification(String gauge, String reference, StringMonitorInfo info, ObjectName name, String attribute)
/*     */   {
/* 131 */     Logger logger = getLogger();
/*     */     
/* 133 */     boolean equals = compare(gauge, reference) == 0;
/*     */     
/* 135 */     if ((info.isDifferNotified()) && (!equals))
/*     */     {
/* 137 */       if (logger.isEnabledFor(10)) logger.debug("Difference already notified, gauge=" + gauge + ", string-to-compare=" + reference);
/* 138 */       return;
/*     */     }
/* 140 */     if ((info.isMatchNotified()) && (equals))
/*     */     {
/* 142 */       if (logger.isEnabledFor(10)) logger.debug("Match already notified, gauge=" + gauge + ", string-to-compare=" + reference);
/* 143 */       return;
/*     */     }
/*     */     
/* 146 */     if (equals)
/*     */     {
/* 148 */       if (logger.isEnabledFor(10)) logger.debug("Gauge matches, gauge=" + gauge + ", string-to-compare=" + reference);
/* 149 */       info.setDifferNotified(false);
/* 150 */       if (getNotifyMatch())
/*     */       {
/* 152 */         if (logger.isEnabledFor(10)) logger.debug("Sending string match notification");
/* 153 */         info.setMatchNotified(true);
/* 154 */         sendNotification("jmx.monitor.string.matches", "Gauge " + gauge + " matched " + reference, name, attribute, gauge, reference);
/*     */       }
/*     */       else
/*     */       {
/* 158 */         info.setMatchNotified(false);
/* 159 */         if (logger.isEnabledFor(10)) logger.debug("StringMonitor is configured in non-match-notification mode");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 164 */       if (logger.isEnabledFor(10)) logger.debug("Gauge differs, gauge=" + gauge + ", string-to-compare=" + reference);
/* 165 */       info.setMatchNotified(false);
/* 166 */       if (getNotifyDiffer())
/*     */       {
/* 168 */         if (logger.isEnabledFor(10)) logger.debug("Sending string differ notification");
/* 169 */         info.setDifferNotified(true);
/* 170 */         sendNotification("jmx.monitor.string.differs", "Gauge " + gauge + " differs from " + reference, name, attribute, gauge, reference);
/*     */       }
/*     */       else
/*     */       {
/* 174 */         info.setDifferNotified(false);
/* 175 */         if (logger.isEnabledFor(10)) logger.debug("StringMonitor is configured in non-differ-notification mode"); } } }
/*     */   
/*     */   protected class StringMonitorInfo extends MX4JMonitor.MonitorInfo { private String gauge;
/*     */     private long timestamp;
/*     */     
/* 180 */     protected StringMonitorInfo() { super(); }
/*     */     
/*     */ 
/*     */     private boolean matchNotified;
/*     */     
/*     */     private boolean differNotified;
/*     */     
/*     */     public String getGauge()
/*     */     {
/* 189 */       return this.gauge;
/*     */     }
/*     */     
/*     */     public void setGauge(String gauge)
/*     */     {
/* 194 */       this.gauge = gauge;
/*     */     }
/*     */     
/*     */     public long getTimestamp()
/*     */     {
/* 199 */       return this.timestamp;
/*     */     }
/*     */     
/*     */     public void setTimestamp(long timestamp)
/*     */     {
/* 204 */       this.timestamp = timestamp;
/*     */     }
/*     */     
/*     */     public boolean isMatchNotified()
/*     */     {
/* 209 */       return this.matchNotified;
/*     */     }
/*     */     
/*     */     public void setMatchNotified(boolean matchNotified)
/*     */     {
/* 214 */       this.matchNotified = matchNotified;
/*     */     }
/*     */     
/*     */     public boolean isDifferNotified()
/*     */     {
/* 219 */       return this.differNotified;
/*     */     }
/*     */     
/*     */     public void setDifferNotified(boolean differNotified)
/*     */     {
/* 224 */       this.differNotified = differNotified;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 229 */       StringBuffer buffer = new StringBuffer(super.toString());
/* 230 */       buffer.append(", gauge=").append(getGauge());
/* 231 */       buffer.append(", matchNotified=").append(isMatchNotified());
/* 232 */       buffer.append(", differNotified=").append(isDifferNotified());
/* 233 */       return buffer.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/monitor/MX4JStringMonitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */