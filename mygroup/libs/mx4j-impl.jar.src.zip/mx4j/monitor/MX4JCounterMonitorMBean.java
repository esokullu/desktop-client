package mx4j.monitor;

import javax.management.ObjectName;

public abstract interface MX4JCounterMonitorMBean
  extends MX4JMonitorMBean
{
  public abstract Number getDerivedGauge(ObjectName paramObjectName);
  
  public abstract long getDerivedGaugeTimeStamp(ObjectName paramObjectName);
  
  public abstract Number getThreshold(ObjectName paramObjectName);
  
  public abstract Number getInitThreshold();
  
  public abstract void setInitThreshold(Number paramNumber)
    throws IllegalArgumentException;
  
  public abstract Number getOffset();
  
  public abstract void setOffset(Number paramNumber)
    throws IllegalArgumentException;
  
  public abstract Number getModulus();
  
  public abstract void setModulus(Number paramNumber)
    throws IllegalArgumentException;
  
  public abstract boolean getNotify();
  
  public abstract void setNotify(boolean paramBoolean);
  
  public abstract boolean getDifferenceMode();
  
  public abstract void setDifferenceMode(boolean paramBoolean);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/monitor/MX4JCounterMonitorMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */