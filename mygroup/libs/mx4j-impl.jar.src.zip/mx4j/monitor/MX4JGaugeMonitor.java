/*     */ package mx4j.monitor;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MX4JGaugeMonitor
/*     */   extends MX4JMonitor
/*     */   implements MX4JGaugeMonitorMBean
/*     */ {
/*  25 */   private static Integer ZERO = new Integer(0);
/*     */   
/*  27 */   private Number highThreshold = ZERO;
/*  28 */   private Number lowThreshold = ZERO;
/*     */   private boolean notifyHigh;
/*     */   private boolean notifyLow;
/*     */   private boolean differenceMode;
/*     */   
/*     */   public MX4JGaugeMonitor() throws NotCompliantMBeanException
/*     */   {
/*  35 */     super(MX4JGaugeMonitorMBean.class);
/*     */   }
/*     */   
/*     */   protected MX4JGaugeMonitor(Class management) throws NotCompliantMBeanException
/*     */   {
/*  40 */     super(management);
/*     */   }
/*     */   
/*     */ 
/*     */   public MBeanNotificationInfo[] getNotificationInfo()
/*     */   {
/*  46 */     return new MBeanNotificationInfo[0];
/*     */   }
/*     */   
/*     */   public synchronized Number getHighThreshold()
/*     */   {
/*  51 */     return this.highThreshold;
/*     */   }
/*     */   
/*     */   public synchronized Number getLowThreshold()
/*     */   {
/*  56 */     return this.lowThreshold;
/*     */   }
/*     */   
/*     */   public void setThresholds(Number highValue, Number lowValue) throws IllegalArgumentException
/*     */   {
/*  61 */     if (highValue == null) throw new IllegalArgumentException("High Threshold cannot be null");
/*  62 */     if (lowValue == null) throw new IllegalArgumentException("Low Threshold cannot be null");
/*  63 */     if (highValue.getClass() != lowValue.getClass()) throw new IllegalArgumentException("Thresholds must be of the same type");
/*  64 */     if (compare(highValue, lowValue) < 0) throw new IllegalArgumentException("High threshold cannot be lower than low threshold");
/*  65 */     this.highThreshold = highValue;
/*  66 */     this.lowThreshold = lowValue;
/*     */   }
/*     */   
/*     */   public synchronized boolean getNotifyHigh()
/*     */   {
/*  71 */     return this.notifyHigh;
/*     */   }
/*     */   
/*     */   public synchronized boolean getNotifyLow()
/*     */   {
/*  76 */     return this.notifyLow;
/*     */   }
/*     */   
/*     */   public synchronized void setNotifyHigh(boolean notifyHigh)
/*     */   {
/*  81 */     this.notifyHigh = notifyHigh;
/*     */   }
/*     */   
/*     */   public synchronized void setNotifyLow(boolean notifyLow)
/*     */   {
/*  86 */     this.notifyLow = notifyLow;
/*     */   }
/*     */   
/*     */   public synchronized boolean getDifferenceMode()
/*     */   {
/*  91 */     return this.differenceMode;
/*     */   }
/*     */   
/*     */   public synchronized void setDifferenceMode(boolean differenceMode)
/*     */   {
/*  96 */     this.differenceMode = differenceMode;
/*     */   }
/*     */   
/*     */   public Number getDerivedGauge(ObjectName objectName)
/*     */   {
/* 101 */     GaugeMonitorInfo info = (GaugeMonitorInfo)getMonitorInfo(objectName);
/* 102 */     return info.getGauge();
/*     */   }
/*     */   
/*     */   public long getDerivedGaugeTimeStamp(ObjectName objectName)
/*     */   {
/* 107 */     GaugeMonitorInfo info = (GaugeMonitorInfo)getMonitorInfo(objectName);
/* 108 */     return info.getTimestamp();
/*     */   }
/*     */   
/*     */   protected MX4JMonitor.MonitorInfo createMonitorInfo()
/*     */   {
/* 113 */     return new GaugeMonitorInfo();
/*     */   }
/*     */   
/*     */   protected int compare(Number left, Number right)
/*     */   {
/* 118 */     if (((left instanceof BigDecimal)) && ((right instanceof BigDecimal))) return ((BigDecimal)left).compareTo((BigDecimal)right);
/* 119 */     if (((left instanceof BigInteger)) && ((right instanceof BigInteger))) return ((BigInteger)left).compareTo((BigInteger)right);
/* 120 */     return new Double(left.doubleValue()).compareTo(new Double(right.doubleValue()));
/*     */   }
/*     */   
/*     */   protected Number sub(Number left, Number right)
/*     */   {
/* 125 */     if (((left instanceof BigDecimal)) && ((right instanceof BigDecimal))) return ((BigDecimal)left).subtract((BigDecimal)right);
/* 126 */     if ((left instanceof BigDecimal)) return ((BigDecimal)left).subtract(new BigDecimal(right.doubleValue()));
/* 127 */     if (((left instanceof BigInteger)) && ((right instanceof BigInteger))) return ((BigInteger)left).subtract((BigInteger)right);
/* 128 */     if ((left instanceof BigInteger)) return ((BigInteger)left).subtract(BigInteger.valueOf(right.longValue()));
/* 129 */     if (((left instanceof Double)) || ((right instanceof Double))) return new Double(left.doubleValue() - right.doubleValue());
/* 130 */     if (((left instanceof Float)) || ((right instanceof Float))) return new Float(left.floatValue() - right.floatValue());
/* 131 */     if (((left instanceof Long)) || ((right instanceof Long))) return new Long(left.longValue() - right.longValue());
/* 132 */     if (((left instanceof Integer)) || ((right instanceof Integer))) return new Integer(left.intValue() - right.intValue());
/* 133 */     if (((left instanceof Short)) || ((right instanceof Short))) return new Short((short)(left.shortValue() - right.shortValue()));
/* 134 */     if (((left instanceof Byte)) || ((right instanceof Byte))) return new Byte((byte)(left.byteValue() - right.byteValue()));
/* 135 */     return null;
/*     */   }
/*     */   
/*     */   protected void monitor(ObjectName name, String attribute, Object value, MX4JMonitor.MonitorInfo monitorInfo)
/*     */   {
/* 140 */     if (!(value instanceof Number))
/*     */     {
/* 142 */       sendErrorNotification(monitorInfo, "jmx.monitor.error.type", "Attribute type must be a Number, not " + value.getClass(), name, attribute);
/* 143 */       return;
/*     */     }
/*     */     
/* 146 */     Number gauge = (Number)value;
/*     */     
/*     */ 
/* 149 */     Number high = null;
/* 150 */     Number low = null;
/* 151 */     synchronized (this)
/*     */     {
/* 153 */       high = getHighThreshold();
/* 154 */       low = getLowThreshold();
/*     */     }
/* 156 */     Class gaugeClass = gauge.getClass();
/* 157 */     if ((high != ZERO) && (high.getClass() != gaugeClass))
/*     */     {
/* 159 */       sendErrorNotification(monitorInfo, "jmx.monitor.error.threshold", "Threshold type " + high.getClass() + " must be of same type of the attribute " + gaugeClass, name, attribute);
/* 160 */       return;
/*     */     }
/* 162 */     if ((low != ZERO) && (low.getClass() != gaugeClass))
/*     */     {
/* 164 */       sendErrorNotification(monitorInfo, "jmx.monitor.error.threshold", "Offset type " + low.getClass() + " must be of same type of the attribute " + gaugeClass, name, attribute);
/* 165 */       return;
/*     */     }
/*     */     
/* 168 */     Logger logger = getLogger();
/*     */     
/*     */ 
/* 171 */     GaugeMonitorInfo info = (GaugeMonitorInfo)monitorInfo;
/* 172 */     if (logger.isEnabledFor(10))
/*     */     {
/* 174 */       logger.debug("Computing gauge, previous values are: " + info);
/* 175 */       logger.debug("Current values are: gauge=" + gauge + ", highThreshold=" + high + ", lowThreshold=" + low);
/*     */     }
/*     */     
/* 178 */     if (getDifferenceMode())
/*     */     {
/* 180 */       Number diffGauge = sub(gauge, info.getGauge());
/* 181 */       if (logger.isEnabledFor(10)) logger.debug("CounterMonitor in difference mode, difference gauge=" + diffGauge);
/* 182 */       compareAndSendNotification(diffGauge, low, high, info, name, attribute);
/*     */     }
/*     */     else
/*     */     {
/* 186 */       if (logger.isEnabledFor(10)) logger.debug("CounterMonitor in absolute mode, gauge=" + gauge);
/* 187 */       compareAndSendNotification(gauge, low, high, info, name, attribute);
/*     */     }
/*     */     
/* 190 */     info.setGauge(gauge);
/* 191 */     info.setTimestamp(System.currentTimeMillis());
/*     */   }
/*     */   
/*     */   private void compareAndSendNotification(Number gauge, Number low, Number high, GaugeMonitorInfo info, ObjectName name, String attribute)
/*     */   {
/* 196 */     Logger logger = getLogger();
/*     */     
/* 198 */     if ((info.isHighNotified()) && (compare(gauge, low) > 0))
/*     */     {
/* 200 */       if (logger.isEnabledFor(10)) logger.debug("High threshold " + high + " already notified, gauge " + gauge + " not below low threshold " + low);
/* 201 */       return;
/*     */     }
/* 203 */     if ((info.isLowNotified()) && (compare(gauge, high) < 0))
/*     */     {
/* 205 */       if (logger.isEnabledFor(10)) logger.debug("Low threshold " + low + " already notified, gauge " + gauge + " not above high threshold " + high);
/* 206 */       return;
/*     */     }
/*     */     
/* 209 */     if (compare(gauge, high) >= 0)
/*     */     {
/* 211 */       if (logger.isEnabledFor(10)) logger.debug("Gauge above high threshold: gauge=" + gauge + ", high threshold=" + high + ", low threshold=" + low);
/* 212 */       info.setLowNotified(false);
/* 213 */       if (getNotifyHigh())
/*     */       {
/* 215 */         if (logger.isEnabledFor(10)) logger.debug("Sending high threshold exceeded notification");
/* 216 */         info.setHighNotified(true);
/* 217 */         sendNotification("jmx.monitor.gauge.high", "High threshold " + high + " exceeded: " + gauge, name, attribute, gauge, high);
/*     */       }
/*     */       else
/*     */       {
/* 221 */         info.setHighNotified(false);
/* 222 */         if (logger.isEnabledFor(10)) logger.debug("GaugeMonitor is configured in non-high-notification mode");
/*     */       }
/*     */     }
/* 225 */     else if (compare(gauge, low) <= 0)
/*     */     {
/* 227 */       if (logger.isEnabledFor(10)) logger.debug("Gauge below low threshold: gauge=" + gauge + ", low threshold=" + low + ", high threshold=" + high);
/* 228 */       info.setHighNotified(false);
/* 229 */       if (getNotifyLow())
/*     */       {
/* 231 */         if (logger.isEnabledFor(10)) logger.debug("Sending low threshold exceeded notification");
/* 232 */         info.setLowNotified(true);
/* 233 */         sendNotification("jmx.monitor.gauge.low", "Low threshold " + low + " exceeded: " + gauge, name, attribute, gauge, low);
/*     */       }
/*     */       else
/*     */       {
/* 237 */         info.setLowNotified(false);
/* 238 */         if (logger.isEnabledFor(10)) logger.debug("GaugeMonitor is configured in non-low-notification mode");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 243 */       info.setHighNotified(false);
/* 244 */       info.setLowNotified(false);
/* 245 */       if (logger.isEnabledFor(10)) logger.debug("Gauge between thresholds: gauge=" + gauge + ", low threshold=" + low + ", high threshold=" + high);
/*     */     }
/*     */   }
/*     */   
/* 249 */   protected class GaugeMonitorInfo extends MX4JMonitor.MonitorInfo { protected GaugeMonitorInfo() { super(); }
/*     */     
/* 251 */     private Number gauge = MX4JGaugeMonitor.ZERO;
/*     */     private long timestamp;
/*     */     private boolean highNotified;
/*     */     private boolean lowNotified;
/*     */     
/*     */     public Number getGauge()
/*     */     {
/* 258 */       return this.gauge;
/*     */     }
/*     */     
/*     */     public void setGauge(Number gauge)
/*     */     {
/* 263 */       this.gauge = gauge;
/*     */     }
/*     */     
/*     */     public long getTimestamp()
/*     */     {
/* 268 */       return this.timestamp;
/*     */     }
/*     */     
/*     */     public void setTimestamp(long timestamp)
/*     */     {
/* 273 */       this.timestamp = timestamp;
/*     */     }
/*     */     
/*     */     public boolean isHighNotified()
/*     */     {
/* 278 */       return this.highNotified;
/*     */     }
/*     */     
/*     */     public void setHighNotified(boolean highNotified)
/*     */     {
/* 283 */       this.highNotified = highNotified;
/*     */     }
/*     */     
/*     */     public boolean isLowNotified()
/*     */     {
/* 288 */       return this.lowNotified;
/*     */     }
/*     */     
/*     */     public void setLowNotified(boolean lowNotified)
/*     */     {
/* 293 */       this.lowNotified = lowNotified;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 298 */       StringBuffer buffer = new StringBuffer(super.toString());
/* 299 */       buffer.append(", gauge=").append(getGauge());
/* 300 */       buffer.append(", lowNotified=").append(isLowNotified());
/* 301 */       buffer.append(", highNotified=").append(isHighNotified());
/* 302 */       return buffer.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/monitor/MX4JGaugeMonitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */