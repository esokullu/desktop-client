/*    */ package mx4j.monitor;
/*    */ 
/*    */ import javax.management.Notification;
/*    */ import javax.management.ObjectName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MX4JMonitorNotification
/*    */   extends Notification
/*    */ {
/*    */   private final ObjectName observedObject;
/*    */   private final String observedAttribute;
/*    */   private final Object derivedGauge;
/*    */   private final Object trigger;
/*    */   
/*    */   public MX4JMonitorNotification(String type, Object source, long sequenceNumber, long timeStamp, String message, ObjectName monitoredName, String attribute, Object gauge, Object trigger)
/*    */   {
/* 26 */     super(type, source, sequenceNumber, timeStamp, message);
/* 27 */     this.observedObject = monitoredName;
/* 28 */     this.observedAttribute = attribute;
/* 29 */     this.derivedGauge = gauge;
/* 30 */     this.trigger = trigger;
/*    */   }
/*    */   
/*    */   public ObjectName getObservedObject()
/*    */   {
/* 35 */     return this.observedObject;
/*    */   }
/*    */   
/*    */   public Object getDerivedGauge()
/*    */   {
/* 40 */     return this.derivedGauge;
/*    */   }
/*    */   
/*    */   public String getObservedAttribute()
/*    */   {
/* 45 */     return this.observedAttribute;
/*    */   }
/*    */   
/*    */   public Object getTrigger()
/*    */   {
/* 50 */     return this.trigger;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 55 */     StringBuffer buffer = new StringBuffer("[");
/* 56 */     buffer.append(super.toString()).append(", ");
/* 57 */     buffer.append("observed=").append(getObservedObject()).append(", ");
/* 58 */     buffer.append("gauge=").append(getDerivedGauge()).append(", ");
/* 59 */     buffer.append("attribute=").append(getObservedAttribute()).append(", ");
/* 60 */     buffer.append("trigger=").append(getTrigger()).append("]");
/* 61 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/monitor/MX4JMonitorNotification.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */