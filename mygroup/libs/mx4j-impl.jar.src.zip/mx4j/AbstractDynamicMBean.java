/*     */ package mx4j;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.DynamicMBean;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanConstructorInfo;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.RuntimeErrorException;
/*     */ import javax.management.RuntimeMBeanException;
/*     */ import mx4j.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDynamicMBean
/*     */   implements DynamicMBean
/*     */ {
/*     */   private MBeanInfo info;
/*     */   private Object resource;
/*     */   
/*     */   public Object getAttribute(String attribute)
/*     */     throws AttributeNotFoundException, MBeanException, ReflectionException
/*     */   {
/*  95 */     if (attribute == null) { throw new AttributeNotFoundException("Attribute " + attribute + " not found");
/*     */     }
/*  97 */     Object resource = null;
/*  98 */     MBeanInfo info = null;
/*  99 */     synchronized (this)
/*     */     {
/* 101 */       resource = getResourceOrThis();
/* 102 */       info = getMBeanInfo();
/*     */     }
/*     */     
/* 105 */     MBeanAttributeInfo[] attrs = info.getAttributes();
/* 106 */     if ((attrs == null) || (attrs.length == 0)) { throw new AttributeNotFoundException("No attributes defined for this MBean");
/*     */     }
/* 108 */     for (int i = 0; i < attrs.length; i++)
/*     */     {
/* 110 */       MBeanAttributeInfo attr = attrs[i];
/* 111 */       if (attr != null)
/*     */       {
/* 113 */         if (attribute.equals(attr.getName()))
/*     */         {
/* 115 */           if (!attr.isReadable()) { throw new ReflectionException(new NoSuchMethodException("No getter defined for attribute: " + attribute));
/*     */           }
/*     */           
/* 118 */           String prefix = null;
/* 119 */           if (attr.isIs()) {
/* 120 */             prefix = "is";
/*     */           } else {
/* 122 */             prefix = "get";
/*     */           }
/*     */           try
/*     */           {
/* 126 */             return invoke(resource, prefix + attr.getName(), new Class[0], new Object[0]);
/*     */           }
/*     */           catch (InvalidAttributeValueException x)
/*     */           {
/* 130 */             throw new ReflectionException(x);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 135 */     throw new AttributeNotFoundException("Attribute " + attribute + " not found");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AttributeList getAttributes(String[] attributes)
/*     */   {
/* 143 */     AttributeList list = new AttributeList();
/*     */     
/* 145 */     if (attributes != null)
/*     */     {
/* 147 */       for (int i = 0; i < attributes.length; i++)
/*     */       {
/* 149 */         String attribute = attributes[i];
/*     */         try
/*     */         {
/* 152 */           Object result = getAttribute(attribute);
/* 153 */           list.add(new Attribute(attribute, result));
/*     */         }
/*     */         catch (AttributeNotFoundException ignored) {}catch (MBeanException ignored) {}catch (ReflectionException ignored) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 167 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized MBeanInfo getMBeanInfo()
/*     */   {
/* 179 */     if (this.info == null) setMBeanInfo(createMBeanInfo());
/* 180 */     return this.info;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(String method, Object[] arguments, String[] params)
/*     */     throws MBeanException, ReflectionException
/*     */   {
/* 190 */     if (method == null) throw new IllegalArgumentException("Method name cannot be null");
/* 191 */     if (arguments == null) arguments = new Object[0];
/* 192 */     if (params == null) { params = new String[0];
/*     */     }
/* 194 */     Object resource = null;
/* 195 */     MBeanInfo info = null;
/* 196 */     synchronized (this)
/*     */     {
/* 198 */       resource = getResourceOrThis();
/* 199 */       info = getMBeanInfo();
/*     */     }
/*     */     
/* 202 */     MBeanOperationInfo[] opers = info.getOperations();
/* 203 */     if ((opers == null) || (opers.length == 0)) { throw new ReflectionException(new NoSuchMethodException("No operations defined for this MBean"));
/*     */     }
/* 205 */     for (int i = 0; i < opers.length; i++)
/*     */     {
/* 207 */       MBeanOperationInfo oper = opers[i];
/* 208 */       if (oper != null)
/*     */       {
/* 210 */         if (method.equals(oper.getName()))
/*     */         {
/* 212 */           MBeanParameterInfo[] parameters = oper.getSignature();
/* 213 */           if (params.length == parameters.length)
/*     */           {
/* 215 */             String[] signature = new String[parameters.length];
/* 216 */             for (int j = 0; j < signature.length; j++)
/*     */             {
/* 218 */               MBeanParameterInfo param = parameters[j];
/* 219 */               if (param == null) {
/* 220 */                 signature[j] = null;
/*     */               } else {
/* 222 */                 signature[j] = param.getType();
/*     */               }
/*     */             }
/* 225 */             if (Utils.arrayEquals(params, signature))
/*     */             {
/*     */               try
/*     */               {
/*     */ 
/* 230 */                 Class[] classes = Utils.loadClasses(resource.getClass().getClassLoader(), signature);
/* 231 */                 return invoke(resource, method, classes, arguments);
/*     */               }
/*     */               catch (ClassNotFoundException x)
/*     */               {
/* 235 */                 throw new ReflectionException(x);
/*     */               }
/*     */               catch (InvalidAttributeValueException x)
/*     */               {
/* 239 */                 throw new ReflectionException(x);
/*     */               } }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 245 */     throw new ReflectionException(new NoSuchMethodException("Operation " + method + " with signature " + Arrays.asList(params) + " is not defined for this MBean"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttribute(Attribute attribute)
/*     */     throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException
/*     */   {
/* 255 */     if (attribute == null) { throw new AttributeNotFoundException("Attribute " + attribute + " not found");
/*     */     }
/* 257 */     Object resource = null;
/* 258 */     MBeanInfo info = null;
/* 259 */     synchronized (this)
/*     */     {
/* 261 */       resource = getResourceOrThis();
/* 262 */       info = getMBeanInfo();
/*     */     }
/*     */     
/* 265 */     MBeanAttributeInfo[] attrs = info.getAttributes();
/* 266 */     if ((attrs == null) || (attrs.length == 0)) { throw new AttributeNotFoundException("No attributes defined for this MBean");
/*     */     }
/* 268 */     for (int i = 0; i < attrs.length; i++)
/*     */     {
/* 270 */       MBeanAttributeInfo attr = attrs[i];
/* 271 */       if (attr != null)
/*     */       {
/* 273 */         if (attribute.getName().equals(attr.getName()))
/*     */         {
/* 275 */           if (!attr.isWritable()) { throw new ReflectionException(new NoSuchMethodException("No setter defined for attribute: " + attribute));
/*     */           }
/*     */           try
/*     */           {
/* 279 */             String signature = attr.getType();
/* 280 */             Class cls = Utils.loadClass(resource.getClass().getClassLoader(), signature);
/* 281 */             invoke(resource, "set" + attr.getName(), new Class[] { cls }, new Object[] { attribute.getValue() });
/* 282 */             return;
/*     */           }
/*     */           catch (ClassNotFoundException x)
/*     */           {
/* 286 */             throw new ReflectionException(x);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 291 */     throw new AttributeNotFoundException("Attribute " + attribute + " not found");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AttributeList setAttributes(AttributeList attributes)
/*     */   {
/* 299 */     AttributeList list = new AttributeList();
/*     */     
/* 301 */     if (attributes != null)
/*     */     {
/* 303 */       for (int i = 0; i < attributes.size(); i++)
/*     */       {
/* 305 */         Attribute attribute = (Attribute)attributes.get(i);
/*     */         try
/*     */         {
/* 308 */           setAttribute(attribute);
/* 309 */           list.add(attribute);
/*     */         }
/*     */         catch (AttributeNotFoundException ignored) {}catch (InvalidAttributeValueException ignored) {}catch (MBeanException ignored) {}catch (ReflectionException ignored) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 326 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   protected Object invoke(String name, Class[] params, Object[] args)
/*     */     throws InvalidAttributeValueException, MBeanException, ReflectionException
/*     */   {
/* 336 */     Object resource = getResourceOrThis();
/* 337 */     return invoke(resource, name, params, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object invoke(Object resource, String name, Class[] params, Object[] args)
/*     */     throws InvalidAttributeValueException, MBeanException, ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 353 */       Class cls = resource.getClass();
/* 354 */       Method method = findMethod(cls, name, params);
/* 355 */       return invokeMethod(method, resource, args);
/*     */     }
/*     */     catch (NoSuchMethodException x)
/*     */     {
/* 359 */       throw new ReflectionException(x);
/*     */     }
/*     */     catch (IllegalAccessException x)
/*     */     {
/* 363 */       throw new ReflectionException(x);
/*     */     }
/*     */     catch (IllegalArgumentException x)
/*     */     {
/* 367 */       throw new InvalidAttributeValueException(x.toString());
/*     */     }
/*     */     catch (InvocationTargetException x)
/*     */     {
/* 371 */       Throwable t = x.getTargetException();
/* 372 */       if ((t instanceof RuntimeException))
/* 373 */         throw new RuntimeMBeanException((RuntimeException)t);
/* 374 */       if ((t instanceof Exception)) throw new MBeanException((Exception)t);
/* 375 */       throw new RuntimeErrorException((Error)t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Method findMethod(Class cls, String name, Class[] params)
/*     */     throws NoSuchMethodException
/*     */   {
/* 389 */     return cls.getMethod(name, params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object invokeMethod(Method method, Object resource, Object[] args)
/*     */     throws IllegalAccessException, IllegalArgumentException, InvocationTargetException
/*     */   {
/* 401 */     return method.invoke(resource, args);
/*     */   }
/*     */   
/*     */   private Object getResourceOrThis()
/*     */   {
/* 406 */     Object resource = getResource();
/* 407 */     if (resource == null) resource = this;
/* 408 */     return resource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized Object getResource()
/*     */   {
/* 418 */     return this.resource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setResource(Object resource)
/*     */   {
/* 428 */     this.resource = resource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void setMBeanInfo(MBeanInfo info)
/*     */   {
/* 439 */     this.info = info;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanInfo createMBeanInfo()
/*     */   {
/* 456 */     MBeanAttributeInfo[] attrs = createMBeanAttributeInfo();
/* 457 */     MBeanConstructorInfo[] ctors = createMBeanConstructorInfo();
/* 458 */     MBeanOperationInfo[] opers = createMBeanOperationInfo();
/* 459 */     MBeanNotificationInfo[] notifs = createMBeanNotificationInfo();
/* 460 */     String className = getMBeanClassName();
/* 461 */     String description = getMBeanDescription();
/* 462 */     return new MBeanInfo(className, description, attrs, ctors, opers, notifs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanAttributeInfo[] createMBeanAttributeInfo()
/*     */   {
/* 470 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanConstructorInfo[] createMBeanConstructorInfo()
/*     */   {
/* 478 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanOperationInfo[] createMBeanOperationInfo()
/*     */   {
/* 486 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanNotificationInfo[] createMBeanNotificationInfo()
/*     */   {
/* 494 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getMBeanClassName()
/*     */   {
/* 503 */     return getClass().getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getMBeanDescription()
/*     */   {
/* 511 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/AbstractDynamicMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */