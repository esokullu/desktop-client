/*     */ package mx4j;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanDescriptionAdapter
/*     */   implements MBeanDescription
/*     */ {
/*     */   public String getMBeanDescription()
/*     */   {
/*  23 */     return "Manageable Bean";
/*     */   }
/*     */   
/*     */   public String getConstructorDescription(Constructor ctor)
/*     */   {
/*  28 */     return "Constructor exposed for management";
/*     */   }
/*     */   
/*     */   public String getConstructorParameterName(Constructor ctor, int index)
/*     */   {
/*  33 */     switch (index)
/*     */     {
/*     */     case 0: 
/*  36 */       return "param1";
/*     */     case 1: 
/*  38 */       return "param2";
/*     */     case 2: 
/*  40 */       return "param3";
/*     */     case 3: 
/*  42 */       return "param4";
/*     */     }
/*  44 */     return "param" + (index + 1);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getConstructorParameterDescription(Constructor ctor, int index)
/*     */   {
/*  50 */     switch (index)
/*     */     {
/*     */     case 0: 
/*  53 */       return "Constructor's parameter n. 1";
/*     */     case 1: 
/*  55 */       return "Constructor's parameter n. 2";
/*     */     case 2: 
/*  57 */       return "Constructor's parameter n. 3";
/*     */     case 3: 
/*  59 */       return "Constructor's parameter n. 4";
/*     */     }
/*  61 */     return "Constructor's parameter n. " + (index + 1);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getAttributeDescription(String attribute)
/*     */   {
/*  67 */     return "Attribute exposed for management";
/*     */   }
/*     */   
/*     */   public String getOperationDescription(Method operation)
/*     */   {
/*  72 */     return "Operation exposed for management";
/*     */   }
/*     */   
/*     */   public String getOperationParameterName(Method method, int index)
/*     */   {
/*  77 */     switch (index)
/*     */     {
/*     */     case 0: 
/*  80 */       return "param1";
/*     */     case 1: 
/*  82 */       return "param2";
/*     */     case 2: 
/*  84 */       return "param3";
/*     */     case 3: 
/*  86 */       return "param4";
/*     */     }
/*  88 */     return "param" + (index + 1);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getOperationParameterDescription(Method method, int index)
/*     */   {
/*  94 */     switch (index)
/*     */     {
/*     */     case 0: 
/*  97 */       return "Operation's parameter n. 1";
/*     */     case 1: 
/*  99 */       return "Operation's parameter n. 2";
/*     */     case 2: 
/* 101 */       return "Operation's parameter n. 3";
/*     */     case 3: 
/* 103 */       return "Operation's parameter n. 4";
/*     */     }
/* 105 */     return "Operation's parameter n. " + (index + 1);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/MBeanDescriptionAdapter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */