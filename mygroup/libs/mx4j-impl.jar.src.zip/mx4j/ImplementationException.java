/*    */ package mx4j;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImplementationException
/*    */   extends RuntimeException
/*    */ {
/*    */   public ImplementationException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ImplementationException(String message)
/*    */   {
/* 25 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/ImplementationException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */