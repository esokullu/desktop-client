/*    */ package mx4j.log;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommonsLogger
/*    */   extends Logger
/*    */ {
/* 18 */   private Log log = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void setCategory(String category)
/*    */   {
/* 26 */     super.setCategory(category);
/* 27 */     this.log = LogFactory.getLog(getCategory());
/*    */   }
/*    */   
/*    */   protected void log(int priority, Object message, Throwable t)
/*    */   {
/* 32 */     switch (priority)
/*    */     {
/*    */     case 50: 
/* 35 */       if (t == null) {
/* 36 */         this.log.fatal(message);
/*    */       } else
/* 38 */         this.log.fatal(message, t);
/* 39 */       break;
/*    */     case 40: 
/* 41 */       if (t == null) {
/* 42 */         this.log.error(message);
/*    */       } else
/* 44 */         this.log.error(message, t);
/* 45 */       break;
/*    */     case 30: 
/* 47 */       if (t == null) {
/* 48 */         this.log.warn(message);
/*    */       } else
/* 50 */         this.log.warn(message, t);
/* 51 */       break;
/*    */     case 20: 
/* 53 */       if (t == null) {
/* 54 */         this.log.info(message);
/*    */       } else
/* 56 */         this.log.info(message, t);
/* 57 */       break;
/*    */     case 10: 
/* 59 */       if (t == null) {
/* 60 */         this.log.debug(message);
/*    */       } else
/* 62 */         this.log.debug(message, t);
/* 63 */       break;
/*    */     case 0: 
/* 65 */       if (t == null) {
/* 66 */         this.log.trace(message);
/*    */       } else {
/* 68 */         this.log.trace(message, t);
/*    */       }
/*    */       break;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/log/CommonsLogger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */