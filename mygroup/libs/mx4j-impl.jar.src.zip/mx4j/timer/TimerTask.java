/*     */ package mx4j.timer;
/*     */ 
/*     */ import java.util.Date;
/*     */ import javax.management.timer.TimerNotification;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TimerTask
/*     */   extends TimeTask
/*     */ {
/*     */   private TimerNotification m_notification;
/*     */   private long m_date;
/*     */   private long m_period;
/*     */   private long m_occurrences;
/*     */   private long m_initialOccurrences;
/*     */   private int m_hash;
/*     */   private boolean m_fixedRate;
/*     */   
/*     */   public TimerTask(TimerNotification n, Date date, long period, long occurrences, boolean fixedRate)
/*     */   {
/*  31 */     this.m_notification = n;
/*  32 */     this.m_date = date.getTime();
/*  33 */     this.m_period = period;
/*  34 */     this.m_occurrences = occurrences;
/*  35 */     this.m_initialOccurrences = occurrences;
/*  36 */     this.m_fixedRate = fixedRate;
/*     */     
/*     */ 
/*  39 */     this.m_hash = (new Long(getDate()).hashCode() ^ new Long(getPeriod()).hashCode() ^ new Long(getInitialOccurrences()).hashCode());
/*     */     
/*  41 */     setNextExecutionTime(getDate());
/*     */   }
/*     */   
/*     */   public TimerNotification getNotification()
/*     */   {
/*  46 */     return this.m_notification;
/*     */   }
/*     */   
/*     */   public boolean isFinished()
/*     */   {
/*  51 */     return super.isFinished();
/*     */   }
/*     */   
/*     */   public void setFinished(boolean value)
/*     */   {
/*  56 */     super.setFinished(value);
/*     */   }
/*     */   
/*     */   public long getPeriod()
/*     */   {
/*  61 */     return this.m_period;
/*     */   }
/*     */   
/*     */   public boolean isPeriodic()
/*     */   {
/*  66 */     boolean periodic = (getPeriod() > 0L) && ((getInitialOccurrences() == 0L) || (getOccurrences() > 0L));
/*  67 */     return periodic;
/*     */   }
/*     */   
/*     */   public long getNextExecutionTime()
/*     */   {
/*  72 */     return super.getNextExecutionTime();
/*     */   }
/*     */   
/*     */   public void setNextExecutionTime(long time)
/*     */   {
/*  77 */     super.setNextExecutionTime(time);
/*  78 */     this.m_occurrences -= 1L;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  83 */     return this.m_hash;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  88 */     if (obj == null) return false;
/*  89 */     if (obj == this) { return true;
/*     */     }
/*     */     try
/*     */     {
/*  93 */       TimerTask other = (TimerTask)obj;
/*  94 */       return (getDate() == other.getDate()) && (getPeriod() == other.getPeriod()) && (getInitialOccurrences() == other.getInitialOccurrences());
/*     */     }
/*     */     catch (ClassCastException x) {}
/*     */     
/*  98 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public long getOccurrences()
/*     */   {
/* 104 */     return this.m_occurrences;
/*     */   }
/*     */   
/*     */   private long getInitialOccurrences()
/*     */   {
/* 109 */     return this.m_initialOccurrences;
/*     */   }
/*     */   
/*     */   public long getDate()
/*     */   {
/* 114 */     return this.m_date;
/*     */   }
/*     */   
/*     */   public boolean getFixedRate()
/*     */   {
/* 119 */     return this.m_fixedRate;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/timer/TimerTask.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */