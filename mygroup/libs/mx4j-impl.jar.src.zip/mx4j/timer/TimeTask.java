/*     */ package mx4j.timer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TimeTask
/*     */   implements Comparable, Runnable
/*     */ {
/*     */   private long executionTime;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean finished;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void run();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isPeriodic()
/*     */   {
/*  42 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected long getPeriod()
/*     */   {
/*  52 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getFixedRate()
/*     */   {
/*  61 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected long getNextExecutionTime()
/*     */   {
/*  71 */     return this.executionTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setNextExecutionTime(long time)
/*     */   {
/*  81 */     this.executionTime = time;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFinished(boolean value)
/*     */   {
/*  92 */     this.finished = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isFinished()
/*     */   {
/* 102 */     return this.finished;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(Object obj)
/*     */   {
/* 112 */     if (obj == null) return 1;
/* 113 */     if (obj == this) { return 0;
/*     */     }
/* 115 */     TimeTask other = (TimeTask)obj;
/* 116 */     long et = getNextExecutionTime();
/* 117 */     long oet = other.getNextExecutionTime();
/* 118 */     if (et > oet)
/* 119 */       return 1;
/* 120 */     if (et < oet) return -1;
/* 121 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/timer/TimeTask.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */