/*     */ package mx4j.timer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeQueue
/*     */ {
/*     */   private Thread thread;
/*     */   private volatile boolean running;
/*     */   private final ArrayList tasks;
/*     */   private final boolean daemon;
/*     */   
/*     */   public TimeQueue()
/*     */   {
/*  36 */     this(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TimeQueue(boolean daemon)
/*     */   {
/*  44 */     this.tasks = new ArrayList();
/*  45 */     this.daemon = daemon;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/*  56 */     synchronized (this)
/*     */     {
/*  58 */       if (!this.running)
/*     */       {
/*  60 */         this.running = true;
/*  61 */         this.thread = new Thread(new Loop(null), "MBean Timer Notification Thread");
/*  62 */         this.thread.setDaemon(this.daemon);
/*  63 */         this.thread.start();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/*  78 */     synchronized (this)
/*     */     {
/*  80 */       if (this.running)
/*     */       {
/*  82 */         this.running = false;
/*  83 */         this.thread.interrupt();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int size()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: dup
/*     */     //   2: astore_1
/*     */     //   3: monitorenter
/*     */     //   4: aload_0
/*     */     //   5: getfield 8	mx4j/timer/TimeQueue:tasks	Ljava/util/ArrayList;
/*     */     //   8: invokevirtual 18	java/util/ArrayList:size	()I
/*     */     //   11: aload_1
/*     */     //   12: monitorexit
/*     */     //   13: ireturn
/*     */     //   14: astore_2
/*     */     //   15: aload_1
/*     */     //   16: monitorexit
/*     */     //   17: aload_2
/*     */     //   18: athrow
/*     */     // Line number table:
/*     */     //   Java source line #93	-> byte code offset #0
/*     */     //   Java source line #95	-> byte code offset #4
/*     */     //   Java source line #96	-> byte code offset #14
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	19	0	this	TimeQueue
/*     */     //   2	14	1	Ljava/lang/Object;	Object
/*     */     //   14	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	13	14	finally
/*     */     //   14	17	14	finally
/*     */   }
/*     */   
/*     */   public void schedule(TimeTask task)
/*     */   {
/* 106 */     synchronized (this)
/*     */     {
/* 108 */       this.tasks.add(task);
/*     */       
/* 110 */       Collections.sort(this.tasks);
/* 111 */       notifyAll();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void unschedule(TimeTask task)
/*     */   {
/* 122 */     synchronized (this)
/*     */     {
/* 124 */       this.tasks.remove(task);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 133 */     synchronized (this)
/*     */     {
/* 135 */       this.tasks.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   private TimeTask getTask() throws InterruptedException
/*     */   {
/* 141 */     synchronized (this)
/*     */     {
/* 143 */       while (this.tasks.isEmpty())
/*     */       {
/* 145 */         wait();
/*     */       }
/*     */       
/*     */ 
/* 149 */       TimeTask task = (TimeTask)this.tasks.get(0);
/* 150 */       return task;
/*     */     }
/*     */   }
/*     */   
/* 154 */   private class Loop implements Runnable { Loop(TimeQueue.1 x1) { this(); }
/*     */     
/*     */     public void run() {
/*     */       for (;;) {
/* 158 */         if ((TimeQueue.this.running) && (!TimeQueue.this.thread.isInterrupted()))
/*     */         {
/*     */           try
/*     */           {
/* 162 */             TimeTask task = TimeQueue.this.getTask();
/* 163 */             long now = System.currentTimeMillis();
/* 164 */             long executionTime = task.getNextExecutionTime();
/* 165 */             if (executionTime == 0L) executionTime = now;
/* 166 */             long timeToWait = executionTime - now;
/* 167 */             boolean runTask = timeToWait <= 0L;
/* 168 */             if (!runTask)
/*     */             {
/*     */ 
/* 171 */               Object lock = TimeQueue.this;
/* 172 */               synchronized (lock)
/*     */               {
/*     */ 
/* 175 */                 lock.wait(timeToWait);
/*     */               }
/*     */               
/*     */             }
/*     */             else
/*     */             {
/* 181 */               TimeQueue.this.unschedule(task);
/*     */               
/* 183 */               if (task.isPeriodic())
/*     */               {
/*     */ 
/*     */ 
/* 187 */                 if (task.getFixedRate())
/*     */                 {
/* 189 */                   task.setNextExecutionTime(executionTime + task.getPeriod());
/*     */                 }
/*     */                 else
/*     */                 {
/* 193 */                   task.setNextExecutionTime(now + task.getPeriod());
/*     */                 }
/*     */                 
/*     */ 
/* 197 */                 TimeQueue.this.schedule(task);
/*     */ 
/*     */               }
/*     */               else
/*     */               {
/* 202 */                 task.setFinished(true);
/*     */               }
/*     */               
/*     */ 
/*     */               try
/*     */               {
/* 208 */                 task.run();
/*     */ 
/*     */               }
/*     */               catch (Throwable x)
/*     */               {
/* 213 */                 x.printStackTrace();
/*     */               }
/*     */             }
/*     */           }
/*     */           catch (InterruptedException x)
/*     */           {
/* 219 */             Thread.currentThread().interrupt();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private Loop() {}
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/timer/TimeQueue.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */