/*     */ package mx4j.util;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utils
/*     */ {
/*     */   public static Class loadClass(ClassLoader loader, String name)
/*     */     throws ClassNotFoundException
/*     */   {
/*  29 */     if (name == null) { throw new ClassNotFoundException("null");
/*     */     }
/*  31 */     name = name.trim();
/*  32 */     if (name.equals("boolean"))
/*  33 */       return Boolean.TYPE;
/*  34 */     if (name.equals("byte"))
/*  35 */       return Byte.TYPE;
/*  36 */     if (name.equals("char"))
/*  37 */       return Character.TYPE;
/*  38 */     if (name.equals("short"))
/*  39 */       return Short.TYPE;
/*  40 */     if (name.equals("int"))
/*  41 */       return Integer.TYPE;
/*  42 */     if (name.equals("long"))
/*  43 */       return Long.TYPE;
/*  44 */     if (name.equals("float"))
/*  45 */       return Float.TYPE;
/*  46 */     if (name.equals("double"))
/*  47 */       return Double.TYPE;
/*  48 */     if (name.equals("java.lang.String"))
/*  49 */       return String.class;
/*  50 */     if (name.equals("java.lang.Object"))
/*  51 */       return Object.class;
/*  52 */     if (name.startsWith("["))
/*     */     {
/*     */ 
/*  55 */       int dimension = 0;
/*  56 */       while (name.charAt(dimension) == '[')
/*     */       {
/*  58 */         dimension++;
/*     */       }
/*  60 */       char type = name.charAt(dimension);
/*  61 */       Class cls = null;
/*  62 */       switch (type)
/*     */       {
/*     */       case 'Z': 
/*  65 */         cls = Boolean.TYPE;
/*  66 */         break;
/*     */       case 'B': 
/*  68 */         cls = Byte.TYPE;
/*  69 */         break;
/*     */       case 'C': 
/*  71 */         cls = Character.TYPE;
/*  72 */         break;
/*     */       case 'S': 
/*  74 */         cls = Short.TYPE;
/*  75 */         break;
/*     */       case 'I': 
/*  77 */         cls = Integer.TYPE;
/*  78 */         break;
/*     */       case 'J': 
/*  80 */         cls = Long.TYPE;
/*  81 */         break;
/*     */       case 'F': 
/*  83 */         cls = Float.TYPE;
/*  84 */         break;
/*     */       case 'D': 
/*  86 */         cls = Double.TYPE;
/*  87 */         break;
/*     */       
/*     */       case 'L': 
/*  90 */         String n = name.substring(dimension + 1, name.length() - 1);
/*  91 */         cls = loadClass(loader, n);
/*     */       }
/*     */       
/*     */       
/*  95 */       if (cls == null)
/*     */       {
/*  97 */         throw new ClassNotFoundException(name);
/*     */       }
/*     */       
/*     */ 
/* 101 */       int[] dim = new int[dimension];
/* 102 */       return Array.newInstance(cls, dim).getClass();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 107 */     if (loader != null) {
/* 108 */       return loader.loadClass(name);
/*     */     }
/* 110 */     return Class.forName(name, false, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class[] loadClasses(ClassLoader loader, String[] names)
/*     */     throws ClassNotFoundException
/*     */   {
/* 120 */     int n = names.length;
/* 121 */     Class[] cls = new Class[n];
/* 122 */     for (int i = 0; i < n; i++)
/*     */     {
/* 124 */       String name = names[i];
/* 125 */       cls[i] = loadClass(loader, name);
/*     */     }
/* 127 */     return cls;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAttributeGetter(Method m)
/*     */   {
/* 135 */     if (m == null) { return false;
/*     */     }
/* 137 */     String name = m.getName();
/* 138 */     Class retType = m.getReturnType();
/* 139 */     Class[] params = m.getParameterTypes();
/* 140 */     if ((retType != Void.TYPE) && (params.length == 0))
/*     */     {
/* 142 */       if ((name.startsWith("get")) && (name.length() > 3))
/* 143 */         return true;
/* 144 */       if ((name.startsWith("is")) && (retType == Boolean.TYPE)) return true;
/*     */     }
/* 146 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAttributeSetter(Method m)
/*     */   {
/* 154 */     if (m == null) { return false;
/*     */     }
/* 156 */     String name = m.getName();
/* 157 */     Class retType = m.getReturnType();
/* 158 */     Class[] params = m.getParameterTypes();
/* 159 */     if ((retType == Void.TYPE) && (params.length == 1) && (name.startsWith("set")) && (name.length() > 3))
/*     */     {
/* 161 */       return true;
/*     */     }
/* 163 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean wildcardMatch(String pattern, String string)
/*     */   {
/* 168 */     int stringLength = string.length();
/* 169 */     int stringIndex = 0;
/* 170 */     for (int patternIndex = 0; patternIndex < pattern.length(); patternIndex++)
/*     */     {
/* 172 */       char c = pattern.charAt(patternIndex);
/* 173 */       if (c == '*')
/*     */       {
/*     */ 
/*     */ 
/* 177 */         while (stringIndex < stringLength)
/*     */         {
/* 179 */           if (wildcardMatch(pattern.substring(patternIndex + 1), string.substring(stringIndex)))
/*     */           {
/* 181 */             return true;
/*     */           }
/*     */           
/* 184 */           stringIndex++;
/*     */         }
/*     */       }
/* 187 */       if (c == '?')
/*     */       {
/*     */ 
/* 190 */         stringIndex++;
/* 191 */         if (stringIndex > stringLength)
/*     */         {
/* 193 */           return false;
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 199 */         if ((stringIndex >= stringLength) || (c != string.charAt(stringIndex)))
/*     */         {
/* 201 */           return false;
/*     */         }
/* 203 */         stringIndex++;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 208 */     return stringIndex == stringLength;
/*     */   }
/*     */   
/*     */   public static boolean arrayEquals(Object[] arr1, Object[] arr2)
/*     */   {
/* 213 */     if ((arr1 == null) && (arr2 == null)) return true;
/* 214 */     if (((arr1 == null ? 1 : 0) ^ (arr2 == null ? 1 : 0)) != 0) return false;
/* 215 */     if (!arr1.getClass().equals(arr2.getClass())) return false;
/* 216 */     if (arr1.length != arr2.length) { return false;
/*     */     }
/* 218 */     for (int i = 0; i < arr1.length; i++)
/*     */     {
/* 220 */       Object obj1 = arr1[i];
/* 221 */       Object obj2 = arr2[i];
/* 222 */       if (((obj1 == null ? 1 : 0) ^ (obj2 == null ? 1 : 0)) != 0) return false;
/* 223 */       if ((obj1 != null) && (!obj1.equals(obj2))) return false;
/*     */     }
/* 225 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean arrayEquals(byte[] arr1, byte[] arr2)
/*     */   {
/* 230 */     if ((arr1 == null) && (arr2 == null)) return true;
/* 231 */     if (((arr1 == null ? 1 : 0) ^ (arr2 == null ? 1 : 0)) != 0) return false;
/* 232 */     if (!arr1.getClass().equals(arr2.getClass())) return false;
/* 233 */     if (arr1.length != arr2.length) { return false;
/*     */     }
/* 235 */     for (int i = 0; i < arr1.length; i++)
/*     */     {
/* 237 */       byte b1 = arr1[i];
/* 238 */       byte b2 = arr2[i];
/* 239 */       if (b1 != b2) return false;
/*     */     }
/* 241 */     return true;
/*     */   }
/*     */   
/*     */   public static int arrayHashCode(Object[] arr)
/*     */   {
/* 246 */     int hash = 0;
/* 247 */     if (arr != null)
/*     */     {
/*     */ 
/* 250 */       hash ^= arr.getClass().hashCode();
/* 251 */       for (int i = 0; i < arr.length; i++)
/*     */       {
/* 253 */         hash ^= (arr[i] == null ? 0 : arr[i].hashCode());
/*     */       }
/*     */     }
/* 256 */     return hash;
/*     */   }
/*     */   
/*     */   public static int arrayHashCode(byte[] arr)
/*     */   {
/* 261 */     int hash = 0;
/* 262 */     if (arr != null)
/*     */     {
/*     */ 
/* 265 */       hash ^= arr.getClass().hashCode();
/* 266 */       for (int i = 0; i < arr.length; i++)
/*     */       {
/* 268 */         hash ^= arr[i];
/*     */       }
/*     */     }
/* 271 */     return hash;
/*     */   }
/*     */   
/*     */   public static char[] arrayCopy(char[] chars)
/*     */   {
/* 276 */     if (chars == null) return null;
/* 277 */     char[] copy = new char[chars.length];
/* 278 */     System.arraycopy(chars, 0, copy, 0, chars.length);
/* 279 */     return copy;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/util/Utils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */