package mx4j;

public final class MX4JSystemKeys
{
  public static final String MX4J_MBEANSERVER_REPOSITORY = "mx4j.mbeanserver.repository";
  public static final String MX4J_MBEANSERVER_CLASSLOADER_REPOSITORY = "mx4j.mbeanserver.classloader.repository";
  public static final String MX4J_LOG_PRIORITY = "mx4j.log.priority";
  public static final String MX4J_LOG_PROTOTYPE = "mx4j.log.prototype";
  public static final String MX4J_STRICT_MBEAN_INTERFACE = "mx4j.strict.mbean.interface";
  public static final String MX4J_MBEAN_INVOKER = "mx4j.mbean.invoker";
  public static final String MX4J_OBJECTNAME_CACHING = "mx4j.objectname.caching";
  public static final String MX4J_MBEAN_METADATA = "mx4j.mbean.metadata";
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/MX4JSystemKeys.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */