package mx4j;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public abstract interface MBeanDescription
{
  public abstract String getMBeanDescription();
  
  public abstract String getConstructorDescription(Constructor paramConstructor);
  
  public abstract String getConstructorParameterName(Constructor paramConstructor, int paramInt);
  
  public abstract String getConstructorParameterDescription(Constructor paramConstructor, int paramInt);
  
  public abstract String getAttributeDescription(String paramString);
  
  public abstract String getOperationDescription(Method paramMethod);
  
  public abstract String getOperationParameterName(Method paramMethod, int paramInt);
  
  public abstract String getOperationParameterDescription(Method paramMethod, int paramInt);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-impl.jar!/mx4j/MBeanDescription.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */