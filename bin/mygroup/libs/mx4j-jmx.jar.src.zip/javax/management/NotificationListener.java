package javax.management;

import java.util.EventListener;

public abstract interface NotificationListener
  extends EventListener
{
  public abstract void handleNotification(Notification paramNotification, Object paramObject);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/NotificationListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */