/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BooleanValueExp
/*    */   extends QueryEval
/*    */   implements ValueExp
/*    */ {
/*    */   private static final long serialVersionUID = 7754922052666594581L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final boolean val;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   BooleanValueExp(boolean val)
/*    */   {
/* 23 */     this.val = val;
/*    */   }
/*    */   
/*    */   boolean booleanValue()
/*    */   {
/* 28 */     return this.val;
/*    */   }
/*    */   
/*    */   public ValueExp apply(ObjectName name) throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException
/*    */   {
/* 33 */     return this;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/BooleanValueExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */