package javax.management;

public abstract interface DescriptorAccess
{
  public abstract Descriptor getDescriptor();
  
  public abstract void setDescriptor(Descriptor paramDescriptor);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/DescriptorAccess.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */