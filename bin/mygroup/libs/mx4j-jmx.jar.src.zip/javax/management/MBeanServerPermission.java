/*     */ package javax.management;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.security.BasicPermission;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanServerPermission
/*     */   extends BasicPermission
/*     */ {
/*     */   private static final long serialVersionUID = -5661980843569388590L;
/*     */   private transient ArrayList targets;
/*     */   private transient boolean wildcard;
/*     */   
/*     */   public MBeanServerPermission(String name)
/*     */   {
/*  49 */     this(name, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MBeanServerPermission(String name, String actions)
/*     */   {
/*  60 */     super(name);
/*  61 */     parseName(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getActions()
/*     */   {
/*  69 */     return null;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  74 */     return this.targets.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  79 */     if (obj == null) return false;
/*  80 */     if (obj == this) { return true;
/*     */     }
/*     */     try
/*     */     {
/*  84 */       MBeanServerPermission other = (MBeanServerPermission)obj;
/*     */       
/*  86 */       return this.targets.equals(other.targets);
/*     */     }
/*     */     catch (ClassCastException x) {}
/*     */     
/*     */ 
/*  91 */     return false;
/*     */   }
/*     */   
/*     */   public boolean implies(Permission p)
/*     */   {
/*  96 */     if (p == null) return false;
/*  97 */     if (getClass() != p.getClass()) { return false;
/*     */     }
/*  99 */     MBeanServerPermission other = (MBeanServerPermission)p;
/* 100 */     if (this.wildcard) return true;
/* 101 */     if (other.wildcard) { return false;
/*     */     }
/* 103 */     if (this.targets.containsAll(other.targets)) { return true;
/*     */     }
/*     */     
/* 106 */     if ((other.targets.contains("newMBeanServer")) && (this.targets.contains("createMBeanServer")))
/*     */     {
/*     */ 
/*     */ 
/* 110 */       for (int i = 0; i < other.targets.size(); i++)
/*     */       {
/* 112 */         Object perm = other.targets.get(i);
/* 113 */         if ((!"newMBeanServer".equals(perm)) && 
/* 114 */           (!this.targets.contains(perm))) return false;
/*     */       }
/* 116 */       return true;
/*     */     }
/*     */     
/* 119 */     return false;
/*     */   }
/*     */   
/*     */   private void parseName(String name)
/*     */   {
/* 124 */     if (name == null) throw new IllegalArgumentException("Permission name cannot be null");
/* 125 */     name = name.trim();
/* 126 */     if (name.length() == 0) { throw new IllegalArgumentException("Permission name cannot be empty");
/*     */     }
/* 128 */     this.targets = new ArrayList();
/* 129 */     StringTokenizer tokenizer = new StringTokenizer(name, ",");
/* 130 */     while (tokenizer.hasMoreTokens())
/*     */     {
/* 132 */       String target = tokenizer.nextToken().trim();
/* 133 */       if (target.length() != 0) {
/* 134 */         if ("*".equals(target))
/*     */         {
/* 136 */           this.targets.clear();
/* 137 */           this.wildcard = true;
/* 138 */           return;
/*     */         }
/*     */         
/*     */ 
/* 142 */         this.targets.add(target);
/*     */       }
/*     */     }
/*     */     
/* 146 */     if (this.targets.size() < 1) { throw new IllegalArgumentException("Permission name does not contain targets");
/*     */     }
/*     */     
/* 149 */     Collections.sort(this.targets);
/*     */   }
/*     */   
/*     */   public PermissionCollection newPermissionCollection()
/*     */   {
/* 154 */     return null;
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
/*     */   {
/* 159 */     stream.defaultReadObject();
/* 160 */     parseName(getName());
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanServerPermission.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */