/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeChangeNotification
/*    */   extends Notification
/*    */ {
/*    */   private static final long serialVersionUID = 535176054565814134L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final String ATTRIBUTE_CHANGE = "jmx.attribute.change";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final String attributeName;
/*    */   
/*    */ 
/*    */ 
/*    */   private final String attributeType;
/*    */   
/*    */ 
/*    */ 
/*    */   private final Object oldValue;
/*    */   
/*    */ 
/*    */ 
/*    */   private final Object newValue;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public AttributeChangeNotification(Object source, long sequenceNumber, long timestamp, String message, String attributeName, String attributeType, Object oldValue, Object newValue)
/*    */   {
/* 39 */     super("jmx.attribute.change", source, sequenceNumber, timestamp, message);
/* 40 */     this.attributeName = attributeName;
/* 41 */     this.attributeType = attributeType;
/* 42 */     this.oldValue = oldValue;
/* 43 */     this.newValue = newValue;
/*    */   }
/*    */   
/*    */   public String getAttributeName()
/*    */   {
/* 48 */     return this.attributeName;
/*    */   }
/*    */   
/*    */   public String getAttributeType()
/*    */   {
/* 53 */     return this.attributeType;
/*    */   }
/*    */   
/*    */   public Object getOldValue()
/*    */   {
/* 58 */     return this.oldValue;
/*    */   }
/*    */   
/*    */   public Object getNewValue()
/*    */   {
/* 63 */     return this.newValue;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/AttributeChangeNotification.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */