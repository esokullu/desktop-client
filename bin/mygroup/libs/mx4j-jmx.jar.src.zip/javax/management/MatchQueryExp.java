/*     */ package javax.management;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MatchQueryExp
/*     */   extends QueryEval
/*     */   implements QueryExp
/*     */ {
/*     */   private static final long serialVersionUID = -7156603696948215014L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final AttributeValueExp exp;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String pattern;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   MatchQueryExp(AttributeValueExp exp, StringValueExp pattern)
/*     */   {
/*  30 */     this.exp = exp;
/*  31 */     this.pattern = (pattern == null ? null : pattern.getValue());
/*     */   }
/*     */   
/*     */   public void setMBeanServer(MBeanServer server)
/*     */   {
/*  36 */     super.setMBeanServer(server);
/*  37 */     if (this.exp != null) this.exp.setMBeanServer(server);
/*     */   }
/*     */   
/*     */   public boolean apply(ObjectName name) throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException
/*     */   {
/*  42 */     ValueExp value = this.exp.apply(name);
/*  43 */     if ((value instanceof StringValueExp))
/*     */     {
/*  45 */       return wildcardMatch(((StringValueExp)value).getValue(), this.pattern);
/*     */     }
/*  47 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean wildcardMatch(String s, String p)
/*     */   {
/*  59 */     if ((s == null) && (p == null)) return true;
/*  60 */     if (s == null) return false;
/*  61 */     if (p == null) { return true;
/*     */     }
/*     */     
/*  64 */     int si = 0;int pi = 0;
/*  65 */     int slen = s.length();
/*  66 */     int plen = p.length();
/*     */     
/*  68 */     while (pi < plen)
/*     */     {
/*  70 */       char c = p.charAt(pi++);
/*  71 */       if (c == '?')
/*     */       {
/*  73 */         si++; if (si > slen) return false;
/*     */       }
/*  75 */       else if (c == '[')
/*     */       {
/*  77 */         boolean wantit = true;
/*  78 */         boolean seenit = false;
/*  79 */         if (p.charAt(pi) == '!')
/*     */         {
/*  81 */           wantit = false;
/*  82 */           pi++;
/*     */         }
/*  84 */         for (;;) { pi++; if ((pi >= plen) || ((c = p.charAt(pi)) == ']'))
/*     */             break;
/*  86 */           if ((p.charAt(pi) == '-') && (pi + 1 < plen))
/*     */           {
/*  88 */             if ((s.charAt(si) >= c) && (s.charAt(si) <= p.charAt(pi + 1)))
/*     */             {
/*  90 */               seenit = true;
/*     */             }
/*  92 */             pi++;
/*     */ 
/*     */ 
/*     */           }
/*  96 */           else if (c == s.charAt(si))
/*     */           {
/*  98 */             seenit = true;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 103 */         if ((pi >= plen) || (wantit != seenit)) { return false;
/*     */         }
/* 105 */         pi++;
/* 106 */         si++;
/*     */       } else {
/* 108 */         if (c == '*')
/*     */         {
/* 110 */           if (pi >= plen) { return true;
/*     */           }
/*     */           do
/*     */           {
/* 114 */             if (wildcardMatch(s.substring(si), p.substring(pi))) { return true;
/*     */             }
/* 116 */             si++; } while (si < slen);
/* 117 */           return false;
/*     */         }
/* 119 */         if (c == '\\')
/*     */         {
/* 121 */           if ((pi >= plen) || (p.charAt(pi++) != s.charAt(si++))) { return false;
/*     */           }
/*     */           
/*     */         }
/* 125 */         else if ((si >= slen) || (c != s.charAt(si++))) return false;
/*     */       }
/*     */     }
/* 128 */     return si == slen;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MatchQueryExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */