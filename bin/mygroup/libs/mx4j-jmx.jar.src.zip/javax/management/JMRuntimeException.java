/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMRuntimeException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 6573344628407841861L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public JMRuntimeException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public JMRuntimeException(String message)
/*    */   {
/* 24 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/JMRuntimeException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */