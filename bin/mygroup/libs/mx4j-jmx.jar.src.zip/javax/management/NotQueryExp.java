/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NotQueryExp
/*    */   extends QueryEval
/*    */   implements QueryExp
/*    */ {
/*    */   private static final long serialVersionUID = 5269643775896723397L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private QueryExp exp;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   NotQueryExp(QueryExp exp)
/*    */   {
/* 28 */     this.exp = exp;
/*    */   }
/*    */   
/*    */   public void setMBeanServer(MBeanServer server)
/*    */   {
/* 33 */     super.setMBeanServer(server);
/* 34 */     if (this.exp != null) this.exp.setMBeanServer(server);
/*    */   }
/*    */   
/*    */   public boolean apply(ObjectName name) throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException
/*    */   {
/* 39 */     if (this.exp != null) return !this.exp.apply(name);
/* 40 */     return false;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/NotQueryExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */