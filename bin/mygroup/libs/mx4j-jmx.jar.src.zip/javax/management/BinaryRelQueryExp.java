/*     */ package javax.management;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BinaryRelQueryExp
/*     */   extends QueryEval
/*     */   implements QueryExp
/*     */ {
/*     */   private static final long serialVersionUID = -5690656271650491000L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ValueExp exp1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int relOp;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ValueExp exp2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   BinaryRelQueryExp(int operation, ValueExp exp1, ValueExp exp2)
/*     */   {
/*  34 */     this.relOp = operation;
/*  35 */     this.exp1 = exp1;
/*  36 */     this.exp2 = exp2;
/*     */   }
/*     */   
/*     */   public void setMBeanServer(MBeanServer server)
/*     */   {
/*  41 */     super.setMBeanServer(server);
/*  42 */     if (this.exp1 != null) this.exp1.setMBeanServer(server);
/*  43 */     if (this.exp2 != null) this.exp2.setMBeanServer(server);
/*     */   }
/*     */   
/*     */   public boolean apply(ObjectName name) throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException
/*     */   {
/*  48 */     if ((this.exp1 == null) && (this.exp2 == null) && ((this.relOp == 4) || (this.relOp == 2) || (this.relOp == 3)))
/*     */     {
/*  50 */       return true;
/*     */     }
/*     */     
/*  53 */     if ((this.exp1 != null) && (this.exp2 != null))
/*     */     {
/*  55 */       ValueExp val1 = this.exp1.apply(name);
/*  56 */       ValueExp val2 = this.exp2.apply(name);
/*     */       
/*  58 */       if (((val1 instanceof NumericValueExp)) && ((val2 instanceof NumericValueExp)))
/*     */       {
/*  60 */         NumericValueExp num1 = (NumericValueExp)val1;
/*  61 */         NumericValueExp num2 = (NumericValueExp)val2;
/*     */         
/*  63 */         if ((num1.isDouble()) || (num2.isDouble()))
/*     */         {
/*  65 */           return compare(new Double(num1.doubleValue()), new Double(num2.doubleValue()));
/*     */         }
/*     */         
/*     */ 
/*  69 */         return compare(new Long(num1.longValue()), new Long(num2.longValue()));
/*     */       }
/*     */       
/*  72 */       if (((val1 instanceof BooleanValueExp)) && ((val2 instanceof BooleanValueExp)))
/*     */       {
/*  74 */         boolean b1 = ((BooleanValueExp)val1).booleanValue();
/*  75 */         boolean b2 = ((BooleanValueExp)val2).booleanValue();
/*  76 */         return compare(new Long(b1 ? 1L : 0L), new Long(b2 ? 1L : 0L));
/*     */       }
/*  78 */       if (((val1 instanceof StringValueExp)) && ((val2 instanceof StringValueExp)))
/*     */       {
/*  80 */         String s1 = ((StringValueExp)val1).getValue();
/*  81 */         String s2 = ((StringValueExp)val2).getValue();
/*  82 */         return compare(s1, s2);
/*     */       }
/*     */     }
/*     */     
/*  86 */     return false;
/*     */   }
/*     */   
/*     */   private boolean compare(Comparable c1, Comparable c2)
/*     */   {
/*  91 */     switch (this.relOp)
/*     */     {
/*     */     case 4: 
/*  94 */       if ((c1 == null) && (c2 == null)) return true;
/*  95 */       if ((c1 == null) || (c2 == null)) return false;
/*  96 */       return c1.equals(c2);
/*     */     case 2: 
/*  98 */       if ((c1 == null) && (c2 == null)) return true;
/*  99 */       if ((c1 == null) && (c2 != null)) return false;
/* 100 */       if ((c1 != null) && (c2 == null)) return true;
/* 101 */       return c1.compareTo(c2) >= 0;
/*     */     case 3: 
/* 103 */       if ((c1 == null) && (c2 == null)) return true;
/* 104 */       if ((c1 == null) && (c2 != null)) return true;
/* 105 */       if ((c1 != null) && (c2 == null)) return false;
/* 106 */       return c1.compareTo(c2) <= 0;
/*     */     case 0: 
/* 108 */       if ((c1 == null) && (c2 == null)) return false;
/* 109 */       if ((c1 == null) && (c2 != null)) return false;
/* 110 */       if ((c1 != null) && (c2 == null)) return true;
/* 111 */       return c1.compareTo(c2) > 0;
/*     */     case 1: 
/* 113 */       if ((c1 == null) && (c2 == null)) return false;
/* 114 */       if ((c1 == null) && (c2 != null)) return true;
/* 115 */       if ((c1 != null) && (c2 == null)) return false;
/* 116 */       return c1.compareTo(c2) < 0;
/*     */     }
/* 118 */     return false;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/BinaryRelQueryExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */