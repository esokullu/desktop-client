package javax.management;

public abstract interface PersistentMBean
{
  public abstract void load()
    throws MBeanException, InstanceNotFoundException, RuntimeOperationsException;
  
  public abstract void store()
    throws MBeanException, RuntimeOperationsException, InstanceNotFoundException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/PersistentMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */