/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidApplicationException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -3048022274675537269L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final Object val;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidApplicationException(Object value)
/*    */   {
/* 25 */     super(String.valueOf(value));
/* 26 */     this.val = value;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/InvalidApplicationException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */