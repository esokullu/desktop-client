/*     */ package javax.management;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NotificationBroadcasterSupport
/*     */   implements NotificationEmitter
/*     */ {
/*  41 */   private static final NotificationFilter NULL_FILTER = new NotificationFilter()
/*     */   {
/*     */     public boolean isNotificationEnabled(Notification notification)
/*     */     {
/*  45 */       return true;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/*  50 */       return "null filter";
/*     */     }
/*     */   };
/*     */   
/*  54 */   private static final Object NULL_HANDBACK = new Object()
/*     */   {
/*     */     public String toString()
/*     */     {
/*  58 */       return "null handback";
/*     */     }
/*     */   };
/*     */   
/*  62 */   private HashMap m_listeners = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Logger getLogger()
/*     */   {
/*  70 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */   
/*     */   public void addNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback)
/*     */   {
/*  75 */     Logger logger = getLogger();
/*     */     
/*  77 */     if (logger.isEnabledFor(0)) { logger.trace("Adding notification listener: " + listener + ", filter: " + filter + ", handback: " + handback + " to " + this);
/*     */     }
/*  79 */     if (listener == null) { throw new IllegalArgumentException("Notification listener cannot be null");
/*     */     }
/*     */     
/*  82 */     if (filter == null) filter = NULL_FILTER;
/*  83 */     if (handback == null) { handback = NULL_HANDBACK;
/*     */     }
/*  85 */     FilterHandbackPair pair = new FilterHandbackPair(filter, handback, null);
/*     */     
/*  87 */     synchronized (this)
/*     */     {
/*  89 */       ArrayList pairs = (ArrayList)this.m_listeners.get(listener);
/*     */       
/*  91 */       if (pairs == null)
/*     */       {
/*     */ 
/*  94 */         pairs = new ArrayList();
/*  95 */         pairs.add(pair);
/*  96 */         this.m_listeners.put(listener, pairs);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 101 */         for (int i = 0; i < pairs.size(); i++)
/*     */         {
/* 103 */           FilterHandbackPair other = (FilterHandbackPair)pairs.get(i);
/* 104 */           if ((pair.filter.equals(other.filter)) && (pair.handback.equals(other.handback)))
/*     */           {
/*     */ 
/* 107 */             throw new RuntimeOperationsException(new IllegalArgumentException("Notification listener is already registered"));
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 113 */         pairs.add(pair);
/*     */       }
/*     */       
/* 116 */       if (logger.isEnabledFor(0)) { logger.trace("Filters - Handbacks for this listener: " + pairs);
/*     */       }
/*     */     }
/* 119 */     if (logger.isEnabledFor(0)) logger.trace("Notification listener added successfully to " + this);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(NotificationListener listener) throws ListenerNotFoundException
/*     */   {
/* 124 */     Logger logger = getLogger();
/* 125 */     if (logger.isEnabledFor(0)) { logger.trace("Removing notification listener: " + listener);
/*     */     }
/* 127 */     int removed = removeNotificationListenerImpl(listener, null, null);
/*     */     
/* 129 */     if (logger.isEnabledFor(0)) logger.trace(removed + " notification listener(s) removed successfully from " + this);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback) throws ListenerNotFoundException
/*     */   {
/* 134 */     Logger logger = getLogger();
/* 135 */     if (logger.isEnabledFor(0)) { logger.trace("Removing notification listener: " + listener + ", filter: " + filter + ", handback: " + handback);
/*     */     }
/*     */     
/* 138 */     if (filter == null) filter = NULL_FILTER;
/* 139 */     if (handback == null) { handback = NULL_HANDBACK;
/*     */     }
/* 141 */     int removed = removeNotificationListenerImpl(listener, filter, handback);
/*     */     
/* 143 */     if (logger.isEnabledFor(0)) logger.trace(removed + " notification listener(s) removed successfully from " + this);
/*     */   }
/*     */   
/*     */   private int removeNotificationListenerImpl(NotificationListener listener, NotificationFilter filter, Object handback) throws ListenerNotFoundException
/*     */   {
/* 148 */     Logger logger = getLogger();
/* 149 */     synchronized (this)
/*     */     {
/* 151 */       if (logger.isEnabledFor(0)) { logger.trace("Listeners for " + this + " are: " + this.m_listeners);
/*     */       }
/* 153 */       ArrayList pairs = (ArrayList)this.m_listeners.get(listener);
/*     */       
/* 155 */       if (pairs == null) { throw new ListenerNotFoundException("NotificationListener " + listener + " not found");
/*     */       }
/* 157 */       if (filter == null)
/*     */       {
/* 159 */         if (handback == null)
/*     */         {
/*     */ 
/*     */ 
/* 163 */           ArrayList removed = (ArrayList)this.m_listeners.remove(listener);
/* 164 */           return removed.size();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 170 */         int count = 0;
/* 171 */         for (int i = 0; i < pairs.size(); i++)
/*     */         {
/* 173 */           Object hand = ((FilterHandbackPair)pairs.get(i)).handback;
/* 174 */           if (handback.equals(hand))
/*     */           {
/* 176 */             pairs.remove(i);
/* 177 */             count++;
/*     */           }
/*     */         }
/* 180 */         if (count == 0) { throw new ListenerNotFoundException("NotificationListener " + listener + " with handback " + handback + " not found");
/*     */         }
/*     */         
/* 183 */         if (pairs.isEmpty()) { this.m_listeners.remove(listener);
/*     */         }
/* 185 */         return count;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 190 */       if (handback == null)
/*     */       {
/*     */ 
/*     */ 
/* 194 */         int count = 0;
/* 195 */         for (int i = 0; i < pairs.size(); i++)
/*     */         {
/* 197 */           Object filt = ((FilterHandbackPair)pairs.get(i)).filter;
/* 198 */           if (filter.equals(filt))
/*     */           {
/* 200 */             pairs.remove(i);
/* 201 */             count++;
/*     */           }
/*     */         }
/* 204 */         if (count == 0) { throw new ListenerNotFoundException("NotificationListener " + listener + " with filter " + filter + " not found");
/*     */         }
/*     */         
/* 207 */         if (pairs.isEmpty()) { this.m_listeners.remove(listener);
/*     */         }
/* 209 */         return count;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 215 */       int count = 0;
/* 216 */       for (int i = 0; i < pairs.size(); i++)
/*     */       {
/* 218 */         FilterHandbackPair pair = (FilterHandbackPair)pairs.get(i);
/* 219 */         if ((filter.equals(pair.filter)) && (handback.equals(pair.handback)))
/*     */         {
/* 221 */           pairs.remove(i);
/* 222 */           count++;
/*     */         }
/*     */       }
/* 225 */       if (count == 0) { throw new ListenerNotFoundException("NotificationListener " + listener + " with filter " + filter + " and handback " + handback + " not found");
/*     */       }
/*     */       
/* 228 */       if (pairs.isEmpty()) { this.m_listeners.remove(listener);
/*     */       }
/* 230 */       return count;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MBeanNotificationInfo[] getNotificationInfo()
/*     */   {
/* 239 */     return new MBeanNotificationInfo[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sendNotification(Notification notification)
/*     */   {
/* 249 */     Logger logger = getLogger();
/* 250 */     boolean trace = logger.isEnabledFor(0);
/* 251 */     boolean info = logger.isEnabledFor(20);
/*     */     
/* 253 */     HashMap listeners = null;
/*     */     
/* 255 */     synchronized (this)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 260 */       listeners = (HashMap)this.m_listeners.clone();
/*     */     }
/*     */     
/*     */ 
/* 264 */     Iterator i = listeners.keySet().iterator();
/*     */     
/* 266 */     if ((i.hasNext()) && (trace)) { logger.trace("Sending notifications from " + this);
/*     */     }
/* 268 */     while (i.hasNext())
/*     */     {
/* 270 */       NotificationListener listener = (NotificationListener)i.next();
/* 271 */       if (trace) { logger.trace("\tListener is: " + listener);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 276 */       ArrayList pairs = null;
/* 277 */       synchronized (this)
/*     */       {
/* 279 */         pairs = (ArrayList)listeners.get(listener);
/* 280 */         pairs = (ArrayList)pairs.clone();
/*     */       }
/*     */       
/* 283 */       if (trace) { logger.trace("\tFilters - Handback for this listener: " + pairs);
/*     */       }
/*     */       
/* 286 */       for (int j = 0; j < pairs.size(); j++)
/*     */       {
/* 288 */         FilterHandbackPair pair = (FilterHandbackPair)pairs.get(j);
/*     */         
/* 290 */         NotificationFilter filter = pair.filter;
/* 291 */         Object handback = pair.handback;
/*     */         
/*     */ 
/* 294 */         if (filter == NULL_FILTER) filter = null;
/* 295 */         if (handback == NULL_HANDBACK) { handback = null;
/*     */         }
/* 297 */         boolean enabled = false;
/*     */         try
/*     */         {
/* 300 */           enabled = (filter == null) || (filter.isNotificationEnabled(notification));
/*     */         }
/*     */         catch (Throwable x)
/*     */         {
/* 304 */           if (info) { logger.info("Throwable caught from isNotificationEnabled", x);
/*     */           }
/*     */         }
/*     */         
/* 308 */         if (trace) { logger.trace("\t\tFilter is: " + filter + ", enabled: " + enabled);
/*     */         }
/* 310 */         if (enabled)
/*     */         {
/* 312 */           if (trace)
/*     */           {
/* 314 */             logger.debug("\t\tHandback is: " + handback);
/* 315 */             logger.debug("\t\tSending notification " + notification);
/*     */           }
/*     */           
/*     */           try
/*     */           {
/* 320 */             handleNotification(listener, notification, handback);
/*     */           }
/*     */           catch (Throwable x)
/*     */           {
/* 324 */             if (info) { logger.info("Throwable caught from handleNotification", x);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 347 */   protected void handleNotification(NotificationListener listener, Notification notification, Object handback) { listener.handleNotification(notification, handback); }
/*     */   
/*     */   private static class FilterHandbackPair {
/* 350 */     FilterHandbackPair(NotificationFilter x0, Object x1, NotificationBroadcasterSupport.1 x2) { this(x0, x1); }
/*     */     
/*     */ 
/*     */     private NotificationFilter filter;
/*     */     private Object handback;
/*     */     private FilterHandbackPair(NotificationFilter filter, Object handback)
/*     */     {
/* 357 */       this.filter = filter;
/* 358 */       this.handback = handback;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/NotificationBroadcasterSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */