/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ /**
/*    */  * @deprecated
/*    */  */
/*    */ public class DefaultLoaderRepository
/*    */ {
/*    */   /**
/*    */    * @deprecated
/*    */    */
/*    */   public static Class loadClass(String s)
/*    */     throws ClassNotFoundException
/*    */   {
/* 26 */     return javax.management.loading.DefaultLoaderRepository.loadClass(s);
/*    */   }
/*    */   
/*    */ 
/*    */   /**
/*    */    * @deprecated
/*    */    */
/*    */   public static Class loadClassWithout(ClassLoader classloader, String s)
/*    */     throws ClassNotFoundException
/*    */   {
/* 36 */     return javax.management.loading.DefaultLoaderRepository.loadClassWithout(classloader, s);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/DefaultLoaderRepository.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */