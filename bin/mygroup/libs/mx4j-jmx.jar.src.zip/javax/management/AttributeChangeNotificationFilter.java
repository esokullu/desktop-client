/*     */ package javax.management;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectInputStream.GetField;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectOutputStream.PutField;
/*     */ import java.io.ObjectStreamField;
/*     */ import java.io.Serializable;
/*     */ import java.io.StreamCorruptedException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttributeChangeNotificationFilter
/*     */   implements NotificationFilter, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -6347317584796410029L;
/*     */   private static final String serialName = "enabledAttributes";
/*  34 */   private static final ObjectStreamField[] serialPersistentFields = { new ObjectStreamField("enabledAttributes", Vector.class) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  39 */   private HashSet enabledAttributes = new HashSet();
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  43 */     return this.enabledAttributes.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  48 */     if (obj == null) return false;
/*  49 */     if (obj == this) { return true;
/*     */     }
/*     */     try
/*     */     {
/*  53 */       AttributeChangeNotificationFilter other = (AttributeChangeNotificationFilter)obj;
/*  54 */       return getEnabledAttributes().equals(other.getEnabledAttributes());
/*     */     }
/*     */     catch (ClassCastException x) {}
/*     */     
/*     */ 
/*  59 */     return false;
/*     */   }
/*     */   
/*     */   public void enableAttribute(String name) throws IllegalArgumentException
/*     */   {
/*  64 */     if (name == null) throw new IllegalArgumentException("Name cannot be null");
/*  65 */     synchronized (this.enabledAttributes)
/*     */     {
/*  67 */       this.enabledAttributes.add(name);
/*     */     }
/*     */   }
/*     */   
/*     */   public void disableAttribute(String name)
/*     */   {
/*  73 */     if (name != null)
/*     */     {
/*  75 */       synchronized (this.enabledAttributes)
/*     */       {
/*  77 */         this.enabledAttributes.remove(name);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void disableAllAttributes()
/*     */   {
/*  84 */     synchronized (this.enabledAttributes)
/*     */     {
/*  86 */       this.enabledAttributes.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Vector getEnabledAttributes()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 9	javax/management/AttributeChangeNotificationFilter:enabledAttributes	Ljava/util/HashSet;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: new 21	java/util/Vector
/*     */     //   10: dup
/*     */     //   11: aload_0
/*     */     //   12: getfield 9	javax/management/AttributeChangeNotificationFilter:enabledAttributes	Ljava/util/HashSet;
/*     */     //   15: invokespecial 22	java/util/Vector:<init>	(Ljava/util/Collection;)V
/*     */     //   18: aload_1
/*     */     //   19: monitorexit
/*     */     //   20: areturn
/*     */     //   21: astore_2
/*     */     //   22: aload_1
/*     */     //   23: monitorexit
/*     */     //   24: aload_2
/*     */     //   25: athrow
/*     */     // Line number table:
/*     */     //   Java source line #92	-> byte code offset #0
/*     */     //   Java source line #94	-> byte code offset #7
/*     */     //   Java source line #95	-> byte code offset #21
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	26	0	this	AttributeChangeNotificationFilter
/*     */     //   5	18	1	Ljava/lang/Object;	Object
/*     */     //   21	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	20	21	finally
/*     */     //   21	24	21	finally
/*     */   }
/*     */   
/*     */   public boolean isNotificationEnabled(Notification notification)
/*     */   {
/* 101 */     if (!(notification instanceof AttributeChangeNotification)) return false;
/* 102 */     AttributeChangeNotification n = (AttributeChangeNotification)notification;
/*     */     
/* 104 */     if (!"jmx.attribute.change".equals(n.getType())) return false;
/* 105 */     String attributeName = n.getAttributeName();
/*     */     
/* 107 */     if (attributeName != null)
/*     */     {
/* 109 */       synchronized (this.enabledAttributes)
/*     */       {
/* 111 */         if (this.enabledAttributes.contains(attributeName)) return true;
/*     */       }
/*     */     }
/* 114 */     return false;
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/* 119 */     ObjectInputStream.GetField fields = in.readFields();
/*     */     
/* 121 */     Vector vector = (Vector)fields.get("enabledAttributes", null);
/* 122 */     if (fields.defaulted("enabledAttributes"))
/*     */     {
/* 124 */       throw new StreamCorruptedException("Serialized stream corrupted: expecting a non-null Vector");
/*     */     }
/*     */     
/* 127 */     if (this.enabledAttributes == null) this.enabledAttributes = new HashSet();
/* 128 */     this.enabledAttributes.clear();
/* 129 */     this.enabledAttributes.addAll(vector);
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException
/*     */   {
/* 134 */     ObjectOutputStream.PutField fields = out.putFields();
/*     */     
/* 136 */     Vector vector = getEnabledAttributes();
/* 137 */     fields.put("enabledAttributes", vector);
/* 138 */     out.writeFields();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/AttributeChangeNotificationFilter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */