/*    */ package javax.management;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class QueryEval
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 2675899265640874796L;
/*    */   private transient MBeanServer server;
/* 23 */   private static ThreadLocal serverPerThread = new ThreadLocal();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setMBeanServer(MBeanServer server)
/*    */   {
/* 30 */     this.server = server;
/* 31 */     serverPerThread.set(server);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static MBeanServer getMBeanServer()
/*    */   {
/* 41 */     return (MBeanServer)serverPerThread.get();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/QueryEval.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */