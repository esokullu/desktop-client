/*    */ package javax.management;
/*    */ 
/*    */ import mx4j.server.MX4JMBeanServerBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanServerBuilder
/*    */ {
/*    */   private MBeanServerBuilder builder;
/*    */   
/*    */   public MBeanServerDelegate newMBeanServerDelegate()
/*    */   {
/* 44 */     return builderDelegate().newMBeanServerDelegate();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MBeanServer newMBeanServer(String defaultDomain, MBeanServer outer, MBeanServerDelegate delegate)
/*    */   {
/* 54 */     return builderDelegate().newMBeanServer(defaultDomain, outer, delegate);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private synchronized MBeanServerBuilder builderDelegate()
/*    */   {
/* 64 */     if (this.builder == null)
/* 65 */       this.builder = new MX4JMBeanServerBuilder();
/* 66 */     return this.builder;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanServerBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */