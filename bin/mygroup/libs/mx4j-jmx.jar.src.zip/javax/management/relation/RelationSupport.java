/*     */ package javax.management.relation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.management.MBeanRegistration;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MBeanServerInvocationHandler;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RelationSupport
/*     */   implements RelationSupportMBean, MBeanRegistration
/*     */ {
/*     */   private String m_relationId;
/*     */   private String m_relationTypeName;
/*     */   private ObjectName m_relationServiceObjectName;
/*     */   private MBeanServer m_server;
/*     */   private RelationServiceMBean m_proxy;
/*  35 */   private Boolean m_isInRelationService = null;
/*  36 */   private Map m_roleNameToRole = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RelationSupport(String relationId, ObjectName relationServiceObjectName, MBeanServer server, String relationTypeName, RoleList roleList)
/*     */     throws InvalidRoleValueException, IllegalArgumentException
/*     */   {
/*  45 */     init(relationId, relationServiceObjectName, relationTypeName, roleList);
/*     */     
/*  47 */     this.m_server = server;
/*  48 */     this.m_proxy = ((RelationServiceMBean)MBeanServerInvocationHandler.newProxyInstance(this.m_server, this.m_relationServiceObjectName, RelationServiceMBean.class, false));
/*     */     
/*     */ 
/*     */ 
/*  52 */     this.m_isInRelationService = new Boolean(false);
/*     */   }
/*     */   
/*     */   private void init(String relationId, ObjectName relationServiceObjectName, String relationTypeName, RoleList roleList)
/*     */     throws InvalidRoleValueException
/*     */   {
/*  58 */     if (relationId == null) throw new IllegalArgumentException("Illegal Null RelationId");
/*  59 */     if (relationServiceObjectName == null) throw new IllegalArgumentException("Illegal Null RelatiobService ObjectName");
/*  60 */     if (relationTypeName == null) throw new IllegalArgumentException("Illegal Null RelationTypeName");
/*  61 */     if (roleList == null) throw new IllegalArgumentException("Illegal Null RoleList");
/*  62 */     this.m_relationId = relationId;
/*  63 */     this.m_relationServiceObjectName = relationServiceObjectName;
/*  64 */     this.m_relationTypeName = relationTypeName;
/*     */     
/*  66 */     initializeRoleList(roleList);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RelationSupport(String relationId, ObjectName relationServiceObjectName, String relationTypeName, RoleList roleList)
/*     */     throws InvalidRoleValueException, IllegalArgumentException
/*     */   {
/*  74 */     init(relationId, relationServiceObjectName, relationTypeName, roleList);
/*     */   }
/*     */   
/*     */   public List getRole(String roleName)
/*     */     throws IllegalArgumentException, RoleNotFoundException, RelationServiceNotRegisteredException
/*     */   {
/*  80 */     Logger logger = getLogger();
/*  81 */     if (roleName == null) throw new IllegalArgumentException("Role name cannot be null");
/*  82 */     if (logger.isEnabledFor(30)) logger.warn("getting roles whith RoleName: " + roleName + " from RelationSupport");
/*  83 */     Role role = getRoleFromRoleName(roleName);
/*     */     
/*  85 */     int problemType = getReadingProblemType(role, roleName, this.m_relationTypeName);
/*     */     
/*  87 */     if (problemType == 0) {
/*  88 */       return role.getRoleValue();
/*     */     }
/*     */     
/*  91 */     if (problemType == 1)
/*     */     {
/*  93 */       logger.warn("RoleName: " + roleName + " not found");
/*  94 */       throw new RoleNotFoundException("RoleName: " + roleName + " does not exist in the relation");
/*     */     }
/*  96 */     if (problemType == 2)
/*     */     {
/*  98 */       logger.warn("Role with roleName: " + roleName + " cannot be read.");
/*  99 */       throw new RoleNotFoundException("RoleName: " + roleName + " is not readable");
/*     */     }
/*     */     
/*     */ 
/* 103 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int getReadingProblemType(Role role, String roleName, String relationTypeName)
/*     */     throws RelationServiceNotRegisteredException, IllegalArgumentException
/*     */   {
/* 112 */     if (roleName == null) throw new IllegalArgumentException("Null Role Name.");
/* 113 */     Logger logger = getLogger();
/* 114 */     if (logger.isEnabledFor(30)) logger.warn("Checking the Role reading...");
/* 115 */     if (role == null) return 1;
/*     */     try
/*     */     {
/* 118 */       return this.m_proxy.checkRoleReading(roleName, relationTypeName).intValue();
/*     */     }
/*     */     catch (RelationTypeNotFoundException ex)
/*     */     {
/* 122 */       logger.warn("Unable to find the Relation Type with name " + relationTypeName);
/* 123 */       throw new RuntimeOperationsException(null, "Relation Type with name: " + relationTypeName + " was not found");
/*     */     }
/*     */   }
/*     */   
/*     */   public RoleResult getRoles(String[] roleNames)
/*     */     throws IllegalArgumentException, RelationServiceNotRegisteredException
/*     */   {
/* 130 */     if (roleNames == null) throw new IllegalArgumentException("Null RoleName Array.");
/* 131 */     Logger logger = getLogger();
/* 132 */     if (logger.isEnabledFor(30)) logger.warn("Getting roles");
/* 133 */     RoleList roleList = new RoleList();
/* 134 */     RoleUnresolvedList unresolvedList = new RoleUnresolvedList();
/* 135 */     for (int i = 0; i < roleNames.length; i++)
/*     */     {
/* 137 */       String currentRoleName = roleNames[i];
/* 138 */       Role role = getRoleFromRoleName(currentRoleName);
/*     */       
/* 140 */       int problemType = getReadingProblemType(role, currentRoleName, this.m_relationTypeName);
/*     */       
/* 142 */       if (problemType == 0) {
/* 143 */         roleList.add((Role)role.clone());
/*     */       }
/*     */       else
/* 146 */         unresolvedList.add(new RoleUnresolved(currentRoleName, null, problemType));
/*     */     }
/* 148 */     return new RoleResult(roleList, unresolvedList);
/*     */   }
/*     */   
/*     */   public RoleResult getAllRoles()
/*     */     throws RelationServiceNotRegisteredException
/*     */   {
/* 154 */     Logger logger = getLogger();
/* 155 */     if (logger.isEnabledFor(30)) logger.warn("getting all roles");
/* 156 */     List roleNameList = getAllRoleNamesList();
/* 157 */     String[] roleNames = new String[roleNameList.size()];
/* 158 */     int index = 0;
/* 159 */     for (Iterator i = roleNameList.iterator(); i.hasNext();)
/*     */     {
/* 161 */       roleNames[index] = ((String)i.next());
/* 162 */       index++;
/*     */     }
/* 164 */     return getRoles(roleNames);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public RoleList retrieveAllRoles()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 10	javax/management/relation/RelationSupport:m_roleNameToRole	Ljava/util/Map;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: new 64	javax/management/relation/RoleList
/*     */     //   10: dup
/*     */     //   11: new 84	java/util/ArrayList
/*     */     //   14: dup
/*     */     //   15: aload_0
/*     */     //   16: getfield 10	javax/management/relation/RelationSupport:m_roleNameToRole	Ljava/util/Map;
/*     */     //   19: invokeinterface 85 1 0
/*     */     //   24: invokespecial 86	java/util/ArrayList:<init>	(Ljava/util/Collection;)V
/*     */     //   27: invokespecial 87	javax/management/relation/RoleList:<init>	(Ljava/util/List;)V
/*     */     //   30: aload_1
/*     */     //   31: monitorexit
/*     */     //   32: areturn
/*     */     //   33: astore_2
/*     */     //   34: aload_1
/*     */     //   35: monitorexit
/*     */     //   36: aload_2
/*     */     //   37: athrow
/*     */     // Line number table:
/*     */     //   Java source line #169	-> byte code offset #0
/*     */     //   Java source line #171	-> byte code offset #7
/*     */     //   Java source line #172	-> byte code offset #33
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	38	0	this	RelationSupport
/*     */     //   5	30	1	Ljava/lang/Object;	Object
/*     */     //   33	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	32	33	finally
/*     */     //   33	36	33	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private ArrayList getAllRolesList()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 10	javax/management/relation/RelationSupport:m_roleNameToRole	Ljava/util/Map;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: new 84	java/util/ArrayList
/*     */     //   10: dup
/*     */     //   11: aload_0
/*     */     //   12: getfield 10	javax/management/relation/RelationSupport:m_roleNameToRole	Ljava/util/Map;
/*     */     //   15: invokeinterface 85 1 0
/*     */     //   20: invokespecial 86	java/util/ArrayList:<init>	(Ljava/util/Collection;)V
/*     */     //   23: aload_1
/*     */     //   24: monitorexit
/*     */     //   25: areturn
/*     */     //   26: astore_2
/*     */     //   27: aload_1
/*     */     //   28: monitorexit
/*     */     //   29: aload_2
/*     */     //   30: athrow
/*     */     // Line number table:
/*     */     //   Java source line #177	-> byte code offset #0
/*     */     //   Java source line #179	-> byte code offset #7
/*     */     //   Java source line #180	-> byte code offset #26
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	31	0	this	RelationSupport
/*     */     //   5	23	1	Ljava/lang/Object;	Object
/*     */     //   26	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	25	26	finally
/*     */     //   26	29	26	finally
/*     */   }
/*     */   
/*     */   public void setRole(Role role)
/*     */     throws IllegalArgumentException, RoleNotFoundException, RelationTypeNotFoundException, InvalidRoleValueException, RelationServiceNotRegisteredException, RelationNotFoundException
/*     */   {
/* 187 */     if (role == null) { throw new IllegalArgumentException("RelationSupport setRole has recieved a null Role.");
/*     */     }
/* 189 */     String roleName = role.getRoleName();
/* 190 */     Role oldRole = getRoleFromRoleName(roleName);
/*     */     List oldRoleValue;
/*     */     Boolean toBeInitialized;
/*     */     List oldRoleValue;
/* 194 */     if (oldRole == null)
/*     */     {
/* 196 */       Boolean toBeInitialized = new Boolean(true);
/* 197 */       oldRoleValue = new ArrayList();
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 202 */       toBeInitialized = new Boolean(false);
/* 203 */       oldRoleValue = oldRole.getRoleValue();
/*     */     }
/*     */     
/* 206 */     int problemType = getRoleWritingValue(role, this.m_relationTypeName, toBeInitialized);
/* 207 */     if (problemType == 0)
/*     */     {
/* 209 */       if (!toBeInitialized.booleanValue())
/*     */       {
/*     */ 
/* 212 */         sendUpdateRoleNotification(this.m_relationId, role, oldRoleValue);
/* 213 */         updateRelationServiceMap(this.m_relationId, role, oldRoleValue);
/*     */       }
/* 215 */       addRolesToRoleMap(roleName, role);
/*     */     }
/*     */     else
/*     */     {
/* 219 */       RelationService.throwRoleProblemException(problemType, roleName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   int getRoleWritingValue(Role role, String relationTypeName, Boolean toBeInitialized)
/*     */     throws RelationTypeNotFoundException
/*     */   {
/* 228 */     if (this.m_proxy == null) throw new IllegalArgumentException("Please check the RelationService is running");
/* 229 */     return this.m_proxy.checkRoleWriting(role, relationTypeName, toBeInitialized).intValue();
/*     */   }
/*     */   
/*     */ 
/*     */   public RoleResult setRoles(RoleList roleList)
/*     */     throws IllegalArgumentException, RelationServiceNotRegisteredException, RelationTypeNotFoundException, RelationNotFoundException
/*     */   {
/* 236 */     Logger logger = getLogger();
/* 237 */     if (roleList == null) throw new IllegalArgumentException("RoleList cannot be null");
/* 238 */     if (logger.isEnabledFor(30)) logger.warn("setting roles");
/* 239 */     RoleList newRoleList = new RoleList();
/* 240 */     RoleUnresolvedList roleUnresolvedList = new RoleUnresolvedList();
/*     */     
/*     */ 
/* 243 */     for (Iterator i = roleList.iterator(); i.hasNext();)
/*     */     {
/* 245 */       Role currentRole = (Role)i.next();
/* 246 */       String roleName = currentRole.getRoleName();
/* 247 */       Role oldRole = getRoleFromRoleName(roleName);
/* 248 */       List oldRoleValue; Boolean needsInitializing; List oldRoleValue; if (oldRole == null)
/*     */       {
/* 250 */         Boolean needsInitializing = new Boolean(true);
/* 251 */         oldRoleValue = new ArrayList();
/*     */       }
/*     */       else
/*     */       {
/* 255 */         needsInitializing = new Boolean(false);
/* 256 */         oldRoleValue = oldRole.getRoleValue();
/*     */       }
/* 258 */       int problemType = getRoleWritingValue(currentRole, this.m_relationTypeName, needsInitializing);
/* 259 */       if (problemType == 0)
/*     */       {
/* 261 */         if (!needsInitializing.booleanValue())
/*     */         {
/*     */ 
/* 264 */           sendUpdateRoleNotification(this.m_relationId, currentRole, oldRoleValue);
/* 265 */           updateRelationServiceMap(this.m_relationId, currentRole, oldRoleValue);
/*     */         }
/*     */         
/* 268 */         addRolesToRoleMap(roleName, currentRole);
/* 269 */         newRoleList.add(currentRole);
/*     */       }
/*     */       else
/*     */       {
/* 273 */         if (logger.isEnabledFor(30)) logger.warn("We have some unresolved roles adding them to RoleUnresolvedList");
/* 274 */         roleUnresolvedList.add(new RoleUnresolved(roleName, currentRole.getRoleValue(), problemType));
/*     */       }
/*     */     }
/* 277 */     return new RoleResult(roleList, roleUnresolvedList);
/*     */   }
/*     */   
/*     */   public Integer getRoleCardinality(String roleName)
/*     */     throws IllegalArgumentException, RoleNotFoundException
/*     */   {
/* 283 */     Logger logger = getLogger();
/* 284 */     if (logger.isEnabledFor(30)) logger.warn("checking role cardinality with role named: " + roleName);
/* 285 */     if (roleName == null) throw new IllegalArgumentException("Role name should not be null.");
/* 286 */     Role role = getRoleFromRoleName(roleName);
/* 287 */     if (role == null)
/*     */     {
/* 289 */       int problemType = 1;
/*     */       
/*     */       try
/*     */       {
/* 293 */         RelationService.throwRoleProblemException(problemType, roleName);
/*     */       }
/*     */       catch (InvalidRoleValueException ex)
/*     */       {
/* 297 */         new RuntimeOperationsException(null, "Invalid role value");
/*     */       }
/*     */     }
/* 300 */     List roleValue = role.getRoleValue();
/* 301 */     return new Integer(roleValue.size());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleMBeanUnregistration(ObjectName objectName, String roleName)
/*     */     throws IllegalArgumentException, RoleNotFoundException, InvalidRoleValueException, RelationServiceNotRegisteredException, RelationTypeNotFoundException, RelationNotFoundException
/*     */   {
/* 310 */     Logger logger = getLogger();
/* 311 */     if (objectName == null) throw new IllegalArgumentException("ObjectName is null");
/* 312 */     if (roleName == null) throw new IllegalArgumentException("Null roleName");
/* 313 */     if (logger.isEnabledFor(30))
/*     */     {
/* 315 */       logger.warn("MBean with ObjectName: " + objectName.getCanonicalName() + " has been unregistered from the" + " MBeanServer. Setting new Role values");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 320 */     Role newRole = createNewRole(roleName, objectName);
/* 321 */     setRole(newRole);
/*     */   }
/*     */   
/*     */ 
/*     */   private Role createNewRole(String roleName, ObjectName objectName)
/*     */     throws RoleNotFoundException
/*     */   {
/* 328 */     Role role = getRoleFromRoleName(roleName);
/* 329 */     if (role == null) { throw new RoleNotFoundException("No role found for role name: " + roleName);
/*     */     }
/*     */     
/* 332 */     ArrayList newRoleValue = (ArrayList)((ArrayList)role.getRoleValue()).clone();
/* 333 */     newRoleValue.remove(objectName);
/* 334 */     Role newRole = new Role(roleName, newRoleValue);
/* 335 */     return newRole;
/*     */   }
/*     */   
/*     */   public Map getReferencedMBeans()
/*     */   {
/* 340 */     Logger logger = getLogger();
/* 341 */     if (logger.isEnabledFor(30)) logger.warn("getting mbeanReferenced in RelationService");
/* 342 */     HashMap referencedMBeansMap = new HashMap();
/* 343 */     for (Iterator i = getAllRolesList().iterator(); i.hasNext();)
/*     */     {
/* 345 */       Role currentRole = (Role)i.next();
/* 346 */       currentRoleName = currentRole.getRoleName();
/*     */       
/* 348 */       List mbeanList = currentRole.getRoleValue();
/* 349 */       for (iter = mbeanList.iterator(); iter.hasNext();)
/*     */       {
/* 351 */         ObjectName currentObjectName = (ObjectName)iter.next();
/* 352 */         List mbeanRoleNameList = (List)referencedMBeansMap.get(currentObjectName);
/* 353 */         boolean newReference = false;
/* 354 */         if (mbeanRoleNameList == null)
/*     */         {
/*     */ 
/* 357 */           newReference = true;
/* 358 */           mbeanRoleNameList = new ArrayList();
/*     */         }
/* 360 */         mbeanRoleNameList.add(currentRoleName);
/*     */         
/* 362 */         if (newReference) referencedMBeansMap.put(currentObjectName, mbeanRoleNameList); } }
/*     */     String currentRoleName;
/*     */     Iterator iter;
/* 365 */     return referencedMBeansMap;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private Role getRoleFromRoleName(String roleName)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 10	javax/management/relation/RelationSupport:m_roleNameToRole	Ljava/util/Map;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 10	javax/management/relation/RelationSupport:m_roleNameToRole	Ljava/util/Map;
/*     */     //   11: aload_1
/*     */     //   12: invokeinterface 129 2 0
/*     */     //   17: checkcast 69	javax/management/relation/Role
/*     */     //   20: aload_2
/*     */     //   21: monitorexit
/*     */     //   22: areturn
/*     */     //   23: astore_3
/*     */     //   24: aload_2
/*     */     //   25: monitorexit
/*     */     //   26: aload_3
/*     */     //   27: athrow
/*     */     // Line number table:
/*     */     //   Java source line #370	-> byte code offset #0
/*     */     //   Java source line #372	-> byte code offset #7
/*     */     //   Java source line #373	-> byte code offset #23
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	28	0	this	RelationSupport
/*     */     //   0	28	1	roleName	String
/*     */     //   5	20	2	Ljava/lang/Object;	Object
/*     */     //   23	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	22	23	finally
/*     */     //   23	26	23	finally
/*     */   }
/*     */   
/*     */   public String getRelationTypeName()
/*     */   {
/* 378 */     return this.m_relationTypeName;
/*     */   }
/*     */   
/*     */   public ObjectName getRelationServiceName()
/*     */   {
/* 383 */     return this.m_relationServiceObjectName;
/*     */   }
/*     */   
/*     */   public String getRelationId()
/*     */   {
/* 388 */     return this.m_relationId;
/*     */   }
/*     */   
/*     */   public Boolean isInRelationService()
/*     */   {
/* 393 */     return new Boolean(this.m_isInRelationService.booleanValue());
/*     */   }
/*     */   
/*     */   public void setRelationServiceManagementFlag(Boolean isHandledByRelationService) throws IllegalArgumentException
/*     */   {
/* 398 */     if (isHandledByRelationService == null) throw new IllegalArgumentException("Null flag");
/* 399 */     this.m_isInRelationService = new Boolean(isHandledByRelationService.booleanValue());
/*     */   }
/*     */   
/*     */   public ObjectName preRegister(MBeanServer server, ObjectName name)
/*     */     throws Exception
/*     */   {
/* 405 */     if (server == null) throw new IllegalArgumentException("MBean Server is null cannot pre-register.");
/* 406 */     if (name == null) throw new IllegalArgumentException("Cannot register a null ObjectName");
/* 407 */     Logger logger = getLogger();
/* 408 */     if (logger.isEnabledFor(30)) logger.warn("pre Registering the RelationSupport");
/* 409 */     this.m_server = server;
/* 410 */     this.m_proxy = ((RelationServiceMBean)MBeanServerInvocationHandler.newProxyInstance(this.m_server, this.m_relationServiceObjectName, RelationServiceMBean.class, false));
/*     */     
/*     */ 
/*     */ 
/* 414 */     return name;
/*     */   }
/*     */   
/*     */   public void postRegister(Boolean registrationDone)
/*     */   {
/* 419 */     Logger logger = getLogger();
/* 420 */     boolean done = registrationDone.booleanValue();
/* 421 */     if (!done)
/*     */     {
/* 423 */       this.m_server = null;
/* 424 */       logger.warn("RelationSupport was NOT registered");
/*     */ 
/*     */ 
/*     */     }
/* 428 */     else if (logger.isEnabledFor(0))
/*     */     {
/* 430 */       logger.trace("RelationSupport postRegistered");
/*     */     }
/*     */   }
/*     */   
/*     */   public void preDeregister()
/*     */     throws Exception
/*     */   {
/* 437 */     Logger logger = getLogger();
/* 438 */     if (logger.isEnabledFor(0))
/*     */     {
/* 440 */       logger.debug("RelationSupport preDeregistered");
/*     */     }
/*     */   }
/*     */   
/*     */   public void postDeregister()
/*     */   {
/* 446 */     Logger logger = getLogger();
/* 447 */     if (logger.isEnabledFor(0))
/*     */     {
/* 449 */       logger.debug("RelationSupport postDeregistered");
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private List getAllRoleNamesList()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 10	javax/management/relation/RelationSupport:m_roleNameToRole	Ljava/util/Map;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: new 84	java/util/ArrayList
/*     */     //   10: dup
/*     */     //   11: aload_0
/*     */     //   12: getfield 10	javax/management/relation/RelationSupport:m_roleNameToRole	Ljava/util/Map;
/*     */     //   15: invokeinterface 140 1 0
/*     */     //   20: invokespecial 86	java/util/ArrayList:<init>	(Ljava/util/Collection;)V
/*     */     //   23: aload_1
/*     */     //   24: monitorexit
/*     */     //   25: areturn
/*     */     //   26: astore_2
/*     */     //   27: aload_1
/*     */     //   28: monitorexit
/*     */     //   29: aload_2
/*     */     //   30: athrow
/*     */     // Line number table:
/*     */     //   Java source line #455	-> byte code offset #0
/*     */     //   Java source line #457	-> byte code offset #7
/*     */     //   Java source line #458	-> byte code offset #26
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	31	0	this	RelationSupport
/*     */     //   5	23	1	Ljava/lang/Object;	Object
/*     */     //   26	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	25	26	finally
/*     */     //   26	29	26	finally
/*     */   }
/*     */   
/*     */   private void initializeRoleList(RoleList roleList)
/*     */     throws InvalidRoleValueException
/*     */   {
/* 463 */     if (roleList == null) return;
/* 464 */     for (Iterator i = roleList.iterator(); i.hasNext();)
/*     */     {
/* 466 */       Role currentRole = (Role)i.next();
/* 467 */       String currentRoleName = currentRole.getRoleName();
/*     */       
/* 469 */       if (this.m_roleNameToRole.containsKey(currentRoleName))
/*     */       {
/* 471 */         throw new InvalidRoleValueException("RoleName already in use.");
/*     */       }
/*     */       
/* 474 */       addRolesToRoleMap(currentRoleName, currentRole);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void addRolesToRoleMap(String roleName, Role role)
/*     */   {
/* 481 */     synchronized (this.m_roleNameToRole)
/*     */     {
/* 483 */       this.m_roleNameToRole.put(roleName, role.clone());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void updateRelationServiceMap(String relationId, Role role, List oldRoleValue)
/*     */     throws IllegalArgumentException, RelationServiceNotRegisteredException, RelationNotFoundException
/*     */   {
/* 492 */     Logger logger = getLogger();
/* 493 */     if (this.m_proxy != null) {
/* 494 */       this.m_proxy.updateRoleMap(relationId, role, oldRoleValue);
/*     */     }
/*     */     else {
/* 497 */       logger.warn("The RelationService cannot be registered.");
/* 498 */       throw new RelationServiceNotRegisteredException("Please check the RelationService is registered in the server");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void sendUpdateRoleNotification(String relationId, Role role, List oldRoleValue)
/*     */     throws RelationServiceNotRegisteredException, RelationNotFoundException
/*     */   {
/* 507 */     Logger logger = getLogger();
/* 508 */     if (relationId == null) throw new IllegalArgumentException("Null RelationId passed into sendUpdateRoleNotification");
/* 509 */     if (role == null) throw new IllegalArgumentException("Null role passed into sendUpdateRoleNotification");
/* 510 */     if (oldRoleValue == null) throw new IllegalArgumentException("Null list of role Values passed into sendUpdateRoleNotification");
/* 511 */     if (this.m_proxy != null) {
/* 512 */       this.m_proxy.sendRoleUpdateNotification(relationId, role, oldRoleValue);
/*     */     }
/*     */     else {
/* 515 */       logger.warn("cannot send an update notification as RelationService may not be registered, please check.");
/* 516 */       throw new RelationServiceNotRegisteredException("Please check the relation service has been registered in the MBeanServer");
/*     */     }
/*     */   }
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/* 522 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RelationSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */