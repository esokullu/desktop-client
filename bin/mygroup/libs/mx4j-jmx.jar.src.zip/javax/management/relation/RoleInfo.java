/*     */ package javax.management.relation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RoleInfo
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2504952983494636987L;
/*  20 */   public static int ROLE_CARDINALITY_INFINITY = -1;
/*     */   
/*     */   private String name;
/*     */   
/*     */   private String description;
/*     */   
/*     */   private String referencedMBeanClassName;
/*     */   private boolean isWritable;
/*     */   private boolean isReadable;
/*     */   private int minDegree;
/*     */   private int maxDegree;
/*     */   
/*     */   public RoleInfo(String roleName, String mbeanClassName, boolean isReadable, boolean isWritable, int minNumber, int maxNumber, String description)
/*     */     throws IllegalArgumentException, InvalidRoleInfoException, ClassNotFoundException, NotCompliantMBeanException
/*     */   {
/*  35 */     initialize(roleName, mbeanClassName, isReadable, isWritable, minNumber, maxNumber, description);
/*     */   }
/*     */   
/*     */ 
/*     */   public RoleInfo(String roleName, String mbeanClassName, boolean isReadable, boolean isWritable)
/*     */     throws IllegalArgumentException, ClassNotFoundException, NotCompliantMBeanException
/*     */   {
/*     */     try
/*     */     {
/*  44 */       initialize(roleName, mbeanClassName, isReadable, isWritable, 1, 1, null);
/*     */     }
/*     */     catch (InvalidRoleInfoException ignored) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RoleInfo(String roleName, String mbeanClassName)
/*     */     throws IllegalArgumentException, ClassNotFoundException, NotCompliantMBeanException
/*     */   {
/*     */     try
/*     */     {
/*  57 */       initialize(roleName, mbeanClassName, true, true, 1, 1, null);
/*     */     }
/*     */     catch (InvalidRoleInfoException ignored) {}
/*     */   }
/*     */   
/*     */ 
/*     */   public RoleInfo(RoleInfo info)
/*     */     throws IllegalArgumentException
/*     */   {
/*  66 */     if (info == null)
/*     */     {
/*  68 */       throw new IllegalArgumentException("RoleInfo cannot be null");
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  73 */       initialize(info.getName(), info.getRefMBeanClassName(), info.isReadable(), info.isWritable(), info.getMinDegree(), info.getMaxDegree(), info.getDescription());
/*     */     }
/*     */     catch (Exception ignored) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void initialize(String roleName, String mbeanClassName, boolean isReadable, boolean isWritable, int minNumber, int maxNumber, String description)
/*     */     throws IllegalArgumentException, InvalidRoleInfoException, ClassNotFoundException, NotCompliantMBeanException
/*     */   {
/*  83 */     if (roleName == null) throw new IllegalArgumentException("Null Role name");
/*  84 */     if (mbeanClassName == null) throw new IllegalArgumentException("Null MBean class Name");
/*  85 */     this.name = roleName;
/*  86 */     this.isReadable = isReadable;
/*  87 */     this.isWritable = isWritable;
/*  88 */     this.description = description;
/*     */     
/*  90 */     checkValidCardinality(maxNumber, minNumber);
/*  91 */     this.maxDegree = maxNumber;
/*  92 */     this.minDegree = minNumber;
/*  93 */     this.referencedMBeanClassName = mbeanClassName;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  98 */     return this.name;
/*     */   }
/*     */   
/*     */   public boolean isReadable()
/*     */   {
/* 103 */     return this.isReadable;
/*     */   }
/*     */   
/*     */   public boolean isWritable()
/*     */   {
/* 108 */     return this.isWritable;
/*     */   }
/*     */   
/*     */   public String getDescription()
/*     */   {
/* 113 */     return this.description;
/*     */   }
/*     */   
/*     */   public int getMinDegree()
/*     */   {
/* 118 */     return this.minDegree;
/*     */   }
/*     */   
/*     */   public int getMaxDegree()
/*     */   {
/* 123 */     return this.maxDegree;
/*     */   }
/*     */   
/*     */   public String getRefMBeanClassName()
/*     */   {
/* 128 */     return this.referencedMBeanClassName;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean checkMaxDegree(int maxNumber)
/*     */   {
/* 134 */     if ((maxNumber >= ROLE_CARDINALITY_INFINITY) && ((this.maxDegree == ROLE_CARDINALITY_INFINITY) || ((maxNumber != ROLE_CARDINALITY_INFINITY) && (maxNumber <= this.maxDegree))))
/*     */     {
/*     */ 
/* 137 */       return true;
/*     */     }
/* 139 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean checkMinDegree(int minNumber)
/*     */   {
/* 145 */     if ((minNumber >= ROLE_CARDINALITY_INFINITY) && ((this.minDegree == ROLE_CARDINALITY_INFINITY) || (minNumber >= this.minDegree)))
/*     */     {
/*     */ 
/* 148 */       return true;
/*     */     }
/* 150 */     return false;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 155 */     StringBuffer result = new StringBuffer("Name: ");
/* 156 */     result.append(this.name);
/* 157 */     result.append("; isReadable: ").append(this.isReadable);
/* 158 */     result.append("; isWritable: ").append(this.isWritable);
/* 159 */     result.append("; description: ").append(this.description);
/* 160 */     result.append("; minimum degree: ").append(this.minDegree);
/* 161 */     result.append("; maximum degree: ").append(this.maxDegree);
/* 162 */     result.append("; MBean class: ").append(this.referencedMBeanClassName);
/* 163 */     return result.toString();
/*     */   }
/*     */   
/*     */   private void checkValidCardinality(int maxNumber, int minNumber) throws InvalidRoleInfoException
/*     */   {
/* 168 */     if ((maxNumber != ROLE_CARDINALITY_INFINITY) && ((minNumber == ROLE_CARDINALITY_INFINITY) || (minNumber > maxNumber)))
/*     */     {
/* 170 */       throw new InvalidRoleInfoException("Role cardinality is invalid");
/*     */     }
/* 172 */     if ((minNumber < ROLE_CARDINALITY_INFINITY) || (maxNumber < ROLE_CARDINALITY_INFINITY))
/*     */     {
/* 174 */       throw new InvalidRoleInfoException("Role cardinality is invalid");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RoleInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */