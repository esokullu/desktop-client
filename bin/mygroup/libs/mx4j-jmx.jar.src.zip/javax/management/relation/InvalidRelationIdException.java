/*    */ package javax.management.relation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidRelationIdException
/*    */   extends RelationException
/*    */ {
/*    */   private static final long serialVersionUID = -7115040321202754171L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidRelationIdException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidRelationIdException(String message)
/*    */   {
/* 25 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/InvalidRelationIdException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */