/*    */ package javax.management.relation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelationNotFoundException
/*    */   extends RelationException
/*    */ {
/*    */   private static final long serialVersionUID = -3793951411158559116L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RelationNotFoundException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RelationNotFoundException(String message)
/*    */   {
/* 24 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RelationNotFoundException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */