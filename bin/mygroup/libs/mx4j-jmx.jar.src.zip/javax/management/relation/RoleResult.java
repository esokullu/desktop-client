/*    */ package javax.management.relation;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleResult
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -6304063118040985512L;
/*    */   private RoleList roleList;
/*    */   private RoleUnresolvedList unresolvedRoleList;
/*    */   
/*    */   public RoleResult(RoleList roleList, RoleUnresolvedList unresolvedList)
/*    */   {
/* 25 */     setRoles(roleList);
/* 26 */     setRolesUnresolved(unresolvedList);
/*    */   }
/*    */   
/*    */   public RoleList getRoles()
/*    */   {
/* 31 */     return this.roleList == null ? null : (RoleList)this.roleList.clone();
/*    */   }
/*    */   
/*    */   public RoleUnresolvedList getRolesUnresolved()
/*    */   {
/* 36 */     return this.unresolvedRoleList == null ? null : (RoleUnresolvedList)this.unresolvedRoleList.clone();
/*    */   }
/*    */   
/*    */   public void setRoles(RoleList list) {
/*    */     Iterator i;
/* 41 */     if (list != null)
/*    */     {
/* 43 */       if (this.roleList == null)
/*    */       {
/* 45 */         this.roleList = new RoleList();
/*    */       }
/* 47 */       for (i = list.iterator(); i.hasNext();)
/*    */       {
/* 49 */         Role currentRole = (Role)i.next();
/* 50 */         this.roleList.add(currentRole.clone());
/*    */       }
/*    */     }
/*    */     else
/*    */     {
/* 55 */       this.roleList = null;
/*    */     }
/*    */   }
/*    */   
/*    */   public void setRolesUnresolved(RoleUnresolvedList list) {
/*    */     Iterator i;
/* 61 */     if (list != null)
/*    */     {
/* 63 */       if (this.unresolvedRoleList == null)
/*    */       {
/* 65 */         this.unresolvedRoleList = new RoleUnresolvedList();
/*    */       }
/* 67 */       for (i = list.iterator(); i.hasNext();)
/*    */       {
/* 69 */         RoleUnresolved currentUnresolvedRole = (RoleUnresolved)i.next();
/* 70 */         this.unresolvedRoleList.add(currentUnresolvedRole.clone());
/*    */       }
/*    */     }
/*    */     else
/*    */     {
/* 75 */       this.unresolvedRoleList = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RoleResult.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */