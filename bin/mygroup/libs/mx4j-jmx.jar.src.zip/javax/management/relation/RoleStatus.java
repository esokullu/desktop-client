/*    */ package javax.management.relation;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleStatus
/*    */ {
/*    */   public static final int NO_ROLE_WITH_NAME = 1;
/*    */   
/*    */ 
/*    */   public static final int ROLE_NOT_READABLE = 2;
/*    */   
/*    */   public static final int ROLE_NOT_WRITABLE = 3;
/*    */   
/*    */   public static final int LESS_THAN_MIN_ROLE_DEGREE = 4;
/*    */   
/*    */   public static final int MORE_THAN_MAX_ROLE_DEGREE = 5;
/*    */   
/*    */   public static final int REF_MBEAN_OF_INCORRECT_CLASS = 6;
/*    */   
/*    */   public static final int REF_MBEAN_NOT_REGISTERED = 7;
/*    */   
/*    */ 
/*    */   public static boolean isRoleStatus(int roleStatusType)
/*    */   {
/* 25 */     if ((roleStatusType != 1) && (roleStatusType != 2) && (roleStatusType != 3) && (roleStatusType != 4) && (roleStatusType != 5) && (roleStatusType != 6) && (roleStatusType != 7))
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 31 */       return false;
/*    */     }
/* 33 */     return true;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RoleStatus.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */