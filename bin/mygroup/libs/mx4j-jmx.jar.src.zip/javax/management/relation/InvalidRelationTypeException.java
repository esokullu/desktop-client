/*    */ package javax.management.relation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidRelationTypeException
/*    */   extends RelationException
/*    */ {
/*    */   private static final long serialVersionUID = 3007446608299169961L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidRelationTypeException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidRelationTypeException(String message)
/*    */   {
/* 25 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/InvalidRelationTypeException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */