/*    */ package javax.management.relation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelationTypeNotFoundException
/*    */   extends RelationException
/*    */ {
/*    */   private static final long serialVersionUID = 1274155316284300752L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RelationTypeNotFoundException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RelationTypeNotFoundException(String message)
/*    */   {
/* 25 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RelationTypeNotFoundException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */