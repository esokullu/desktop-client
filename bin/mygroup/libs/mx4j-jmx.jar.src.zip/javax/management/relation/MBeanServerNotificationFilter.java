/*     */ package javax.management.relation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectInputStream.GetField;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectOutputStream.PutField;
/*     */ import java.io.ObjectStreamField;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import javax.management.MBeanServerNotification;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationFilterSupport;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanServerNotificationFilter
/*     */   extends NotificationFilterSupport
/*     */ {
/*     */   private static final long serialVersionUID = 2605900539589789736L;
/*  29 */   private static final String[] serialNames = { "selectedNames", "deselectedNames" };
/*  30 */   private static final ObjectStreamField[] serialPersistentFields = { new ObjectStreamField(serialNames[0], List.class), new ObjectStreamField(serialNames[1], List.class) };
/*     */   
/*     */ 
/*     */   private HashSet m_disabledObjectNames;
/*     */   
/*     */ 
/*     */   private HashSet m_enabledObjectNames;
/*     */   
/*     */ 
/*     */   public MBeanServerNotificationFilter()
/*     */   {
/*  41 */     enableType("JMX.mbean.registered");
/*  42 */     enableType("JMX.mbean.unregistered");
/*     */     
/*     */ 
/*  45 */     disableAllObjectNames();
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  50 */     int result = this.m_disabledObjectNames != null ? this.m_disabledObjectNames.hashCode() : 0;
/*  51 */     result = 29 * result + (this.m_enabledObjectNames != null ? this.m_enabledObjectNames.hashCode() : 0);
/*  52 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  57 */     if (this == obj) return true;
/*  58 */     if (!(obj instanceof MBeanServerNotificationFilter)) { return false;
/*     */     }
/*  60 */     MBeanServerNotificationFilter other = (MBeanServerNotificationFilter)obj;
/*     */     
/*  62 */     if (this.m_disabledObjectNames != null ? !this.m_disabledObjectNames.equals(other.m_disabledObjectNames) : other.m_disabledObjectNames != null) return false;
/*  63 */     if (this.m_enabledObjectNames != null ? !this.m_enabledObjectNames.equals(other.m_enabledObjectNames) : other.m_enabledObjectNames != null) { return false;
/*     */     }
/*  65 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void disableAllObjectNames()
/*     */   {
/*  71 */     if (this.m_enabledObjectNames == null)
/*     */     {
/*  73 */       this.m_enabledObjectNames = new HashSet();
/*     */     }
/*     */     else
/*     */     {
/*  77 */       this.m_enabledObjectNames.clear();
/*     */     }
/*     */     
/*  80 */     this.m_disabledObjectNames = null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void enableAllObjectNames()
/*     */   {
/*  86 */     if (this.m_disabledObjectNames == null)
/*     */     {
/*  88 */       this.m_disabledObjectNames = new HashSet();
/*     */     }
/*     */     else
/*     */     {
/*  92 */       this.m_disabledObjectNames.clear();
/*     */     }
/*     */     
/*  95 */     this.m_enabledObjectNames = null;
/*     */   }
/*     */   
/*     */   public void enableObjectName(ObjectName name) throws IllegalArgumentException
/*     */   {
/* 100 */     if (name == null)
/*     */     {
/* 102 */       throw new IllegalArgumentException("ObjectName cannot be null");
/*     */     }
/*     */     
/*     */ 
/* 106 */     if ((this.m_disabledObjectNames != null) && (this.m_disabledObjectNames.size() > 0))
/*     */     {
/* 108 */       this.m_disabledObjectNames.remove(name);
/*     */     }
/*     */     
/*     */ 
/* 112 */     if (this.m_enabledObjectNames != null)
/*     */     {
/* 114 */       this.m_enabledObjectNames.add(name);
/*     */     }
/*     */   }
/*     */   
/*     */   public void disableObjectName(ObjectName name) throws IllegalArgumentException
/*     */   {
/* 120 */     if (name == null)
/*     */     {
/* 122 */       throw new IllegalArgumentException("ObjectName cannot be null");
/*     */     }
/*     */     
/*     */ 
/* 126 */     if ((this.m_enabledObjectNames != null) && (this.m_enabledObjectNames.size() > 0))
/*     */     {
/* 128 */       this.m_enabledObjectNames.remove(name);
/*     */     }
/*     */     
/*     */ 
/* 132 */     if (this.m_disabledObjectNames != null)
/*     */     {
/* 134 */       this.m_disabledObjectNames.add(name);
/*     */     }
/*     */   }
/*     */   
/*     */   public Vector getEnabledObjectNames()
/*     */   {
/* 140 */     if (this.m_enabledObjectNames == null)
/*     */     {
/* 142 */       return null;
/*     */     }
/* 144 */     Vector v = new Vector();
/* 145 */     v.addAll(this.m_enabledObjectNames);
/* 146 */     return v;
/*     */   }
/*     */   
/*     */   public Vector getDisabledObjectNames()
/*     */   {
/* 151 */     if (this.m_disabledObjectNames == null)
/*     */     {
/* 153 */       return null;
/*     */     }
/* 155 */     Vector v = new Vector();
/* 156 */     v.addAll(this.m_disabledObjectNames);
/* 157 */     return v;
/*     */   }
/*     */   
/*     */   public boolean isNotificationEnabled(Notification notification)
/*     */   {
/* 162 */     boolean goOn = super.isNotificationEnabled(notification);
/*     */     
/* 164 */     if (goOn)
/*     */     {
/* 166 */       if ((notification instanceof MBeanServerNotification))
/*     */       {
/* 168 */         MBeanServerNotification n = (MBeanServerNotification)notification;
/* 169 */         ObjectName name = n.getMBeanName();
/*     */         
/* 171 */         if (this.m_enabledObjectNames == null)
/*     */         {
/*     */ 
/* 174 */           if ((this.m_disabledObjectNames != null) && (this.m_disabledObjectNames.contains(name)))
/*     */           {
/*     */ 
/* 177 */             return false;
/*     */           }
/*     */           
/*     */ 
/* 181 */           return true;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 187 */         if (this.m_enabledObjectNames.contains(name))
/*     */         {
/*     */ 
/* 190 */           return true;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 195 */         return false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 201 */     return false;
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/* 206 */     ObjectInputStream.GetField fields = in.readFields();
/*     */     
/* 208 */     Vector vector = (Vector)fields.get(serialNames[0], null);
/* 209 */     if (fields.defaulted(serialNames[0]))
/*     */     {
/* 211 */       throw new IOException("Serialized stream corrupted: expecting a non-null Vector");
/*     */     }
/* 213 */     if (vector != null)
/*     */     {
/* 215 */       if (this.m_enabledObjectNames == null)
/*     */       {
/* 217 */         this.m_enabledObjectNames = new HashSet();
/*     */       }
/* 219 */       this.m_enabledObjectNames.clear();
/* 220 */       this.m_enabledObjectNames.addAll(vector);
/*     */     }
/*     */     
/* 223 */     vector = (Vector)fields.get(serialNames[1], null);
/* 224 */     if (fields.defaulted(serialNames[1]))
/*     */     {
/* 226 */       throw new IOException("Serialized stream corrupted: expecting a non-null Vector");
/*     */     }
/* 228 */     if (vector != null)
/*     */     {
/* 230 */       if (this.m_disabledObjectNames == null)
/*     */       {
/* 232 */         this.m_disabledObjectNames = new HashSet();
/*     */       }
/* 234 */       this.m_disabledObjectNames.clear();
/* 235 */       this.m_disabledObjectNames.addAll(vector);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException
/*     */   {
/* 241 */     ObjectOutputStream.PutField fields = out.putFields();
/*     */     
/* 243 */     Vector vector = getEnabledObjectNames();
/* 244 */     fields.put(serialNames[0], vector);
/*     */     
/* 246 */     vector = getDisabledObjectNames();
/* 247 */     fields.put(serialNames[1], vector);
/*     */     
/* 249 */     out.writeFields();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/MBeanServerNotificationFilter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */