/*    */ package javax.management.relation;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleList
/*    */   extends ArrayList
/*    */ {
/*    */   private static final long serialVersionUID = 5568344346499649313L;
/*    */   
/*    */   public RoleList() {}
/*    */   
/*    */   public RoleList(int initialCapacity)
/*    */   {
/* 28 */     super(initialCapacity);
/*    */   }
/*    */   
/*    */   public RoleList(List list) throws IllegalArgumentException
/*    */   {
/* 33 */     if (list == null) throw new IllegalArgumentException("list argument must not be null");
/* 34 */     for (Iterator listIterator = list.iterator(); listIterator.hasNext();)
/*    */     {
/* 36 */       Object currentListItem = listIterator.next();
/* 37 */       if (!(currentListItem instanceof Role))
/*    */       {
/* 39 */         throw new IllegalArgumentException("Item added to the RoleList: " + currentListItem + " does not represent a Role");
/*    */       }
/* 41 */       add((Role)currentListItem);
/*    */     }
/*    */   }
/*    */   
/*    */   public void add(Role role) throws IllegalArgumentException
/*    */   {
/* 47 */     if (role == null)
/*    */     {
/* 49 */       throw new IllegalArgumentException("A role cannot be null");
/*    */     }
/* 51 */     super.add(role);
/*    */   }
/*    */   
/*    */   public void add(int index, Role role) throws IllegalArgumentException, IndexOutOfBoundsException
/*    */   {
/* 56 */     if (role == null)
/*    */     {
/* 58 */       throw new IllegalArgumentException("Cannot have a null role value");
/*    */     }
/* 60 */     super.add(index, role);
/*    */   }
/*    */   
/*    */   public void set(int index, Role role) throws IllegalArgumentException, IndexOutOfBoundsException
/*    */   {
/* 65 */     if (role == null)
/*    */     {
/* 67 */       throw new IllegalArgumentException("Cannot have a null role");
/*    */     }
/* 69 */     super.set(index, role);
/*    */   }
/*    */   
/*    */   public boolean addAll(RoleList roleList) throws IndexOutOfBoundsException
/*    */   {
/* 74 */     if (roleList == null)
/*    */     {
/* 76 */       return true;
/*    */     }
/* 78 */     return super.addAll(roleList);
/*    */   }
/*    */   
/*    */   public boolean addAll(int index, RoleList roleList) throws IllegalArgumentException, IndexOutOfBoundsException
/*    */   {
/* 83 */     if (roleList == null)
/*    */     {
/* 85 */       return true;
/*    */     }
/* 87 */     return super.addAll(index, roleList);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RoleList.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */