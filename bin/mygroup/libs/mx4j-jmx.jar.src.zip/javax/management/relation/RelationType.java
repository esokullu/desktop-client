package javax.management.relation;

import java.io.Serializable;
import java.util.List;

public abstract interface RelationType
  extends Serializable
{
  public abstract String getRelationTypeName();
  
  public abstract RoleInfo getRoleInfo(String paramString)
    throws RoleInfoNotFoundException;
  
  public abstract List getRoleInfos();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RelationType.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */