/*     */ package javax.management.relation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Role
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -279985518429862552L;
/*     */   private String name;
/*     */   private List objectNameList;
/*     */   
/*     */   public Role(String roleName, List roleValueList)
/*     */     throws IllegalArgumentException
/*     */   {
/*  29 */     setRoleName(roleName);
/*     */     
/*  31 */     setRoleValue(roleValueList);
/*     */   }
/*     */   
/*     */   public void setRoleName(String roleName) throws IllegalArgumentException
/*     */   {
/*  36 */     if (roleName == null) throw new IllegalArgumentException("Cannot have a null role name");
/*  37 */     this.name = roleName;
/*     */   }
/*     */   
/*     */   public void setRoleValue(List roleValues) throws IllegalArgumentException
/*     */   {
/*  42 */     if (roleValues == null) throw new IllegalArgumentException("List of role values cannot be null");
/*  43 */     if (this.objectNameList == null)
/*     */     {
/*  45 */       this.objectNameList = new ArrayList();
/*     */     }
/*  47 */     this.objectNameList.clear();
/*  48 */     this.objectNameList.addAll(roleValues);
/*     */   }
/*     */   
/*     */   public String getRoleName()
/*     */   {
/*  53 */     return this.name;
/*     */   }
/*     */   
/*     */   public List getRoleValue()
/*     */   {
/*  58 */     return new ArrayList(this.objectNameList);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  63 */     StringBuffer roleToString = new StringBuffer("roleName: ");
/*  64 */     roleToString.append(this.name);
/*  65 */     roleToString.append("\nroleValue: ");
/*  66 */     String values = roleValueToString(this.objectNameList);
/*  67 */     roleToString.append(values);
/*  68 */     return roleToString.toString();
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*     */     try
/*     */     {
/*  75 */       return new Role(this.name, this.objectNameList);
/*     */     }
/*     */     catch (IllegalArgumentException ignored) {}
/*     */     
/*     */ 
/*  80 */     return null;
/*     */   }
/*     */   
/*     */   public static String roleValueToString(List roleValues)
/*     */     throws IllegalArgumentException
/*     */   {
/*  86 */     StringBuffer valuesToString = new StringBuffer();
/*  87 */     for (Iterator roleValuesIterator = roleValues.iterator(); roleValuesIterator.hasNext();)
/*     */     {
/*  89 */       ObjectName currentObjName = (ObjectName)roleValuesIterator.next();
/*  90 */       valuesToString.append(currentObjName.toString());
/*     */       
/*  92 */       if (roleValuesIterator.hasNext())
/*     */       {
/*  94 */         valuesToString.append("\n");
/*     */       }
/*     */     }
/*  97 */     return valuesToString.toString();
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/* 102 */     if (this == o) return true;
/* 103 */     if (!(o instanceof Role)) { return false;
/*     */     }
/* 105 */     Role role = (Role)o;
/*     */     
/* 107 */     if (this.name != null ? !this.name.equals(role.name) : role.name != null) return false;
/* 108 */     if (this.objectNameList != null ? !this.objectNameList.equals(role.objectNameList) : role.objectNameList != null) { return false;
/*     */     }
/* 110 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 116 */     int result = this.name != null ? this.name.hashCode() : 0;
/* 117 */     result = 29 * result + (this.objectNameList != null ? this.objectNameList.hashCode() : 0);
/* 118 */     return result;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/Role.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */