/*     */ package javax.management.relation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RoleUnresolved
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -48350262537070138L;
/*     */   private String roleName;
/*     */   private List roleValue;
/*     */   private int problemType;
/*     */   
/*     */   public RoleUnresolved(String roleName, List roleValues, int problemType)
/*     */     throws IllegalArgumentException
/*     */   {
/*  29 */     setRoleName(roleName);
/*  30 */     setRoleValue(roleValues);
/*  31 */     setProblemType(problemType);
/*     */   }
/*     */   
/*     */   public int getProblemType()
/*     */   {
/*  36 */     return this.problemType;
/*     */   }
/*     */   
/*     */   public String getRoleName()
/*     */   {
/*  41 */     return this.roleName;
/*     */   }
/*     */   
/*     */ 
/*     */   public List getRoleValue()
/*     */   {
/*  47 */     return this.roleValue == null ? null : new ArrayList(this.roleValue);
/*     */   }
/*     */   
/*     */   public void setRoleName(String name)
/*     */   {
/*  52 */     if (name == null) throw new IllegalArgumentException("Role Name cannot be null");
/*  53 */     this.roleName = name;
/*     */   }
/*     */   
/*     */   public void setRoleValue(List list)
/*     */   {
/*  58 */     if (list != null)
/*     */     {
/*  60 */       if (this.roleValue == null)
/*     */       {
/*  62 */         this.roleValue = new ArrayList();
/*     */       }
/*  64 */       this.roleValue.clear();
/*  65 */       this.roleValue.addAll(list);
/*     */     }
/*     */     else
/*     */     {
/*  69 */       this.roleValue = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setProblemType(int type)
/*     */   {
/*  75 */     if (!RoleStatus.isRoleStatus(type))
/*     */     {
/*  77 */       throw new IllegalArgumentException("Problem Type unknown");
/*     */     }
/*  79 */     this.problemType = type;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*     */     try
/*     */     {
/*  86 */       RoleUnresolved tempRole = (RoleUnresolved)super.clone();
/*     */       
/*  88 */       tempRole.roleValue = getRoleValue();
/*  89 */       return tempRole;
/*     */     }
/*     */     catch (CloneNotSupportedException ignored) {}
/*     */     
/*  93 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  99 */     StringBuffer roleBuff = new StringBuffer();
/* 100 */     roleBuff.append("Role Name: ").append(this.roleName);
/* 101 */     Iterator i; if (this.roleValue != null)
/*     */     {
/* 103 */       roleBuff.append("\nRole Values:");
/* 104 */       for (i = this.roleValue.iterator(); i.hasNext();)
/*     */       {
/* 106 */         ObjectName objectName = (ObjectName)i.next();
/* 107 */         roleBuff.append(objectName);
/* 108 */         if (i.hasNext())
/*     */         {
/* 110 */           roleBuff.append(", ");
/*     */         }
/*     */       }
/*     */     }
/* 114 */     roleBuff.append("\nProblem Type:");
/* 115 */     roleBuff.append(this.problemType);
/* 116 */     return roleBuff.toString();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RoleUnresolved.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */