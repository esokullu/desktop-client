/*    */ package javax.management.relation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidRoleValueException
/*    */   extends RelationException
/*    */ {
/*    */   private static final long serialVersionUID = -2066091747301983721L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidRoleValueException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidRoleValueException(String s)
/*    */   {
/* 24 */     super(s);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/InvalidRoleValueException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */