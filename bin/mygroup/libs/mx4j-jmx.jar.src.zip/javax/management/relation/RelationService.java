/*      */ package javax.management.relation;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.management.InstanceNotFoundException;
/*      */ import javax.management.MBeanNotificationInfo;
/*      */ import javax.management.MBeanRegistration;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.MBeanServerInvocationHandler;
/*      */ import javax.management.MBeanServerNotification;
/*      */ import javax.management.MalformedObjectNameException;
/*      */ import javax.management.Notification;
/*      */ import javax.management.NotificationBroadcasterSupport;
/*      */ import javax.management.NotificationListener;
/*      */ import javax.management.ObjectName;
/*      */ import javax.management.RuntimeOperationsException;
/*      */ import mx4j.log.Log;
/*      */ import mx4j.log.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RelationService
/*      */   extends NotificationBroadcasterSupport
/*      */   implements RelationServiceMBean, MBeanRegistration, NotificationListener
/*      */ {
/*      */   private boolean m_purgeFlag;
/*   46 */   private Long m_notificationCounter = new Long(0L);
/*      */   
/*   48 */   private MBeanServer m_server = null;
/*   49 */   private RelationSupportMBean m_proxy = null;
/*   50 */   private ObjectName m_relationServiceObjectName = null;
/*      */   
/*   52 */   private MBeanServerNotificationFilter m_notificationFilter = null;
/*      */   
/*   54 */   private Map m_relationIdToRelationObject = new HashMap();
/*   55 */   private Map m_relationIdToRelationTypeName = new HashMap();
/*   56 */   private Map m_relationMBeanObjectNameToRelationId = new HashMap();
/*   57 */   private Map m_relationTypeNameToRelationTypeObject = new HashMap();
/*   58 */   private Map m_relationTypeNameToRelationIds = new HashMap();
/*   59 */   private Map m_referencedMBeanObjectNameToRelationIds = new HashMap();
/*      */   
/*   61 */   private List m_deregisteredNotificationList = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RelationService(boolean purgeFlag)
/*      */   {
/*   73 */     this.m_purgeFlag = purgeFlag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void isActive()
/*      */     throws RelationServiceNotRegisteredException
/*      */   {
/*   83 */     Logger logger = getLogger();
/*   84 */     if (this.m_server == null)
/*      */     {
/*   86 */       logger.error("RelationService has not been registered in the MBeanServer");
/*   87 */       throw new RelationServiceNotRegisteredException("Relation Service is not registered");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getPurgeFlag()
/*      */   {
/*   97 */     return this.m_purgeFlag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPurgeFlag(boolean purgeFlag)
/*      */   {
/*  107 */     this.m_purgeFlag = purgeFlag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void createRelationType(String relationTypeName, RoleInfo[] roleInfos)
/*      */     throws IllegalArgumentException, InvalidRelationTypeException
/*      */   {
/*  125 */     if (relationTypeName == null) throw new IllegalArgumentException("Illegal Null Relation Type Name value");
/*  126 */     if (roleInfos == null) { throw new IllegalArgumentException("Illegal Null RoleInfo");
/*      */     }
/*  128 */     Logger logger = getLogger();
/*  129 */     if (logger.isEnabledFor(10)) { logger.debug("Creating Relation Type with relationTypeName: " + relationTypeName);
/*      */     }
/*  131 */     RelationTypeSupport relationType = new RelationTypeSupport(relationTypeName, roleInfos);
/*      */     
/*  133 */     addRelationTypeToMap(relationTypeName, relationType);
/*      */   }
/*      */   
/*      */ 
/*      */   private void addRelationTypeToMap(String relationTypeName, RelationType relationType)
/*      */   {
/*  139 */     Logger logger = getLogger();
/*      */     
/*  141 */     synchronized (this.m_relationTypeNameToRelationTypeObject)
/*      */     {
/*  143 */       if (this.m_relationTypeNameToRelationTypeObject.get(relationTypeName) != null)
/*      */       {
/*  145 */         logger.warn("Cannot addRelationType as a relationType of the same name: " + relationTypeName + " already exists in the RelationService");
/*  146 */         throw new IllegalArgumentException("RelationType with name: " + relationTypeName + " already exists in the RelationService");
/*      */       }
/*      */       
/*  149 */       if ((relationType instanceof RelationTypeSupport))
/*      */       {
/*  151 */         ((RelationTypeSupport)relationType).setRelationServiceFlag(true);
/*      */       }
/*      */       
/*  154 */       this.m_relationTypeNameToRelationTypeObject.put(relationTypeName, relationType);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private RelationType getRelationType(String relationTypeName)
/*      */     throws IllegalArgumentException, RelationTypeNotFoundException
/*      */   {
/*  163 */     synchronized (this.m_relationTypeNameToRelationTypeObject)
/*      */     {
/*  165 */       RelationType relationType = (RelationType)this.m_relationTypeNameToRelationTypeObject.get(relationTypeName);
/*      */       
/*  167 */       if (relationType == null)
/*      */       {
/*  169 */         throw new RelationTypeNotFoundException("No RelationType found for relationTypeName: " + relationTypeName);
/*      */       }
/*  171 */       return relationType;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRelationType(RelationType relationType)
/*      */     throws IllegalArgumentException, InvalidRelationTypeException
/*      */   {
/*  190 */     if (relationType == null) { throw new IllegalArgumentException("Relation Type should not be null.");
/*      */     }
/*  192 */     Logger logger = getLogger();
/*  193 */     if (logger.isEnabledFor(10)) { logger.debug("Adding a RelationType");
/*      */     }
/*  195 */     List roleInfoList = relationType.getRoleInfos();
/*  196 */     if (roleInfoList == null)
/*      */     {
/*  198 */       logger.warn("Cannot add RelationType: " + relationType.getClass().getName() + " RoleInfo information was not provided with the RelationType.");
/*  199 */       throw new IllegalArgumentException("No RoleInfo provided with Relation Type");
/*      */     }
/*      */     
/*  202 */     RoleInfo[] roleInfos = new RoleInfo[roleInfoList.size()];
/*  203 */     int index = 0;
/*  204 */     for (Iterator i = roleInfoList.iterator(); i.hasNext();)
/*      */     {
/*  206 */       RoleInfo currentRoleInfo = (RoleInfo)i.next();
/*  207 */       roleInfos[index] = currentRoleInfo;
/*  208 */       index++;
/*      */     }
/*      */     
/*  211 */     RelationTypeSupport.checkRoleInfos(roleInfos);
/*  212 */     String relationTypeName = relationType.getRelationTypeName();
/*      */     
/*  214 */     addRelationTypeToMap(relationTypeName, relationType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public List getAllRelationTypeNames()
/*      */   {
/*      */     List result;
/*      */     
/*  223 */     synchronized (this.m_relationTypeNameToRelationTypeObject)
/*      */     {
/*  225 */       result = new ArrayList(this.m_relationTypeNameToRelationTypeObject.keySet());
/*      */     }
/*      */     List result;
/*  228 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List getRoleInfos(String relationTypeName)
/*      */     throws IllegalArgumentException, RelationTypeNotFoundException
/*      */   {
/*  240 */     if (relationTypeName == null) throw new IllegalArgumentException("Illegal relationType name is null.");
/*  241 */     RelationType relationType = getRelationType(relationTypeName);
/*      */     
/*  243 */     return relationType.getRoleInfos();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RoleInfo getRoleInfo(String relationTypeName, String roleInfoName)
/*      */     throws IllegalArgumentException, RelationTypeNotFoundException, RoleInfoNotFoundException
/*      */   {
/*  257 */     if (relationTypeName == null) throw new IllegalArgumentException("Null relation type name");
/*  258 */     if (roleInfoName == null) { throw new IllegalArgumentException("Null RoleInfo name");
/*      */     }
/*  260 */     return getRelationType(relationTypeName).getRoleInfo(roleInfoName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeRelationType(String relationTypeName)
/*      */     throws IllegalArgumentException, RelationServiceNotRegisteredException, RelationTypeNotFoundException
/*      */   {
/*  279 */     Logger logger = getLogger();
/*  280 */     isActive();
/*  281 */     if (relationTypeName == null) throw new IllegalArgumentException("Illegal: relationType name cannot be null.");
/*  282 */     if (logger.isEnabledFor(10)) { logger.debug("Removing RelationType with relationTypeName: " + relationTypeName);
/*      */     }
/*      */     
/*  285 */     List tempList = getRelationIds(relationTypeName);
/*      */     
/*  287 */     if (tempList == null)
/*      */     {
/*  289 */       logger.debug("no relationType named " + relationTypeName + " has not been found: have you called addRelationType()");
/*  290 */       tempList = new ArrayList();
/*      */     }
/*      */     
/*      */ 
/*  294 */     List relationIdList = tempList;
/*  295 */     removeRelationTypeObject(relationTypeName);
/*  296 */     removeRelationTypeName(relationTypeName);
/*      */     
/*  298 */     for (Iterator i = relationIdList.iterator(); i.hasNext();)
/*      */     {
/*  300 */       String currentRelationId = (String)i.next();
/*      */       
/*      */       try
/*      */       {
/*  304 */         removeRelation(currentRelationId);
/*      */       }
/*      */       catch (RelationNotFoundException ex)
/*      */       {
/*  308 */         throw new RuntimeOperationsException(null, ex.toString());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void removeRelationTypeObject(String relationTypeName)
/*      */   {
/*  316 */     synchronized (this.m_relationTypeNameToRelationTypeObject)
/*      */     {
/*  318 */       this.m_relationTypeNameToRelationTypeObject.remove(relationTypeName);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private List getRelationIds(String relationTypeName)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 20	javax/management/relation/RelationService:m_relationTypeNameToRelationIds	Ljava/util/Map;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 20	javax/management/relation/RelationService:m_relationTypeNameToRelationIds	Ljava/util/Map;
/*      */     //   11: aload_1
/*      */     //   12: invokeinterface 46 2 0
/*      */     //   17: checkcast 94	java/util/List
/*      */     //   20: aload_2
/*      */     //   21: monitorexit
/*      */     //   22: areturn
/*      */     //   23: astore_3
/*      */     //   24: aload_2
/*      */     //   25: monitorexit
/*      */     //   26: aload_3
/*      */     //   27: athrow
/*      */     // Line number table:
/*      */     //   Java source line #324	-> byte code offset #0
/*      */     //   Java source line #326	-> byte code offset #7
/*      */     //   Java source line #327	-> byte code offset #23
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	28	0	this	RelationService
/*      */     //   0	28	1	relationTypeName	String
/*      */     //   5	20	2	Ljava/lang/Object;	Object
/*      */     //   23	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	22	23	finally
/*      */     //   23	26	23	finally
/*      */   }
/*      */   
/*      */   public void createRelation(String relationId, String relationTypeName, RoleList roleList)
/*      */     throws IllegalArgumentException, RelationServiceNotRegisteredException, RoleNotFoundException, InvalidRelationIdException, RelationTypeNotFoundException, InvalidRoleValueException
/*      */   {
/*  350 */     isActive();
/*  351 */     if (relationId == null) throw new IllegalArgumentException("Null Relation Id");
/*  352 */     if (relationTypeName == null) throw new IllegalArgumentException("Null Relation Type Name");
/*  353 */     Logger logger = getLogger();
/*  354 */     if (logger.isEnabledFor(10))
/*      */     {
/*  356 */       logger.debug("Creating an InternalRelation with ID: " + relationId + " and relationType name: " + relationTypeName);
/*      */     }
/*      */     
/*  359 */     InternalRelation internalRelation = new InternalRelation(relationId, this.m_relationServiceObjectName, relationTypeName, roleList);
/*      */     
/*      */     try
/*      */     {
/*  363 */       if (getRelationObject(relationId) != null)
/*      */       {
/*  365 */         logger.warn("There is a Relation already registered in the RelationServcie with ID: " + relationId);
/*  366 */         throw new InvalidRelationIdException("There is already a relation with id: " + relationId);
/*      */       }
/*      */     }
/*      */     catch (RelationNotFoundException ex) {}
/*      */     
/*      */ 
/*      */ 
/*  373 */     RelationType relationType = getRelationType(relationTypeName);
/*  374 */     ArrayList roleInfoList = (ArrayList)buildRoleInfoList(relationType, roleList);
/*  375 */     if (!roleInfoList.isEmpty())
/*      */     {
/*  377 */       initializeMissingCreateRoles(roleInfoList, internalRelation, relationId, relationTypeName);
/*      */     }
/*      */     
/*  380 */     synchronized (this.m_relationIdToRelationObject)
/*      */     {
/*  382 */       this.m_relationIdToRelationObject.put(relationId, internalRelation);
/*      */     }
/*  384 */     addRelationId(relationId, relationTypeName);
/*  385 */     addRelationTypeName(relationId, relationTypeName);
/*  386 */     updateRoles(roleList, relationId);
/*      */     try
/*      */     {
/*  389 */       if (logger.isEnabledFor(10)) logger.debug("sending RelationCreation notification to all listeners");
/*  390 */       sendRelationCreationNotification(relationId);
/*      */     }
/*      */     catch (RelationNotFoundException ex)
/*      */     {
/*  394 */       throw new RuntimeOperationsException(null, "Unable to send notification as Relation not found");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void updateRoles(RoleList roleList, String relationId)
/*      */     throws RelationServiceNotRegisteredException, IllegalArgumentException
/*      */   {
/*  402 */     if (roleList == null) throw new IllegalArgumentException("Null RoleList");
/*  403 */     if (relationId == null) throw new IllegalArgumentException("Null relationId");
/*  404 */     for (Iterator i = roleList.iterator(); i.hasNext();)
/*      */     {
/*  406 */       Role currentRole = (Role)i.next();
/*  407 */       ArrayList tempList = new ArrayList();
/*      */       try
/*      */       {
/*  410 */         updateRoleMap(relationId, currentRole, tempList);
/*      */       }
/*      */       catch (RelationNotFoundException ex)
/*      */       {
/*  414 */         throw new RuntimeOperationsException(null, "Cannot update the roleMap as Relation not found");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private List buildRoleInfoList(RelationType relationType, List roleList)
/*      */     throws InvalidRoleValueException, RoleNotFoundException
/*      */   {
/*  422 */     List roleInfoList = relationType.getRoleInfos();
/*  423 */     Iterator i; if (roleList != null)
/*      */     {
/*  425 */       for (i = roleList.iterator(); i.hasNext();)
/*      */       {
/*  427 */         Role currentRole = (Role)i.next();
/*  428 */         String currentRoleName = currentRole.getRoleName();
/*  429 */         List currentRoleValue = currentRole.getRoleValue();
/*      */         
/*      */         try
/*      */         {
/*  433 */           roleInfo = relationType.getRoleInfo(currentRoleName);
/*      */         }
/*      */         catch (RoleInfoNotFoundException ex) {
/*      */           RoleInfo roleInfo;
/*  437 */           throw new RoleNotFoundException(ex.getMessage()); }
/*      */         RoleInfo roleInfo;
/*  439 */         int problemType = checkRoleCardinality(currentRoleName, currentRoleValue, roleInfo).intValue();
/*  440 */         if (problemType != 0)
/*      */         {
/*  442 */           throwRoleProblemException(problemType, currentRoleName);
/*      */         }
/*  444 */         roleInfoList.remove(roleInfoList.indexOf(roleInfo));
/*      */       }
/*      */     }
/*  447 */     return roleInfoList;
/*      */   }
/*      */   
/*      */   private void addRelationTypeName(String relationId, String relationTypeName)
/*      */   {
/*  452 */     synchronized (this.m_relationTypeNameToRelationIds)
/*      */     {
/*  454 */       ArrayList idList = (ArrayList)this.m_relationTypeNameToRelationIds.get(relationTypeName);
/*  455 */       boolean isNewRelation = false;
/*  456 */       if (idList == null)
/*      */       {
/*  458 */         isNewRelation = true;
/*  459 */         idList = new ArrayList();
/*      */       }
/*  461 */       idList.add(relationId);
/*  462 */       if (isNewRelation) this.m_relationTypeNameToRelationIds.put(relationTypeName, idList);
/*      */     }
/*      */   }
/*      */   
/*      */   private void addRelationObjectName(String relationId, ObjectName relationObjectName)
/*      */   {
/*  468 */     synchronized (this.m_relationIdToRelationObject)
/*      */     {
/*  470 */       this.m_relationIdToRelationObject.put(relationId, relationObjectName);
/*      */     }
/*      */   }
/*      */   
/*      */   private void addRelationId(String relationId, String relationTypeName)
/*      */   {
/*  476 */     synchronized (this.m_relationIdToRelationTypeName)
/*      */     {
/*  478 */       this.m_relationIdToRelationTypeName.put(relationId, relationTypeName);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initializeMissingCreateRoles(List roleInfoList, InternalRelation internalRelation, String relationId, String relationTypeName)
/*      */     throws RelationTypeNotFoundException, RelationServiceNotRegisteredException, InvalidRoleValueException, RoleNotFoundException, IllegalArgumentException
/*      */   {
/*  488 */     isActive();
/*  489 */     if (roleInfoList == null) throw new IllegalArgumentException("RoleInfoList is Null");
/*  490 */     if (relationId == null) throw new IllegalArgumentException("RelationId is Null.");
/*  491 */     if (relationTypeName == null) { throw new IllegalArgumentException("Relation Type Name is Null.");
/*      */     }
/*  493 */     for (Iterator i = roleInfoList.iterator(); i.hasNext();)
/*      */     {
/*  495 */       RoleInfo currentRoleInfo = (RoleInfo)i.next();
/*  496 */       String roleName = currentRoleInfo.getName();
/*      */       
/*  498 */       ArrayList temp = new ArrayList();
/*  499 */       Role role = new Role(roleName, temp);
/*      */       try
/*      */       {
/*  502 */         internalRelation.setRole(role);
/*      */       }
/*      */       catch (RelationNotFoundException ex)
/*      */       {
/*  506 */         throw new RuntimeOperationsException(null, ex.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private Integer checkRoleCardinality(String roleName, List roleValue, RoleInfo roleInfo)
/*      */   {
/*  513 */     if (roleName == null) throw new IllegalArgumentException("Null Role Name");
/*  514 */     if (roleValue == null) throw new IllegalArgumentException("Null roleValue List");
/*  515 */     if (roleInfo == null) throw new IllegalArgumentException("Null RoleInfo");
/*  516 */     Logger logger = getLogger();
/*  517 */     if (logger.isEnabledFor(10)) { logger.debug("checking role cardinality");
/*      */     }
/*  519 */     if (!roleName.equals(roleInfo.getName()))
/*      */     {
/*  521 */       logger.warn("Role does not have a valid roleName");
/*  522 */       return new Integer(1);
/*      */     }
/*  524 */     if (!roleInfo.checkMinDegree(roleValue.size()))
/*      */     {
/*  526 */       logger.warn("Minimum number of references defined in the RoleInfo has fallen below minimum");
/*  527 */       return new Integer(4);
/*      */     }
/*  529 */     if (!roleInfo.checkMaxDegree(roleValue.size()))
/*      */     {
/*  531 */       logger.warn("Maximum number of references defined in the RoleInfo has gone above the maximum");
/*  532 */       return new Integer(5);
/*      */     }
/*      */     
/*  535 */     String referencedClassName = roleInfo.getRefMBeanClassName();
/*  536 */     for (Iterator i = roleValue.iterator(); i.hasNext();)
/*      */     {
/*  538 */       ObjectName currentObjectName = (ObjectName)i.next();
/*  539 */       if (currentObjectName == null)
/*      */       {
/*  541 */         logger.warn("The mbean with RoleName: " + roleName + " is not registered in the MBeanServer");
/*  542 */         return new Integer(7);
/*      */       }
/*  544 */       if (!this.m_server.isRegistered(currentObjectName))
/*      */       {
/*  546 */         logger.warn("The mbean with ObjectName: " + currentObjectName.getCanonicalName() + " is not registered in the MBeanServer");
/*  547 */         return new Integer(7);
/*      */       }
/*      */       try
/*      */       {
/*  551 */         if (!this.m_server.isInstanceOf(currentObjectName, referencedClassName))
/*      */         {
/*  553 */           logger.warn("The class referenced: " + currentObjectName.toString() + " does not match the class expected: " + referencedClassName + " in RoleInfo: " + roleInfo.toString());
/*      */           
/*  555 */           return new Integer(6);
/*      */         }
/*      */       }
/*      */       catch (InstanceNotFoundException ex)
/*      */       {
/*  560 */         return null;
/*      */       }
/*      */     }
/*  563 */     return new Integer(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRelation(ObjectName relationMBeanObjectName)
/*      */     throws IllegalArgumentException, RelationServiceNotRegisteredException, NoSuchMethodException, InvalidRelationIdException, InstanceNotFoundException, InvalidRelationServiceException, RelationTypeNotFoundException, RoleNotFoundException, InvalidRoleValueException
/*      */   {
/*  601 */     isActive();
/*  602 */     Logger logger = getLogger();
/*  603 */     if (logger.isEnabledFor(10)) { logger.debug("adding a Relation with ObjectName: " + relationMBeanObjectName.toString());
/*      */     }
/*      */     
/*  606 */     checkValidRelation(relationMBeanObjectName);
/*      */     
/*      */ 
/*  609 */     this.m_proxy = ((RelationSupportMBean)MBeanServerInvocationHandler.newProxyInstance(this.m_server, relationMBeanObjectName, RelationSupportMBean.class, false));
/*      */     
/*  611 */     String relationId = this.m_proxy.getRelationId();
/*  612 */     if (relationId == null) { throw new InvalidRelationIdException("No RelationId provided");
/*      */     }
/*      */     
/*  615 */     ObjectName relationServiceObjectName = this.m_proxy.getRelationServiceName();
/*      */     
/*  617 */     if (!checkRelationServiceIsCurrent(relationServiceObjectName))
/*      */     {
/*  619 */       throw new InvalidRelationServiceException("The Relation Service referenced in the MBean is not the current one.");
/*      */     }
/*      */     
/*  622 */     String relationTypeName = this.m_proxy.getRelationTypeName();
/*  623 */     if (relationTypeName == null) { throw new RelationTypeNotFoundException("RelationType not found");
/*      */     }
/*  625 */     RoleList roleList = this.m_proxy.retrieveAllRoles();
/*      */     
/*      */     try
/*      */     {
/*  629 */       if (getRelationObject(relationId) != null) { throw new InvalidRelationIdException("Relation with ID " + relationId + " already exists");
/*      */       }
/*      */     }
/*      */     catch (RelationNotFoundException ex) {}
/*      */     
/*      */ 
/*  635 */     RelationType relationType = getRelationType(relationTypeName);
/*  636 */     ArrayList roleInfoList = (ArrayList)buildRoleInfoList(relationType, roleList);
/*  637 */     Iterator i; if (!roleInfoList.isEmpty())
/*      */     {
/*  639 */       for (i = roleInfoList.iterator(); i.hasNext();)
/*      */       {
/*  641 */         RoleInfo currentRoleInfo = (RoleInfo)i.next();
/*  642 */         String currentRoleName = currentRoleInfo.getName();
/*  643 */         ArrayList emptyValueList = new ArrayList();
/*  644 */         Role role = new Role(currentRoleName, emptyValueList);
/*      */         try
/*      */         {
/*  647 */           this.m_proxy.setRole(role);
/*      */         }
/*      */         catch (RelationNotFoundException ex)
/*      */         {
/*  651 */           throw new RuntimeOperationsException(null, ex.getMessage());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  656 */     updateAllInternals(relationId, relationMBeanObjectName, relationTypeName, roleList);
/*      */   }
/*      */   
/*      */ 
/*      */   private void updateAllInternals(String relationId, ObjectName relationMBeanObjectName, String relationTypeName, RoleList roleList)
/*      */     throws RelationServiceNotRegisteredException
/*      */   {
/*  663 */     addRelationObjectName(relationId, relationMBeanObjectName);
/*  664 */     addRelationId(relationId, relationTypeName);
/*  665 */     addRelationTypeName(relationId, relationTypeName);
/*  666 */     updateRoles(roleList, relationId);
/*      */     try
/*      */     {
/*  669 */       sendRelationCreationNotification(relationId);
/*      */     }
/*      */     catch (RelationNotFoundException ex)
/*      */     {
/*  673 */       throw new RuntimeOperationsException(null, "Cannot send a notification for relationId " + relationId + " as relation not found.");
/*      */     }
/*      */     
/*  676 */     synchronized (this.m_relationMBeanObjectNameToRelationId)
/*      */     {
/*  678 */       this.m_relationMBeanObjectNameToRelationId.put(relationMBeanObjectName, relationId);
/*      */     }
/*  680 */     this.m_proxy.setRelationServiceManagementFlag(new Boolean(true));
/*  681 */     List newReferenceList = new ArrayList();
/*  682 */     newReferenceList.add(relationMBeanObjectName);
/*  683 */     updateUnregistrationListener(newReferenceList, null);
/*      */   }
/*      */   
/*      */   private boolean checkRelationServiceIsCurrent(ObjectName relationServiceObjectName)
/*      */   {
/*  688 */     if (relationServiceObjectName == null) return false;
/*  689 */     if (!relationServiceObjectName.equals(this.m_relationServiceObjectName)) return false;
/*  690 */     return true;
/*      */   }
/*      */   
/*      */   private void checkValidRelation(ObjectName relationMBeanObjectName) throws IllegalArgumentException, InstanceNotFoundException
/*      */   {
/*  695 */     if (relationMBeanObjectName == null) throw new IllegalArgumentException("Cannot have a null Relation ObjectName");
/*  696 */     Logger logger = getLogger();
/*  697 */     if (!this.m_server.isInstanceOf(relationMBeanObjectName, "javax.management.relation.Relation"))
/*      */     {
/*  699 */       logger.warn("An MBean which is to be added as a Relation must implement the Relation interface");
/*  700 */       throw new InstanceNotFoundException("MBean does implement the Relation interface");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectName isRelationMBean(String relationId)
/*      */     throws IllegalArgumentException, RelationNotFoundException
/*      */   {
/*  715 */     if (relationId == null) throw new IllegalArgumentException("Null Relation Id.");
/*  716 */     Object result = getRelationObject(relationId);
/*  717 */     if ((result instanceof ObjectName))
/*      */     {
/*  719 */       return (ObjectName)result;
/*      */     }
/*  721 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String isRelation(ObjectName objectName)
/*      */     throws IllegalArgumentException
/*      */   {
/*  733 */     if (objectName == null) throw new IllegalArgumentException("Null ObjectName");
/*  734 */     return getMBeanObjectName(objectName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Boolean hasRelation(String relationId)
/*      */     throws IllegalArgumentException
/*      */   {
/*  746 */     if (relationId == null) throw new IllegalArgumentException("Null Relation Id");
/*  747 */     Boolean hasRelation = null;
/*      */     try
/*      */     {
/*  750 */       Object result = getRelationObject(relationId);
/*  751 */       if (result != null) hasRelation = Boolean.TRUE;
/*      */     }
/*      */     catch (RelationNotFoundException ex)
/*      */     {
/*  755 */       hasRelation = Boolean.FALSE;
/*      */     }
/*  757 */     return hasRelation;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public List getAllRelationIds()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 16	javax/management/relation/RelationService:m_relationIdToRelationObject	Ljava/util/Map;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: new 22	java/util/ArrayList
/*      */     //   10: dup
/*      */     //   11: aload_0
/*      */     //   12: getfield 16	javax/management/relation/RelationService:m_relationIdToRelationObject	Ljava/util/Map;
/*      */     //   15: invokeinterface 72 1 0
/*      */     //   20: invokespecial 73	java/util/ArrayList:<init>	(Ljava/util/Collection;)V
/*      */     //   23: aload_1
/*      */     //   24: monitorexit
/*      */     //   25: areturn
/*      */     //   26: astore_2
/*      */     //   27: aload_1
/*      */     //   28: monitorexit
/*      */     //   29: aload_2
/*      */     //   30: athrow
/*      */     // Line number table:
/*      */     //   Java source line #767	-> byte code offset #0
/*      */     //   Java source line #769	-> byte code offset #7
/*      */     //   Java source line #770	-> byte code offset #26
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	this	RelationService
/*      */     //   5	23	1	Ljava/lang/Object;	Object
/*      */     //   26	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	25	26	finally
/*      */     //   26	29	26	finally
/*      */   }
/*      */   
/*      */   public Integer checkRoleReading(String roleName, String relationTypeName)
/*      */     throws IllegalArgumentException, RelationTypeNotFoundException
/*      */   {
/*  790 */     if (roleName == null) throw new IllegalArgumentException("Null RoleName");
/*  791 */     if (relationTypeName == null) throw new IllegalArgumentException("Null RelationType name.");
/*  792 */     Logger logger = getLogger();
/*  793 */     if (logger.isEnabledFor(10)) logger.debug("checking if Role with RoleName: " + roleName + " is readable");
/*  794 */     RelationType relationType = getRelationType(relationTypeName);
/*      */     try
/*      */     {
/*  797 */       RoleInfo roleInfo = relationType.getRoleInfo(roleName);
/*  798 */       if (!roleName.equals(roleInfo.getName())) return new Integer(1);
/*  799 */       if (!roleInfo.isReadable())
/*      */       {
/*  801 */         logger.warn("RoleInfo: " + roleInfo.toString() + " cannot be read");
/*  802 */         return new Integer(2);
/*      */       }
/*      */     }
/*      */     catch (RoleInfoNotFoundException ex)
/*      */     {
/*  807 */       logger.warn("roleInfo for roleName: " + roleName + " has not been found.");
/*  808 */       return new Integer(1);
/*      */     }
/*  810 */     return new Integer(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Integer checkRoleWriting(Role role, String relationTypeName, Boolean isInitialized)
/*      */     throws IllegalArgumentException, RelationTypeNotFoundException
/*      */   {
/*  835 */     if (role == null) throw new IllegalArgumentException("checkRoleWriting was given a null Role");
/*  836 */     if (relationTypeName == null) throw new IllegalArgumentException("checkRoleWriting was given a null RelationTypeName");
/*  837 */     if (isInitialized == null) throw new IllegalArgumentException("checkRoleWriting was given a null Boolean");
/*  838 */     Logger logger = getLogger();
/*  839 */     RelationType relationType = getRelationType(relationTypeName);
/*  840 */     String roleName = role.getRoleName();
/*  841 */     if (logger.isEnabledFor(10)) logger.debug("checking if Role with RoleName: " + roleName + " is readable");
/*  842 */     ArrayList roleValue = (ArrayList)role.getRoleValue();
/*  843 */     boolean canWrite = true;
/*  844 */     if (isInitialized.booleanValue()) { canWrite = false;
/*      */     }
/*      */     try
/*      */     {
/*  848 */       roleInfo = relationType.getRoleInfo(roleName);
/*      */     }
/*      */     catch (RoleInfoNotFoundException ex) {
/*      */       RoleInfo roleInfo;
/*  852 */       logger.warn("roleInfo for roleName: " + roleName + " has not been found.");
/*  853 */       return new Integer(1); }
/*      */     RoleInfo roleInfo;
/*  855 */     if (canWrite)
/*      */     {
/*  857 */       if (!roleInfo.isWritable())
/*      */       {
/*  859 */         logger.warn("RoleInfo: " + roleInfo.toString() + " cannot be written to.");
/*  860 */         return new Integer(3);
/*      */       }
/*      */     }
/*  863 */     return checkRoleCardinality(roleName, roleValue, roleInfo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendRelationCreationNotification(String relationId)
/*      */     throws IllegalArgumentException, RelationNotFoundException
/*      */   {
/*  883 */     if (relationId == null) throw new IllegalArgumentException("Null Relation Id.");
/*  884 */     Logger logger = getLogger();
/*  885 */     String message = "Creation of relation " + relationId;
/*  886 */     String relationTypeName = getRelationTypeNameFromMap(relationId);
/*      */     
/*  888 */     if (logger.isEnabledFor(10)) {
/*  889 */       logger.debug("A relation has been created with ID: " + relationId + " and relationTypeName: " + relationTypeName + " ..sending notification");
/*      */     }
/*      */     
/*  892 */     ObjectName relationObjectName = isRelationMBean(relationId);
/*  893 */     String notificationType = getCreationNotificationType(relationObjectName);
/*  894 */     long sequenceNumber = getNotificationSequenceNumber().longValue();
/*  895 */     Date currentDate = new Date();
/*  896 */     long timestamp = currentDate.getTime();
/*  897 */     RelationNotification relationNotification = new RelationNotification(notificationType, this, sequenceNumber, timestamp, message, relationId, relationTypeName, relationObjectName, null);
/*      */     
/*  899 */     sendNotification(relationNotification);
/*      */   }
/*      */   
/*      */ 
/*      */   private Long getNotificationSequenceNumber()
/*      */   {
/*  905 */     synchronized (this.m_notificationCounter)
/*      */     {
/*  907 */       Long result = new Long(this.m_notificationCounter.longValue() + 1L);
/*  908 */       this.m_notificationCounter = new Long(result.longValue()); }
/*      */     Long result;
/*  910 */     return result;
/*      */   }
/*      */   
/*      */   private String getCreationNotificationType(ObjectName relationObjectName)
/*      */   {
/*  915 */     if (relationObjectName != null)
/*      */     {
/*  917 */       return "jmx.relation.creation.mbean";
/*      */     }
/*  919 */     return "jmx.relation.creation.basic";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendRoleUpdateNotification(String relationId, Role newRole, List oldRoleValues)
/*      */     throws IllegalArgumentException, RelationNotFoundException
/*      */   {
/*  942 */     if (relationId == null) throw new IllegalArgumentException("Null RelationId");
/*  943 */     if (newRole == null) throw new IllegalArgumentException("Null Role");
/*  944 */     if (oldRoleValues == null) { throw new IllegalArgumentException("Null List of role values");
/*      */     }
/*  946 */     Logger logger = getLogger();
/*  947 */     if (logger.isEnabledFor(10)) logger.debug("Sending a roleUpdateNotification of Relation with ID: " + relationId);
/*  948 */     String roleName = newRole.getRoleName();
/*  949 */     List newRoleValues = newRole.getRoleValue();
/*  950 */     String newRoleValueMessage = Role.roleValueToString(newRoleValues);
/*  951 */     String oldRoleValueMessage = Role.roleValueToString(oldRoleValues);
/*  952 */     StringBuffer message = new StringBuffer("Value of the role ");
/*  953 */     message.append(roleName);
/*  954 */     message.append(" has changed\nOld value:\n");
/*  955 */     message.append(oldRoleValueMessage);
/*  956 */     message.append("\nNew value:\n");
/*  957 */     message.append(newRoleValueMessage);
/*  958 */     if (logger.isEnabledFor(10)) logger.debug("Notification message: " + message.toString());
/*  959 */     String relationTypeName = getRelationTypeNameFromMap(relationId);
/*      */     
/*      */ 
/*  962 */     ObjectName relationObjectName = isRelationMBean(relationId);
/*      */     String notificationType;
/*  964 */     String notificationType; if (relationObjectName != null) {
/*  965 */       notificationType = "jmx.relation.update.mbean";
/*      */     } else {
/*  967 */       notificationType = "jmx.relation.update.basic";
/*      */     }
/*  969 */     long sequenceNumber = getNotificationSequenceNumber().longValue();
/*  970 */     Date currentDate = new Date();
/*  971 */     long timeStamp = currentDate.getTime();
/*      */     
/*  973 */     RelationNotification notification = new RelationNotification(notificationType, this, sequenceNumber, timeStamp, message.toString(), relationId, relationTypeName, relationObjectName, roleName, newRoleValues, oldRoleValues);
/*      */     
/*      */ 
/*  976 */     sendNotification(notification);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendRelationRemovalNotification(String relationId, List unregisteredMBeanList)
/*      */     throws IllegalArgumentException, RelationNotFoundException
/*      */   {
/*  996 */     if (relationId == null) { throw new IllegalArgumentException("Null RelationId");
/*      */     }
/*  998 */     Logger logger = getLogger();
/*  999 */     if (logger.isEnabledFor(10)) logger.debug("sending relationRemovalNotification of ID: " + relationId);
/* 1000 */     StringBuffer message = new StringBuffer("Removal of relation ");
/* 1001 */     message.append(relationId);
/* 1002 */     String relationTypeName = getRelationTypeNameFromMap(relationId);
/* 1003 */     ObjectName relationObjectName = isRelationMBean(relationId);
/*      */     String notificationType;
/* 1005 */     String notificationType; if (relationObjectName != null) {
/* 1006 */       notificationType = "jmx.relation.removal.mbean";
/*      */     } else
/* 1008 */       notificationType = "jmx.relation.removal.basic";
/* 1009 */     long sequenceNumber = getNotificationSequenceNumber().longValue();
/* 1010 */     Date currentDate = new Date();
/* 1011 */     long timeStamp = currentDate.getTime();
/* 1012 */     RelationNotification notification = new RelationNotification(notificationType, this, sequenceNumber, timeStamp, message.toString(), relationId, relationTypeName, relationObjectName, unregisteredMBeanList);
/*      */     
/*      */ 
/* 1015 */     sendNotification(notification);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateRoleMap(String relationId, Role role, List oldRoleValues)
/*      */     throws IllegalArgumentException, RelationServiceNotRegisteredException, RelationNotFoundException
/*      */   {
/* 1037 */     isActive();
/* 1038 */     if (relationId == null) throw new IllegalArgumentException("Null Relation Id");
/* 1039 */     if (role == null) throw new IllegalArgumentException("Null Role");
/* 1040 */     if (oldRoleValues == null) { throw new IllegalArgumentException("Null Role value list.");
/*      */     }
/* 1042 */     Logger logger = getLogger();
/* 1043 */     if (logger.isEnabledFor(10)) { logger.debug("Updating the RelationService RoleMap");
/*      */     }
/* 1045 */     String roleName = role.getRoleName();
/* 1046 */     List newRoleValue = role.getRoleValue();
/*      */     
/*      */ 
/* 1049 */     List oldValues = (ArrayList)((ArrayList)oldRoleValues).clone();
/*      */     
/*      */ 
/* 1052 */     List newReferenceList = new ArrayList();
/* 1053 */     for (Iterator i = newRoleValue.iterator(); i.hasNext();)
/*      */     {
/* 1055 */       ObjectName currentObjectName = (ObjectName)i.next();
/*      */       
/* 1057 */       int currentObjectNamePosition = oldValues.indexOf(currentObjectName);
/*      */       
/* 1059 */       if (currentObjectNamePosition == -1)
/*      */       {
/*      */ 
/* 1062 */         if (addNewMBeanReference(currentObjectName, relationId, roleName))
/*      */         {
/*      */ 
/* 1065 */           newReferenceList.add(currentObjectName);
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else {
/* 1071 */         oldValues.remove(currentObjectNamePosition);
/*      */       }
/*      */     }
/* 1074 */     List obsoleteReferenceList = getObsoleteReferenceList(oldValues, relationId, roleName);
/*      */     
/* 1076 */     updateUnregistrationListener(newReferenceList, obsoleteReferenceList);
/*      */   }
/*      */   
/*      */   private List getObsoleteReferenceList(List oldValues, String relationId, String roleName)
/*      */     throws IllegalArgumentException
/*      */   {
/* 1082 */     List obsoleteReferenceList = new ArrayList();
/* 1083 */     for (Iterator i = oldValues.iterator(); i.hasNext();)
/*      */     {
/* 1085 */       ObjectName currentObjectName = (ObjectName)i.next();
/* 1086 */       if (removeMBeanReference(currentObjectName, relationId, roleName))
/*      */       {
/* 1088 */         obsoleteReferenceList.add(currentObjectName);
/*      */       }
/*      */     }
/* 1091 */     return obsoleteReferenceList;
/*      */   }
/*      */   
/*      */   private boolean removeMBeanReference(ObjectName objectName, String relationId, String roleName)
/*      */     throws IllegalArgumentException
/*      */   {
/* 1097 */     if (relationId == null) throw new IllegalArgumentException("Null Relation Id");
/* 1098 */     if (objectName == null) throw new IllegalArgumentException("Null ObjectName");
/* 1099 */     if (roleName == null) { throw new IllegalArgumentException("Null Role Name.");
/*      */     }
/* 1101 */     HashMap mbeanReferenceMap = (HashMap)getReferencedMBeansFromMap(objectName);
/*      */     
/*      */ 
/* 1104 */     if (mbeanReferenceMap == null) { return true;
/*      */     }
/* 1106 */     ArrayList roleNames = (ArrayList)mbeanReferenceMap.get(relationId);
/*      */     
/*      */ 
/* 1109 */     if (roleNames != null)
/*      */     {
/*      */ 
/* 1112 */       if (roleNames.indexOf(roleName) != -1) { roleNames.remove(roleNames.indexOf(roleName));
/*      */       }
/* 1114 */       if (roleNames.isEmpty()) mbeanReferenceMap.remove(relationId);
/*      */     }
/* 1116 */     if (mbeanReferenceMap.isEmpty())
/*      */     {
/*      */ 
/* 1119 */       removeObjectName(objectName);
/* 1120 */       return true;
/*      */     }
/* 1122 */     return false;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private Map getReferencedMBeansFromMap(ObjectName objectName)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 21	javax/management/relation/RelationService:m_referencedMBeanObjectNameToRelationIds	Ljava/util/Map;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 21	javax/management/relation/RelationService:m_referencedMBeanObjectNameToRelationIds	Ljava/util/Map;
/*      */     //   11: aload_1
/*      */     //   12: invokeinterface 46 2 0
/*      */     //   17: checkcast 14	java/util/HashMap
/*      */     //   20: aload_2
/*      */     //   21: monitorexit
/*      */     //   22: areturn
/*      */     //   23: astore_3
/*      */     //   24: aload_2
/*      */     //   25: monitorexit
/*      */     //   26: aload_3
/*      */     //   27: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1127	-> byte code offset #0
/*      */     //   Java source line #1129	-> byte code offset #7
/*      */     //   Java source line #1130	-> byte code offset #23
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	28	0	this	RelationService
/*      */     //   0	28	1	objectName	ObjectName
/*      */     //   5	20	2	Ljava/lang/Object;	Object
/*      */     //   23	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	22	23	finally
/*      */     //   23	26	23	finally
/*      */   }
/*      */   
/*      */   private boolean addNewMBeanReference(ObjectName objectName, String relationId, String roleName)
/*      */     throws IllegalArgumentException
/*      */   {
/* 1136 */     if (relationId == null) throw new IllegalArgumentException("Null Relation Id");
/* 1137 */     if (roleName == null) throw new IllegalArgumentException("Null Role Name");
/* 1138 */     if (objectName == null) { throw new IllegalArgumentException("Null ObjectName.");
/*      */     }
/*      */     
/*      */     HashMap mbeanReferenceMap;
/* 1142 */     synchronized (this.m_referencedMBeanObjectNameToRelationIds)
/*      */     {
/* 1144 */       mbeanReferenceMap = (HashMap)this.m_referencedMBeanObjectNameToRelationIds.get(objectName);
/*      */     }
/*      */     HashMap mbeanReferenceMap;
/* 1147 */     if (mbeanReferenceMap == null)
/*      */     {
/* 1149 */       mbeanReferenceMap = new HashMap();
/*      */     }
/* 1151 */     if (mbeanReferenceMap.get(relationId) == null)
/*      */     {
/* 1153 */       ArrayList roleNames = new ArrayList();
/* 1154 */       roleNames.add(roleName);
/*      */       
/* 1156 */       mbeanReferenceMap.put(relationId, roleNames);
/* 1157 */       addObjectNameToMBeanReference(objectName, mbeanReferenceMap);
/* 1158 */       return true;
/*      */     }
/*      */     
/* 1161 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   private void addObjectNameToMBeanReference(ObjectName objectName, HashMap mbeanReferenceMap)
/*      */   {
/* 1167 */     synchronized (this.m_referencedMBeanObjectNameToRelationIds)
/*      */     {
/* 1169 */       Map temp = (Map)this.m_referencedMBeanObjectNameToRelationIds.get(objectName);
/* 1170 */       if (temp != null)
/*      */       {
/* 1172 */         mbeanReferenceMap.putAll(temp);
/*      */       }
/* 1174 */       this.m_referencedMBeanObjectNameToRelationIds.put(objectName, mbeanReferenceMap);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeRelation(String relationId)
/*      */     throws IllegalArgumentException, RelationServiceNotRegisteredException, RelationNotFoundException
/*      */   {
/* 1196 */     isActive();
/* 1197 */     if (relationId == null) throw new IllegalArgumentException("Null Relation Id");
/* 1198 */     Logger logger = getLogger();
/* 1199 */     if (logger.isEnabledFor(10)) logger.debug("Removing a Relation from the RelationService.");
/* 1200 */     Object result = getRelationObject(relationId);
/* 1201 */     if ((result instanceof ObjectName))
/*      */     {
/*      */ 
/* 1204 */       List obsoleteReferences = new ArrayList();
/* 1205 */       obsoleteReferences.add(result);
/*      */       
/* 1207 */       updateUnregistrationListener(null, obsoleteReferences);
/*      */     }
/*      */     
/* 1210 */     sendRelationRemovalNotification(relationId, null);
/*      */     
/* 1212 */     List nonReferencedObjectNameList = getNonReferencedMBeans(relationId);
/*      */     
/* 1214 */     removeNonReferencedMBeans(nonReferencedObjectNameList);
/*      */     
/* 1216 */     removeRelationId(relationId);
/*      */     
/* 1218 */     if ((result instanceof ObjectName)) { removeRelationMBean((ObjectName)result);
/*      */     }
/* 1220 */     String relationTypeName = getRelationTypeNameFromMap(relationId);
/*      */     
/* 1222 */     removeRelationIdToRelationTypeName(relationId);
/*      */     
/* 1224 */     List relationIdsList = getRelationIds(relationTypeName);
/*      */     
/*      */ 
/* 1227 */     if (relationIdsList != null)
/*      */     {
/* 1229 */       relationIdsList.remove(relationId);
/* 1230 */       if (relationIdsList.isEmpty())
/*      */       {
/*      */ 
/* 1233 */         removeRelationTypeName(relationTypeName);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void removeRelationMBean(ObjectName objectName)
/*      */   {
/* 1240 */     synchronized (this.m_relationMBeanObjectNameToRelationId)
/*      */     {
/* 1242 */       this.m_relationMBeanObjectNameToRelationId.remove(objectName);
/*      */     }
/*      */   }
/*      */   
/*      */   private void removeNonReferencedMBeans(List nonReferencedMBeansList) {
/*      */     Iterator i;
/* 1248 */     synchronized (this.m_referencedMBeanObjectNameToRelationIds)
/*      */     {
/* 1250 */       for (i = nonReferencedMBeansList.iterator(); i.hasNext();)
/*      */       {
/* 1252 */         ObjectName currentObjectName = (ObjectName)i.next();
/* 1253 */         this.m_referencedMBeanObjectNameToRelationIds.remove(currentObjectName);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private List getNonReferencedMBeans(String relationId)
/*      */   {
/* 1260 */     List referencedMBeanList = new ArrayList();
/* 1261 */     List nonReferencedObjectNameList = new ArrayList();
/* 1262 */     Iterator i; synchronized (this.m_referencedMBeanObjectNameToRelationIds)
/*      */     {
/* 1264 */       for (i = this.m_referencedMBeanObjectNameToRelationIds.keySet().iterator(); i.hasNext();)
/*      */       {
/* 1266 */         ObjectName currentObjectName = (ObjectName)i.next();
/* 1267 */         HashMap relationIdMap = (HashMap)this.m_referencedMBeanObjectNameToRelationIds.get(currentObjectName);
/* 1268 */         if (relationIdMap.containsKey(relationId))
/*      */         {
/* 1270 */           relationIdMap.remove(relationId);
/* 1271 */           referencedMBeanList.add(currentObjectName);
/*      */         }
/* 1273 */         if (relationIdMap.isEmpty()) nonReferencedObjectNameList.add(currentObjectName);
/*      */       }
/*      */     }
/* 1276 */     return nonReferencedObjectNameList;
/*      */   }
/*      */   
/*      */   private void removeRelationTypeName(String relationTypeName)
/*      */   {
/* 1281 */     synchronized (this.m_relationTypeNameToRelationIds)
/*      */     {
/* 1283 */       this.m_relationTypeNameToRelationIds.remove(relationTypeName);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private String getRelationTypeNameFromMap(String relationId)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 17	javax/management/relation/RelationService:m_relationIdToRelationTypeName	Ljava/util/Map;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 17	javax/management/relation/RelationService:m_relationIdToRelationTypeName	Ljava/util/Map;
/*      */     //   11: aload_1
/*      */     //   12: invokeinterface 46 2 0
/*      */     //   17: checkcast 87	java/lang/String
/*      */     //   20: aload_2
/*      */     //   21: monitorexit
/*      */     //   22: areturn
/*      */     //   23: astore_3
/*      */     //   24: aload_2
/*      */     //   25: monitorexit
/*      */     //   26: aload_3
/*      */     //   27: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1289	-> byte code offset #0
/*      */     //   Java source line #1291	-> byte code offset #7
/*      */     //   Java source line #1292	-> byte code offset #23
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	28	0	this	RelationService
/*      */     //   0	28	1	relationId	String
/*      */     //   5	20	2	Ljava/lang/Object;	Object
/*      */     //   23	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	22	23	finally
/*      */     //   23	26	23	finally
/*      */   }
/*      */   
/*      */   private void removeRelationIdToRelationTypeName(String relationId)
/*      */   {
/* 1297 */     synchronized (this.m_relationIdToRelationTypeName)
/*      */     {
/* 1299 */       this.m_relationIdToRelationTypeName.remove(relationId);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private String getMBeanObjectName(ObjectName objectName)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 18	javax/management/relation/RelationService:m_relationMBeanObjectNameToRelationId	Ljava/util/Map;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 18	javax/management/relation/RelationService:m_relationMBeanObjectNameToRelationId	Ljava/util/Map;
/*      */     //   11: aload_1
/*      */     //   12: invokeinterface 46 2 0
/*      */     //   17: checkcast 87	java/lang/String
/*      */     //   20: aload_2
/*      */     //   21: monitorexit
/*      */     //   22: areturn
/*      */     //   23: astore_3
/*      */     //   24: aload_2
/*      */     //   25: monitorexit
/*      */     //   26: aload_3
/*      */     //   27: athrow
/*      */     // Line number table:
/*      */     //   Java source line #1305	-> byte code offset #0
/*      */     //   Java source line #1307	-> byte code offset #7
/*      */     //   Java source line #1308	-> byte code offset #23
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	28	0	this	RelationService
/*      */     //   0	28	1	objectName	ObjectName
/*      */     //   5	20	2	Ljava/lang/Object;	Object
/*      */     //   23	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	22	23	finally
/*      */     //   23	26	23	finally
/*      */   }
/*      */   
/*      */   private void removeRelationId(String relationId)
/*      */   {
/* 1313 */     synchronized (this.m_relationIdToRelationObject)
/*      */     {
/* 1315 */       this.m_relationIdToRelationObject.remove(relationId);
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateUnregistrationListener(List newReferenceList, List obsoleteReferences) throws RelationServiceNotRegisteredException
/*      */   {
/* 1321 */     if ((newReferenceList != null) && (obsoleteReferences != null))
/*      */     {
/*      */ 
/* 1324 */       if ((newReferenceList.isEmpty()) && (obsoleteReferences.isEmpty())) return;
/*      */     }
/* 1326 */     isActive();
/* 1327 */     if ((newReferenceList != null) || (obsoleteReferences != null))
/*      */     {
/* 1329 */       boolean isNewListener = false;
/* 1330 */       if (this.m_notificationFilter == null)
/*      */       {
/* 1332 */         this.m_notificationFilter = new MBeanServerNotificationFilter();
/* 1333 */         isNewListener = true;
/*      */       }
/* 1335 */       synchronized (this.m_notificationFilter)
/*      */       {
/*      */ 
/* 1338 */         if (newReferenceList != null) { updateNewReferences(newReferenceList);
/*      */         }
/*      */         
/* 1341 */         if (obsoleteReferences != null) { updateObsoleteReferences(obsoleteReferences);
/*      */         }
/* 1343 */         ObjectName mbeanServerDelegateName = null;
/*      */         try
/*      */         {
/* 1346 */           mbeanServerDelegateName = new ObjectName("JMImplementation:type=MBeanServerDelegate");
/*      */         }
/*      */         catch (MalformedObjectNameException ignored) {}
/*      */         
/*      */ 
/*      */ 
/* 1352 */         if (isNewListener)
/*      */         {
/*      */           try
/*      */           {
/* 1356 */             this.m_server.addNotificationListener(mbeanServerDelegateName, this, this.m_notificationFilter, null);
/*      */           }
/*      */           catch (InstanceNotFoundException ex)
/*      */           {
/* 1360 */             throw new RelationServiceNotRegisteredException(ex.getMessage());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateObsoleteReferences(List obsoleteReferences)
/*      */   {
/* 1369 */     for (Iterator i = obsoleteReferences.iterator(); i.hasNext();)
/*      */     {
/* 1371 */       ObjectName name = (ObjectName)i.next();
/* 1372 */       this.m_notificationFilter.disableObjectName(name);
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateNewReferences(List newReferencesList)
/*      */   {
/* 1378 */     for (Iterator i = newReferencesList.iterator(); i.hasNext();)
/*      */     {
/* 1380 */       ObjectName name = (ObjectName)i.next();
/* 1381 */       this.m_notificationFilter.enableObjectName(name);
/*      */     }
/*      */   }
/*      */   
/*      */   private Relation getRelation(String relationId)
/*      */     throws RelationNotFoundException
/*      */   {
/* 1388 */     if (relationId == null) { throw new IllegalArgumentException("Null relation id passed into getRelation.");
/*      */     }
/*      */     
/* 1391 */     if (isRelationMBean(relationId) == null)
/*      */     {
/* 1393 */       synchronized (this.m_relationIdToRelationObject)
/*      */       {
/* 1395 */         Relation relation = (Relation)this.m_relationIdToRelationObject.get(relationId);
/* 1396 */         return relation;
/*      */       }
/*      */     }
/*      */     
/* 1400 */     ObjectName relationObjectName = (ObjectName)this.m_relationIdToRelationObject.get(relationId);
/*      */     
/* 1402 */     if (relationObjectName == null)
/*      */     {
/* 1404 */       throw new RelationNotFoundException("Relation not found with ID: " + relationId);
/*      */     }
/*      */     
/* 1407 */     this.m_proxy = ((RelationSupportMBean)MBeanServerInvocationHandler.newProxyInstance(this.m_server, relationObjectName, RelationSupportMBean.class, false));
/* 1408 */     return this.m_proxy;
/*      */   }
/*      */   
/*      */   private Object getRelationObject(String relationId)
/*      */     throws IllegalArgumentException, RelationNotFoundException
/*      */   {
/* 1414 */     if (relationId == null) { throw new IllegalArgumentException("Null Relation Id");
/*      */     }
/* 1416 */     synchronized (this.m_relationIdToRelationObject)
/*      */     {
/* 1418 */       Object relationObject = this.m_relationIdToRelationObject.get(relationId);
/* 1419 */       if (relationObject == null)
/*      */       {
/*      */ 
/* 1422 */         throw new RelationNotFoundException("Null Relation");
/*      */       }
/*      */       
/* 1425 */       return relationObject;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void purgeRelations()
/*      */     throws RelationServiceNotRegisteredException
/*      */   {
/* 1452 */     isActive();
/* 1453 */     Logger logger = getLogger();
/* 1454 */     if (logger.isEnabledFor(10)) { logger.debug("purging relations");
/*      */     }
/*      */     
/* 1457 */     synchronized (this.m_deregisteredNotificationList)
/*      */     {
/*      */ 
/* 1460 */       ArrayList localDeregisteredNotificationList = (ArrayList)((ArrayList)this.m_deregisteredNotificationList).clone();
/*      */       
/* 1462 */       this.m_deregisteredNotificationList = new ArrayList();
/*      */     }
/*      */     ArrayList localDeregisteredNotificationList;
/* 1465 */     List obsoleteReferenceList = new ArrayList();
/* 1466 */     Object localMBeanToRelationId = new HashMap();
/* 1467 */     Iterator i; synchronized (this.m_referencedMBeanObjectNameToRelationIds)
/*      */     {
/* 1469 */       for (i = localDeregisteredNotificationList.iterator(); i.hasNext();)
/*      */       {
/* 1471 */         MBeanServerNotification serverNotification = (MBeanServerNotification)i.next();
/* 1472 */         ObjectName deregisteredMBeanName = serverNotification.getMBeanName();
/* 1473 */         obsoleteReferenceList.add(deregisteredMBeanName);
/*      */         
/* 1475 */         HashMap relationIdMap = (HashMap)this.m_referencedMBeanObjectNameToRelationIds.get(deregisteredMBeanName);
/* 1476 */         ((Map)localMBeanToRelationId).put(deregisteredMBeanName, relationIdMap);
/* 1477 */         this.m_referencedMBeanObjectNameToRelationIds.remove(deregisteredMBeanName);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1482 */     updateUnregistrationListener(null, obsoleteReferenceList);
/* 1483 */     for (Iterator i = localDeregisteredNotificationList.iterator(); i.hasNext();)
/*      */     {
/* 1485 */       MBeanServerNotification currentNotification = (MBeanServerNotification)i.next();
/* 1486 */       ObjectName unregisteredMBeanObjectName = currentNotification.getMBeanName();
/* 1487 */       HashMap localRelationIdMap = (HashMap)((Map)localMBeanToRelationId).get(unregisteredMBeanObjectName);
/*      */       
/* 1489 */       Set localRelationIdSet = localRelationIdMap.keySet();
/*      */       
/* 1491 */       unregisterReferences(localRelationIdSet, localRelationIdMap, unregisteredMBeanObjectName);
/*      */     }
/*      */   }
/*      */   
/*      */   private void unregisterReferences(Set relationIdSet, Map relationIdMap, ObjectName objectName)
/*      */     throws RelationServiceNotRegisteredException
/*      */   {
/* 1498 */     for (Iterator iter = relationIdSet.iterator(); iter.hasNext();)
/*      */     {
/* 1500 */       String currentRelationId = (String)iter.next();
/* 1501 */       ArrayList localRoleNamesList = (ArrayList)relationIdMap.get(currentRelationId);
/*      */       try
/*      */       {
/* 1504 */         handleReferenceUnregistration(currentRelationId, objectName, localRoleNamesList);
/*      */       }
/*      */       catch (RelationTypeNotFoundException ex)
/*      */       {
/* 1508 */         throw new RuntimeOperationsException(null, ex.getMessage());
/*      */       }
/*      */       catch (RelationNotFoundException ex)
/*      */       {
/* 1512 */         throw new RuntimeOperationsException(null, ex.getMessage());
/*      */       }
/*      */       catch (RoleNotFoundException ex)
/*      */       {
/* 1516 */         throw new RuntimeOperationsException(null, ex.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void handleReferenceUnregistration(String relationId, ObjectName unregisteredObjectName, List roleNames)
/*      */     throws IllegalArgumentException, RelationServiceNotRegisteredException, RelationNotFoundException, RoleNotFoundException, RelationTypeNotFoundException
/*      */   {
/* 1525 */     if (relationId == null) throw new IllegalArgumentException("Null relationId");
/* 1526 */     if (unregisteredObjectName == null) throw new IllegalArgumentException("Null ObjectName");
/* 1527 */     if (roleNames == null) { throw new IllegalArgumentException("Null roleName list");
/*      */     }
/* 1529 */     isActive();
/* 1530 */     String relationTypeName = getRelationTypeName(relationId);
/*      */     
/* 1532 */     boolean canDeleteRelation = false;
/* 1533 */     for (Iterator i = roleNames.iterator(); i.hasNext();)
/*      */     {
/* 1535 */       String currentRoleName = (String)i.next();
/* 1536 */       int currentRoleCardinality = getRoleCardinality(relationId, currentRoleName).intValue();
/* 1537 */       int newRoleCardinality = currentRoleCardinality - 1;
/*      */       
/*      */       try
/*      */       {
/* 1541 */         currentRoleInfo = getRoleInfo(relationTypeName, currentRoleName);
/*      */       }
/*      */       catch (RelationTypeNotFoundException ex) {
/*      */         RoleInfo currentRoleInfo;
/* 1545 */         throw new RuntimeOperationsException(null, ex.getMessage());
/*      */       }
/*      */       catch (RoleInfoNotFoundException ex)
/*      */       {
/* 1549 */         throw new RuntimeOperationsException(null, ex.getMessage());
/*      */       }
/*      */       RoleInfo currentRoleInfo;
/* 1552 */       if (!currentRoleInfo.checkMinDegree(newRoleCardinality))
/*      */       {
/* 1554 */         canDeleteRelation = true;
/*      */       }
/*      */     }
/*      */     Iterator i;
/* 1558 */     if (canDeleteRelation)
/*      */     {
/* 1560 */       removeRelation(relationId);
/*      */     }
/*      */     else
/*      */     {
/* 1564 */       for (i = roleNames.iterator(); i.hasNext();)
/*      */       {
/* 1566 */         String currentRoleName = (String)i.next();
/*      */         try
/*      */         {
/* 1569 */           Relation relation = getRelation(relationId);
/* 1570 */           relation.handleMBeanUnregistration(unregisteredObjectName, currentRoleName);
/*      */         }
/*      */         catch (InvalidRoleValueException ex)
/*      */         {
/* 1574 */           throw new RuntimeOperationsException(null, ex.getMessage());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void removeObjectName(ObjectName objectName)
/*      */   {
/* 1582 */     synchronized (this.m_referencedMBeanObjectNameToRelationIds)
/*      */     {
/* 1584 */       this.m_referencedMBeanObjectNameToRelationIds.remove(objectName);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Map findReferencingRelations(ObjectName mbeanObjectName, String relationTypeName, String roleName)
/*      */     throws IllegalArgumentException
/*      */   {
/* 1601 */     if (mbeanObjectName == null) throw new IllegalArgumentException("Cannot find references for a null ObjectName");
/* 1602 */     Logger logger = getLogger();
/* 1603 */     if (logger.isEnabledFor(10)) {
/* 1604 */       logger.debug("finding referencing relations for MBean with ObjectName: " + mbeanObjectName.getCanonicalName() + " and relationTypeName: " + relationTypeName + " and roleName: " + roleName);
/*      */     }
/* 1606 */     HashMap result = new HashMap();
/* 1607 */     HashMap relationIdMap = (HashMap)getReferencedMBeansFromMap(mbeanObjectName);
/* 1608 */     Iterator i; if (relationIdMap != null)
/*      */     {
/* 1610 */       Set allRelationIds = relationIdMap.keySet();
/*      */       List relationIdList;
/* 1612 */       List relationIdList; if (relationTypeName == null)
/*      */       {
/* 1614 */         relationIdList = new ArrayList(allRelationIds);
/*      */       }
/*      */       else
/*      */       {
/* 1618 */         relationIdList = findReferencesFromIds(allRelationIds, relationTypeName);
/*      */       }
/*      */       
/* 1621 */       for (i = relationIdList.iterator(); i.hasNext();)
/*      */       {
/* 1623 */         String currentRelationId = (String)i.next();
/* 1624 */         ArrayList currentRoleNameList = (ArrayList)relationIdMap.get(currentRelationId);
/* 1625 */         if (roleName == null)
/*      */         {
/* 1627 */           result.put(currentRelationId, currentRoleNameList.clone());
/*      */         }
/* 1629 */         else if (currentRoleNameList.contains(roleName))
/*      */         {
/* 1631 */           ArrayList roleNameList = new ArrayList();
/* 1632 */           roleNameList.add(roleName);
/* 1633 */           result.put(currentRelationId, roleNameList);
/*      */         }
/*      */       }
/*      */     }
/* 1637 */     return result;
/*      */   }
/*      */   
/*      */   private ArrayList findReferencesFromIds(Set allRelationIds, String relationTypeName)
/*      */   {
/* 1642 */     ArrayList relationIdList = new ArrayList();
/* 1643 */     for (Iterator i = allRelationIds.iterator(); i.hasNext();)
/*      */     {
/* 1645 */       String currentRelationId = (String)i.next();
/* 1646 */       String currentRelationTypeName = getRelationTypeNameFromMap(currentRelationId);
/* 1647 */       if (currentRelationTypeName.equals(relationTypeName))
/*      */       {
/* 1649 */         relationIdList.add(currentRelationId);
/*      */       }
/*      */     }
/* 1652 */     return relationIdList;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Map findAssociatedMBeans(ObjectName mbeanObjectName, String relationTypeName, String roleName)
/*      */     throws IllegalArgumentException
/*      */   {
/* 1669 */     if (mbeanObjectName == null) throw new IllegalArgumentException("mbean ObjectName cannot be null.");
/* 1670 */     Logger logger = getLogger();
/* 1671 */     if (logger.isEnabledFor(10)) {
/* 1672 */       logger.debug("finding associated relations for MBean with ObjectName: " + mbeanObjectName.getCanonicalName() + " and relationTypeName: " + relationTypeName + " and roleName: " + roleName);
/*      */     }
/* 1674 */     Map relationIdsToRoleNames = findReferencingRelations(mbeanObjectName, relationTypeName, roleName);
/* 1675 */     Map result = new HashMap();
/* 1676 */     for (Iterator i = relationIdsToRoleNames.keySet().iterator(); i.hasNext();)
/*      */     {
/* 1678 */       currentRelationId = (String)i.next();
/*      */       
/*      */       try
/*      */       {
/* 1682 */         objectNamesToRoleMap = (HashMap)getReferencedMBeans(currentRelationId);
/*      */       }
/*      */       catch (RelationNotFoundException ex) {
/*      */         HashMap objectNamesToRoleMap;
/* 1686 */         logger.warn("Relation with ID: " + currentRelationId + " not found.");
/* 1687 */         throw new RuntimeOperationsException(null, "Relation Not Found"); }
/*      */       HashMap objectNamesToRoleMap;
/* 1689 */       for (iter = objectNamesToRoleMap.keySet().iterator(); iter.hasNext();)
/*      */       {
/* 1691 */         ObjectName objectName = (ObjectName)iter.next();
/* 1692 */         if (!objectName.equals(mbeanObjectName))
/*      */         {
/* 1694 */           ArrayList currentRelationIdList = new ArrayList();
/* 1695 */           currentRelationIdList.add(currentRelationId);
/* 1696 */           result.put(objectName, currentRelationIdList);
/*      */         } } }
/*      */     String currentRelationId;
/*      */     Iterator iter;
/* 1700 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List findRelationsOfType(String relationTypeName)
/*      */     throws IllegalArgumentException, RelationTypeNotFoundException
/*      */   {
/* 1713 */     if (relationTypeName == null) throw new IllegalArgumentException("relation type name cannot be null.");
/* 1714 */     Logger logger = getLogger();
/* 1715 */     if (logger.isEnabledFor(10)) { logger.debug("finding relations matching relationTypeName: " + relationTypeName);
/*      */     }
/* 1717 */     List relationIdList = getRelationIds(relationTypeName);
/* 1718 */     List result = new ArrayList();
/* 1719 */     if (relationIdList != null)
/*      */     {
/*      */ 
/* 1722 */       result = relationIdList;
/*      */     }
/* 1724 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List getRole(String relationId, String roleName)
/*      */     throws IllegalArgumentException, RelationServiceNotRegisteredException, RelationNotFoundException, RoleNotFoundException
/*      */   {
/* 1743 */     isActive();
/* 1744 */     if (relationId == null) throw new IllegalArgumentException("RelationId cannot have a null value.");
/* 1745 */     if (roleName == null) throw new IllegalArgumentException("Role Name cannot have a null value.");
/* 1746 */     Relation relationObject = getRelation(relationId);
/* 1747 */     return relationObject.getRole(roleName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RoleResult getRoles(String relationId, String[] roleNames)
/*      */     throws IllegalArgumentException, RelationNotFoundException, RelationServiceNotRegisteredException
/*      */   {
/* 1763 */     if (relationId == null) throw new IllegalArgumentException("Illegal Argument relationId is null.");
/* 1764 */     if (roleNames == null) throw new IllegalArgumentException("Array of Roles Names should not be null");
/* 1765 */     isActive();
/* 1766 */     Relation relation = getRelation(relationId);
/* 1767 */     return relation.getRoles(roleNames);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RoleResult getAllRoles(String relationId)
/*      */     throws IllegalArgumentException, RelationNotFoundException, RelationServiceNotRegisteredException
/*      */   {
/* 1783 */     if (relationId == null) { throw new IllegalArgumentException("RelationId cannot be null");
/*      */     }
/* 1785 */     Relation relation = getRelation(relationId);
/* 1786 */     return relation.getAllRoles();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Integer getRoleCardinality(String relationId, String roleName)
/*      */     throws IllegalArgumentException, RelationNotFoundException, RoleNotFoundException
/*      */   {
/* 1802 */     if (relationId == null) throw new IllegalArgumentException("Relation Id is null.");
/* 1803 */     if (roleName == null) throw new IllegalArgumentException("Role Name is null.");
/* 1804 */     Object relationObject = getRelationObject(relationId);
/* 1805 */     if ((relationObject instanceof InternalRelation)) {
/* 1806 */       return ((InternalRelation)relationObject).getRoleCardinality(roleName);
/*      */     }
/* 1808 */     return this.m_proxy.getRoleCardinality(roleName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRole(String relationId, Role role)
/*      */     throws IllegalArgumentException, RelationServiceNotRegisteredException, RelationNotFoundException, RoleNotFoundException, InvalidRoleValueException
/*      */   {
/* 1834 */     if (relationId == null) throw new IllegalArgumentException("Illegal Null Relation Id.");
/* 1835 */     if (role == null) throw new IllegalArgumentException("Illegal Null Role.");
/* 1836 */     isActive();
/* 1837 */     Relation relation = getRelation(relationId);
/*      */     try
/*      */     {
/* 1840 */       relation.setRole(role);
/*      */     }
/*      */     catch (RelationTypeNotFoundException e)
/*      */     {
/* 1844 */       throw new RelationNotFoundException("RelationType not found error: " + e.getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RoleResult setRoles(String relationId, RoleList roleList)
/*      */     throws RelationServiceNotRegisteredException, IllegalArgumentException, RelationNotFoundException
/*      */   {
/* 1864 */     if (relationId == null) throw new IllegalArgumentException("Relation Id is null");
/* 1865 */     if (roleList == null) throw new IllegalArgumentException("RoleList is null");
/* 1866 */     isActive();
/* 1867 */     Relation relation = getRelation(relationId);
/*      */     try
/*      */     {
/* 1870 */       return relation.setRoles(roleList);
/*      */     }
/*      */     catch (RelationTypeNotFoundException ex)
/*      */     {
/* 1874 */       throw new RuntimeOperationsException(null, "Unable to find a RelationTypeName for relation ID: " + relationId);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Map getReferencedMBeans(String relationId)
/*      */     throws IllegalArgumentException, RelationNotFoundException
/*      */   {
/* 1888 */     if (relationId == null) throw new IllegalArgumentException("Null Relation Id");
/* 1889 */     Logger logger = getLogger();
/* 1890 */     if (logger.isEnabledFor(10)) logger.debug("getting MBeans referenced for ID: " + relationId);
/* 1891 */     Relation relation = getRelation(relationId);
/* 1892 */     return relation.getReferencedMBeans();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRelationTypeName(String relationId)
/*      */     throws IllegalArgumentException, RelationNotFoundException
/*      */   {
/* 1905 */     if (relationId == null) throw new IllegalArgumentException("Null Relation Id");
/* 1906 */     Logger logger = getLogger();
/* 1907 */     if (logger.isEnabledFor(10)) logger.debug("getting the relationType for ID: " + relationId);
/* 1908 */     Relation relation = getRelation(relationId);
/* 1909 */     return relation.getRelationTypeName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleNotification(Notification notification, Object handback)
/*      */   {
/* 1921 */     if (notification == null) throw new IllegalArgumentException("Null Notification");
/* 1922 */     if ((notification instanceof MBeanServerNotification))
/*      */     {
/* 1924 */       String notificationType = notification.getType();
/* 1925 */       if (notificationType.equals("JMX.mbean.unregistered"))
/*      */       {
/* 1927 */         ObjectName mbeanName = ((MBeanServerNotification)notification).getMBeanName();
/*      */         
/* 1929 */         handleUnregistration(notification, mbeanName);
/*      */         
/* 1931 */         handleMBeanRemoval(mbeanName);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void handleMBeanRemoval(ObjectName mbeanName)
/*      */   {
/* 1938 */     String relationId = getMBeanObjectName(mbeanName);
/* 1939 */     if (relationId != null)
/*      */     {
/*      */       try
/*      */       {
/*      */ 
/* 1944 */         removeRelation(relationId);
/*      */       }
/*      */       catch (Exception ex)
/*      */       {
/* 1948 */         throw new RuntimeOperationsException(null, ex.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void handleUnregistration(Notification notification, ObjectName objectName)
/*      */   {
/* 1955 */     boolean isReferenced = false;
/* 1956 */     synchronized (this.m_referencedMBeanObjectNameToRelationIds)
/*      */     {
/*      */ 
/* 1959 */       if (this.m_referencedMBeanObjectNameToRelationIds.containsKey(objectName))
/*      */       {
/*      */ 
/* 1962 */         synchronized (this.m_deregisteredNotificationList)
/*      */         {
/* 1964 */           this.m_deregisteredNotificationList.add(notification);
/*      */         }
/* 1966 */         isReferenced = true;
/*      */       }
/* 1968 */       if ((isReferenced) && (this.m_purgeFlag))
/*      */       {
/*      */         try
/*      */         {
/*      */ 
/* 1973 */           purgeRelations();
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/* 1977 */           throw new RuntimeOperationsException(null, ex.getMessage());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MBeanNotificationInfo[] getNotificationInfo()
/*      */   {
/* 1990 */     MBeanNotificationInfo[] notificationInfo = new MBeanNotificationInfo[1];
/* 1991 */     String[] notificationTypes = new String[6];
/* 1992 */     notificationTypes[0] = "jmx.relation.creation.basic";
/* 1993 */     notificationTypes[1] = "jmx.relation.creation.mbean";
/* 1994 */     notificationTypes[2] = "jmx.relation.update.basic";
/* 1995 */     notificationTypes[3] = "jmx.relation.update.mbean";
/* 1996 */     notificationTypes[4] = "jmx.relation.removal.basic";
/* 1997 */     notificationTypes[5] = "jmx.relation.removal.mbean";
/*      */     
/* 1999 */     String notificationDescription = "Sent when a relation is created, updated or deleted.";
/* 2000 */     notificationInfo[0] = new MBeanNotificationInfo(notificationTypes, "RelationNotification", notificationDescription);
/* 2001 */     return notificationInfo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectName preRegister(MBeanServer server, ObjectName name)
/*      */     throws Exception
/*      */   {
/* 2020 */     this.m_server = server;
/* 2021 */     this.m_relationServiceObjectName = (name == null ? new ObjectName(this.m_server.getDefaultDomain(), "service", "Relation") : name);
/* 2022 */     return this.m_relationServiceObjectName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void postRegister(Boolean registrationDone)
/*      */   {
/* 2034 */     Logger logger = getLogger();
/* 2035 */     boolean done = registrationDone.booleanValue();
/* 2036 */     if (!done)
/*      */     {
/* 2038 */       this.m_server = null;
/* 2039 */       logger.warn("Relation service was NOT registered");
/*      */ 
/*      */ 
/*      */     }
/* 2043 */     else if (logger.isEnabledFor(10))
/*      */     {
/* 2045 */       logger.debug("Relation service postRegistered");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void preDeregister()
/*      */     throws Exception
/*      */   {
/* 2060 */     Logger logger = getLogger();
/* 2061 */     if (logger.isEnabledFor(10))
/*      */     {
/* 2063 */       logger.debug("Relation service preDeregistered");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void postDeregister()
/*      */   {
/* 2073 */     Logger logger = getLogger();
/* 2074 */     if (logger.isEnabledFor(10))
/*      */     {
/* 2076 */       logger.debug("Relation service postDeregistered");
/*      */     }
/*      */   }
/*      */   
/*      */   static void throwRoleProblemException(int problemType, String roleName)
/*      */     throws IllegalArgumentException, RoleNotFoundException, InvalidRoleValueException
/*      */   {
/* 2083 */     switch (problemType)
/*      */     {
/*      */     case 1: 
/* 2086 */       throw new RoleNotFoundException("RoleName: " + roleName + " does not exist in the relation");
/*      */     case 2: 
/* 2088 */       throw new RoleNotFoundException("RoleName: " + roleName + " is not readable");
/*      */     case 3: 
/* 2090 */       throw new RoleNotFoundException("RoleName: " + roleName + " is not writable");
/*      */     case 4: 
/* 2092 */       throw new InvalidRoleValueException("RoleName: " + roleName + " has references less than the expected minimum.");
/*      */     
/*      */     case 5: 
/* 2095 */       throw new InvalidRoleValueException("RoleName: " + roleName + " has references more than the expected maximum.");
/*      */     
/*      */     case 6: 
/* 2098 */       throw new InvalidRoleValueException("RoleName: " + roleName + " has a MBean reference to a MBean not of the expected class of references for that role.");
/*      */     
/*      */     case 7: 
/* 2101 */       throw new InvalidRoleValueException("RoleName: " + roleName + "  has a reference to null MBean or to a MBean not registered.");
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */   private Logger getLogger()
/*      */   {
/* 2108 */     return Log.getLogger(getClass().getName());
/*      */   }
/*      */   
/*      */   final class InternalRelation
/*      */     extends RelationSupport
/*      */   {
/*      */     InternalRelation(String relationId, ObjectName relationServiceObjectName, String relationTypeName, RoleList roleList)
/*      */       throws InvalidRoleValueException, IllegalArgumentException
/*      */     {
/* 2117 */       super(relationServiceObjectName, relationTypeName, roleList);
/*      */     }
/*      */     
/*      */ 
/*      */     int getReadingProblemType(Role role, String roleName, String relationTypeName)
/*      */     {
/* 2123 */       if (roleName == null) throw new IllegalArgumentException("Null RoleName");
/* 2124 */       if (role == null) {
/* 2125 */         return 1;
/*      */       }
/*      */       
/*      */       try
/*      */       {
/* 2130 */         return RelationService.this.checkRoleReading(roleName, relationTypeName).intValue();
/*      */       }
/*      */       catch (RelationTypeNotFoundException ex)
/*      */       {
/* 2134 */         throw new RuntimeOperationsException(null, ex.getMessage());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     int getRoleWritingValue(Role role, String relationTypeName, Boolean toBeInitialized)
/*      */       throws RelationTypeNotFoundException
/*      */     {
/*      */       try
/*      */       {
/* 2144 */         return RelationService.this.checkRoleWriting(role, relationTypeName, toBeInitialized).intValue();
/*      */       }
/*      */       catch (RelationTypeNotFoundException ex)
/*      */       {
/* 2148 */         throw new RuntimeOperationsException(null, ex.getMessage());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     void sendUpdateRoleNotification(String relationId, Role role, List oldRoleValue)
/*      */       throws RelationServiceNotRegisteredException, RelationNotFoundException
/*      */     {
/* 2156 */       if (relationId == null) throw new IllegalArgumentException("Null RelationId passed into sendUpdateRoleNotification");
/* 2157 */       if (role == null) throw new IllegalArgumentException("Null role passed into sendUpdateRoleNotification");
/* 2158 */       if (oldRoleValue == null) throw new IllegalArgumentException("Null list of role Values passed into sendUpdateRoleNotification");
/* 2159 */       RelationService.this.sendRoleUpdateNotification(relationId, role, oldRoleValue);
/*      */     }
/*      */     
/*      */     void updateRelationServiceMap(String relationId, Role role, List oldRoleValue)
/*      */       throws IllegalArgumentException, RelationServiceNotRegisteredException, RelationNotFoundException
/*      */     {
/* 2165 */       if (relationId == null) throw new IllegalArgumentException("Null RelationId passed into updateRelationServiceMap");
/* 2166 */       if (role == null) throw new IllegalArgumentException("Null role passed into updateRelationServiceMap");
/* 2167 */       if (oldRoleValue == null) throw new IllegalArgumentException("Null list of role Values passed into updateRelationServiceMap");
/* 2168 */       RelationService.this.updateRoleMap(relationId, role, oldRoleValue);
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RelationService.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */