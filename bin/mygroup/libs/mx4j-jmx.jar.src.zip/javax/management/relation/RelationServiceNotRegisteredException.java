/*    */ package javax.management.relation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelationServiceNotRegisteredException
/*    */   extends RelationException
/*    */ {
/*    */   private static final long serialVersionUID = 8454744887157122910L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RelationServiceNotRegisteredException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RelationServiceNotRegisteredException(String message)
/*    */   {
/* 24 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RelationServiceNotRegisteredException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */