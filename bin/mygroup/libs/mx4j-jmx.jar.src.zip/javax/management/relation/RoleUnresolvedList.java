/*    */ package javax.management.relation;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleUnresolvedList
/*    */   extends ArrayList
/*    */ {
/*    */   private static final long serialVersionUID = 4054902803091433324L;
/*    */   
/*    */   public RoleUnresolvedList() {}
/*    */   
/*    */   public RoleUnresolvedList(int initialCapacity)
/*    */   {
/* 27 */     super(initialCapacity);
/*    */   }
/*    */   
/*    */   public RoleUnresolvedList(List list)
/*    */     throws IllegalArgumentException
/*    */   {
/* 33 */     if (list == null)
/*    */     {
/* 35 */       throw new IllegalArgumentException("List cannot be null");
/*    */     }
/* 37 */     for (Iterator i = list.iterator(); i.hasNext();)
/*    */     {
/* 39 */       Object currentIteration = i.next();
/* 40 */       if (!(currentIteration instanceof RoleUnresolved))
/*    */       {
/* 42 */         throw new IllegalArgumentException("All elements in the list must be an instance of RoleUnresolved");
/*    */       }
/* 44 */       add((RoleUnresolved)currentIteration);
/*    */     }
/*    */   }
/*    */   
/*    */   public void add(RoleUnresolved roleUnresolved) throws IllegalArgumentException
/*    */   {
/* 50 */     if (roleUnresolved == null)
/*    */     {
/* 52 */       throw new IllegalArgumentException("RoleUnresolved cannot be null");
/*    */     }
/* 54 */     super.add(roleUnresolved);
/*    */   }
/*    */   
/*    */   public void add(int index, RoleUnresolved roleUnresolved) throws IllegalArgumentException, IndexOutOfBoundsException
/*    */   {
/* 59 */     if (roleUnresolved == null)
/*    */     {
/* 61 */       throw new IllegalArgumentException("RoleUnresolved cannot be null");
/*    */     }
/* 63 */     super.add(index, roleUnresolved);
/*    */   }
/*    */   
/*    */   public void set(int index, RoleUnresolved roleUnresolved) throws IllegalArgumentException, IndexOutOfBoundsException
/*    */   {
/* 68 */     if (roleUnresolved == null)
/*    */     {
/* 70 */       throw new IllegalArgumentException("RoleUnresolved cannot be null");
/*    */     }
/* 72 */     super.set(index, roleUnresolved);
/*    */   }
/*    */   
/*    */   public boolean addAll(RoleUnresolvedList roleUnresolvedList) throws IndexOutOfBoundsException
/*    */   {
/* 77 */     if (roleUnresolvedList == null) return true;
/* 78 */     return super.addAll(roleUnresolvedList);
/*    */   }
/*    */   
/*    */   public boolean addAll(int index, RoleUnresolvedList roleUnresolvedList) throws IllegalArgumentException, IndexOutOfBoundsException
/*    */   {
/* 83 */     if (roleUnresolvedList == null) return true;
/* 84 */     return super.addAll(index, roleUnresolvedList);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RoleUnresolvedList.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */