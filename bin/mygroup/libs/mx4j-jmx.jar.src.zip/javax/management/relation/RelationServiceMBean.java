package javax.management.relation;

import java.util.List;
import java.util.Map;
import javax.management.InstanceNotFoundException;
import javax.management.ObjectName;

public abstract interface RelationServiceMBean
{
  public abstract void isActive()
    throws RelationServiceNotRegisteredException;
  
  public abstract boolean getPurgeFlag();
  
  public abstract void setPurgeFlag(boolean paramBoolean);
  
  public abstract void createRelationType(String paramString, RoleInfo[] paramArrayOfRoleInfo)
    throws IllegalArgumentException, InvalidRelationTypeException;
  
  public abstract void addRelationType(RelationType paramRelationType)
    throws IllegalArgumentException, InvalidRelationTypeException;
  
  public abstract List getAllRelationTypeNames();
  
  public abstract List getRoleInfos(String paramString)
    throws IllegalArgumentException, RelationTypeNotFoundException;
  
  public abstract RoleInfo getRoleInfo(String paramString1, String paramString2)
    throws IllegalArgumentException, RelationTypeNotFoundException, RoleInfoNotFoundException;
  
  public abstract void removeRelationType(String paramString)
    throws IllegalArgumentException, RelationServiceNotRegisteredException, RelationTypeNotFoundException;
  
  public abstract void createRelation(String paramString1, String paramString2, RoleList paramRoleList)
    throws IllegalArgumentException, RelationServiceNotRegisteredException, RoleNotFoundException, InvalidRelationIdException, RelationTypeNotFoundException, InvalidRoleValueException;
  
  public abstract void addRelation(ObjectName paramObjectName)
    throws IllegalArgumentException, RelationServiceNotRegisteredException, NoSuchMethodException, InvalidRelationIdException, InstanceNotFoundException, InvalidRelationServiceException, RelationTypeNotFoundException, RoleNotFoundException, InvalidRoleValueException;
  
  public abstract ObjectName isRelationMBean(String paramString)
    throws IllegalArgumentException, RelationNotFoundException;
  
  public abstract String isRelation(ObjectName paramObjectName)
    throws IllegalArgumentException;
  
  public abstract Boolean hasRelation(String paramString)
    throws IllegalArgumentException;
  
  public abstract List getAllRelationIds();
  
  public abstract Integer checkRoleReading(String paramString1, String paramString2)
    throws IllegalArgumentException, RelationTypeNotFoundException;
  
  public abstract Integer checkRoleWriting(Role paramRole, String paramString, Boolean paramBoolean)
    throws IllegalArgumentException, RelationTypeNotFoundException;
  
  public abstract void sendRelationCreationNotification(String paramString)
    throws IllegalArgumentException, RelationNotFoundException;
  
  public abstract void sendRoleUpdateNotification(String paramString, Role paramRole, List paramList)
    throws IllegalArgumentException, RelationNotFoundException;
  
  public abstract void sendRelationRemovalNotification(String paramString, List paramList)
    throws IllegalArgumentException, RelationNotFoundException;
  
  public abstract void updateRoleMap(String paramString, Role paramRole, List paramList)
    throws IllegalArgumentException, RelationServiceNotRegisteredException, RelationNotFoundException;
  
  public abstract void removeRelation(String paramString)
    throws IllegalArgumentException, RelationServiceNotRegisteredException, RelationNotFoundException;
  
  public abstract void purgeRelations()
    throws RelationServiceNotRegisteredException;
  
  public abstract Map findReferencingRelations(ObjectName paramObjectName, String paramString1, String paramString2)
    throws IllegalArgumentException;
  
  public abstract Map findAssociatedMBeans(ObjectName paramObjectName, String paramString1, String paramString2)
    throws IllegalArgumentException;
  
  public abstract List findRelationsOfType(String paramString)
    throws IllegalArgumentException, RelationTypeNotFoundException;
  
  public abstract List getRole(String paramString1, String paramString2)
    throws IllegalArgumentException, RelationServiceNotRegisteredException, RelationNotFoundException, RoleNotFoundException;
  
  public abstract RoleResult getRoles(String paramString, String[] paramArrayOfString)
    throws IllegalArgumentException, RelationNotFoundException, RelationServiceNotRegisteredException;
  
  public abstract RoleResult getAllRoles(String paramString)
    throws IllegalArgumentException, RelationNotFoundException, RelationServiceNotRegisteredException;
  
  public abstract Integer getRoleCardinality(String paramString1, String paramString2)
    throws IllegalArgumentException, RelationNotFoundException, RoleNotFoundException;
  
  public abstract void setRole(String paramString, Role paramRole)
    throws IllegalArgumentException, RelationServiceNotRegisteredException, RelationNotFoundException, RoleNotFoundException, InvalidRoleValueException, RelationTypeNotFoundException;
  
  public abstract RoleResult setRoles(String paramString, RoleList paramRoleList)
    throws RelationServiceNotRegisteredException, IllegalArgumentException, RelationNotFoundException;
  
  public abstract Map getReferencedMBeans(String paramString)
    throws IllegalArgumentException, RelationNotFoundException;
  
  public abstract String getRelationTypeName(String paramString)
    throws IllegalArgumentException, RelationNotFoundException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RelationServiceMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */