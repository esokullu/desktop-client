/*     */ package javax.management.relation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RelationTypeSupport
/*     */   implements RelationType
/*     */ {
/*     */   private static final long serialVersionUID = 4611072955724144607L;
/*     */   private String typeName;
/*  24 */   private Map roleName2InfoMap = new HashMap();
/*     */   private boolean isInRelationService;
/*     */   
/*     */   public RelationTypeSupport(String relationTypeName, RoleInfo[] roleInfo)
/*     */     throws IllegalArgumentException, InvalidRelationTypeException
/*     */   {
/*  30 */     if ((relationTypeName == null) || (roleInfo == null)) throw new IllegalArgumentException("Illegal Null Value");
/*  31 */     this.typeName = relationTypeName;
/*     */     
/*  33 */     checkRoleInfos(roleInfo);
/*     */     
/*  35 */     addRoleInfos(roleInfo);
/*     */   }
/*     */   
/*     */   protected RelationTypeSupport(String relationTypeName)
/*     */   {
/*  40 */     if (relationTypeName == null) throw new IllegalArgumentException("Null RelationType Name");
/*  41 */     this.typeName = relationTypeName;
/*     */   }
/*     */   
/*     */   private void addRoleInfos(RoleInfo[] roleInfos) throws IllegalArgumentException
/*     */   {
/*  46 */     if (roleInfos == null) throw new IllegalArgumentException("Null RoleInfo[]");
/*  47 */     synchronized (this.roleName2InfoMap)
/*     */     {
/*  49 */       for (int i = 0; i < roleInfos.length; i++)
/*     */       {
/*  51 */         RoleInfo currentRoleInfo = roleInfos[i];
/*  52 */         addRoleNameToRoleInfo(currentRoleInfo.getName(), currentRoleInfo);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String getRelationTypeName()
/*     */   {
/*  59 */     return this.typeName;
/*     */   }
/*     */   
/*     */   public RoleInfo getRoleInfo(String roleInfoName) throws RoleInfoNotFoundException, IllegalArgumentException
/*     */   {
/*  64 */     if (roleInfoName == null) throw new IllegalArgumentException("roleInfo Name cannot have a null value");
/*  65 */     RoleInfo roleInfo = (RoleInfo)this.roleName2InfoMap.get(roleInfoName);
/*  66 */     if (roleInfo == null)
/*     */     {
/*  68 */       throw new RoleInfoNotFoundException("No role info for role named " + roleInfoName);
/*     */     }
/*  70 */     return roleInfo;
/*     */   }
/*     */   
/*     */   public List getRoleInfos()
/*     */   {
/*  75 */     return new ArrayList(this.roleName2InfoMap.values());
/*     */   }
/*     */   
/*     */   protected void addRoleInfo(RoleInfo roleInfo) throws IllegalArgumentException, InvalidRelationTypeException
/*     */   {
/*  80 */     if (roleInfo == null) throw new IllegalArgumentException("Cannot add a null roleInfo in the relation service");
/*  81 */     if (this.isInRelationService) throw new RuntimeOperationsException(null, "RoleInfo cannot be added as the relation type is already declared in the relation service");
/*  82 */     String roleName = roleInfo.getName();
/*     */     
/*  84 */     if (this.roleName2InfoMap.containsKey(roleName))
/*     */     {
/*  86 */       throw new InvalidRelationTypeException("Already a roleInfo declared for roleName " + roleName);
/*     */     }
/*     */     
/*     */ 
/*  90 */     addRoleNameToRoleInfo(roleName, roleInfo);
/*     */   }
/*     */   
/*     */   private void addRoleNameToRoleInfo(String roleName, RoleInfo roleInfo)
/*     */   {
/*  95 */     synchronized (this.roleName2InfoMap)
/*     */     {
/*  97 */       this.roleName2InfoMap.put(roleName, roleInfo);
/*     */     }
/*     */   }
/*     */   
/*     */   static void checkRoleInfos(RoleInfo[] roleInfo)
/*     */     throws IllegalArgumentException, InvalidRelationTypeException
/*     */   {
/* 104 */     if (roleInfo == null) throw new IllegalArgumentException("RoleInfo is null.");
/* 105 */     if (roleInfo.length == 0) throw new InvalidRelationTypeException("RoleInfo is empty");
/* 106 */     ArrayList roleNameList = new ArrayList();
/* 107 */     for (int i = 0; i < roleInfo.length; i++)
/*     */     {
/* 109 */       RoleInfo currentRoleInfo = roleInfo[i];
/* 110 */       if (currentRoleInfo == null) throw new InvalidRelationTypeException("Null roleInfo");
/* 111 */       String roleName = currentRoleInfo.getName();
/* 112 */       if (roleNameList.contains(roleName))
/*     */       {
/* 114 */         throw new InvalidRelationTypeException("Two RoleInfos provided for role " + roleName);
/*     */       }
/* 116 */       roleNameList.add(roleName);
/*     */     }
/*     */   }
/*     */   
/*     */   void setRelationServiceFlag(boolean value)
/*     */   {
/* 122 */     this.isInRelationService = value;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RelationTypeSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */