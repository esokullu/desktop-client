/*    */ package javax.management.relation;
/*    */ 
/*    */ import javax.management.JMException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelationException
/*    */   extends JMException
/*    */ {
/*    */   private static final long serialVersionUID = 5434016005679159613L;
/*    */   
/*    */   public RelationException() {}
/*    */   
/*    */   public RelationException(String message)
/*    */   {
/* 26 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RelationException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */