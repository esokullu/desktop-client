/*     */ package javax.management.relation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.management.Notification;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RelationNotification
/*     */   extends Notification
/*     */ {
/*     */   private static final long serialVersionUID = -6871117877523310399L;
/*     */   public static final String RELATION_BASIC_CREATION = "jmx.relation.creation.basic";
/*     */   public static final String RELATION_MBEAN_CREATION = "jmx.relation.creation.mbean";
/*     */   public static final String RELATION_BASIC_REMOVAL = "jmx.relation.removal.basic";
/*     */   public static final String RELATION_MBEAN_REMOVAL = "jmx.relation.removal.mbean";
/*     */   public static final String RELATION_BASIC_UPDATE = "jmx.relation.update.basic";
/*     */   public static final String RELATION_MBEAN_UPDATE = "jmx.relation.update.mbean";
/*     */   private String relationId;
/*     */   private String relationTypeName;
/*     */   private String roleName;
/*     */   private ObjectName relationObjName;
/*     */   private List unregisterMBeanList;
/*     */   private List oldRoleValue;
/*     */   private List newRoleValue;
/*     */   
/*     */   public RelationNotification(String createRemoveType, Object source, long sequenceNumber, long timestamp, String message, String relationId, String relationTypeName, ObjectName relationObjectName, List unregisteredMBeanList)
/*     */     throws IllegalArgumentException
/*     */   {
/*  44 */     super(createRemoveType, source, sequenceNumber, timestamp, message);
/*     */     
/*  46 */     checkCreateRemoveType(createRemoveType);
/*  47 */     this.relationId = relationId;
/*  48 */     this.relationTypeName = relationTypeName;
/*  49 */     this.relationObjName = relationObjectName;
/*  50 */     setUnregisterMBeanList(unregisteredMBeanList);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RelationNotification(String updateType, Object source, long sequenceNumber, long timestamp, String message, String relationId, String relationTypeName, ObjectName relationObjectName, String roleName, List newRoleValues, List oldRoleValues)
/*     */     throws IllegalArgumentException
/*     */   {
/*  60 */     super(updateType, source, sequenceNumber, timestamp, message);
/*     */     
/*  62 */     checkUpdateType(updateType);
/*  63 */     this.relationId = relationId;
/*  64 */     this.relationTypeName = relationTypeName;
/*  65 */     this.relationObjName = relationObjectName;
/*  66 */     this.roleName = roleName;
/*  67 */     setOldRoleValues(oldRoleValues);
/*  68 */     setNewRoleValues(newRoleValues);
/*     */   }
/*     */   
/*     */   private void setOldRoleValues(List list)
/*     */   {
/*  73 */     if (list != null)
/*     */     {
/*  75 */       if (this.oldRoleValue == null)
/*     */       {
/*  77 */         this.oldRoleValue = new ArrayList();
/*     */       }
/*  79 */       this.oldRoleValue.clear();
/*  80 */       this.oldRoleValue.addAll(list);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setNewRoleValues(List list)
/*     */   {
/*  86 */     if (list != null)
/*     */     {
/*  88 */       if (this.newRoleValue == null)
/*     */       {
/*  90 */         this.newRoleValue = new ArrayList();
/*     */       }
/*  92 */       this.newRoleValue.clear();
/*  93 */       this.newRoleValue.addAll(list);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setUnregisterMBeanList(List list)
/*     */   {
/*  99 */     if (list != null)
/*     */     {
/* 101 */       if (this.unregisterMBeanList == null)
/*     */       {
/* 103 */         this.unregisterMBeanList = new ArrayList();
/*     */       }
/* 105 */       this.unregisterMBeanList.clear();
/* 106 */       this.unregisterMBeanList.addAll(list);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getRelationId()
/*     */   {
/* 112 */     return this.relationId;
/*     */   }
/*     */   
/*     */   public String getRelationTypeName()
/*     */   {
/* 117 */     return this.relationTypeName;
/*     */   }
/*     */   
/*     */   public ObjectName getObjectName()
/*     */   {
/* 122 */     return this.relationObjName;
/*     */   }
/*     */   
/*     */   public List getMBeansToUnregister()
/*     */   {
/* 127 */     if (this.unregisterMBeanList != null)
/*     */     {
/*     */ 
/* 130 */       return new ArrayList(this.unregisterMBeanList);
/*     */     }
/*     */     
/*     */ 
/* 134 */     return Collections.EMPTY_LIST;
/*     */   }
/*     */   
/*     */ 
/*     */   public List getNewRoleValue()
/*     */   {
/* 140 */     if (this.newRoleValue != null)
/*     */     {
/*     */ 
/* 143 */       return new ArrayList(this.newRoleValue);
/*     */     }
/*     */     
/*     */ 
/* 147 */     return Collections.EMPTY_LIST;
/*     */   }
/*     */   
/*     */ 
/*     */   public List getOldRoleValue()
/*     */   {
/* 153 */     if (this.oldRoleValue != null)
/*     */     {
/*     */ 
/* 156 */       return new ArrayList(this.oldRoleValue);
/*     */     }
/*     */     
/*     */ 
/* 160 */     return Collections.EMPTY_LIST;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getRoleName()
/*     */   {
/* 166 */     return this.roleName;
/*     */   }
/*     */   
/*     */   private void checkCreateRemoveType(String type) throws IllegalArgumentException
/*     */   {
/* 171 */     if ((!type.equals("jmx.relation.creation.basic")) && (!type.equals("jmx.relation.creation.mbean")) && (!type.equals("jmx.relation.removal.basic")) && (!type.equals("jmx.relation.removal.mbean")))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 176 */       throw new IllegalArgumentException("Notification type is not recognized must be one of create or remove");
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkUpdateType(String type) throws IllegalArgumentException
/*     */   {
/* 182 */     if ((!type.equals("jmx.relation.update.basic")) && (!type.equals("jmx.relation.update.mbean")))
/*     */     {
/* 184 */       throw new IllegalArgumentException("Notification type is not recognized must be one of update");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RelationNotification.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */