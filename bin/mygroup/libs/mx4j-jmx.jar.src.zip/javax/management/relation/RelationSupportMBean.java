package javax.management.relation;

public abstract interface RelationSupportMBean
  extends Relation
{
  public abstract Boolean isInRelationService();
  
  public abstract void setRelationServiceManagementFlag(Boolean paramBoolean)
    throws IllegalArgumentException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RelationSupportMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */