/*    */ package javax.management.relation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleInfoNotFoundException
/*    */   extends RelationException
/*    */ {
/*    */   private static final long serialVersionUID = 4394092234999959939L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RoleInfoNotFoundException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RoleInfoNotFoundException(String message)
/*    */   {
/* 24 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RoleInfoNotFoundException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */