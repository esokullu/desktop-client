/*    */ package javax.management.relation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleNotFoundException
/*    */   extends RelationException
/*    */ {
/*    */   private static final long serialVersionUID = -2986406101364031481L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RoleNotFoundException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RoleNotFoundException(String message)
/*    */   {
/* 24 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/relation/RoleNotFoundException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */