/*    */ package javax.management.timer;
/*    */ 
/*    */ import javax.management.Notification;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ /**
/*    */  * @deprecated
/*    */  */
/*    */ public class TimerAlarmClockNotification
/*    */   extends Notification
/*    */ {
/*    */   private static final long serialVersionUID = -4841061275673620641L;
/*    */   
/*    */   /**
/*    */    * @deprecated
/*    */    */
/*    */   public TimerAlarmClockNotification(TimerAlarmClock timer)
/*    */   {
/* 30 */     super("", timer, 0L);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/timer/TimerAlarmClockNotification.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */