package javax.management.timer;

import java.util.Date;
import java.util.TimerTask;

class TimerAlarmClock
  extends TimerTask
{
  public TimerAlarmClock(Timer timer, Date nextOccurrence) {}
  
  public TimerAlarmClock(Timer timer, long timeout) {}
  
  public void run() {}
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/timer/TimerAlarmClock.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */