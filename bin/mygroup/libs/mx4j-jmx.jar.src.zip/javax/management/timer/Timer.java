/*     */ package javax.management.timer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.MBeanRegistration;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationBroadcasterSupport;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import mx4j.timer.TimeQueue;
/*     */ import mx4j.timer.TimerTask;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Timer
/*     */   extends NotificationBroadcasterSupport
/*     */   implements TimerMBean, MBeanRegistration
/*     */ {
/*     */   public static final long ONE_SECOND = 1000L;
/*     */   public static final long ONE_MINUTE = 60000L;
/*     */   public static final long ONE_HOUR = 3600000L;
/*     */   public static final long ONE_DAY = 86400000L;
/*     */   public static final long ONE_WEEK = 604800000L;
/*  40 */   private TimeQueue queue = new TimeQueue();
/*     */   private boolean isActive;
/*     */   private int notificationID;
/*  43 */   private HashMap tasks = new HashMap();
/*     */   private boolean sendPastNotification;
/*     */   private ObjectName objectName;
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/*  49 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */   
/*     */   public ObjectName preRegister(MBeanServer server, ObjectName name) throws Exception
/*     */   {
/*  54 */     Logger logger = getLogger();
/*  55 */     this.objectName = name;
/*  56 */     if (logger.isEnabledFor(0)) logger.trace("Timer service " + this.objectName + " preRegistered successfully");
/*  57 */     return name;
/*     */   }
/*     */   
/*     */   public void postRegister(Boolean registrationDone)
/*     */   {
/*  62 */     Logger logger = getLogger();
/*  63 */     boolean done = registrationDone.booleanValue();
/*  64 */     if (!done)
/*     */     {
/*  66 */       logger.warn("Timer service " + this.objectName + " was not registered");
/*     */ 
/*     */ 
/*     */     }
/*  70 */     else if (logger.isEnabledFor(0)) logger.trace("Timer service " + this.objectName + " postRegistered successfully.");
/*     */   }
/*     */   
/*     */   public void preDeregister()
/*     */     throws Exception
/*     */   {
/*  76 */     Logger logger = getLogger();
/*  77 */     stop();
/*  78 */     if (logger.isEnabledFor(0)) logger.trace("Timer service " + this.objectName + " preDeregistered successfully");
/*     */   }
/*     */   
/*     */   public void postDeregister()
/*     */   {
/*  83 */     Logger logger = getLogger();
/*  84 */     if (logger.isEnabledFor(0)) logger.trace("Timer service " + this.objectName + " postDeregistered successfully");
/*     */   }
/*     */   
/*     */   public void start()
/*     */   {
/*  89 */     if (!isActive())
/*     */     {
/*  91 */       Logger logger = getLogger();
/*  92 */       if (logger.isEnabledFor(0)) { logger.trace("Starting Timer service " + this.objectName);
/*     */       }
/*  94 */       this.queue.clear();
/*  95 */       this.queue.start();
/*     */       
/*  97 */       ArrayList tasks = updateTasks();
/*  98 */       scheduleTasks(tasks);
/*     */       
/* 100 */       this.isActive = true;
/*     */       
/* 102 */       if (logger.isEnabledFor(0)) logger.trace("Timer service " + this.objectName + " started successfully");
/*     */     }
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/* 108 */     if (isActive())
/*     */     {
/* 110 */       Logger logger = getLogger();
/* 111 */       if (logger.isEnabledFor(0)) { logger.trace("Stopping Timer service " + this.objectName);
/*     */       }
/* 113 */       this.queue.stop();
/* 114 */       this.queue.clear();
/*     */       
/* 116 */       this.isActive = false;
/*     */       
/* 118 */       if (logger.isEnabledFor(0)) logger.trace("Timer service " + this.objectName + " stopped successfully");
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isActive()
/*     */   {
/* 124 */     return this.isActive;
/*     */   }
/*     */   
/*     */   public Integer addNotification(String type, String message, Object userData, Date date) throws IllegalArgumentException
/*     */   {
/* 129 */     return addNotification(type, message, userData, date, 0L, 0L, false);
/*     */   }
/*     */   
/*     */   public Integer addNotification(String type, String message, Object userData, Date date, long period) throws IllegalArgumentException
/*     */   {
/* 134 */     return addNotification(type, message, userData, date, period, 0L, false);
/*     */   }
/*     */   
/*     */   public Integer addNotification(String type, String message, Object userData, Date date, long period, long occurrences) throws IllegalArgumentException
/*     */   {
/* 139 */     return addNotification(type, message, userData, date, period, occurrences, false);
/*     */   }
/*     */   
/*     */   public Integer addNotification(String type, String message, Object userData, Date date, long period, long occurrences, boolean fixedRate) throws IllegalArgumentException
/*     */   {
/* 144 */     if (date == null) throw new IllegalArgumentException("Notification date cannot be null");
/* 145 */     if (period < 0L) throw new IllegalArgumentException("Period cannot be negative");
/* 146 */     if (occurrences < 0L) { throw new IllegalArgumentException("Occurrences cannot be negative");
/*     */     }
/* 148 */     long now = System.currentTimeMillis();
/*     */     
/* 150 */     if (isActive())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 155 */       if (date.getTime() < now) { date = new Date(now);
/*     */       }
/*     */       
/* 158 */       if ((period > 0L) && (occurrences > 0L))
/*     */       {
/* 160 */         long lastTime = date.getTime() + (occurrences - 1L) * period;
/* 161 */         if (lastTime < now) { throw new IllegalArgumentException("Last date for periodic notification is before current date");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 166 */     Integer id = addNotificationImpl(type, message, userData, date, period, occurrences, fixedRate);
/*     */     
/*     */ 
/* 169 */     if (isActive())
/*     */     {
/* 171 */       TimerTask task = getTask(id);
/* 172 */       updateTask(task, now);
/* 173 */       if (!task.isFinished())
/*     */       {
/* 175 */         this.queue.schedule(task);
/*     */       }
/*     */     }
/* 178 */     return id;
/*     */   }
/*     */   
/*     */   private Integer addNotificationImpl(String type, String message, Object userData, Date date, long period, long occurrences, boolean fixedRate)
/*     */   {
/* 183 */     Logger logger = getLogger();
/*     */     
/* 185 */     Integer id = createNotificationID();
/*     */     
/* 187 */     TimerNotification notification = new TimerNotification(type, this, 0L, System.currentTimeMillis(), message, id);
/* 188 */     notification.setUserData(userData);
/* 189 */     if (logger.isEnabledFor(10)) { logger.debug("Adding timer notification: " + notification + " on Timer service " + this.objectName);
/*     */     }
/* 191 */     TimerTask task = createTimerTask(notification, date, period, occurrences, fixedRate);
/*     */     
/* 193 */     synchronized (this)
/*     */     {
/* 195 */       this.tasks.put(id, task);
/*     */     }
/*     */     
/* 198 */     return id;
/*     */   }
/*     */   
/*     */   private TimerTask createTimerTask(TimerNotification notification, Date date, long period, long occurrences, boolean fixedRate)
/*     */   {
/* 203 */     new TimerTask(notification, date, period, occurrences, fixedRate)
/*     */     {
/*     */ 
/*     */       public void run()
/*     */       {
/* 208 */         Timer.this.sendNotification(getNotification());
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private ArrayList updateTasks()
/*     */   {
/* 215 */     ArrayList list = new ArrayList();
/* 216 */     boolean sendPast = getSendPastNotifications();
/* 217 */     long now = System.currentTimeMillis();
/* 218 */     synchronized (this)
/*     */     {
/* 220 */       for (Iterator i = this.tasks.entrySet().iterator(); i.hasNext();)
/*     */       {
/* 222 */         Map.Entry entry = getNextNonFinishedTaskEntry(i);
/* 223 */         if (entry == null)
/*     */           break;
/* 225 */         TimerTask task = (TimerTask)entry.getValue();
/*     */         
/* 227 */         if (!sendPast)
/*     */         {
/* 229 */           updateTask(task, now);
/* 230 */           if (task.isFinished()) {}
/*     */         } else {
/* 232 */           list.add(task);
/*     */         } }
/* 234 */       return list;
/*     */     }
/*     */   }
/*     */   
/*     */   private void updateTask(TimerTask task, long now)
/*     */   {
/* 240 */     long time = task.getNextExecutionTime();
/*     */     
/* 242 */     while ((time < now) && (!task.isFinished()))
/*     */     {
/* 244 */       if (task.isPeriodic())
/*     */       {
/* 246 */         task.setNextExecutionTime(time + task.getPeriod());
/* 247 */         time = task.getNextExecutionTime();
/*     */       }
/*     */       else
/*     */       {
/* 251 */         task.setFinished(true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void scheduleTasks(ArrayList tasks)
/*     */   {
/* 258 */     synchronized (this)
/*     */     {
/* 260 */       for (int i = 0; i < tasks.size(); i++)
/*     */       {
/* 262 */         TimerTask task = (TimerTask)tasks.get(i);
/* 263 */         this.queue.schedule(task);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeNotification(Integer id) throws InstanceNotFoundException
/*     */   {
/* 270 */     Logger logger = getLogger();
/*     */     
/* 272 */     synchronized (this)
/*     */     {
/* 274 */       TimerTask t = getTask(id);
/* 275 */       if (t == null) throw new InstanceNotFoundException("Cannot find notification to remove with id: " + id);
/* 276 */       this.queue.unschedule(t);
/* 277 */       this.tasks.remove(id);
/* 278 */       if (logger.isEnabledFor(10)) logger.debug("Notification " + t.getNotification() + " removed successfully from Timer service " + this.objectName);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeNotifications(String type) throws InstanceNotFoundException
/*     */   {
/* 284 */     Logger logger = getLogger();
/*     */     
/* 286 */     boolean found = false;
/* 287 */     Iterator i; synchronized (this)
/*     */     {
/* 289 */       for (i = this.tasks.entrySet().iterator(); i.hasNext();)
/*     */       {
/* 291 */         Map.Entry entry = getNextNonFinishedTaskEntry(i);
/* 292 */         if (entry == null)
/*     */           break;
/* 294 */         TimerTask t = (TimerTask)entry.getValue();
/* 295 */         TimerNotification n = t.getNotification();
/* 296 */         if (n.getType().equals(type))
/*     */         {
/* 298 */           this.queue.unschedule(t);
/* 299 */           i.remove();
/* 300 */           if (logger.isEnabledFor(10)) logger.debug("Notification " + n + " removed successfully from Timer service " + this.objectName);
/* 301 */           found = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 306 */     if (!found) throw new InstanceNotFoundException("Cannot find timer notification to remove with type: " + type + " from Timer service " + this.objectName);
/*     */   }
/*     */   
/*     */   public void removeAllNotifications()
/*     */   {
/* 311 */     synchronized (this)
/*     */     {
/* 313 */       this.queue.clear();
/* 314 */       this.tasks.clear();
/* 315 */       this.notificationID = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public Vector getAllNotificationIDs()
/*     */   {
/* 321 */     Vector vector = new Vector();
/* 322 */     Iterator i; synchronized (this)
/*     */     {
/* 324 */       for (i = this.tasks.entrySet().iterator(); i.hasNext();)
/*     */       {
/* 326 */         Map.Entry entry = getNextNonFinishedTaskEntry(i);
/* 327 */         if (entry == null) break;
/* 328 */         vector.add(entry.getKey());
/*     */       }
/*     */     }
/* 331 */     return vector;
/*     */   }
/*     */   
/*     */   public Vector getNotificationIDs(String type)
/*     */   {
/* 336 */     Vector vector = new Vector();
/* 337 */     Iterator i; synchronized (this)
/*     */     {
/* 339 */       for (i = this.tasks.entrySet().iterator(); i.hasNext();)
/*     */       {
/* 341 */         Map.Entry entry = getNextNonFinishedTaskEntry(i);
/* 342 */         if (entry == null) break;
/* 343 */         TimerTask t = (TimerTask)entry.getValue();
/* 344 */         TimerNotification n = t.getNotification();
/* 345 */         if (n.getType().equals(type))
/*     */         {
/* 347 */           vector.add(entry.getKey());
/*     */         }
/*     */       }
/*     */     }
/* 351 */     return vector;
/*     */   }
/*     */   
/*     */   public boolean getSendPastNotifications()
/*     */   {
/* 356 */     return this.sendPastNotification;
/*     */   }
/*     */   
/*     */   public void setSendPastNotifications(boolean value)
/*     */   {
/* 361 */     this.sendPastNotification = value;
/*     */   }
/*     */   
/*     */   public int getNbNotifications()
/*     */   {
/* 366 */     int count = 0;
/* 367 */     synchronized (this)
/*     */     {
/* 369 */       for (Iterator i = this.tasks.entrySet().iterator(); i.hasNext();)
/*     */       {
/* 371 */         Map.Entry entry = getNextNonFinishedTaskEntry(i);
/* 372 */         if (entry == null) break;
/* 373 */         count++;
/*     */       }
/* 375 */       return count;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isEmpty()
/*     */   {
/* 381 */     synchronized (this)
/*     */     {
/* 383 */       return getNbNotifications() == 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public String getNotificationType(Integer id)
/*     */   {
/* 389 */     synchronized (this)
/*     */     {
/* 391 */       TimerTask t = getTask(id);
/* 392 */       return t == null ? null : t.getNotification().getType();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getNotificationMessage(Integer id)
/*     */   {
/* 398 */     synchronized (this)
/*     */     {
/* 400 */       TimerTask t = getTask(id);
/* 401 */       return t == null ? null : t.getNotification().getMessage();
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getNotificationUserData(Integer id)
/*     */   {
/* 407 */     synchronized (this)
/*     */     {
/* 409 */       TimerTask t = getTask(id);
/* 410 */       return t == null ? null : t.getNotification().getUserData();
/*     */     }
/*     */   }
/*     */   
/*     */   public Date getDate(Integer id)
/*     */   {
/* 416 */     synchronized (this)
/*     */     {
/* 418 */       TimerTask t = getTask(id);
/* 419 */       return t == null ? null : new Date(t.getDate());
/*     */     }
/*     */   }
/*     */   
/*     */   public Long getPeriod(Integer id)
/*     */   {
/* 425 */     synchronized (this)
/*     */     {
/* 427 */       TimerTask t = getTask(id);
/* 428 */       return t == null ? null : new Long(t.getPeriod());
/*     */     }
/*     */   }
/*     */   
/*     */   public Long getNbOccurences(Integer id)
/*     */   {
/* 434 */     synchronized (this)
/*     */     {
/* 436 */       TimerTask t = getTask(id);
/* 437 */       return t == null ? null : new Long(t.getOccurrences());
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private Integer createNotificationID()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: dup
/*     */     //   2: astore_1
/*     */     //   3: monitorenter
/*     */     //   4: new 111	java/lang/Integer
/*     */     //   7: dup
/*     */     //   8: aload_0
/*     */     //   9: dup
/*     */     //   10: getfield 98	javax/management/timer/Timer:notificationID	I
/*     */     //   13: iconst_1
/*     */     //   14: iadd
/*     */     //   15: dup_x1
/*     */     //   16: putfield 98	javax/management/timer/Timer:notificationID	I
/*     */     //   19: invokespecial 112	java/lang/Integer:<init>	(I)V
/*     */     //   22: aload_1
/*     */     //   23: monitorexit
/*     */     //   24: areturn
/*     */     //   25: astore_2
/*     */     //   26: aload_1
/*     */     //   27: monitorexit
/*     */     //   28: aload_2
/*     */     //   29: athrow
/*     */     // Line number table:
/*     */     //   Java source line #443	-> byte code offset #0
/*     */     //   Java source line #445	-> byte code offset #4
/*     */     //   Java source line #446	-> byte code offset #25
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	30	0	this	Timer
/*     */     //   2	25	1	Ljava/lang/Object;	Object
/*     */     //   25	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	24	25	finally
/*     */     //   25	28	25	finally
/*     */   }
/*     */   
/*     */   private TimerTask getTask(Integer id)
/*     */   {
/* 451 */     Logger logger = getLogger();
/*     */     
/* 453 */     synchronized (this)
/*     */     {
/* 455 */       TimerTask t = (TimerTask)this.tasks.get(id);
/*     */       
/* 457 */       if (logger.isEnabledFor(10)) { logger.debug("Retrieving task with id " + id + ": " + t);
/*     */       }
/* 459 */       if ((t != null) && (t.isFinished()))
/*     */       {
/* 461 */         if (logger.isEnabledFor(10)) { logger.debug("Task with id " + id + " is expired, removing it");
/*     */         }
/* 463 */         this.tasks.remove(id);
/* 464 */         t = null;
/*     */       }
/* 466 */       return t;
/*     */     }
/*     */   }
/*     */   
/*     */   private Map.Entry getNextNonFinishedTaskEntry(Iterator i)
/*     */   {
/* 472 */     Logger logger = getLogger();
/*     */     
/* 474 */     synchronized (this)
/*     */     {
/* 476 */       if (i.hasNext())
/*     */       {
/* 478 */         Map.Entry entry = (Map.Entry)i.next();
/* 479 */         TimerTask t = (TimerTask)entry.getValue();
/* 480 */         if (t.isFinished())
/*     */         {
/* 482 */           if (logger.isEnabledFor(10)) logger.debug("Found an expired notification, removing it: " + t);
/* 483 */           i.remove();
/* 484 */           return getNextNonFinishedTaskEntry(i);
/*     */         }
/* 486 */         return entry;
/*     */       }
/* 488 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void sendNotification(Notification n)
/*     */   {
/* 494 */     Logger logger = getLogger();
/* 495 */     if (logger.isEnabledFor(0)) logger.trace("Start sending notifications from Timer service " + this.objectName);
/* 496 */     super.sendNotification(n);
/* 497 */     if (logger.isEnabledFor(0)) logger.trace("Finished sending notifications from Timer service " + this.objectName);
/*     */   }
/*     */   
/*     */   public Boolean getFixedRate(Integer id)
/*     */   {
/* 502 */     return new Boolean(getTask(id).getFixedRate());
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/timer/Timer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */