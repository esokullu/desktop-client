/*    */ package javax.management.timer;
/*    */ 
/*    */ import javax.management.Notification;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimerNotification
/*    */   extends Notification
/*    */ {
/*    */   private static final long serialVersionUID = 1798492029603825750L;
/*    */   private Integer notificationID;
/*    */   
/*    */   public TimerNotification(String type, Object source, long sequenceNumber, long timeStamp, String message, Integer id)
/*    */   {
/* 26 */     super(type, source, sequenceNumber, timeStamp, message);
/* 27 */     this.notificationID = id;
/*    */   }
/*    */   
/*    */   public Integer getNotificationID()
/*    */   {
/* 32 */     return this.notificationID;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 37 */     StringBuffer b = new StringBuffer("[");
/* 38 */     b.append(super.toString());
/* 39 */     b.append(", notificationID=").append(this.notificationID);
/* 40 */     b.append("]");
/* 41 */     return b.toString();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/timer/TimerNotification.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */