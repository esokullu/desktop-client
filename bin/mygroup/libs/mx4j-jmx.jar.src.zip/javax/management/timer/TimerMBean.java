package javax.management.timer;

import java.util.Date;
import java.util.Vector;
import javax.management.InstanceNotFoundException;

public abstract interface TimerMBean
{
  public abstract Integer addNotification(String paramString1, String paramString2, Object paramObject, Date paramDate)
    throws IllegalArgumentException;
  
  public abstract Integer addNotification(String paramString1, String paramString2, Object paramObject, Date paramDate, long paramLong)
    throws IllegalArgumentException;
  
  public abstract Integer addNotification(String paramString1, String paramString2, Object paramObject, Date paramDate, long paramLong1, long paramLong2)
    throws IllegalArgumentException;
  
  public abstract Integer addNotification(String paramString1, String paramString2, Object paramObject, Date paramDate, long paramLong1, long paramLong2, boolean paramBoolean)
    throws IllegalArgumentException;
  
  public abstract Vector getAllNotificationIDs();
  
  public abstract Date getDate(Integer paramInteger);
  
  public abstract Boolean getFixedRate(Integer paramInteger);
  
  public abstract int getNbNotifications();
  
  public abstract Long getNbOccurences(Integer paramInteger);
  
  public abstract Vector getNotificationIDs(String paramString);
  
  public abstract String getNotificationMessage(Integer paramInteger);
  
  public abstract String getNotificationType(Integer paramInteger);
  
  public abstract Object getNotificationUserData(Integer paramInteger);
  
  public abstract Long getPeriod(Integer paramInteger);
  
  public abstract boolean getSendPastNotifications();
  
  public abstract boolean isActive();
  
  public abstract boolean isEmpty();
  
  public abstract void removeAllNotifications();
  
  public abstract void removeNotifications(String paramString)
    throws InstanceNotFoundException;
  
  public abstract void removeNotification(Integer paramInteger)
    throws InstanceNotFoundException;
  
  public abstract void setSendPastNotifications(boolean paramBoolean);
  
  public abstract void start();
  
  public abstract void stop();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/timer/TimerMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */