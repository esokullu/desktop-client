/*    */ package javax.management;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanParameterInfo
/*    */   extends MBeanFeatureInfo
/*    */   implements Cloneable, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 7432616882776782338L;
/*    */   private String type;
/*    */   
/*    */   public MBeanParameterInfo(String name, String type, String description)
/*    */   {
/* 38 */     super(name, description);
/* 39 */     this.type = type;
/*    */   }
/*    */   
/*    */   public Object clone()
/*    */   {
/*    */     try
/*    */     {
/* 46 */       return super.clone();
/*    */     }
/*    */     catch (CloneNotSupportedException ignored) {}
/*    */     
/* 50 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getType()
/*    */   {
/* 61 */     return this.type;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 66 */     int hash = super.hashCode();
/* 67 */     String t = getType();
/* 68 */     if (t != null) hash = 29 * hash + t.hashCode();
/* 69 */     return hash;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 74 */     if (!super.equals(obj)) return false;
/* 75 */     if (!(obj instanceof MBeanParameterInfo)) { return false;
/*    */     }
/* 77 */     MBeanParameterInfo other = (MBeanParameterInfo)obj;
/* 78 */     String thisType = getType();
/* 79 */     String otherType = other.getType();
/* 80 */     if (thisType != null ? !thisType.equals(otherType) : otherType != null) { return false;
/*    */     }
/* 82 */     return true;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanParameterInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */