/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BetweenQueryExp
/*    */   extends QueryEval
/*    */   implements QueryExp
/*    */ {
/*    */   private static final long serialVersionUID = -2933597532866307444L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final ValueExp exp1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final ValueExp exp2;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final ValueExp exp3;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   BetweenQueryExp(ValueExp exp1, ValueExp exp2, ValueExp exp3)
/*    */   {
/* 34 */     this.exp1 = exp1;
/* 35 */     this.exp2 = exp2;
/* 36 */     this.exp3 = exp3;
/*    */   }
/*    */   
/*    */   public void setMBeanServer(MBeanServer server)
/*    */   {
/* 41 */     super.setMBeanServer(server);
/* 42 */     if (this.exp1 != null) this.exp1.setMBeanServer(server);
/* 43 */     if (this.exp2 != null) this.exp2.setMBeanServer(server);
/* 44 */     if (this.exp3 != null) this.exp3.setMBeanServer(server);
/*    */   }
/*    */   
/*    */   public boolean apply(ObjectName name) throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException
/*    */   {
/* 49 */     if ((this.exp1 != null) && (this.exp2 != null) && (this.exp3 != null))
/*    */     {
/* 51 */       ValueExp val1 = this.exp1.apply(name);
/* 52 */       ValueExp val2 = this.exp2.apply(name);
/* 53 */       ValueExp val3 = this.exp3.apply(name);
/*    */       
/* 55 */       if (((val1 instanceof NumericValueExp)) && ((val2 instanceof NumericValueExp)) && ((val3 instanceof NumericValueExp)))
/*    */       {
/* 57 */         NumericValueExp num1 = (NumericValueExp)val1;
/* 58 */         NumericValueExp num2 = (NumericValueExp)val2;
/* 59 */         NumericValueExp num3 = (NumericValueExp)val3;
/*    */         
/* 61 */         if ((num1.isDouble()) || (num2.isDouble()) || (num3.isDouble()))
/*    */         {
/* 63 */           return isBetween(new Double(num1.doubleValue()), new Double(num2.doubleValue()), new Double(num3.doubleValue()));
/*    */         }
/*    */         
/*    */ 
/* 67 */         return isBetween(new Long(num1.longValue()), new Long(num2.longValue()), new Long(num3.longValue()));
/*    */       }
/*    */       
/* 70 */       if (((val1 instanceof StringValueExp)) && ((val2 instanceof StringValueExp)) && ((val3 instanceof StringValueExp)))
/*    */       {
/* 72 */         String s1 = ((StringValueExp)val1).getValue();
/* 73 */         String s2 = ((StringValueExp)val2).getValue();
/* 74 */         String s3 = ((StringValueExp)val3).getValue();
/* 75 */         return isBetween(s1, s2, s3);
/*    */       }
/*    */     }
/*    */     
/* 79 */     return false;
/*    */   }
/*    */   
/*    */   private boolean isBetween(Comparable c1, Comparable c2, Comparable c3)
/*    */   {
/* 84 */     if ((c1 == null) && (c2 == null) && (c3 == null)) return true;
/* 85 */     if ((c1 == null) && ((c2 == null) || (c3 == null))) return true;
/* 86 */     if (c1 == null) return false;
/* 87 */     if ((c1 != null) && ((c2 == null) || (c3 == null))) return false;
/* 88 */     return (c1.compareTo(c2) >= 0) && (c1.compareTo(c3) <= 0);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/BetweenQueryExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */