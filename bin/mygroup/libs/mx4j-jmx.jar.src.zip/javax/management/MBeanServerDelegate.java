/*     */ package javax.management;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.rmi.server.UID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanServerDelegate
/*     */   implements MBeanServerDelegateMBean, NotificationEmitter
/*     */ {
/*     */   private static long mbeanServerCount;
/*  26 */   private static final MBeanNotificationInfo[] notifications = { new MBeanNotificationInfo(new String[] { "JMX.mbean.registered", "JMX.mbean.unregistered" }, MBeanServerNotification.class.getName(), "Notifications emitted by the MBeanServerDelegate MBean upon registration or unregistration of MBeans") };
/*     */   
/*     */ 
/*     */   private String mbeanServerID;
/*     */   
/*     */ 
/*  32 */   private NotificationBroadcasterSupport broadcaster = new NotificationBroadcasterSupport();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback)
/*     */     throws IllegalArgumentException
/*     */   {
/*  43 */     this.broadcaster.addNotificationListener(listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(NotificationListener listener) throws ListenerNotFoundException
/*     */   {
/*  48 */     this.broadcaster.removeNotificationListener(listener);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback)
/*     */     throws ListenerNotFoundException
/*     */   {
/*  54 */     this.broadcaster.removeNotificationListener(listener, filter, handback);
/*     */   }
/*     */   
/*     */   public MBeanNotificationInfo[] getNotificationInfo()
/*     */   {
/*  59 */     return notifications;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sendNotification(Notification notification)
/*     */   {
/*  67 */     this.broadcaster.sendNotification(notification);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getMBeanServerId()
/*     */   {
/*  73 */     synchronized (this)
/*     */     {
/*  75 */       if (this.mbeanServerID == null) this.mbeanServerID = generateMBeanServerID();
/*     */     }
/*  77 */     return this.mbeanServerID;
/*     */   }
/*     */   
/*     */   public String getImplementationName()
/*     */   {
/*  82 */     return "MX4J";
/*     */   }
/*     */   
/*     */   public String getImplementationVendor()
/*     */   {
/*  87 */     return "The MX4J Team";
/*     */   }
/*     */   
/*     */   public String getImplementationVersion()
/*     */   {
/*  92 */     return "2.1.0";
/*     */   }
/*     */   
/*     */   public String getSpecificationName()
/*     */   {
/*  97 */     return "Java Management Extensions";
/*     */   }
/*     */   
/*     */   public String getSpecificationVendor()
/*     */   {
/* 102 */     return "Sun Microsystems";
/*     */   }
/*     */   
/*     */   public String getSpecificationVersion()
/*     */   {
/* 107 */     return "1.2 Maintenance Release";
/*     */   }
/*     */   
/*     */   private String getLocalHost()
/*     */   {
/*     */     try
/*     */     {
/* 114 */       return InetAddress.getLocalHost().getHostName();
/*     */     }
/*     */     catch (UnknownHostException ignored) {}
/*     */     
/* 118 */     return "localhost";
/*     */   }
/*     */   
/*     */ 
/*     */   private String generateMBeanServerID()
/*     */   {
/* 124 */     long count = 0L;
/* 125 */     synchronized (MBeanServerDelegate.class)
/*     */     {
/* 127 */       mbeanServerCount += 1L;
/* 128 */       count = mbeanServerCount;
/*     */     }
/*     */     
/* 131 */     UID uid = new UID();
/* 132 */     return uid.toString() + ":" + getLocalHost() + ":" + count;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanServerDelegate.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */