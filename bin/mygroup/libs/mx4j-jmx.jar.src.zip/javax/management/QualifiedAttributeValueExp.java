/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class QualifiedAttributeValueExp
/*    */   extends AttributeValueExp
/*    */ {
/*    */   private static final long serialVersionUID = 8832517277410933254L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private String className;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private transient MBeanServer server;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   QualifiedAttributeValueExp(String className, String attr)
/*    */   {
/* 30 */     super(attr);
/* 31 */     this.className = className;
/*    */   }
/*    */   
/*    */   public void setMBeanServer(MBeanServer server)
/*    */   {
/* 36 */     super.setMBeanServer(server);
/* 37 */     this.server = server;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public ValueExp apply(ObjectName name)
/*    */     throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException
/*    */   {
/*    */     try
/*    */     {
/* 47 */       String cls = this.server.getObjectInstance(name).getClassName();
/* 48 */       if (cls.equals(this.className)) { return super.apply(name);
/*    */       }
/*    */     }
/*    */     catch (InstanceNotFoundException ignored) {}
/*    */     
/* 53 */     throw new InvalidApplicationException(this.className);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/QualifiedAttributeValueExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */