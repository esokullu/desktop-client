/*     */ package javax.management;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.util.EventObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Notification
/*     */   extends EventObject
/*     */ {
/*     */   private static final long serialVersionUID = -7516092053498031989L;
/*     */   private String type;
/*     */   private long sequenceNumber;
/*     */   private long timeStamp;
/*     */   private String message;
/*     */   private Object userData;
/*     */   protected Object source;
/*     */   
/*     */   public Notification(String type, Object source, long sequenceNumber)
/*     */   {
/*  60 */     this(type, source, sequenceNumber, System.currentTimeMillis(), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Notification(String type, Object source, long sequenceNumber, long timeStamp)
/*     */   {
/*  70 */     this(type, source, sequenceNumber, timeStamp, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Notification(String type, Object source, long sequenceNumber, String message)
/*     */   {
/*  80 */     this(type, source, sequenceNumber, System.currentTimeMillis(), message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Notification(String type, Object source, long sequenceNumber, long timeStamp, String message)
/*     */   {
/*  95 */     super(source);
/*  96 */     this.source = source;
/*  97 */     this.type = type;
/*  98 */     this.sequenceNumber = sequenceNumber;
/*  99 */     this.timeStamp = timeStamp;
/* 100 */     this.message = message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 108 */     return this.message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getType()
/*     */   {
/* 116 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getSource()
/*     */   {
/* 126 */     return this.source;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSource(Object source)
/*     */   {
/* 136 */     this.source = source;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getSequenceNumber()
/*     */   {
/* 146 */     return this.sequenceNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSequenceNumber(long sequenceNumber)
/*     */   {
/* 156 */     this.sequenceNumber = sequenceNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTimeStamp()
/*     */   {
/* 166 */     return this.timeStamp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeStamp(long timeStamp)
/*     */   {
/* 176 */     this.timeStamp = timeStamp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getUserData()
/*     */   {
/* 186 */     return this.userData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserData(Object userData)
/*     */   {
/* 196 */     this.userData = userData;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 201 */     StringBuffer b = new StringBuffer("[");
/* 202 */     b.append("source=").append(getSource()).append(", ");
/* 203 */     b.append("message=").append(getMessage()).append(", ");
/* 204 */     b.append("sequence=").append(getSequenceNumber()).append(", ");
/* 205 */     b.append("type=").append(getType()).append(", ");
/* 206 */     b.append("time=").append(getTimeStamp()).append(", ");
/* 207 */     b.append("data=").append(getUserData());
/* 208 */     b.append("]");
/* 209 */     return b.toString();
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/* 214 */     in.defaultReadObject();
/*     */     
/* 216 */     this.source = this.source;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/Notification.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */