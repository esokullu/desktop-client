/*     */ package javax.management;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectInputStream.GetField;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectOutputStream.PutField;
/*     */ import java.io.ObjectStreamField;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NotificationFilterSupport
/*     */   implements NotificationFilter, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 6579080007561786969L;
/*     */   private static final String serialName = "enabledTypes";
/*  37 */   private static final ObjectStreamField[] serialPersistentFields = { new ObjectStreamField("enabledTypes", List.class) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  42 */   private HashSet types = new HashSet();
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/*  46 */     if (this == o) return true;
/*  47 */     if (!(o instanceof NotificationFilterSupport)) { return false;
/*     */     }
/*  49 */     NotificationFilterSupport support = (NotificationFilterSupport)o;
/*     */     
/*  51 */     if (!this.types.equals(support.types)) { return false;
/*     */     }
/*  53 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  58 */     return this.types.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enableType(String type)
/*     */     throws IllegalArgumentException
/*     */   {
/*  69 */     if (type == null) throw new IllegalArgumentException("Null notification type");
/*  70 */     synchronized (this.types)
/*     */     {
/*  72 */       this.types.add(type);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void disableAllTypes()
/*     */   {
/*  81 */     synchronized (this.types)
/*     */     {
/*  83 */       this.types.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void disableType(String type)
/*     */   {
/*  94 */     synchronized (this.types)
/*     */     {
/*  96 */       this.types.remove(type);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector getEnabledTypes()
/*     */   {
/* 105 */     Vector v = new Vector();
/* 106 */     synchronized (this.types)
/*     */     {
/* 108 */       v.addAll(this.types);
/*     */     }
/* 110 */     return v;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNotificationEnabled(Notification notification)
/*     */   {
/* 121 */     String type = notification.getType();
/* 122 */     Iterator i; if (type != null)
/*     */     {
/* 124 */       for (i = getEnabledTypes().iterator(); i.hasNext();)
/*     */       {
/* 126 */         String t = (String)i.next();
/* 127 */         if (type.startsWith(t)) return true;
/*     */       }
/*     */     }
/* 130 */     return false;
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/* 135 */     ObjectInputStream.GetField fields = in.readFields();
/*     */     
/* 137 */     Vector vector = (Vector)fields.get("enabledTypes", null);
/* 138 */     if (fields.defaulted("enabledTypes"))
/*     */     {
/* 140 */       throw new IOException("Serialized stream corrupted: expecting a non-null Vector");
/*     */     }
/*     */     
/* 143 */     if (this.types == null) this.types = new HashSet();
/* 144 */     this.types.clear();
/* 145 */     this.types.addAll(vector);
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException
/*     */   {
/* 150 */     ObjectOutputStream.PutField fields = out.putFields();
/*     */     
/* 152 */     Vector vector = getEnabledTypes();
/* 153 */     fields.put("enabledTypes", vector);
/* 154 */     out.writeFields();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/NotificationFilterSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */