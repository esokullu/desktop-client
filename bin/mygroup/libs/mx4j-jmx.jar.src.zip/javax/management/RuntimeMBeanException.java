/*     */ package javax.management;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuntimeMBeanException
/*     */   extends JMRuntimeException
/*     */ {
/*     */   private static final long serialVersionUID = 5274912751982730171L;
/*     */   private RuntimeException runtimeException;
/*     */   
/*     */   public RuntimeMBeanException(RuntimeException exception)
/*     */   {
/*  35 */     this.runtimeException = exception;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RuntimeMBeanException(RuntimeException exception, String message)
/*     */   {
/*  46 */     super(message);
/*  47 */     this.runtimeException = exception;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RuntimeException getTargetException()
/*     */   {
/*  55 */     return this.runtimeException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getCause()
/*     */   {
/*  63 */     return getTargetException();
/*     */   }
/*     */   
/*     */   public String getMessage()
/*     */   {
/*  68 */     return super.getMessage() + " nested runtime exception is " + this.runtimeException;
/*     */   }
/*     */   
/*     */   public void printStackTrace()
/*     */   {
/*  73 */     if (this.runtimeException == null)
/*     */     {
/*  75 */       super.printStackTrace();
/*     */     }
/*     */     else
/*     */     {
/*  79 */       synchronized (System.err)
/*     */       {
/*  81 */         System.err.println(this);
/*  82 */         this.runtimeException.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void printStackTrace(PrintStream s)
/*     */   {
/*  89 */     if (this.runtimeException == null)
/*     */     {
/*  91 */       super.printStackTrace(s);
/*     */     }
/*     */     else
/*     */     {
/*  95 */       synchronized (s)
/*     */       {
/*  97 */         s.println(this);
/*  98 */         this.runtimeException.printStackTrace(s);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void printStackTrace(PrintWriter w)
/*     */   {
/* 105 */     if (this.runtimeException == null)
/*     */     {
/* 107 */       super.printStackTrace(w);
/*     */     }
/*     */     else
/*     */     {
/* 111 */       synchronized (w)
/*     */       {
/* 113 */         w.println(this);
/* 114 */         this.runtimeException.printStackTrace(w);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/RuntimeMBeanException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */