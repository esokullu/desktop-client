/*     */ package javax.management;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import mx4j.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanInfo
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -6451021435135161911L;
/*  22 */   private static final MBeanConstructorInfo[] EMPTY_CONSTRUCTORS = new MBeanConstructorInfo[0];
/*  23 */   private static final MBeanAttributeInfo[] EMPTY_ATTRIBUTES = new MBeanAttributeInfo[0];
/*  24 */   private static final MBeanOperationInfo[] EMPTY_OPERATIONS = new MBeanOperationInfo[0];
/*  25 */   private static final MBeanNotificationInfo[] EMPTY_NOTIFICATIONS = new MBeanNotificationInfo[0];
/*     */   
/*     */ 
/*     */ 
/*     */   private String className;
/*     */   
/*     */ 
/*     */ 
/*     */   private String description;
/*     */   
/*     */ 
/*     */ 
/*     */   private MBeanConstructorInfo[] constructors;
/*     */   
/*     */ 
/*     */ 
/*     */   private MBeanAttributeInfo[] attributes;
/*     */   
/*     */ 
/*     */ 
/*     */   private MBeanOperationInfo[] operations;
/*     */   
/*     */ 
/*     */   private MBeanNotificationInfo[] notifications;
/*     */   
/*     */ 
/*     */ 
/*     */   public MBeanInfo(String className, String description, MBeanAttributeInfo[] attributes, MBeanConstructorInfo[] constructors, MBeanOperationInfo[] operations, MBeanNotificationInfo[] notifications)
/*     */   {
/*  54 */     this.className = className;
/*  55 */     this.description = description;
/*  56 */     this.constructors = ((constructors == null) || (constructors.length == 0) ? EMPTY_CONSTRUCTORS : constructors);
/*  57 */     this.attributes = ((attributes == null) || (attributes.length == 0) ? EMPTY_ATTRIBUTES : attributes);
/*  58 */     this.operations = ((operations == null) || (operations.length == 0) ? EMPTY_OPERATIONS : operations);
/*  59 */     this.notifications = ((notifications == null) || (notifications.length == 0) ? EMPTY_NOTIFICATIONS : notifications);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object clone()
/*     */   {
/*     */     try
/*     */     {
/*  67 */       return super.clone();
/*     */     }
/*     */     catch (CloneNotSupportedException x) {}
/*     */     
/*  71 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getClassName()
/*     */   {
/*  77 */     return this.className;
/*     */   }
/*     */   
/*     */   public String getDescription()
/*     */   {
/*  82 */     return this.description;
/*     */   }
/*     */   
/*     */   public MBeanConstructorInfo[] getConstructors()
/*     */   {
/*  87 */     return this.constructors;
/*     */   }
/*     */   
/*     */   public MBeanAttributeInfo[] getAttributes()
/*     */   {
/*  92 */     return this.attributes;
/*     */   }
/*     */   
/*     */   public MBeanOperationInfo[] getOperations()
/*     */   {
/*  97 */     return this.operations;
/*     */   }
/*     */   
/*     */   public MBeanNotificationInfo[] getNotifications()
/*     */   {
/* 102 */     return this.notifications;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 107 */     int hash = 0;
/* 108 */     String cn = getClassName();
/* 109 */     if (cn != null) hash = 29 * hash + cn.hashCode();
/* 110 */     String de = getDescription();
/* 111 */     if (de != null) hash = 29 * hash + de.hashCode();
/* 112 */     MBeanConstructorInfo[] co = getConstructors();
/* 113 */     if (co != null) hash = 29 * hash + Utils.arrayHashCode(co);
/* 114 */     MBeanAttributeInfo[] at = getAttributes();
/* 115 */     if (at != null) hash = 29 * hash + Utils.arrayHashCode(at);
/* 116 */     MBeanOperationInfo[] op = getOperations();
/* 117 */     if (op != null) hash = 29 * hash + Utils.arrayHashCode(op);
/* 118 */     MBeanNotificationInfo[] no = getNotifications();
/* 119 */     if (no != null) hash = 29 * hash + Utils.arrayHashCode(no);
/* 120 */     return hash;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 125 */     if (obj == this) return true;
/* 126 */     if (!(obj instanceof MBeanInfo)) { return false;
/*     */     }
/* 128 */     MBeanInfo other = (MBeanInfo)obj;
/* 129 */     String thisClassName = getClassName();
/* 130 */     String otherClassName = other.getClassName();
/* 131 */     if (thisClassName != null ? !thisClassName.equals(otherClassName) : otherClassName != null) return false;
/* 132 */     String thisDescription = getDescription();
/* 133 */     String otherDescription = other.getDescription();
/* 134 */     if (thisDescription != null ? !thisDescription.equals(otherDescription) : otherDescription != null) return false;
/* 135 */     if (!Utils.arrayEquals(getConstructors(), other.getConstructors())) return false;
/* 136 */     if (!Utils.arrayEquals(getAttributes(), other.getAttributes())) return false;
/* 137 */     if (!Utils.arrayEquals(getOperations(), other.getOperations())) return false;
/* 138 */     if (!Utils.arrayEquals(getNotifications(), other.getNotifications())) return false;
/* 139 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */