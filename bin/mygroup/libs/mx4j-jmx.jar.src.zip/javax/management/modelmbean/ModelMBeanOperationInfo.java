/*     */ package javax.management.modelmbean;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import javax.management.Descriptor;
/*     */ import javax.management.DescriptorAccess;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelMBeanOperationInfo
/*     */   extends MBeanOperationInfo
/*     */   implements DescriptorAccess
/*     */ {
/*     */   private static final long serialVersionUID = 6532732096650090465L;
/*     */   private Descriptor operationDescriptor;
/*     */   
/*     */   public ModelMBeanOperationInfo(String description, Method method)
/*     */   {
/*  29 */     this(description, method, null);
/*     */   }
/*     */   
/*     */   public ModelMBeanOperationInfo(String description, Method method, Descriptor descriptor)
/*     */   {
/*  34 */     super(description, method);
/*  35 */     checkAndSetDescriptor(descriptor);
/*     */   }
/*     */   
/*     */   public ModelMBeanOperationInfo(String name, String description, MBeanParameterInfo[] params, String type, int impact)
/*     */   {
/*  40 */     this(name, description, params, type, impact, null);
/*     */   }
/*     */   
/*     */   public ModelMBeanOperationInfo(String name, String description, MBeanParameterInfo[] params, String type, int impact, Descriptor descriptor)
/*     */   {
/*  45 */     super(name, description, params, type, impact);
/*  46 */     checkAndSetDescriptor(descriptor);
/*     */   }
/*     */   
/*     */   public ModelMBeanOperationInfo(ModelMBeanOperationInfo copy)
/*     */   {
/*  51 */     super(copy.getName(), copy.getDescription(), copy.getSignature(), copy.getReturnType(), copy.getImpact());
/*  52 */     checkAndSetDescriptor(copy.getDescriptor());
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  57 */     return new ModelMBeanOperationInfo(this);
/*     */   }
/*     */   
/*     */   public Descriptor getDescriptor()
/*     */   {
/*  62 */     return (Descriptor)this.operationDescriptor.clone();
/*     */   }
/*     */   
/*     */   public void setDescriptor(Descriptor descriptor)
/*     */   {
/*  67 */     if (descriptor == null)
/*     */     {
/*  69 */       this.operationDescriptor = createDefaultDescriptor();
/*     */ 
/*     */ 
/*     */     }
/*  73 */     else if (isDescriptorValid(descriptor))
/*     */     {
/*  75 */       this.operationDescriptor = ((Descriptor)descriptor.clone());
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*  82 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid descriptor"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void checkAndSetDescriptor(Descriptor descriptor)
/*     */   {
/*  89 */     if (descriptor == null)
/*     */     {
/*  91 */       this.operationDescriptor = createDefaultDescriptor();
/*     */     }
/*  93 */     else if (isDescriptorValid(descriptor))
/*     */     {
/*  95 */       this.operationDescriptor = ((Descriptor)descriptor.clone());
/*  96 */       if (this.operationDescriptor.getFieldValue("displayName") == null)
/*     */       {
/*  98 */         this.operationDescriptor.setField("displayName", getName());
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 103 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid Descriptor"));
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isDescriptorValid(Descriptor descriptor)
/*     */   {
/* 109 */     if (!descriptor.isValid())
/*     */     {
/* 111 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 117 */     String[] names = descriptor.getFieldNames();
/*     */     
/* 119 */     if ((!ModelMBeanInfoSupport.containsIgnoreCase(names, "name")) || (!ModelMBeanInfoSupport.containsIgnoreCase(names, "descriptortype")) || (!ModelMBeanInfoSupport.containsIgnoreCase(names, "role")))
/*     */     {
/*     */ 
/*     */ 
/* 123 */       return false;
/*     */     }
/*     */     
/* 126 */     String name = getName();
/* 127 */     if (name == null)
/*     */     {
/* 129 */       return false;
/*     */     }
/* 131 */     if (!name.equals(descriptor.getFieldValue("name")))
/*     */     {
/* 133 */       return false;
/*     */     }
/*     */     
/* 136 */     String desctype = (String)descriptor.getFieldValue("descriptortype");
/* 137 */     if (desctype.compareToIgnoreCase("operation") != 0) { return false;
/*     */     }
/* 139 */     if ((!"getter".equals(descriptor.getFieldValue("role"))) && (!"setter".equals(descriptor.getFieldValue("role"))) && (!"operation".equals(descriptor.getFieldValue("role"))))
/*     */     {
/*     */ 
/*     */ 
/* 143 */       return false;
/*     */     }
/*     */     
/* 146 */     return true;
/*     */   }
/*     */   
/*     */   private Descriptor createDefaultDescriptor()
/*     */   {
/* 151 */     String[] names = { "name", "descriptorType", "role", "displayName" };
/* 152 */     Object[] values = { getName(), "operation", "operation", getName() };
/* 153 */     return new DescriptorSupport(names, values);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/modelmbean/ModelMBeanOperationInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */