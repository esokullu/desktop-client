/*    */ package javax.management.modelmbean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLParseException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 3176664577895105181L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public XMLParseException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public XMLParseException(String message)
/*    */   {
/* 26 */     super(message);
/*    */   }
/*    */   
/*    */   public XMLParseException(Exception x, String message)
/*    */   {
/* 31 */     super(message + " - " + x);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/modelmbean/XMLParseException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */