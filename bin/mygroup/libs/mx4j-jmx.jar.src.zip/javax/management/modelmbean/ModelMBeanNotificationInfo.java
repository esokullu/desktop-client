/*     */ package javax.management.modelmbean;
/*     */ 
/*     */ import javax.management.Descriptor;
/*     */ import javax.management.DescriptorAccess;
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelMBeanNotificationInfo
/*     */   extends MBeanNotificationInfo
/*     */   implements DescriptorAccess, Cloneable
/*     */ {
/*     */   private static final long serialVersionUID = -7445681389570207141L;
/*     */   private Descriptor notificationDescriptor;
/*     */   
/*     */   public ModelMBeanNotificationInfo(String[] types, String name, String description)
/*     */   {
/*  29 */     this(types, name, description, null);
/*     */   }
/*     */   
/*     */   public ModelMBeanNotificationInfo(String[] types, String name, String description, Descriptor descriptor)
/*     */   {
/*  34 */     super(types, name, description);
/*  35 */     checkAndSetDescriptor(descriptor);
/*     */   }
/*     */   
/*     */   public ModelMBeanNotificationInfo(ModelMBeanNotificationInfo copy)
/*     */   {
/*  40 */     super(copy.getNotifTypes(), copy.getName(), copy.getDescription());
/*  41 */     checkAndSetDescriptor(copy.getDescriptor());
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  46 */     return new ModelMBeanNotificationInfo(this);
/*     */   }
/*     */   
/*     */   public Descriptor getDescriptor()
/*     */   {
/*  51 */     return (Descriptor)this.notificationDescriptor.clone();
/*     */   }
/*     */   
/*     */   public void setDescriptor(Descriptor descriptor)
/*     */   {
/*  56 */     if (descriptor == null)
/*     */     {
/*  58 */       this.notificationDescriptor = createDefaultDescriptor();
/*     */ 
/*     */ 
/*     */     }
/*  62 */     else if (isDescriptorValid(descriptor))
/*     */     {
/*  64 */       this.notificationDescriptor = ((Descriptor)descriptor.clone());
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*  71 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid descriptor"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void checkAndSetDescriptor(Descriptor descriptor)
/*     */   {
/*  78 */     if (descriptor == null)
/*     */     {
/*  80 */       this.notificationDescriptor = createDefaultDescriptor();
/*     */     }
/*  82 */     else if (isDescriptorValid(descriptor))
/*     */     {
/*  84 */       this.notificationDescriptor = ((Descriptor)descriptor.clone());
/*  85 */       if (this.notificationDescriptor.getFieldValue("displayname") == null)
/*     */       {
/*  87 */         this.notificationDescriptor.setField("displayname", getName());
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*  92 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid Descriptor"));
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isDescriptorValid(Descriptor descriptor)
/*     */   {
/*  98 */     if (!descriptor.isValid())
/*     */     {
/* 100 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 106 */     String[] names = descriptor.getFieldNames();
/*     */     
/* 108 */     if ((!ModelMBeanInfoSupport.containsIgnoreCase(names, "name")) || (!ModelMBeanInfoSupport.containsIgnoreCase(names, "descriptortype")) || (!ModelMBeanInfoSupport.containsIgnoreCase(names, "severity")))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 115 */       return false;
/*     */     }
/*     */     
/* 118 */     String name = getName();
/* 119 */     if (name == null)
/*     */     {
/* 121 */       return false;
/*     */     }
/* 123 */     if (!name.equals(descriptor.getFieldValue("name")))
/*     */     {
/* 125 */       return false;
/*     */     }
/*     */     
/* 128 */     String desctype = (String)descriptor.getFieldValue("descriptortype");
/* 129 */     if (desctype.compareToIgnoreCase("notification") != 0) { return false;
/*     */     }
/*     */     
/* 132 */     int severity = objectToInt(descriptor.getFieldValue("severity"));
/* 133 */     if ((severity < 0) || (severity > 6))
/*     */     {
/* 135 */       return false;
/*     */     }
/*     */     
/* 138 */     return true;
/*     */   }
/*     */   
/*     */   private Descriptor createDefaultDescriptor()
/*     */   {
/* 143 */     String[] names = { "name", "descriptorType", "severity", "displayName" };
/* 144 */     Object[] values = { getName(), "notification", "5", getName() };
/* 145 */     return new DescriptorSupport(names, values);
/*     */   }
/*     */   
/*     */   private int objectToInt(Object value)
/*     */   {
/* 150 */     if (value == null)
/*     */     {
/* 152 */       return -1;
/*     */     }
/*     */     
/* 155 */     if ((value instanceof Number))
/*     */     {
/* 157 */       return ((Number)value).intValue();
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 163 */       return Integer.parseInt(value.toString());
/*     */     }
/*     */     catch (NumberFormatException x) {}
/*     */     
/* 167 */     return -1;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/modelmbean/ModelMBeanNotificationInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */