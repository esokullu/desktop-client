/*    */ package javax.management.modelmbean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidTargetObjectTypeException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1190536278266811217L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private Exception exception;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidTargetObjectTypeException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidTargetObjectTypeException(String message)
/*    */   {
/* 27 */     super(message);
/*    */   }
/*    */   
/*    */   public InvalidTargetObjectTypeException(Exception x, String message)
/*    */   {
/* 32 */     super(message);
/* 33 */     this.exception = x;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/modelmbean/InvalidTargetObjectTypeException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */