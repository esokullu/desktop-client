/*      */ package javax.management.modelmbean;
/*      */ 
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import javax.management.Attribute;
/*      */ import javax.management.AttributeChangeNotification;
/*      */ import javax.management.AttributeChangeNotificationFilter;
/*      */ import javax.management.AttributeList;
/*      */ import javax.management.AttributeNotFoundException;
/*      */ import javax.management.Descriptor;
/*      */ import javax.management.InstanceNotFoundException;
/*      */ import javax.management.InvalidAttributeValueException;
/*      */ import javax.management.ListenerNotFoundException;
/*      */ import javax.management.MBeanAttributeInfo;
/*      */ import javax.management.MBeanException;
/*      */ import javax.management.MBeanInfo;
/*      */ import javax.management.MBeanNotificationInfo;
/*      */ import javax.management.MBeanRegistration;
/*      */ import javax.management.MBeanRegistrationException;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.MalformedObjectNameException;
/*      */ import javax.management.Notification;
/*      */ import javax.management.NotificationBroadcasterSupport;
/*      */ import javax.management.NotificationEmitter;
/*      */ import javax.management.NotificationFilter;
/*      */ import javax.management.NotificationListener;
/*      */ import javax.management.ObjectName;
/*      */ import javax.management.ReflectionException;
/*      */ import javax.management.RuntimeErrorException;
/*      */ import javax.management.RuntimeOperationsException;
/*      */ import javax.management.ServiceNotFoundException;
/*      */ import javax.management.loading.ClassLoaderRepository;
/*      */ import mx4j.ImplementationException;
/*      */ import mx4j.log.FileLogger;
/*      */ import mx4j.log.Log;
/*      */ import mx4j.log.Logger;
/*      */ import mx4j.log.MBeanLogger;
/*      */ import mx4j.persist.FilePersister;
/*      */ import mx4j.persist.MBeanPersister;
/*      */ import mx4j.persist.PersisterMBean;
/*      */ import mx4j.util.Utils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RequiredModelMBean
/*      */   implements ModelMBean, MBeanRegistration, NotificationEmitter
/*      */ {
/*      */   private static final String OBJECT_RESOURCE_TYPE = "ObjectReference";
/*      */   private static final int ALWAYS_STALE = 1;
/*      */   private static final int NEVER_STALE = 2;
/*      */   private static final int STALE = 3;
/*      */   private static final int NOT_STALE = 4;
/*      */   private static final int PERSIST_NEVER = -1;
/*      */   private static final int PERSIST_ON_TIMER = -2;
/*      */   private static final int PERSIST_ON_UPDATE = -3;
/*      */   private static final int PERSIST_NO_MORE_OFTEN_THAN = -4;
/*      */   private MBeanServer m_mbeanServer;
/*      */   private Object m_managedResource;
/*      */   private boolean m_canBeRegistered;
/*      */   private ModelMBeanInfo m_modelMBeanInfo;
/*   75 */   private NotificationBroadcasterSupport m_attributeChangeBroadcaster = new NotificationBroadcasterSupport();
/*   76 */   private NotificationBroadcasterSupport m_generalBroadcaster = new NotificationBroadcasterSupport();
/*      */   
/*      */   public RequiredModelMBean() throws MBeanException, RuntimeOperationsException
/*      */   {
/*      */     try
/*      */     {
/*   82 */       load();
/*      */     }
/*      */     catch (Exception x)
/*      */     {
/*   86 */       Logger logger = getLogger();
/*   87 */       logger.warn("Cannot restore previously saved status", x);
/*      */     }
/*      */   }
/*      */   
/*      */   public RequiredModelMBean(ModelMBeanInfo info) throws MBeanException, RuntimeOperationsException
/*      */   {
/*   93 */     if (info == null) {
/*   94 */       throw new RuntimeOperationsException(new IllegalArgumentException("ModelMBeanInfo parameter can't be null"));
/*      */     }
/*   96 */     setModelMBeanInfo(info);
/*      */   }
/*      */   
/*      */   private Logger getLogger()
/*      */   {
/*  101 */     return Log.getLogger(getClass().getName());
/*      */   }
/*      */   
/*      */   public ObjectName preRegister(MBeanServer server, ObjectName name) throws Exception
/*      */   {
/*  106 */     if (this.m_canBeRegistered)
/*      */     {
/*  108 */       this.m_mbeanServer = server;
/*  109 */       return name;
/*      */     }
/*      */     
/*      */ 
/*  113 */     throw new MBeanRegistrationException(new IllegalStateException("ModelMBean cannot be registered until setModelMBeanInfo has been called"));
/*      */   }
/*      */   
/*      */ 
/*      */   public void postRegister(Boolean registrationDone)
/*      */   {
/*  119 */     if (!registrationDone.booleanValue()) clear();
/*      */   }
/*      */   
/*      */   public void preDeregister()
/*      */     throws Exception
/*      */   {}
/*      */   
/*      */   public void postDeregister()
/*      */   {
/*  128 */     clear();
/*      */   }
/*      */   
/*      */   private void clear()
/*      */   {
/*  133 */     this.m_mbeanServer = null;
/*      */   }
/*      */   
/*      */   public void setModelMBeanInfo(ModelMBeanInfo modelMBeanInfo)
/*      */     throws MBeanException, RuntimeOperationsException
/*      */   {
/*  139 */     if (modelMBeanInfo == null) throw new RuntimeOperationsException(new IllegalArgumentException("ModelMBeanInfo cannot be null"));
/*  140 */     if (!isModelMBeanInfoValid(modelMBeanInfo)) { throw new RuntimeOperationsException(new IllegalArgumentException("ModelMBeanInfo is invalid"));
/*      */     }
/*  142 */     this.m_modelMBeanInfo = ((ModelMBeanInfo)modelMBeanInfo.clone());
/*      */     
/*  144 */     Logger logger = getLogger();
/*  145 */     if (logger.isEnabledFor(10)) { logger.debug("ModelMBeanInfo successfully set to: " + this.m_modelMBeanInfo);
/*      */     }
/*  147 */     this.m_canBeRegistered = true;
/*      */   }
/*      */   
/*      */   private boolean isModelMBeanInfoValid(ModelMBeanInfo info)
/*      */   {
/*  152 */     if ((info == null) || (info.getClassName() == null)) { return false;
/*      */     }
/*  154 */     return true;
/*      */   }
/*      */   
/*      */   public void setManagedResource(Object resource, String resourceType) throws MBeanException, RuntimeOperationsException, InstanceNotFoundException, InvalidTargetObjectTypeException
/*      */   {
/*  159 */     if (resource == null) throw new RuntimeOperationsException(new IllegalArgumentException("Managed resource cannot be null"));
/*  160 */     if (!isResourceTypeSupported(resourceType)) { throw new InvalidTargetObjectTypeException(resourceType);
/*      */     }
/*  162 */     Logger logger = getLogger();
/*  163 */     if (logger.isEnabledFor(10)) logger.debug("Setting managed resource to be: " + resource);
/*  164 */     this.m_managedResource = resource;
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean isResourceTypeSupported(String resourceType)
/*      */   {
/*  170 */     return "ObjectReference".equals(resourceType);
/*      */   }
/*      */   
/*      */   private Object getManagedResource()
/*      */   {
/*  175 */     return this.m_managedResource;
/*      */   }
/*      */   
/*      */   public MBeanInfo getMBeanInfo()
/*      */   {
/*  180 */     return this.m_modelMBeanInfo == null ? null : (MBeanInfo)this.m_modelMBeanInfo.clone();
/*      */   }
/*      */   
/*      */   public void addAttributeChangeNotificationListener(NotificationListener listener, String attributeName, Object handback) throws MBeanException, RuntimeOperationsException, IllegalArgumentException
/*      */   {
/*  185 */     if (listener == null) throw new RuntimeOperationsException(new IllegalArgumentException("Listener cannot be null"));
/*  186 */     AttributeChangeNotificationFilter filter = new AttributeChangeNotificationFilter();
/*  187 */     if (attributeName != null)
/*      */     {
/*  189 */       filter.enableAttribute(attributeName);
/*      */     }
/*      */     else
/*      */     {
/*  193 */       MBeanAttributeInfo[] ai = this.m_modelMBeanInfo.getAttributes();
/*  194 */       for (int i = 0; i < ai.length; i++)
/*      */       {
/*  196 */         Descriptor d = ((ModelMBeanAttributeInfo)ai[i]).getDescriptor();
/*  197 */         filter.enableAttribute((String)d.getFieldValue("name"));
/*      */       }
/*      */     }
/*      */     
/*  201 */     getAttributeChangeBroadcaster().addNotificationListener(listener, filter, handback);
/*      */     
/*  203 */     Logger logger = getLogger();
/*  204 */     if (logger.isEnabledFor(10)) logger.debug("Listener " + listener + " for attribute " + attributeName + " added successfully, handback is " + handback);
/*      */   }
/*      */   
/*      */   public void addNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback) throws IllegalArgumentException
/*      */   {
/*  209 */     this.m_generalBroadcaster.addNotificationListener(listener, filter, handback);
/*      */   }
/*      */   
/*      */   public MBeanNotificationInfo[] getNotificationInfo()
/*      */   {
/*  214 */     return this.m_modelMBeanInfo.getNotifications();
/*      */   }
/*      */   
/*      */   public void removeAttributeChangeNotificationListener(NotificationListener listener, String attributeName) throws MBeanException, RuntimeOperationsException, ListenerNotFoundException
/*      */   {
/*  219 */     removeAttributeChangeNotificationListener(listener, attributeName, null);
/*      */   }
/*      */   
/*      */   private void removeAttributeChangeNotificationListener(NotificationListener listener, String attributeName, Object handback)
/*      */     throws MBeanException, RuntimeOperationsException, ListenerNotFoundException
/*      */   {
/*  225 */     if (listener == null) throw new RuntimeOperationsException(new IllegalArgumentException("Listener cannot be null"));
/*  226 */     AttributeChangeNotificationFilter filter = new AttributeChangeNotificationFilter();
/*  227 */     if (attributeName != null)
/*      */     {
/*  229 */       filter.enableAttribute(attributeName);
/*      */     }
/*      */     else
/*      */     {
/*  233 */       MBeanAttributeInfo[] ai = this.m_modelMBeanInfo.getAttributes();
/*  234 */       for (int i = 0; i < ai.length; i++)
/*      */       {
/*  236 */         Descriptor d = ((ModelMBeanAttributeInfo)ai[i]).getDescriptor();
/*  237 */         filter.enableAttribute((String)d.getFieldValue("name"));
/*      */       }
/*      */     }
/*      */     
/*  241 */     getAttributeChangeBroadcaster().removeNotificationListener(listener, filter, handback);
/*      */     
/*  243 */     Logger logger = getLogger();
/*  244 */     if (logger.isEnabledFor(10)) logger.debug("Listener " + listener + " for attribute " + attributeName + " removed successfully, handback is " + handback);
/*      */   }
/*      */   
/*      */   public void removeNotificationListener(NotificationListener listener) throws RuntimeOperationsException, ListenerNotFoundException
/*      */   {
/*  249 */     this.m_generalBroadcaster.removeNotificationListener(listener);
/*      */   }
/*      */   
/*      */   public void removeNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback) throws RuntimeOperationsException, ListenerNotFoundException
/*      */   {
/*  254 */     this.m_generalBroadcaster.removeNotificationListener(listener, filter, handback);
/*      */   }
/*      */   
/*      */   public void sendAttributeChangeNotification(Attribute oldAttribute, Attribute newAttribute) throws MBeanException, RuntimeOperationsException
/*      */   {
/*  259 */     if ((oldAttribute == null) || (newAttribute == null)) throw new RuntimeOperationsException(new IllegalArgumentException("Attribute cannot be null"));
/*  260 */     if (!oldAttribute.getName().equals(newAttribute.getName())) { throw new RuntimeOperationsException(new IllegalArgumentException("Attribute names cannot be different"));
/*      */     }
/*      */     
/*  263 */     Object oldValue = oldAttribute.getValue();
/*  264 */     AttributeChangeNotification n = new AttributeChangeNotification(this, 1L, System.currentTimeMillis(), "Attribute value changed", oldAttribute.getName(), oldValue == null ? null : oldValue.getClass().getName(), oldValue, newAttribute.getValue());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  272 */     sendAttributeChangeNotification(n);
/*      */   }
/*      */   
/*      */   public void sendAttributeChangeNotification(AttributeChangeNotification notification) throws MBeanException, RuntimeOperationsException
/*      */   {
/*  277 */     if (notification == null) { throw new RuntimeOperationsException(new IllegalArgumentException("Notification cannot be null"));
/*      */     }
/*  279 */     getAttributeChangeBroadcaster().sendNotification(notification);
/*      */     
/*  281 */     Logger modelMBeanLogger = getModelMBeanLogger(notification.getType());
/*  282 */     if ((modelMBeanLogger != null) && (modelMBeanLogger.isEnabledFor(10))) { modelMBeanLogger.debug("ModelMBean log: " + new Date() + " - " + notification);
/*      */     }
/*  284 */     Logger logger = getLogger();
/*  285 */     if (logger.isEnabledFor(10)) logger.debug("Attribute change notification " + notification + " sent");
/*      */   }
/*      */   
/*      */   public void sendNotification(String message) throws MBeanException, RuntimeOperationsException
/*      */   {
/*  290 */     Notification notification = new Notification("jmx.modelmbean.general", this, 1L, message);
/*  291 */     sendNotification(notification);
/*      */   }
/*      */   
/*      */   public void sendNotification(Notification notification) throws MBeanException, RuntimeOperationsException
/*      */   {
/*  296 */     this.m_generalBroadcaster.sendNotification(notification);
/*      */   }
/*      */   
/*      */   public AttributeList getAttributes(String[] attributes)
/*      */   {
/*  301 */     if (attributes == null) { throw new RuntimeOperationsException(new IllegalArgumentException("Attribute names cannot be null"));
/*      */     }
/*  303 */     Logger logger = getLogger();
/*      */     
/*  305 */     AttributeList list = new AttributeList();
/*  306 */     for (int i = 0; i < attributes.length; i++)
/*      */     {
/*  308 */       String attrName = attributes[i];
/*  309 */       Attribute attribute = null;
/*      */       try
/*      */       {
/*  312 */         Object value = getAttribute(attrName);
/*  313 */         attribute = new Attribute(attrName, value);
/*  314 */         list.add(attribute);
/*      */       }
/*      */       catch (Exception x)
/*      */       {
/*  318 */         if (logger.isEnabledFor(0)) { logger.trace("getAttribute for attribute " + attrName + " failed", x);
/*      */         }
/*      */       }
/*      */     }
/*  322 */     return list;
/*      */   }
/*      */   
/*      */   public Object getAttribute(String attribute) throws AttributeNotFoundException, MBeanException, ReflectionException
/*      */   {
/*  327 */     if (attribute == null) { throw new RuntimeOperationsException(new IllegalArgumentException("Attribute name cannot be null"));
/*      */     }
/*  329 */     Logger logger = getLogger();
/*      */     
/*      */ 
/*  332 */     ModelMBeanInfo info = getModelMBeanInfo();
/*  333 */     if (info == null) throw new AttributeNotFoundException("ModelMBeanInfo is null");
/*  334 */     if (logger.isEnabledFor(10)) { logger.debug("ModelMBeanInfo is: " + info);
/*      */     }
/*      */     
/*  337 */     ModelMBeanAttributeInfo attrInfo = info.getAttribute(attribute);
/*  338 */     if (attrInfo == null) throw new AttributeNotFoundException("Cannot find ModelMBeanAttributeInfo for attribute " + attribute);
/*  339 */     if (logger.isEnabledFor(10)) logger.debug("Attribute info is: " + attrInfo);
/*  340 */     if (!attrInfo.isReadable()) { throw new AttributeNotFoundException("Attribute " + attribute + " is not readable");
/*      */     }
/*      */     
/*  343 */     Descriptor mbeanDescriptor = info.getMBeanDescriptor();
/*  344 */     if (mbeanDescriptor == null) throw new AttributeNotFoundException("MBean descriptor cannot be null");
/*  345 */     if (logger.isEnabledFor(10)) { logger.debug("MBean descriptor is: " + mbeanDescriptor);
/*      */     }
/*      */     
/*  348 */     Descriptor attributeDescriptor = attrInfo.getDescriptor();
/*  349 */     if (attributeDescriptor == null) throw new AttributeNotFoundException("Attribute descriptor for attribute " + attribute + " cannot be null");
/*  350 */     if (logger.isEnabledFor(10)) { logger.debug("Attribute descriptor is: " + attributeDescriptor);
/*      */     }
/*  352 */     Object returnValue = null;
/*      */     
/*  354 */     String lastUpdateField = "lastUpdatedTimeStamp";
/*      */     
/*  356 */     int staleness = getStaleness(attributeDescriptor, mbeanDescriptor, lastUpdateField);
/*      */     
/*  358 */     if ((staleness == 1) || (staleness == 3))
/*      */     {
/*  360 */       if (logger.isEnabledFor(0)) { logger.trace("Value is stale");
/*      */       }
/*  362 */       String getter = (String)attributeDescriptor.getFieldValue("getMethod");
/*  363 */       if (logger.isEnabledFor(10)) logger.debug("getMethod field is: " + getter);
/*  364 */       if (getter == null)
/*      */       {
/*      */ 
/*  367 */         returnValue = attributeDescriptor.getFieldValue("default");
/*      */         
/*  369 */         if (returnValue != null)
/*      */         {
/*      */ 
/*      */ 
/*  373 */           Class returned = returnValue.getClass();
/*  374 */           Class declared = loadClassWithContextClassLoader(attrInfo.getType());
/*      */           
/*  376 */           checkAssignability(returned, declared);
/*      */         }
/*      */         
/*  379 */         if (logger.isEnabledFor(10)) logger.debug("getAttribute for attribute " + attribute + " returns default value: " + returnValue);
/*      */       }
/*      */       else
/*      */       {
/*  383 */         if (logger.isEnabledFor(0)) { logger.trace("Invoking attribute getter...");
/*      */         }
/*  385 */         Object target = resolveTargetObject(attributeDescriptor);
/*  386 */         returnValue = invokeMethod(target, getter, new Class[0], new Object[0]);
/*  387 */         if (logger.isEnabledFor(10)) { logger.debug("Returned value is: " + returnValue);
/*      */         }
/*  389 */         if (returnValue != null)
/*      */         {
/*      */ 
/*      */ 
/*  393 */           Class returned = returnValue.getClass();
/*  394 */           Class declared = loadClassWithContextClassLoader(attrInfo.getType());
/*      */           
/*  396 */           checkAssignability(returned, declared);
/*      */         }
/*      */         
/*      */ 
/*  400 */         if (staleness != 1)
/*      */         {
/*  402 */           attributeDescriptor.setField("value", returnValue);
/*  403 */           attributeDescriptor.setField(lastUpdateField, new Long(System.currentTimeMillis()));
/*  404 */           if (logger.isEnabledFor(0)) { logger.trace("Returned value has been cached");
/*      */           }
/*      */           
/*  407 */           info.setDescriptor(attributeDescriptor, "attribute");
/*      */         }
/*      */         
/*  410 */         if (logger.isEnabledFor(10)) { logger.debug("getAttribute for attribute " + attribute + " returns invoked value: " + returnValue);
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  416 */       returnValue = attributeDescriptor.getFieldValue("value");
/*      */       
/*  418 */       if (returnValue != null)
/*      */       {
/*      */ 
/*      */ 
/*  422 */         Class returned = returnValue.getClass();
/*  423 */         Class declared = loadClassWithContextClassLoader(attrInfo.getType());
/*      */         
/*  425 */         checkAssignability(returned, declared);
/*      */       }
/*      */       
/*  428 */       if (logger.isEnabledFor(10)) { logger.debug("getAttribute for attribute " + attribute + " returns cached value: " + returnValue);
/*      */       }
/*      */     }
/*      */     
/*  432 */     return returnValue;
/*      */   }
/*      */   
/*      */   public AttributeList setAttributes(AttributeList attributes)
/*      */   {
/*  437 */     if (attributes == null) { throw new RuntimeOperationsException(new IllegalArgumentException("Attribute list cannot be null"));
/*      */     }
/*  439 */     Logger logger = getLogger();
/*      */     
/*  441 */     AttributeList list = new AttributeList();
/*  442 */     for (Iterator i = attributes.iterator(); i.hasNext();)
/*      */     {
/*  444 */       Attribute attribute = (Attribute)i.next();
/*  445 */       String name = attribute.getName();
/*      */       try
/*      */       {
/*  448 */         setAttribute(attribute);
/*  449 */         list.add(attribute);
/*      */       }
/*      */       catch (Exception x)
/*      */       {
/*  453 */         if (logger.isEnabledFor(0)) { logger.trace("setAttribute for attribute " + name + " failed", x);
/*      */         }
/*      */       }
/*      */     }
/*  457 */     return list;
/*      */   }
/*      */   
/*      */   public void setAttribute(Attribute attribute) throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException
/*      */   {
/*  462 */     if (attribute == null) { throw new RuntimeOperationsException(new IllegalArgumentException("Attribute cannot be null"));
/*      */     }
/*  464 */     Logger logger = getLogger();
/*      */     
/*      */ 
/*      */ 
/*  468 */     ModelMBeanInfo info = getModelMBeanInfo();
/*  469 */     if (info == null) throw new AttributeNotFoundException("ModelMBeanInfo is null");
/*  470 */     if (logger.isEnabledFor(10)) { logger.debug("ModelMBeanInfo is: " + info);
/*      */     }
/*  472 */     String attrName = attribute.getName();
/*  473 */     Object attrValue = attribute.getValue();
/*      */     
/*      */ 
/*  476 */     ModelMBeanAttributeInfo attrInfo = info.getAttribute(attrName);
/*  477 */     if (attrInfo == null) throw new AttributeNotFoundException("Cannot find ModelMBeanAttributeInfo for attribute " + attrName);
/*  478 */     if (logger.isEnabledFor(10)) { logger.debug("Attribute info is: " + attrInfo);
/*      */     }
/*  480 */     if (!attrInfo.isWritable()) { throw new AttributeNotFoundException("Attribute " + attrName + " is not writable");
/*      */     }
/*      */     
/*  483 */     Descriptor mbeanDescriptor = info.getMBeanDescriptor();
/*  484 */     if (mbeanDescriptor == null) throw new AttributeNotFoundException("MBean descriptor cannot be null");
/*  485 */     if (logger.isEnabledFor(10)) { logger.debug("MBean descriptor is: " + mbeanDescriptor);
/*      */     }
/*      */     
/*  488 */     Descriptor attributeDescriptor = attrInfo.getDescriptor();
/*  489 */     if (attributeDescriptor == null) throw new AttributeNotFoundException("Attribute descriptor for attribute " + attrName + " cannot be null");
/*  490 */     if (logger.isEnabledFor(10)) { logger.debug("Attribute descriptor is: " + attributeDescriptor);
/*      */     }
/*  492 */     String lastUpdateField = "lastUpdatedTimeStamp";
/*      */     
/*  494 */     Object oldValue = null;
/*      */     try
/*      */     {
/*  497 */       oldValue = getAttribute(attrName);
/*  498 */       if (logger.isEnabledFor(10)) logger.debug("Previous value of attribute " + attrName + ": " + oldValue);
/*      */     }
/*      */     catch (Exception x)
/*      */     {
/*  502 */       if (logger.isEnabledFor(10)) { logger.debug("Cannot get previous value of attribute " + attrName, x);
/*      */       }
/*      */     }
/*      */     
/*  506 */     String method = (String)attributeDescriptor.getFieldValue("setMethod");
/*  507 */     if (logger.isEnabledFor(10)) logger.debug("setMethod field is: " + method);
/*  508 */     if (method != null)
/*      */     {
/*  510 */       Class declared = loadClassWithContextClassLoader(attrInfo.getType());
/*  511 */       if (attrValue != null)
/*      */       {
/*  513 */         Class parameter = attrValue.getClass();
/*  514 */         checkAssignability(parameter, declared);
/*      */       }
/*      */       
/*      */ 
/*  518 */       Object target = resolveTargetObject(attributeDescriptor);
/*  519 */       invokeMethod(target, method, new Class[] { declared }, new Object[] { attrValue });
/*      */       
/*      */ 
/*  522 */       int staleness = getStaleness(attributeDescriptor, mbeanDescriptor, lastUpdateField);
/*  523 */       if (staleness != 1)
/*      */       {
/*  525 */         attributeDescriptor.setField("value", attrValue);
/*  526 */         attributeDescriptor.setField(lastUpdateField, new Long(System.currentTimeMillis()));
/*  527 */         if (logger.isEnabledFor(0)) { logger.trace("Attribute's value has been cached");
/*      */         }
/*      */         
/*      */       }
/*  531 */       else if (logger.isEnabledFor(0)) { logger.trace("Always stale, avoiding to cache attribute's value");
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  536 */       if (attrValue != null)
/*      */       {
/*  538 */         Class parameter = attrValue.getClass();
/*  539 */         Class declared = loadClassWithContextClassLoader(attrInfo.getType());
/*      */         
/*  541 */         checkAssignability(parameter, declared);
/*      */       }
/*      */       
/*      */ 
/*  545 */       attributeDescriptor.setField("value", attrValue);
/*      */     }
/*      */     
/*      */ 
/*  549 */     info.setDescriptor(attributeDescriptor, "attribute");
/*      */     
/*      */ 
/*  552 */     if (logger.isEnabledFor(0)) logger.trace("Sending attribute change notifications");
/*  553 */     sendAttributeChangeNotification(new Attribute(attrName, oldValue), attribute);
/*      */     
/*      */ 
/*  556 */     boolean persistNow = shouldPersistNow(attributeDescriptor, mbeanDescriptor, lastUpdateField);
/*  557 */     if (persistNow)
/*      */     {
/*  559 */       if (logger.isEnabledFor(0)) logger.trace("Persisting this ModelMBean...");
/*      */       try
/*      */       {
/*  562 */         store();
/*  563 */         if (logger.isEnabledFor(0)) logger.trace("ModelMBean persisted successfully");
/*      */       }
/*      */       catch (Exception x)
/*      */       {
/*  567 */         logger.error("Cannot store ModelMBean after setAttribute", x);
/*  568 */         if ((x instanceof MBeanException)) {
/*  569 */           throw ((MBeanException)x);
/*      */         }
/*  571 */         throw new MBeanException(x);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public Object invoke(String method, Object[] arguments, String[] params) throws MBeanException, ReflectionException
/*      */   {
/*  578 */     if (method == null) throw new RuntimeOperationsException(new IllegalArgumentException("Method name cannot be null"));
/*  579 */     if (arguments == null) arguments = new Object[0];
/*  580 */     if (params == null) { params = new String[0];
/*      */     }
/*  582 */     Logger logger = getLogger();
/*      */     
/*      */ 
/*  585 */     ModelMBeanInfo info = getModelMBeanInfo();
/*  586 */     if (info == null) throw new MBeanException(new ServiceNotFoundException("ModelMBeanInfo is null"));
/*  587 */     if (logger.isEnabledFor(10)) { logger.debug("ModelMBeanInfo is: " + info);
/*      */     }
/*      */     
/*  590 */     ModelMBeanOperationInfo operInfo = info.getOperation(method);
/*  591 */     if (operInfo == null)
/*      */     {
/*      */ 
/*      */       try
/*      */       {
/*      */ 
/*  597 */         Class[] clzArgs = new Class[params.length];
/*  598 */         for (int i = 0; i < clzArgs.length; i++)
/*      */         {
/*  600 */           clzArgs[i] = getClass().getClassLoader().loadClass(params[i]);
/*      */         }
/*      */         
/*      */ 
/*  604 */         Method invocationMethod = getClass().getMethod(method, clzArgs);
/*  605 */         operInfo = new ModelMBeanOperationInfo("", invocationMethod);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  609 */         throw new MBeanException(new ServiceNotFoundException("Cannot find ModelMBeanOperationInfo for operation " + method));
/*      */       }
/*      */     }
/*  612 */     if (logger.isEnabledFor(10)) { logger.debug("Operation info is: " + operInfo);
/*      */     }
/*      */     
/*  615 */     Descriptor operationDescriptor = operInfo.getDescriptor();
/*  616 */     if (operationDescriptor == null) throw new MBeanException(new ServiceNotFoundException("Operation descriptor for operation " + method + " cannot be null"));
/*  617 */     String role = (String)operationDescriptor.getFieldValue("role");
/*  618 */     if ((role == null) || (!role.equals("operation"))) throw new MBeanException(new ServiceNotFoundException("Operation descriptor field 'role' must be 'operation', not " + role));
/*  619 */     if (logger.isEnabledFor(10)) { logger.debug("Operation descriptor is: " + operationDescriptor);
/*      */     }
/*      */     
/*  622 */     Descriptor mbeanDescriptor = info.getMBeanDescriptor();
/*  623 */     if (mbeanDescriptor == null) throw new MBeanException(new ServiceNotFoundException("MBean descriptor cannot be null"));
/*  624 */     if (logger.isEnabledFor(10)) { logger.debug("MBean descriptor is: " + mbeanDescriptor);
/*      */     }
/*  626 */     Object returnValue = null;
/*      */     
/*  628 */     String lastUpdateField = "lastReturnedTimeStamp";
/*      */     
/*      */ 
/*  631 */     int staleness = getStaleness(operationDescriptor, mbeanDescriptor, lastUpdateField);
/*      */     
/*  633 */     if ((staleness == 1) || (staleness == 3))
/*      */     {
/*  635 */       if (logger.isEnabledFor(0)) { logger.trace("Value is stale");
/*      */       }
/*      */       
/*  638 */       Class[] parameters = null;
/*      */       try
/*      */       {
/*  641 */         parameters = Utils.loadClasses(Thread.currentThread().getContextClassLoader(), params);
/*      */       }
/*      */       catch (ClassNotFoundException x)
/*      */       {
/*  645 */         logger.error("Cannot find operation's parameter classes", x);
/*  646 */         throw new ReflectionException(x);
/*      */       }
/*      */       
/*  649 */       if (logger.isEnabledFor(0)) { logger.trace("Invoking operation...");
/*      */       }
/*      */       
/*  652 */       Object target = resolveTargetObject(operationDescriptor);
/*  653 */       returnValue = invokeMethod(target, method, parameters, arguments);
/*      */       
/*  655 */       if (logger.isEnabledFor(10)) { logger.debug("Returned value is: " + returnValue);
/*      */       }
/*  657 */       if (returnValue != null)
/*      */       {
/*  659 */         Class parameter = returnValue.getClass();
/*  660 */         Class declared = loadClassWithContextClassLoader(operInfo.getReturnType());
/*      */         
/*  662 */         checkAssignability(parameter, declared);
/*      */       }
/*      */       
/*      */ 
/*  666 */       if (staleness != 1)
/*      */       {
/*  668 */         operationDescriptor.setField("lastReturnedValue", returnValue);
/*  669 */         operationDescriptor.setField(lastUpdateField, new Long(System.currentTimeMillis()));
/*  670 */         if (logger.isEnabledFor(0))
/*      */         {
/*  672 */           logger.trace("Returned value has been cached");
/*      */         }
/*      */         
/*      */ 
/*  676 */         info.setDescriptor(operationDescriptor, "operation");
/*      */       }
/*      */       
/*  679 */       if (logger.isEnabledFor(10)) { logger.debug("invoke for operation " + method + " returns invoked value: " + returnValue);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  684 */       returnValue = operationDescriptor.getFieldValue("lastReturnedValue");
/*      */       
/*  686 */       if (returnValue != null)
/*      */       {
/*  688 */         Class parameter = returnValue.getClass();
/*  689 */         Class declared = loadClassWithContextClassLoader(operInfo.getReturnType());
/*      */         
/*  691 */         checkAssignability(parameter, declared);
/*      */       }
/*      */       
/*  694 */       if (logger.isEnabledFor(10)) { logger.debug("invoke for operation " + method + " returns cached value: " + returnValue);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  700 */     boolean persistNow = shouldPersistNow(operationDescriptor, null, lastUpdateField);
/*  701 */     int impact = operInfo.getImpact();
/*  702 */     if ((persistNow) && (impact != 0))
/*      */     {
/*  704 */       if (logger.isEnabledFor(0)) logger.trace("Persisting this ModelMBean...");
/*      */       try
/*      */       {
/*  707 */         store();
/*  708 */         if (logger.isEnabledFor(0)) logger.trace("ModelMBean persisted successfully");
/*      */       }
/*      */       catch (Exception x)
/*      */       {
/*  712 */         logger.error("Cannot store ModelMBean after operation invocation", x);
/*  713 */         if ((x instanceof MBeanException)) {
/*  714 */           throw ((MBeanException)x);
/*      */         }
/*  716 */         throw new MBeanException(x);
/*      */       }
/*      */     }
/*      */     
/*  720 */     return returnValue;
/*      */   }
/*      */   
/*      */   private Object resolveTargetObject(Descriptor descriptor) throws MBeanException
/*      */   {
/*  725 */     Logger logger = getLogger();
/*  726 */     Object target = descriptor.getFieldValue("targetObject");
/*  727 */     if (logger.isEnabledFor(0)) logger.trace("targetObject is: " + target);
/*  728 */     if (target == null)
/*      */     {
/*  730 */       target = getManagedResource();
/*      */     }
/*      */     else
/*      */     {
/*  734 */       String targetObjectType = (String)descriptor.getFieldValue("targetObjectType");
/*  735 */       if (logger.isEnabledFor(0)) logger.trace("targetObjectType is: " + targetObjectType);
/*  736 */       if (targetObjectType == null)
/*      */       {
/*      */ 
/*  739 */         targetObjectType = "ObjectReference";
/*      */       }
/*      */       
/*  742 */       if (!isResourceTypeSupported(targetObjectType)) throw new MBeanException(new InvalidTargetObjectTypeException(targetObjectType));
/*      */     }
/*  744 */     return target;
/*      */   }
/*      */   
/*      */   public void load() throws MBeanException, RuntimeOperationsException, InstanceNotFoundException
/*      */   {
/*  749 */     PersisterMBean persister = findPersister();
/*  750 */     if (persister != null)
/*      */     {
/*  752 */       ModelMBeanInfo info = (ModelMBeanInfo)persister.load();
/*  753 */       setModelMBeanInfo(info);
/*      */     }
/*      */   }
/*      */   
/*      */   public void store() throws MBeanException, RuntimeOperationsException, InstanceNotFoundException
/*      */   {
/*  759 */     PersisterMBean persister = findPersister();
/*  760 */     if (persister != null)
/*      */     {
/*      */ 
/*  763 */       ModelMBeanInfo info = (ModelMBeanInfo)getMBeanInfo();
/*  764 */       persister.store(info);
/*      */     }
/*      */   }
/*      */   
/*      */   protected ClassLoaderRepository getClassLoaderRepository()
/*      */   {
/*  770 */     if (this.m_mbeanServer != null) {
/*  771 */       return this.m_mbeanServer.getClassLoaderRepository();
/*      */     }
/*  773 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean shouldPersistNow(Descriptor attribute, Descriptor mbean, String lastUpdateField)
/*      */   {
/*  779 */     int persist = getPersistPolicy(attribute, mbean);
/*  780 */     if (persist == -4)
/*      */     {
/*  782 */       Long period = getFieldTimeValue(attribute, mbean, "persistPeriod");
/*  783 */       long now = System.currentTimeMillis();
/*  784 */       Long lastUpdate = (Long)attribute.getFieldValue(lastUpdateField);
/*  785 */       if (now - lastUpdate.longValue() < period.longValue()) {
/*  786 */         return false;
/*      */       }
/*  788 */       return true;
/*      */     }
/*  790 */     if (persist == -1)
/*      */     {
/*  792 */       return false;
/*      */     }
/*  794 */     if (persist == -2)
/*      */     {
/*  796 */       return false;
/*      */     }
/*  798 */     if (persist == -3)
/*      */     {
/*  800 */       return true;
/*      */     }
/*      */     
/*      */ 
/*  804 */     throw new ImplementationException("Invalid persist value");
/*      */   }
/*      */   
/*      */ 
/*      */   private int getPersistPolicy(Descriptor descriptor, Descriptor mbean)
/*      */   {
/*  810 */     Logger logger = getLogger();
/*      */     
/*  812 */     String persist = (String)descriptor.getFieldValue("persistPolicy");
/*  813 */     if ((persist == null) && (mbean != null)) persist = (String)mbean.getFieldValue("persistPolicy");
/*  814 */     if (persist == null)
/*      */     {
/*  816 */       if (logger.isEnabledFor(0)) logger.trace("No persist policy defined, assuming Never");
/*  817 */       return -1;
/*      */     }
/*      */     
/*      */ 
/*  821 */     if (persist.equals("Never"))
/*      */     {
/*  823 */       if (logger.isEnabledFor(0)) logger.trace("Persist never");
/*  824 */       return -1;
/*      */     }
/*  826 */     if (persist.equals("OnUpdate"))
/*      */     {
/*  828 */       if (logger.isEnabledFor(0)) logger.trace("Persist on update");
/*  829 */       return -3;
/*      */     }
/*  831 */     if (persist.equals("OnTimer"))
/*      */     {
/*  833 */       if (logger.isEnabledFor(0)) logger.trace("Persist on update");
/*  834 */       return -2;
/*      */     }
/*  836 */     if (persist.equals("NoMoreOftenThan"))
/*      */     {
/*  838 */       if (logger.isEnabledFor(0))
/*      */       {
/*  840 */         Long period = getFieldTimeValue(descriptor, mbean, "persistPeriod");
/*  841 */         logger.trace("Persist no more often than " + period);
/*      */       }
/*  843 */       return -4;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  848 */     if (logger.isEnabledFor(0)) logger.trace("Invalid persist policy, assuming persist never");
/*  849 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getStaleness(Descriptor attribute, Descriptor mbean, String lastUpdateField)
/*      */   {
/*  856 */     Logger logger = getLogger();
/*      */     
/*  858 */     Long currencyTimeLimit = getFieldTimeValue(attribute, mbean, "currencyTimeLimit");
/*  859 */     if (currencyTimeLimit == null)
/*      */     {
/*      */ 
/*  862 */       if (logger.isEnabledFor(0)) logger.trace("No currencyTimeLimit defined, assuming always stale");
/*  863 */       return 1;
/*      */     }
/*      */     
/*      */ 
/*  867 */     long ctl = currencyTimeLimit.longValue() * 1000L;
/*  868 */     if (logger.isEnabledFor(0)) { logger.trace("currencyTimeLimit is (ms): " + ctl);
/*      */     }
/*  870 */     if (ctl == 0L)
/*      */     {
/*      */ 
/*  873 */       if (logger.isEnabledFor(0)) logger.trace("Never stale");
/*  874 */       return 2;
/*      */     }
/*  876 */     if (ctl < 0L)
/*      */     {
/*      */ 
/*  879 */       if (logger.isEnabledFor(0)) logger.trace("Always stale");
/*  880 */       return 1;
/*      */     }
/*      */     
/*      */ 
/*  884 */     Long timestamp = (Long)attribute.getFieldValue(lastUpdateField);
/*  885 */     long luts = 0L;
/*      */     
/*  887 */     if (timestamp != null) luts = timestamp.longValue();
/*  888 */     if (logger.isEnabledFor(10)) { logger.debug(lastUpdateField + " is: " + luts);
/*      */     }
/*  890 */     long now = System.currentTimeMillis();
/*  891 */     if (now < luts + ctl)
/*      */     {
/*      */ 
/*  894 */       if (timestamp == null)
/*      */       {
/*      */ 
/*  897 */         if (logger.isEnabledFor(0)) logger.trace("Stale since was never set");
/*  898 */         return 3;
/*      */       }
/*      */       
/*      */ 
/*  902 */       if (logger.isEnabledFor(0)) logger.trace("Not stale");
/*  903 */       return 4;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  909 */     if (logger.isEnabledFor(0)) logger.trace("Stale");
/*  910 */     return 3;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Long getFieldTimeValue(Descriptor descriptor, Descriptor mbean, String field)
/*      */   {
/*  918 */     Logger logger = getLogger();
/*      */     
/*  920 */     Object value = descriptor.getFieldValue(field);
/*  921 */     if (logger.isEnabledFor(10)) { logger.debug("Descriptor's " + field + " field: " + value);
/*      */     }
/*  923 */     if ((value == null) && (mbean != null))
/*      */     {
/*  925 */       value = mbean.getFieldValue(field);
/*  926 */       if (logger.isEnabledFor(10)) logger.debug("MBean's " + field + " field: " + value);
/*  927 */       if (value == null) { return null;
/*      */       }
/*      */     }
/*  930 */     if ((value instanceof Number)) { return new Long(((Number)value).longValue());
/*      */     }
/*  932 */     if ((value instanceof String))
/*      */     {
/*      */       try
/*      */       {
/*  936 */         long ctl = Long.parseLong((String)value);
/*  937 */         return new Long(ctl);
/*      */       }
/*      */       catch (NumberFormatException x)
/*      */       {
/*  941 */         return new Long(0L);
/*      */       }
/*      */     }
/*  944 */     return new Long(0L);
/*      */   }
/*      */   
/*      */   private Object invokeMethod(Object target, String methodName, Class[] params, Object[] args)
/*      */     throws MBeanException, ReflectionException
/*      */   {
/*  950 */     Object realTarget = null;
/*  951 */     Method method = null;
/*      */     try
/*      */     {
/*  954 */       realTarget = this;
/*  955 */       method = realTarget.getClass().getMethod(methodName, params);
/*      */     }
/*      */     catch (NoSuchMethodException x)
/*      */     {
/*  959 */       realTarget = target;
/*      */     }
/*      */     
/*  962 */     if (realTarget == null) { throw new MBeanException(new ServiceNotFoundException("Could not find target"));
/*      */     }
/*  964 */     if (method == null)
/*      */     {
/*      */       try
/*      */       {
/*  968 */         method = realTarget.getClass().getMethod(methodName, params);
/*      */       }
/*      */       catch (NoSuchMethodException x)
/*      */       {
/*  972 */         throw new ReflectionException(x);
/*      */       }
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  978 */       Object value = method.invoke(realTarget, args);
/*  979 */       Logger logger = getLogger();
/*  980 */       if (logger.isEnabledFor(10)) logger.debug("Method invocation returned value: " + value);
/*  981 */       return value;
/*      */     }
/*      */     catch (IllegalAccessException x)
/*      */     {
/*  985 */       throw new ReflectionException(x);
/*      */     }
/*      */     catch (IllegalArgumentException x)
/*      */     {
/*  989 */       throw new MBeanException(x);
/*      */     }
/*      */     catch (InvocationTargetException x)
/*      */     {
/*  993 */       Throwable t = x.getTargetException();
/*  994 */       if ((t instanceof Error)) {
/*  995 */         throw new MBeanException(new RuntimeErrorException((Error)t));
/*      */       }
/*  997 */       throw new MBeanException((Exception)t);
/*      */     }
/*      */   }
/*      */   
/*      */   private Logger getModelMBeanLogger(String notificationType)
/*      */     throws MBeanException
/*      */   {
/* 1004 */     ModelMBeanInfo info = getModelMBeanInfo();
/*      */     
/*      */ 
/* 1007 */     Descriptor descriptor = null;
/* 1008 */     Logger modelMBeanLogger = null;
/* 1009 */     if (notificationType != null)
/*      */     {
/* 1011 */       descriptor = info.getDescriptor(notificationType, "notification");
/* 1012 */       modelMBeanLogger = findLogger(descriptor);
/*      */     }
/*      */     
/* 1015 */     if (modelMBeanLogger == null)
/*      */     {
/* 1017 */       descriptor = info.getMBeanDescriptor();
/* 1018 */       modelMBeanLogger = findLogger(descriptor);
/* 1019 */       if (modelMBeanLogger != null) { return modelMBeanLogger;
/*      */       }
/*      */     }
/* 1022 */     return null;
/*      */   }
/*      */   
/*      */   private Logger findLogger(Descriptor descriptor)
/*      */   {
/* 1027 */     Logger logger = getLogger();
/*      */     
/* 1029 */     if (descriptor == null)
/*      */     {
/* 1031 */       if (logger.isEnabledFor(0)) logger.trace("Can't find MBean logger, descriptor is null");
/* 1032 */       return null;
/*      */     }
/*      */     
/* 1035 */     String log = (String)descriptor.getFieldValue("log");
/* 1036 */     String location = (String)descriptor.getFieldValue("logFile");
/*      */     
/* 1038 */     if (logger.isEnabledFor(10)) { logger.debug("Log fields: log=" + log + ", file=" + location);
/*      */     }
/* 1040 */     if ((log == null) || (!Boolean.valueOf(log).booleanValue()))
/*      */     {
/* 1042 */       if (logger.isEnabledFor(10)) logger.debug("Logging is not supported by this ModelMBean");
/* 1043 */       return null;
/*      */     }
/*      */     
/* 1046 */     if (location == null)
/*      */     {
/*      */ 
/* 1049 */       location = (String)descriptor.getFieldValue("logMBean");
/* 1050 */       if (logger.isEnabledFor(10)) { logger.debug("Log fields: mbean=" + location);
/*      */       }
/* 1052 */       if (location == null)
/*      */       {
/* 1054 */         if (logger.isEnabledFor(0)) logger.trace("Logging is not supported by this ModelMBean");
/* 1055 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */       try
/*      */       {
/* 1061 */         ObjectName objectName = new ObjectName(location);
/* 1062 */         MBeanServer server = getMBeanServer();
/* 1063 */         if (server == null) throw new MBeanException(new IllegalStateException("RequiredModelMBean is not registered"));
/* 1064 */         if (server.isRegistered(objectName))
/*      */         {
/* 1066 */           MBeanLogger l = new MBeanLogger(server, objectName);
/* 1067 */           if (logger.isEnabledFor(10)) logger.debug("ModelMBean log supported by delegating to this MBean: " + objectName);
/* 1068 */           return l;
/*      */         }
/*      */         
/* 1071 */         return null;
/*      */ 
/*      */       }
/*      */       catch (MalformedObjectNameException x)
/*      */       {
/* 1076 */         if (logger.isEnabledFor(10)) logger.debug("Specified logMBean field does not contain a valid ObjectName: " + location);
/* 1077 */         return null;
/*      */       }
/*      */       catch (MBeanException x)
/*      */       {
/* 1081 */         if (logger.isEnabledFor(10)) logger.debug("logMBean field does not specify an MBean that supports logging delegation", x);
/* 1082 */         return null;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1088 */     if (logger.isEnabledFor(10)) logger.debug("ModelMBean log supported on file system");
/* 1089 */     return new FileLogger(location);
/*      */   }
/*      */   
/*      */ 
/*      */   private NotificationBroadcasterSupport getAttributeChangeBroadcaster()
/*      */   {
/* 1095 */     return this.m_attributeChangeBroadcaster;
/*      */   }
/*      */   
/*      */   private MBeanServer getMBeanServer()
/*      */   {
/* 1100 */     return this.m_mbeanServer;
/*      */   }
/*      */   
/*      */ 
/*      */   private ModelMBeanInfo getModelMBeanInfo()
/*      */   {
/* 1106 */     return this.m_modelMBeanInfo;
/*      */   }
/*      */   
/*      */   private PersisterMBean findPersister() throws MBeanException, InstanceNotFoundException
/*      */   {
/* 1111 */     Logger logger = getLogger();
/*      */     
/* 1113 */     ModelMBeanInfo info = getModelMBeanInfo();
/* 1114 */     if (info == null)
/*      */     {
/*      */ 
/* 1117 */       if (logger.isEnabledFor(0)) logger.trace("Can't find persister, ModelMBeanInfo is null");
/* 1118 */       return null;
/*      */     }
/* 1120 */     Descriptor mbeanDescriptor = info.getMBeanDescriptor();
/* 1121 */     if (mbeanDescriptor == null)
/*      */     {
/*      */ 
/* 1124 */       if (logger.isEnabledFor(0)) logger.trace("Can't find persister, MBean descriptor is null");
/* 1125 */       return null;
/*      */     }
/*      */     
/* 1128 */     String location = (String)mbeanDescriptor.getFieldValue("persistLocation");
/* 1129 */     String name = (String)mbeanDescriptor.getFieldValue("persistName");
/* 1130 */     String mbeanName = (String)mbeanDescriptor.getFieldValue("name");
/* 1131 */     if (logger.isEnabledFor(10)) { logger.debug("Persistence fields: location=" + location + ", name=" + name);
/*      */     }
/* 1133 */     if ((mbeanName == null) && (name == null))
/*      */     {
/* 1135 */       if (logger.isEnabledFor(10)) logger.debug("Persistence is not supported by this ModelMBean");
/* 1136 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 1140 */     if (name != null)
/*      */     {
/*      */       try
/*      */       {
/* 1144 */         ObjectName objectName = new ObjectName(name.trim());
/*      */         
/* 1146 */         MBeanServer server = getMBeanServer();
/* 1147 */         if (server == null) { throw new MBeanException(new IllegalStateException("RequiredModelMBean is not registered"));
/*      */         }
/* 1149 */         if ((server.isRegistered(objectName)) && (server.isInstanceOf(objectName, PersisterMBean.class.getName())))
/*      */         {
/*      */ 
/* 1152 */           PersisterMBean persister = new MBeanPersister(server, objectName);
/* 1153 */           if (logger.isEnabledFor(10)) logger.debug("Persistence is delegated to this MBean: " + objectName);
/* 1154 */           return persister;
/*      */         }
/*      */         
/*      */ 
/* 1158 */         throw new InstanceNotFoundException(objectName.toString());
/*      */ 
/*      */       }
/*      */       catch (MalformedObjectNameException ignored)
/*      */       {
/*      */ 
/* 1164 */         if (logger.isEnabledFor(0)) { logger.trace("Persistence is not delegated to another MBean");
/*      */         }
/*      */         
/*      */ 
/* 1168 */         FilePersister persister = new FilePersister(location, name);
/* 1169 */         if (logger.isEnabledFor(10)) logger.debug("Persistence is realized through file system in " + persister.getFileName());
/* 1170 */         return persister;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1175 */     FilePersister persister = new FilePersister(location, mbeanName);
/* 1176 */     if (logger.isEnabledFor(10)) logger.debug("Persistence is realized through file system in " + persister.getFileName());
/* 1177 */     return persister;
/*      */   }
/*      */   
/*      */ 
/*      */   private Class loadClassWithContextClassLoader(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1185 */       return Utils.loadClass(Thread.currentThread().getContextClassLoader(), name);
/*      */     }
/*      */     catch (ClassNotFoundException x)
/*      */     {
/* 1189 */       Logger logger = getLogger();
/* 1190 */       if (logger.isEnabledFor(0)) logger.trace("Cannot find attribute's declared return class", x); }
/* 1191 */     return null;
/*      */   }
/*      */   
/*      */   private void checkAssignability(Class parameter, Class declared)
/*      */     throws MBeanException
/*      */   {
/* 1197 */     Logger logger = getLogger();
/*      */     
/* 1199 */     if (logger.isEnabledFor(10))
/*      */     {
/* 1201 */       logger.debug("The class of the parameter is: " + parameter);
/* 1202 */       if (parameter != null) logger.debug("The classloder of the parameter's class is: " + parameter.getClassLoader());
/* 1203 */       logger.debug("The class declared as type of the attribute is: " + declared);
/* 1204 */       if (declared != null) { logger.debug("The classloader of the declared parameter's class is: " + declared.getClassLoader());
/*      */       }
/*      */     }
/* 1207 */     boolean assignable = false;
/*      */     
/* 1209 */     if ((declared == null) || (parameter == null)) {
/* 1210 */       assignable = false;
/* 1211 */     } else if ((declared == Boolean.TYPE) && (parameter == Boolean.class)) {
/* 1212 */       assignable = true;
/* 1213 */     } else if ((declared == Byte.TYPE) && (parameter == Byte.class)) {
/* 1214 */       assignable = true;
/* 1215 */     } else if ((declared == Character.TYPE) && (parameter == Character.class)) {
/* 1216 */       assignable = true;
/* 1217 */     } else if ((declared == Short.TYPE) && (parameter == Short.class)) {
/* 1218 */       assignable = true;
/* 1219 */     } else if ((declared == Integer.TYPE) && (parameter == Integer.class)) {
/* 1220 */       assignable = true;
/* 1221 */     } else if ((declared == Long.TYPE) && (parameter == Long.class)) {
/* 1222 */       assignable = true;
/* 1223 */     } else if ((declared == Float.TYPE) && (parameter == Float.class)) {
/* 1224 */       assignable = true;
/* 1225 */     } else if ((declared == Double.TYPE) && (parameter == Double.class)) {
/* 1226 */       assignable = true;
/*      */     } else {
/* 1228 */       assignable = declared.isAssignableFrom(parameter);
/*      */     }
/* 1230 */     if (!assignable)
/*      */     {
/* 1232 */       if (logger.isEnabledFor(0)) logger.trace("Parameter value's class and attribute's declared return class are not assignable");
/* 1233 */       throw new MBeanException(new InvalidAttributeValueException("Returned type and declared type are not assignable"));
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/modelmbean/RequiredModelMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */