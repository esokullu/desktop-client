/*     */ package javax.management.modelmbean;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.management.Descriptor;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DescriptorSupport
/*     */   implements Descriptor
/*     */ {
/*     */   private static final long serialVersionUID = -6292969195866300415L;
/*  38 */   private HashMap descriptor = new HashMap(20);
/*  39 */   private transient HashMap fields = new HashMap(20);
/*     */   
/*     */ 
/*     */   public DescriptorSupport() {}
/*     */   
/*     */   public DescriptorSupport(int initNumFields)
/*     */     throws MBeanException, RuntimeOperationsException
/*     */   {
/*  47 */     if (initNumFields <= 0)
/*     */     {
/*  49 */       throw new RuntimeOperationsException(new IllegalArgumentException("Number of Fields cannot be <= 0"));
/*     */     }
/*  51 */     this.descriptor = new HashMap(initNumFields);
/*  52 */     this.fields = new HashMap(initNumFields);
/*     */   }
/*     */   
/*     */   public DescriptorSupport(DescriptorSupport inDescr)
/*     */   {
/*  57 */     if (inDescr != null)
/*     */     {
/*  59 */       setFields(inDescr.getFieldNames(), inDescr.getFieldValues(inDescr.getFieldNames()));
/*     */     }
/*     */   }
/*     */   
/*     */   public DescriptorSupport(String xml) throws MBeanException, RuntimeOperationsException, XMLParseException
/*     */   {
/*  65 */     if (xml == null)
/*     */     {
/*  67 */       throw new RuntimeOperationsException(new IllegalArgumentException("Descriptor XML string is null"));
/*     */     }
/*     */     
/*  70 */     NodeList fields = documentFromXML(xml).getElementsByTagName("field");
/*  71 */     for (int i = 0; i < fields.getLength(); i++)
/*     */     {
/*  73 */       addFieldFromXML(fields.item(i));
/*     */     }
/*     */   }
/*     */   
/*     */   public DescriptorSupport(String[] pairs)
/*     */   {
/*  79 */     if ((pairs != null) && (pairs.length != 0))
/*     */     {
/*  81 */       for (int i = 0; i < pairs.length; i++)
/*     */       {
/*  83 */         String pair = pairs[i];
/*  84 */         if (pair == null)
/*     */         {
/*  86 */           throw new RuntimeOperationsException(new IllegalArgumentException("Illegal pair: " + pair));
/*     */         }
/*  88 */         int equal = pair.indexOf('=');
/*  89 */         if (equal < 1)
/*     */         {
/*  91 */           throw new RuntimeOperationsException(new IllegalArgumentException("Illegal pair: " + pair));
/*     */         }
/*     */         
/*     */ 
/*  95 */         String name = pair.substring(0, equal);
/*  96 */         Object value = null;
/*  97 */         if (equal < pair.length() - 1)
/*     */         {
/*  99 */           value = pair.substring(equal + 1);
/*     */         }
/* 101 */         setField(name, value);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public DescriptorSupport(String[] names, Object[] values)
/*     */   {
/* 109 */     setFields(names, values);
/*     */   }
/*     */   
/*     */   public Object clone() throws RuntimeOperationsException
/*     */   {
/* 114 */     return new DescriptorSupport(this);
/*     */   }
/*     */   
/*     */   public Object getFieldValue(String name) throws RuntimeOperationsException
/*     */   {
/* 119 */     if ((name == null) || (name.trim().length() == 0))
/*     */     {
/* 121 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid field name"));
/*     */     }
/*     */     
/* 124 */     ValueHolder holder = (ValueHolder)this.fields.get(name.toLowerCase());
/* 125 */     return holder == null ? null : holder.fieldValue;
/*     */   }
/*     */   
/*     */   public void setField(String name, Object value) throws RuntimeOperationsException
/*     */   {
/* 130 */     checkField(name, value);
/* 131 */     this.descriptor.put(name, value);
/* 132 */     this.fields.put(name.toLowerCase(), new ValueHolder(name, value, null));
/*     */   }
/*     */   
/*     */   public void removeField(String name)
/*     */   {
/* 137 */     if (name != null)
/*     */     {
/* 139 */       ValueHolder holder = (ValueHolder)this.fields.remove(name.toLowerCase());
/* 140 */       if (holder != null) { this.descriptor.remove(holder.fieldName);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] getFieldNames()
/*     */   {
/* 147 */     String[] names = (String[])this.descriptor.keySet().toArray(new String[0]);
/* 148 */     return names;
/*     */   }
/*     */   
/*     */   public Object[] getFieldValues(String[] names)
/*     */   {
/* 153 */     if (names == null)
/*     */     {
/*     */ 
/* 156 */       Object[] values = this.descriptor.values().toArray(new Object[0]);
/* 157 */       return values;
/*     */     }
/*     */     
/* 160 */     ArrayList list = new ArrayList();
/* 161 */     for (int i = 0; i < names.length; i++)
/*     */     {
/*     */       try
/*     */       {
/* 165 */         Object value = getFieldValue(names[i]);
/* 166 */         list.add(value);
/*     */       }
/*     */       catch (RuntimeOperationsException x)
/*     */       {
/* 170 */         list.add(null);
/*     */       }
/*     */     }
/* 173 */     Object[] values = list.toArray(new Object[list.size()]);
/* 174 */     return values;
/*     */   }
/*     */   
/*     */   public String[] getFields()
/*     */   {
/* 179 */     ArrayList list = new ArrayList();
/* 180 */     StringBuffer buffer = new StringBuffer();
/*     */     
/* 182 */     for (Iterator i = this.descriptor.entrySet().iterator(); i.hasNext();)
/*     */     {
/* 184 */       Map.Entry entry = (Map.Entry)i.next();
/* 185 */       String key = (String)entry.getKey();
/* 186 */       Object value = entry.getValue();
/* 187 */       buffer.setLength(0);
/* 188 */       buffer.append(key);
/* 189 */       buffer.append("=");
/* 190 */       if (value != null)
/*     */       {
/* 192 */         if ((value instanceof String))
/*     */         {
/* 194 */           buffer.append(value.toString());
/*     */         }
/*     */         else
/*     */         {
/* 198 */           buffer.append("(");
/* 199 */           buffer.append(value.toString());
/* 200 */           buffer.append(")");
/*     */         }
/*     */       }
/* 203 */       list.add(buffer.toString());
/*     */     }
/* 205 */     String[] fields = (String[])list.toArray(new String[list.size()]);
/* 206 */     return fields;
/*     */   }
/*     */   
/*     */   public void setFields(String[] names, Object[] values) throws RuntimeOperationsException
/*     */   {
/* 211 */     if ((names == null) || (values == null) || (names.length != values.length))
/*     */     {
/* 213 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid arguments"));
/*     */     }
/*     */     
/* 216 */     for (int i = 0; i < names.length; i++)
/*     */     {
/* 218 */       setField(names[i], values[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isValid() throws RuntimeOperationsException
/*     */   {
/* 224 */     if ((getFieldValue("name") == null) || (getFieldValue("descriptorType") == null)) { return false;
/*     */     }
/*     */     try
/*     */     {
/* 228 */       for (Iterator i = this.descriptor.entrySet().iterator(); i.hasNext();)
/*     */       {
/* 230 */         Map.Entry entry = (Map.Entry)i.next();
/* 231 */         String name = (String)entry.getKey();
/* 232 */         Object value = entry.getValue();
/* 233 */         checkField(name, value);
/*     */       }
/* 235 */       return true;
/*     */     }
/*     */     catch (RuntimeOperationsException x) {}
/*     */     
/* 239 */     return false;
/*     */   }
/*     */   
/*     */   public String toXMLString()
/*     */     throws RuntimeOperationsException
/*     */   {
/* 245 */     StringBuffer buf = new StringBuffer(32);
/* 246 */     buf.append("<Descriptor>");
/*     */     
/*     */     try
/*     */     {
/* 250 */       if (this.descriptor.size() != 0)
/*     */       {
/* 252 */         Iterator i = this.descriptor.entrySet().iterator();
/* 253 */         while (i.hasNext())
/*     */         {
/*     */ 
/* 256 */           Map.Entry entry = (Map.Entry)i.next();
/* 257 */           Object value = entry.getValue();
/* 258 */           String valstr = toXMLValueString(value);
/* 259 */           buf.append("<field name=\"");
/* 260 */           buf.append(entry.getKey());
/* 261 */           buf.append("\" value=\"");
/* 262 */           buf.append(valstr);
/* 263 */           buf.append("\"></field>");
/*     */         }
/*     */       }
/* 266 */       buf.append("</Descriptor>");
/* 267 */       return buf.toString();
/*     */     }
/*     */     catch (RuntimeException x)
/*     */     {
/* 271 */       throw new RuntimeOperationsException(x);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() throws RuntimeOperationsException
/*     */   {
/* 277 */     StringBuffer buf = new StringBuffer();
/*     */     try {
/*     */       Iterator i;
/* 280 */       if (this.descriptor.size() != 0)
/*     */       {
/* 282 */         for (i = this.descriptor.entrySet().iterator(); i.hasNext();)
/*     */         {
/* 284 */           Map.Entry entry = (Map.Entry)i.next();
/* 285 */           buf.append(entry.getKey()).append(" ").append(entry.getValue());
/* 286 */           if (i.hasNext())
/*     */           {
/* 288 */             buf.append(",");
/*     */           }
/*     */         }
/*     */       }
/* 292 */       return buf.toString();
/*     */     }
/*     */     catch (RuntimeOperationsException x) {}
/*     */     
/*     */ 
/* 297 */     return buf.toString();
/*     */   }
/*     */   
/*     */   private void addFieldFromXML(Node n)
/*     */     throws XMLParseException, DOMException, RuntimeOperationsException
/*     */   {
/* 303 */     if (!(n instanceof Element))
/*     */     {
/* 305 */       throw new XMLParseException("Invalid XML descriptor entity");
/*     */     }
/*     */     
/*     */ 
/* 309 */     NamedNodeMap attributes = n.getAttributes();
/* 310 */     if ((attributes.getLength() != 2) && ((attributes.getNamedItem("name") == null) || (attributes.getNamedItem("value") == null)))
/*     */     {
/*     */ 
/*     */ 
/* 314 */       throw new XMLParseException("Invalid XML descriptor element");
/*     */     }
/*     */     
/*     */ 
/* 318 */     String name = attributes.getNamedItem("name").getNodeValue();
/*     */     
/* 320 */     String value = attributes.getNamedItem("value").getNodeValue();
/*     */     
/* 322 */     setField(name, parseValueString(value));
/*     */   }
/*     */   
/*     */ 
/*     */   private void checkField(String name, Object value)
/*     */     throws RuntimeOperationsException
/*     */   {
/* 329 */     if ((name == null) || (name.trim().length() == 0))
/*     */     {
/* 331 */       throw new RuntimeOperationsException(new IllegalArgumentException("Illegal field name"));
/*     */     }
/*     */     
/* 334 */     boolean isValid = true;
/*     */     
/* 336 */     if (name.equalsIgnoreCase("name"))
/*     */     {
/* 338 */       isValid = (value != null) && ((value instanceof String)) && (((String)value).length() != 0);
/*     */     }
/* 340 */     else if (name.equalsIgnoreCase("descriptorType"))
/*     */     {
/* 342 */       isValid = (value != null) && ((value.toString().equalsIgnoreCase("MBean")) || (value.toString().equalsIgnoreCase("attribute")) || (value.toString().equalsIgnoreCase("operation")) || (value.toString().equalsIgnoreCase("notification")));
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 347 */     else if (name.equalsIgnoreCase("role"))
/*     */     {
/* 349 */       isValid = (value != null) && ((value.equals("constructor")) || (value.equals("operation")) || (value.equals("getter")) || (value.equals("setter")));
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 354 */     else if (name.equalsIgnoreCase("persistPolicy"))
/*     */     {
/* 356 */       isValid = (value != null) && ((value.toString().equalsIgnoreCase("Never")) || (value.toString().equalsIgnoreCase("OnTimer")) || (value.toString().equalsIgnoreCase("OnUpdate")) || (value.toString().equalsIgnoreCase("NoMoreOftenThan")) || (value.toString().equalsIgnoreCase("Always")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 362 */     else if (name.equalsIgnoreCase("persistPeriod"))
/*     */     {
/* 364 */       int v = objectToInt(value);
/* 365 */       isValid = v >= -1;
/*     */     }
/* 367 */     else if (name.equalsIgnoreCase("currencyTimeLimit"))
/*     */     {
/* 369 */       int v = objectToInt(value);
/* 370 */       isValid = v >= -1;
/*     */     }
/* 372 */     else if (name.equalsIgnoreCase("visibility"))
/*     */     {
/* 374 */       int v = objectToInt(value);
/* 375 */       isValid = (v >= 1) && (v <= 4);
/*     */     }
/* 377 */     else if ((name.equalsIgnoreCase("getMethod")) || (name.equalsIgnoreCase("setMethod")))
/*     */     {
/* 379 */       isValid = (value != null) && (value.toString().trim().length() > 0);
/*     */     }
/* 381 */     else if (name.equalsIgnoreCase("protocolMap"))
/*     */     {
/* 383 */       isValid = value instanceof Descriptor;
/*     */     }
/* 385 */     else if (name.equalsIgnoreCase("lastUpdatedTimeStamp"))
/*     */     {
/* 387 */       long v = objectToLong(value);
/* 388 */       isValid = v > 0L;
/*     */     }
/* 390 */     else if (name.equalsIgnoreCase("severity"))
/*     */     {
/* 392 */       int v = objectToInt(value);
/* 393 */       isValid = (v >= 0) && (v <= 6);
/*     */     }
/* 395 */     else if (name.equalsIgnoreCase("messageId"))
/*     */     {
/* 397 */       isValid = value != null;
/*     */     }
/* 399 */     else if (name.equalsIgnoreCase("log"))
/*     */     {
/* 401 */       isValid = (value != null) && (((value instanceof Boolean)) || (((value instanceof String)) && ((value.toString().equalsIgnoreCase("true")) || (value.toString().equalsIgnoreCase("false")) || (value.toString().equalsIgnoreCase("t")) || (value.toString().equalsIgnoreCase("f")))));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 409 */     if (!isValid)
/*     */     {
/* 411 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid value '" + value + "' for field " + name));
/*     */     }
/*     */   }
/*     */   
/*     */   private Document documentFromXML(String xml) throws XMLParseException
/*     */   {
/*     */     try
/*     */     {
/* 419 */       DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/*     */       
/* 421 */       return db.parse(new ByteArrayInputStream(xml.getBytes()));
/*     */ 
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/* 426 */       throw new XMLParseException(x.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private Class getObjectValueClass(String value) throws XMLParseException
/*     */   {
/* 432 */     int eoc = value.indexOf("/");
/* 433 */     if (eoc == -1)
/*     */     {
/* 435 */       throw new XMLParseException("Illegal XML descriptor class name");
/*     */     }
/* 437 */     String klass = value.substring(1, eoc);
/* 438 */     Class result = null;
/*     */     try
/*     */     {
/* 441 */       result = Thread.currentThread().getContextClassLoader().loadClass(klass);
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/* 445 */       throw new XMLParseException(x.toString());
/*     */     }
/* 447 */     return result;
/*     */   }
/*     */   
/*     */   private String getObjectValueString(String value) throws XMLParseException
/*     */   {
/* 452 */     int bov = value.indexOf("/");
/* 453 */     if (bov == -1)
/*     */     {
/* 455 */       throw new XMLParseException("Illegal XML descriptor object value");
/*     */     }
/* 457 */     return value.substring(bov + 1, value.length() - 1);
/*     */   }
/*     */   
/*     */   private String objectClassToID(Class k)
/*     */   {
/* 462 */     StringBuffer result = new StringBuffer();
/* 463 */     result.append(k.getName());
/* 464 */     result.append("/");
/* 465 */     return result.toString();
/*     */   }
/*     */   
/*     */   private int objectToInt(Object obj) throws RuntimeOperationsException
/*     */   {
/*     */     try
/*     */     {
/* 472 */       return Integer.parseInt(obj.toString());
/*     */     }
/*     */     catch (NumberFormatException x)
/*     */     {
/* 476 */       throw new RuntimeOperationsException(new IllegalArgumentException("Illegal value '" + obj + "' for numeric field"));
/*     */     }
/*     */     catch (NullPointerException x)
/*     */     {
/* 480 */       throw new RuntimeOperationsException(new IllegalArgumentException("Illegal value '" + obj + "' for numeric field"));
/*     */     }
/*     */   }
/*     */   
/*     */   private long objectToLong(Object obj) throws RuntimeOperationsException
/*     */   {
/*     */     try
/*     */     {
/* 488 */       return Long.parseLong(obj.toString());
/*     */     }
/*     */     catch (NumberFormatException x)
/*     */     {
/* 492 */       throw new RuntimeOperationsException(new IllegalArgumentException("Illegal value '" + obj + "' for numeric field"));
/*     */     }
/*     */     catch (NullPointerException x)
/*     */     {
/* 496 */       throw new RuntimeOperationsException(new IllegalArgumentException("Illegal value '" + obj + "' for numeric field"));
/*     */     }
/*     */   }
/*     */   
/*     */   private Object parseValueString(String value) throws XMLParseException
/*     */   {
/* 502 */     Object result = null;
/* 503 */     if (value.compareToIgnoreCase("(null)") == 0)
/*     */     {
/* 505 */       result = null;
/*     */     }
/* 507 */     else if (value.charAt(0) != '(')
/*     */     {
/* 509 */       result = value;
/*     */     }
/*     */     else
/*     */     {
/* 513 */       result = parseObjectValueString(value);
/*     */     }
/* 515 */     return result;
/*     */   }
/*     */   
/*     */   private Object parseObjectValueString(String value) throws XMLParseException
/*     */   {
/* 520 */     if (value.charAt(value.length() - 1) != ')')
/*     */     {
/* 522 */       throw new XMLParseException("Invalid XML descriptor value");
/*     */     }
/*     */     
/* 525 */     Object result = null;
/* 526 */     Class k = getObjectValueClass(value);
/* 527 */     String s = getObjectValueString(value);
/*     */     try
/*     */     {
/* 530 */       if (k != Character.class)
/*     */       {
/* 532 */         result = k.getConstructor(new Class[] { String.class }).newInstance(new Object[] { s });
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 537 */         result = new Character(s.charAt(0));
/*     */       }
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/* 542 */       throw new XMLParseException(x.toString());
/*     */     }
/* 544 */     return result;
/*     */   }
/*     */   
/*     */   private String toXMLValueString(Object value) {
/*     */     String result;
/*     */     String result;
/* 550 */     if (value == null)
/*     */     {
/* 552 */       result = "(null)";
/*     */     }
/*     */     else
/*     */     {
/* 556 */       Class k = value.getClass();
/* 557 */       String result; if ((k == String.class) && (((String)value).charAt(0) != '('))
/*     */       {
/* 559 */         result = (String)value;
/*     */       }
/*     */       else
/*     */       {
/* 563 */         result = toObjectXMLValueString(k, value);
/*     */       }
/*     */     }
/* 566 */     return result;
/*     */   }
/*     */   
/*     */   private String toObjectXMLValueString(Class k, Object value)
/*     */   {
/* 571 */     StringBuffer result = new StringBuffer();
/* 572 */     result.append("(");
/* 573 */     result.append(objectClassToID(k));
/* 574 */     result.append(value.toString());
/* 575 */     result.append(")");
/* 576 */     return result.toString();
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
/*     */   {
/* 581 */     stream.defaultReadObject();
/* 582 */     this.fields = new HashMap(this.descriptor.size());
/* 583 */     for (Iterator i = this.descriptor.entrySet().iterator(); i.hasNext();)
/*     */     {
/* 585 */       Map.Entry entry = (Map.Entry)i.next();
/* 586 */       String name = (String)entry.getKey();
/* 587 */       this.fields.put(name.toLowerCase(), new ValueHolder(name, entry.getValue(), null)); } }
/*     */   
/*     */   private static class ValueHolder { private final String fieldName;
/*     */     
/* 591 */     ValueHolder(String x0, Object x1, DescriptorSupport.1 x2) { this(x0, x1); }
/*     */     
/*     */ 
/*     */     private final Object fieldValue;
/*     */     
/*     */     private ValueHolder(String fieldName, Object value)
/*     */     {
/* 598 */       this.fieldName = fieldName;
/* 599 */       this.fieldValue = value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/modelmbean/DescriptorSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */