/*     */ package javax.management.modelmbean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.management.Descriptor;
/*     */ import javax.management.DescriptorAccess;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanConstructorInfo;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanFeatureInfo;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelMBeanInfoSupport
/*     */   extends MBeanInfo
/*     */   implements ModelMBeanInfo, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -1935722590756516193L;
/*     */   private Descriptor modelMBeanDescriptor;
/*     */   private MBeanAttributeInfo[] modelMBeanAttributes;
/*     */   private MBeanConstructorInfo[] modelMBeanConstructors;
/*     */   private MBeanNotificationInfo[] modelMBeanNotifications;
/*     */   private MBeanOperationInfo[] modelMBeanOperations;
/*     */   
/*     */   public ModelMBeanInfoSupport(String className, String description, ModelMBeanAttributeInfo[] attributes, ModelMBeanConstructorInfo[] constructors, ModelMBeanOperationInfo[] operations, ModelMBeanNotificationInfo[] notifications)
/*     */   {
/*  45 */     this(className, description, attributes, constructors, operations, notifications, null);
/*     */   }
/*     */   
/*     */   public ModelMBeanInfoSupport(String className, String description, ModelMBeanAttributeInfo[] attributes, ModelMBeanConstructorInfo[] constructors, ModelMBeanOperationInfo[] operations, ModelMBeanNotificationInfo[] notifications, Descriptor mbeanDescriptor)
/*     */   {
/*  50 */     super(className, description, attributes, constructors, operations, notifications);
/*  51 */     this.modelMBeanAttributes = attributes;
/*  52 */     this.modelMBeanConstructors = constructors;
/*  53 */     this.modelMBeanNotifications = notifications;
/*  54 */     this.modelMBeanOperations = operations;
/*  55 */     checkAndSetDescriptor(mbeanDescriptor);
/*     */   }
/*     */   
/*     */   public ModelMBeanInfoSupport(ModelMBeanInfo model)
/*     */   {
/*  60 */     super(model.getClassName(), model.getDescription(), model.getAttributes(), model.getConstructors(), model.getOperations(), model.getNotifications());
/*  61 */     if (model.getAttributes() != null)
/*     */     {
/*     */ 
/*  64 */       MBeanAttributeInfo[] attributes = model.getAttributes();
/*  65 */       this.modelMBeanAttributes = new ModelMBeanAttributeInfo[attributes.length];
/*  66 */       for (int i = 0; i < attributes.length; i++)
/*     */       {
/*  68 */         MBeanAttributeInfo attribute = attributes[i];
/*  69 */         if ((attribute instanceof ModelMBeanAttributeInfo)) {
/*  70 */           this.modelMBeanAttributes[i] = new ModelMBeanAttributeInfo((ModelMBeanAttributeInfo)attribute);
/*     */         } else
/*  72 */           this.modelMBeanAttributes[i] = new ModelMBeanAttributeInfo(attribute.getName(), attribute.getType(), attribute.getDescription(), attribute.isReadable(), attribute.isWritable(), attribute.isIs());
/*     */       }
/*     */     }
/*  75 */     if (model.getConstructors() != null)
/*     */     {
/*     */ 
/*  78 */       MBeanConstructorInfo[] constructors = model.getConstructors();
/*  79 */       this.modelMBeanConstructors = new ModelMBeanConstructorInfo[constructors.length];
/*  80 */       for (int i = 0; i < constructors.length; i++)
/*     */       {
/*  82 */         MBeanConstructorInfo constructor = constructors[i];
/*  83 */         if ((constructor instanceof ModelMBeanConstructorInfo)) {
/*  84 */           this.modelMBeanConstructors[i] = new ModelMBeanConstructorInfo((ModelMBeanConstructorInfo)constructor);
/*     */         } else
/*  86 */           this.modelMBeanConstructors[i] = new ModelMBeanConstructorInfo(constructor.getName(), constructor.getDescription(), constructor.getSignature());
/*     */       }
/*     */     }
/*  89 */     if (model.getOperations() != null)
/*     */     {
/*     */ 
/*  92 */       MBeanOperationInfo[] operations = model.getOperations();
/*  93 */       this.modelMBeanOperations = new ModelMBeanOperationInfo[operations.length];
/*  94 */       for (int i = 0; i < operations.length; i++)
/*     */       {
/*  96 */         MBeanOperationInfo operation = operations[i];
/*  97 */         if ((operation instanceof ModelMBeanOperationInfo)) {
/*  98 */           this.modelMBeanOperations[i] = new ModelMBeanOperationInfo((ModelMBeanOperationInfo)operation);
/*     */         } else
/* 100 */           this.modelMBeanOperations[i] = new ModelMBeanOperationInfo(operation.getName(), operation.getDescription(), operation.getSignature(), operation.getReturnType(), operation.getImpact());
/*     */       }
/*     */     }
/* 103 */     if (model.getNotifications() != null)
/*     */     {
/*     */ 
/* 106 */       MBeanNotificationInfo[] notifications = model.getNotifications();
/* 107 */       this.modelMBeanNotifications = new ModelMBeanNotificationInfo[notifications.length];
/* 108 */       for (int i = 0; i < notifications.length; i++)
/*     */       {
/* 110 */         MBeanNotificationInfo notification = notifications[i];
/* 111 */         if ((notification instanceof ModelMBeanNotificationInfo)) {
/* 112 */           this.modelMBeanNotifications[i] = new ModelMBeanNotificationInfo((ModelMBeanNotificationInfo)notification);
/*     */         } else
/* 114 */           this.modelMBeanNotifications[i] = new ModelMBeanNotificationInfo(notification.getNotifTypes(), notification.getName(), notification.getDescription());
/*     */       }
/*     */     }
/* 117 */     Descriptor mBeanDescriptor = null;
/*     */     try
/*     */     {
/* 120 */       mBeanDescriptor = model.getMBeanDescriptor();
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/*     */ 
/*     */ 
/* 126 */     checkAndSetDescriptor(mBeanDescriptor);
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 131 */     return new ModelMBeanInfoSupport(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Descriptor[] getDescriptors(String type)
/*     */     throws MBeanException, RuntimeOperationsException
/*     */   {
/* 139 */     if (type == null)
/*     */     {
/* 141 */       Descriptor[] attrs = getDescriptors("attribute");
/* 142 */       Descriptor[] opers = getDescriptors("operation");
/* 143 */       Descriptor[] ctors = getDescriptors("constructor");
/* 144 */       Descriptor[] notifs = getDescriptors("notification");
/* 145 */       Descriptor[] all = new Descriptor[attrs.length + opers.length + ctors.length + notifs.length + 1];
/* 146 */       int i = 0;
/* 147 */       all[i] = getMBeanDescriptor();
/* 148 */       i++;
/* 149 */       System.arraycopy(attrs, 0, all, i, attrs.length);
/* 150 */       i += attrs.length;
/* 151 */       System.arraycopy(opers, 0, all, i, opers.length);
/* 152 */       i += opers.length;
/* 153 */       System.arraycopy(ctors, 0, all, i, ctors.length);
/* 154 */       i += ctors.length;
/* 155 */       System.arraycopy(notifs, 0, all, i, notifs.length);
/*     */       
/* 157 */       return all;
/*     */     }
/* 159 */     if (type.equals("mbean"))
/*     */     {
/* 161 */       return new Descriptor[] { getMBeanDescriptor() };
/*     */     }
/* 163 */     if (type.equals("attribute"))
/*     */     {
/* 165 */       MBeanAttributeInfo[] attrs = this.modelMBeanAttributes;
/* 166 */       if (attrs == null)
/*     */       {
/* 168 */         return new Descriptor[0];
/*     */       }
/* 170 */       Descriptor[] attributes = new Descriptor[attrs.length];
/* 171 */       for (int i = 0; i < attrs.length; i++)
/*     */       {
/* 173 */         ModelMBeanAttributeInfo attr = (ModelMBeanAttributeInfo)attrs[i];
/*     */         
/* 175 */         attributes[i] = attr.getDescriptor();
/*     */       }
/* 177 */       return attributes;
/*     */     }
/* 179 */     if (type.equals("operation"))
/*     */     {
/* 181 */       MBeanOperationInfo[] opers = this.modelMBeanOperations;
/* 182 */       if (opers == null)
/*     */       {
/* 184 */         return new Descriptor[0];
/*     */       }
/* 186 */       Descriptor[] operations = new Descriptor[opers.length];
/* 187 */       for (int i = 0; i < opers.length; i++)
/*     */       {
/* 189 */         ModelMBeanOperationInfo oper = (ModelMBeanOperationInfo)opers[i];
/*     */         
/* 191 */         operations[i] = oper.getDescriptor();
/*     */       }
/* 193 */       return operations;
/*     */     }
/* 195 */     if (type.equals("constructor"))
/*     */     {
/* 197 */       MBeanConstructorInfo[] ctors = this.modelMBeanConstructors;
/* 198 */       if (ctors == null)
/*     */       {
/* 200 */         return new Descriptor[0];
/*     */       }
/* 202 */       Descriptor[] constructors = new Descriptor[ctors.length];
/* 203 */       for (int i = 0; i < ctors.length; i++)
/*     */       {
/* 205 */         ModelMBeanConstructorInfo ctor = (ModelMBeanConstructorInfo)ctors[i];
/*     */         
/* 207 */         constructors[i] = ctor.getDescriptor();
/*     */       }
/* 209 */       return constructors;
/*     */     }
/* 211 */     if (type.equals("notification"))
/*     */     {
/* 213 */       MBeanNotificationInfo[] notifs = this.modelMBeanNotifications;
/* 214 */       if (notifs == null)
/*     */       {
/* 216 */         return new Descriptor[0];
/*     */       }
/* 218 */       Descriptor[] notifications = new Descriptor[notifs.length];
/* 219 */       for (int i = 0; i < notifs.length; i++)
/*     */       {
/* 221 */         ModelMBeanNotificationInfo notif = (ModelMBeanNotificationInfo)notifs[i];
/*     */         
/* 223 */         notifications[i] = notif.getDescriptor();
/*     */       }
/* 225 */       return notifications;
/*     */     }
/*     */     
/*     */ 
/* 229 */     throw new RuntimeOperationsException(new IllegalArgumentException("Invalid descriptor type"));
/*     */   }
/*     */   
/*     */   public void setDescriptors(Descriptor[] descriptors)
/*     */     throws MBeanException, RuntimeOperationsException
/*     */   {
/* 235 */     if (descriptors == null)
/*     */     {
/* 237 */       throw new RuntimeOperationsException(new IllegalArgumentException("Descriptors cannot be null"));
/*     */     }
/* 239 */     RuntimeOperationsException x = null;
/* 240 */     for (int i = 0; i < descriptors.length; i++)
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/*     */ 
/* 246 */         setDescriptor(descriptors[i], null);
/*     */       }
/*     */       catch (RuntimeOperationsException ignored)
/*     */       {
/* 250 */         x = ignored;
/*     */       }
/*     */     }
/*     */     
/* 254 */     if (x != null)
/*     */     {
/* 256 */       throw x;
/*     */     }
/*     */   }
/*     */   
/*     */   public Descriptor getDescriptor(String name) throws MBeanException, RuntimeOperationsException
/*     */   {
/* 262 */     return getDescriptor(name, null);
/*     */   }
/*     */   
/*     */   public Descriptor getDescriptor(String name, String type) throws MBeanException, RuntimeOperationsException
/*     */   {
/* 267 */     if (name == null)
/*     */     {
/* 269 */       throw new RuntimeOperationsException(new IllegalArgumentException("Descriptor name cannot be null"));
/*     */     }
/*     */     
/*     */ 
/* 273 */     if ("MBean".equals(type))
/*     */     {
/* 275 */       return getMBeanDescriptor();
/*     */     }
/* 277 */     if (type != null)
/*     */     {
/* 279 */       Descriptor[] descrs = getDescriptors(type);
/* 280 */       for (int i = 0; i < descrs.length; i++)
/*     */       {
/* 282 */         Descriptor descr = descrs[i];
/* 283 */         if (name.equals(descr.getFieldValue("name")))
/*     */         {
/*     */ 
/* 286 */           return descr;
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 293 */       Descriptor result = findDescriptorByName(this.modelMBeanAttributes, name);
/* 294 */       if (result != null)
/*     */       {
/* 296 */         return result;
/*     */       }
/* 298 */       result = findDescriptorByName(this.modelMBeanConstructors, name);
/* 299 */       if (result != null)
/*     */       {
/* 301 */         return result;
/*     */       }
/* 303 */       result = findDescriptorByName(this.modelMBeanNotifications, name);
/* 304 */       if (result != null)
/*     */       {
/* 306 */         return result;
/*     */       }
/* 308 */       result = findDescriptorByName(this.modelMBeanOperations, name);
/* 309 */       if (result != null)
/*     */       {
/* 311 */         return result;
/*     */       }
/*     */     }
/* 314 */     return null;
/*     */   }
/*     */   
/*     */   public void setDescriptor(Descriptor descriptor, String descriptorType)
/*     */     throws MBeanException, RuntimeOperationsException
/*     */   {
/* 320 */     if (descriptor == null)
/*     */     {
/* 322 */       return;
/*     */     }
/* 324 */     if (descriptorType == null)
/*     */     {
/* 326 */       descriptorType = (String)descriptor.getFieldValue("descriptorType");
/*     */       
/* 328 */       if (descriptorType == null)
/*     */       {
/* 330 */         throw new RuntimeOperationsException(new IllegalArgumentException("Field descriptorType in the given descriptor is not valid"));
/*     */       }
/*     */       
/* 333 */       if (descriptorType.equals("operation"))
/*     */       {
/*     */ 
/* 336 */         String role = (String)descriptor.getFieldValue("role");
/* 337 */         if (role == null)
/*     */         {
/* 339 */           throw new RuntimeOperationsException(new IllegalArgumentException("Field role in the given descriptor is not valid"));
/*     */         }
/*     */         
/* 342 */         descriptorType = role;
/*     */       }
/*     */     }
/*     */     
/* 346 */     String name = (String)descriptor.getFieldValue("name");
/* 347 */     if (name == null)
/*     */     {
/* 349 */       throw new RuntimeOperationsException(new IllegalArgumentException("Field name in the given descriptor is not valid"));
/*     */     }
/*     */     
/*     */ 
/* 353 */     if (descriptorType.equals("MBean"))
/*     */     {
/* 355 */       setMBeanDescriptor(descriptor);
/*     */     }
/* 357 */     else if (descriptorType.equals("attribute"))
/*     */     {
/* 359 */       MBeanAttributeInfo[] attrs = this.modelMBeanAttributes;
/* 360 */       if (attrs != null)
/*     */       {
/* 362 */         for (int i = 0; i < attrs.length; i++)
/*     */         {
/* 364 */           ModelMBeanAttributeInfo attr = (ModelMBeanAttributeInfo)attrs[i];
/* 365 */           if (name.equals(attr.getName()))
/*     */           {
/*     */ 
/* 368 */             attr.setDescriptor(descriptor);
/* 369 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 374 */     else if (descriptorType.equals("notification"))
/*     */     {
/* 376 */       MBeanNotificationInfo[] notifs = this.modelMBeanNotifications;
/* 377 */       if (notifs != null)
/*     */       {
/* 379 */         for (int i = 0; i < notifs.length; i++)
/*     */         {
/* 381 */           ModelMBeanNotificationInfo notif = (ModelMBeanNotificationInfo)notifs[i];
/* 382 */           if (name.equals(notif.getName()))
/*     */           {
/*     */ 
/* 385 */             notif.setDescriptor(descriptor);
/* 386 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 391 */     else if (descriptorType.equals("constructor"))
/*     */     {
/* 393 */       MBeanConstructorInfo[] ctors = this.modelMBeanConstructors;
/* 394 */       if (ctors != null)
/*     */       {
/* 396 */         for (int i = 0; i < ctors.length; i++)
/*     */         {
/* 398 */           ModelMBeanConstructorInfo ctor = (ModelMBeanConstructorInfo)ctors[i];
/* 399 */           if (name.equals(ctor.getName()))
/*     */           {
/*     */ 
/* 402 */             ctor.setDescriptor(descriptor);
/* 403 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 408 */     else if (descriptorType.equals("operation"))
/*     */     {
/* 410 */       MBeanOperationInfo[] opers = this.modelMBeanOperations;
/* 411 */       if (opers != null)
/*     */       {
/* 413 */         for (int i = 0; i < opers.length; i++)
/*     */         {
/* 415 */           ModelMBeanOperationInfo oper = (ModelMBeanOperationInfo)opers[i];
/* 416 */           if (name.equals(oper.getName()))
/*     */           {
/*     */ 
/* 419 */             oper.setDescriptor(descriptor);
/* 420 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public ModelMBeanAttributeInfo getAttribute(String name) throws MBeanException, RuntimeOperationsException
/*     */   {
/* 429 */     if (name == null)
/*     */     {
/* 431 */       throw new RuntimeOperationsException(new IllegalArgumentException("Name argument cannot be null"));
/*     */     }
/* 433 */     MBeanAttributeInfo[] attrs = this.modelMBeanAttributes;
/* 434 */     if (attrs != null)
/*     */     {
/* 436 */       for (int i = 0; i < attrs.length; i++)
/*     */       {
/* 438 */         ModelMBeanAttributeInfo attr = (ModelMBeanAttributeInfo)attrs[i];
/* 439 */         if (name.equals(attr.getName()))
/*     */         {
/*     */ 
/* 442 */           return (ModelMBeanAttributeInfo)attr.clone();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 447 */     return null;
/*     */   }
/*     */   
/*     */   public ModelMBeanOperationInfo getOperation(String name) throws MBeanException, RuntimeOperationsException
/*     */   {
/* 452 */     if (name == null)
/*     */     {
/* 454 */       throw new RuntimeOperationsException(new IllegalArgumentException("Name argument cannot be null"));
/*     */     }
/* 456 */     MBeanOperationInfo[] opers = this.modelMBeanOperations;
/* 457 */     if (opers != null)
/*     */     {
/* 459 */       for (int i = 0; i < opers.length; i++)
/*     */       {
/* 461 */         ModelMBeanOperationInfo oper = (ModelMBeanOperationInfo)opers[i];
/* 462 */         if (name.equals(oper.getName()))
/*     */         {
/*     */ 
/* 465 */           return (ModelMBeanOperationInfo)oper.clone();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 470 */     return null;
/*     */   }
/*     */   
/*     */   public ModelMBeanConstructorInfo getConstructor(String name) throws MBeanException, RuntimeOperationsException
/*     */   {
/* 475 */     if (name == null)
/*     */     {
/* 477 */       throw new RuntimeOperationsException(new IllegalArgumentException("Name argument cannot be null"));
/*     */     }
/* 479 */     MBeanConstructorInfo[] ctors = this.modelMBeanConstructors;
/* 480 */     if (ctors != null)
/*     */     {
/* 482 */       for (int i = 0; i < ctors.length; i++)
/*     */       {
/* 484 */         ModelMBeanConstructorInfo ctor = (ModelMBeanConstructorInfo)ctors[i];
/* 485 */         if (name.equals(ctor.getName()))
/*     */         {
/*     */ 
/* 488 */           return (ModelMBeanConstructorInfo)ctor.clone();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 493 */     return null;
/*     */   }
/*     */   
/*     */   public ModelMBeanNotificationInfo getNotification(String name) throws MBeanException, RuntimeOperationsException
/*     */   {
/* 498 */     if (name == null)
/*     */     {
/* 500 */       throw new RuntimeOperationsException(new IllegalArgumentException("Name argument cannot be null"));
/*     */     }
/* 502 */     MBeanNotificationInfo[] notifs = this.modelMBeanNotifications;
/* 503 */     if (notifs != null)
/*     */     {
/* 505 */       for (int i = 0; i < notifs.length; i++)
/*     */       {
/* 507 */         ModelMBeanNotificationInfo notif = (ModelMBeanNotificationInfo)notifs[i];
/* 508 */         if (name.equals(notif.getName()))
/*     */         {
/*     */ 
/* 511 */           return (ModelMBeanNotificationInfo)notif.clone();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 516 */     return null;
/*     */   }
/*     */   
/*     */   public Descriptor getMBeanDescriptor() throws MBeanException, RuntimeOperationsException
/*     */   {
/* 521 */     return (Descriptor)this.modelMBeanDescriptor.clone();
/*     */   }
/*     */   
/*     */   public void setMBeanDescriptor(Descriptor descriptor) throws MBeanException, RuntimeOperationsException
/*     */   {
/* 526 */     if (descriptor == null)
/*     */     {
/*     */ 
/* 529 */       this.modelMBeanDescriptor = createDefaultMBeanDescriptor();
/*     */ 
/*     */ 
/*     */     }
/* 533 */     else if (isDescriptorValid(descriptor))
/*     */     {
/* 535 */       this.modelMBeanDescriptor = ((Descriptor)descriptor.clone());
/*     */     }
/*     */     else
/*     */     {
/* 539 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid descriptor"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MBeanConstructorInfo[] getConstructors()
/*     */   {
/* 547 */     MBeanConstructorInfo[] ctors = this.modelMBeanConstructors;
/* 548 */     if (ctors == null)
/*     */     {
/* 550 */       return null;
/*     */     }
/* 552 */     ModelMBeanConstructorInfo[] constructors = new ModelMBeanConstructorInfo[ctors.length];
/* 553 */     for (int i = 0; i < ctors.length; i++)
/*     */     {
/* 555 */       ModelMBeanConstructorInfo ctor = (ModelMBeanConstructorInfo)ctors[i];
/* 556 */       constructors[i] = ((ModelMBeanConstructorInfo)ctor.clone());
/*     */     }
/* 558 */     return constructors;
/*     */   }
/*     */   
/*     */ 
/*     */   public MBeanAttributeInfo[] getAttributes()
/*     */   {
/* 564 */     MBeanAttributeInfo[] attrs = this.modelMBeanAttributes;
/* 565 */     if (attrs == null)
/*     */     {
/* 567 */       return null;
/*     */     }
/* 569 */     ModelMBeanAttributeInfo[] attributes = new ModelMBeanAttributeInfo[attrs.length];
/* 570 */     for (int i = 0; i < attrs.length; i++)
/*     */     {
/* 572 */       ModelMBeanAttributeInfo attr = (ModelMBeanAttributeInfo)attrs[i];
/* 573 */       attributes[i] = ((ModelMBeanAttributeInfo)attr.clone());
/*     */     }
/* 575 */     return attributes;
/*     */   }
/*     */   
/*     */ 
/*     */   public MBeanOperationInfo[] getOperations()
/*     */   {
/* 581 */     MBeanOperationInfo[] opers = this.modelMBeanOperations;
/* 582 */     if (opers == null)
/*     */     {
/* 584 */       return null;
/*     */     }
/* 586 */     ModelMBeanOperationInfo[] operations = new ModelMBeanOperationInfo[opers.length];
/* 587 */     for (int i = 0; i < opers.length; i++)
/*     */     {
/* 589 */       ModelMBeanOperationInfo oper = (ModelMBeanOperationInfo)opers[i];
/* 590 */       operations[i] = ((ModelMBeanOperationInfo)oper.clone());
/*     */     }
/* 592 */     return operations;
/*     */   }
/*     */   
/*     */ 
/*     */   public MBeanNotificationInfo[] getNotifications()
/*     */   {
/* 598 */     MBeanNotificationInfo[] notifs = this.modelMBeanNotifications;
/* 599 */     if (notifs == null)
/*     */     {
/* 601 */       return null;
/*     */     }
/* 603 */     ModelMBeanNotificationInfo[] notifications = new ModelMBeanNotificationInfo[notifs.length];
/* 604 */     for (int i = 0; i < notifs.length; i++)
/*     */     {
/* 606 */       ModelMBeanNotificationInfo notif = (ModelMBeanNotificationInfo)notifs[i];
/* 607 */       notifications[i] = ((ModelMBeanNotificationInfo)notif.clone());
/*     */     }
/* 609 */     return notifications;
/*     */   }
/*     */   
/*     */   private void checkAndSetDescriptor(Descriptor descriptor)
/*     */   {
/* 614 */     if (descriptor == null)
/*     */     {
/* 616 */       this.modelMBeanDescriptor = createDefaultMBeanDescriptor();
/*     */     }
/* 618 */     else if (isDescriptorValid(descriptor))
/*     */     {
/* 620 */       this.modelMBeanDescriptor = addRequiredFields(descriptor);
/*     */     }
/*     */     else
/*     */     {
/* 624 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid Descriptor"));
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isDescriptorValid(Descriptor descriptor)
/*     */   {
/* 630 */     if (!descriptor.isValid())
/*     */     {
/* 632 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 638 */     String[] names = descriptor.getFieldNames();
/*     */     
/* 640 */     if ((!containsIgnoreCase(names, "name")) || (!containsIgnoreCase(names, "descriptortype")))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 647 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 658 */     String desctype = (String)descriptor.getFieldValue("descriptortype");
/* 659 */     if (desctype.compareToIgnoreCase("mbean") != 0) { return false;
/*     */     }
/* 661 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Descriptor createDefaultMBeanDescriptor()
/*     */   {
/* 671 */     String[] names = { "name", "descriptorType", "displayName", "persistPolicy", "log", "export", "visibility" };
/* 672 */     int index = getClassName().lastIndexOf('.') + 1;
/* 673 */     Object[] values = { getClassName().substring(index), "MBean", getClassName(), "Never", "F", "F", "1" };
/* 674 */     return new DescriptorSupport(names, values);
/*     */   }
/*     */   
/*     */ 
/*     */   private Descriptor findDescriptorByName(MBeanFeatureInfo[] features, String name)
/*     */   {
/* 680 */     if (features != null)
/*     */     {
/* 682 */       for (int i = 0; i < features.length; i++)
/*     */       {
/* 684 */         MBeanFeatureInfo feature = features[i];
/* 685 */         if ((feature != null) && (feature.getName().equals(name)) && ((feature instanceof DescriptorAccess)))
/*     */         {
/* 687 */           return ((DescriptorAccess)feature).getDescriptor();
/*     */         }
/*     */       }
/*     */     }
/* 691 */     return null;
/*     */   }
/*     */   
/*     */   private Descriptor addRequiredFields(Descriptor d)
/*     */   {
/* 696 */     Descriptor result = (Descriptor)d.clone();
/* 697 */     String[] reqfields = { "displayname", "persistpolicy", "log", "export", "visibility" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 704 */     String[] defvalues = { (String)d.getFieldValue("name"), "never", "F", "F", "1" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 711 */     List fields = Arrays.asList(d.getFieldNames());
/* 712 */     for (int i = 0; i < reqfields.length; i++)
/*     */     {
/* 714 */       if (!fields.contains(reqfields[i]))
/*     */       {
/* 716 */         result.setField(reqfields[i], defvalues[i]);
/*     */       }
/*     */     }
/* 719 */     return result;
/*     */   }
/*     */   
/*     */   static boolean containsIgnoreCase(String[] fields, String field)
/*     */   {
/* 724 */     for (int i = 0; i < fields.length; i++)
/*     */     {
/* 726 */       if (fields[i].equalsIgnoreCase(field)) return true;
/*     */     }
/* 728 */     return false;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/modelmbean/ModelMBeanInfoSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */