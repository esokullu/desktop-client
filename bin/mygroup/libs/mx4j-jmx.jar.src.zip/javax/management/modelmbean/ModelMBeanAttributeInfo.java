/*     */ package javax.management.modelmbean;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import javax.management.Descriptor;
/*     */ import javax.management.DescriptorAccess;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelMBeanAttributeInfo
/*     */   extends MBeanAttributeInfo
/*     */   implements DescriptorAccess, Cloneable
/*     */ {
/*     */   private static final long serialVersionUID = 6181543027787327345L;
/*     */   private Descriptor attrDescriptor;
/*     */   
/*     */   public ModelMBeanAttributeInfo(String name, String description, Method getter, Method setter)
/*     */     throws IntrospectionException
/*     */   {
/*  31 */     this(name, description, getter, setter, null);
/*     */   }
/*     */   
/*     */   public ModelMBeanAttributeInfo(String name, String description, Method getter, Method setter, Descriptor descriptor) throws IntrospectionException
/*     */   {
/*  36 */     super(name, description, getter, setter);
/*  37 */     checkAndSetDescriptor(descriptor);
/*     */   }
/*     */   
/*     */   public ModelMBeanAttributeInfo(String name, String type, String description, boolean isReadable, boolean isWritable, boolean isIs)
/*     */   {
/*  42 */     this(name, type, description, isReadable, isWritable, isIs, null);
/*     */   }
/*     */   
/*     */   public ModelMBeanAttributeInfo(String name, String type, String description, boolean isReadable, boolean isWritable, boolean isIs, Descriptor descriptor)
/*     */   {
/*  47 */     super(name, type, description, isReadable, isWritable, isIs);
/*  48 */     checkAndSetDescriptor(descriptor);
/*     */   }
/*     */   
/*     */   public ModelMBeanAttributeInfo(ModelMBeanAttributeInfo copy)
/*     */   {
/*  53 */     super(copy.getName(), copy.getType(), copy.getDescription(), copy.isReadable(), copy.isWritable(), copy.isIs());
/*  54 */     checkAndSetDescriptor(copy.getDescriptor());
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  59 */     return new ModelMBeanAttributeInfo(this);
/*     */   }
/*     */   
/*     */   public Descriptor getDescriptor()
/*     */   {
/*  64 */     return (Descriptor)this.attrDescriptor.clone();
/*     */   }
/*     */   
/*     */   public void setDescriptor(Descriptor descriptor)
/*     */   {
/*  69 */     if (descriptor == null)
/*     */     {
/*  71 */       this.attrDescriptor = createDefaultDescriptor();
/*     */ 
/*     */ 
/*     */     }
/*  75 */     else if (isDescriptorValid(descriptor))
/*     */     {
/*  77 */       this.attrDescriptor = ((Descriptor)descriptor.clone());
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*  83 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid descriptor"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void checkAndSetDescriptor(Descriptor descriptor)
/*     */   {
/*  90 */     if (descriptor == null)
/*     */     {
/*  92 */       this.attrDescriptor = createDefaultDescriptor();
/*     */     }
/*  94 */     else if (isDescriptorValid(descriptor))
/*     */     {
/*  96 */       this.attrDescriptor = ((Descriptor)descriptor.clone());
/*  97 */       if (this.attrDescriptor.getFieldValue("displayname") == null)
/*     */       {
/*  99 */         this.attrDescriptor.setField("displayname", getName());
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 104 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid Descriptor"));
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isDescriptorValid(Descriptor descriptor)
/*     */   {
/* 110 */     if (!descriptor.isValid())
/*     */     {
/* 112 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 118 */     String[] names = descriptor.getFieldNames();
/*     */     
/* 120 */     if ((!ModelMBeanInfoSupport.containsIgnoreCase(names, "name")) || (!ModelMBeanInfoSupport.containsIgnoreCase(names, "descriptortype")))
/*     */     {
/*     */ 
/* 123 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 127 */     String name = getName();
/* 128 */     if (name == null)
/*     */     {
/* 130 */       return false;
/*     */     }
/* 132 */     if (!name.equals(descriptor.getFieldValue("name")))
/*     */     {
/* 134 */       return false;
/*     */     }
/*     */     
/* 137 */     String desctype = (String)descriptor.getFieldValue("descriptortype");
/* 138 */     if (desctype.compareToIgnoreCase("attribute") != 0) { return false;
/*     */     }
/* 140 */     return true;
/*     */   }
/*     */   
/*     */   private Descriptor createDefaultDescriptor()
/*     */   {
/* 145 */     String[] names = { "name", "descriptorType", "displayName" };
/* 146 */     Object[] values = { getName(), "attribute", getName() };
/* 147 */     return new DescriptorSupport(names, values);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/modelmbean/ModelMBeanAttributeInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */