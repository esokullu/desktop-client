/*     */ package javax.management.modelmbean;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import javax.management.Descriptor;
/*     */ import javax.management.DescriptorAccess;
/*     */ import javax.management.MBeanConstructorInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelMBeanConstructorInfo
/*     */   extends MBeanConstructorInfo
/*     */   implements DescriptorAccess, Cloneable
/*     */ {
/*     */   private static final long serialVersionUID = 3862947819818064362L;
/*     */   private Descriptor consDescriptor;
/*     */   
/*     */   public ModelMBeanConstructorInfo(String description, Constructor constructor)
/*     */   {
/*  31 */     this(description, constructor, null);
/*     */   }
/*     */   
/*     */   public ModelMBeanConstructorInfo(String description, Constructor constructor, Descriptor descriptor)
/*     */   {
/*  36 */     super(description, constructor);
/*  37 */     checkAndSetDescriptor(descriptor);
/*     */   }
/*     */   
/*     */   public ModelMBeanConstructorInfo(String name, String description, MBeanParameterInfo[] params)
/*     */   {
/*  42 */     this(name, description, params, null);
/*     */   }
/*     */   
/*     */   public ModelMBeanConstructorInfo(String name, String description, MBeanParameterInfo[] params, Descriptor descriptor)
/*     */   {
/*  47 */     super(name, description, params);
/*  48 */     checkAndSetDescriptor(descriptor);
/*     */   }
/*     */   
/*     */   ModelMBeanConstructorInfo(ModelMBeanConstructorInfo copy)
/*     */   {
/*  53 */     super(copy.getName(), copy.getDescription(), copy.getSignature());
/*  54 */     checkAndSetDescriptor(copy.getDescriptor());
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  59 */     return new ModelMBeanConstructorInfo(this);
/*     */   }
/*     */   
/*     */   public Descriptor getDescriptor()
/*     */   {
/*  64 */     return (Descriptor)this.consDescriptor.clone();
/*     */   }
/*     */   
/*     */   public void setDescriptor(Descriptor descriptor)
/*     */   {
/*  69 */     if (descriptor == null)
/*     */     {
/*  71 */       this.consDescriptor = createDefaultDescriptor();
/*     */ 
/*     */ 
/*     */     }
/*  75 */     else if (isDescriptorValid(descriptor))
/*     */     {
/*  77 */       this.consDescriptor = ((Descriptor)descriptor.clone());
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*  83 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid descriptor"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void checkAndSetDescriptor(Descriptor descriptor)
/*     */   {
/*  90 */     if (descriptor == null)
/*     */     {
/*  92 */       this.consDescriptor = createDefaultDescriptor();
/*     */     }
/*  94 */     else if (isDescriptorValid(descriptor))
/*     */     {
/*  96 */       this.consDescriptor = ((Descriptor)descriptor.clone());
/*  97 */       if (this.consDescriptor.getFieldValue("displayName") == null)
/*     */       {
/*  99 */         this.consDescriptor.setField("displayName", getName());
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 104 */       throw new RuntimeOperationsException(new IllegalArgumentException("Invalid descriptor"));
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isDescriptorValid(Descriptor descriptor)
/*     */   {
/* 110 */     if (!descriptor.isValid())
/*     */     {
/* 112 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 118 */     String[] names = descriptor.getFieldNames();
/*     */     
/* 120 */     if ((!ModelMBeanInfoSupport.containsIgnoreCase(names, "name")) || (!ModelMBeanInfoSupport.containsIgnoreCase(names, "descriptortype")) || (!ModelMBeanInfoSupport.containsIgnoreCase(names, "role")))
/*     */     {
/*     */ 
/*     */ 
/* 124 */       return false;
/*     */     }
/*     */     
/* 127 */     if ((ModelMBeanInfoSupport.containsIgnoreCase(names, "persistpolicy")) || (ModelMBeanInfoSupport.containsIgnoreCase(names, "currencytimelimit")))
/*     */     {
/*     */ 
/* 130 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 134 */     String name = getName();
/* 135 */     if (name == null)
/*     */     {
/* 137 */       return false;
/*     */     }
/* 139 */     if (!name.equals(descriptor.getFieldValue("name")))
/*     */     {
/* 141 */       return false;
/*     */     }
/*     */     
/* 144 */     String desctype = (String)descriptor.getFieldValue("descriptortype");
/* 145 */     if (desctype.compareToIgnoreCase("operation") != 0) { return false;
/*     */     }
/* 147 */     String role = (String)descriptor.getFieldValue("role");
/* 148 */     if (role.compareTo("constructor") != 0) { return false;
/*     */     }
/* 150 */     return true;
/*     */   }
/*     */   
/*     */   private Descriptor createDefaultDescriptor()
/*     */   {
/* 155 */     String[] names = { "name", "descriptorType", "role", "displayName" };
/* 156 */     Object[] values = { getName(), "operation", "constructor", getName() };
/* 157 */     return new DescriptorSupport(names, values);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/modelmbean/ModelMBeanConstructorInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */