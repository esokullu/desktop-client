/*     */ package javax.management;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttributeList
/*     */   extends ArrayList
/*     */ {
/*     */   private static final long serialVersionUID = -4077085769279709076L;
/*     */   
/*     */   public AttributeList() {}
/*     */   
/*     */   public AttributeList(int initialCapacity)
/*     */   {
/*  27 */     super(initialCapacity);
/*     */   }
/*     */   
/*     */   public AttributeList(AttributeList list)
/*     */   {
/*  32 */     super(list);
/*     */   }
/*     */   
/*     */   public boolean add(Object o)
/*     */   {
/*  37 */     if ((o instanceof Attribute)) {
/*  38 */       return super.add(o);
/*     */     }
/*  40 */     throw new RuntimeOperationsException(new IllegalArgumentException("Elements of AttributeList can only be Attribute objects"));
/*     */   }
/*     */   
/*     */   public void add(Attribute a)
/*     */   {
/*  45 */     add(a);
/*     */   }
/*     */   
/*     */   public void add(int index, Object element)
/*     */   {
/*  50 */     if ((element instanceof Attribute))
/*     */     {
/*     */       try
/*     */       {
/*  54 */         super.add(index, element);
/*     */       }
/*     */       catch (IndexOutOfBoundsException x)
/*     */       {
/*  58 */         throw new RuntimeOperationsException(x);
/*     */       }
/*     */       
/*     */     }
/*     */     else {
/*  63 */       throw new RuntimeOperationsException(new IllegalArgumentException("Elements of AttributeList can only be Attribute objects"));
/*     */     }
/*     */   }
/*     */   
/*     */   public void add(int index, Attribute element)
/*     */   {
/*  69 */     add(index, element);
/*     */   }
/*     */   
/*     */   public boolean addAll(Collection c)
/*     */   {
/*  74 */     if ((c instanceof AttributeList))
/*     */     {
/*  76 */       return super.addAll(c);
/*     */     }
/*     */     
/*     */ 
/*  80 */     throw new RuntimeOperationsException(new IllegalArgumentException("Only AttributeList objects can be added to other AttributeList"));
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean addAll(AttributeList c)
/*     */   {
/*  86 */     return addAll(c);
/*     */   }
/*     */   
/*     */   public boolean addAll(int index, Collection c)
/*     */   {
/*  91 */     if ((c instanceof AttributeList))
/*     */     {
/*     */       try
/*     */       {
/*  95 */         return super.addAll(index, c);
/*     */       }
/*     */       catch (IndexOutOfBoundsException x)
/*     */       {
/*  99 */         throw new RuntimeOperationsException(x);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 104 */     throw new RuntimeOperationsException(new IllegalArgumentException("Only AttributeList objects can be added to other AttributeList"));
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean addAll(int index, AttributeList c)
/*     */   {
/* 110 */     return addAll(index, c);
/*     */   }
/*     */   
/*     */   public Object set(int index, Object element)
/*     */   {
/* 115 */     if ((element instanceof Attribute))
/*     */     {
/*     */       try
/*     */       {
/* 119 */         return super.set(index, element);
/*     */       }
/*     */       catch (IndexOutOfBoundsException x)
/*     */       {
/* 123 */         throw new RuntimeOperationsException(x);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 128 */     throw new RuntimeOperationsException(new IllegalArgumentException("Elements of AttributeList can only be Attribute objects"));
/*     */   }
/*     */   
/*     */ 
/*     */   public void set(int index, Attribute element)
/*     */   {
/* 134 */     set(index, element);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/AttributeList.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */