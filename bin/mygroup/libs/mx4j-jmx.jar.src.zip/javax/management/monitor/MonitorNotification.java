/*    */ package javax.management.monitor;
/*    */ 
/*    */ import javax.management.Notification;
/*    */ import javax.management.ObjectName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MonitorNotification
/*    */   extends Notification
/*    */ {
/*    */   private static final long serialVersionUID = -4608189663661929204L;
/*    */   public static final String OBSERVED_ATTRIBUTE_ERROR = "jmx.monitor.error.attribute";
/*    */   public static final String OBSERVED_ATTRIBUTE_TYPE_ERROR = "jmx.monitor.error.type";
/*    */   public static final String OBSERVED_OBJECT_ERROR = "jmx.monitor.error.mbean";
/*    */   public static final String RUNTIME_ERROR = "jmx.monitor.error.runtime";
/*    */   public static final String STRING_TO_COMPARE_VALUE_DIFFERED = "jmx.monitor.string.differs";
/*    */   public static final String STRING_TO_COMPARE_VALUE_MATCHED = "jmx.monitor.string.matches";
/*    */   public static final String THRESHOLD_ERROR = "jmx.monitor.error.threshold";
/*    */   public static final String THRESHOLD_HIGH_VALUE_EXCEEDED = "jmx.monitor.gauge.high";
/*    */   public static final String THRESHOLD_LOW_VALUE_EXCEEDED = "jmx.monitor.gauge.low";
/*    */   public static final String THRESHOLD_VALUE_EXCEEDED = "jmx.monitor.counter.threshold";
/*    */   private final ObjectName observedObject;
/*    */   private final String observedAttribute;
/*    */   private final Object derivedGauge;
/*    */   private final Object trigger;
/*    */   
/*    */   MonitorNotification(String type, Object source, long sequenceNumber, long timeStamp, String message, ObjectName monitoredName, String attribute, Object gauge, Object trigger)
/*    */   {
/* 39 */     super(type, source, sequenceNumber, timeStamp, message);
/* 40 */     this.observedObject = monitoredName;
/* 41 */     this.observedAttribute = attribute;
/* 42 */     this.derivedGauge = gauge;
/* 43 */     this.trigger = trigger;
/*    */   }
/*    */   
/*    */   public ObjectName getObservedObject()
/*    */   {
/* 48 */     return this.observedObject;
/*    */   }
/*    */   
/*    */   public Object getDerivedGauge()
/*    */   {
/* 53 */     return this.derivedGauge;
/*    */   }
/*    */   
/*    */   public String getObservedAttribute()
/*    */   {
/* 58 */     return this.observedAttribute;
/*    */   }
/*    */   
/*    */   public Object getTrigger()
/*    */   {
/* 63 */     return this.trigger;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 68 */     StringBuffer buffer = new StringBuffer("[");
/* 69 */     buffer.append(super.toString()).append(", ");
/* 70 */     buffer.append("observed=").append(getObservedObject()).append(", ");
/* 71 */     buffer.append("gauge=").append(getDerivedGauge()).append(", ");
/* 72 */     buffer.append("attribute=").append(getObservedAttribute()).append(", ");
/* 73 */     buffer.append("trigger=").append(getTrigger()).append("]");
/* 74 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/monitor/MonitorNotification.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */