/*     */ package javax.management.monitor;
/*     */ 
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationBroadcasterSupport;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.monitor.MX4JCounterMonitor;
/*     */ import mx4j.monitor.MX4JMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CounterMonitor
/*     */   extends Monitor
/*     */   implements CounterMonitorMBean
/*     */ {
/*  25 */   private static final MBeanNotificationInfo[] notificationInfos = { new MBeanNotificationInfo(new String[] { "jmx.monitor.error.runtime", "jmx.monitor.error.mbean", "jmx.monitor.error.attribute", "jmx.monitor.error.type", "jmx.monitor.error.threshold", "jmx.monitor.counter.threshold" }, MonitorNotification.class.getName(), "Notifications sent by the CounterMonitor MBean") };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   MX4JMonitor createMX4JMonitor()
/*     */   {
/*     */     try
/*     */     {
/*  44 */       new MX4JCounterMonitor()
/*     */       {
/*     */         protected NotificationBroadcasterSupport createNotificationEmitter()
/*     */         {
/*  48 */           return CounterMonitor.this;
/*     */         }
/*     */         
/*     */         public MBeanNotificationInfo[] getNotificationInfo()
/*     */         {
/*  53 */           return CounterMonitor.notificationInfos;
/*     */         }
/*     */         
/*     */         protected Notification createMonitorNotification(String type, long sequence, String message, ObjectName observed, String attribute, Object gauge, Object trigger)
/*     */         {
/*  58 */           return new MonitorNotification(type, this, sequence, System.currentTimeMillis(), message, observed, attribute, gauge, trigger);
/*     */         }
/*     */       };
/*     */     }
/*     */     catch (NotCompliantMBeanException x) {}
/*     */     
/*  64 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void start()
/*     */   {
/*  70 */     MX4JMonitor monitor = getMX4JMonitor();
/*  71 */     monitor.start();
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/*  76 */     MX4JMonitor monitor = getMX4JMonitor();
/*  77 */     monitor.stop();
/*     */   }
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Number getDerivedGauge()
/*     */   {
/*  85 */     return getDerivedGauge(getObservedObject());
/*     */   }
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public long getDerivedGaugeTimeStamp()
/*     */   {
/*  93 */     return getDerivedGaugeTimeStamp(getObservedObject());
/*     */   }
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Number getThreshold()
/*     */   {
/* 101 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 102 */     return monitor.getThreshold(getObservedObject());
/*     */   }
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setThreshold(Number value) throws IllegalArgumentException
/*     */   {
/* 110 */     setInitThreshold(value);
/*     */   }
/*     */   
/*     */   public Number getDerivedGauge(ObjectName objectName)
/*     */   {
/* 115 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 116 */     return monitor.getDerivedGauge(objectName);
/*     */   }
/*     */   
/*     */   public long getDerivedGaugeTimeStamp(ObjectName objectName)
/*     */   {
/* 121 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 122 */     return monitor.getDerivedGaugeTimeStamp(objectName);
/*     */   }
/*     */   
/*     */   public Number getThreshold(ObjectName objectName)
/*     */   {
/* 127 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 128 */     return monitor.getThreshold(objectName);
/*     */   }
/*     */   
/*     */   public Number getInitThreshold()
/*     */   {
/* 133 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 134 */     return monitor.getInitThreshold();
/*     */   }
/*     */   
/*     */   public void setInitThreshold(Number value) throws IllegalArgumentException
/*     */   {
/* 139 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 140 */     monitor.setInitThreshold(value);
/*     */   }
/*     */   
/*     */   public Number getOffset()
/*     */   {
/* 145 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 146 */     return monitor.getOffset();
/*     */   }
/*     */   
/*     */   public synchronized void setOffset(Number value) throws IllegalArgumentException
/*     */   {
/* 151 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 152 */     monitor.setOffset(value);
/*     */   }
/*     */   
/*     */   public Number getModulus()
/*     */   {
/* 157 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 158 */     return monitor.getModulus();
/*     */   }
/*     */   
/*     */   public void setModulus(Number value) throws IllegalArgumentException
/*     */   {
/* 163 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 164 */     monitor.setModulus(value);
/*     */   }
/*     */   
/*     */   public boolean getNotify()
/*     */   {
/* 169 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 170 */     return monitor.getNotify();
/*     */   }
/*     */   
/*     */   public void setNotify(boolean value)
/*     */   {
/* 175 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 176 */     monitor.setNotify(value);
/*     */   }
/*     */   
/*     */   public boolean getDifferenceMode()
/*     */   {
/* 181 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 182 */     return monitor.getDifferenceMode();
/*     */   }
/*     */   
/*     */   public void setDifferenceMode(boolean value)
/*     */   {
/* 187 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 188 */     monitor.setDifferenceMode(value);
/*     */   }
/*     */   
/*     */   public MBeanNotificationInfo[] getNotificationInfo()
/*     */   {
/* 193 */     MX4JCounterMonitor monitor = (MX4JCounterMonitor)getMX4JMonitor();
/* 194 */     return monitor.getNotificationInfo();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/monitor/CounterMonitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */