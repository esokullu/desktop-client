package javax.management.monitor;

import javax.management.ObjectName;

public abstract interface StringMonitorMBean
  extends MonitorMBean
{
  /**
   * @deprecated
   */
  public abstract String getDerivedGauge();
  
  /**
   * @deprecated
   */
  public abstract long getDerivedGaugeTimeStamp();
  
  public abstract String getDerivedGauge(ObjectName paramObjectName);
  
  public abstract long getDerivedGaugeTimeStamp(ObjectName paramObjectName);
  
  public abstract String getStringToCompare();
  
  public abstract void setStringToCompare(String paramString)
    throws IllegalArgumentException;
  
  public abstract boolean getNotifyMatch();
  
  public abstract void setNotifyMatch(boolean paramBoolean);
  
  public abstract boolean getNotifyDiffer();
  
  public abstract void setNotifyDiffer(boolean paramBoolean);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/monitor/StringMonitorMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */