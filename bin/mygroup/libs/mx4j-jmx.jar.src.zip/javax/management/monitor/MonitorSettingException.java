/*    */ package javax.management.monitor;
/*    */ 
/*    */ import javax.management.JMRuntimeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MonitorSettingException
/*    */   extends JMRuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -8807913418190202007L;
/*    */   
/*    */   public MonitorSettingException() {}
/*    */   
/*    */   public MonitorSettingException(String message)
/*    */   {
/* 26 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/monitor/MonitorSettingException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */