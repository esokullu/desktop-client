/*     */ package javax.management.monitor;
/*     */ 
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationBroadcasterSupport;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.monitor.MX4JMonitor;
/*     */ import mx4j.monitor.MX4JStringMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringMonitor
/*     */   extends Monitor
/*     */   implements StringMonitorMBean
/*     */ {
/*  25 */   private static final MBeanNotificationInfo[] notificationInfos = { new MBeanNotificationInfo(new String[] { "jmx.monitor.error.runtime", "jmx.monitor.error.mbean", "jmx.monitor.error.attribute", "jmx.monitor.error.type", "jmx.monitor.string.matches", "jmx.monitor.string.differs" }, MonitorNotification.class.getName(), "Notifications sent by the StringMonitor MBean") };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   MX4JMonitor createMX4JMonitor()
/*     */   {
/*     */     try
/*     */     {
/*  44 */       new MX4JStringMonitor()
/*     */       {
/*     */         protected NotificationBroadcasterSupport createNotificationEmitter()
/*     */         {
/*  48 */           return StringMonitor.this;
/*     */         }
/*     */         
/*     */         public MBeanNotificationInfo[] getNotificationInfo()
/*     */         {
/*  53 */           return StringMonitor.notificationInfos;
/*     */         }
/*     */         
/*     */         protected Notification createMonitorNotification(String type, long sequence, String message, ObjectName observed, String attribute, Object gauge, Object trigger)
/*     */         {
/*  58 */           return new MonitorNotification(type, this, sequence, System.currentTimeMillis(), message, observed, attribute, gauge, trigger);
/*     */         }
/*     */       };
/*     */     }
/*     */     catch (NotCompliantMBeanException x) {}
/*     */     
/*  64 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void start()
/*     */   {
/*  70 */     MX4JMonitor monitor = getMX4JMonitor();
/*  71 */     monitor.start();
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/*  76 */     MX4JMonitor monitor = getMX4JMonitor();
/*  77 */     monitor.stop();
/*     */   }
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public String getDerivedGauge()
/*     */   {
/*  85 */     return getDerivedGauge(getObservedObject());
/*     */   }
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public long getDerivedGaugeTimeStamp()
/*     */   {
/*  93 */     return getDerivedGaugeTimeStamp(getObservedObject());
/*     */   }
/*     */   
/*     */   public String getDerivedGauge(ObjectName objectName)
/*     */   {
/*  98 */     MX4JStringMonitor monitor = (MX4JStringMonitor)getMX4JMonitor();
/*  99 */     return monitor.getDerivedGauge(objectName);
/*     */   }
/*     */   
/*     */   public long getDerivedGaugeTimeStamp(ObjectName objectName)
/*     */   {
/* 104 */     MX4JStringMonitor monitor = (MX4JStringMonitor)getMX4JMonitor();
/* 105 */     return monitor.getDerivedGaugeTimeStamp(objectName);
/*     */   }
/*     */   
/*     */   public String getStringToCompare()
/*     */   {
/* 110 */     MX4JStringMonitor monitor = (MX4JStringMonitor)getMX4JMonitor();
/* 111 */     return monitor.getStringToCompare();
/*     */   }
/*     */   
/*     */   public void setStringToCompare(String value) throws IllegalArgumentException
/*     */   {
/* 116 */     MX4JStringMonitor monitor = (MX4JStringMonitor)getMX4JMonitor();
/* 117 */     monitor.setStringToCompare(value);
/*     */   }
/*     */   
/*     */   public boolean getNotifyMatch()
/*     */   {
/* 122 */     MX4JStringMonitor monitor = (MX4JStringMonitor)getMX4JMonitor();
/* 123 */     return monitor.getNotifyMatch();
/*     */   }
/*     */   
/*     */   public void setNotifyMatch(boolean value)
/*     */   {
/* 128 */     MX4JStringMonitor monitor = (MX4JStringMonitor)getMX4JMonitor();
/* 129 */     monitor.setNotifyMatch(value);
/*     */   }
/*     */   
/*     */   public boolean getNotifyDiffer()
/*     */   {
/* 134 */     MX4JStringMonitor monitor = (MX4JStringMonitor)getMX4JMonitor();
/* 135 */     return monitor.getNotifyDiffer();
/*     */   }
/*     */   
/*     */   public void setNotifyDiffer(boolean value)
/*     */   {
/* 140 */     MX4JStringMonitor monitor = (MX4JStringMonitor)getMX4JMonitor();
/* 141 */     monitor.setNotifyDiffer(value);
/*     */   }
/*     */   
/*     */   public MBeanNotificationInfo[] getNotificationInfo()
/*     */   {
/* 146 */     MX4JStringMonitor monitor = (MX4JStringMonitor)getMX4JMonitor();
/* 147 */     return monitor.getNotificationInfo();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/monitor/StringMonitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */