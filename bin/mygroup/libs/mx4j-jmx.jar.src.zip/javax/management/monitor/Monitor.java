/*     */ package javax.management.monitor;
/*     */ 
/*     */ import javax.management.MBeanRegistration;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.NotificationBroadcasterSupport;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.monitor.MX4JMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Monitor
/*     */   extends NotificationBroadcasterSupport
/*     */   implements MonitorMBean, MBeanRegistration
/*     */ {
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   protected int alreadyNotified;
/*     */   protected int[] alreadyNotifieds;
/*     */   protected static final int capacityIncrement = 16;
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   protected String dbgTag;
/*     */   protected int elementCount;
/*     */   protected static final int OBSERVED_ATTRIBUTE_ERROR_NOTIFIED = 2;
/*     */   protected static final int OBSERVED_ATTRIBUTE_TYPE_ERROR_NOTIFIED = 4;
/*     */   protected static final int OBSERVED_OBJECT_ERROR_NOTIFIED = 1;
/*     */   protected static final int RESET_FLAGS_ALREADY_NOTIFIED = 0;
/*     */   protected static final int RUNTIME_ERROR_NOTIFIED = 8;
/*     */   protected MBeanServer server;
/*     */   private MX4JMonitor monitor;
/*     */   
/*     */   abstract MX4JMonitor createMX4JMonitor();
/*     */   
/*     */   synchronized MX4JMonitor getMX4JMonitor()
/*     */   {
/*  52 */     if (this.monitor == null)
/*     */     {
/*  54 */       this.monitor = createMX4JMonitor();
/*     */     }
/*  56 */     return this.monitor;
/*     */   }
/*     */   
/*     */   public abstract void start();
/*     */   
/*     */   public abstract void stop();
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public ObjectName getObservedObject()
/*     */   {
/*  68 */     ObjectName[] observed = getObservedObjects();
/*  69 */     if ((observed == null) || (observed.length < 1)) return null;
/*  70 */     return observed[0];
/*     */   }
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setObservedObject(ObjectName objectName) throws IllegalArgumentException
/*     */   {
/*  78 */     MX4JMonitor monitor = getMX4JMonitor();
/*  79 */     synchronized (monitor)
/*     */     {
/*  81 */       monitor.clearObservedObjects();
/*  82 */       monitor.addObservedObject(objectName);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getObservedAttribute()
/*     */   {
/*  88 */     MX4JMonitor monitor = getMX4JMonitor();
/*  89 */     return monitor.getObservedAttribute();
/*     */   }
/*     */   
/*     */   public void setObservedAttribute(String attribute) throws IllegalArgumentException
/*     */   {
/*  94 */     MX4JMonitor monitor = getMX4JMonitor();
/*  95 */     monitor.setObservedAttribute(attribute);
/*     */   }
/*     */   
/*     */   public long getGranularityPeriod()
/*     */   {
/* 100 */     MX4JMonitor monitor = getMX4JMonitor();
/* 101 */     return monitor.getGranularityPeriod();
/*     */   }
/*     */   
/*     */   public void setGranularityPeriod(long period) throws IllegalArgumentException
/*     */   {
/* 106 */     MX4JMonitor monitor = getMX4JMonitor();
/* 107 */     monitor.setGranularityPeriod(period);
/*     */   }
/*     */   
/*     */   public boolean isActive()
/*     */   {
/* 112 */     MX4JMonitor monitor = getMX4JMonitor();
/* 113 */     return monitor.isActive();
/*     */   }
/*     */   
/*     */   public ObjectName preRegister(MBeanServer server, ObjectName name) throws Exception
/*     */   {
/* 118 */     this.server = server;
/* 119 */     MX4JMonitor monitor = getMX4JMonitor();
/* 120 */     return monitor.preRegister(server, name);
/*     */   }
/*     */   
/*     */   public void postRegister(Boolean registrationDone)
/*     */   {
/* 125 */     MX4JMonitor monitor = getMX4JMonitor();
/* 126 */     monitor.postRegister(registrationDone);
/*     */   }
/*     */   
/*     */   public void preDeregister() throws Exception
/*     */   {
/* 131 */     MX4JMonitor monitor = getMX4JMonitor();
/* 132 */     monitor.preDeregister();
/*     */   }
/*     */   
/*     */   public void postDeregister()
/*     */   {
/* 137 */     MX4JMonitor monitor = getMX4JMonitor();
/* 138 */     monitor.postDeregister();
/*     */   }
/*     */   
/*     */   public void addObservedObject(ObjectName objectName) throws IllegalArgumentException
/*     */   {
/* 143 */     MX4JMonitor monitor = getMX4JMonitor();
/* 144 */     monitor.addObservedObject(objectName);
/*     */   }
/*     */   
/*     */   public ObjectName[] getObservedObjects()
/*     */   {
/* 149 */     MX4JMonitor monitor = getMX4JMonitor();
/* 150 */     return monitor.getObservedObjects();
/*     */   }
/*     */   
/*     */   public boolean containsObservedObject(ObjectName objectName)
/*     */   {
/* 155 */     MX4JMonitor monitor = getMX4JMonitor();
/* 156 */     return monitor.containsObservedObject(objectName);
/*     */   }
/*     */   
/*     */   public void removeObservedObject(ObjectName objectName)
/*     */   {
/* 161 */     MX4JMonitor monitor = getMX4JMonitor();
/* 162 */     monitor.removeObservedObject(objectName);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/monitor/Monitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */