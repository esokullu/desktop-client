/*     */ package javax.management.monitor;
/*     */ 
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationBroadcasterSupport;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.monitor.MX4JGaugeMonitor;
/*     */ import mx4j.monitor.MX4JMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GaugeMonitor
/*     */   extends Monitor
/*     */   implements GaugeMonitorMBean
/*     */ {
/*  25 */   private static final MBeanNotificationInfo[] notificationInfos = { new MBeanNotificationInfo(new String[] { "jmx.monitor.error.runtime", "jmx.monitor.error.mbean", "jmx.monitor.error.attribute", "jmx.monitor.error.type", "jmx.monitor.error.threshold", "jmx.monitor.gauge.high", "jmx.monitor.gauge.low" }, MonitorNotification.class.getName(), "Notifications sent by the GaugeMonitor MBean") };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   MX4JMonitor createMX4JMonitor()
/*     */   {
/*     */     try
/*     */     {
/*  45 */       new MX4JGaugeMonitor()
/*     */       {
/*     */         protected NotificationBroadcasterSupport createNotificationEmitter()
/*     */         {
/*  49 */           return GaugeMonitor.this;
/*     */         }
/*     */         
/*     */         public MBeanNotificationInfo[] getNotificationInfo()
/*     */         {
/*  54 */           return GaugeMonitor.notificationInfos;
/*     */         }
/*     */         
/*     */         protected Notification createMonitorNotification(String type, long sequence, String message, ObjectName observed, String attribute, Object gauge, Object trigger)
/*     */         {
/*  59 */           return new MonitorNotification(type, this, sequence, System.currentTimeMillis(), message, observed, attribute, gauge, trigger);
/*     */         }
/*     */       };
/*     */     }
/*     */     catch (NotCompliantMBeanException x) {}
/*     */     
/*  65 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void start()
/*     */   {
/*  71 */     MX4JMonitor monitor = getMX4JMonitor();
/*  72 */     monitor.start();
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/*  77 */     MX4JMonitor monitor = getMX4JMonitor();
/*  78 */     monitor.stop();
/*     */   }
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Number getDerivedGauge()
/*     */   {
/*  86 */     return getDerivedGauge(getObservedObject());
/*     */   }
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public long getDerivedGaugeTimeStamp()
/*     */   {
/*  94 */     return getDerivedGaugeTimeStamp(getObservedObject());
/*     */   }
/*     */   
/*     */   public Number getDerivedGauge(ObjectName objectName)
/*     */   {
/*  99 */     MX4JGaugeMonitor monitor = (MX4JGaugeMonitor)getMX4JMonitor();
/* 100 */     return monitor.getDerivedGauge(objectName);
/*     */   }
/*     */   
/*     */   public long getDerivedGaugeTimeStamp(ObjectName objectName)
/*     */   {
/* 105 */     MX4JGaugeMonitor monitor = (MX4JGaugeMonitor)getMX4JMonitor();
/* 106 */     return monitor.getDerivedGaugeTimeStamp(objectName);
/*     */   }
/*     */   
/*     */   public Number getHighThreshold()
/*     */   {
/* 111 */     MX4JGaugeMonitor monitor = (MX4JGaugeMonitor)getMX4JMonitor();
/* 112 */     return monitor.getHighThreshold();
/*     */   }
/*     */   
/*     */   public Number getLowThreshold()
/*     */   {
/* 117 */     MX4JGaugeMonitor monitor = (MX4JGaugeMonitor)getMX4JMonitor();
/* 118 */     return monitor.getLowThreshold();
/*     */   }
/*     */   
/*     */   public void setThresholds(Number highValue, Number lowValue) throws IllegalArgumentException
/*     */   {
/* 123 */     MX4JGaugeMonitor monitor = (MX4JGaugeMonitor)getMX4JMonitor();
/* 124 */     monitor.setThresholds(highValue, lowValue);
/*     */   }
/*     */   
/*     */   public boolean getNotifyHigh()
/*     */   {
/* 129 */     MX4JGaugeMonitor monitor = (MX4JGaugeMonitor)getMX4JMonitor();
/* 130 */     return monitor.getNotifyHigh();
/*     */   }
/*     */   
/*     */   public void setNotifyHigh(boolean value)
/*     */   {
/* 135 */     MX4JGaugeMonitor monitor = (MX4JGaugeMonitor)getMX4JMonitor();
/* 136 */     monitor.setNotifyHigh(value);
/*     */   }
/*     */   
/*     */   public boolean getNotifyLow()
/*     */   {
/* 141 */     MX4JGaugeMonitor monitor = (MX4JGaugeMonitor)getMX4JMonitor();
/* 142 */     return monitor.getNotifyLow();
/*     */   }
/*     */   
/*     */   public void setNotifyLow(boolean value)
/*     */   {
/* 147 */     MX4JGaugeMonitor monitor = (MX4JGaugeMonitor)getMX4JMonitor();
/* 148 */     monitor.setNotifyLow(value);
/*     */   }
/*     */   
/*     */   public boolean getDifferenceMode()
/*     */   {
/* 153 */     MX4JGaugeMonitor monitor = (MX4JGaugeMonitor)getMX4JMonitor();
/* 154 */     return monitor.getDifferenceMode();
/*     */   }
/*     */   
/*     */   public void setDifferenceMode(boolean value)
/*     */   {
/* 159 */     MX4JGaugeMonitor monitor = (MX4JGaugeMonitor)getMX4JMonitor();
/* 160 */     monitor.setDifferenceMode(value);
/*     */   }
/*     */   
/*     */   public MBeanNotificationInfo[] getNotificationInfo()
/*     */   {
/* 165 */     MX4JGaugeMonitor monitor = (MX4JGaugeMonitor)getMX4JMonitor();
/* 166 */     return monitor.getNotificationInfo();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/monitor/GaugeMonitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */