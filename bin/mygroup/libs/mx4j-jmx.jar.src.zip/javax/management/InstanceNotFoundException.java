/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InstanceNotFoundException
/*    */   extends OperationsException
/*    */ {
/*    */   private static final long serialVersionUID = -882579438394773049L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InstanceNotFoundException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InstanceNotFoundException(String message)
/*    */   {
/* 24 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/InstanceNotFoundException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */