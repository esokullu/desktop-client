/*     */ package javax.management;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import mx4j.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanOperationInfo
/*     */   extends MBeanFeatureInfo
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -6178860474881375330L;
/*     */   public static final int INFO = 0;
/*     */   public static final int ACTION = 1;
/*     */   public static final int ACTION_INFO = 2;
/*     */   public static final int UNKNOWN = 3;
/*     */   private MBeanParameterInfo[] signature;
/*     */   private String type;
/*     */   private int impact;
/*     */   
/*     */   public MBeanOperationInfo(String description, Method method)
/*     */   {
/*  65 */     super(method.getName(), description);
/*  66 */     Class[] params = method.getParameterTypes();
/*  67 */     this.signature = new MBeanParameterInfo[params.length];
/*  68 */     for (int i = 0; i < params.length; i++)
/*     */     {
/*  70 */       this.signature[i] = new MBeanParameterInfo("", params[i].getName(), "");
/*     */     }
/*  72 */     this.type = method.getReturnType().getName();
/*  73 */     this.impact = 3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MBeanOperationInfo(String name, String description, MBeanParameterInfo[] signature, String type, int impact)
/*     */   {
/*  87 */     super(name, description);
/*  88 */     this.signature = (signature == null ? new MBeanParameterInfo[0] : signature);
/*  89 */     this.type = type;
/*  90 */     this.impact = impact;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*     */     try
/*     */     {
/*  97 */       return super.clone();
/*     */     }
/*     */     catch (CloneNotSupportedException ignored) {}
/*     */     
/* 101 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getReturnType()
/*     */   {
/* 110 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MBeanParameterInfo[] getSignature()
/*     */   {
/* 118 */     return this.signature;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getImpact()
/*     */   {
/* 126 */     return this.impact;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 131 */     int hash = super.hashCode();
/*     */     
/* 133 */     String type = getReturnType();
/* 134 */     if (type != null) hash = 29 * hash + type.hashCode();
/* 135 */     hash = 29 * hash + Utils.arrayHashCode(getSignature());
/* 136 */     hash = 29 * hash + getImpact();
/*     */     
/* 138 */     return hash;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 143 */     if (!super.equals(obj)) return false;
/* 144 */     if (!(obj instanceof MBeanOperationInfo)) { return false;
/*     */     }
/* 146 */     MBeanOperationInfo other = (MBeanOperationInfo)obj;
/*     */     
/* 148 */     String thisType = getReturnType();
/* 149 */     String otherType = other.getReturnType();
/* 150 */     if (thisType != null ? !thisType.equals(otherType) : otherType != null) return false;
/* 151 */     if (!Utils.arrayEquals(getSignature(), other.getSignature())) return false;
/* 152 */     if (getImpact() != other.getImpact()) { return false;
/*     */     }
/* 154 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanOperationInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */