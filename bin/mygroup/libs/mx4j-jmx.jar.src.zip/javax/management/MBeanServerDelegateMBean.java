package javax.management;

public abstract interface MBeanServerDelegateMBean
{
  public abstract String getImplementationName();
  
  public abstract String getImplementationVendor();
  
  public abstract String getImplementationVersion();
  
  public abstract String getMBeanServerId();
  
  public abstract String getSpecificationName();
  
  public abstract String getSpecificationVendor();
  
  public abstract String getSpecificationVersion();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanServerDelegateMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */