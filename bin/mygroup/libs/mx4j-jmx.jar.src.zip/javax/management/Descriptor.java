package javax.management;

import java.io.Serializable;

public abstract interface Descriptor
  extends Cloneable, Serializable
{
  public abstract Object getFieldValue(String paramString)
    throws RuntimeOperationsException;
  
  public abstract void setField(String paramString, Object paramObject)
    throws RuntimeOperationsException;
  
  public abstract void removeField(String paramString);
  
  public abstract String[] getFieldNames();
  
  public abstract Object[] getFieldValues(String[] paramArrayOfString);
  
  public abstract String[] getFields();
  
  public abstract void setFields(String[] paramArrayOfString, Object[] paramArrayOfObject)
    throws RuntimeOperationsException;
  
  public abstract Object clone()
    throws RuntimeOperationsException;
  
  public abstract boolean isValid()
    throws RuntimeOperationsException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/Descriptor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */