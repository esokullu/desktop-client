/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InQueryExp
/*    */   extends QueryEval
/*    */   implements QueryExp
/*    */ {
/*    */   private static final long serialVersionUID = -5801329450358952434L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final ValueExp val;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final ValueExp[] valueList;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   InQueryExp(ValueExp val, ValueExp[] valueList)
/*    */   {
/* 30 */     this.val = val;
/* 31 */     this.valueList = valueList;
/*    */   }
/*    */   
/*    */   public void setMBeanServer(MBeanServer server)
/*    */   {
/* 36 */     super.setMBeanServer(server);
/* 37 */     if (this.val != null) this.val.setMBeanServer(server);
/* 38 */     if (this.valueList != null)
/*    */     {
/* 40 */       for (int i = 0; i < this.valueList.length; i++)
/*    */       {
/* 42 */         ValueExp v = this.valueList[i];
/* 43 */         if (v != null) v.setMBeanServer(server);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean apply(ObjectName name) throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException
/*    */   {
/* 50 */     if ((this.val != null) && (this.valueList != null))
/*    */     {
/* 52 */       ValueExp valueExp = this.val.apply(name);
/* 53 */       if ((valueExp instanceof NumericValueExp))
/*    */       {
/* 55 */         NumericValueExp numExp = (NumericValueExp)valueExp;
/* 56 */         if (numExp.isDouble())
/*    */         {
/* 58 */           for (int i = 0; i < this.valueList.length; i++)
/*    */           {
/* 60 */             ValueExp exp = this.valueList[i];
/* 61 */             if ((exp instanceof NumericValueExp))
/*    */             {
/* 63 */               if (((NumericValueExp)exp).doubleValue() == numExp.doubleValue()) { return true;
/*    */               }
/*    */               
/*    */             }
/*    */           }
/*    */         } else {
/* 69 */           for (int i = 0; i < this.valueList.length; i++)
/*    */           {
/* 71 */             ValueExp exp = this.valueList[i];
/* 72 */             if ((exp instanceof NumericValueExp))
/*    */             {
/* 74 */               if (((NumericValueExp)exp).longValue() == numExp.longValue()) return true;
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/* 79 */       else if ((valueExp instanceof StringValueExp))
/*    */       {
/* 81 */         String s1 = ((StringValueExp)valueExp).getValue();
/* 82 */         for (int i = 0; i < this.valueList.length; i++)
/*    */         {
/* 84 */           ValueExp exp = this.valueList[i];
/* 85 */           if ((exp instanceof StringValueExp))
/*    */           {
/* 87 */             String s2 = ((StringValueExp)exp).getValue();
/* 88 */             if ((s1 == null) && (s2 == null)) return true;
/* 89 */             if ((s1 != null) && (s2 != null))
/*    */             {
/* 91 */               if (s1.equals(s2)) return true;
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 97 */     return false;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/InQueryExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */