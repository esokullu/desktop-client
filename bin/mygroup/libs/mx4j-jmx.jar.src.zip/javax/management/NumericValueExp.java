/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NumericValueExp
/*    */   extends QueryEval
/*    */   implements ValueExp
/*    */ {
/*    */   private static final long serialVersionUID = -4679739485102359104L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private Number val;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   NumericValueExp(Number val)
/*    */   {
/* 28 */     this.val = val;
/*    */   }
/*    */   
/*    */   public ValueExp apply(ObjectName name) throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException
/*    */   {
/* 33 */     return this;
/*    */   }
/*    */   
/*    */   boolean isDouble()
/*    */   {
/* 38 */     return ((this.val instanceof Float)) || ((this.val instanceof Double));
/*    */   }
/*    */   
/*    */   double doubleValue()
/*    */   {
/* 43 */     return this.val.doubleValue();
/*    */   }
/*    */   
/*    */   long longValue()
/*    */   {
/* 48 */     return this.val.longValue();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/NumericValueExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */