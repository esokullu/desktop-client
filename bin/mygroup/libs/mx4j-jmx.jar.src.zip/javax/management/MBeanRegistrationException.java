/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanRegistrationException
/*    */   extends MBeanException
/*    */ {
/*    */   private static final long serialVersionUID = 4482382455277067805L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MBeanRegistrationException(Exception x)
/*    */   {
/* 21 */     super(x);
/*    */   }
/*    */   
/*    */   public MBeanRegistrationException(Exception x, String message)
/*    */   {
/* 26 */     super(x, message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanRegistrationException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */