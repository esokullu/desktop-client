/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BadStringOperationException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 7802201238441662100L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final String op;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BadStringOperationException(String operation)
/*    */   {
/* 25 */     super(operation);
/* 26 */     this.op = operation;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/BadStringOperationException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */