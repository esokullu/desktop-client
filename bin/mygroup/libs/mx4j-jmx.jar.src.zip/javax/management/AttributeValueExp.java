/*     */ package javax.management;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttributeValueExp
/*     */   implements ValueExp
/*     */ {
/*     */   private static final long serialVersionUID = -7768025046539163385L;
/*     */   private String attr;
/*     */   private transient MBeanServer server;
/*     */   
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public AttributeValueExp() {}
/*     */   
/*     */   public AttributeValueExp(String attr)
/*     */   {
/*  44 */     this.attr = attr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAttributeName()
/*     */   {
/*  52 */     return this.attr;
/*     */   }
/*     */   
/*     */   public ValueExp apply(ObjectName name) throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException
/*     */   {
/*     */     try
/*     */     {
/*  59 */       Object value = getAttribute(name);
/*  60 */       if (value == null)
/*     */       {
/*     */ 
/*  63 */         return createValueExp(name);
/*     */       }
/*  65 */       if ((value instanceof Number))
/*     */       {
/*  67 */         return new NumericValueExp((Number)value);
/*     */       }
/*  69 */       if ((value instanceof Boolean))
/*     */       {
/*  71 */         return new BooleanValueExp(((Boolean)value).booleanValue());
/*     */       }
/*  73 */       if ((value instanceof String))
/*     */       {
/*  75 */         return new StringValueExp((String)value);
/*     */       }
/*     */       
/*     */ 
/*  79 */       throw new BadAttributeValueExpException(value);
/*     */ 
/*     */     }
/*     */     catch (RuntimeOperationsException x)
/*     */     {
/*  84 */       throw new BadAttributeValueExpException(getAttributeName());
/*     */     }
/*     */   }
/*     */   
/*     */   public void setMBeanServer(MBeanServer server)
/*     */   {
/*  90 */     this.server = server;
/*     */   }
/*     */   
/*     */   protected Object getAttribute(ObjectName name)
/*     */   {
/*     */     try
/*     */     {
/*  97 */       return this.server.getAttribute(name, getAttributeName());
/*     */     }
/*     */     catch (MBeanException x) {}catch (AttributeNotFoundException x) {}catch (InstanceNotFoundException x) {}catch (ReflectionException x) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */     throw new RuntimeOperationsException(null);
/*     */   }
/*     */   
/*     */   private ValueExp createValueExp(ObjectName name) throws BadAttributeValueExpException
/*     */   {
/*     */     try
/*     */     {
/* 118 */       MBeanInfo info = (MBeanInfo)AccessController.doPrivileged(new PrivilegedExceptionAction() {
/*     */         private final ObjectName val$name;
/*     */         
/*     */         public Object run() throws Exception {
/* 122 */           return AttributeValueExp.this.server.getMBeanInfo(this.val$name);
/*     */         }
/*     */         
/* 125 */       });
/* 126 */       MBeanAttributeInfo[] attrs = info.getAttributes();
/* 127 */       for (int i = 0; i < attrs.length; i++)
/*     */       {
/* 129 */         MBeanAttributeInfo attribute = attrs[i];
/* 130 */         if (attribute.getName().equals(getAttributeName()))
/*     */         {
/* 132 */           String type = attribute.getType();
/* 133 */           if (type.equals("java.lang.String"))
/*     */           {
/* 135 */             return new StringValueExp(null);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 141 */           throw new BadAttributeValueExpException(null);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (PrivilegedActionException x) {}
/*     */     
/*     */ 
/*     */ 
/* 149 */     throw new BadAttributeValueExpException(null);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/AttributeValueExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */