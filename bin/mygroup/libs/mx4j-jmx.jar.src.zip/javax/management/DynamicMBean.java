package javax.management;

public abstract interface DynamicMBean
{
  public abstract MBeanInfo getMBeanInfo();
  
  public abstract Object getAttribute(String paramString)
    throws AttributeNotFoundException, MBeanException, ReflectionException;
  
  public abstract void setAttribute(Attribute paramAttribute)
    throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException;
  
  public abstract AttributeList getAttributes(String[] paramArrayOfString);
  
  public abstract AttributeList setAttributes(AttributeList paramAttributeList);
  
  public abstract Object invoke(String paramString, Object[] paramArrayOfObject, String[] paramArrayOfString)
    throws MBeanException, ReflectionException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/DynamicMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */