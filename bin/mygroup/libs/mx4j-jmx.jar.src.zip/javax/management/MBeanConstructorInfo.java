/*    */ package javax.management;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Constructor;
/*    */ import mx4j.util.Utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanConstructorInfo
/*    */   extends MBeanFeatureInfo
/*    */   implements Cloneable, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 4433990064191844427L;
/*    */   private MBeanParameterInfo[] signature;
/*    */   
/*    */   public MBeanConstructorInfo(String description, Constructor constructor)
/*    */   {
/* 40 */     super(constructor.getName(), description);
/* 41 */     Class[] params = constructor.getParameterTypes();
/* 42 */     this.signature = new MBeanParameterInfo[params.length];
/* 43 */     for (int i = 0; i < params.length; i++)
/*    */     {
/* 45 */       this.signature[i] = new MBeanParameterInfo("", params[i].getName(), "");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MBeanConstructorInfo(String name, String description, MBeanParameterInfo[] signature)
/*    */   {
/* 58 */     super(name, description);
/* 59 */     this.signature = (signature == null ? new MBeanParameterInfo[0] : signature);
/*    */   }
/*    */   
/*    */   public Object clone()
/*    */   {
/*    */     try
/*    */     {
/* 66 */       return super.clone();
/*    */     }
/*    */     catch (CloneNotSupportedException ignored) {}
/*    */     
/* 70 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MBeanParameterInfo[] getSignature()
/*    */   {
/* 79 */     return this.signature;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 84 */     return super.hashCode() + 29 * Utils.arrayHashCode(getSignature());
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 89 */     if (!super.equals(obj)) return false;
/* 90 */     if (!(obj instanceof MBeanConstructorInfo)) { return false;
/*    */     }
/* 92 */     MBeanConstructorInfo other = (MBeanConstructorInfo)obj;
/* 93 */     return Utils.arrayEquals(getSignature(), other.getSignature());
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanConstructorInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */