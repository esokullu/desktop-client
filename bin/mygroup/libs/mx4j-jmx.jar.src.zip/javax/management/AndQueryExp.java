/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AndQueryExp
/*    */   extends QueryEval
/*    */   implements QueryExp
/*    */ {
/*    */   private static final long serialVersionUID = -1081892073854801359L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final QueryExp exp1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final QueryExp exp2;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   AndQueryExp(QueryExp exp1, QueryExp exp2)
/*    */   {
/* 30 */     this.exp1 = exp1;
/* 31 */     this.exp2 = exp2;
/*    */   }
/*    */   
/*    */   public void setMBeanServer(MBeanServer server)
/*    */   {
/* 36 */     super.setMBeanServer(server);
/* 37 */     if (this.exp1 != null) this.exp1.setMBeanServer(server);
/* 38 */     if (this.exp2 != null) this.exp2.setMBeanServer(server);
/*    */   }
/*    */   
/*    */   public boolean apply(ObjectName name) throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException
/*    */   {
/* 43 */     if ((this.exp1 != null) && (this.exp2 != null))
/*    */     {
/* 45 */       return (this.exp1.apply(name)) && (this.exp2.apply(name));
/*    */     }
/* 47 */     return false;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/AndQueryExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */