/*     */ package javax.management;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import mx4j.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectName
/*     */   implements QueryExp, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1081892073854801359L;
/*     */   private static final boolean cacheEnabled;
/*     */   private static final WeakObjectNameCache cache;
/*     */   private transient String propertiesString;
/*     */   private transient boolean isPropertyPattern;
/*     */   private transient boolean isDomainPattern;
/*     */   private transient String canonicalName;
/*     */   
/*     */   static
/*     */   {
/*  41 */     String enableCache = (String)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public Object run()
/*     */       {
/*  45 */         return System.getProperty("mx4j.objectname.caching");
/*     */       }
/*     */     });
/*  48 */     if (enableCache != null)
/*     */     {
/*  50 */       cacheEnabled = Boolean.valueOf(enableCache).booleanValue();
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*  55 */       cacheEnabled = true;
/*     */     }
/*  57 */     if (cacheEnabled)
/*     */     {
/*  59 */       cache = new WeakObjectNameCache(null);
/*     */     }
/*     */     else
/*     */     {
/*  63 */       cache = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName(String name)
/*     */     throws MalformedObjectNameException
/*     */   {
/*  74 */     if (name == null) throw new NullPointerException("ObjectName 'name' parameter can't be null");
/*  75 */     if (name.length() == 0) name = "*:*";
/*  76 */     parse(name);
/*     */   }
/*     */   
/*     */   public ObjectName(String domain, Hashtable table) throws MalformedObjectNameException
/*     */   {
/*  81 */     if (domain == null) throw new NullPointerException("ObjectName 'domain' parameter can't be null");
/*  82 */     if (table == null) throw new NullPointerException("ObjectName 'table' parameter can't be null");
/*  83 */     if (!isDomainValid(domain)) throw new MalformedObjectNameException("Invalid domain: " + domain);
/*  84 */     if (table.isEmpty()) { throw new MalformedObjectNameException("Properties table cannot be empty");
/*     */     }
/*  86 */     for (Iterator i = table.entrySet().iterator(); i.hasNext();)
/*     */     {
/*  88 */       Map.Entry entry = (Map.Entry)i.next();
/*  89 */       String key = entry.getKey().toString();
/*  90 */       if (!isKeyValid(key)) throw new MalformedObjectNameException("Invalid key: " + key);
/*  91 */       Object value = entry.getValue();
/*  92 */       if (!(value instanceof String)) throw new MalformedObjectNameException("Property values must be Strings");
/*  93 */       String strvalue = value.toString();
/*  94 */       if (!isValueValid(strvalue)) { throw new MalformedObjectNameException("Invalid value: " + strvalue);
/*     */       }
/*     */     }
/*  97 */     init(domain, convertPropertiesToString(new TreeMap(table)), table);
/*     */   }
/*     */   
/*     */   public ObjectName(String domain, String key, String value) throws MalformedObjectNameException
/*     */   {
/* 102 */     if (domain == null) throw new NullPointerException("ObjectName 'domain' parameter can't be null");
/* 103 */     if (key == null) throw new NullPointerException("ObjectName 'key' parameter can't be null");
/* 104 */     if (value == null) throw new NullPointerException("ObjectName 'value' parameter can't be null");
/* 105 */     if (!isDomainValid(domain)) throw new MalformedObjectNameException("Invalid domain: " + domain);
/* 106 */     if (!isKeyValid(key)) throw new MalformedObjectNameException("Invalid key: " + key);
/* 107 */     if (!isValueValid(value)) { throw new MalformedObjectNameException("Invalid value: " + value);
/*     */     }
/* 109 */     Map table = new HashMap();
/* 110 */     table.put(key, value);
/* 111 */     init(domain, convertPropertiesToString(table), table);
/*     */   }
/*     */   
/*     */   public boolean apply(ObjectName name)
/*     */   {
/* 116 */     boolean result = false;
/*     */     
/* 118 */     if (name.isPattern()) {
/* 119 */       result = false;
/* 120 */     } else if (isPattern()) {
/* 121 */       result = (domainsMatch(this, name)) && (propertiesMatch(this, name));
/*     */     } else {
/* 123 */       result = equals(name);
/*     */     }
/* 125 */     return result;
/*     */   }
/*     */   
/*     */   boolean implies(ObjectName name)
/*     */   {
/* 130 */     return (domainsMatch(this, name)) && (propertiesMatch(this, name));
/*     */   }
/*     */   
/*     */   private boolean domainsMatch(ObjectName name1, ObjectName name2)
/*     */   {
/* 135 */     String thisDomain = name1.getDomain();
/* 136 */     boolean thisPattern = name1.isDomainPattern();
/* 137 */     String otherDomain = name2.getDomain();
/* 138 */     boolean otherPattern = name2.isDomainPattern();
/*     */     
/* 140 */     if ((!thisPattern) && (otherPattern)) return false;
/* 141 */     if ((!thisPattern) && (!otherPattern) && (!thisDomain.equals(otherDomain))) return false;
/* 142 */     return Utils.wildcardMatch(thisDomain, otherDomain);
/*     */   }
/*     */   
/*     */   private boolean propertiesMatch(ObjectName name1, ObjectName name2)
/*     */   {
/* 147 */     Map thisProperties = name1.getPropertiesMap();
/* 148 */     boolean thisPattern = name1.isPropertyPattern();
/* 149 */     Map otherProperties = name2.getPropertiesMap();
/* 150 */     boolean otherPattern = name2.isPropertyPattern();
/*     */     
/* 152 */     if ((!thisPattern) && (otherPattern)) return false;
/* 153 */     if ((!thisPattern) && (!otherPattern) && (!thisProperties.equals(otherProperties))) return false;
/* 154 */     if ((thisPattern) && (!otherProperties.entrySet().containsAll(thisProperties.entrySet()))) { return false;
/*     */     }
/* 156 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCanonicalKeyPropertyListString()
/*     */   {
/* 165 */     String canonical = getCanonicalName();
/* 166 */     int index = canonical.indexOf(':');
/* 167 */     String list = canonical.substring(index + 1);
/* 168 */     if (isPropertyPattern())
/*     */     {
/* 170 */       if (getKeyPropertyListString().length() == 0) {
/* 171 */         return list.substring(0, list.length() - "*".length());
/*     */       }
/* 173 */       return list.substring(0, list.length() - ",*".length());
/*     */     }
/* 175 */     return list;
/*     */   }
/*     */   
/*     */   public String getCanonicalName()
/*     */   {
/* 180 */     return this.canonicalName;
/*     */   }
/*     */   
/*     */   public String getDomain()
/*     */   {
/* 185 */     String canonical = getCanonicalName();
/* 186 */     int index = canonical.indexOf(':');
/* 187 */     return canonical.substring(0, index);
/*     */   }
/*     */   
/*     */   public String getKeyProperty(String key)
/*     */   {
/* 192 */     Map props = getPropertiesMap();
/* 193 */     return (String)props.get(key);
/*     */   }
/*     */   
/*     */   public Hashtable getKeyPropertyList()
/*     */   {
/* 198 */     return new Hashtable(getPropertiesMap());
/*     */   }
/*     */   
/*     */ 
/*     */   private Map getPropertiesMap()
/*     */   {
/*     */     try
/*     */     {
/* 206 */       return convertStringToProperties(getKeyPropertyListString(), null);
/*     */     }
/*     */     catch (MalformedObjectNameException x) {}
/*     */     
/* 210 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getKeyPropertyListString()
/*     */   {
/* 216 */     return this.propertiesString;
/*     */   }
/*     */   
/*     */   public boolean isPattern()
/*     */   {
/* 221 */     return (isDomainPattern()) || (isPropertyPattern());
/*     */   }
/*     */   
/*     */   public boolean isPropertyPattern()
/*     */   {
/* 226 */     return this.isPropertyPattern;
/*     */   }
/*     */   
/*     */   public boolean isDomainPattern()
/*     */   {
/* 231 */     return this.isDomainPattern;
/*     */   }
/*     */   
/*     */   public static ObjectName getInstance(ObjectName name)
/*     */   {
/* 236 */     if (name.getClass() == ObjectName.class) { return name;
/*     */     }
/*     */     try
/*     */     {
/* 240 */       return getInstance(name.getCanonicalName());
/*     */     }
/*     */     catch (MalformedObjectNameException x)
/*     */     {
/* 244 */       throw new IllegalArgumentException(x.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   public static ObjectName getInstance(String name) throws MalformedObjectNameException
/*     */   {
/* 250 */     if (cacheEnabled)
/*     */     {
/* 252 */       ObjectName cached = null;
/* 253 */       synchronized (cache)
/*     */       {
/* 255 */         cached = cache.get(name);
/*     */       }
/* 257 */       if (cached != null) { return cached;
/*     */       }
/*     */     }
/*     */     
/* 261 */     return new ObjectName(name);
/*     */   }
/*     */   
/*     */   public static ObjectName getInstance(String domain, Hashtable table) throws MalformedObjectNameException
/*     */   {
/* 266 */     return new ObjectName(domain, table);
/*     */   }
/*     */   
/*     */   public static ObjectName getInstance(String domain, String key, String value) throws MalformedObjectNameException
/*     */   {
/* 271 */     return new ObjectName(domain, key, value);
/*     */   }
/*     */   
/*     */   public static String quote(String value)
/*     */   {
/* 276 */     StringBuffer buffer = new StringBuffer("\"");
/* 277 */     for (int i = 0; i < value.length(); i++)
/*     */     {
/* 279 */       char ch = value.charAt(i);
/* 280 */       switch (ch)
/*     */       {
/*     */       case '\n': 
/* 283 */         buffer.append("\\n");
/* 284 */         break;
/*     */       case '"': 
/* 286 */         buffer.append("\\\"");
/* 287 */         break;
/*     */       case '\\': 
/* 289 */         buffer.append("\\\\");
/* 290 */         break;
/*     */       case '*': 
/* 292 */         buffer.append("\\*");
/* 293 */         break;
/*     */       case '?': 
/* 295 */         buffer.append("\\?");
/* 296 */         break;
/*     */       default: 
/* 298 */         buffer.append(ch);
/*     */       }
/*     */       
/*     */     }
/* 302 */     buffer.append("\"");
/* 303 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public static String unquote(String value) throws IllegalArgumentException
/*     */   {
/* 308 */     int lastIndex = value.length() - 1;
/* 309 */     if ((lastIndex < 1) || (value.charAt(0) != '"') || (value.charAt(lastIndex) != '"')) { throw new IllegalArgumentException("The given string is not quoted");
/*     */     }
/* 311 */     StringBuffer buffer = new StringBuffer();
/* 312 */     for (int i = 1; i < lastIndex; i++)
/*     */     {
/* 314 */       char ch = value.charAt(i);
/* 315 */       if (ch == '\\')
/*     */       {
/*     */ 
/* 318 */         i++;
/* 319 */         if (i == lastIndex) throw new IllegalArgumentException("Invalid escape sequence at the end of quoted string");
/* 320 */         ch = value.charAt(i);
/* 321 */         switch (ch)
/*     */         {
/*     */         case 'n': 
/* 324 */           buffer.append("\n");
/* 325 */           break;
/*     */         case '"': 
/* 327 */           buffer.append("\"");
/* 328 */           break;
/*     */         case '\\': 
/* 330 */           buffer.append("\\");
/* 331 */           break;
/*     */         case '*': 
/* 333 */           buffer.append("*");
/* 334 */           break;
/*     */         case '?': 
/* 336 */           buffer.append("?");
/* 337 */           break;
/*     */         default: 
/* 339 */           throw new IllegalArgumentException("Invalid escape sequence: \\" + ch);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 344 */         switch (ch)
/*     */         {
/*     */         case '\n': 
/*     */         case '"': 
/*     */         case '*': 
/*     */         case '?': 
/* 350 */           throw new IllegalArgumentException("Invalid unescaped character: " + ch);
/*     */         }
/* 352 */         buffer.append(ch);
/*     */       }
/*     */     }
/*     */     
/* 356 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private void parse(String name) throws MalformedObjectNameException
/*     */   {
/* 361 */     boolean isSubclass = getClass() != ObjectName.class;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 367 */     if ((cacheEnabled) && (!isSubclass))
/*     */     {
/* 369 */       ObjectName cached = null;
/* 370 */       synchronized (cache)
/*     */       {
/* 372 */         cached = cache.get(name);
/*     */       }
/* 374 */       if (cached != null)
/*     */       {
/*     */ 
/* 377 */         this.propertiesString = cached.getKeyPropertyListString();
/* 378 */         this.isDomainPattern = cached.isDomainPattern();
/* 379 */         this.isPropertyPattern = cached.isPropertyPattern();
/* 380 */         this.canonicalName = cached.getCanonicalName();
/* 381 */         return;
/*     */       }
/*     */     }
/*     */     
/* 385 */     String domain = parseDomain(name);
/* 386 */     if (!isDomainValid(domain)) { throw new MalformedObjectNameException("Invalid domain: " + domain);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 394 */     String properties = parseProperties(name);
/*     */     
/* 396 */     if (properties.trim().length() < 1) throw new MalformedObjectNameException("Missing properties");
/* 397 */     if (properties.trim().endsWith(",")) throw new MalformedObjectNameException("Missing property after trailing comma");
/* 398 */     StringBuffer propsString = new StringBuffer();
/* 399 */     Map table = convertStringToProperties(properties, propsString);
/*     */     
/* 401 */     init(domain, propsString.toString(), table);
/*     */     
/* 403 */     if ((cacheEnabled) && (!isSubclass))
/*     */     {
/*     */ 
/* 406 */       synchronized (cache)
/*     */       {
/*     */ 
/* 409 */         cache.put(name, this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private String parseDomain(String objectName) throws MalformedObjectNameException
/*     */   {
/* 416 */     int colon = objectName.indexOf(':');
/* 417 */     if (colon < 0) { throw new MalformedObjectNameException("Missing ':' character in ObjectName");
/*     */     }
/* 419 */     String domain = objectName.substring(0, colon);
/* 420 */     return domain;
/*     */   }
/*     */   
/*     */   private boolean isDomainValid(String domain)
/*     */   {
/* 425 */     if (domain == null) return false;
/* 426 */     if (domain.indexOf('\n') >= 0) return false;
/* 427 */     if (domain.indexOf(":") >= 0) return false;
/* 428 */     return true;
/*     */   }
/*     */   
/*     */   private String parseProperties(String objectName) throws MalformedObjectNameException
/*     */   {
/* 433 */     int colon = objectName.indexOf(':');
/* 434 */     if (colon < 0) { throw new MalformedObjectNameException("Missing ':' character in ObjectName");
/*     */     }
/* 436 */     String list = objectName.substring(colon + 1);
/* 437 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map convertStringToProperties(String properties, StringBuffer buffer)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 450 */     if (buffer != null) buffer.setLength(0);
/* 451 */     Map table = new HashMap();
/*     */     
/* 453 */     StringBuffer toBeParsed = new StringBuffer(properties);
/* 454 */     while (toBeParsed.length() > 0)
/*     */     {
/* 456 */       String key = parsePropertyKey(toBeParsed);
/*     */       
/* 458 */       String value = null;
/* 459 */       if ("*".equals(key)) {
/* 460 */         value = "*";
/*     */       } else {
/* 462 */         value = parsePropertyValue(toBeParsed);
/*     */       }
/* 464 */       Object duplicate = table.put(key, value);
/* 465 */       if (duplicate != null) { throw new MalformedObjectNameException("Duplicate key not allowed: " + key);
/*     */       }
/* 467 */       if ((buffer != null) && (!"*".equals(key)))
/*     */       {
/* 469 */         if (buffer.length() > 0) buffer.append(',');
/* 470 */         buffer.append(key).append('=').append(value);
/*     */       }
/*     */     }
/*     */     
/* 474 */     return table;
/*     */   }
/*     */   
/*     */   private String parsePropertyKey(StringBuffer buffer) throws MalformedObjectNameException
/*     */   {
/* 479 */     String toBeParsed = buffer.toString();
/* 480 */     int equal = toBeParsed.indexOf('=');
/* 481 */     int comma = toBeParsed.indexOf(',');
/*     */     
/* 483 */     if ((equal < 0) && (comma < 0))
/*     */     {
/*     */ 
/* 486 */       String key = toBeParsed.trim();
/* 487 */       if (!"*".equals(key)) throw new MalformedObjectNameException("Invalid key: '" + key + "'");
/* 488 */       buffer.setLength(0);
/* 489 */       return key;
/*     */     }
/*     */     
/* 492 */     if ((comma >= 0) && (comma < equal))
/*     */     {
/*     */ 
/* 495 */       String key = toBeParsed.substring(0, comma).trim();
/* 496 */       if (!"*".equals(key)) throw new MalformedObjectNameException("Invalid key: '" + key + "'");
/* 497 */       buffer.delete(0, comma + 1);
/* 498 */       return key;
/*     */     }
/*     */     
/*     */ 
/* 502 */     String key = toBeParsed.substring(0, equal);
/* 503 */     if (!isKeyValid(key)) throw new MalformedObjectNameException("Invalid key: '" + key + "'");
/* 504 */     buffer.delete(0, equal + 1);
/* 505 */     return key;
/*     */   }
/*     */   
/*     */   private boolean isKeyValid(String key)
/*     */   {
/* 510 */     if (key == null) return false;
/* 511 */     if (key.trim().length() < 1) return false;
/* 512 */     if (key.indexOf('\n') >= 0) return false;
/* 513 */     if (key.indexOf(',') >= 0) return false;
/* 514 */     if (key.indexOf('=') >= 0) return false;
/* 515 */     if (key.indexOf('*') >= 0) return false;
/* 516 */     if (key.indexOf('?') >= 0) return false;
/* 517 */     if (key.indexOf(':') >= 0) return false;
/* 518 */     return true;
/*     */   }
/*     */   
/*     */   private String parsePropertyValue(StringBuffer buffer) throws MalformedObjectNameException
/*     */   {
/* 523 */     String toBeParsed = buffer.toString();
/* 524 */     if (toBeParsed.trim().startsWith("\""))
/*     */     {
/*     */ 
/* 527 */       int start = toBeParsed.indexOf('"') + 1;
/* 528 */       int endQuote = -1;
/*     */       
/* 530 */       while ((endQuote = toBeParsed.indexOf('"', start)) >= 0)
/*     */       {
/* 532 */         int bslashes = countBackslashesBackwards(toBeParsed, endQuote);
/* 533 */         if (bslashes % 2 != 0)
/*     */         {
/* 535 */           start = endQuote + 1;
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 540 */           String value = toBeParsed.substring(0, endQuote + 1).trim();
/* 541 */           if (!isValueValid(value)) { throw new MalformedObjectNameException("Invalid value: '" + value + "'");
/*     */           }
/* 543 */           buffer.delete(0, endQuote + 1);
/*     */           
/* 545 */           toBeParsed = buffer.toString();
/* 546 */           if (toBeParsed.trim().startsWith(","))
/*     */           {
/* 548 */             int comma = toBeParsed.indexOf(',');
/* 549 */             buffer.delete(0, comma + 1);
/* 550 */             return value;
/*     */           }
/* 552 */           if (toBeParsed.trim().length() == 0)
/*     */           {
/* 554 */             buffer.setLength(0);
/* 555 */             return value;
/*     */           }
/*     */           
/*     */ 
/* 559 */           throw new MalformedObjectNameException("Garbage after quoted value: " + toBeParsed);
/*     */         }
/*     */       }
/* 562 */       throw new MalformedObjectNameException("Missing closing quote: " + toBeParsed);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 567 */     int comma = toBeParsed.indexOf(',');
/* 568 */     if (comma >= 0)
/*     */     {
/* 570 */       String value = toBeParsed.substring(0, comma);
/* 571 */       if (!isValueValid(value)) throw new MalformedObjectNameException("Invalid value: '" + value + "'");
/* 572 */       buffer.delete(0, comma + 1);
/* 573 */       return value;
/*     */     }
/*     */     
/*     */ 
/* 577 */     String value = toBeParsed;
/* 578 */     if (!isValueValid(value)) throw new MalformedObjectNameException("Invalid value: '" + value + "'");
/* 579 */     buffer.setLength(0);
/* 580 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int indexOfLastConsecutiveBackslash(String value, int from)
/*     */   {
/* 587 */     int index = value.indexOf('\\', from);
/* 588 */     if (index < 0) return index;
/* 589 */     if (index == value.length() - 1) { return index;
/*     */     }
/* 591 */     int next = indexOfLastConsecutiveBackslash(value, from + 1);
/* 592 */     if (next < 0) {
/* 593 */       return index;
/*     */     }
/* 595 */     return next;
/*     */   }
/*     */   
/*     */   private boolean isValueValid(String value)
/*     */   {
/* 600 */     if (value == null) return false;
/* 601 */     if (value.length() == 0) return false;
/* 602 */     if (value.indexOf('\n') >= 0) { return false;
/*     */     }
/* 604 */     if (value.trim().startsWith("\""))
/*     */     {
/*     */ 
/* 607 */       value = value.substring(1, value.length() - 1);
/*     */       
/*     */ 
/* 610 */       int start = 0;
/* 611 */       int index = -1;
/*     */       do
/*     */       {
/* 614 */         index = indexOfLastConsecutiveBackslash(value, start);
/* 615 */         if (index >= 0)
/*     */         {
/*     */ 
/* 618 */           int count = countBackslashesBackwards(value, index + 1);
/* 619 */           if (count % 2 != 0)
/*     */           {
/*     */ 
/* 622 */             if (index == value.length() - 1) { return false;
/*     */             }
/* 624 */             char next = value.charAt(index + 1);
/* 625 */             if ((next != '\\') && (next != 'n') && (next != '"') && (next != '?') && (next != '*')) return false;
/*     */           }
/* 627 */           start = index + 1;
/*     */         }
/*     */         
/* 630 */       } while (index >= 0);
/*     */       
/* 632 */       start = 0;
/* 633 */       index = -1;
/*     */       do
/*     */       {
/* 636 */         index = value.indexOf('"', start);
/* 637 */         if (index < 0) index = value.indexOf('*', start);
/* 638 */         if (index < 0) index = value.indexOf('?', start);
/* 639 */         if (index >= 0)
/*     */         {
/* 641 */           int bslashCount = countBackslashesBackwards(value, index);
/*     */           
/* 643 */           if (bslashCount % 2 == 0) return false;
/* 644 */           start = index + 1;
/*     */         }
/*     */         
/* 647 */       } while (index >= 0);
/*     */     }
/*     */     else
/*     */     {
/* 651 */       if (value.indexOf(',') >= 0) return false;
/* 652 */       if (value.indexOf('=') >= 0) return false;
/* 653 */       if (value.indexOf(':') >= 0) return false;
/* 654 */       if (value.indexOf('"') >= 0) return false;
/* 655 */       if (value.indexOf('*') >= 0) return false;
/* 656 */       if (value.indexOf('?') >= 0) return false;
/*     */     }
/* 658 */     return true;
/*     */   }
/*     */   
/*     */   private int countBackslashesBackwards(String string, int from)
/*     */   {
/* 663 */     int bslashCount = 0;
/* 664 */     for (;;) { from--; if (from < 0)
/*     */         break;
/* 666 */       if (string.charAt(from) != '\\') break;
/* 667 */       bslashCount++;
/*     */     }
/*     */     
/*     */ 
/* 671 */     return bslashCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init(String domain, String propertiesString, Map properties)
/*     */   {
/* 681 */     initDomain(domain);
/* 682 */     initProperties(properties);
/* 683 */     this.propertiesString = propertiesString;
/* 684 */     StringBuffer buffer = new StringBuffer(domain).append(':').append(convertPropertiesToString(new TreeMap(properties)));
/* 685 */     if (isPropertyPattern())
/*     */     {
/* 687 */       if (getKeyPropertyListString().length() == 0) {
/* 688 */         buffer.append('*');
/*     */       } else
/* 690 */         buffer.append(",*");
/*     */     }
/* 692 */     this.canonicalName = buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initDomain(String domain)
/*     */   {
/* 701 */     if ((domain.indexOf('*') >= 0) || (domain.indexOf('?') >= 0))
/*     */     {
/* 703 */       this.isDomainPattern = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initProperties(Map properties)
/*     */   {
/* 714 */     if (properties.containsKey("*"))
/*     */     {
/*     */ 
/* 717 */       properties.remove("*");
/* 718 */       this.isPropertyPattern = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String convertPropertiesToString(Map properties)
/*     */   {
/* 728 */     StringBuffer b = new StringBuffer();
/* 729 */     boolean firstTime = true;
/* 730 */     for (Iterator i = properties.entrySet().iterator(); i.hasNext();)
/*     */     {
/* 732 */       if (!firstTime) {
/* 733 */         b.append(",");
/*     */       } else {
/* 735 */         firstTime = false;
/*     */       }
/* 737 */       Map.Entry entry = (Map.Entry)i.next();
/* 738 */       b.append(entry.getKey());
/* 739 */       b.append("=");
/* 740 */       b.append(entry.getValue());
/*     */     }
/*     */     
/* 743 */     return b.toString();
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 748 */     return getCanonicalName().hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 753 */     if (obj == null) return false;
/* 754 */     if (obj == this) { return true;
/*     */     }
/*     */     try
/*     */     {
/* 758 */       ObjectName other = (ObjectName)obj;
/* 759 */       return getCanonicalName().equals(other.getCanonicalName());
/*     */     }
/*     */     catch (ClassCastException ignored) {}
/*     */     
/*     */ 
/* 764 */     return false;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 769 */     return getName(false);
/*     */   }
/*     */   
/*     */ 
/*     */   private String getName(boolean canonical)
/*     */   {
/* 775 */     StringBuffer buffer = new StringBuffer(getDomain()).append(':');
/* 776 */     String properties = canonical ? getCanonicalKeyPropertyListString() : getKeyPropertyListString();
/* 777 */     buffer.append(properties);
/* 778 */     if (isPropertyPattern())
/*     */     {
/* 780 */       if (properties.length() == 0) {
/* 781 */         buffer.append("*");
/*     */       } else
/* 783 */         buffer.append(",*");
/*     */     }
/* 785 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException
/*     */   {
/* 790 */     out.defaultWriteObject();
/* 791 */     String name = getName(false);
/* 792 */     out.writeObject(name);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/* 797 */     in.defaultReadObject();
/* 798 */     String objectName = (String)in.readObject();
/*     */     try
/*     */     {
/* 801 */       parse(objectName);
/*     */     }
/*     */     catch (MalformedObjectNameException x)
/*     */     {
/* 805 */       throw new InvalidObjectException("String representing the ObjectName is not a valid ObjectName: " + x.toString()); } }
/*     */   
/*     */   public void setMBeanServer(MBeanServer server) {}
/*     */   
/* 809 */   private static class WeakObjectNameCache { WeakObjectNameCache(ObjectName.1 x0) { this(); }
/*     */     
/* 811 */     private WeakObjectNameCache() { this.queue = new ReferenceQueue();
/* 812 */       this.map = new HashMap();
/*     */     }
/*     */     
/*     */     public void put(String key, ObjectName value) {
/* 816 */       cleanup();
/* 817 */       this.map.put(key, WeakValue.create(key, value, this.queue));
/*     */     }
/*     */     
/*     */     public ObjectName get(String key)
/*     */     {
/* 822 */       cleanup();
/* 823 */       WeakValue value = (WeakValue)this.map.get(key);
/* 824 */       if (value == null) {
/* 825 */         return null;
/*     */       }
/* 827 */       return (ObjectName)value.get();
/*     */     }
/*     */     
/*     */     private void cleanup()
/*     */     {
/* 832 */       WeakValue ref = null;
/* 833 */       while ((ref = (WeakValue)this.queue.poll()) != null)
/*     */       {
/* 835 */         this.map.remove(ref.getKey());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     private ReferenceQueue queue;
/*     */     
/*     */     private HashMap map;
/*     */     private static final class WeakValue
/*     */       extends WeakReference
/*     */     {
/*     */       private Object key;
/*     */       
/*     */       public static WeakValue create(Object key, Object value, ReferenceQueue queue)
/*     */       {
/* 850 */         if (value == null) return null;
/* 851 */         return new WeakValue(key, value, queue);
/*     */       }
/*     */       
/*     */       private WeakValue(Object key, Object value, ReferenceQueue queue)
/*     */       {
/* 856 */         super(queue);
/* 857 */         this.key = key;
/*     */       }
/*     */       
/*     */       public Object getKey()
/*     */       {
/* 862 */         return this.key;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/ObjectName.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */