/*    */ package javax.management;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Attribute
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 2484220110589082382L;
/*    */   private final String name;
/*    */   private final Object value;
/*    */   private transient int hash;
/*    */   
/*    */   public Attribute(String name, Object value)
/*    */   {
/* 33 */     if (name == null) { throw new RuntimeOperationsException(new IllegalArgumentException("The name of an attribute cannot be null"));
/*    */     }
/* 35 */     this.name = name;
/* 36 */     this.value = value;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 41 */     if (obj == null) return false;
/* 42 */     if (obj == this) { return true;
/*    */     }
/*    */     try
/*    */     {
/* 46 */       Attribute other = (Attribute)obj;
/* 47 */       boolean namesEqual = this.name.equals(other.name);
/* 48 */       boolean valuesEqual = false;
/* 49 */       if (this.value == null) {
/* 50 */         valuesEqual = other.value == null;
/*    */       } else
/* 52 */         valuesEqual = this.value.equals(other.value);
/* 53 */       return (namesEqual) && (valuesEqual);
/*    */     }
/*    */     catch (ClassCastException ignored) {}
/*    */     
/*    */ 
/* 58 */     return false;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 63 */     if (this.hash == 0) this.hash = computeHash();
/* 64 */     return this.hash;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 69 */     return this.name;
/*    */   }
/*    */   
/*    */   public Object getValue()
/*    */   {
/* 74 */     return this.value;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 79 */     return "Attribute's name: " + getName() + ", value: " + getValue();
/*    */   }
/*    */   
/*    */   private int computeHash()
/*    */   {
/* 84 */     int hash = this.name.hashCode();
/* 85 */     if (this.value != null) hash ^= this.value.hashCode();
/* 86 */     return hash;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/Attribute.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */