/*    */ package javax.management;
/*    */ 
/*    */ import java.security.BasicPermission;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanTrustPermission
/*    */   extends BasicPermission
/*    */ {
/*    */   private static final long serialVersionUID = -2952178077029018140L;
/*    */   
/*    */   public MBeanTrustPermission(String name)
/*    */   {
/* 33 */     this(name, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MBeanTrustPermission(String name, String actions)
/*    */   {
/* 44 */     super(name, actions);
/* 45 */     if ((!"register".equals(name)) && (!"*".equals(name))) throw new IllegalArgumentException("Target name must be 'register' or '*' not '" + name + "'");
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanTrustPermission.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */