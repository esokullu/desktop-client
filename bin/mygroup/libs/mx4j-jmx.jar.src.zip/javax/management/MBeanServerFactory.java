/*     */ package javax.management;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import javax.management.loading.ClassLoaderRepository;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanServerFactory
/*     */ {
/*  26 */   private static ArrayList servers = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Logger getLogger()
/*     */   {
/*  34 */     return Log.getLogger(MBeanServerFactory.class.getName());
/*     */   }
/*     */   
/*     */   public static MBeanServer createMBeanServer()
/*     */   {
/*  39 */     return createMBeanServer(null);
/*     */   }
/*     */   
/*     */   public static MBeanServer createMBeanServer(String defaultDomain)
/*     */   {
/*  44 */     MBeanServer server = createMBeanServerImpl(defaultDomain, "createMBeanServer");
/*  45 */     synchronized (servers)
/*     */     {
/*  47 */       servers.add(server);
/*     */     }
/*  49 */     Logger logger = getLogger();
/*  50 */     if (logger.isEnabledFor(0)) logger.trace("MBeanServer " + server + " registered successfully");
/*  51 */     return server;
/*     */   }
/*     */   
/*     */   public static MBeanServer newMBeanServer()
/*     */   {
/*  56 */     return newMBeanServer(null);
/*     */   }
/*     */   
/*     */   public static MBeanServer newMBeanServer(String defaultDomain)
/*     */   {
/*  61 */     return createMBeanServerImpl(defaultDomain, "newMBeanServer");
/*     */   }
/*     */   
/*     */   public static void releaseMBeanServer(MBeanServer server)
/*     */   {
/*  66 */     Logger logger = getLogger();
/*     */     try
/*     */     {
/*  69 */       if (logger.isEnabledFor(0)) { logger.trace("Releasing MBeanServer " + server);
/*     */       }
/*  71 */       if (server != null)
/*     */       {
/*  73 */         SecurityManager sm = System.getSecurityManager();
/*  74 */         if (sm != null) { sm.checkPermission(new MBeanServerPermission("releaseMBeanServer"));
/*     */         }
/*  76 */         boolean removed = false;
/*  77 */         synchronized (servers)
/*     */         {
/*  79 */           removed = servers.remove(server);
/*     */         }
/*     */         
/*  82 */         if (removed)
/*     */         {
/*  84 */           if (logger.isEnabledFor(0)) { logger.trace("MBeanServer " + server + " released successfully");
/*     */           }
/*     */           
/*     */         }
/*  88 */         else if (logger.isEnabledFor(20)) { logger.info("MBeanServer " + server + " not released, cannot find it");
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*  93 */       else if (logger.isEnabledFor(10)) { logger.debug("Cannot release a null MBeanServer");
/*     */       }
/*     */     }
/*     */     catch (SecurityException x)
/*     */     {
/*  98 */       if (logger.isEnabledFor(0)) logger.trace("Security Exception caught while releasing MBeanServer " + server, x);
/*  99 */       throw x;
/*     */     }
/*     */   }
/*     */   
/*     */   public static ArrayList findMBeanServer(String id)
/*     */   {
/* 105 */     Logger logger = getLogger();
/* 106 */     ArrayList list = null;
/*     */     try
/*     */     {
/* 109 */       if (logger.isEnabledFor(0)) { logger.trace("Finding MBeanServer with ID: " + id);
/*     */       }
/* 111 */       SecurityManager sm = System.getSecurityManager();
/* 112 */       if (sm != null) { sm.checkPermission(new MBeanServerPermission("findMBeanServer"));
/*     */       }
/* 114 */       if (id == null)
/*     */       {
/* 116 */         list = (ArrayList)servers.clone();
/*     */       }
/*     */       else
/*     */       {
/* 120 */         list = new ArrayList();
/* 121 */         synchronized (servers)
/*     */         {
/* 123 */           for (int i = 0; i < servers.size(); i++)
/*     */           {
/* 125 */             MBeanServer server = (MBeanServer)servers.get(i);
/* 126 */             String serverId = getMBeanServerId(server);
/* 127 */             if (id.equals(serverId))
/*     */             {
/* 129 */               list.add(server);
/* 130 */               if (logger.isEnabledFor(0)) { logger.trace("Found matching MBeanServer: " + server);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 136 */       if (logger.isEnabledFor(0)) { logger.trace("MBeanServer(s) found: " + list);
/*     */       }
/* 138 */       return list;
/*     */     }
/*     */     catch (SecurityException x)
/*     */     {
/* 142 */       if (logger.isEnabledFor(0)) logger.trace("Security Exception caught while finding MBeanServer with ID: " + id, x);
/* 143 */       throw x;
/*     */     }
/*     */   }
/*     */   
/*     */   private static String getMBeanServerId(MBeanServer server)
/*     */   {
/*     */     try
/*     */     {
/* 151 */       (String)AccessController.doPrivileged(new PrivilegedExceptionAction() {
/*     */         private final MBeanServer val$server;
/*     */         
/*     */         public Object run() throws Exception {
/* 155 */           return this.val$server.getAttribute(ObjectName.getInstance("JMImplementation:type=MBeanServerDelegate"), "MBeanServerId");
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (SecurityException x)
/*     */     {
/* 161 */       Logger logger = getLogger();
/* 162 */       if (logger.isEnabledFor(0)) logger.trace("No permission to get MBeanServerID", x);
/*     */     }
/*     */     catch (PrivilegedActionException x)
/*     */     {
/* 166 */       Logger logger = getLogger();
/* 167 */       if (logger.isEnabledFor(0)) logger.trace("Could not get MBeanServerID", x.getException());
/*     */     }
/*     */     catch (Throwable x)
/*     */     {
/* 171 */       Logger logger = getLogger();
/* 172 */       if (logger.isEnabledFor(0)) logger.trace("Could not get MBeanServerID", x);
/*     */     }
/* 174 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public static ClassLoaderRepository getClassLoaderRepository(MBeanServer server)
/*     */   {
/* 180 */     return server.getClassLoaderRepository();
/*     */   }
/*     */   
/*     */   private static MBeanServer createMBeanServerImpl(String domain, String permission)
/*     */   {
/* 185 */     Logger logger = getLogger();
/* 186 */     boolean trace = logger.isEnabledFor(0);
/*     */     try
/*     */     {
/* 189 */       SecurityManager sm = System.getSecurityManager();
/* 190 */       if (sm != null) { sm.checkPermission(new MBeanServerPermission(permission));
/*     */       }
/*     */       
/*     */ 
/* 194 */       if (trace) logger.trace("Obtaining MBeanServerBuilder");
/* 195 */       MBeanServerBuilder builder = createMBeanServerBuilder();
/* 196 */       if (trace) { logger.trace("Using MBeanServerBuilder " + builder.getClass());
/*     */       }
/*     */       
/*     */ 
/* 200 */       if (trace) logger.trace("Creating MBeanServerDelegate...");
/* 201 */       MBeanServerDelegate delegate = builder.newMBeanServerDelegate();
/* 202 */       if (trace) { logger.trace("MBeanServerDelegate " + delegate.getClass() + " created successfully");
/*     */       }
/*     */       
/*     */ 
/* 206 */       if (trace) logger.trace("Creating MBeanServer...");
/* 207 */       MBeanServer mbs = builder.newMBeanServer(domain, null, delegate);
/* 208 */       if (trace) logger.trace("MBeanServer " + mbs + " created successfully");
/* 209 */       if (logger.isEnabledFor(20))
/*     */       {
/* 211 */         String mbeanServerId = getMBeanServerId(mbs);
/* 212 */         if (mbeanServerId != null) {
/* 213 */           logger.info("Created MBeanServer with ID: " + mbeanServerId);
/*     */         } else
/* 215 */           logger.info("Created MBeanServer");
/*     */       }
/* 217 */       return mbs;
/*     */     }
/*     */     catch (SecurityException x)
/*     */     {
/* 221 */       if (trace) logger.trace("Security Exception caught while creating an MBeanServer", x);
/* 222 */       throw x;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static MBeanServerBuilder createMBeanServerBuilder()
/*     */   {
/* 229 */     Class builderClass = loadMBeanServerBuilderClass();
/*     */     try
/*     */     {
/* 232 */       return (MBeanServerBuilder)builderClass.newInstance();
/*     */     }
/*     */     catch (ClassCastException e)
/*     */     {
/* 236 */       throw new JMRuntimeException("Specified MBeanServerBuilder must be a subclass of MBeanServerBuilder: " + builderClass);
/*     */     }
/*     */     catch (IllegalAccessException e)
/*     */     {
/* 240 */       throw new JMRuntimeException("Can't instantiate MBeanServerBuilder " + builderClass + ": " + e);
/*     */     }
/*     */     catch (InstantiationException e)
/*     */     {
/* 244 */       throw new JMRuntimeException("Can't instantiate MBeanServerBuilder " + builderClass + ": " + e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static Class loadMBeanServerBuilderClass()
/*     */   {
/* 251 */     String builderClassName = (String)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public Object run()
/*     */       {
/* 255 */         return System.getProperty("javax.management.builder.initial");
/*     */       }
/*     */     });
/*     */     
/* 259 */     if ((builderClassName == null) || (builderClassName.length() == 0))
/*     */     {
/* 261 */       return MBeanServerBuilder.class;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 266 */       return Thread.currentThread().getContextClassLoader().loadClass(builderClassName);
/*     */     }
/*     */     catch (ClassNotFoundException e)
/*     */     {
/* 270 */       throw new JMRuntimeException("MBeanServerBuilder class not found: " + builderClassName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanServerFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */