/*     */ package javax.management;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.security.Permission;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.StringTokenizer;
/*     */ import mx4j.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanPermission
/*     */   extends Permission
/*     */ {
/*     */   private static final long serialVersionUID = -2416928705275160661L;
/*     */   private static final String WILDCARD = "*";
/*     */   private static final String NILCARD = "-";
/*     */   private String actions;
/*     */   private transient int hash;
/*     */   private transient String className;
/*     */   private transient String memberName;
/*     */   private transient ObjectName objectName;
/*     */   private transient ArrayList actionsList;
/*     */   
/*     */   public MBeanPermission(String name, String actions)
/*     */   {
/*  71 */     super(name);
/*  72 */     this.actions = actions;
/*     */     
/*  74 */     parse(name, actions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MBeanPermission(String className, String memberName, ObjectName objectName, String actions)
/*     */   {
/*  88 */     this(createTargetName(className, memberName, objectName), actions);
/*     */   }
/*     */   
/*     */   private static String createTargetName(String className, String memberName, ObjectName objectName)
/*     */   {
/*  93 */     StringBuffer target = new StringBuffer();
/*     */     
/*  95 */     if (className != null) { target.append(className);
/*     */     }
/*  97 */     if (memberName != null)
/*     */     {
/*  99 */       target.append("#");
/* 100 */       target.append(memberName);
/*     */     }
/*     */     
/* 103 */     if (objectName != null)
/*     */     {
/* 105 */       target.append("[");
/* 106 */       target.append(objectName.getCanonicalName());
/* 107 */       target.append("]");
/*     */     }
/*     */     
/* 110 */     if (target.length() == 0) { return "*";
/*     */     }
/* 112 */     return target.toString();
/*     */   }
/*     */   
/*     */   private void parse(String name, String actions)
/*     */   {
/* 117 */     this.className = parseClassName(name);
/* 118 */     this.memberName = parseMemberName(name);
/* 119 */     this.objectName = parseObjectName(name);
/* 120 */     this.actionsList = parseActions(actions);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 125 */     if (this.hash == 0) this.hash = computeHash();
/* 126 */     return this.hash;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 131 */     if (obj == null) return false;
/* 132 */     if (obj == this) return true;
/* 133 */     if (getClass() != obj.getClass()) { return false;
/*     */     }
/*     */     
/* 136 */     MBeanPermission other = (MBeanPermission)obj;
/*     */     
/*     */ 
/* 139 */     if (!areEqual(getClassName(), other.getClassName())) return false;
/* 140 */     if (!areEqual(getMemberName(), other.getMemberName())) return false;
/* 141 */     if (!areEqual(getObjectName(), other.getObjectName())) return false;
/* 142 */     return getActionsList().equals(other.getActionsList());
/*     */   }
/*     */   
/*     */   private boolean areEqual(Object obj1, Object obj2)
/*     */   {
/* 147 */     if (obj1 == null) return obj2 == null;
/* 148 */     return obj1.equals(obj2);
/*     */   }
/*     */   
/*     */   public String getActions()
/*     */   {
/* 153 */     return this.actions;
/*     */   }
/*     */   
/*     */   private String getClassName()
/*     */   {
/* 158 */     return this.className;
/*     */   }
/*     */   
/*     */   private String getMemberName()
/*     */   {
/* 163 */     return this.memberName;
/*     */   }
/*     */   
/*     */   private ObjectName getObjectName()
/*     */   {
/* 168 */     return this.objectName;
/*     */   }
/*     */   
/*     */   private ArrayList getActionsList()
/*     */   {
/* 173 */     return this.actionsList;
/*     */   }
/*     */   
/*     */   public boolean implies(Permission p)
/*     */   {
/* 178 */     if (p == null) return false;
/* 179 */     if (getClass() != p.getClass()) { return false;
/*     */     }
/* 181 */     MBeanPermission permission = (MBeanPermission)p;
/* 182 */     if (!impliesClassName(permission)) return false;
/* 183 */     if (!impliesMemberName(permission)) return false;
/* 184 */     if (!impliesObjectName(permission)) return false;
/* 185 */     if (!impliesActions(permission)) return false;
/* 186 */     return true;
/*     */   }
/*     */   
/*     */   private boolean impliesClassName(MBeanPermission p)
/*     */   {
/* 191 */     return impliesTarget(getClassName(), p.getClassName());
/*     */   }
/*     */   
/*     */   private boolean impliesMemberName(MBeanPermission p)
/*     */   {
/* 196 */     return impliesTarget(getMemberName(), p.getMemberName());
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean impliesTarget(String thisTarget, String otherTarget)
/*     */   {
/* 202 */     if (thisTarget == null) return otherTarget == null;
/* 203 */     if (otherTarget == null) { return true;
/*     */     }
/*     */     
/* 206 */     if (thisTarget.equals(otherTarget)) { return true;
/*     */     }
/*     */     
/*     */ 
/* 210 */     boolean otherWildcard = otherTarget.indexOf("*") >= 0;
/*     */     
/* 212 */     boolean thisWildcard = thisTarget.indexOf("*") >= 0;
/*     */     
/* 214 */     if (thisWildcard)
/*     */     {
/* 216 */       if (otherWildcard)
/*     */       {
/*     */ 
/* 219 */         return thisTarget.equals("*");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 224 */       return Utils.wildcardMatch(thisTarget, otherTarget);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 229 */     if (otherWildcard)
/*     */     {
/* 231 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 235 */     return thisTarget.equals(otherTarget);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean impliesObjectName(MBeanPermission p)
/*     */   {
/* 242 */     ObjectName name1 = getObjectName();
/* 243 */     ObjectName name2 = p.getObjectName();
/*     */     
/*     */ 
/* 246 */     if (name1 == null) return name2 == null;
/* 247 */     if (name2 == null) { return true;
/*     */     }
/* 249 */     return name1.implies(name2);
/*     */   }
/*     */   
/*     */   private boolean impliesActions(MBeanPermission p)
/*     */   {
/* 254 */     ArrayList thisActions = getActionsList();
/* 255 */     boolean thisWild = thisActions.contains("*");
/*     */     
/* 257 */     ArrayList otherActions = p.getActionsList();
/* 258 */     boolean otherWild = otherActions.contains("*");
/*     */     
/*     */ 
/* 261 */     if (thisWild) { return true;
/*     */     }
/* 263 */     if (otherWild) { return false;
/*     */     }
/* 265 */     if (thisActions.containsAll(otherActions)) { return true;
/*     */     }
/*     */     
/* 268 */     if ((otherActions.contains("queryNames")) && (thisActions.contains("queryMBeans")))
/*     */     {
/*     */ 
/* 271 */       for (int i = 0; i < otherActions.size(); i++)
/*     */       {
/* 273 */         Object perm = otherActions.get(i);
/* 274 */         if ((!"queryNames".equals(perm)) && 
/* 275 */           (!thisActions.contains(perm))) return false;
/*     */       }
/* 277 */       return true;
/*     */     }
/*     */     
/* 280 */     return false;
/*     */   }
/*     */   
/*     */   private String parseClassName(String name)
/*     */   {
/* 285 */     if (name == null) { throw new IllegalArgumentException("Target name cannot be null");
/*     */     }
/* 287 */     String target = name.trim();
/*     */     
/* 289 */     if (target.length() == 0) { throw new IllegalArgumentException("Target name cannot be empty");
/*     */     }
/*     */     
/* 292 */     int square = target.indexOf('[');
/* 293 */     if (square >= 0)
/*     */     {
/*     */ 
/* 296 */       target = target.substring(0, square).trim();
/*     */     }
/*     */     
/*     */ 
/* 300 */     if (target.length() == 0) { return "*";
/*     */     }
/*     */     
/* 303 */     int pound = target.indexOf('#');
/* 304 */     if (pound >= 0)
/*     */     {
/*     */ 
/* 307 */       target = target.substring(0, pound).trim();
/*     */     }
/*     */     
/*     */ 
/* 311 */     if (target.length() == 0) { return "*";
/*     */     }
/*     */     
/* 314 */     if (target.equals("-")) { return null;
/*     */     }
/* 316 */     return target;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String parseMemberName(String name)
/*     */   {
/* 323 */     String target = name.trim();
/*     */     
/*     */ 
/* 326 */     int square = target.indexOf('[');
/* 327 */     if (square >= 0)
/*     */     {
/*     */ 
/* 330 */       target = target.substring(0, square).trim();
/*     */     }
/*     */     
/*     */ 
/* 334 */     if (target.length() == 0) { return "*";
/*     */     }
/*     */     
/* 337 */     int pound = target.indexOf('#');
/* 338 */     if (pound >= 0)
/*     */     {
/*     */ 
/* 341 */       target = target.substring(pound + 1).trim();
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 346 */       target = "*";
/*     */     }
/*     */     
/*     */ 
/* 350 */     if (target.equals("-")) { return null;
/*     */     }
/* 352 */     return target;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private ObjectName parseObjectName(String name)
/*     */   {
/* 359 */     String target = name.trim();
/* 360 */     String inside = "*:*";
/*     */     
/*     */ 
/* 363 */     int open = target.indexOf('[');
/* 364 */     if (open >= 0)
/*     */     {
/* 366 */       int close = target.indexOf(']');
/* 367 */       if (close < 0) { throw new IllegalArgumentException("Missing closing ObjectName bracket");
/*     */       }
/*     */       
/* 370 */       inside = target.substring(open + 1, close).trim();
/* 371 */       if (inside.length() == 0) { throw new IllegalArgumentException("Empty string in ObjectName brackets");
/*     */       }
/*     */       
/* 374 */       if (inside.equals("-")) { return null;
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 380 */       return new ObjectName(inside);
/*     */ 
/*     */     }
/*     */     catch (MalformedObjectNameException x)
/*     */     {
/* 385 */       throw new IllegalArgumentException("Invalid ObjectName: " + inside);
/*     */     }
/*     */   }
/*     */   
/*     */   private ArrayList parseActions(String actions)
/*     */   {
/* 391 */     if (actions == null) { throw new IllegalArgumentException("Actions list cannot be null");
/*     */     }
/* 393 */     actions = actions.trim();
/*     */     
/* 395 */     if (actions.length() == 0) { throw new IllegalArgumentException("Actions list cannot be empty");
/*     */     }
/*     */     
/* 398 */     ArrayList list = new ArrayList();
/* 399 */     StringTokenizer tokenizer = new StringTokenizer(actions, ",");
/* 400 */     while (tokenizer.hasMoreTokens())
/*     */     {
/* 402 */       String token = tokenizer.nextToken().trim();
/* 403 */       if (token.length() != 0) {
/* 404 */         if (token.equals("*"))
/*     */         {
/* 406 */           list.clear();
/* 407 */           list.add("*");
/* 408 */           return list;
/*     */         }
/*     */         
/*     */ 
/* 412 */         list.add(token);
/*     */       }
/*     */     }
/*     */     
/* 416 */     if (list.size() < 1) { throw new IllegalArgumentException("No actions specified");
/*     */     }
/*     */     
/* 419 */     Collections.sort(list);
/*     */     
/* 421 */     return list;
/*     */   }
/*     */   
/*     */   private int computeHash()
/*     */   {
/* 426 */     String cls = getClassName();
/* 427 */     int hash = cls == null ? "-".hashCode() : cls.hashCode();
/* 428 */     String member = getMemberName();
/* 429 */     hash ^= (member == null ? "-".hashCode() : member.hashCode());
/* 430 */     ObjectName name = getObjectName();
/* 431 */     hash ^= (name == null ? "-".hashCode() : name.hashCode());
/* 432 */     hash ^= getActionsList().hashCode();
/* 433 */     return hash;
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException
/*     */   {
/* 438 */     stream.defaultReadObject();
/* 439 */     parse(getName(), getActions());
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanPermission.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */