/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BadAttributeValueExpException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -3105272988410493376L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final Object val;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BadAttributeValueExpException(Object value)
/*    */   {
/* 25 */     super(String.valueOf(value));
/* 26 */     this.val = value;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/BadAttributeValueExpException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */