/*    */ package javax.management;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectInstance
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -4099952623687795850L;
/*    */   private String className;
/*    */   private ObjectName name;
/*    */   
/*    */   public ObjectInstance(String objectName, String className)
/*    */     throws MalformedObjectNameException
/*    */   {
/* 41 */     this(new ObjectName(objectName), className);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ObjectInstance(ObjectName objectName, String className)
/*    */   {
/* 52 */     if ((objectName == null) || (objectName.isPattern())) throw new RuntimeOperationsException(new IllegalArgumentException("Invalid object name"));
/* 53 */     if ((className == null) || (className.trim().length() == 0)) throw new RuntimeOperationsException(new IllegalArgumentException("Class name cannot be null or empty"));
/* 54 */     this.name = objectName;
/* 55 */     this.className = className;
/*    */   }
/*    */   
/*    */   public boolean equals(Object object)
/*    */   {
/* 60 */     if (object == null) return false;
/* 61 */     if (object == this) { return true;
/*    */     }
/*    */     try
/*    */     {
/* 65 */       ObjectInstance other = (ObjectInstance)object;
/* 66 */       return (this.name.equals(other.name)) && (this.className.equals(other.className));
/*    */     }
/*    */     catch (ClassCastException ignored) {}
/*    */     
/*    */ 
/* 71 */     return false;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 76 */     return this.name.hashCode() ^ this.className.hashCode();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ObjectName getObjectName()
/*    */   {
/* 84 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getClassName()
/*    */   {
/* 94 */     return this.className;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 99 */     return getClassName() + "@" + getObjectName();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/ObjectInstance.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */