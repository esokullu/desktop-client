/*    */ package javax.management;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import mx4j.util.Utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanNotificationInfo
/*    */   extends MBeanFeatureInfo
/*    */   implements Cloneable, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -3888371564530107064L;
/*    */   private String[] types;
/*    */   
/*    */   public MBeanNotificationInfo(String[] notifsType, String name, String description)
/*    */   {
/* 40 */     super(name, description);
/* 41 */     this.types = (notifsType == null ? new String[0] : notifsType);
/*    */   }
/*    */   
/*    */   public Object clone()
/*    */   {
/*    */     try
/*    */     {
/* 48 */       return super.clone();
/*    */     }
/*    */     catch (CloneNotSupportedException ignored) {}
/*    */     
/* 52 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String[] getNotifTypes()
/*    */   {
/* 61 */     return this.types;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 66 */     return super.hashCode() + 29 * Utils.arrayHashCode(getNotifTypes());
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 71 */     if (!super.equals(obj)) return false;
/* 72 */     if (!(obj instanceof MBeanNotificationInfo)) { return false;
/*    */     }
/* 74 */     MBeanNotificationInfo other = (MBeanNotificationInfo)obj;
/* 75 */     return Utils.arrayEquals(getNotifTypes(), other.getNotifTypes());
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanNotificationInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */