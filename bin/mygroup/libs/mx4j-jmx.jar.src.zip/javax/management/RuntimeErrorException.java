/*     */ package javax.management;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuntimeErrorException
/*     */   extends JMRuntimeException
/*     */ {
/*     */   private static final long serialVersionUID = 704338937753949796L;
/*     */   private Error error;
/*     */   
/*     */   public RuntimeErrorException(Error error)
/*     */   {
/*  35 */     this.error = error;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RuntimeErrorException(Error error, String message)
/*     */   {
/*  46 */     super(message);
/*  47 */     this.error = error;
/*     */   }
/*     */   
/*     */   public String getMessage()
/*     */   {
/*  52 */     return super.getMessage() + " nested error is " + this.error;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Error getTargetError()
/*     */   {
/*  60 */     return this.error;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getCause()
/*     */   {
/*  68 */     return getTargetError();
/*     */   }
/*     */   
/*     */   public void printStackTrace()
/*     */   {
/*  73 */     if (this.error == null)
/*     */     {
/*  75 */       super.printStackTrace();
/*     */     }
/*     */     else
/*     */     {
/*  79 */       synchronized (System.err)
/*     */       {
/*  81 */         System.err.println(this);
/*  82 */         this.error.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void printStackTrace(PrintStream s)
/*     */   {
/*  89 */     if (this.error == null)
/*     */     {
/*  91 */       super.printStackTrace(s);
/*     */     }
/*     */     else
/*     */     {
/*  95 */       synchronized (s)
/*     */       {
/*  97 */         s.println(this);
/*  98 */         this.error.printStackTrace(s);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void printStackTrace(PrintWriter w)
/*     */   {
/* 105 */     if (this.error == null)
/*     */     {
/* 107 */       super.printStackTrace(w);
/*     */     }
/*     */     else
/*     */     {
/* 111 */       synchronized (w)
/*     */       {
/* 113 */         w.println(this);
/* 114 */         this.error.printStackTrace(w);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/RuntimeErrorException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */