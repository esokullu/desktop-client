/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OrQueryExp
/*    */   extends QueryEval
/*    */   implements QueryExp
/*    */ {
/*    */   private static final long serialVersionUID = 2962973084421716523L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private QueryExp exp1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private QueryExp exp2;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   OrQueryExp(QueryExp exp1, QueryExp exp2)
/*    */   {
/* 32 */     this.exp1 = exp1;
/* 33 */     this.exp2 = exp2;
/*    */   }
/*    */   
/*    */   public void setMBeanServer(MBeanServer server)
/*    */   {
/* 38 */     super.setMBeanServer(server);
/* 39 */     if (this.exp1 != null) this.exp1.setMBeanServer(server);
/* 40 */     if (this.exp2 != null) this.exp2.setMBeanServer(server);
/*    */   }
/*    */   
/*    */   public boolean apply(ObjectName name) throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException
/*    */   {
/* 45 */     return (this.exp1.apply(name)) || (this.exp2.apply(name));
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/OrQueryExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */