/*     */ package javax.management;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Query
/*     */ {
/*     */   public static final int GT = 0;
/*     */   
/*     */ 
/*     */   public static final int LT = 1;
/*     */   
/*     */ 
/*     */   public static final int GE = 2;
/*     */   
/*     */ 
/*     */   public static final int LE = 3;
/*     */   
/*     */ 
/*     */   public static final int EQ = 4;
/*     */   
/*     */ 
/*     */   public static final int PLUS = 0;
/*     */   
/*     */ 
/*     */   public static final int MINUS = 1;
/*     */   
/*     */   public static final int TIMES = 2;
/*     */   
/*     */   public static final int DIV = 3;
/*     */   
/*     */ 
/*     */   public static QueryExp not(QueryExp queryExp)
/*     */   {
/*  34 */     return new NotQueryExp(queryExp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static QueryExp and(QueryExp q1, QueryExp q2)
/*     */   {
/*  42 */     return new AndQueryExp(q1, q2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static QueryExp or(QueryExp q1, QueryExp q2)
/*     */   {
/*  50 */     return new OrQueryExp(q1, q2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static QueryExp gt(ValueExp v1, ValueExp v2)
/*     */   {
/*  58 */     return new BinaryRelQueryExp(0, v1, v2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static QueryExp geq(ValueExp v1, ValueExp v2)
/*     */   {
/*  66 */     return new BinaryRelQueryExp(2, v1, v2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static QueryExp leq(ValueExp v1, ValueExp v2)
/*     */   {
/*  74 */     return new BinaryRelQueryExp(3, v1, v2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static QueryExp lt(ValueExp v1, ValueExp v2)
/*     */   {
/*  82 */     return new BinaryRelQueryExp(1, v1, v2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static QueryExp eq(ValueExp v1, ValueExp v2)
/*     */   {
/*  90 */     return new BinaryRelQueryExp(4, v1, v2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static QueryExp between(ValueExp v1, ValueExp v2, ValueExp v3)
/*     */   {
/*  98 */     return new BetweenQueryExp(v1, v2, v3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static QueryExp in(ValueExp val, ValueExp[] valueList)
/*     */   {
/* 106 */     return new InQueryExp(val, valueList);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AttributeValueExp attr(String name)
/*     */   {
/* 114 */     return new AttributeValueExp(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AttributeValueExp attr(String className, String name)
/*     */   {
/* 122 */     return new QualifiedAttributeValueExp(className, name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AttributeValueExp classattr()
/*     */   {
/* 130 */     return new ClassAttributeValueExp();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static StringValueExp value(String val)
/*     */   {
/* 138 */     return new StringValueExp(val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ValueExp value(Number val)
/*     */   {
/* 146 */     return new NumericValueExp(val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ValueExp value(int val)
/*     */   {
/* 154 */     return value(new Integer(val));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ValueExp value(long val)
/*     */   {
/* 162 */     return value(new Long(val));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ValueExp value(float val)
/*     */   {
/* 170 */     return value(new Float(val));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ValueExp value(double val)
/*     */   {
/* 178 */     return value(new Double(val));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ValueExp value(boolean val)
/*     */   {
/* 186 */     return new BooleanValueExp(val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ValueExp plus(ValueExp value1, ValueExp value2)
/*     */   {
/* 194 */     return new BinaryOpValueExp(0, value1, value2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ValueExp minus(ValueExp value1, ValueExp value2)
/*     */   {
/* 202 */     return new BinaryOpValueExp(1, value1, value2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ValueExp times(ValueExp value1, ValueExp value2)
/*     */   {
/* 210 */     return new BinaryOpValueExp(2, value1, value2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ValueExp div(ValueExp value1, ValueExp value2)
/*     */   {
/* 218 */     return new BinaryOpValueExp(3, value1, value2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static QueryExp match(AttributeValueExp a, StringValueExp s)
/*     */   {
/* 226 */     return new MatchQueryExp(a, s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static QueryExp initialSubString(AttributeValueExp a, StringValueExp s)
/*     */   {
/* 234 */     return new MatchQueryExp(a, new StringValueExp(s.getValue() + "*"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static QueryExp anySubString(AttributeValueExp a, StringValueExp s)
/*     */   {
/* 242 */     return new MatchQueryExp(a, new StringValueExp("*" + s.getValue() + "*"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static QueryExp finalSubString(AttributeValueExp a, StringValueExp s)
/*     */   {
/* 250 */     return new MatchQueryExp(a, new StringValueExp("*" + s.getValue()));
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/Query.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */