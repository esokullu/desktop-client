/*    */ package javax.management;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanFeatureInfo
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 3952882688968447265L;
/*    */   protected String name;
/*    */   protected String description;
/*    */   
/*    */   public MBeanFeatureInfo(String name, String description)
/*    */   {
/* 39 */     this.name = name;
/* 40 */     this.description = description;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 48 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getDescription()
/*    */   {
/* 56 */     return this.description;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 61 */     int hash = 0;
/* 62 */     String n = getName();
/* 63 */     if (n != null) hash = 29 * hash + n.hashCode();
/* 64 */     String d = getDescription();
/* 65 */     if (d != null) hash = 29 * hash + d.hashCode();
/* 66 */     return hash;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 71 */     if (this == obj) return true;
/* 72 */     if (!(obj instanceof MBeanFeatureInfo)) { return false;
/*    */     }
/* 74 */     MBeanFeatureInfo other = (MBeanFeatureInfo)obj;
/* 75 */     String thisName = getName();
/* 76 */     String otherName = other.getName();
/* 77 */     if (thisName != null ? !thisName.equals(otherName) : otherName != null) return false;
/* 78 */     String thisDescr = getDescription();
/* 79 */     String otherDescr = other.getDescription();
/* 80 */     if (thisDescr != null ? !thisDescr.equals(otherDescr) : otherDescr != null) return false;
/* 81 */     return true;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanFeatureInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */