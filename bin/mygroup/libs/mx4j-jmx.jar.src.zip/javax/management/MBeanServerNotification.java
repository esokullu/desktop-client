/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanServerNotification
/*    */   extends Notification
/*    */ {
/*    */   private static final long serialVersionUID = 2876477500475969677L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final String REGISTRATION_NOTIFICATION = "JMX.mbean.registered";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final String UNREGISTRATION_NOTIFICATION = "JMX.mbean.unregistered";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private ObjectName objectName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MBeanServerNotification(String type, Object source, long sequenceNumber, ObjectName objectName)
/*    */   {
/* 45 */     super(type, source, sequenceNumber, "");
/* 46 */     if ((!type.equals("JMX.mbean.registered")) && (!type.equals("JMX.mbean.unregistered")))
/*    */     {
/* 48 */       throw new RuntimeOperationsException(new IllegalArgumentException("Bad notification type for MBeanServerNotification"));
/*    */     }
/* 50 */     this.objectName = objectName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ObjectName getMBeanName()
/*    */   {
/* 58 */     return this.objectName;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 63 */     StringBuffer b = new StringBuffer(super.toString());
/* 64 */     b.append("[");
/* 65 */     b.append(getMBeanName());
/* 66 */     b.append("]");
/* 67 */     return b.toString();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanServerNotification.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */