package javax.management.openmbean;

import java.util.Collection;
import java.util.Set;

public abstract interface TabularData
{
  public abstract Object[] calculateIndex(CompositeData paramCompositeData);
  
  public abstract void clear();
  
  public abstract boolean containsKey(Object[] paramArrayOfObject)
    throws InvalidOpenTypeException;
  
  public abstract boolean containsValue(CompositeData paramCompositeData);
  
  public abstract boolean equals(Object paramObject);
  
  public abstract CompositeData get(Object[] paramArrayOfObject)
    throws InvalidKeyException;
  
  public abstract TabularType getTabularType();
  
  public abstract int hashCode();
  
  public abstract boolean isEmpty();
  
  public abstract Set keySet();
  
  public abstract void put(CompositeData paramCompositeData)
    throws InvalidOpenTypeException, KeyAlreadyExistsException;
  
  public abstract void putAll(CompositeData[] paramArrayOfCompositeData)
    throws InvalidOpenTypeException, KeyAlreadyExistsException;
  
  public abstract CompositeData remove(Object[] paramArrayOfObject)
    throws InvalidKeyException;
  
  public abstract int size();
  
  public abstract String toString();
  
  public abstract Collection values();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/TabularData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */