package javax.management.openmbean;

import java.util.Collection;

public abstract interface CompositeData
{
  public abstract boolean containsKey(String paramString);
  
  public abstract boolean containsValue(Object paramObject);
  
  public abstract boolean equals(Object paramObject);
  
  public abstract Object get(String paramString)
    throws InvalidKeyException;
  
  public abstract Object[] getAll(String[] paramArrayOfString)
    throws InvalidKeyException;
  
  public abstract CompositeType getCompositeType();
  
  public abstract int hashCode();
  
  public abstract String toString();
  
  public abstract Collection values();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/CompositeData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */