/*     */ package javax.management.openmbean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayType
/*     */   extends OpenType
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 720504429830309770L;
/*  27 */   private int dimension = 0;
/*     */   
/*     */ 
/*     */ 
/*  31 */   private OpenType elementType = null;
/*     */   
/*     */ 
/*  34 */   private transient int hashCode = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArrayType(int dimension, OpenType elementType)
/*     */     throws OpenDataException
/*     */   {
/*  50 */     super(createArrayName(elementType, dimension), createArrayName(elementType, dimension), createDescription(elementType, dimension));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  55 */     if ((elementType instanceof ArrayType)) {
/*  56 */       throw new OpenDataException("elementType can't be instance of ArrayType");
/*     */     }
/*  58 */     if (dimension <= 0) { throw new IllegalArgumentException("int type dimension must be greater than or equal to 1");
/*     */     }
/*     */     
/*  61 */     this.dimension = dimension;
/*  62 */     this.elementType = elementType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDimension()
/*     */   {
/*  73 */     return this.dimension;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OpenType getElementOpenType()
/*     */   {
/*  85 */     return this.elementType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isValue(Object object)
/*     */   {
/*  96 */     boolean result = false;
/*     */     
/*  98 */     if ((object == null) || (!object.getClass().isArray()))
/*     */     {
/* 100 */       result = false;
/*     */     }
/* 102 */     else if ((this.elementType instanceof SimpleType))
/*     */     {
/* 104 */       result = getClassName().equals(object.getClass().getName());
/*     */     }
/* 106 */     else if ((this.elementType instanceof CompositeType))
/*     */     {
/*     */       try
/*     */       {
/* 110 */         Class elementClass = Thread.currentThread().getContextClassLoader().loadClass(getClassName());
/* 111 */         if (elementClass.isAssignableFrom(object.getClass()))
/*     */         {
/* 113 */           if (this.dimension == 1)
/*     */           {
/* 115 */             result = isValidCompositeDimension((CompositeData[])object);
/*     */           }
/*     */           else
/*     */           {
/* 119 */             result = true;
/* 120 */             for (int d = 0; (d < this.dimension) && (result == true); d++)
/*     */             {
/* 122 */               result = isValidCompositeDimension((CompositeData[])Array.get(object, d));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (ClassNotFoundException x)
/*     */       {
/* 129 */         result = false;
/*     */       }
/*     */       
/* 132 */     } else if ((this.elementType instanceof TabularType))
/*     */     {
/*     */       try
/*     */       {
/* 136 */         Class elementClass = Thread.currentThread().getContextClassLoader().loadClass(getClassName());
/* 137 */         if (elementClass.isAssignableFrom(object.getClass()))
/*     */         {
/* 139 */           if (this.dimension == 1)
/*     */           {
/* 141 */             result = isValidTabularDimension((TabularData[])object);
/*     */           }
/*     */           else
/*     */           {
/* 145 */             result = true;
/* 146 */             for (int d = 0; (d < this.dimension) && (result == true); d++)
/*     */             {
/* 148 */               result = isValidTabularDimension((TabularData[])Array.get(object, d));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (ClassNotFoundException x)
/*     */       {
/* 155 */         result = false;
/*     */       }
/*     */     }
/*     */     
/* 159 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 170 */     if (object == null)
/* 171 */       return false;
/* 172 */     if (object == this) { return true;
/*     */     }
/* 174 */     if (object != null)
/*     */     {
/*     */ 
/* 177 */       if ((object instanceof ArrayType))
/*     */       {
/* 179 */         ArrayType checkedType = (ArrayType)object;
/*     */         
/* 181 */         if (checkedType.dimension != this.dimension)
/* 182 */           return false;
/* 183 */         if (getElementOpenType().equals(checkedType.getElementOpenType()))
/* 184 */           return true;
/*     */       }
/*     */     }
/* 187 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 198 */     if (this.hashCode == 0)
/*     */     {
/* 200 */       computeHashCode();
/*     */     }
/* 202 */     return this.hashCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 213 */     StringBuffer sb = new StringBuffer();
/* 214 */     sb.append(this.elementType.getClassName());
/* 215 */     sb.append("(typename=");
/* 216 */     sb.append(getTypeName());
/* 217 */     sb.append(",dimension=");
/* 218 */     sb.append("" + this.dimension);
/* 219 */     sb.append(",elementType=");
/* 220 */     sb.append(this.elementType.toString());
/* 221 */     sb.append(")");
/*     */     
/* 223 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String createDescription(OpenType type, int size)
/*     */   {
/* 232 */     StringBuffer sb = new StringBuffer("" + size);
/* 233 */     sb.append("-dimension array of ");
/* 234 */     sb.append(type.getClassName());
/* 235 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   private static String createArrayName(OpenType type, int size)
/*     */   {
/* 241 */     if (size <= 0) throw new IllegalArgumentException("int type dimension must be greater than or equal to 1");
/* 242 */     StringBuffer sb = new StringBuffer();
/* 243 */     for (int i = 0; i < size; i++)
/* 244 */       sb.append("[");
/* 245 */     sb.append("L");
/* 246 */     sb.append(type.getClassName());
/* 247 */     sb.append(";");
/* 248 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private void computeHashCode()
/*     */   {
/* 253 */     this.hashCode = (this.dimension + this.elementType.hashCode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean arrayHasNull(Object[] obj)
/*     */   {
/* 268 */     for (int i = 0; i < obj.length; i++)
/*     */     {
/* 270 */       if (obj[i] == null)
/*     */       {
/* 272 */         return true;
/*     */       }
/*     */       
/* 275 */       if (obj[i].getClass().isArray())
/*     */       {
/* 277 */         if (arrayHasNull((Object[])obj[i]))
/*     */         {
/* 279 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 285 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean isValidCompositeDimension(CompositeData[] dimension)
/*     */   {
/* 292 */     boolean result = true;
/*     */     
/* 294 */     for (int i = 0; (i < dimension.length) && (result == true); i++)
/*     */     {
/* 296 */       if ((dimension[i] != null) && (!this.elementType.isValue(dimension[i]))) {
/* 297 */         result = false;
/*     */       }
/*     */     }
/* 300 */     return result;
/*     */   }
/*     */   
/*     */   private boolean isValidTabularDimension(TabularData[] dimension)
/*     */   {
/* 305 */     boolean result = true;
/*     */     
/* 307 */     for (int i = 0; (i < dimension.length) && (result == true); i++)
/*     */     {
/* 309 */       if ((dimension[i] != null) && (!this.elementType.isValue(dimension[i]))) {
/* 310 */         result = false;
/*     */       }
/*     */     }
/* 313 */     return result;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/ArrayType.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */