/*     */ package javax.management.openmbean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenMBeanParameterInfoSupport
/*     */   extends MBeanParameterInfo
/*     */   implements OpenMBeanParameterInfo, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -7235016873758443122L;
/*  24 */   private OpenType openType = null;
/*  25 */   private Object defaultValue = null;
/*  26 */   private Set legalValues = null;
/*  27 */   private Comparable minValue = null;
/*  28 */   private Comparable maxValue = null;
/*     */   
/*  30 */   private transient int m_hashcode = 0;
/*     */   
/*     */   public OpenMBeanParameterInfoSupport(String name, String description, OpenType openType)
/*     */   {
/*  34 */     super(name, openType == null ? "" : openType.getClassName(), description);
/*  35 */     if ((name == null) || (name.trim().length() == 0)) throw new IllegalArgumentException("name parameter cannot be null or an empty string.");
/*  36 */     if ((description == null) || (description.trim().length() == 0)) throw new IllegalArgumentException("description parameter cannot be null or an empty string.");
/*  37 */     if (openType == null) throw new IllegalArgumentException("OpenType parameter cannot be null.");
/*  38 */     this.openType = openType;
/*     */   }
/*     */   
/*     */   public OpenMBeanParameterInfoSupport(String name, String description, OpenType openType, Object defaultValue) throws OpenDataException
/*     */   {
/*  43 */     this(name, description, openType);
/*  44 */     if (defaultValue != null)
/*     */     {
/*  46 */       if ((openType.isArray()) || ((openType instanceof TabularType))) throw new OpenDataException("openType should not be an ArrayType or a TabularType when a default value is required.");
/*  47 */       if (!openType.isValue(defaultValue)) throw new OpenDataException("defaultValue class name " + defaultValue.getClass().getName() + " does not match the one defined in openType.");
/*  48 */       this.defaultValue = defaultValue;
/*     */     }
/*     */   }
/*     */   
/*     */   public OpenMBeanParameterInfoSupport(String name, String description, OpenType openType, Object defaultValue, Object[] legalValues) throws OpenDataException
/*     */   {
/*  54 */     this(name, description, openType, defaultValue);
/*  55 */     if ((legalValues != null) && (legalValues.length > 0))
/*     */     {
/*  57 */       if ((openType.isArray()) || ((openType instanceof TabularType))) throw new OpenDataException("legalValues not supported if openType is an ArrayType or an instanceof TabularType");
/*  58 */       for (int i = 0; i < legalValues.length; i++)
/*     */       {
/*  60 */         if (!openType.isValue(legalValues[i])) { throw new OpenDataException("The element at index " + i + " of type " + legalValues[i] + " is not an value specified in openType.");
/*     */         }
/*     */       }
/*  63 */       assignLegalValues(legalValues);
/*  64 */       if ((hasDefaultValue()) && (hasLegalValues()) && (!this.legalValues.contains(defaultValue))) throw new OpenDataException("LegalValues must contain the defaultValue");
/*     */     }
/*     */   }
/*     */   
/*     */   public OpenMBeanParameterInfoSupport(String name, String description, OpenType openType, Object defaultValue, Comparable minValue, Comparable maxValue) throws OpenDataException
/*     */   {
/*  70 */     this(name, description, openType, defaultValue);
/*  71 */     if (minValue != null)
/*     */     {
/*     */ 
/*  74 */       if (!openType.isValue(minValue)) throw new OpenDataException("Comparable value of " + minValue.getClass().getName() + " does not match the openType value of " + openType.getClassName());
/*  75 */       this.minValue = minValue;
/*     */     }
/*  77 */     if (maxValue != null)
/*     */     {
/*  79 */       if (!openType.isValue(maxValue)) throw new OpenDataException("Comparable value of " + maxValue.getClass().getName() + " does not match the openType value of " + openType.getClassName());
/*  80 */       this.maxValue = maxValue;
/*     */     }
/*  82 */     if ((hasMinValue()) && (hasMaxValue()) && (minValue.compareTo(maxValue) > 0)) throw new OpenDataException("minValue cannot be greater than maxValue.");
/*  83 */     if ((hasDefaultValue()) && (hasMinValue()) && (minValue.compareTo(defaultValue) > 0)) throw new OpenDataException("minValue cannot be greater than defaultValue.");
/*  84 */     if ((hasDefaultValue()) && (hasMaxValue()) && (((Comparable)defaultValue).compareTo(maxValue) > 0)) { throw new OpenDataException("defaultValue cannot be greater than maxValue.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void assignLegalValues(Object[] legalValues)
/*     */   {
/*  93 */     HashSet modifiableSet = new HashSet();
/*  94 */     for (int i = 0; i < legalValues.length; i++)
/*     */     {
/*  96 */       modifiableSet.add(legalValues[i]);
/*     */     }
/*  98 */     this.legalValues = Collections.unmodifiableSet(modifiableSet);
/*     */   }
/*     */   
/*     */   public OpenType getOpenType()
/*     */   {
/* 103 */     return this.openType;
/*     */   }
/*     */   
/*     */   public Object getDefaultValue()
/*     */   {
/* 108 */     return this.defaultValue;
/*     */   }
/*     */   
/*     */   public Set getLegalValues()
/*     */   {
/* 113 */     return this.legalValues;
/*     */   }
/*     */   
/*     */   public Comparable getMinValue()
/*     */   {
/* 118 */     return this.minValue;
/*     */   }
/*     */   
/*     */   public Comparable getMaxValue()
/*     */   {
/* 123 */     return this.maxValue;
/*     */   }
/*     */   
/*     */   public boolean hasDefaultValue()
/*     */   {
/* 128 */     return this.defaultValue != null;
/*     */   }
/*     */   
/*     */   public boolean hasLegalValues()
/*     */   {
/* 133 */     return this.legalValues != null;
/*     */   }
/*     */   
/*     */   public boolean hasMinValue()
/*     */   {
/* 138 */     return this.minValue != null;
/*     */   }
/*     */   
/*     */   public boolean hasMaxValue()
/*     */   {
/* 143 */     return this.maxValue != null;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isValue(Object obj)
/*     */   {
/* 149 */     if ((hasDefaultValue()) && (obj == null)) { return true;
/*     */     }
/* 151 */     if (!this.openType.isValue(obj)) return false;
/* 152 */     if ((hasLegalValues()) && (!this.legalValues.contains(obj))) return false;
/* 153 */     if ((hasMinValue()) && (this.minValue.compareTo(obj) > 0)) return false;
/* 154 */     if ((hasMaxValue()) && (this.maxValue.compareTo(obj) < 0)) return false;
/* 155 */     return true;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 160 */     if (obj == this) return true;
/* 161 */     if (obj == null) return false;
/* 162 */     if (!(obj instanceof OpenMBeanParameterInfo)) { return false;
/*     */     }
/* 164 */     OpenMBeanParameterInfo paramObj = (OpenMBeanParameterInfo)obj;
/*     */     
/* 166 */     if (!getName().equals(paramObj.getName())) return false;
/* 167 */     if (!getOpenType().equals(paramObj.getOpenType())) { return false;
/*     */     }
/* 169 */     if ((hasDefaultValue()) && (!getDefaultValue().equals(paramObj.getDefaultValue()))) return false;
/* 170 */     if ((!hasDefaultValue()) && (paramObj.hasDefaultValue())) { return false;
/*     */     }
/* 172 */     if ((hasMinValue()) && (!getMinValue().equals(paramObj.getMinValue()))) return false;
/* 173 */     if ((!hasMinValue()) && (paramObj.hasMinValue())) { return false;
/*     */     }
/* 175 */     if ((hasMaxValue()) && (!getMaxValue().equals(paramObj.getMaxValue()))) return false;
/* 176 */     if ((!hasMaxValue()) && (paramObj.hasMaxValue())) { return false;
/*     */     }
/* 178 */     if ((hasLegalValues()) && (!getLegalValues().equals(paramObj.getLegalValues()))) return false;
/* 179 */     if ((!hasLegalValues()) && (paramObj.hasLegalValues())) { return false;
/*     */     }
/* 181 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 186 */     if (this.m_hashcode == 0)
/*     */     {
/* 188 */       int result = getName().hashCode();
/* 189 */       result += getOpenType().hashCode();
/* 190 */       result += (!hasDefaultValue() ? 0 : getDefaultValue().hashCode());
/* 191 */       result += (!hasLegalValues() ? 0 : getLegalValues().hashCode());
/* 192 */       result += (!hasMinValue() ? 0 : getMinValue().hashCode());
/* 193 */       result += (!hasMaxValue() ? 0 : getMaxValue().hashCode());
/* 194 */       this.m_hashcode = result;
/*     */     }
/* 196 */     return this.m_hashcode;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 201 */     StringBuffer buf = new StringBuffer(getClass().getName());
/* 202 */     buf.append("\t(name = ");
/* 203 */     buf.append(getName());
/* 204 */     buf.append("\topenType = ");
/* 205 */     buf.append(this.openType.toString());
/* 206 */     buf.append("\tdefault value = ");
/* 207 */     buf.append(String.valueOf(this.defaultValue));
/* 208 */     buf.append("\tmin value = ");
/* 209 */     buf.append(String.valueOf(this.minValue));
/* 210 */     buf.append("\tmax value = ");
/* 211 */     buf.append(String.valueOf(this.maxValue));
/* 212 */     buf.append("\tlegal values = ");
/* 213 */     buf.append(String.valueOf(this.legalValues));
/* 214 */     buf.append(")");
/* 215 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/OpenMBeanParameterInfoSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */