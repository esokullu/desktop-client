/*     */ package javax.management.openmbean;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.io.StreamCorruptedException;
/*     */ import mx4j.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class OpenType
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -9195195325186646468L;
/*  25 */   public static final String[] ALLOWED_CLASSNAMES = { "java.lang.Void", "java.lang.Boolean", "java.lang.Byte", "java.lang.Character", "java.lang.Short", "java.lang.Integer", "java.lang.Long", "java.lang.Float", "java.lang.Double", "java.lang.String", "java.math.BigDecimal", "java.math.BigInteger", "java.util.Date", "javax.management.ObjectName", CompositeData.class.getName(), TabularData.class.getName() };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  45 */   private String className = null;
/*  46 */   private String typeName = null;
/*  47 */   private String description = null;
/*     */   
/*     */   protected OpenType(String className, String typeName, String description) throws OpenDataException
/*     */   {
/*  51 */     initialize(className, typeName, description);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void initialize(String className, String typeName, String description)
/*     */     throws OpenDataException
/*     */   {
/*  59 */     if (className == null) throw new IllegalArgumentException("null className is invalid");
/*  60 */     if (typeName == null) throw new IllegalArgumentException("null typeName is invalid");
/*  61 */     if (description == null) throw new IllegalArgumentException("null description is invalid");
/*  62 */     if (!validateClass(className)) throw new OpenDataException("Class does not represent one of the allowed className types");
/*  63 */     this.className = className;
/*  64 */     this.typeName = typeName;
/*  65 */     this.description = description;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean validateClass(String className)
/*     */   {
/*  76 */     if (className.startsWith("[")) { className = className.substring(className.indexOf("L") + 1, className.length() - 1);
/*     */     }
/*  78 */     for (int i = 0; i < ALLOWED_CLASSNAMES.length; i++)
/*     */     {
/*  80 */       if (className.equals(ALLOWED_CLASSNAMES[i])) return true;
/*     */     }
/*  82 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getClassName()
/*     */   {
/*  92 */     return this.className;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 102 */     return this.description;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTypeName()
/*     */   {
/* 112 */     return this.typeName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isArray()
/*     */   {
/* 122 */     Class c = null;
/*     */     try
/*     */     {
/* 125 */       c = Utils.loadClass(Thread.currentThread().getContextClassLoader(), this.className);
/*     */     }
/*     */     catch (ClassNotFoundException e)
/*     */     {
/* 129 */       return false;
/*     */     }
/* 131 */     return c.isArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream inputStream)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 139 */     inputStream.defaultReadObject();
/*     */     try
/*     */     {
/* 142 */       initialize(this.className, this.typeName, this.description);
/*     */     }
/*     */     catch (OpenDataException e)
/*     */     {
/* 146 */       throw new StreamCorruptedException("The object read from the ObjectInputStream during deserialization is not valid");
/*     */     }
/*     */   }
/*     */   
/*     */   public abstract boolean isValue(Object paramObject);
/*     */   
/*     */   public abstract boolean equals(Object paramObject);
/*     */   
/*     */   public abstract int hashCode();
/*     */   
/*     */   public abstract String toString();
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/OpenType.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */