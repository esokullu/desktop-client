/*     */ package javax.management.openmbean;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TabularDataSupport
/*     */   implements TabularData, Map, Cloneable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 5720150593236309827L;
/*     */   private Map dataMap;
/*     */   private TabularType tabularType;
/*     */   private transient String[] m_indexNames;
/*     */   
/*     */   public TabularDataSupport(TabularType tabularType)
/*     */   {
/*  49 */     this(tabularType, 101, 0.75F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TabularDataSupport(TabularType tabularType, int initialCapacity, float loadFactor)
/*     */   {
/*  62 */     if (tabularType == null) throw new IllegalArgumentException("TabularTypeBackUP instance cannot be null.");
/*  63 */     if (initialCapacity < 0) throw new IllegalArgumentException("The initialCapacity cannot be a negative number.");
/*  64 */     if (loadFactor < 0.0F) { throw new IllegalArgumentException("The load factor cannot be a negative number.");
/*     */     }
/*  66 */     this.tabularType = tabularType;
/*  67 */     this.dataMap = new HashMap(initialCapacity, loadFactor);
/*  68 */     initialize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initialize()
/*     */   {
/*  77 */     List tabularIndexList = this.tabularType.getIndexNames();
/*  78 */     this.m_indexNames = ((String[])tabularIndexList.toArray(new String[tabularIndexList.size()]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TabularType getTabularType()
/*     */   {
/*  88 */     return this.tabularType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object[] calculateIndex(CompositeData value)
/*     */   {
/* 104 */     if (value == null) throw new NullPointerException("CompositeData object cannot be null");
/* 105 */     if (!value.getCompositeType().equals(this.tabularType.getRowType())) throw new InvalidOpenTypeException("Invalid CompositeData object, its' tabularType is not equal to the row type of this TabularType instance");
/* 106 */     return Collections.unmodifiableList(Arrays.asList(value.getAll(this.m_indexNames))).toArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 118 */     if (!(key instanceof Object[])) return false;
/* 119 */     return containsKey((Object[])key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsKey(Object[] key)
/*     */   {
/* 131 */     if (key == null) return false;
/* 132 */     return this.dataMap.containsKey(Arrays.asList(key));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsValue(CompositeData value)
/*     */   {
/* 144 */     return this.dataMap.containsValue(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 155 */     return this.dataMap.containsValue(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object get(Object key)
/*     */   {
/* 166 */     return get((Object[])key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompositeData get(Object[] key)
/*     */   {
/* 180 */     validateKeys(key);
/* 181 */     return (CompositeData)this.dataMap.get(Arrays.asList(key));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object put(Object key, Object value)
/*     */   {
/* 192 */     put((CompositeData)value);
/* 193 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void put(CompositeData value)
/*     */   {
/* 212 */     List list = Collections.unmodifiableList(Arrays.asList(calculateIndex(value)));
/* 213 */     if (this.dataMap.containsKey(list)) throw new KeyAlreadyExistsException("The list of index names already exists in this instance");
/* 214 */     this.dataMap.put(list, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object remove(Object key)
/*     */   {
/* 225 */     return remove((Object[])key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompositeData remove(Object[] key)
/*     */   {
/* 238 */     validateKeys(key);
/* 239 */     return (CompositeData)this.dataMap.remove(Arrays.asList(key));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putAll(Map t)
/*     */   {
/* 257 */     if ((t == null) || (t.size() == 0)) { return;
/*     */     }
/*     */     try
/*     */     {
/* 261 */       compositeData = (CompositeData[])t.values().toArray(new CompositeData[t.size()]);
/*     */     }
/*     */     catch (ArrayStoreException e) {
/*     */       CompositeData[] compositeData;
/* 265 */       throw new ClassCastException("The values contained in t must all be of type CompositeData"); }
/*     */     CompositeData[] compositeData;
/* 267 */     putAll(compositeData);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putAll(CompositeData[] values)
/*     */   {
/* 284 */     if ((values == null) || (values.length == 0)) { return;
/*     */     }
/*     */     
/* 287 */     List storeList = validateNoDuplicates(values);
/*     */     
/*     */ 
/* 290 */     for (int i = 0; i < values.length; i++)
/*     */     {
/* 292 */       this.dataMap.put(storeList.get(i), values[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private List validateNoDuplicates(CompositeData[] values)
/*     */   {
/* 301 */     List storeList = new ArrayList();
/* 302 */     for (int i = 0; i < values.length; i++)
/*     */     {
/* 304 */       List list = Collections.unmodifiableList(Arrays.asList(calculateIndex(values[i])));
/*     */       
/*     */ 
/* 307 */       if (storeList.contains(list)) { throw new KeyAlreadyExistsException("value at [" + i + "] has the same index values as: " + storeList.indexOf(list));
/*     */       }
/*     */       
/* 310 */       storeList.add(list);
/*     */     }
/* 312 */     return storeList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 320 */     this.dataMap.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 328 */     return this.dataMap.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 336 */     return this.dataMap.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set keySet()
/*     */   {
/* 350 */     return this.dataMap.keySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection values()
/*     */   {
/* 363 */     return this.dataMap.values();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set entrySet()
/*     */   {
/* 378 */     return this.dataMap.entrySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 389 */     TabularDataSupport dataSupportClone = null;
/*     */     try
/*     */     {
/* 392 */       dataSupportClone = (TabularDataSupport)super.clone();
/* 393 */       dataSupportClone.dataMap = ((HashMap)((HashMap)this.dataMap).clone());
/*     */ 
/*     */     }
/*     */     catch (CloneNotSupportedException e)
/*     */     {
/* 398 */       return null;
/*     */     }
/* 400 */     return dataSupportClone;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 415 */     if (!(obj instanceof TabularData)) return false;
/* 416 */     TabularData tabularData = (TabularData)obj;
/* 417 */     for (Iterator i = values().iterator(); i.hasNext();)
/*     */     {
/* 419 */       CompositeData compositeData = (CompositeData)i.next();
/* 420 */       if (!tabularData.containsValue(compositeData)) return false;
/*     */     }
/* 422 */     return (getTabularType().equals(tabularData.getTabularType())) && (size() == tabularData.size());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 433 */     int result = this.tabularType.hashCode();
/* 434 */     for (Iterator i = values().iterator(); i.hasNext();)
/*     */     {
/* 436 */       result += i.next().hashCode();
/*     */     }
/* 438 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 450 */     return getClass().getName() + "(tabularType = " + this.tabularType.toString() + ",contains = " + this.dataMap.toString() + ")";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void validateKeys(Object[] key)
/*     */   {
/* 458 */     if ((key == null) || (key.length == 0)) throw new NullPointerException("Object[] key cannot be null or of zero length");
/* 459 */     if (key.length != this.m_indexNames.length) throw new InvalidKeyException("Length of Object[] passed in as a parameter is not equal to the number of items: " + this.m_indexNames.length + " as specified for the indexing rows in this instance.");
/* 460 */     for (int i = 0; i < key.length; i++)
/*     */     {
/* 462 */       OpenType openType = this.tabularType.getRowType().getType(this.m_indexNames[i]);
/* 463 */       if ((key[i] != null) && (!openType.isValue(key[i]))) { throw new InvalidKeyException("expected value is: " + openType + " at index: " + i + " but got: " + key[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void readObject(ObjectInputStream inputStream)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 472 */     inputStream.defaultReadObject();
/* 473 */     initialize();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/TabularDataSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */