/*     */ package javax.management.openmbean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenMBeanAttributeInfoSupport
/*     */   extends MBeanAttributeInfo
/*     */   implements OpenMBeanAttributeInfo, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -4867215622149721849L;
/*     */   private OpenType openType;
/*  25 */   private Object defaultValue = null;
/*  26 */   private Set legalValues = null;
/*  27 */   private Comparable minValue = null;
/*  28 */   private Comparable maxValue = null;
/*     */   
/*  30 */   private transient int hashCode = 0;
/*  31 */   private transient String toStringName = null;
/*     */   
/*     */   public OpenMBeanAttributeInfoSupport(String name, String description, OpenType openType, boolean isReadable, boolean isWritable, boolean isIs)
/*     */   {
/*  35 */     super(name, openType == null ? "" : openType.getClassName(), description, isReadable, isWritable, isIs);
/*  36 */     if (openType == null)
/*  37 */       throw new IllegalArgumentException("OpenType can't be null");
/*  38 */     if ((name == null) || (name.length() == 0) || (name.trim().length() == 0))
/*  39 */       throw new IllegalArgumentException("name can't be null or empty");
/*  40 */     if ((description == null) || (description.length() == 0) || (description.trim().length() == 0)) {
/*  41 */       throw new IllegalArgumentException("description can't be null or empty");
/*     */     }
/*  43 */     this.openType = openType;
/*     */   }
/*     */   
/*     */   public OpenMBeanAttributeInfoSupport(String name, String description, OpenType openType, boolean isReadable, boolean isWritable, boolean isIs, Object defaultValue) throws OpenDataException
/*     */   {
/*  48 */     this(name, description, openType, isReadable, isWritable, isIs);
/*     */     
/*  50 */     if (((openType instanceof ArrayType)) || ((openType instanceof TabularType)))
/*     */     {
/*  52 */       if (defaultValue != null) {
/*  53 */         throw new OpenDataException("defaultValue is not supported for ArrayType and TabularType. Should be null");
/*     */       }
/*     */     }
/*  56 */     if ((defaultValue != null) && (!openType.isValue(defaultValue))) {
/*  57 */       throw new OpenDataException("defaultValue is not a valid value for the given OpenType");
/*     */     }
/*     */   }
/*     */   
/*     */   public OpenMBeanAttributeInfoSupport(String name, String description, OpenType openType, boolean isReadable, boolean isWritable, boolean isIs, Object defaultValue, Object[] legalValues)
/*     */     throws OpenDataException
/*     */   {
/*  64 */     this(name, description, openType, isReadable, isWritable, isIs, defaultValue);
/*     */     
/*  66 */     if (((openType instanceof ArrayType)) || ((openType instanceof TabularType)))
/*     */     {
/*  68 */       if ((legalValues != null) && (legalValues.length > 0)) {
/*  69 */         throw new OpenDataException("legalValues isn't allowed for ArrayType and TabularType. Should be null or empty array");
/*     */       }
/*  71 */     } else if ((legalValues != null) && (legalValues.length > 0))
/*     */     {
/*  73 */       Set tmpSet = new HashSet(legalValues.length);
/*     */       
/*  75 */       for (int i = 0; i < legalValues.length; i++)
/*     */       {
/*  77 */         Object lv = legalValues[i];
/*  78 */         if (openType.isValue(lv))
/*     */         {
/*  80 */           tmpSet.add(lv);
/*     */         }
/*     */         else
/*     */         {
/*  84 */           throw new OpenDataException("An Entry in the set of legalValues is not a valid value for the given opentype");
/*     */         }
/*     */       }
/*     */       
/*  88 */       if ((defaultValue != null) && (!tmpSet.contains(defaultValue)))
/*     */       {
/*  90 */         throw new OpenDataException("The legal value set must include the default value");
/*     */       }
/*     */       
/*  93 */       this.legalValues = Collections.unmodifiableSet(tmpSet);
/*     */     }
/*     */   }
/*     */   
/*     */   public OpenMBeanAttributeInfoSupport(String name, String description, OpenType openType, boolean isReadable, boolean isWritable, boolean isIs, Object defaultValue, Comparable minValue, Comparable maxValue) throws OpenDataException
/*     */   {
/*  99 */     this(name, description, openType, isReadable, isWritable, isIs, defaultValue);
/*     */     
/* 101 */     if ((minValue != null) && 
/* 102 */       (!openType.isValue(minValue))) {
/* 103 */       throw new OpenDataException("minValue is not a valid value for the specified openType");
/*     */     }
/* 105 */     if ((maxValue != null) && 
/* 106 */       (!openType.isValue(maxValue))) {
/* 107 */       throw new OpenDataException("maxValue is not a valid value for the specified openType");
/*     */     }
/* 109 */     if ((minValue != null) && (maxValue != null) && 
/* 110 */       (minValue.compareTo(maxValue) > 0)) {
/* 111 */       throw new OpenDataException("minValue and/or maxValue is invalid: minValue is greater than maxValue");
/*     */     }
/* 113 */     if ((defaultValue != null) && (minValue != null) && 
/* 114 */       (minValue.compareTo(defaultValue) > 0)) {
/* 115 */       throw new OpenDataException("defaultvalue and/or minValue is invalid: minValue is greater than defaultValue");
/*     */     }
/* 117 */     if ((defaultValue != null) && (maxValue != null) && 
/* 118 */       (((Comparable)defaultValue).compareTo(maxValue) > 0)) {
/* 119 */       throw new OpenDataException("defaultvalue and/or maxValue is invalid: defaultValue is greater than maxValue");
/*     */     }
/* 121 */     this.minValue = minValue;
/* 122 */     this.maxValue = maxValue;
/*     */   }
/*     */   
/*     */   public OpenType getOpenType()
/*     */   {
/* 127 */     return this.openType;
/*     */   }
/*     */   
/*     */   public Object getDefaultValue()
/*     */   {
/* 132 */     return this.defaultValue;
/*     */   }
/*     */   
/*     */   public Set getLegalValues()
/*     */   {
/* 137 */     return this.legalValues;
/*     */   }
/*     */   
/*     */   public Comparable getMinValue()
/*     */   {
/* 142 */     return this.minValue;
/*     */   }
/*     */   
/*     */   public Comparable getMaxValue()
/*     */   {
/* 147 */     return this.maxValue;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hasDefaultValue()
/*     */   {
/* 153 */     return this.defaultValue != null;
/*     */   }
/*     */   
/*     */   public boolean hasLegalValues()
/*     */   {
/* 158 */     return this.legalValues != null;
/*     */   }
/*     */   
/*     */   public boolean hasMinValue()
/*     */   {
/* 163 */     return this.minValue != null;
/*     */   }
/*     */   
/*     */   public boolean hasMaxValue()
/*     */   {
/* 168 */     return this.maxValue != null;
/*     */   }
/*     */   
/*     */   public boolean isValue(Object obj)
/*     */   {
/* 173 */     if (this.defaultValue != null)
/*     */     {
/* 175 */       if (this.openType.isValue(obj)) { return true;
/*     */       }
/*     */       
/*     */     }
/* 179 */     else if (obj == null) { return true;
/*     */     }
/*     */     
/* 182 */     return false;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 187 */     if (obj == this) { return true;
/*     */     }
/* 189 */     if (obj == null) { return false;
/*     */     }
/* 191 */     if (!(obj instanceof OpenMBeanAttributeInfo)) { return false;
/*     */     }
/* 193 */     OpenMBeanAttributeInfo other = (OpenMBeanAttributeInfo)obj;
/* 194 */     if (!getName().equals(other.getName())) return false;
/* 195 */     if (!getOpenType().equals(other.getOpenType())) return false;
/* 196 */     if (isReadable() != other.isReadable()) return false;
/* 197 */     if (isWritable() != other.isWritable()) return false;
/* 198 */     if (isIs() != other.isIs()) { return false;
/*     */     }
/* 200 */     if (hasDefaultValue())
/*     */     {
/* 202 */       if (!getDefaultValue().equals(other.getDefaultValue())) { return false;
/*     */       }
/*     */       
/*     */     }
/* 206 */     else if (other.hasDefaultValue()) { return false;
/*     */     }
/*     */     
/* 209 */     if (hasMinValue())
/*     */     {
/* 211 */       if (!getMinValue().equals(other.getMinValue())) { return false;
/*     */       }
/*     */       
/*     */     }
/* 215 */     else if (other.hasMinValue()) { return false;
/*     */     }
/*     */     
/* 218 */     if (hasMaxValue())
/*     */     {
/* 220 */       if (!getMaxValue().equals(other.getMaxValue())) { return false;
/*     */       }
/*     */       
/*     */     }
/* 224 */     else if (other.hasMaxValue()) { return false;
/*     */     }
/*     */     
/* 227 */     if (hasLegalValues())
/*     */     {
/* 229 */       if (!getLegalValues().equals(other.getLegalValues())) { return false;
/*     */       }
/*     */       
/*     */     }
/* 233 */     else if (other.hasLegalValues()) { return false;
/*     */     }
/*     */     
/* 236 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 241 */     if (this.hashCode == 0)
/*     */     {
/* 243 */       int result = getName().hashCode();
/* 244 */       result += getOpenType().hashCode();
/* 245 */       result += (!hasDefaultValue() ? 0 : getDefaultValue().hashCode());
/* 246 */       result += (!hasLegalValues() ? 0 : getLegalValues().hashCode());
/* 247 */       result += (!hasMinValue() ? 0 : getMinValue().hashCode());
/* 248 */       result += (!hasMaxValue() ? 0 : getMaxValue().hashCode());
/* 249 */       this.hashCode = result;
/*     */     }
/* 251 */     return this.hashCode;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 256 */     if (this.toStringName == null)
/*     */     {
/* 258 */       StringBuffer sb = new StringBuffer(getClass().getName());
/* 259 */       sb.append("(name=");
/* 260 */       sb.append(getName());
/* 261 */       sb.append(", opentype=");
/* 262 */       sb.append(this.openType.toString());
/* 263 */       sb.append(", defaultValue=");
/* 264 */       sb.append(hasDefaultValue() ? getDefaultValue().toString() : "null");
/* 265 */       sb.append(", minValue=");
/* 266 */       sb.append(hasMinValue() ? getMinValue().toString() : "null");
/* 267 */       sb.append(", maxValue=");
/* 268 */       sb.append(hasMaxValue() ? getMaxValue().toString() : "null");
/* 269 */       sb.append(", legalValues=");
/* 270 */       sb.append(hasLegalValues() ? getLegalValues().toString() : "null");
/* 271 */       sb.append(")");
/* 272 */       this.toStringName = sb.toString();
/*     */     }
/* 274 */     return this.toStringName;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/OpenMBeanAttributeInfoSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */