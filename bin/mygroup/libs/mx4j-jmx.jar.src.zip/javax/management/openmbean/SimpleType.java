/*     */ package javax.management.openmbean;
/*     */ 
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Date;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SimpleType
/*     */   extends OpenType
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2215577471957694503L;
/*     */   public static final SimpleType BIGDECIMAL;
/*     */   public static final SimpleType BIGINTEGER;
/*     */   public static final SimpleType BOOLEAN;
/*     */   public static final SimpleType BYTE;
/*     */   public static final SimpleType CHARACTER;
/*     */   public static final SimpleType DOUBLE;
/*     */   public static final SimpleType FLOAT;
/*     */   public static final SimpleType INTEGER;
/*     */   public static final SimpleType LONG;
/*     */   public static final SimpleType OBJECTNAME;
/*     */   public static final SimpleType SHORT;
/*     */   public static final SimpleType STRING;
/*     */   public static final SimpleType DATE;
/*     */   public static final SimpleType VOID;
/*     */   
/*     */   static
/*     */   {
/*  54 */     SimpleType temp = null;
/*     */     try
/*     */     {
/*  57 */       temp = new SimpleType("java.math.BigDecimal");
/*     */     }
/*     */     catch (OpenDataException ignored) {}
/*     */     
/*     */ 
/*  62 */     BIGDECIMAL = temp;
/*  63 */     temp = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  68 */       temp = new SimpleType("java.math.BigInteger");
/*     */     }
/*     */     catch (OpenDataException ignored) {}
/*     */     
/*     */ 
/*  73 */     BIGINTEGER = temp;
/*  74 */     temp = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  79 */       temp = new SimpleType("java.lang.Boolean");
/*     */     }
/*     */     catch (OpenDataException ignored) {}
/*     */     
/*     */ 
/*  84 */     BOOLEAN = temp;
/*  85 */     temp = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  90 */       temp = new SimpleType("java.lang.Byte");
/*     */     }
/*     */     catch (OpenDataException ignored) {}
/*     */     
/*     */ 
/*  95 */     BYTE = temp;
/*  96 */     temp = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 101 */       temp = new SimpleType("java.lang.Character");
/*     */     }
/*     */     catch (OpenDataException ignored) {}
/*     */     
/*     */ 
/* 106 */     CHARACTER = temp;
/* 107 */     temp = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 112 */       temp = new SimpleType("java.lang.Double");
/*     */     }
/*     */     catch (OpenDataException ignored) {}
/*     */     
/*     */ 
/* 117 */     DOUBLE = temp;
/* 118 */     temp = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 123 */       temp = new SimpleType("java.lang.Float");
/*     */     }
/*     */     catch (OpenDataException ignored) {}
/*     */     
/*     */ 
/* 128 */     FLOAT = temp;
/* 129 */     temp = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 134 */       temp = new SimpleType("java.lang.Integer");
/*     */     }
/*     */     catch (OpenDataException ignored) {}
/*     */     
/*     */ 
/* 139 */     INTEGER = temp;
/* 140 */     temp = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 145 */       temp = new SimpleType("java.lang.Long");
/*     */     }
/*     */     catch (OpenDataException ignored) {}
/*     */     
/*     */ 
/* 150 */     LONG = temp;
/* 151 */     temp = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 156 */       temp = new SimpleType("javax.management.ObjectName");
/*     */     }
/*     */     catch (OpenDataException ignored) {}
/*     */     
/*     */ 
/* 161 */     OBJECTNAME = temp;
/* 162 */     temp = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 167 */       temp = new SimpleType("java.lang.Short");
/*     */     }
/*     */     catch (OpenDataException ignored) {}
/*     */     
/*     */ 
/* 172 */     SHORT = temp;
/* 173 */     temp = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 178 */       temp = new SimpleType("java.lang.String");
/*     */     }
/*     */     catch (OpenDataException ignored) {}
/*     */     
/*     */ 
/* 183 */     STRING = temp;
/* 184 */     temp = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 189 */       temp = new SimpleType("java.util.Date");
/*     */     }
/*     */     catch (OpenDataException ignored) {}
/*     */     
/*     */ 
/* 194 */     DATE = temp;
/* 195 */     temp = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 200 */       temp = new SimpleType("java.lang.Void");
/*     */     }
/*     */     catch (OpenDataException ignored) {}
/*     */     
/*     */ 
/* 205 */     VOID = temp;
/* 206 */     temp = null;
/*     */   }
/*     */   
/* 209 */   private transient int m_hashCode = 0;
/*     */   
/*     */   private SimpleType(String className) throws OpenDataException
/*     */   {
/* 213 */     super(className, className, className);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isValue(Object object)
/*     */   {
/* 226 */     if (object == null) return false;
/* 227 */     return getClassName().equals(object.getClass().getName());
/*     */   }
/*     */   
/*     */   public Object readResolve()
/*     */     throws ObjectStreamException
/*     */   {
/* 233 */     if (getClassName().equals(String.class.getName()))
/* 234 */       return STRING;
/* 235 */     if (getClassName().equals(BigDecimal.class.getName()))
/* 236 */       return BIGDECIMAL;
/* 237 */     if (getClassName().equals(BigInteger.class.getName()))
/* 238 */       return BIGINTEGER;
/* 239 */     if (getClassName().equals(Boolean.class.getName()))
/* 240 */       return BOOLEAN;
/* 241 */     if (getClassName().equals(Byte.class.getName()))
/* 242 */       return BYTE;
/* 243 */     if (getClassName().equals(Character.class.getName()))
/* 244 */       return CHARACTER;
/* 245 */     if (getClassName().equals(Double.class.getName()))
/* 246 */       return DOUBLE;
/* 247 */     if (getClassName().equals(Float.class.getName()))
/* 248 */       return FLOAT;
/* 249 */     if (getClassName().equals(Integer.class.getName()))
/* 250 */       return INTEGER;
/* 251 */     if (getClassName().equals(Long.class.getName()))
/* 252 */       return LONG;
/* 253 */     if (getClassName().equals(ObjectName.class.getName()))
/* 254 */       return OBJECTNAME;
/* 255 */     if (getClassName().equals(Short.class.getName()))
/* 256 */       return SHORT;
/* 257 */     if (getClassName().equals(Void.class.getName()))
/* 258 */       return VOID;
/* 259 */     if (getClassName().equals(Date.class.getName())) {
/* 260 */       return DATE;
/*     */     }
/* 262 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 272 */     if (!(object instanceof SimpleType)) return false;
/* 273 */     SimpleType otherType = (SimpleType)object;
/* 274 */     return getClassName().equals(otherType.getClassName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 284 */     if (this.m_hashCode == 0)
/*     */     {
/* 286 */       int result = getClassName().hashCode();
/* 287 */       this.m_hashCode = result;
/*     */     }
/* 289 */     return this.m_hashCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 299 */     return getClass().getName() + "(name = " + getTypeName() + ")";
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/SimpleType.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */