/*    */ package javax.management.openmbean;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidOpenTypeException
/*    */   extends IllegalArgumentException
/*    */   implements Serializable
/*    */ {
/*    */   public InvalidOpenTypeException() {}
/*    */   
/*    */   public InvalidOpenTypeException(String s)
/*    */   {
/* 23 */     super(s);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/InvalidOpenTypeException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */