/*    */ package javax.management.openmbean;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidKeyException
/*    */   extends IllegalArgumentException
/*    */   implements Serializable
/*    */ {
/*    */   public InvalidKeyException() {}
/*    */   
/*    */   public InvalidKeyException(String s)
/*    */   {
/* 23 */     super(s);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/InvalidKeyException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */