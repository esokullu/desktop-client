/*     */ package javax.management.openmbean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanConstructorInfo;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenMBeanInfoSupport
/*     */   extends MBeanInfo
/*     */   implements OpenMBeanInfo, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 4349395935420511492L;
/*  27 */   private transient int hashCode = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OpenMBeanInfoSupport(String className, String description, OpenMBeanAttributeInfo[] openAttributes, OpenMBeanConstructorInfo[] openConstructors, OpenMBeanOperationInfo[] openOperations, MBeanNotificationInfo[] notifications)
/*     */   {
/*  36 */     super(className, description, createMBeanAttributes(openAttributes), createMBeanConstructors(openConstructors), createMBeanOperations(openOperations), notifications);
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  41 */     if (obj == null) return false;
/*  42 */     if (obj == this) return true;
/*  43 */     if (!(obj instanceof OpenMBeanInfo)) { return false;
/*     */     }
/*  45 */     OpenMBeanInfo other = (OpenMBeanInfo)obj;
/*  46 */     String thisClassName = getClassName();
/*  47 */     String otherClassName = other.getClassName();
/*  48 */     if (thisClassName != null ? !thisClassName.equals(otherClassName) : otherClassName != null) { return false;
/*     */     }
/*  50 */     if (!Arrays.equals(getConstructors(), other.getConstructors())) return false;
/*  51 */     if (!Arrays.equals(getAttributes(), other.getAttributes())) return false;
/*  52 */     if (!Arrays.equals(getOperations(), other.getOperations())) return false;
/*  53 */     if (!Arrays.equals(getNotifications(), other.getNotifications())) { return false;
/*     */     }
/*  55 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  60 */     if (this.hashCode == 0)
/*     */     {
/*  62 */       int hash = getClassName() == null ? 0 : getClassName().hashCode();
/*  63 */       if (getConstructors() != null) hash += Arrays.asList(getConstructors()).hashCode();
/*  64 */       if (getAttributes() != null) hash += Arrays.asList(getAttributes()).hashCode();
/*  65 */       if (getOperations() != null) hash += Arrays.asList(getOperations()).hashCode();
/*  66 */       if (getNotifications() != null) hash += Arrays.asList(getNotifications()).hashCode();
/*  67 */       this.hashCode = hash;
/*     */     }
/*  69 */     return this.hashCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static MBeanAttributeInfo[] createMBeanAttributes(OpenMBeanAttributeInfo[] attributes)
/*     */     throws ArrayStoreException
/*     */   {
/*  77 */     if (attributes == null) return null;
/*  78 */     MBeanAttributeInfo[] attrInfo = new MBeanAttributeInfo[attributes.length];
/*  79 */     System.arraycopy(attributes, 0, attrInfo, 0, attrInfo.length);
/*  80 */     return attrInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static MBeanConstructorInfo[] createMBeanConstructors(OpenMBeanConstructorInfo[] constructors)
/*     */     throws ArrayStoreException
/*     */   {
/*  88 */     if (constructors == null) return null;
/*  89 */     MBeanConstructorInfo[] constInfo = new MBeanConstructorInfo[constructors.length];
/*  90 */     System.arraycopy(constructors, 0, constInfo, 0, constInfo.length);
/*  91 */     return constInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static MBeanOperationInfo[] createMBeanOperations(OpenMBeanOperationInfo[] operations)
/*     */     throws ArrayStoreException
/*     */   {
/*  99 */     if (operations == null) return null;
/* 100 */     MBeanOperationInfo[] operInfo = new MBeanOperationInfo[operations.length];
/* 101 */     System.arraycopy(operations, 0, operInfo, 0, operInfo.length);
/* 102 */     return operInfo;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/OpenMBeanInfoSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */