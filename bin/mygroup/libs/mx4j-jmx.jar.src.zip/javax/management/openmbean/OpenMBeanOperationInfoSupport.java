/*     */ package javax.management.openmbean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenMBeanOperationInfoSupport
/*     */   extends MBeanOperationInfo
/*     */   implements OpenMBeanOperationInfo, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 4996859732565369366L;
/*     */   private OpenType returnOpenType;
/*  25 */   private transient int hashCode = 0;
/*  26 */   private transient String toStringName = null;
/*     */   
/*     */   public OpenMBeanOperationInfoSupport(String name, String description, OpenMBeanParameterInfo[] signature, OpenType returntype, int impact)
/*     */   {
/*  30 */     super(name, description, signature == null ? (MBeanParameterInfo[])Arrays.asList(new OpenMBeanParameterInfo[0]).toArray(new MBeanParameterInfo[0]) : (MBeanParameterInfo[])Arrays.asList(signature).toArray(new MBeanParameterInfo[0]), returntype == null ? "" : returntype.getClassName(), impact);
/*     */     
/*     */ 
/*  33 */     if ((name == null) || (name.length() == 0)) { throw new IllegalArgumentException("name cannot be null or empty");
/*     */     }
/*  35 */     if ((description == null) || (description.length() == 0)) { throw new IllegalArgumentException("descripiton cannot be null or empty");
/*     */     }
/*  37 */     if (returntype == null) { throw new IllegalArgumentException("return open type cannont be null");
/*     */     }
/*  39 */     if ((impact != 1) && (impact != 2) && (impact != 0) && (impact != 3))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  44 */       throw new IllegalArgumentException("invalid impact");
/*     */     }
/*     */     
/*  47 */     if ((signature != null) && (signature.getClass().isInstance(new MBeanParameterInfo[0].getClass())))
/*     */     {
/*  49 */       throw new ArrayStoreException("signature elements can't be assigned to MBeanParameterInfo");
/*     */     }
/*     */     
/*  52 */     this.returnOpenType = returntype;
/*     */   }
/*     */   
/*     */   public OpenType getReturnOpenType()
/*     */   {
/*  57 */     return this.returnOpenType;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  62 */     if (obj == null) return false;
/*  63 */     if (obj == this) return true;
/*  64 */     if (!(obj instanceof OpenMBeanOperationInfo)) { return false;
/*     */     }
/*  66 */     OpenMBeanOperationInfo other = (OpenMBeanOperationInfo)obj;
/*     */     
/*  68 */     String thisName = getName();
/*  69 */     String otherName = other.getName();
/*  70 */     if (thisName != null ? !thisName.equals(otherName) : otherName != null) { return false;
/*     */     }
/*  72 */     if (other.getImpact() != getImpact()) { return false;
/*     */     }
/*  74 */     OpenType thisReturn = getReturnOpenType();
/*  75 */     OpenType otherReturn = other.getReturnOpenType();
/*  76 */     if (thisReturn != null ? !thisReturn.equals(otherReturn) : otherReturn != null) { return false;
/*     */     }
/*  78 */     if (!Arrays.equals(getSignature(), other.getSignature())) { return false;
/*     */     }
/*  80 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  85 */     if (this.hashCode == 0)
/*     */     {
/*  87 */       int result = getName().hashCode();
/*  88 */       result += getReturnOpenType().hashCode();
/*  89 */       result += getImpact();
/*  90 */       result += Arrays.asList(getSignature()).hashCode();
/*  91 */       this.hashCode = result;
/*     */     }
/*  93 */     return this.hashCode;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  98 */     if (this.toStringName == null)
/*     */     {
/* 100 */       StringBuffer sb = new StringBuffer();
/* 101 */       sb.append(getClass().getName());
/* 102 */       sb.append("(name=");
/* 103 */       sb.append(getName());
/* 104 */       sb.append(",signature=");
/* 105 */       sb.append(Arrays.asList(getSignature()).toString());
/* 106 */       sb.append(",returnOpenType=");
/* 107 */       sb.append(this.returnOpenType.toString());
/* 108 */       sb.append(",impact=");
/* 109 */       sb.append(getImpact());
/* 110 */       sb.append(")");
/*     */       
/* 112 */       this.toStringName = sb.toString();
/*     */     }
/* 114 */     return this.toStringName;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/OpenMBeanOperationInfoSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */