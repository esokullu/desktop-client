/*     */ package javax.management.openmbean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TabularType
/*     */   extends OpenType
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 6554071860220659261L;
/*  22 */   private CompositeType rowType = null;
/*  23 */   private List indexNames = null;
/*     */   
/*  25 */   private transient int m_hashcode = 0;
/*  26 */   private transient String m_classDescription = null;
/*     */   
/*     */   public TabularType(String typeName, String description, CompositeType rowType, String[] indexNames) throws OpenDataException
/*     */   {
/*  30 */     super(TabularData.class.getName(), typeName, description);
/*  31 */     if (typeName.trim().length() == 0) throw new IllegalArgumentException("TabularType name can't be empty");
/*  32 */     if (description.trim().length() == 0) throw new IllegalArgumentException("TabularType description can't be empty");
/*  33 */     validate(rowType, indexNames);
/*  34 */     this.rowType = rowType;
/*  35 */     ArrayList temp = new ArrayList();
/*  36 */     for (int i = 0; i < indexNames.length; i++) temp.add(indexNames[i]);
/*  37 */     this.indexNames = Collections.unmodifiableList(temp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void validate(CompositeType rowType, String[] indexNames)
/*     */     throws OpenDataException
/*     */   {
/*  47 */     if (rowType == null) throw new IllegalArgumentException("The CompositeType passed in cannot be null");
/*  48 */     if ((indexNames == null) || (indexNames.length == 0)) { throw new IllegalArgumentException("The String[] indexNames cannot be null or empty");
/*     */     }
/*  50 */     for (int i = 0; i < indexNames.length; i++)
/*     */     {
/*  52 */       String item = indexNames[i];
/*  53 */       if ((item == null) || (item.length() == 0))
/*     */       {
/*  55 */         throw new IllegalArgumentException("An Item in the indexNames[] cannot be null or of zero length");
/*     */       }
/*  57 */       if (!rowType.containsKey(item))
/*     */       {
/*  59 */         throw new OpenDataException("Element value: " + indexNames[i] + " at index: " + i + " is not a valid item name for RowType");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public CompositeType getRowType()
/*     */   {
/*  66 */     return this.rowType;
/*     */   }
/*     */   
/*     */   public List getIndexNames()
/*     */   {
/*  71 */     return this.indexNames;
/*     */   }
/*     */   
/*     */   public boolean isValue(Object object)
/*     */   {
/*  76 */     if (!(object instanceof TabularData)) return false;
/*  77 */     TabularData tabularData = (TabularData)object;
/*  78 */     return equals(tabularData.getTabularType());
/*     */   }
/*     */   
/*     */   public boolean equals(Object object)
/*     */   {
/*  83 */     if (object == this) return true;
/*  84 */     if (!(object instanceof TabularType)) return false;
/*  85 */     TabularType tabularType = (TabularType)object;
/*  86 */     return (getRowType().equals(tabularType.getRowType())) && (getIndexNames().equals(tabularType.getIndexNames())) && (getTypeName().equals(tabularType.getTypeName()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  93 */     if (this.m_hashcode == 0)
/*     */     {
/*  95 */       int result = getTypeName().hashCode();
/*  96 */       result += getRowType().hashCode();
/*  97 */       List names = getIndexNames();
/*  98 */       for (int i = 0; i < names.size(); i++)
/*     */       {
/* 100 */         Object name = names.get(i);
/* 101 */         result += name.hashCode();
/*     */       }
/* 103 */       this.m_hashcode = result;
/*     */     }
/* 105 */     return this.m_hashcode;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 110 */     if (this.m_classDescription == null)
/*     */     {
/* 112 */       StringBuffer classString = new StringBuffer("TabularType name: ").append(getTypeName());
/* 113 */       classString.append(" rowType: ").append(getRowType());
/* 114 */       classString.append("indexNames: ").append(getIndexNames());
/* 115 */       this.m_classDescription = classString.toString();
/*     */     }
/* 117 */     return this.m_classDescription;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/TabularType.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */