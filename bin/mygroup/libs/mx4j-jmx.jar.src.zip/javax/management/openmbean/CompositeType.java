/*     */ package javax.management.openmbean;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.io.StreamCorruptedException;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeType
/*     */   extends OpenType
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -5366242454346948798L;
/*     */   private TreeMap nameToDescription;
/*     */   private TreeMap nameToType;
/*  30 */   private transient String m_classStringValue = null;
/*  31 */   private transient int m_hashcode = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompositeType(String typeName, String description, String[] itemNames, String[] itemDescriptions, OpenType[] itemTypes)
/*     */     throws OpenDataException
/*     */   {
/*  60 */     super(CompositeData.class.getName(), typeName, description);
/*  61 */     validate(typeName, description, itemNames, itemDescriptions, itemTypes);
/*  62 */     initialize(itemNames, itemDescriptions, itemTypes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void initialize(String[] itemNames, String[] itemDescriptions, OpenType[] itemTypes)
/*     */     throws OpenDataException
/*     */   {
/*  70 */     this.m_hashcode = computeHashCode(getTypeName(), itemNames, itemTypes);
/*  71 */     this.nameToDescription = new TreeMap();
/*  72 */     this.nameToType = new TreeMap();
/*  73 */     for (int i = 0; i < itemNames.length; i++)
/*     */     {
/*  75 */       String item = itemNames[i].trim();
/*  76 */       if (this.nameToDescription.containsKey(item)) throw new OpenDataException("The key: " + item + " is already mapped to a previous entry");
/*  77 */       this.nameToDescription.put(item, itemDescriptions[i]);
/*  78 */       this.nameToType.put(item, itemTypes[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void validate(String typeName, String description, String[] itemNames, String[] itemDescriptions, OpenType[] itemTypes)
/*     */     throws OpenDataException
/*     */   {
/*  88 */     if ((typeName == null) || (typeName.length() == 0)) throw new IllegalArgumentException("typeName can't be null or empty");
/*  89 */     if ((description == null) || (description.length() == 0)) throw new IllegalArgumentException("description can't be null or empty");
/*  90 */     if ((itemNames == null) || (itemNames.length == 0)) throw new IllegalArgumentException("The String[] of itemNames cannot be null or empty");
/*  91 */     if ((itemDescriptions == null) || (itemDescriptions.length == 0)) throw new IllegalArgumentException("The String[] of itemDescriptions cannot be null or empty");
/*  92 */     if ((itemTypes == null) || (itemTypes.length == 0)) throw new IllegalArgumentException("The OpenType[] of itemTypes cannot be null or empty");
/*  93 */     if ((itemDescriptions.length != itemNames.length) || (itemTypes.length != itemNames.length)) throw new OpenDataException("itemNames, itemDescriptions and itemTypes must all be the same length");
/*  94 */     for (int i = 0; i < itemNames.length; i++)
/*     */     {
/*  96 */       String value = itemNames[i];
/*  97 */       String d = itemDescriptions[i];
/*  98 */       if (value == null) throw new IllegalArgumentException("The itemName at index: " + i + " cannot be a null value");
/*  99 */       if (d == null) throw new IllegalArgumentException("The itemDescription at index: " + i + " cannot be a null value");
/* 100 */       if (value.trim().equals("")) throw new IllegalArgumentException("The itemName at index: " + i + " cannot be an empty string");
/* 101 */       if (d.trim().equals("")) throw new IllegalArgumentException("The itemDescription at index: " + i + " cannot be an empty string");
/* 102 */       if (itemTypes[i] == null) { throw new IllegalArgumentException("The OpenType at index: " + i + " cannot be a null value");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsKey(String itemName)
/*     */   {
/* 114 */     if ((itemName == null) || (itemName.length() == 0)) { return false;
/*     */     }
/* 116 */     return this.nameToDescription.containsKey(itemName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescription(String itemName)
/*     */   {
/* 127 */     if ((itemName == null) || (itemName.length() == 0)) return null;
/* 128 */     return (String)this.nameToDescription.get(itemName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OpenType getType(String itemName)
/*     */   {
/* 139 */     if ((itemName == null) || (itemName.length() == 0)) return null;
/* 140 */     return (OpenType)this.nameToType.get(itemName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set keySet()
/*     */   {
/* 150 */     return Collections.unmodifiableSet(this.nameToDescription.keySet());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isValue(Object object)
/*     */   {
/* 161 */     if (!(object instanceof CompositeData)) return false;
/* 162 */     CompositeData compositeData = (CompositeData)object;
/* 163 */     return equals(compositeData.getCompositeType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 175 */     if (object == this) { return true;
/*     */     }
/*     */     
/* 178 */     if (!(object instanceof CompositeType)) return false;
/* 179 */     CompositeType type = (CompositeType)object;
/* 180 */     if (!getTypeName().equals(type.getTypeName())) return false;
/* 181 */     return this.nameToType.equals(type.nameToType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 189 */     return this.m_hashcode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 197 */     if (this.m_classStringValue == null)
/*     */     {
/* 199 */       StringBuffer value = new StringBuffer(100);
/* 200 */       value.append(getClassName()).append(" TypeName: ").append(getTypeName()).append(" contains data:\n");
/* 201 */       for (Iterator i = this.nameToType.entrySet().iterator(); i.hasNext();)
/*     */       {
/* 203 */         Map.Entry entry = (Map.Entry)i.next();
/* 204 */         value.append("ItemName: ").append((String)entry.getKey()).append(" OpenType value: ").append(((OpenType)entry.getValue()).toString()).append("\n");
/*     */       }
/* 206 */       this.m_classStringValue = value.toString();
/*     */     }
/* 208 */     return this.m_classStringValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream inputStream)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 216 */     inputStream.defaultReadObject();
/* 217 */     String[] itemNames = (String[])this.nameToDescription.keySet().toArray(new String[this.nameToDescription.size()]);
/* 218 */     String[] itemDescriptions = (String[])this.nameToDescription.values().toArray(new String[this.nameToDescription.size()]);
/* 219 */     OpenType[] itemTypes = (OpenType[])this.nameToType.values().toArray(new OpenType[this.nameToType.size()]);
/*     */     try
/*     */     {
/* 222 */       validate(getTypeName(), getDescription(), itemNames, itemDescriptions, itemTypes);
/* 223 */       initialize(itemNames, itemDescriptions, itemTypes);
/*     */     }
/*     */     catch (OpenDataException e)
/*     */     {
/* 227 */       throw new StreamCorruptedException("validation failed for deserialized object, unable to create object in the correct state");
/*     */     }
/*     */   }
/*     */   
/*     */   private int computeHashCode(String name, String[] itemnames, OpenType[] itemtypes)
/*     */   {
/* 233 */     int result = name.hashCode();
/* 234 */     for (int i = 0; i < itemnames.length; i++)
/*     */     {
/* 236 */       result += itemnames[i].hashCode();
/* 237 */       result += itemtypes[i].hashCode();
/*     */     }
/* 239 */     return result;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/CompositeType.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */