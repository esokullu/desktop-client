/*     */ package javax.management.openmbean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeDataSupport
/*     */   implements CompositeData, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 8003518976613702244L;
/*  25 */   private SortedMap contents = new TreeMap();
/*     */   
/*     */   private CompositeType compositeType;
/*  28 */   private transient int m_hashcode = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompositeDataSupport(CompositeType compositeType, String[] itemNames, Object[] itemValues)
/*     */     throws OpenDataException
/*     */   {
/*  50 */     init(compositeType, itemNames, itemValues);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompositeDataSupport(CompositeType compositeType, Map items)
/*     */     throws OpenDataException
/*     */   {
/*  67 */     init(compositeType, items != null ? (String[])items.keySet().toArray(new String[items.size()]) : null, items != null ? items.values().toArray() : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void init(CompositeType compositeType, String[] itemNames, Object[] itemValues)
/*     */     throws OpenDataException
/*     */   {
/*  75 */     if (compositeType == null) throw new IllegalArgumentException("Null CompositeType is not an acceptable value");
/*  76 */     if ((itemNames == null) || (itemNames.length == 0)) throw new IllegalArgumentException("ItemNames cannot be null or empty (zero length)");
/*  77 */     if ((itemValues == null) || (itemValues.length == 0)) throw new IllegalArgumentException("ItemValues cannot be null or empty (zero length)");
/*  78 */     if (itemNames.length != itemValues.length) { throw new IllegalArgumentException("Both the itemNames and itemValues arrays must be of equals length");
/*     */     }
/*     */     
/*  81 */     validateTypes(compositeType, itemNames);
/*     */     
/*     */ 
/*  84 */     validateContents(compositeType, itemNames, itemValues);
/*     */     
/*     */ 
/*  87 */     this.compositeType = compositeType;
/*     */     
/*     */ 
/*  90 */     createMapData(itemNames, itemValues);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void validateContents(CompositeType compositeType, String[] itemNames, Object[] itemValues)
/*     */     throws OpenDataException
/*     */   {
/*  98 */     for (int i = 0; i < itemValues.length; i++)
/*     */     {
/* 100 */       if (itemValues[i] != null)
/*     */       {
/* 102 */         OpenType openType = compositeType.getType(itemNames[i]);
/* 103 */         if (!openType.isValue(itemValues[i])) {
/* 104 */           throw new OpenDataException("itemValue at index " + i + " is not a valid value for itemName " + itemNames[i] + " and itemType " + openType);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void validateTypes(CompositeType compositeType, String[] itemNames)
/*     */     throws OpenDataException
/*     */   {
/* 119 */     for (int i = 0; i < itemNames.length; i++)
/*     */     {
/* 121 */       if ((itemNames[i] == null) || (itemNames[i].trim().equals(""))) throw new IllegalArgumentException("Value of itemName at [" + i + "] is null or empty, unacceptable values");
/*     */     }
/* 123 */     Set keyTypes = compositeType.keySet();
/* 124 */     if (itemNames.length != keyTypes.size()) throw new OpenDataException("The size of array arguments itemNames[] and itemValues[] should be equal to the number of items defined in argument compositeType");
/* 125 */     if (!Arrays.asList(itemNames).containsAll(keyTypes)) { throw new OpenDataException("itemNames[] does not contain all names defined in the compositeType of this instance.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void createMapData(String[] itemNames, Object[] itemValues)
/*     */   {
/* 133 */     for (int i = 0; i < itemNames.length; i++)
/*     */     {
/* 135 */       this.contents.put(itemNames[i], itemValues[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompositeType getCompositeType()
/*     */   {
/* 144 */     return this.compositeType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object get(String key)
/*     */   {
/* 155 */     if ((key == null) || (key.trim().equals(""))) throw new IllegalArgumentException("Null or empty key");
/* 156 */     if (!this.contents.containsKey(key.trim())) throw new InvalidKeyException("Key with value " + key + " is not a current stored key in this instance");
/* 157 */     return this.contents.get(key.trim());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object[] getAll(String[] keys)
/*     */   {
/* 171 */     if ((keys == null) || (keys.length == 0)) return new Object[0];
/* 172 */     Object[] dataMapValues = new Object[keys.length];
/* 173 */     for (int i = 0; i < keys.length; i++)
/*     */     {
/* 175 */       dataMapValues[i] = get(keys[i]);
/*     */     }
/* 177 */     return dataMapValues;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsKey(String key)
/*     */   {
/* 188 */     if ((key == null) || (key.trim().equals(""))) return false;
/* 189 */     return this.contents.containsKey(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 200 */     return this.contents.containsValue(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection values()
/*     */   {
/* 211 */     return Collections.unmodifiableCollection(this.contents.values());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 227 */     if (!(obj instanceof CompositeData))
/* 228 */       return false;
/* 229 */     CompositeData compositeData = (CompositeData)obj;
/* 230 */     boolean result = getCompositeType().equals(compositeData.getCompositeType());
/*     */     
/* 232 */     if (result)
/*     */     {
/* 234 */       Iterator i = this.contents.entrySet().iterator();
/* 235 */       while ((i.hasNext()) && (result))
/*     */       {
/* 237 */         Map.Entry entry = (Map.Entry)i.next();
/* 238 */         String key = (String)entry.getKey();
/* 239 */         Object entryvalue = entry.getValue();
/* 240 */         Object cdvalue = compositeData.get(key);
/* 241 */         if (entryvalue == null)
/*     */         {
/* 243 */           result = cdvalue == null;
/*     */         }
/*     */         else
/*     */         {
/* 247 */           result = entryvalue.equals(cdvalue);
/*     */         }
/*     */       }
/*     */     }
/* 251 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 262 */     if (this.m_hashcode == 0)
/*     */     {
/* 264 */       int result = getCompositeType().hashCode();
/* 265 */       for (Iterator i = this.contents.entrySet().iterator(); i.hasNext();)
/*     */       {
/* 267 */         Map.Entry entry = (Map.Entry)i.next();
/* 268 */         if (entry.getValue() != null) result += entry.getValue().hashCode();
/*     */       }
/* 270 */       this.m_hashcode = result;
/*     */     }
/* 272 */     return this.m_hashcode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 283 */     StringBuffer buffer = new StringBuffer(getClass().getName());
/* 284 */     buffer.append("\tCompositeType = ");
/* 285 */     buffer.append(this.compositeType.toString());
/* 286 */     buffer.append("\tcontents are: ");
/* 287 */     buffer.append(this.contents.toString());
/* 288 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/CompositeDataSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */