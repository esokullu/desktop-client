/*    */ package javax.management.openmbean;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.management.JMException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenDataException
/*    */   extends JMException
/*    */   implements Serializable
/*    */ {
/*    */   public OpenDataException() {}
/*    */   
/*    */   public OpenDataException(String message)
/*    */   {
/* 24 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/OpenDataException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */