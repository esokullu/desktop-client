package javax.management.openmbean;

public abstract interface OpenMBeanAttributeInfo
  extends OpenMBeanParameterInfo
{
  public abstract boolean isReadable();
  
  public abstract boolean isWritable();
  
  public abstract boolean isIs();
  
  public abstract boolean equals(Object paramObject);
  
  public abstract int hashCode();
  
  public abstract String toString();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/OpenMBeanAttributeInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */