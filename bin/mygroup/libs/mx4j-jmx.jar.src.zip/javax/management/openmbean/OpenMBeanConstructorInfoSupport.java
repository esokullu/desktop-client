/*    */ package javax.management.openmbean;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import javax.management.MBeanConstructorInfo;
/*    */ import javax.management.MBeanParameterInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenMBeanConstructorInfoSupport
/*    */   extends MBeanConstructorInfo
/*    */   implements OpenMBeanConstructorInfo, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -4400441579007477003L;
/* 24 */   private transient int m_hashcode = 0;
/*    */   
/*    */   public OpenMBeanConstructorInfoSupport(String name, String description, OpenMBeanParameterInfo[] signature)
/*    */   {
/* 28 */     super(name, description, signature == null ? null : (MBeanParameterInfo[])Arrays.asList(signature).toArray(new MBeanParameterInfo[0]));
/* 29 */     if ((name == null) || (name.trim().length() == 0)) throw new IllegalArgumentException("name parameter cannot be null or an empty string");
/* 30 */     if ((description == null) || (description.trim().length() == 0)) throw new IllegalArgumentException("description parameter cannot be null or an empty string");
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 35 */     if (!(obj instanceof OpenMBeanConstructorInfo)) return false;
/* 36 */     OpenMBeanConstructorInfo toCompare = (OpenMBeanConstructorInfo)obj;
/* 37 */     return (getName().equals(toCompare.getName())) && (Arrays.equals(getSignature(), toCompare.getSignature()));
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 42 */     if (this.m_hashcode == 0)
/*    */     {
/* 44 */       int result = getName().hashCode();
/* 45 */       result += Arrays.asList(getSignature()).hashCode();
/* 46 */       this.m_hashcode = result;
/*    */     }
/* 48 */     return this.m_hashcode;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 53 */     return getClass().getName() + " ( name = " + getName() + " signature = " + Arrays.asList(getSignature()).toString() + " )";
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/openmbean/OpenMBeanConstructorInfoSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */