package javax.management;

import java.io.Serializable;

public abstract interface ValueExp
  extends Serializable
{
  public abstract ValueExp apply(ObjectName paramObjectName)
    throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException;
  
  public abstract void setMBeanServer(MBeanServer paramMBeanServer);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/ValueExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */