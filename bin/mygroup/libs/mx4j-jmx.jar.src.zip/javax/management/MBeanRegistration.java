package javax.management;

public abstract interface MBeanRegistration
{
  public abstract ObjectName preRegister(MBeanServer paramMBeanServer, ObjectName paramObjectName)
    throws Exception;
  
  public abstract void postRegister(Boolean paramBoolean);
  
  public abstract void preDeregister()
    throws Exception;
  
  public abstract void postDeregister();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanRegistration.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */