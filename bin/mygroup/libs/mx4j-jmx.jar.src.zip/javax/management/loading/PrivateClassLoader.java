package javax.management.loading;

public abstract interface PrivateClassLoader {}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/loading/PrivateClassLoader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */