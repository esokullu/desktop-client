/*    */ package javax.management.loading;
/*    */ 
/*    */ import java.net.URL;
/*    */ import java.net.URLStreamHandlerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrivateMLet
/*    */   extends MLet
/*    */   implements PrivateClassLoader
/*    */ {
/*    */   public PrivateMLet(URL[] urls, boolean delegateToCLR)
/*    */   {
/* 32 */     super(urls, delegateToCLR);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PrivateMLet(URL[] urls, ClassLoader parent, boolean delegateToCLR)
/*    */   {
/* 45 */     super(urls, parent, delegateToCLR);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PrivateMLet(URL[] urls, ClassLoader parent, URLStreamHandlerFactory factory, boolean delegateToCLR)
/*    */   {
/* 59 */     super(urls, parent, factory, delegateToCLR);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/loading/PrivateMLet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */