/*    */ package javax.management.loading;
/*    */ 
/*    */ import java.net.URL;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MLetContent
/*    */ {
/*    */   private Map attributes;
/*    */   private URL mletFileURL;
/*    */   private URL codebaseURL;
/*    */   
/*    */   public MLetContent(URL mletFileURL, Map attributes)
/*    */   {
/* 31 */     this.mletFileURL = mletFileURL;
/* 32 */     this.attributes = attributes;
/*    */     
/* 34 */     this.codebaseURL = ((URL)attributes.remove("codebaseURL"));
/*    */   }
/*    */   
/*    */   public Map getAttributes()
/*    */   {
/* 39 */     return this.attributes;
/*    */   }
/*    */   
/*    */   public URL getDocumentBase()
/*    */   {
/* 44 */     return this.mletFileURL;
/*    */   }
/*    */   
/*    */   public URL getCodeBase()
/*    */   {
/* 49 */     return this.codebaseURL;
/*    */   }
/*    */   
/*    */   public String getJarFiles()
/*    */   {
/* 54 */     return (String)getParameter("archive");
/*    */   }
/*    */   
/*    */   public String getCode()
/*    */   {
/* 59 */     return (String)getParameter("code");
/*    */   }
/*    */   
/*    */   public String getSerializedObject()
/*    */   {
/* 64 */     return (String)getParameter("object");
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 69 */     return (String)getParameter("name");
/*    */   }
/*    */   
/*    */   public String getVersion()
/*    */   {
/* 74 */     return (String)getParameter("version");
/*    */   }
/*    */   
/*    */   public Object getParameter(String s)
/*    */   {
/* 79 */     return this.attributes.get(s.toLowerCase());
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/loading/MLetContent.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */