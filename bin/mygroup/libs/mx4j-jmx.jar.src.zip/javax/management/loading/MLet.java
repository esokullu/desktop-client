/*     */ package javax.management.loading;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.Externalizable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutput;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.net.URLStreamHandlerFactory;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.management.MBeanRegistration;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ServiceNotFoundException;
/*     */ import mx4j.loading.ClassLoaderObjectInputStream;
/*     */ import mx4j.loading.MLetParseException;
/*     */ import mx4j.loading.MLetParser;
/*     */ import mx4j.loading.MLetTag;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MLet
/*     */   extends URLClassLoader
/*     */   implements MLetMBean, MBeanRegistration, Externalizable
/*     */ {
/*     */   private MBeanServer server;
/*     */   private ObjectName objectName;
/*     */   private boolean delegateToCLR;
/*  56 */   private ThreadLocal loadingOnlyLocally = new ThreadLocal();
/*  57 */   private ThreadLocal loadingWithRepository = new ThreadLocal();
/*     */   private String libraryDir;
/*     */   
/*     */   public MLet()
/*     */   {
/*  62 */     this(new URL[0]);
/*     */   }
/*     */   
/*     */   public MLet(URL[] urls)
/*     */   {
/*  67 */     this(urls, true);
/*     */   }
/*     */   
/*     */   public MLet(URL[] urls, boolean delegateToCLR)
/*     */   {
/*  72 */     super(urls);
/*  73 */     setDelegateToCLR(delegateToCLR);
/*  74 */     this.loadingWithRepository.set(Boolean.FALSE);
/*  75 */     this.loadingOnlyLocally.set(Boolean.FALSE);
/*     */   }
/*     */   
/*     */   public MLet(URL[] urls, ClassLoader parent)
/*     */   {
/*  80 */     this(urls, parent, true);
/*     */   }
/*     */   
/*     */   public MLet(URL[] urls, ClassLoader parent, boolean delegateToCLR)
/*     */   {
/*  85 */     super(urls, parent);
/*  86 */     setDelegateToCLR(delegateToCLR);
/*  87 */     this.loadingWithRepository.set(Boolean.FALSE);
/*  88 */     this.loadingOnlyLocally.set(Boolean.FALSE);
/*     */   }
/*     */   
/*     */   public MLet(URL[] urls, ClassLoader parent, URLStreamHandlerFactory factory)
/*     */   {
/*  93 */     this(urls, parent, factory, true);
/*     */   }
/*     */   
/*     */   public MLet(URL[] urls, ClassLoader parent, URLStreamHandlerFactory factory, boolean delegateToCLR)
/*     */   {
/*  98 */     super(urls, parent, factory);
/*  99 */     setDelegateToCLR(delegateToCLR);
/* 100 */     this.loadingWithRepository.set(Boolean.FALSE);
/* 101 */     this.loadingOnlyLocally.set(Boolean.FALSE);
/*     */   }
/*     */   
/*     */   public ObjectName preRegister(MBeanServer server, ObjectName name) throws Exception
/*     */   {
/* 106 */     this.server = server;
/* 107 */     this.objectName = (name == null ? new ObjectName(this.server.getDefaultDomain(), "service", "MLet") : name);
/* 108 */     Logger logger = getLogger();
/* 109 */     if (logger.isEnabledFor(0)) logger.trace("MLet service " + this.objectName + " preRegistered successfully");
/* 110 */     return this.objectName;
/*     */   }
/*     */   
/*     */   public void postRegister(Boolean registrationDone)
/*     */   {
/* 115 */     Logger logger = getLogger();
/* 116 */     if (!registrationDone.booleanValue())
/*     */     {
/* 118 */       this.server = null;
/* 119 */       if (logger.isEnabledFor(20)) { logger.info("MLet service " + this.objectName + " was not registered");
/*     */       }
/*     */       
/*     */     }
/* 123 */     else if (logger.isEnabledFor(0)) { logger.trace("MLet service " + this.objectName + " postRegistered successfully");
/*     */     }
/*     */   }
/*     */   
/*     */   public void preDeregister() throws Exception
/*     */   {
/* 129 */     Logger logger = getLogger();
/* 130 */     if (logger.isEnabledFor(0)) logger.trace("MLet service " + this.objectName + " preDeregistered successfully");
/*     */   }
/*     */   
/*     */   public void postDeregister()
/*     */   {
/* 135 */     Logger logger = getLogger();
/* 136 */     if (logger.isEnabledFor(0)) logger.trace("MLet service " + this.objectName + " postDeregistered successfully");
/*     */   }
/*     */   
/*     */   public void addURL(String url) throws ServiceNotFoundException
/*     */   {
/* 141 */     addURL(createURL(url));
/*     */   }
/*     */   
/*     */   public void addURL(URL url)
/*     */   {
/* 146 */     Logger logger = getLogger();
/* 147 */     if (!Arrays.asList(getURLs()).contains(url))
/*     */     {
/* 149 */       if (logger.isEnabledFor(0)) logger.trace("Adding URL to this MLet (" + this.objectName + ") classpath: " + url);
/* 150 */       super.addURL(url);
/*     */ 
/*     */ 
/*     */     }
/* 154 */     else if (logger.isEnabledFor(0)) { logger.trace("URL already present in this MLet (" + this.objectName + ") classpath: " + url);
/*     */     }
/*     */   }
/*     */   
/*     */   public Class loadClass(String name, ClassLoaderRepository repository) throws ClassNotFoundException
/*     */   {
/* 160 */     if (repository == null)
/*     */     {
/* 162 */       Class cls = loadClassLocally(name);
/* 163 */       return cls;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 169 */       return loadClassLocally(name);
/*     */ 
/*     */     }
/*     */     catch (ClassNotFoundException x)
/*     */     {
/*     */ 
/* 175 */       return loadClassFromRepository(name, repository);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Class loadClassLocally(String name)
/*     */     throws ClassNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 198 */       this.loadingOnlyLocally.set(Boolean.TRUE);
/* 199 */       return loadClass(name);
/*     */     }
/*     */     finally
/*     */     {
/* 203 */       this.loadingOnlyLocally.set(Boolean.FALSE);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Class loadClassFromRepository(String name, ClassLoaderRepository repository)
/*     */     throws ClassNotFoundException
/*     */   {
/* 213 */     return repository.loadClassBefore(this, name);
/*     */   }
/*     */   
/*     */   protected Class findClass(String name) throws ClassNotFoundException
/*     */   {
/* 218 */     Logger logger = getLogger();
/* 219 */     boolean trace = logger.isEnabledFor(0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 225 */     if (this.loadingWithRepository.get() == Boolean.TRUE)
/*     */     {
/* 227 */       if (trace) logger.trace("MLet " + this + " is recursively calling itself to load class " + name + ": skipping further searches");
/* 228 */       throw new ClassNotFoundException(name);
/*     */     }
/*     */     
/* 231 */     if (trace) { logger.trace("Finding class " + name + "...");
/*     */     }
/*     */     try
/*     */     {
/* 235 */       Class cls = findClassLocally(name);
/* 236 */       if (trace) logger.trace("Class " + name + " found in this MLet's classpath " + this);
/* 237 */       return cls;
/*     */     }
/*     */     catch (ClassNotFoundException x)
/*     */     {
/* 241 */       if (!isDelegateToCLR())
/*     */       {
/* 243 */         if (trace) logger.trace("MLet " + this + " does not delegate to the ClassLoaderRepository");
/* 244 */         throw x;
/*     */       }
/*     */       
/* 247 */       if (this.loadingOnlyLocally.get() == Boolean.TRUE) { throw x;
/*     */       }
/* 249 */       if (this.server == null) { throw x;
/*     */       }
/* 251 */       if (trace) logger.trace("Class " + name + " not found in this MLet's classpath " + this + ", trying the ClassLoaderRepository...", x);
/*     */       try
/*     */       {
/* 254 */         this.loadingWithRepository.set(Boolean.TRUE);
/* 255 */         ClassLoaderRepository repository = this.server.getClassLoaderRepository();
/* 256 */         Class cls = loadClassFromRepository(name, repository);
/* 257 */         if (trace) logger.trace("Class " + name + " found with ClassLoaderRepository " + repository);
/* 258 */         return cls;
/*     */       }
/*     */       catch (ClassNotFoundException xx)
/*     */       {
/* 262 */         if (trace) logger.trace("Class " + name + " not found in ClassLoaderRepository, giving up", xx);
/* 263 */         throw new ClassNotFoundException(name);
/*     */       }
/*     */       finally
/*     */       {
/* 267 */         this.loadingWithRepository.set(Boolean.FALSE);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Class findClassLocally(String name) throws ClassNotFoundException
/*     */   {
/* 274 */     return super.findClass(name);
/*     */   }
/*     */   
/*     */   public Set getMBeansFromURL(String url) throws ServiceNotFoundException
/*     */   {
/* 279 */     return getMBeansFromURL(createURL(url));
/*     */   }
/*     */   
/*     */   public Set getMBeansFromURL(URL url) throws ServiceNotFoundException
/*     */   {
/* 284 */     if (url == null) { throw new ServiceNotFoundException("Cannot load MBeans from null URL");
/*     */     }
/* 286 */     Logger logger = getLogger();
/* 287 */     if (logger.isEnabledFor(0)) { logger.trace("MLet " + this + ", reading MLET file from " + url);
/*     */     }
/* 289 */     InputStream is = null;
/* 290 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 291 */     BufferedOutputStream os = new BufferedOutputStream(baos);
/*     */     try
/*     */     {
/* 294 */       is = url.openStream();
/* 295 */       readFromAndWriteTo(is, os);
/*     */     }
/*     */     catch (IOException x)
/*     */     {
/* 299 */       if (logger.isEnabledFor(0)) logger.trace("Cannot read input stream from URL " + url, x);
/* 300 */       throw new ServiceNotFoundException(x.toString());
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 306 */         if (is != null) is.close();
/* 307 */         os.close();
/*     */       }
/*     */       catch (IOException ignored) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 314 */     String mletFileContent = null;
/*     */     try
/*     */     {
/* 317 */       mletFileContent = new String(baos.toByteArray(), "UTF-8");
/*     */     }
/*     */     catch (UnsupportedEncodingException x)
/*     */     {
/* 321 */       mletFileContent = baos.toString();
/*     */     }
/* 323 */     if (logger.isEnabledFor(0)) { logger.trace("MLet File content is:\n" + mletFileContent);
/*     */     }
/* 325 */     return parseMLetFile(mletFileContent, url);
/*     */   }
/*     */   
/*     */   private Set parseMLetFile(String content, URL mletFileURL) throws ServiceNotFoundException
/*     */   {
/* 330 */     Logger logger = getLogger();
/*     */     
/*     */     try
/*     */     {
/* 334 */       HashSet mbeans = new HashSet();
/* 335 */       MLetParser parser = new MLetParser(this);
/* 336 */       List tags = parser.parse(content);
/*     */       
/* 338 */       for (int i = 0; i < tags.size(); i++)
/*     */       {
/* 340 */         MLetTag tag = (MLetTag)tags.get(i);
/*     */         
/*     */ 
/* 343 */         String[] jars = tag.parseArchive();
/* 344 */         for (int j = 0; j < jars.length; j++)
/*     */         {
/* 346 */           String jar = jars[j];
/* 347 */           URL codebase = handleCheck(tag, jar, mletFileURL, mbeans);
/* 348 */           URL archiveURL = tag.createArchiveURL(codebase, jar);
/* 349 */           addURL(archiveURL);
/*     */         }
/*     */         
/*     */ 
/* 353 */         Object obj = createMBean(tag);
/* 354 */         mbeans.add(obj);
/*     */       }
/*     */       
/* 357 */       return mbeans;
/*     */     }
/*     */     catch (MLetParseException x)
/*     */     {
/* 361 */       if (logger.isEnabledFor(0)) logger.trace("Cannot parse MLet file", x);
/* 362 */       throw new ServiceNotFoundException(x.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private URL handleCheck(MLetTag tag, String archive, URL mletFileURL, Set mbeans)
/*     */   {
/* 371 */     HashMap map = new HashMap();
/* 372 */     map.put("codebaseURL", tag.normalizeCodeBase(mletFileURL));
/* 373 */     map.put("codebase", tag.getCodeBase());
/* 374 */     map.put("archive", tag.getArchive());
/* 375 */     map.put("code", tag.getCode());
/* 376 */     map.put("object", tag.getObject());
/* 377 */     map.put("name", tag.getObjectName());
/* 378 */     map.put("version", tag.getVersion());
/* 379 */     MLetContent mletContent = new MLetContent(mletFileURL, map);
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 384 */       return check(mletContent.getVersion(), mletContent.getCodeBase(), archive, mletContent);
/*     */     }
/*     */     catch (Throwable x)
/*     */     {
/* 388 */       mbeans.add(x); }
/* 389 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected URL check(String version, URL codebase, String archive, MLetContent content)
/*     */     throws Exception
/*     */   {
/* 403 */     return codebase;
/*     */   }
/*     */   
/*     */   private Object createMBean(MLetTag tag) throws ServiceNotFoundException
/*     */   {
/* 408 */     if (this.server == null) { throw new ServiceNotFoundException("MLet not registered on the MBeanServer");
/*     */     }
/* 410 */     Logger logger = getLogger();
/* 411 */     if (logger.isEnabledFor(0)) { logger.trace("MLet " + this + ", creating MBean from\n" + tag);
/*     */     }
/*     */     try
/*     */     {
/* 415 */       Object mbean = null;
/* 416 */       if (tag.getObject() != null)
/*     */       {
/*     */ 
/* 419 */         String name = tag.getObject();
/* 420 */         InputStream is = getResourceAsStream(name);
/* 421 */         if (is == null) { throw new ServiceNotFoundException("Cannot find serialized MBean " + name + " in MLet " + this);
/*     */         }
/* 423 */         InputStream bis = new BufferedInputStream(is);
/*     */         
/*     */ 
/* 426 */         ObjectInputStream ois = new ClassLoaderObjectInputStream(bis, this);
/* 427 */         mbean = ois.readObject();
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 432 */         String clsName = tag.getCode();
/* 433 */         Object[] args = tag.getArguments();
/* 434 */         String[] params = tag.getSignature();
/* 435 */         mbean = this.server.instantiate(clsName, this.objectName, args, params);
/*     */       }
/*     */       
/* 438 */       ObjectName objectName = tag.getObjectName();
/* 439 */       return this.server.registerMBean(mbean, objectName);
/*     */ 
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 444 */       return t;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String findLibrary(String libraryName)
/*     */   {
/* 452 */     String sysLibraryName = System.mapLibraryName(libraryName);
/*     */     
/*     */ 
/* 455 */     String path = copyLibrary(sysLibraryName);
/* 456 */     if (path != null) { return path;
/*     */     }
/*     */     
/* 459 */     String osPath = (String)AccessController.doPrivileged(new PrivilegedAction() {
/*     */       private final String val$sysLibraryName;
/*     */       
/*     */       public Object run() {
/* 463 */         StringBuffer buffer = new StringBuffer();
/* 464 */         buffer.append(System.getProperty("os.name")).append(File.separator);
/* 465 */         buffer.append(System.getProperty("os.arch")).append(File.separator);
/* 466 */         buffer.append(System.getProperty("os.version")).append(File.separator);
/* 467 */         buffer.append("lib").append(File.separator).append(this.val$sysLibraryName);
/* 468 */         return buffer.toString();
/*     */       }
/*     */       
/* 471 */     });
/* 472 */     osPath = removeSpaces(osPath);
/*     */     
/* 474 */     return copyLibrary(osPath);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private String copyLibrary(String library)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokespecial 23	javax/management/loading/MLet:getLogger	()Lmx4j/log/Logger;
/*     */     //   4: astore_2
/*     */     //   5: aload_1
/*     */     //   6: bipush 92
/*     */     //   8: bipush 47
/*     */     //   10: invokevirtual 157	java/lang/String:replace	(CC)Ljava/lang/String;
/*     */     //   13: astore_1
/*     */     //   14: aload_2
/*     */     //   15: iconst_0
/*     */     //   16: invokevirtual 24	mx4j/log/Logger:isEnabledFor	(I)Z
/*     */     //   19: ifeq +26 -> 45
/*     */     //   22: aload_2
/*     */     //   23: new 25	java/lang/StringBuffer
/*     */     //   26: dup
/*     */     //   27: invokespecial 26	java/lang/StringBuffer:<init>	()V
/*     */     //   30: ldc -98
/*     */     //   32: invokevirtual 28	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   35: aload_1
/*     */     //   36: invokevirtual 28	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   39: invokevirtual 31	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*     */     //   42: invokevirtual 32	mx4j/log/Logger:trace	(Ljava/lang/Object;)V
/*     */     //   45: aload_0
/*     */     //   46: aload_1
/*     */     //   47: invokevirtual 159	javax/management/loading/MLet:getResource	(Ljava/lang/String;)Ljava/net/URL;
/*     */     //   50: astore_3
/*     */     //   51: aconst_null
/*     */     //   52: astore 4
/*     */     //   54: aconst_null
/*     */     //   55: astore 5
/*     */     //   57: aload_0
/*     */     //   58: aload_1
/*     */     //   59: invokevirtual 139	javax/management/loading/MLet:getResourceAsStream	(Ljava/lang/String;)Ljava/io/InputStream;
/*     */     //   62: astore 4
/*     */     //   64: aload 4
/*     */     //   66: ifnonnull +19 -> 85
/*     */     //   69: aconst_null
/*     */     //   70: astore 6
/*     */     //   72: aload 4
/*     */     //   74: ifnull +8 -> 82
/*     */     //   77: aload 4
/*     */     //   79: invokevirtual 87	java/io/InputStream:close	()V
/*     */     //   82: aload 6
/*     */     //   84: areturn
/*     */     //   85: aload 4
/*     */     //   87: instanceof 142
/*     */     //   90: ifne +14 -> 104
/*     */     //   93: new 142	java/io/BufferedInputStream
/*     */     //   96: dup
/*     */     //   97: aload 4
/*     */     //   99: invokespecial 143	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
/*     */     //   102: astore 4
/*     */     //   104: new 160	java/io/File
/*     */     //   107: dup
/*     */     //   108: aload_0
/*     */     //   109: invokevirtual 161	javax/management/loading/MLet:getLibraryDirectory	()Ljava/lang/String;
/*     */     //   112: aload_1
/*     */     //   113: invokespecial 162	java/io/File:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   116: astore 6
/*     */     //   118: aload 6
/*     */     //   120: invokevirtual 163	java/io/File:toURL	()Ljava/net/URL;
/*     */     //   123: astore 7
/*     */     //   125: aload 7
/*     */     //   127: aload_3
/*     */     //   128: invokevirtual 164	java/net/URL:equals	(Ljava/lang/Object;)Z
/*     */     //   131: ifeq +23 -> 154
/*     */     //   134: aload 6
/*     */     //   136: invokevirtual 165	java/io/File:getCanonicalPath	()Ljava/lang/String;
/*     */     //   139: astore 8
/*     */     //   141: aload 4
/*     */     //   143: ifnull +8 -> 151
/*     */     //   146: aload 4
/*     */     //   148: invokevirtual 87	java/io/InputStream:close	()V
/*     */     //   151: aload 8
/*     */     //   153: areturn
/*     */     //   154: new 80	java/io/BufferedOutputStream
/*     */     //   157: dup
/*     */     //   158: new 166	java/io/FileOutputStream
/*     */     //   161: dup
/*     */     //   162: aload 6
/*     */     //   164: invokespecial 167	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
/*     */     //   167: invokespecial 81	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
/*     */     //   170: astore 5
/*     */     //   172: aload_0
/*     */     //   173: aload 4
/*     */     //   175: aload 5
/*     */     //   177: invokespecial 83	javax/management/loading/MLet:readFromAndWriteTo	(Ljava/io/InputStream;Ljava/io/OutputStream;)V
/*     */     //   180: aload 6
/*     */     //   182: invokevirtual 165	java/io/File:getCanonicalPath	()Ljava/lang/String;
/*     */     //   185: astore 8
/*     */     //   187: aload 5
/*     */     //   189: ifnull +8 -> 197
/*     */     //   192: aload 5
/*     */     //   194: invokevirtual 168	java/io/OutputStream:close	()V
/*     */     //   197: aload 4
/*     */     //   199: ifnull +8 -> 207
/*     */     //   202: aload 4
/*     */     //   204: invokevirtual 87	java/io/InputStream:close	()V
/*     */     //   207: aload 8
/*     */     //   209: areturn
/*     */     //   210: astore 9
/*     */     //   212: aload 5
/*     */     //   214: ifnull +8 -> 222
/*     */     //   217: aload 5
/*     */     //   219: invokevirtual 168	java/io/OutputStream:close	()V
/*     */     //   222: aload 9
/*     */     //   224: athrow
/*     */     //   225: astore 10
/*     */     //   227: aload 4
/*     */     //   229: ifnull +8 -> 237
/*     */     //   232: aload 4
/*     */     //   234: invokevirtual 87	java/io/InputStream:close	()V
/*     */     //   237: aload 10
/*     */     //   239: athrow
/*     */     //   240: astore 6
/*     */     //   242: aload_2
/*     */     //   243: iconst_0
/*     */     //   244: invokevirtual 24	mx4j/log/Logger:isEnabledFor	(I)Z
/*     */     //   247: ifeq +31 -> 278
/*     */     //   250: aload_2
/*     */     //   251: new 25	java/lang/StringBuffer
/*     */     //   254: dup
/*     */     //   255: invokespecial 26	java/lang/StringBuffer:<init>	()V
/*     */     //   258: ldc -87
/*     */     //   260: invokevirtual 28	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   263: aload_0
/*     */     //   264: invokevirtual 161	javax/management/loading/MLet:getLibraryDirectory	()Ljava/lang/String;
/*     */     //   267: invokevirtual 28	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   270: invokevirtual 31	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*     */     //   273: aload 6
/*     */     //   275: invokevirtual 68	mx4j/log/Logger:trace	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/*     */     //   278: aconst_null
/*     */     //   279: areturn
/*     */     // Line number table:
/*     */     //   Java source line #479	-> byte code offset #0
/*     */     //   Java source line #481	-> byte code offset #5
/*     */     //   Java source line #482	-> byte code offset #14
/*     */     //   Java source line #484	-> byte code offset #45
/*     */     //   Java source line #486	-> byte code offset #51
/*     */     //   Java source line #487	-> byte code offset #54
/*     */     //   Java source line #492	-> byte code offset #57
/*     */     //   Java source line #493	-> byte code offset #64
/*     */     //   Java source line #516	-> byte code offset #72
/*     */     //   Java source line #495	-> byte code offset #85
/*     */     //   Java source line #496	-> byte code offset #104
/*     */     //   Java source line #497	-> byte code offset #118
/*     */     //   Java source line #500	-> byte code offset #125
/*     */     //   Java source line #516	-> byte code offset #141
/*     */     //   Java source line #505	-> byte code offset #154
/*     */     //   Java source line #506	-> byte code offset #172
/*     */     //   Java source line #507	-> byte code offset #180
/*     */     //   Java source line #511	-> byte code offset #187
/*     */     //   Java source line #516	-> byte code offset #197
/*     */     //   Java source line #511	-> byte code offset #210
/*     */     //   Java source line #516	-> byte code offset #225
/*     */     //   Java source line #519	-> byte code offset #240
/*     */     //   Java source line #521	-> byte code offset #242
/*     */     //   Java source line #522	-> byte code offset #278
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	280	0	this	MLet
/*     */     //   0	280	1	library	String
/*     */     //   4	247	2	logger	Logger
/*     */     //   50	78	3	libraryURL	URL
/*     */     //   52	181	4	is	InputStream
/*     */     //   55	163	5	os	OutputStream
/*     */     //   116	65	6	localLibrary	File
/*     */     //   240	34	6	x	IOException
/*     */     //   123	3	7	localLibraryURL	URL
/*     */     //   139	69	8	str2	String
/*     */     //   210	13	9	localObject1	Object
/*     */     //   225	13	10	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   154	187	210	finally
/*     */     //   210	212	210	finally
/*     */     //   57	72	225	finally
/*     */     //   85	141	225	finally
/*     */     //   154	197	225	finally
/*     */     //   210	227	225	finally
/*     */     //   57	82	240	java/io/IOException
/*     */     //   85	151	240	java/io/IOException
/*     */     //   154	207	240	java/io/IOException
/*     */     //   210	240	240	java/io/IOException
/*     */   }
/*     */   
/*     */   private void readFromAndWriteTo(InputStream is, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 528 */     byte[] buffer = new byte[64];
/* 529 */     int read = -1;
/* 530 */     while ((read = is.read(buffer)) >= 0) os.write(buffer, 0, read);
/*     */   }
/*     */   
/*     */   private String removeSpaces(String string)
/*     */   {
/* 535 */     int space = -1;
/* 536 */     StringBuffer buffer = new StringBuffer();
/* 537 */     while ((space = string.indexOf(' ')) >= 0)
/*     */     {
/* 539 */       buffer.append(string.substring(0, space));
/* 540 */       string = string.substring(space + 1);
/*     */     }
/* 542 */     buffer.append(string);
/* 543 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public String getLibraryDirectory()
/*     */   {
/* 548 */     return this.libraryDir;
/*     */   }
/*     */   
/*     */   public void setLibraryDirectory(String libdir)
/*     */   {
/* 553 */     this.libraryDir = libdir;
/*     */   }
/*     */   
/*     */   private boolean isDelegateToCLR()
/*     */   {
/* 558 */     return this.delegateToCLR;
/*     */   }
/*     */   
/*     */   private void setDelegateToCLR(boolean delegateToCLR)
/*     */   {
/* 563 */     this.delegateToCLR = delegateToCLR;
/*     */   }
/*     */   
/*     */   private URL createURL(String urlString) throws ServiceNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 570 */       return new URL(urlString);
/*     */ 
/*     */     }
/*     */     catch (MalformedURLException x)
/*     */     {
/* 575 */       throw new ServiceNotFoundException(x.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/* 581 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readExternal(ObjectInput in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 590 */     throw new UnsupportedOperationException("MLet.readExternal");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeExternal(ObjectOutput out)
/*     */     throws IOException
/*     */   {
/* 599 */     throw new UnsupportedOperationException("MLet.writeExternal");
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/loading/MLet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */