/*    */ package javax.management.loading;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.MBeanServerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ /**
/*    */  * @deprecated
/*    */  */
/*    */ public class DefaultLoaderRepository
/*    */ {
/*    */   public static Class loadClass(String className)
/*    */     throws ClassNotFoundException
/*    */   {
/* 28 */     return loadClassWithout(null, className);
/*    */   }
/*    */   
/*    */   public static Class loadClassWithout(ClassLoader loader, String className) throws ClassNotFoundException
/*    */   {
/* 33 */     ArrayList servers = MBeanServerFactory.findMBeanServer(null);
/* 34 */     for (int i = 0; i < servers.size(); i++)
/*    */     {
/* 36 */       MBeanServer server = (MBeanServer)servers.get(i);
/* 37 */       ClassLoaderRepository repository = server.getClassLoaderRepository();
/*    */       try
/*    */       {
/* 40 */         return repository.loadClassWithout(loader, className);
/*    */       }
/*    */       catch (ClassNotFoundException ignored) {}
/*    */     }
/*    */     
/*    */ 
/* 46 */     throw new ClassNotFoundException(className);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/loading/DefaultLoaderRepository.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */