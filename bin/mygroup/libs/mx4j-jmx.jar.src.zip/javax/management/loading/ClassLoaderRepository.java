package javax.management.loading;

public abstract interface ClassLoaderRepository
{
  public abstract Class loadClass(String paramString)
    throws ClassNotFoundException;
  
  public abstract Class loadClassWithout(ClassLoader paramClassLoader, String paramString)
    throws ClassNotFoundException;
  
  public abstract Class loadClassBefore(ClassLoader paramClassLoader, String paramString)
    throws ClassNotFoundException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/loading/ClassLoaderRepository.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */