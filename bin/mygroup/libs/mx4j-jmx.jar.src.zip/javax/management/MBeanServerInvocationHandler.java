/*     */ package javax.management;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import mx4j.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanServerInvocationHandler
/*     */   implements InvocationHandler
/*     */ {
/*     */   private final MBeanServerConnection connection;
/*     */   private final ObjectName objectName;
/*     */   
/*     */   public MBeanServerInvocationHandler(MBeanServerConnection connection, ObjectName objectName)
/*     */   {
/*  26 */     this.connection = connection;
/*  27 */     this.objectName = objectName;
/*     */   }
/*     */   
/*     */   public static Object newProxyInstance(MBeanServerConnection connection, ObjectName name, Class mbeanInterface, boolean notificationBroadcaster)
/*     */   {
/*  32 */     if (mbeanInterface == null) throw new IllegalArgumentException("MBean interface cannot be null");
/*  33 */     if (!mbeanInterface.isInterface()) throw new IllegalArgumentException("Class parameter must be an interface");
/*  34 */     if (name == null) throw new IllegalArgumentException("MBean ObjectName cannot be null");
/*  35 */     if (connection == null) { throw new IllegalArgumentException("MBeanServerConnection cannot be null");
/*     */     }
/*  37 */     Class[] interfaces = null;
/*  38 */     if ((notificationBroadcaster) && (!mbeanInterface.equals(NotificationEmitter.class)))
/*     */     {
/*  40 */       if (mbeanInterface.equals(NotificationBroadcaster.class))
/*     */       {
/*  42 */         interfaces = new Class[] { NotificationEmitter.class };
/*     */       }
/*     */       else
/*     */       {
/*  46 */         interfaces = new Class[] { mbeanInterface, NotificationEmitter.class };
/*     */       }
/*     */       
/*     */     }
/*     */     else {
/*  51 */       interfaces = new Class[] { mbeanInterface };
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  56 */     ClassLoader loader = mbeanInterface.getClassLoader();
/*  57 */     return Proxy.newProxyInstance(loader, interfaces, new MBeanServerInvocationHandler(connection, name));
/*     */   }
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*     */   {
/*  62 */     Class[] declared = method.getExceptionTypes();
/*     */     
/*  64 */     Class declaringClass = method.getDeclaringClass();
/*  65 */     if ((declaringClass.equals(NotificationBroadcaster.class)) || (declaringClass.equals(NotificationEmitter.class)))
/*     */     {
/*  67 */       return invokeNotificationMethod(proxy, method, args, declared);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  73 */     if (Utils.isAttributeSetter(method))
/*     */     {
/*  75 */       String name = method.getName().substring(3);
/*  76 */       Attribute attribute = new Attribute(name, args[0]);
/*     */       try
/*     */       {
/*  79 */         this.connection.setAttribute(this.objectName, attribute);
/*  80 */         return null;
/*     */       }
/*     */       catch (Throwable x)
/*     */       {
/*  84 */         unwrapThrowable(x, declared);
/*     */       }
/*     */     }
/*  87 */     else if (Utils.isAttributeGetter(method))
/*     */     {
/*  89 */       String n = method.getName();
/*  90 */       String name = null;
/*  91 */       if (n.startsWith("is")) {
/*  92 */         name = n.substring(2);
/*     */       } else {
/*  94 */         name = n.substring(3);
/*     */       }
/*     */       try
/*     */       {
/*  98 */         return this.connection.getAttribute(this.objectName, name);
/*     */       }
/*     */       catch (Throwable x)
/*     */       {
/* 102 */         unwrapThrowable(x, declared);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 107 */       Class[] parameters = method.getParameterTypes();
/* 108 */       String[] params = new String[parameters.length];
/* 109 */       for (int i = 0; i < parameters.length; i++)
/*     */       {
/* 111 */         params[i] = parameters[i].getName();
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 116 */         return this.connection.invoke(this.objectName, method.getName(), args, params);
/*     */       }
/*     */       catch (Throwable x)
/*     */       {
/* 120 */         unwrapThrowable(x, declared);
/*     */       }
/*     */     }
/*     */     
/* 124 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object invokeNotificationMethod(Object proxy, Method method, Object[] args, Class[] declared)
/*     */     throws Throwable
/*     */   {
/* 138 */     String methodName = method.getName();
/* 139 */     int numArgs = args == null ? 0 : args.length;
/*     */     
/* 141 */     if (methodName.equals("addNotificationListener"))
/*     */     {
/*     */       try
/*     */       {
/* 145 */         this.connection.addNotificationListener(this.objectName, (NotificationListener)args[0], (NotificationFilter)args[1], args[2]);
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/* 149 */         unwrapThrowable(t, declared);
/*     */       }
/* 151 */       return null;
/*     */     }
/* 153 */     if (methodName.equals("removeNotificationListener"))
/*     */     {
/* 155 */       switch (numArgs)
/*     */       {
/*     */       case 1: 
/*     */         try
/*     */         {
/* 160 */           this.connection.removeNotificationListener(this.objectName, (NotificationListener)args[0]);
/*     */         }
/*     */         catch (Throwable t)
/*     */         {
/* 164 */           unwrapThrowable(t, declared);
/*     */         }
/* 166 */         return null;
/*     */       
/*     */       case 3: 
/*     */         try
/*     */         {
/* 171 */           this.connection.removeNotificationListener(this.objectName, (NotificationListener)args[0], (NotificationFilter)args[1], args[2]);
/*     */         }
/*     */         catch (Throwable t)
/*     */         {
/* 175 */           unwrapThrowable(t, declared);
/*     */         }
/* 177 */         return null;
/*     */       }
/*     */       
/* 180 */       throw new IllegalArgumentException("Method removeNotificationListener must have 1 or 3 arguments");
/*     */     }
/*     */     
/*     */ 
/* 184 */     if (methodName.equals("getNotificationInfo"))
/*     */     {
/*     */       try
/*     */       {
/* 188 */         MBeanInfo info = this.connection.getMBeanInfo(this.objectName);
/* 189 */         return info.getNotifications();
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/* 193 */         unwrapThrowable(t, declared);
/*     */         
/* 195 */         return null;
/*     */       }
/*     */     }
/*     */     
/* 199 */     throw new IllegalArgumentException("Method " + methodName + " not known to MBean: " + this.objectName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void unwrapThrowable(Throwable x, Class[] declared)
/*     */     throws Throwable
/*     */   {
/* 214 */     if (declared != null)
/*     */     {
/*     */ 
/*     */ 
/* 218 */       for (int i = 0; i < declared.length; i++)
/*     */       {
/* 220 */         Class exception = declared[i];
/* 221 */         if (exception.isInstance(x)) {
/* 222 */           throw x;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 227 */     if ((x instanceof MBeanException))
/*     */     {
/* 229 */       unwrapThrowable(((MBeanException)x).getTargetException(), declared);
/*     */     }
/* 231 */     else if ((x instanceof ReflectionException))
/*     */     {
/* 233 */       unwrapThrowable(((ReflectionException)x).getTargetException(), declared);
/*     */     }
/* 235 */     else if ((x instanceof RuntimeOperationsException))
/*     */     {
/* 237 */       unwrapThrowable(((RuntimeOperationsException)x).getTargetException(), declared);
/*     */     }
/* 239 */     else if ((x instanceof RuntimeMBeanException))
/*     */     {
/* 241 */       unwrapThrowable(((RuntimeMBeanException)x).getTargetException(), declared);
/*     */     }
/* 243 */     else if ((x instanceof RuntimeErrorException))
/*     */     {
/* 245 */       unwrapThrowable(((RuntimeErrorException)x).getTargetError(), declared);
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 252 */       throw x;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanServerInvocationHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */