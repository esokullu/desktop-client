/*     */ package javax.management;
/*     */ 
/*     */ 
/*     */ 
/*     */ class BinaryOpValueExp
/*     */   extends QueryEval
/*     */   implements ValueExp
/*     */ {
/*     */   private static final long serialVersionUID = 1216286847881456786L;
/*     */   
/*     */ 
/*     */   private final int op;
/*     */   
/*     */ 
/*     */   private final ValueExp exp1;
/*     */   
/*     */ 
/*     */   private final ValueExp exp2;
/*     */   
/*     */ 
/*     */ 
/*     */   BinaryOpValueExp(int op, ValueExp exp1, ValueExp exp2)
/*     */   {
/*  24 */     this.op = op;
/*  25 */     this.exp1 = exp1;
/*  26 */     this.exp2 = exp2;
/*     */   }
/*     */   
/*     */   public void setMBeanServer(MBeanServer server)
/*     */   {
/*  31 */     super.setMBeanServer(server);
/*  32 */     if (this.exp1 != null) this.exp1.setMBeanServer(server);
/*  33 */     if (this.exp2 != null) this.exp2.setMBeanServer(server);
/*     */   }
/*     */   
/*     */   public ValueExp apply(ObjectName name) throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException
/*     */   {
/*  38 */     if ((this.exp1 != null) && (this.exp2 != null))
/*     */     {
/*  40 */       ValueExp val1 = this.exp1.apply(name);
/*  41 */       ValueExp val2 = this.exp2.apply(name);
/*     */       
/*  43 */       if ((val1 instanceof NumericValueExp))
/*     */       {
/*  45 */         if ((val2 instanceof NumericValueExp))
/*     */         {
/*  47 */           NumericValueExp num1 = (NumericValueExp)val1;
/*  48 */           NumericValueExp num2 = (NumericValueExp)val2;
/*     */           
/*  50 */           if ((num1.isDouble()) || (num2.isDouble()))
/*     */           {
/*  52 */             double d1 = num1.doubleValue();
/*  53 */             double d2 = num2.doubleValue();
/*  54 */             switch (this.op)
/*     */             {
/*     */             case 0: 
/*  57 */               return Query.value(d1 + d2);
/*     */             case 1: 
/*  59 */               return Query.value(d1 - d2);
/*     */             case 2: 
/*  61 */               return Query.value(d1 * d2);
/*     */             case 3: 
/*  63 */               return Query.value(d1 / d2);
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/*  68 */             long l1 = num1.longValue();
/*  69 */             long l2 = num2.longValue();
/*  70 */             switch (this.op)
/*     */             {
/*     */             case 0: 
/*  73 */               return Query.value(l1 + l2);
/*     */             case 1: 
/*  75 */               return Query.value(l1 - l2);
/*     */             case 2: 
/*  77 */               return Query.value(l1 * l2);
/*     */             case 3: 
/*  79 */               return Query.value(l1 / l2);
/*     */             }
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/*  85 */           throw new BadBinaryOpValueExpException(val2);
/*     */         }
/*     */       } else {
/*  88 */         if ((val1 instanceof StringValueExp))
/*     */         {
/*  90 */           if ((val2 instanceof StringValueExp))
/*     */           {
/*  92 */             String s1 = ((StringValueExp)val1).getValue();
/*  93 */             String s2 = ((StringValueExp)val2).getValue();
/*  94 */             switch (this.op)
/*     */             {
/*     */             case 0: 
/*  97 */               return Query.value(String.valueOf(s1) + String.valueOf(s2));
/*     */             }
/*  99 */             throw new BadStringOperationException("Trying to perform an operation on Strings that is not concatenation");
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 104 */           throw new BadBinaryOpValueExpException(val2);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 109 */         throw new BadBinaryOpValueExpException(val1);
/*     */       }
/*     */     }
/* 112 */     throw new BadBinaryOpValueExpException(null);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/BinaryOpValueExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */