package javax.management;

import java.io.Serializable;

public abstract interface NotificationFilter
  extends Serializable
{
  public abstract boolean isNotificationEnabled(Notification paramNotification);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/NotificationFilter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */