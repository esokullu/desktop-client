/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ClassAttributeValueExp
/*    */   extends AttributeValueExp
/*    */ {
/*    */   private static final long serialVersionUID = -1081892073854801359L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private String attr;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private transient MBeanServer server;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ClassAttributeValueExp()
/*    */   {
/* 28 */     super("classname");
/*    */   }
/*    */   
/*    */   public void setMBeanServer(MBeanServer server)
/*    */   {
/* 33 */     super.setMBeanServer(server);
/* 34 */     this.server = server;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public ValueExp apply(ObjectName name)
/*    */     throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException
/*    */   {
/*    */     try
/*    */     {
/* 44 */       String className = this.server.getObjectInstance(name).getClassName();
/* 45 */       return new StringValueExp(className);
/*    */ 
/*    */     }
/*    */     catch (InstanceNotFoundException ignored)
/*    */     {
/* 50 */       throw new BadAttributeValueExpException(null);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/ClassAttributeValueExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */