/*     */ package javax.management;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import mx4j.util.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanAttributeInfo
/*     */   extends MBeanFeatureInfo
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 8644704819898565848L;
/*     */   private String attributeType;
/*     */   private boolean isRead;
/*     */   private boolean isWrite;
/*     */   private boolean is;
/*     */   
/*     */   public MBeanAttributeInfo(String name, String description, Method getter, Method setter)
/*     */     throws IntrospectionException
/*     */   {
/*  53 */     super(name, description);
/*     */     
/*  55 */     String getterType = null;
/*  56 */     String setterType = null;
/*     */     
/*  58 */     if (getter != null)
/*     */     {
/*  60 */       if (Utils.isAttributeGetter(getter))
/*     */       {
/*  62 */         this.isRead = true;
/*  63 */         if (getter.getName().startsWith("is")) this.is = true;
/*  64 */         getterType = getter.getReturnType().getName();
/*     */       }
/*     */       else {
/*  67 */         throw new IntrospectionException("Bad getter method");
/*     */       } }
/*  69 */     if (setter != null)
/*     */     {
/*  71 */       if (Utils.isAttributeSetter(setter))
/*     */       {
/*  73 */         this.isWrite = true;
/*  74 */         setterType = setter.getParameterTypes()[0].getName();
/*     */       }
/*     */       else {
/*  77 */         throw new IntrospectionException("Bad setter method");
/*     */       }
/*     */     }
/*  80 */     this.attributeType = reconcileAttributeType(getterType, setterType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MBeanAttributeInfo(String name, String className, String description, boolean isReadable, boolean isWritable, boolean isIs)
/*     */   {
/*  94 */     super(name, description);
/*     */     
/*  96 */     this.attributeType = className;
/*  97 */     this.isRead = isReadable;
/*  98 */     this.isWrite = isWritable;
/*  99 */     this.is = isIs;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*     */     try
/*     */     {
/* 106 */       return super.clone();
/*     */     }
/*     */     catch (CloneNotSupportedException ignored) {}
/*     */     
/* 110 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getType()
/*     */   {
/* 116 */     return this.attributeType;
/*     */   }
/*     */   
/*     */   public boolean isReadable()
/*     */   {
/* 121 */     return this.isRead;
/*     */   }
/*     */   
/*     */   public boolean isWritable()
/*     */   {
/* 126 */     return this.isWrite;
/*     */   }
/*     */   
/*     */   public boolean isIs()
/*     */   {
/* 131 */     return this.is;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 136 */     int hash = super.hashCode();
/*     */     
/* 138 */     String t = getType();
/* 139 */     if (t != null) { hash = 29 * hash + t.hashCode();
/*     */     }
/* 141 */     hash = 29 * hash + 3 * (isReadable() ? Boolean.TRUE.hashCode() : Boolean.FALSE.hashCode());
/* 142 */     hash = 29 * hash + 5 * (isWritable() ? Boolean.TRUE.hashCode() : Boolean.FALSE.hashCode());
/* 143 */     hash = 29 * hash + 7 * (isIs() ? Boolean.TRUE.hashCode() : Boolean.FALSE.hashCode());
/*     */     
/* 145 */     return hash;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 150 */     if (!super.equals(obj)) return false;
/* 151 */     if (!(obj instanceof MBeanAttributeInfo)) { return false;
/*     */     }
/* 153 */     MBeanAttributeInfo other = (MBeanAttributeInfo)obj;
/*     */     
/* 155 */     String thisType = getType();
/* 156 */     String otherType = other.getType();
/* 157 */     if (thisType != null ? !thisType.equals(otherType) : otherType != null) { return false;
/*     */     }
/* 159 */     if ((isReadable() ^ other.isReadable())) return false;
/* 160 */     if ((isWritable() ^ other.isWritable())) return false;
/* 161 */     if ((isIs() ^ other.isIs())) { return false;
/*     */     }
/* 163 */     return true;
/*     */   }
/*     */   
/*     */   private String reconcileAttributeType(String getterType, String setterType)
/*     */     throws IntrospectionException
/*     */   {
/* 169 */     String result = null;
/*     */     
/* 171 */     if ((getterType == null) && (setterType != null))
/*     */     {
/* 173 */       result = setterType;
/*     */     }
/* 175 */     else if ((getterType != null) && (setterType == null))
/*     */     {
/* 177 */       result = getterType;
/*     */     }
/* 179 */     else if ((getterType != null) && (setterType != null))
/*     */     {
/* 181 */       if (getterType.compareToIgnoreCase(setterType) == 0)
/*     */       {
/* 183 */         result = getterType;
/*     */       }
/*     */       else
/*     */       {
/* 187 */         throw new IntrospectionException("Attribute setter/getter types don't match");
/*     */       }
/*     */     }
/*     */     
/* 191 */     return result;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanAttributeInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */