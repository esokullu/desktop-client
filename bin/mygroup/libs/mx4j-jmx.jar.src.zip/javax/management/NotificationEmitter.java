package javax.management;

public abstract interface NotificationEmitter
  extends NotificationBroadcaster
{
  public abstract void removeNotificationListener(NotificationListener paramNotificationListener, NotificationFilter paramNotificationFilter, Object paramObject)
    throws ListenerNotFoundException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/NotificationEmitter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */