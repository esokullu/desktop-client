/*    */ package javax.management;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanException
/*    */   extends JMException
/*    */ {
/*    */   private static final long serialVersionUID = 4066342430588744142L;
/*    */   private final Exception exception;
/*    */   
/*    */   public MBeanException(Exception x)
/*    */   {
/* 28 */     this.exception = x;
/*    */   }
/*    */   
/*    */   public MBeanException(Exception x, String message)
/*    */   {
/* 33 */     super(message);
/* 34 */     this.exception = x;
/*    */   }
/*    */   
/*    */   public String getMessage()
/*    */   {
/* 39 */     return super.getMessage() + " nested exception is " + getTargetException();
/*    */   }
/*    */   
/*    */   public Exception getTargetException()
/*    */   {
/* 44 */     return this.exception;
/*    */   }
/*    */   
/*    */   public Throwable getCause()
/*    */   {
/* 49 */     return getTargetException();
/*    */   }
/*    */   
/*    */   public void printStackTrace()
/*    */   {
/* 54 */     if (this.exception == null)
/*    */     {
/* 56 */       super.printStackTrace();
/*    */     }
/*    */     else
/*    */     {
/* 60 */       synchronized (System.err)
/*    */       {
/* 62 */         System.err.println(this);
/* 63 */         this.exception.printStackTrace();
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void printStackTrace(PrintStream s)
/*    */   {
/* 70 */     if (this.exception == null)
/*    */     {
/* 72 */       super.printStackTrace(s);
/*    */     }
/*    */     else
/*    */     {
/* 76 */       synchronized (s)
/*    */       {
/* 78 */         s.println(this);
/* 79 */         this.exception.printStackTrace(s);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void printStackTrace(PrintWriter w)
/*    */   {
/* 86 */     if (this.exception == null)
/*    */     {
/* 88 */       super.printStackTrace(w);
/*    */     }
/*    */     else
/*    */     {
/* 92 */       synchronized (w)
/*    */       {
/* 94 */         w.println(this);
/* 95 */         this.exception.printStackTrace(w);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/MBeanException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */