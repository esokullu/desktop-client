/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringValueExp
/*    */   implements ValueExp
/*    */ {
/*    */   private static final long serialVersionUID = -3256390509806284044L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private String val;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public StringValueExp()
/*    */   {
/* 30 */     this(null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public StringValueExp(String value)
/*    */   {
/* 38 */     this.val = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 46 */     return this.val;
/*    */   }
/*    */   
/*    */   public ValueExp apply(ObjectName name) throws BadStringOperationException, BadBinaryOpValueExpException, BadAttributeValueExpException, InvalidApplicationException
/*    */   {
/* 51 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setMBeanServer(MBeanServer server) {}
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 61 */     return this.val;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/StringValueExp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */