/*    */ package javax.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OperationsException
/*    */   extends JMException
/*    */ {
/*    */   private static final long serialVersionUID = -4967597595580536216L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OperationsException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OperationsException(String message)
/*    */   {
/* 26 */     super(message);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/OperationsException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */