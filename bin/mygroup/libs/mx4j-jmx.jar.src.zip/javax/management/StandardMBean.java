/*     */ package javax.management;
/*     */ 
/*     */ import mx4j.AbstractDynamicMBean;
/*     */ import mx4j.server.MBeanIntrospector;
/*     */ import mx4j.server.MBeanMetaData;
/*     */ import mx4j.server.MBeanMetaData.Factory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardMBean
/*     */   implements DynamicMBean
/*     */ {
/*     */   private MBeanMetaData metadata;
/*     */   private MBeanInfo info;
/*     */   private DynamicMBean support;
/*     */   
/*     */   public StandardMBean(Object implementation, Class management)
/*     */     throws NotCompliantMBeanException
/*     */   {
/* 101 */     this(implementation, management, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected StandardMBean(Class managementInterface)
/*     */     throws NotCompliantMBeanException
/*     */   {
/* 111 */     this(null, managementInterface, true);
/*     */   }
/*     */   
/*     */   private StandardMBean(Object implementation, Class management, boolean useThis) throws NotCompliantMBeanException
/*     */   {
/* 116 */     if (useThis) implementation = this;
/* 117 */     if (implementation == null) throw new IllegalArgumentException("Implementation cannot be null");
/* 118 */     if ((management != null) && (!management.isInterface())) { throw new NotCompliantMBeanException("Class " + management + " is not an interface");
/*     */     }
/* 120 */     this.metadata = introspectMBean(implementation, management);
/* 121 */     if (this.metadata == null) { throw new NotCompliantMBeanException("StandardMBean is not compliant");
/*     */     }
/* 123 */     this.support = new StandardMBeanSupport(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setImplementation(Object implementation)
/*     */     throws NotCompliantMBeanException
/*     */   {
/* 137 */     if (implementation == null) throw new IllegalArgumentException("Implementation cannot be null");
/* 138 */     Class management = getMBeanInterface();
/* 139 */     if (!management.isInstance(implementation)) throw new NotCompliantMBeanException("Implementation " + implementation + " does not implement interface " + management);
/* 140 */     this.metadata.setMBean(implementation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getImplementation()
/*     */   {
/* 151 */     return this.metadata.getMBean();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Class getMBeanInterface()
/*     */   {
/* 163 */     return this.metadata.getMBeanInterface();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class getImplementationClass()
/*     */   {
/* 174 */     return this.metadata.getMBean().getClass();
/*     */   }
/*     */   
/*     */   public Object getAttribute(String attribute) throws AttributeNotFoundException, MBeanException, ReflectionException
/*     */   {
/* 179 */     return this.support.getAttribute(attribute);
/*     */   }
/*     */   
/*     */   public void setAttribute(Attribute attribute) throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException
/*     */   {
/* 184 */     this.support.setAttribute(attribute);
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(String[] attributes)
/*     */   {
/* 189 */     return this.support.getAttributes(attributes);
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(AttributeList attributes)
/*     */   {
/* 194 */     return this.support.setAttributes(attributes);
/*     */   }
/*     */   
/*     */   public Object invoke(String method, Object[] arguments, String[] params) throws MBeanException, ReflectionException
/*     */   {
/* 199 */     return this.support.invoke(method, arguments, params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MBeanInfo getMBeanInfo()
/*     */   {
/* 212 */     MBeanInfo info = getCachedMBeanInfo();
/* 213 */     if (info == null)
/*     */     {
/* 215 */       info = setupMBeanInfo(this.metadata.getMBeanInfo());
/* 216 */       cacheMBeanInfo(info);
/*     */     }
/* 218 */     return info;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getClassName(MBeanInfo info)
/*     */   {
/* 227 */     return info == null ? null : info.getClassName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanInfo info)
/*     */   {
/* 236 */     return info == null ? null : info.getDescription();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanFeatureInfo info)
/*     */   {
/* 249 */     return info == null ? null : info.getDescription();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanAttributeInfo info)
/*     */   {
/* 258 */     return getDescription(info);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanConstructorInfo info)
/*     */   {
/* 267 */     return getDescription(info);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanOperationInfo info)
/*     */   {
/* 276 */     return getDescription(info);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanConstructorInfo constructor, MBeanParameterInfo param, int sequence)
/*     */   {
/* 286 */     return param == null ? null : param.getDescription();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanOperationInfo operation, MBeanParameterInfo param, int sequence)
/*     */   {
/* 296 */     return param == null ? null : param.getDescription();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getParameterName(MBeanConstructorInfo constructor, MBeanParameterInfo param, int sequence)
/*     */   {
/* 306 */     return param == null ? null : param.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getParameterName(MBeanOperationInfo operation, MBeanParameterInfo param, int sequence)
/*     */   {
/* 316 */     return param == null ? null : param.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getImpact(MBeanOperationInfo info)
/*     */   {
/* 325 */     return info == null ? 3 : info.getImpact();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanConstructorInfo[] getConstructors(MBeanConstructorInfo[] constructors, Object implementation)
/*     */   {
/* 337 */     if ((implementation == this) || (implementation == null)) return constructors;
/* 338 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanInfo getCachedMBeanInfo()
/*     */   {
/* 349 */     return this.info;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void cacheMBeanInfo(MBeanInfo info)
/*     */   {
/* 363 */     this.info = info;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MBeanInfo setupMBeanInfo(MBeanInfo info)
/*     */   {
/* 373 */     String clsName = getClassName(info);
/* 374 */     String description = getDescription(info);
/* 375 */     MBeanConstructorInfo[] ctors = setupConstructors(info.getConstructors());
/* 376 */     MBeanAttributeInfo[] attrs = setupAttributes(info.getAttributes());
/* 377 */     MBeanOperationInfo[] opers = setupOperations(info.getOperations());
/* 378 */     MBeanNotificationInfo[] notifs = setupNotifications(info.getNotifications());
/* 379 */     return new MBeanInfo(clsName, description, attrs, ctors, opers, notifs);
/*     */   }
/*     */   
/*     */   private MBeanConstructorInfo[] setupConstructors(MBeanConstructorInfo[] originalCtors)
/*     */   {
/* 384 */     MBeanConstructorInfo[] ctors = getConstructors(originalCtors, getImplementation());
/* 385 */     if (ctors == null) { return null;
/*     */     }
/* 387 */     MBeanConstructorInfo[] newCtors = new MBeanConstructorInfo[ctors.length];
/* 388 */     for (int i = 0; i < ctors.length; i++)
/*     */     {
/* 390 */       MBeanConstructorInfo ctor = ctors[i];
/* 391 */       if (ctor != null)
/*     */       {
/* 393 */         MBeanParameterInfo[] newParams = null;
/* 394 */         MBeanParameterInfo[] params = ctor.getSignature();
/* 395 */         if (params != null)
/*     */         {
/* 397 */           newParams = new MBeanParameterInfo[params.length];
/* 398 */           for (int j = 0; j < params.length; j++)
/*     */           {
/* 400 */             MBeanParameterInfo param = params[j];
/* 401 */             if (param != null)
/*     */             {
/* 403 */               String paramName = getParameterName(ctor, param, j);
/* 404 */               String paramDescr = getDescription(ctor, param, j);
/* 405 */               newParams[j] = new MBeanParameterInfo(paramName, param.getType(), paramDescr);
/*     */             }
/*     */           }
/*     */         }
/* 409 */         String ctorDescr = getDescription(ctor);
/* 410 */         newCtors[i] = new MBeanConstructorInfo(ctor.getName(), ctorDescr, newParams);
/*     */       }
/*     */     }
/* 413 */     return newCtors;
/*     */   }
/*     */   
/*     */   private MBeanAttributeInfo[] setupAttributes(MBeanAttributeInfo[] attrs)
/*     */   {
/* 418 */     if (attrs == null) { return null;
/*     */     }
/* 420 */     MBeanAttributeInfo[] newAttrs = new MBeanAttributeInfo[attrs.length];
/* 421 */     for (int i = 0; i < attrs.length; i++)
/*     */     {
/* 423 */       MBeanAttributeInfo attr = attrs[i];
/* 424 */       if (attr != null)
/*     */       {
/* 426 */         String attrDescr = getDescription(attr);
/* 427 */         newAttrs[i] = new MBeanAttributeInfo(attr.getName(), attr.getType(), attrDescr, attr.isReadable(), attr.isWritable(), attr.isIs());
/*     */       }
/*     */     }
/* 430 */     return newAttrs;
/*     */   }
/*     */   
/*     */   private MBeanOperationInfo[] setupOperations(MBeanOperationInfo[] opers)
/*     */   {
/* 435 */     if (opers == null) { return null;
/*     */     }
/* 437 */     MBeanOperationInfo[] newOpers = new MBeanOperationInfo[opers.length];
/* 438 */     for (int i = 0; i < opers.length; i++)
/*     */     {
/* 440 */       MBeanOperationInfo oper = opers[i];
/* 441 */       if (oper != null)
/*     */       {
/* 443 */         MBeanParameterInfo[] newParams = null;
/* 444 */         MBeanParameterInfo[] params = oper.getSignature();
/* 445 */         if (params != null)
/*     */         {
/* 447 */           newParams = new MBeanParameterInfo[params.length];
/* 448 */           for (int j = 0; j < params.length; j++)
/*     */           {
/* 450 */             MBeanParameterInfo param = params[j];
/* 451 */             if (param != null)
/*     */             {
/* 453 */               String paramName = getParameterName(oper, param, j);
/* 454 */               String paramDescr = getDescription(oper, param, j);
/* 455 */               newParams[j] = new MBeanParameterInfo(paramName, param.getType(), paramDescr);
/*     */             }
/*     */           }
/*     */         }
/* 459 */         String operDescr = getDescription(oper);
/* 460 */         int operImpact = getImpact(oper);
/* 461 */         newOpers[i] = new MBeanOperationInfo(oper.getName(), operDescr, newParams, oper.getReturnType(), operImpact);
/*     */       }
/*     */     }
/* 464 */     return newOpers;
/*     */   }
/*     */   
/*     */   private MBeanNotificationInfo[] setupNotifications(MBeanNotificationInfo[] notifs)
/*     */   {
/* 469 */     return notifs == null ? null : notifs;
/*     */   }
/*     */   
/*     */   private MBeanMetaData introspectMBean(Object implementation, Class management)
/*     */   {
/* 474 */     MBeanMetaData metadata = MBeanMetaData.Factory.create();
/* 475 */     metadata.setMBean(implementation);
/* 476 */     metadata.setClassLoader(implementation.getClass().getClassLoader());
/* 477 */     metadata.setMBeanStandard(true);
/* 478 */     metadata.setMBeanInterface(management);
/*     */     
/* 480 */     MBeanIntrospector introspector = new MBeanIntrospector();
/* 481 */     introspector.introspect(metadata);
/* 482 */     if (!introspector.isMBeanCompliant(metadata)) { return null;
/*     */     }
/* 484 */     return metadata;
/*     */   }
/*     */   
/* 487 */   private class StandardMBeanSupport extends AbstractDynamicMBean { StandardMBeanSupport(StandardMBean.1 x1) { this(); }
/*     */     
/*     */     public synchronized MBeanInfo getMBeanInfo()
/*     */     {
/* 491 */       return StandardMBean.this.getMBeanInfo();
/*     */     }
/*     */     
/*     */     protected Object getResource()
/*     */     {
/* 496 */       return StandardMBean.this.getImplementation();
/*     */     }
/*     */     
/*     */     private StandardMBeanSupport() {}
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/StandardMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */