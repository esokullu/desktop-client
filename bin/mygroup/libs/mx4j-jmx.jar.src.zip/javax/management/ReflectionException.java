/*     */ package javax.management;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectionException
/*     */   extends JMException
/*     */ {
/*     */   private static final long serialVersionUID = 9170809325636915553L;
/*     */   private Exception exception;
/*     */   
/*     */   public ReflectionException(Exception x)
/*     */   {
/*  36 */     this.exception = x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReflectionException(Exception x, String message)
/*     */   {
/*  47 */     super(message);
/*  48 */     this.exception = x;
/*     */   }
/*     */   
/*     */   public String getMessage()
/*     */   {
/*  53 */     return super.getMessage() + " nested exception is " + this.exception;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Exception getTargetException()
/*     */   {
/*  61 */     return this.exception;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getCause()
/*     */   {
/*  69 */     return getTargetException();
/*     */   }
/*     */   
/*     */   public void printStackTrace()
/*     */   {
/*  74 */     if (this.exception == null)
/*     */     {
/*  76 */       super.printStackTrace();
/*     */     }
/*     */     else
/*     */     {
/*  80 */       synchronized (System.err)
/*     */       {
/*  82 */         System.err.println(this);
/*  83 */         this.exception.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void printStackTrace(PrintStream s)
/*     */   {
/*  90 */     if (this.exception == null)
/*     */     {
/*  92 */       super.printStackTrace(s);
/*     */     }
/*     */     else
/*     */     {
/*  96 */       synchronized (s)
/*     */       {
/*  98 */         s.println(this);
/*  99 */         this.exception.printStackTrace(s);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void printStackTrace(PrintWriter w)
/*     */   {
/* 106 */     if (this.exception == null)
/*     */     {
/* 108 */       super.printStackTrace(w);
/*     */     }
/*     */     else
/*     */     {
/* 112 */       synchronized (w)
/*     */       {
/* 114 */         w.println(this);
/* 115 */         this.exception.printStackTrace(w);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-jmx.jar!/javax/management/ReflectionException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */