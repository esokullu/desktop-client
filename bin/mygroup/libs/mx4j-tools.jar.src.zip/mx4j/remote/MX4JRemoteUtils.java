/*     */ package mx4j.remote;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessControlException;
/*     */ import java.security.AccessController;
/*     */ import java.security.CodeSource;
/*     */ import java.security.DomainCombiner;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.security.Principal;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.management.remote.SubjectDelegationPermission;
/*     */ import javax.security.auth.AuthPermission;
/*     */ import javax.security.auth.Policy;
/*     */ import javax.security.auth.Subject;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MX4JRemoteUtils
/*     */ {
/*     */   private static int connectionNumber;
/*     */   
/*     */   public static Map removeNonSerializableEntries(Map map)
/*     */   {
/*  52 */     Map newMap = new HashMap(map.size());
/*  53 */     for (Iterator i = map.entrySet().iterator(); i.hasNext();)
/*     */     {
/*  55 */       Map.Entry entry = (Map.Entry)i.next();
/*  56 */       if (isSerializable(entry)) newMap.put(entry.getKey(), entry.getValue());
/*     */     }
/*  58 */     return newMap;
/*     */   }
/*     */   
/*     */   private static boolean isSerializable(Object object)
/*     */   {
/*  63 */     if ((object instanceof Map.Entry)) return (isSerializable(((Map.Entry)object).getKey())) && (isSerializable(((Map.Entry)object).getValue()));
/*  64 */     if (object == null) return true;
/*  65 */     if ((object instanceof String)) return true;
/*  66 */     if ((object instanceof Number)) return true;
/*  67 */     if (!(object instanceof Serializable)) { return false;
/*     */     }
/*  69 */     return isTrulySerializable(object);
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean isTrulySerializable(Object object)
/*     */   {
/*     */     try
/*     */     {
/*  77 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  78 */       ObjectOutputStream oos = new ObjectOutputStream(baos);
/*  79 */       oos.writeObject(object);
/*  80 */       oos.close();
/*  81 */       return true;
/*     */     }
/*     */     catch (IOException ignored) {}
/*     */     
/*     */ 
/*  86 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String createConnectionID(String protocol, String callerAddress, int callerPort, Subject subject)
/*     */   {
/*  93 */     StringBuffer buffer = new StringBuffer(protocol);
/*  94 */     buffer.append(':');
/*  95 */     if (callerAddress != null) buffer.append("//").append(callerAddress);
/*  96 */     if (callerPort >= 0) buffer.append(':').append(callerPort);
/*  97 */     buffer.append(' ');
/*     */     Iterator i;
/*  99 */     if (subject != null)
/*     */     {
/* 101 */       Set principals = subject.getPrincipals();
/* 102 */       for (i = principals.iterator(); i.hasNext();)
/*     */       {
/* 104 */         Principal principal = (Principal)i.next();
/* 105 */         String name = principal.getName();
/* 106 */         name = name.replace(' ', '_');
/* 107 */         buffer.append(name);
/* 108 */         if (i.hasNext()) buffer.append(';');
/*     */       }
/*     */     }
/* 111 */     buffer.append(' ');
/*     */     
/* 113 */     buffer.append("0x").append(Integer.toHexString(getNextConnectionNumber()).toUpperCase());
/*     */     
/* 115 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private static synchronized int getNextConnectionNumber()
/*     */   {
/* 120 */     return ++connectionNumber;
/*     */   }
/*     */   
/*     */   private static Logger getLogger()
/*     */   {
/* 125 */     return Log.getLogger(MX4JRemoteUtils.class.getName());
/*     */   }
/*     */   
/*     */   public static Object subjectInvoke(Subject subject, Subject delegate, AccessControlContext context, Map environment, PrivilegedExceptionAction action) throws Exception
/*     */   {
/* 130 */     if (delegate != null)
/*     */     {
/* 132 */       if (subject == null) throw new SecurityException("There is no authenticated subject to delegate to");
/* 133 */       checkSubjectDelegationPermission(delegate, getSubjectContext(subject, null, context, environment));
/*     */     }
/*     */     
/* 136 */     Logger logger = getLogger();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */     if (subject == null)
/*     */     {
/* 146 */       if (logger.isEnabledFor(0)) logger.trace("No authenticated subject, invoking action without using Subject.doAs");
/* 147 */       return action.run();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 158 */       if (delegate == null)
/*     */       {
/* 160 */         if (logger.isEnabledFor(0)) logger.trace("Invoking Subject.doAs using authenticated subject " + subject);
/* 161 */         return Subject.doAsPrivileged(subject, action, getSubjectContext(subject, delegate, context, environment));
/*     */       }
/*     */       
/*     */ 
/* 165 */       if (logger.isEnabledFor(0)) logger.trace("Invoking Subject.doAs using delegate subject " + delegate);
/* 166 */       return Subject.doAsPrivileged(delegate, action, getSubjectContext(subject, delegate, context, environment));
/*     */ 
/*     */     }
/*     */     catch (PrivilegedActionException x)
/*     */     {
/* 171 */       throw x.getException();
/*     */     }
/*     */   }
/*     */   
/*     */   private static void checkSubjectDelegationPermission(Subject delegate, AccessControlContext context) throws SecurityException
/*     */   {
/* 177 */     Logger logger = getLogger();
/*     */     
/* 179 */     SecurityManager sm = System.getSecurityManager();
/* 180 */     if (sm == null)
/*     */     {
/* 182 */       if (logger.isEnabledFor(0)) logger.trace("No SecurityManager, skipping Subject delegation permission check");
/* 183 */       return;
/*     */     }
/*     */     
/* 186 */     AccessController.doPrivileged(new PrivilegedAction() {
/*     */       private final Subject val$delegate;
/*     */       
/*     */       public Object run() {
/* 190 */         StringBuffer buffer = new StringBuffer();
/* 191 */         Set principals = this.val$delegate.getPrincipals();
/* 192 */         for (Iterator i = principals.iterator(); i.hasNext();)
/*     */         {
/* 194 */           Principal principal = (Principal)i.next();
/* 195 */           buffer.setLength(0);
/* 196 */           String permission = principal.getClass().getName() + "." + principal.getName();
/* 197 */           AccessController.checkPermission(new SubjectDelegationPermission(permission));
/*     */         }
/* 199 */         return null; } }, context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static AccessControlContext getSubjectContext(Subject subject, Subject delegate, AccessControlContext context, Map environment)
/*     */   {
/* 248 */     Logger logger = getLogger();
/*     */     
/* 250 */     SecurityManager sm = System.getSecurityManager();
/* 251 */     if (sm == null)
/*     */     {
/* 253 */       if (logger.isEnabledFor(0)) { logger.trace("No security manager, injecting JSR 160 domain only");
/*     */       }
/* 255 */       InjectingDomainCombiner combiner = new InjectingDomainCombiner(delegate != null ? delegate : subject);
/* 256 */       return new AccessControlContext(new ProtectionDomain[] { combiner.getInjectedProtectionDomain() });
/*     */     }
/*     */     
/*     */ 
/* 260 */     boolean combine = ((Boolean)AccessController.doPrivileged(new PrivilegedAction() {
/*     */       private final Subject val$subject;
/*     */       private final AccessControlContext val$context;
/*     */       private final Logger val$logger;
/*     */       
/*     */       public Object run() {
/*     */         try {
/* 267 */           MX4JRemoteUtils.checkSubjectDelegationPermission(this.val$subject, this.val$context);
/* 268 */           if (this.val$logger.isEnabledFor(0)) this.val$logger.trace("Check for SubjectDelegationPermission passed, avoiding security domains combination");
/* 269 */           return Boolean.FALSE;
/*     */         }
/*     */         catch (AccessControlException x)
/*     */         {
/* 273 */           if (this.val$logger.isEnabledFor(0)) this.val$logger.trace("Check for SubjectDelegationPermission not passed, combining security domains"); }
/* 274 */         return Boolean.TRUE; } }, context)).booleanValue();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 279 */     if (combine)
/*     */     {
/* 281 */       InjectingDomainCombiner combiner = new InjectingDomainCombiner(delegate != null ? delegate : subject);
/* 282 */       AccessControlContext acc = (AccessControlContext)AccessController.doPrivileged(new PrivilegedAction() {
/*     */         private final AccessControlContext val$context;
/*     */         private final MX4JRemoteUtils.InjectingDomainCombiner val$combiner;
/*     */         
/* 286 */         public Object run() { return new AccessControlContext(this.val$context, this.val$combiner);
/*     */         }
/* 288 */       });
/* 289 */       AccessController.doPrivileged(new PrivilegedAction()
/*     */       {
/*     */ 
/*     */         public Object run()
/*     */         {
/*     */           try
/*     */           {
/* 296 */             AccessController.checkPermission(new AuthPermission("doAsPrivileged"));
/*     */           }
/*     */           catch (AccessControlException ignored) {}
/*     */           
/*     */ 
/* 301 */           return null; } }, acc);
/*     */       
/*     */ 
/* 304 */       ProtectionDomain[] combined = combiner.getCombinedDomains();
/* 305 */       return new AccessControlContext(combined);
/*     */     }
/*     */     
/*     */ 
/* 309 */     InjectingDomainCombiner combiner = new InjectingDomainCombiner(delegate != null ? delegate : subject);
/* 310 */     return new AccessControlContext(new ProtectionDomain[] { combiner.getInjectedProtectionDomain() });
/*     */   }
/*     */   
/*     */   private static class InjectingDomainCombiner implements DomainCombiner
/*     */   {
/*     */     private static Constructor domainConstructor;
/*     */     private ProtectionDomain domain;
/*     */     private ProtectionDomain[] combined;
/*     */     
/*     */     static
/*     */     {
/*     */       try {
/* 322 */         domainConstructor = MX4JRemoteUtils.class$java$security$ProtectionDomain.getConstructor(new Class[] { CodeSource.class, PermissionCollection.class, ClassLoader.class, new Principal[0].getClass() });
/*     */       }
/*     */       catch (Exception x) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public InjectingDomainCombiner(Subject subject)
/*     */     {
/* 334 */       if (domainConstructor != null)
/*     */       {
/* 336 */         Principal[] principals = (Principal[])subject.getPrincipals().toArray(new Principal[0]);
/*     */         try
/*     */         {
/* 339 */           this.domain = ((ProtectionDomain)domainConstructor.newInstance(new Object[] { new CodeSource(null, null), null, null, principals }));
/*     */         }
/*     */         catch (Exception x) {}
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 346 */       if (this.domain == null)
/*     */       {
/*     */ 
/* 349 */         this.domain = new SubjectProtectionDomain(new CodeSource(null, null), subject);
/*     */       }
/*     */     }
/*     */     
/*     */     public ProtectionDomain getInjectedProtectionDomain()
/*     */     {
/* 355 */       return this.domain;
/*     */     }
/*     */     
/*     */     public ProtectionDomain[] combine(ProtectionDomain[] current, ProtectionDomain[] assigned)
/*     */     {
/* 360 */       int length = current.length;
/* 361 */       ProtectionDomain[] result = null;
/* 362 */       if ((assigned == null) || (assigned.length == 0))
/*     */       {
/* 364 */         result = new ProtectionDomain[length + 1];
/* 365 */         System.arraycopy(current, 0, result, 1, length);
/*     */       }
/*     */       else
/*     */       {
/* 369 */         result = new ProtectionDomain[length + assigned.length + 1];
/* 370 */         System.arraycopy(current, 0, result, 1, length);
/* 371 */         System.arraycopy(assigned, 0, result, length + 1, assigned.length);
/*     */       }
/* 373 */       result[0] = this.domain;
/* 374 */       this.combined = result;
/*     */       
/* 376 */       Logger logger = MX4JRemoteUtils.access$100();
/* 377 */       if (logger.isEnabledFor(0))
/*     */       {
/* 379 */         logger.trace("Security domains combination");
/* 380 */         logger.trace("Current domains");
/* 381 */         logger.trace(dumpDomains(current));
/* 382 */         logger.trace("Assigned domains");
/* 383 */         logger.trace(dumpDomains(assigned));
/* 384 */         logger.trace("Combined domains");
/* 385 */         logger.trace(dumpDomains(result));
/*     */       }
/*     */       
/* 388 */       return result;
/*     */     }
/*     */     
/*     */     private String dumpDomains(ProtectionDomain[] domains)
/*     */     {
/* 393 */       if (domains == null) return "null";
/* 394 */       StringBuffer buffer = new StringBuffer();
/* 395 */       for (int i = domains.length - 1; i >= 0; i--)
/*     */       {
/* 397 */         int k = domains.length - 1 - i;
/* 398 */         while (k-- > 0) buffer.append("  ");
/* 399 */         buffer.append(domains[i].getCodeSource().getLocation());
/*     */         
/*     */ 
/*     */ 
/* 403 */         buffer.append("\n");
/*     */       }
/* 405 */       return buffer.toString();
/*     */     }
/*     */     
/*     */     public ProtectionDomain[] getCombinedDomains()
/*     */     {
/* 410 */       return this.combined;
/*     */     }
/*     */     
/*     */     private static class SubjectProtectionDomain extends ProtectionDomain
/*     */     {
/*     */       private final Subject subject;
/*     */       
/*     */       public SubjectProtectionDomain(CodeSource codesource, Subject subject)
/*     */       {
/* 419 */         super(null);
/* 420 */         this.subject = subject;
/*     */       }
/*     */       
/*     */       public boolean implies(Permission permission)
/*     */       {
/* 425 */         Policy policy = (Policy)AccessController.doPrivileged(new MX4JRemoteUtils.5(this));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 432 */         PermissionCollection permissions = policy.getPermissions(this.subject, getCodeSource());
/* 433 */         return permissions.implies(permission);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/remote/MX4JRemoteUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */