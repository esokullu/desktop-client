/*     */ package mx4j.remote;
/*     */ 
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NotificationTuple
/*     */ {
/*  21 */   private static final NotificationFilter NO_FILTER = new NotificationFilter()
/*     */   {
/*     */     public boolean isNotificationEnabled(Notification notification)
/*     */     {
/*  25 */       return true;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/*  30 */       return "no filter";
/*     */     }
/*     */   };
/*  33 */   private static final Object NO_HANDBACK = new Object()
/*     */   {
/*     */     public String toString()
/*     */     {
/*  37 */       return "no handback";
/*     */     }
/*     */   };
/*     */   
/*     */   private final ObjectName observed;
/*     */   private final NotificationListener listener;
/*     */   private final NotificationFilter filter;
/*     */   private final Object handback;
/*     */   private boolean invokeFilter;
/*     */   
/*     */   public NotificationTuple(ObjectName observed, NotificationListener listener)
/*     */   {
/*  49 */     this(observed, listener, NO_FILTER, NO_HANDBACK);
/*     */   }
/*     */   
/*     */   public NotificationTuple(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback)
/*     */   {
/*  54 */     this.observed = observed;
/*  55 */     this.listener = listener;
/*  56 */     this.filter = filter;
/*  57 */     this.handback = handback;
/*  58 */     this.invokeFilter = false;
/*     */   }
/*     */   
/*     */   public ObjectName getObjectName()
/*     */   {
/*  63 */     return this.observed;
/*     */   }
/*     */   
/*     */   public NotificationListener getNotificationListener()
/*     */   {
/*  68 */     return this.listener;
/*     */   }
/*     */   
/*     */   public Object getHandback()
/*     */   {
/*  73 */     if (this.handback == NO_HANDBACK) return null;
/*  74 */     return this.handback;
/*     */   }
/*     */   
/*     */   public NotificationFilter getNotificationFilter()
/*     */   {
/*  79 */     if (this.filter == NO_FILTER) return null;
/*  80 */     return this.filter;
/*     */   }
/*     */   
/*     */   public void setInvokeFilter(boolean invoke)
/*     */   {
/*  85 */     this.invokeFilter = invoke;
/*     */   }
/*     */   
/*     */   public boolean getInvokeFilter()
/*     */   {
/*  90 */     if (!this.invokeFilter) return false;
/*  91 */     NotificationFilter filter = getNotificationFilter();
/*  92 */     if (filter == null) return false;
/*  93 */     return true;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  98 */     if (this == obj) return true;
/*  99 */     if (!(obj instanceof NotificationTuple)) { return false;
/*     */     }
/* 101 */     NotificationTuple other = (NotificationTuple)obj;
/*     */     
/* 103 */     if (!this.observed.equals(other.observed)) return false;
/* 104 */     if (!this.listener.equals(other.listener)) { return false;
/*     */     }
/*     */     
/* 107 */     if (this.filter == NO_FILTER) return true;
/* 108 */     if (other.filter == NO_FILTER) { return true;
/*     */     }
/* 110 */     if (this.filter != null ? !this.filter.equals(other.filter) : other.filter != null) return false;
/* 111 */     if (this.handback != null ? !this.handback.equals(other.handback) : other.handback != null) { return false;
/*     */     }
/* 113 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 119 */     int result = this.observed.hashCode();
/* 120 */     result = 29 * result + this.listener.hashCode();
/* 121 */     result = 29 * result + (this.filter != null ? this.filter.hashCode() : 0);
/* 122 */     result = 29 * result + (this.handback != null ? this.handback.hashCode() : 0);
/* 123 */     return result;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 128 */     StringBuffer buffer = new StringBuffer("NotificationTuple [");
/* 129 */     buffer.append(this.observed).append(", ");
/* 130 */     buffer.append(this.listener).append(", ");
/* 131 */     buffer.append(this.filter).append(", ");
/* 132 */     buffer.append(this.handback).append("]");
/* 133 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/remote/NotificationTuple.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */