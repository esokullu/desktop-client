/*     */ package mx4j.remote;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.management.remote.JMXConnectorProvider;
/*     */ import javax.management.remote.JMXConnectorServerProvider;
/*     */ import javax.management.remote.JMXProviderException;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProviderFactory
/*     */   extends ProviderHelper
/*     */ {
/*     */   public static JMXConnectorProvider newJMXConnectorProvider(JMXServiceURL url, Map env)
/*     */     throws IOException
/*     */   {
/*  32 */     String protocol = normalizeProtocol(url.getProtocol());
/*  33 */     String providerPackages = findProviderPackageList(env, "jmx.remote.protocol.provider.pkgs");
/*  34 */     ClassLoader classLoader = findProviderClassLoader(env, "jmx.remote.protocol.provider.class.loader");
/*  35 */     JMXConnectorProvider provider = (JMXConnectorProvider)loadProvider(providerPackages, protocol, "ClientProvider", classLoader);
/*  36 */     return provider;
/*     */   }
/*     */   
/*     */   public static JMXConnectorServerProvider newJMXConnectorServerProvider(JMXServiceURL url, Map env)
/*     */     throws IOException
/*     */   {
/*  42 */     String protocol = normalizeProtocol(url.getProtocol());
/*  43 */     String providerPackages = findProviderPackageList(env, "jmx.remote.protocol.provider.pkgs");
/*  44 */     ClassLoader classLoader = findProviderClassLoader(env, "jmx.remote.protocol.provider.class.loader");
/*  45 */     JMXConnectorServerProvider provider = (JMXConnectorServerProvider)loadProvider(providerPackages, protocol, "ServerProvider", classLoader);
/*  46 */     return provider;
/*     */   }
/*     */   
/*     */   private static String findEnvironmentProviderPackageList(Map environment, String key) throws JMXProviderException
/*     */   {
/*  51 */     String providerPackages = null;
/*  52 */     if (environment != null)
/*     */     {
/*  54 */       Logger logger = getLogger();
/*  55 */       Object pkgs = environment.get(key);
/*  56 */       if (logger.isEnabledFor(10)) logger.debug("Provider packages in the environment: " + pkgs);
/*  57 */       if ((pkgs != null) && (!(pkgs instanceof String))) throw new JMXProviderException("Provider package list must be a string");
/*  58 */       providerPackages = (String)pkgs;
/*     */     }
/*  60 */     return providerPackages;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String findProviderPackageList(Map environment, String providerPkgsKey)
/*     */     throws JMXProviderException
/*     */   {
/*  69 */     String providerPackages = findEnvironmentProviderPackageList(environment, providerPkgsKey);
/*     */     
/*  71 */     if (providerPackages == null)
/*     */     {
/*  73 */       providerPackages = findSystemPackageList(providerPkgsKey);
/*     */     }
/*     */     
/*  76 */     if ((providerPackages != null) && (providerPackages.trim().length() == 0)) { throw new JMXProviderException("Provider package list cannot be an empty string");
/*     */     }
/*  78 */     if (providerPackages == null) {
/*  79 */       providerPackages = "mx4j.remote.provider|mx4j.tools.remote.provider";
/*     */     } else {
/*  81 */       providerPackages = providerPackages + "|mx4j.remote.provider|mx4j.tools.remote.provider";
/*     */     }
/*  83 */     Logger logger = getLogger();
/*  84 */     if (logger.isEnabledFor(10)) { logger.debug("Provider packages list is: " + providerPackages);
/*     */     }
/*  86 */     return providerPackages;
/*     */   }
/*     */   
/*     */   private static ClassLoader findProviderClassLoader(Map environment, String providerLoaderKey)
/*     */   {
/*  91 */     Logger logger = getLogger();
/*     */     
/*  93 */     ClassLoader classLoader = null;
/*  94 */     if (environment != null)
/*     */     {
/*  96 */       Object loader = environment.get(providerLoaderKey);
/*  97 */       if (logger.isEnabledFor(10)) logger.debug("Provider classloader in the environment: " + loader);
/*  98 */       if ((loader != null) && (!(loader instanceof ClassLoader))) throw new IllegalArgumentException("Provider classloader is not a ClassLoader");
/*  99 */       classLoader = (ClassLoader)loader;
/*     */     }
/*     */     
/* 102 */     if (classLoader == null)
/*     */     {
/* 104 */       classLoader = Thread.currentThread().getContextClassLoader();
/* 105 */       if (logger.isEnabledFor(10)) { logger.debug("Provider classloader in the environment: " + classLoader);
/*     */       }
/*     */     }
/*     */     
/* 109 */     environment.put("jmx.remote.protocol.provider.class.loader", classLoader);
/* 110 */     if (logger.isEnabledFor(0)) { logger.trace("Provider classloader added to the environment");
/*     */     }
/* 112 */     return classLoader;
/*     */   }
/*     */   
/*     */   private static Object loadProvider(String packages, String protocol, String className, ClassLoader loader) throws JMXProviderException, MalformedURLException
/*     */   {
/* 117 */     Logger logger = getLogger();
/*     */     
/* 119 */     StringTokenizer tokenizer = new StringTokenizer(packages, "|");
/* 120 */     String providerClassName; Class providerClass; for (;;) { if (!tokenizer.hasMoreTokens())
/*     */         break label315;
/* 122 */       String pkg = tokenizer.nextToken().trim();
/* 123 */       if (logger.isEnabledFor(10)) { logger.debug("Provider package: " + pkg);
/*     */       }
/*     */       
/* 126 */       if (pkg.length() == 0) { throw new JMXProviderException("Empty package list not allowed: " + packages);
/*     */       }
/* 128 */       providerClassName = constructClassName(pkg, protocol, className);
/*     */       
/* 130 */       providerClass = null;
/*     */       try
/*     */       {
/* 133 */         providerClass = loadClass(providerClassName, loader);
/*     */       }
/*     */       catch (ClassNotFoundException x)
/*     */       {
/* 137 */         if (logger.isEnabledFor(10)) { logger.debug("Provider class " + providerClassName + " not found, continuing with next package");
/*     */         }
/*     */       }
/*     */       catch (Exception x)
/*     */       {
/* 142 */         if (logger.isEnabledFor(0)) logger.trace("Cannot load provider class " + providerClassName, x);
/* 143 */         throw new JMXProviderException("Cannot load provider class " + providerClassName, x);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 148 */       return providerClass.newInstance();
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/* 152 */       if (logger.isEnabledFor(0)) logger.trace("Cannot instantiate provider class " + providerClassName, x);
/* 153 */       throw new JMXProviderException("Cannot instantiate provider class " + providerClassName, x);
/*     */     }
/*     */     
/*     */     label315:
/*     */     
/* 158 */     if (logger.isEnabledFor(10)) logger.debug("Could not find provider for protocol " + protocol + " in package list '" + packages + "'");
/* 159 */     throw new MalformedURLException("Could not find provider for protocol " + protocol + " in package list '" + packages + "'");
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/remote/ProviderFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */