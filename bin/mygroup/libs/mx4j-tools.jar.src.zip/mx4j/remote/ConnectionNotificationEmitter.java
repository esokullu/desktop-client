/*    */ package mx4j.remote;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.NotificationBroadcasterSupport;
/*    */ import javax.management.remote.JMXConnectionNotification;
/*    */ import javax.management.remote.JMXConnector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectionNotificationEmitter
/*    */   extends NotificationBroadcasterSupport
/*    */ {
/*    */   private static long sequenceNumber;
/*    */   private JMXConnector connector;
/*    */   
/*    */   public ConnectionNotificationEmitter(JMXConnector connector)
/*    */   {
/* 27 */     this.connector = connector;
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   private long getNextNotificationNumber()
/*    */   {
/*    */     // Byte code:
/*    */     //   0: getstatic 8	mx4j/remote/ConnectionNotificationEmitter:class$mx4j$remote$ConnectionNotificationEmitter	Ljava/lang/Class;
/*    */     //   3: ifnonnull +15 -> 18
/*    */     //   6: ldc 9
/*    */     //   8: invokestatic 10	mx4j/remote/ConnectionNotificationEmitter:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*    */     //   11: dup
/*    */     //   12: putstatic 8	mx4j/remote/ConnectionNotificationEmitter:class$mx4j$remote$ConnectionNotificationEmitter	Ljava/lang/Class;
/*    */     //   15: goto +6 -> 21
/*    */     //   18: getstatic 8	mx4j/remote/ConnectionNotificationEmitter:class$mx4j$remote$ConnectionNotificationEmitter	Ljava/lang/Class;
/*    */     //   21: dup
/*    */     //   22: astore_1
/*    */     //   23: monitorenter
/*    */     //   24: getstatic 11	mx4j/remote/ConnectionNotificationEmitter:sequenceNumber	J
/*    */     //   27: dup2
/*    */     //   28: lconst_1
/*    */     //   29: ladd
/*    */     //   30: putstatic 11	mx4j/remote/ConnectionNotificationEmitter:sequenceNumber	J
/*    */     //   33: aload_1
/*    */     //   34: monitorexit
/*    */     //   35: lreturn
/*    */     //   36: astore_2
/*    */     //   37: aload_1
/*    */     //   38: monitorexit
/*    */     //   39: aload_2
/*    */     //   40: athrow
/*    */     // Line number table:
/*    */     //   Java source line #32	-> byte code offset #0
/*    */     //   Java source line #34	-> byte code offset #24
/*    */     //   Java source line #35	-> byte code offset #36
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	41	0	this	ConnectionNotificationEmitter
/*    */     //   22	16	1	Ljava/lang/Object;	Object
/*    */     //   36	4	2	localObject1	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   24	35	36	finally
/*    */     //   36	39	36	finally
/*    */   }
/*    */   
/*    */   private String getConnectionId()
/*    */   {
/*    */     try
/*    */     {
/* 42 */       return this.connector.getConnectionId();
/*    */     }
/*    */     catch (IOException x) {}
/*    */     
/* 46 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public void sendConnectionNotificationOpened()
/*    */   {
/* 52 */     JMXConnectionNotification notification = new JMXConnectionNotification("jmx.remote.connection.opened", this.connector, getConnectionId(), getNextNotificationNumber(), "Connection opened", null);
/* 53 */     sendNotification(notification);
/*    */   }
/*    */   
/*    */   public void sendConnectionNotificationClosed()
/*    */   {
/* 58 */     JMXConnectionNotification notification = new JMXConnectionNotification("jmx.remote.connection.closed", this.connector, getConnectionId(), getNextNotificationNumber(), "Connection closed", null);
/* 59 */     sendNotification(notification);
/*    */   }
/*    */   
/*    */   public void sendConnectionNotificationFailed()
/*    */   {
/* 64 */     JMXConnectionNotification notification = new JMXConnectionNotification("jmx.remote.connection.failed", this.connector, getConnectionId(), getNextNotificationNumber(), "Connection failed", null);
/* 65 */     sendNotification(notification);
/*    */   }
/*    */   
/*    */   public void sendConnectionNotificationLost(long howMany)
/*    */   {
/* 70 */     JMXConnectionNotification notification = new JMXConnectionNotification("jmx.remote.connection.notifs.lost", this.connector, getConnectionId(), getNextNotificationNumber(), "Some notification (" + howMany + ") was lost", null);
/* 71 */     sendNotification(notification);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/remote/ConnectionNotificationEmitter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */