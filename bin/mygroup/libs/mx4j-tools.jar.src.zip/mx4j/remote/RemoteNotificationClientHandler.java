package mx4j.remote;

public abstract interface RemoteNotificationClientHandler
{
  public abstract void start();
  
  public abstract void stop();
  
  public abstract boolean contains(NotificationTuple paramNotificationTuple);
  
  public abstract void addNotificationListener(Integer paramInteger, NotificationTuple paramNotificationTuple);
  
  public abstract Integer[] getNotificationListeners(NotificationTuple paramNotificationTuple);
  
  public abstract Integer getNotificationListener(NotificationTuple paramNotificationTuple);
  
  public abstract void removeNotificationListeners(Integer[] paramArrayOfInteger);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/remote/RemoteNotificationClientHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */