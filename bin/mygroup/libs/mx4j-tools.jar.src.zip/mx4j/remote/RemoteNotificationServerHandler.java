package mx4j.remote;

import java.io.IOException;
import javax.management.NotificationFilter;
import javax.management.NotificationListener;
import javax.management.ObjectName;
import javax.management.remote.NotificationResult;

public abstract interface RemoteNotificationServerHandler
{
  public abstract Integer generateListenerID(ObjectName paramObjectName, NotificationFilter paramNotificationFilter);
  
  public abstract NotificationListener getServerNotificationListener();
  
  public abstract void addNotificationListener(Integer paramInteger, NotificationTuple paramNotificationTuple);
  
  public abstract NotificationTuple removeNotificationListener(Integer paramInteger);
  
  public abstract NotificationResult fetchNotifications(long paramLong1, int paramInt, long paramLong2)
    throws IOException;
  
  public abstract NotificationTuple[] close();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/remote/RemoteNotificationServerHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */