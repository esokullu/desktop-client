package mx4j.remote;

public abstract interface MX4JRemoteConstants
{
  public static final String PROVIDER_PACKAGES_SEPARATOR = "|";
  public static final String PROVIDER_PACKAGES = "mx4j.remote.provider|mx4j.tools.remote.provider";
  public static final String CLIENT_PROVIDER_CLASS = "ClientProvider";
  public static final String SERVER_PROVIDER_CLASS = "ServerProvider";
  public static final String PROTOCOL_RESOLVER_PACKAGES = "mx4j.remote.resolver.pkgs";
  public static final String RESOLVER_PACKAGES_SEPARATOR = "|";
  public static final String RESOLVER_PACKAGES = "mx4j.remote.resolver|mx4j.tools.remote.resolver";
  public static final String RESOLVER_CLASS = "Resolver";
  public static final String FETCH_NOTIFICATIONS_TIMEOUT = "jmx.remote.x.client.fetch.timeout";
  public static final String FETCH_NOTIFICATIONS_MAX_NUMBER = "jmx.remote.x.client.max.notifications";
  public static final String NOTIFICATION_BUFFER_CAPACITY = "jmx.remote.x.buffer.size";
  public static final String NOTIFICATION_PURGE_DISTANCE = "jmx.remote.x.notification.purge.distance";
  public static final String FETCH_NOTIFICATIONS_SLEEP = "jmx.remote.x.notification.fetch.sleep";
  public static final String CONNECTION_HEARTBEAT_PERIOD = "jmx.remote.x.connection.heartbeat.period";
  public static final String CONNECTION_HEARTBEAT_RETRIES = "jmx.remote.x.connection.heartbeat.retries";
  public static final String NOTIFICATION_QUEUE_CAPACITY = "jmx.remote.x.queue.size";
  public static final String HTTP_SERVER_CONFIGURATION = "jmx.remote.x.http.server.configuration";
  public static final String ENDPOINT_PROTOCOL = "jmx.remote.x.http.endpoint.protocol";
  public static final String AXIS_JSSE_SOCKET_FACTORY = "jmx.remote.x.https.axis.socket.factory";
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/remote/MX4JRemoteConstants.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */