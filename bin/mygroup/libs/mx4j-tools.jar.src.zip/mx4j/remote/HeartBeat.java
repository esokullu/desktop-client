package mx4j.remote;

import java.io.IOException;

public abstract interface HeartBeat
{
  public abstract void start()
    throws IOException;
  
  public abstract void stop()
    throws IOException;
  
  public abstract long getPulsePeriod();
  
  public abstract int getMaxRetries();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/remote/HeartBeat.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */