/*     */ package mx4j.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodTernaryTree
/*     */ {
/*     */   private Node m_root;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object get(String methodName, String[] signature)
/*     */   {
/*  38 */     if (signature == null)
/*     */     {
/*  40 */       throw new IllegalArgumentException();
/*     */     }
/*  42 */     return search(methodName, signature);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void put(String methodName, String[] signature, Object information)
/*     */   {
/*  52 */     if (signature == null)
/*     */     {
/*  54 */       throw new IllegalArgumentException();
/*     */     }
/*  56 */     this.m_root = insert(this.m_root, methodName, signature, signature.length, information);
/*     */   }
/*     */   
/*     */   private Object search(String methodName, String[] signature)
/*     */   {
/*  61 */     Node node = this.m_root;
/*  62 */     int index = 0;
/*  63 */     while (node != null)
/*     */     {
/*  65 */       Object key = index == 0 ? methodName : signature[(index - 1)];
/*  66 */       if (key == null)
/*     */       {
/*  68 */         throw new IllegalArgumentException();
/*     */       }
/*     */       
/*  71 */       int split = splitFunction(key);
/*  72 */       if (split < node.splitValue)
/*     */       {
/*  74 */         node = node.left;
/*     */       }
/*  76 */       else if (split == node.splitValue)
/*     */       {
/*  78 */         if (index == signature.length)
/*     */         {
/*     */ 
/*     */ 
/*  82 */           if (node.keys == null)
/*     */           {
/*  84 */             return null;
/*     */           }
/*  86 */           for (int i = 0; i < node.keys.length; i++)
/*     */           {
/*  88 */             if (node.keys[i].equals(key))
/*     */             {
/*  90 */               return node.values[i];
/*     */             }
/*     */           }
/*  93 */           return null;
/*     */         }
/*     */         
/*     */ 
/*  97 */         index++;
/*  98 */         node = node.middle;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 103 */         node = node.right;
/*     */       }
/*     */     }
/* 106 */     return null;
/*     */   }
/*     */   
/*     */   private Node insert(Node node, String methodName, String[] signature, int length, Object value)
/*     */   {
/* 111 */     Object key = methodName;
/* 112 */     if (key == null)
/*     */     {
/* 114 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 117 */     int split = splitFunction(key);
/* 118 */     if (node == null)
/*     */     {
/* 120 */       node = new Node(null);
/* 121 */       node.splitValue = split;
/*     */     }
/*     */     
/* 124 */     if (split < node.splitValue)
/*     */     {
/* 126 */       node.left = insert(node.left, methodName, signature, length, value);
/*     */     }
/* 128 */     else if (split == node.splitValue)
/*     */     {
/*     */ 
/*     */ 
/* 132 */       if (length == 0)
/*     */       {
/* 134 */         if (node.keys == null)
/*     */         {
/* 136 */           node.keys = new Object[1];
/* 137 */           node.values = new Object[1];
/* 138 */           node.keys[0] = key;
/* 139 */           node.values[0] = value;
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 144 */           boolean found = false;
/* 145 */           for (int i = 0; i < node.keys.length; i++)
/*     */           {
/* 147 */             if (node.keys[i].equals(key))
/*     */             {
/*     */ 
/* 150 */               node.keys[i] = key;
/* 151 */               node.values[i] = value;
/* 152 */               found = true;
/* 153 */               break;
/*     */             }
/*     */           }
/*     */           
/* 157 */           if (!found)
/*     */           {
/* 159 */             int len = node.keys.length;
/* 160 */             Object[] olds = node.keys;
/* 161 */             node.keys = new Object[len + 1];
/* 162 */             System.arraycopy(olds, 0, node.keys, 0, len);
/* 163 */             node.keys[len] = key;
/*     */             
/* 165 */             olds = node.values;
/* 166 */             node.values = new Object[len + 1];
/* 167 */             System.arraycopy(olds, 0, node.values, 0, len);
/* 168 */             node.values[len] = value;
/*     */           }
/*     */           
/*     */         }
/*     */       }
/*     */       else {
/* 174 */         node.middle = insert(node.middle, signature[(signature.length - length)], signature, length - 1, value);
/*     */       }
/*     */       
/*     */     }
/*     */     else {
/* 179 */       node.right = insert(node.right, methodName, signature, length, value);
/*     */     }
/*     */     
/* 182 */     return node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 187 */   protected int splitFunction(Object obj) { return obj.hashCode(); }
/*     */   
/*     */   private class Node { private Node() {}
/* 190 */     Node(MethodTernaryTree.1 x1) { this(); }
/*     */     
/*     */     private int splitValue;
/*     */     private Node right;
/*     */     private Node middle;
/*     */     private Node left;
/*     */     private Object[] keys;
/*     */     private Object[] values;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/util/MethodTernaryTree.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */