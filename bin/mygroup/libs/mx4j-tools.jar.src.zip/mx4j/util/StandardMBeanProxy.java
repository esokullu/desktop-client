/*     */ package mx4j.util;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.List;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MBeanServerFactory;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.RuntimeErrorException;
/*     */ import javax.management.RuntimeMBeanException;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ /**
/*     */  * @deprecated
/*     */  */
/*     */ public class StandardMBeanProxy
/*     */ {
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static Object create(Class mbeanInterface, ObjectName name)
/*     */   {
/*  61 */     return create(mbeanInterface, null, name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object create(Class mbeanInterface, MBeanServer server, ObjectName name)
/*     */   {
/*  77 */     if (mbeanInterface == null) throw new IllegalArgumentException("MBean interface cannot be null");
/*  78 */     if (!mbeanInterface.isInterface()) throw new IllegalArgumentException("Class parameter must be an interface");
/*  79 */     if (name == null) { throw new IllegalArgumentException("MBean name cannot be null");
/*     */     }
/*  81 */     if (server == null)
/*     */     {
/*  83 */       List list = MBeanServerFactory.findMBeanServer(null);
/*  84 */       if (list.size() > 0) {
/*  85 */         server = (MBeanServer)list.get(0);
/*     */       } else {
/*  87 */         throw new IllegalArgumentException("Cannot find MBeanServer");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  92 */     if (!server.isRegistered(name)) { throw new IllegalArgumentException("ObjectName " + name + " is not known to MBeanServer " + server);
/*     */     }
/*     */     
/*     */ 
/*  96 */     ClassLoader loader = mbeanInterface.getClassLoader();
/*  97 */     return Proxy.newProxyInstance(loader, new Class[] { mbeanInterface }, new LocalHandler(server, name, null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static abstract class Handler
/*     */     implements InvocationHandler
/*     */   {
/*     */     public Object invoke(Object proxy, Method method, Object[] args)
/*     */       throws Throwable
/*     */     {
/* 115 */       if (args == null) { args = new Object[0];
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 120 */       Class[] declared = method.getExceptionTypes();
/*     */       
/* 122 */       if (Utils.isAttributeSetter(method))
/*     */       {
/* 124 */         String name = method.getName().substring(3);
/* 125 */         Attribute attribute = new Attribute(name, args[0]);
/*     */         try
/*     */         {
/* 128 */           setAttribute(attribute);
/* 129 */           return null;
/*     */         }
/*     */         catch (Throwable x)
/*     */         {
/* 133 */           unwrapThrowable(x, declared);
/*     */         }
/*     */       }
/* 136 */       else if (Utils.isAttributeGetter(method))
/*     */       {
/* 138 */         String n = method.getName();
/* 139 */         String name = null;
/* 140 */         if (n.startsWith("is")) {
/* 141 */           name = n.substring(2);
/*     */         } else {
/* 143 */           name = n.substring(3);
/*     */         }
/*     */         try
/*     */         {
/* 147 */           return getAttribute(name);
/*     */         }
/*     */         catch (Throwable x)
/*     */         {
/* 151 */           unwrapThrowable(x, declared);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 156 */         Class[] parameters = method.getParameterTypes();
/* 157 */         String[] params = new String[parameters.length];
/* 158 */         for (int i = 0; i < parameters.length; i++)
/*     */         {
/* 160 */           params[i] = parameters[i].getName();
/*     */         }
/*     */         
/*     */         try
/*     */         {
/* 165 */           return invokeOperation(method.getName(), args, params);
/*     */         }
/*     */         catch (Throwable x)
/*     */         {
/* 169 */           unwrapThrowable(x, declared);
/*     */         }
/*     */       }
/*     */       
/* 173 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected abstract void setAttribute(Attribute paramAttribute)
/*     */       throws Exception;
/*     */     
/*     */ 
/*     */ 
/*     */     protected abstract Object getAttribute(String paramString)
/*     */       throws Exception;
/*     */     
/*     */ 
/*     */ 
/*     */     protected abstract Object invokeOperation(String paramString, Object[] paramArrayOfObject, String[] paramArrayOfString)
/*     */       throws Exception;
/*     */     
/*     */ 
/*     */ 
/*     */     protected void unwrapThrowable(Throwable x, Class[] declared)
/*     */       throws Throwable
/*     */     {
/* 197 */       if (declared != null)
/*     */       {
/*     */ 
/*     */ 
/* 201 */         for (int i = 0; i < declared.length; i++)
/*     */         {
/* 203 */           Class exception = declared[i];
/* 204 */           if (exception.isInstance(x)) { throw x;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 209 */       if ((x instanceof MBeanException))
/*     */       {
/* 211 */         unwrapThrowable(((MBeanException)x).getTargetException(), declared);
/*     */       }
/* 213 */       else if ((x instanceof ReflectionException))
/*     */       {
/* 215 */         unwrapThrowable(((ReflectionException)x).getTargetException(), declared);
/*     */       }
/* 217 */       else if ((x instanceof RuntimeOperationsException))
/*     */       {
/* 219 */         unwrapThrowable(((RuntimeOperationsException)x).getTargetException(), declared);
/*     */       }
/* 221 */       else if ((x instanceof RuntimeMBeanException))
/*     */       {
/* 223 */         unwrapThrowable(((RuntimeMBeanException)x).getTargetException(), declared);
/*     */       }
/* 225 */       else if ((x instanceof RuntimeErrorException))
/*     */       {
/* 227 */         unwrapThrowable(((RuntimeErrorException)x).getTargetError(), declared);
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 234 */         throw x; } } }
/*     */   
/*     */   private static class LocalHandler extends StandardMBeanProxy.Handler { private MBeanServer m_server;
/*     */     private ObjectName m_name;
/*     */     
/* 239 */     LocalHandler(MBeanServer x0, ObjectName x1, StandardMBeanProxy.1 x2) { this(x0, x1); }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private LocalHandler(MBeanServer server, ObjectName name)
/*     */     {
/* 246 */       this.m_server = server;
/* 247 */       this.m_name = name;
/*     */     }
/*     */     
/*     */     protected void setAttribute(Attribute attribute) throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException
/*     */     {
/* 252 */       this.m_server.setAttribute(this.m_name, attribute);
/*     */     }
/*     */     
/*     */     protected Object getAttribute(String attribute) throws InstanceNotFoundException, AttributeNotFoundException, MBeanException, ReflectionException
/*     */     {
/* 257 */       return this.m_server.getAttribute(this.m_name, attribute);
/*     */     }
/*     */     
/*     */     protected Object invokeOperation(String method, Object[] args, String[] params) throws InstanceNotFoundException, MBeanException, ReflectionException
/*     */     {
/* 262 */       return this.m_server.invoke(this.m_name, method, args, params);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/util/StandardMBeanProxy.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */