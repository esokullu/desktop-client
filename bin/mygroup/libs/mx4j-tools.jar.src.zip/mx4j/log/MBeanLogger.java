/*    */ package mx4j.log;
/*    */ 
/*    */ import javax.management.MBeanException;
/*    */ import javax.management.MBeanInfo;
/*    */ import javax.management.MBeanOperationInfo;
/*    */ import javax.management.MBeanParameterInfo;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.ObjectName;
/*    */ import javax.management.ServiceNotFoundException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanLogger
/*    */   extends Logger
/*    */ {
/*    */   private MBeanServer m_server;
/*    */   private ObjectName m_name;
/*    */   
/*    */   public MBeanLogger(MBeanServer server, ObjectName objectName)
/*    */     throws MBeanException
/*    */   {
/* 36 */     if (server == null)
/*    */     {
/* 38 */       throw new MBeanException(new IllegalArgumentException("MBeanServer cannot be null"));
/*    */     }
/* 40 */     if (objectName == null)
/*    */     {
/* 42 */       throw new MBeanException(new IllegalArgumentException("ObjectName cannot be null"));
/*    */     }
/*    */     
/* 45 */     this.m_server = server;
/* 46 */     this.m_name = objectName;
/*    */     
/* 48 */     boolean found = false;
/*    */     try
/*    */     {
/* 51 */       MBeanInfo info = this.m_server.getMBeanInfo(this.m_name);
/* 52 */       MBeanOperationInfo[] opers = info.getOperations();
/* 53 */       if (opers != null)
/*    */       {
/* 55 */         for (int i = 0; i < opers.length; i++)
/*    */         {
/* 57 */           MBeanOperationInfo oper = opers[i];
/* 58 */           if (oper.getName().equals("log"))
/*    */           {
/* 60 */             MBeanParameterInfo[] params = oper.getSignature();
/* 61 */             if (params.length == 3)
/*    */             {
/* 63 */               if ((params[0].getType().equals("int")) && (params[1].getType().equals("java.lang.Object")) && (params[2].getType().equals("java.lang.Throwable")))
/*    */               {
/*    */ 
/*    */ 
/* 67 */                 found = true;
/* 68 */                 break;
/*    */               }
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception x)
/*    */     {
/* 77 */       x.printStackTrace();
/*    */     }
/* 79 */     if (!found)
/*    */     {
/* 81 */       throw new MBeanException(new ServiceNotFoundException("MBean does not have an operation log(int,Object,Throwable)"));
/*    */     }
/*    */   }
/*    */   
/*    */   protected void log(int priority, Object message, Throwable t)
/*    */   {
/*    */     try
/*    */     {
/* 89 */       this.m_server.invoke(this.m_name, "log", new Object[] { new Integer(priority), message, t }, new String[] { "int", "java.lang.Object", "java.lang.Throwable" });
/*    */     }
/*    */     catch (Exception x)
/*    */     {
/* 93 */       x.printStackTrace();
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/log/MBeanLogger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */