/*     */ package mx4j.log;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Log
/*     */ {
/*     */   private static Logger m_prototype;
/*  37 */   private static Map m_prototypeMap = new HashMap();
/*  38 */   private static Map m_loggerCache = new HashMap();
/*     */   
/*     */   private static int m_defaultPriority;
/*     */   
/*     */   static
/*     */   {
/*  44 */     String priority = (String)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public Object run()
/*     */       {
/*  48 */         return System.getProperty("mx4j.log.priority");
/*     */       }
/*     */     });
/*  51 */     if ("trace".equalsIgnoreCase(priority))
/*     */     {
/*  53 */       m_defaultPriority = 0;
/*     */     }
/*  55 */     else if ("debug".equalsIgnoreCase(priority))
/*     */     {
/*  57 */       m_defaultPriority = 10;
/*     */     }
/*  59 */     else if ("info".equalsIgnoreCase(priority))
/*     */     {
/*  61 */       m_defaultPriority = 20;
/*     */     }
/*  63 */     else if ("warn".equalsIgnoreCase(priority))
/*     */     {
/*  65 */       m_defaultPriority = 30;
/*     */     }
/*  67 */     else if ("error".equalsIgnoreCase(priority))
/*     */     {
/*  69 */       m_defaultPriority = 40;
/*     */     }
/*  71 */     else if ("fatal".equalsIgnoreCase(priority))
/*     */     {
/*  73 */       m_defaultPriority = 50;
/*     */     }
/*     */     else
/*     */     {
/*  77 */       m_defaultPriority = 20;
/*     */     }
/*     */     
/*  80 */     String prototype = (String)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public Object run()
/*     */       {
/*  84 */         return System.getProperty("mx4j.log.prototype");
/*     */       }
/*     */     });
/*  87 */     if ((prototype != null) && (prototype.trim().length() > 0))
/*     */     {
/*     */       try
/*     */       {
/*  91 */         ClassLoader cl = Thread.currentThread().getContextClassLoader();
/*  92 */         Class cls = cl.loadClass(prototype);
/*  93 */         redirectTo((Logger)cls.newInstance());
/*     */       }
/*     */       catch (Exception x)
/*     */       {
/*  97 */         x.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setDefaultPriority(int priority)
/*     */   {
/* 115 */     switch (priority)
/*     */     {
/*     */     case 0: 
/* 118 */       m_defaultPriority = 0;
/* 119 */       break;
/*     */     case 10: 
/* 121 */       m_defaultPriority = 10;
/* 122 */       break;
/*     */     case 20: 
/* 124 */       m_defaultPriority = 20;
/* 125 */       break;
/*     */     case 30: 
/* 127 */       m_defaultPriority = 30;
/* 128 */       break;
/*     */     case 40: 
/* 130 */       m_defaultPriority = 40;
/* 131 */       break;
/*     */     case 50: 
/* 133 */       m_defaultPriority = 50;
/* 134 */       break;
/*     */     default: 
/* 136 */       m_defaultPriority = 30;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getDefaultPriority()
/*     */   {
/* 148 */     return m_defaultPriority;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Logger getLogger(String category)
/*     */   {
/* 159 */     if (category == null)
/*     */     {
/* 161 */       throw new RuntimeOperationsException(new IllegalArgumentException("Category cannot be null"));
/*     */     }
/*     */     
/* 164 */     synchronized (m_loggerCache)
/*     */     {
/* 166 */       Logger logger = (Logger)m_loggerCache.get(category);
/* 167 */       if (logger == null)
/*     */       {
/*     */ 
/* 170 */         Logger prototype = null;
/* 171 */         synchronized (m_prototypeMap)
/*     */         {
/* 173 */           prototype = (Logger)m_prototypeMap.get(category);
/*     */         }
/* 175 */         if (prototype == null)
/*     */         {
/*     */ 
/* 178 */           if (m_prototype != null)
/*     */           {
/* 180 */             logger = createLogger(m_prototype, category);
/*     */           }
/*     */           else
/*     */           {
/* 184 */             logger = createLogger(null, category);
/*     */           }
/*     */           
/*     */         }
/*     */         else {
/* 189 */           logger = createLogger(prototype, category);
/*     */         }
/*     */         
/*     */ 
/* 193 */         m_loggerCache.put(category, logger);
/*     */       }
/* 195 */       return logger;
/*     */     }
/*     */   }
/*     */   
/*     */   private static Logger createLogger(Logger prototype, String category)
/*     */   {
/* 201 */     Logger logger = null;
/*     */     try
/*     */     {
/* 204 */       logger = prototype == null ? new Logger() : (Logger)prototype.getClass().newInstance();
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/* 208 */       x.printStackTrace();
/* 209 */       logger = new Logger();
/*     */     }
/* 211 */     logger.setCategory(category);
/* 212 */     logger.setPriority(m_defaultPriority);
/* 213 */     return logger;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void redirectTo(Logger prototype)
/*     */   {
/* 224 */     m_prototype = prototype;
/*     */     
/*     */ 
/* 227 */     synchronized (m_loggerCache)
/*     */     {
/* 229 */       m_loggerCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void redirectTo(Logger prototype, String category)
/*     */   {
/* 244 */     if (category == null)
/*     */     {
/* 246 */       throw new RuntimeOperationsException(new IllegalArgumentException("Category cannot be null"));
/*     */     }
/*     */     
/* 249 */     if (prototype == null)
/*     */     {
/*     */ 
/* 252 */       synchronized (m_prototypeMap)
/*     */       {
/* 254 */         m_prototypeMap.remove(category);
/*     */       }
/*     */       
/*     */ 
/* 258 */       synchronized (m_loggerCache)
/*     */       {
/* 260 */         m_loggerCache.remove(category);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 266 */     synchronized (m_prototypeMap)
/*     */     {
/* 268 */       m_prototypeMap.put(category, prototype);
/*     */     }
/*     */     
/*     */ 
/* 272 */     synchronized (m_loggerCache)
/*     */     {
/* 274 */       m_loggerCache.remove(category);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/log/Log.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */