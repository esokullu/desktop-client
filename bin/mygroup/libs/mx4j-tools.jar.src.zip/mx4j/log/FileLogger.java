package mx4j.log;

public class FileLogger
  extends Logger
{
  public FileLogger(String location) {}
  
  protected void log(int priority, Object message, Throwable t) {}
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/log/FileLogger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */