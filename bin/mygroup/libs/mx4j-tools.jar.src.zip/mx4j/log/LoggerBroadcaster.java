/*     */ package mx4j.log;
/*     */ 
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.MBeanRegistration;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationBroadcasterSupport;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggerBroadcaster
/*     */   extends NotificationBroadcasterSupport
/*     */   implements MBeanRegistration, LoggerBroadcasterMBean
/*     */ {
/*     */   private long m_sequence;
/*     */   private boolean m_registered;
/*     */   private int m_recursionLevel;
/*     */   
/*     */   public ObjectName preRegister(MBeanServer server, ObjectName name)
/*     */     throws Exception
/*     */   {
/*  38 */     return name;
/*     */   }
/*     */   
/*     */   public void postRegister(Boolean registrationDone)
/*     */   {
/*  43 */     if (!registrationDone.booleanValue())
/*     */     {
/*  45 */       return;
/*     */     }
/*  47 */     this.m_registered = true;
/*     */   }
/*     */   
/*     */   public void preDeregister()
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */   public void postDeregister()
/*     */   {
/*  56 */     this.m_registered = false;
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback)
/*     */     throws ListenerNotFoundException
/*     */   {
/*  62 */     super.removeNotificationListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sendNotification(Notification n)
/*     */   {
/*  73 */     int maxRecursionLevel = 1;
/*  74 */     synchronized (this)
/*     */     {
/*  76 */       if (this.m_recursionLevel < maxRecursionLevel)
/*     */       {
/*  78 */         this.m_recursionLevel += 1;
/*  79 */         super.sendNotification(n);
/*  80 */         this.m_recursionLevel -= 1;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void start()
/*     */   {
/*  87 */     Logger logger = createLoggerPrototype();
/*  88 */     Log.redirectTo(logger);
/*     */   }
/*     */   
/*     */   public void start(String category)
/*     */   {
/*  93 */     Logger logger = createLoggerPrototype();
/*  94 */     Log.redirectTo(logger, category);
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/*  99 */     Log.redirectTo(null);
/*     */   }
/*     */   
/*     */   public void stop(String category)
/*     */   {
/* 104 */     Log.redirectTo(null, category);
/*     */   }
/*     */   
/*     */   private boolean isRegistered()
/*     */   {
/* 109 */     return this.m_registered;
/*     */   }
/*     */   
/*     */   public MBeanNotificationInfo[] getNotificationInfo()
/*     */   {
/* 114 */     String[] types = { "mx4j.logger.trace", "mx4j.logger.debug", "mx4j.logger.info", "mx4j.logger.warn", "mx4j.logger.error", "mx4j.logger.fatal" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */     MBeanNotificationInfo notifs = new MBeanNotificationInfo(types, "javax.management.Notification", "MX4J Logger MBean notifications");
/* 121 */     return new MBeanNotificationInfo[] { notifs };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 126 */   protected Logger createLoggerPrototype() { return new LoggerNotifier(this, null); }
/*     */   
/*     */   public static class LoggerNotifier extends Logger {
/* 129 */     LoggerNotifier(LoggerBroadcaster x0, LoggerBroadcaster.1 x1) { this(x0); }
/*     */     
/*     */ 
/*     */ 
/*     */     private LoggerNotifier(LoggerBroadcaster mbean)
/*     */     {
/* 135 */       m_loggerBroadcaster = mbean;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private static LoggerBroadcaster m_loggerBroadcaster;
/*     */     
/*     */ 
/*     */     protected void log(int priority, Object message, Throwable t)
/*     */     {
/* 145 */       notify(priority, message, t);
/*     */     }
/*     */     
/*     */     private void notify(int priority, Object message, Throwable t)
/*     */     {
/* 150 */       if (m_loggerBroadcaster.isRegistered())
/*     */       {
/* 152 */         long sequence = 0L;
/* 153 */         synchronized (this)
/*     */         {
/* 155 */           sequence = LoggerBroadcaster.access$204(m_loggerBroadcaster);
/*     */         }
/*     */         
/* 158 */         String type = null;
/* 159 */         switch (priority)
/*     */         {
/*     */         case 0: 
/* 162 */           type = "mx4j.logger.trace";
/* 163 */           break;
/*     */         case 10: 
/* 165 */           type = "mx4j.logger.debug";
/* 166 */           break;
/*     */         case 20: 
/* 168 */           type = "mx4j.logger.info";
/* 169 */           break;
/*     */         case 30: 
/* 171 */           type = "mx4j.logger.warn";
/* 172 */           break;
/*     */         case 40: 
/* 174 */           type = "mx4j.logger.error";
/* 175 */           break;
/*     */         case 50: 
/* 177 */           type = "mx4j.logger.fatal";
/* 178 */           break;
/*     */         default: 
/* 180 */           type = "mx4j.logger." + priority;
/*     */         }
/*     */         
/*     */         
/* 184 */         String msg = message == null ? "" : message.toString();
/*     */         
/*     */ 
/* 187 */         Notification n = new Notification(type, this, sequence, msg);
/* 188 */         if (t != null)
/*     */         {
/* 190 */           n.setUserData(t);
/*     */         }
/*     */         
/* 193 */         m_loggerBroadcaster.sendNotification(n);
/*     */       }
/*     */     }
/*     */     
/*     */     public LoggerNotifier() {}
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/log/LoggerBroadcaster.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */