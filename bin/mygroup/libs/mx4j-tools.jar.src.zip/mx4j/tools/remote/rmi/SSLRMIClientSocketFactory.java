/*    */ package mx4j.tools.remote.rmi;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Serializable;
/*    */ import java.net.Socket;
/*    */ import java.rmi.server.RMIClientSocketFactory;
/*    */ import javax.net.SocketFactory;
/*    */ import javax.net.ssl.SSLSocketFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SSLRMIClientSocketFactory
/*    */   implements RMIClientSocketFactory, Serializable
/*    */ {
/*    */   public Socket createSocket(String host, int port)
/*    */     throws IOException
/*    */   {
/* 24 */     return SSLSocketFactory.getDefault().createSocket(host, port);
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 29 */     if (obj == null) return false;
/* 30 */     if (this == obj) return true;
/* 31 */     return getClass() == obj.getClass();
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 36 */     return 13;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/rmi/SSLRMIClientSocketFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */