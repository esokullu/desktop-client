/*    */ package mx4j.tools.remote.rmi;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.ServerSocket;
/*    */ import java.rmi.server.RMIServerSocketFactory;
/*    */ import javax.net.ssl.SSLContext;
/*    */ import javax.net.ssl.SSLServerSocketFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SSLRMIServerSocketFactory
/*    */   implements RMIServerSocketFactory
/*    */ {
/*    */   private final SSLContext sslContext;
/*    */   private final int backlog;
/*    */   
/*    */   public SSLRMIServerSocketFactory(SSLContext sslContext)
/*    */   {
/* 27 */     this(sslContext, 50);
/*    */   }
/*    */   
/*    */   public SSLRMIServerSocketFactory(SSLContext sslContext, int backlog)
/*    */   {
/* 32 */     this.sslContext = sslContext;
/* 33 */     this.backlog = backlog;
/*    */   }
/*    */   
/*    */   public ServerSocket createServerSocket(int port) throws IOException
/*    */   {
/* 38 */     SSLServerSocketFactory factory = this.sslContext.getServerSocketFactory();
/* 39 */     return factory.createServerSocket(port, this.backlog);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/rmi/SSLRMIServerSocketFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */