package mx4j.tools.remote;

import java.io.IOException;

public abstract interface ConnectionManager
{
  public abstract Connection connect(Object paramObject)
    throws IOException, SecurityException;
  
  public abstract String getProtocol();
  
  public abstract void close()
    throws IOException;
  
  public abstract void closeConnection(Connection paramConnection)
    throws IOException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/ConnectionManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */