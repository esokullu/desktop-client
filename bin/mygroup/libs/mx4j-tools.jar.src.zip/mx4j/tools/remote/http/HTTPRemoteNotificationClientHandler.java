/*    */ package mx4j.tools.remote.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.management.remote.NotificationResult;
/*    */ import mx4j.remote.AbstractRemoteNotificationClientHandler;
/*    */ import mx4j.remote.ConnectionNotificationEmitter;
/*    */ import mx4j.remote.HeartBeat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTTPRemoteNotificationClientHandler
/*    */   extends AbstractRemoteNotificationClientHandler
/*    */ {
/*    */   private final HTTPConnection connection;
/*    */   
/*    */   public HTTPRemoteNotificationClientHandler(HTTPConnection connection, ConnectionNotificationEmitter emitter, HeartBeat heartbeat, Map environment)
/*    */   {
/* 28 */     super(emitter, heartbeat, environment);
/* 29 */     this.connection = connection;
/*    */   }
/*    */   
/*    */   protected NotificationResult fetchNotifications(long sequence, int maxNumber, long timeout) throws IOException
/*    */   {
/* 34 */     return this.connection.fetchNotifications(sequence, maxNumber, timeout);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/HTTPRemoteNotificationClientHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */