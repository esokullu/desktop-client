/*     */ package mx4j.tools.remote.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import mx4j.remote.ConnectionResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HTTPResolver
/*     */   extends ConnectionResolver
/*     */ {
/*  20 */   private static Map webContainers = new HashMap();
/*  21 */   private static Map deployedURLs = new HashMap();
/*  22 */   private static final WebContainer EXTERNAL_WEB_CONTAINER = new ExternalWebContainer();
/*     */   
/*     */   public Object bindClient(Object client, Map environment) throws IOException
/*     */   {
/*  26 */     return client;
/*     */   }
/*     */   
/*     */   protected String getEndpoint(JMXServiceURL address, Map environment)
/*     */   {
/*  31 */     String transport = getEndpointProtocol(environment);
/*  32 */     return transport + getEndpointPath(address);
/*     */   }
/*     */   
/*     */   protected String getEndpointProtocol(Map environment)
/*     */   {
/*  37 */     if (environment.containsKey("jmx.remote.x.http.endpoint.protocol")) {
/*  38 */       return (String)environment.get("jmx.remote.x.http.endpoint.protocol");
/*     */     }
/*  40 */     return "http";
/*     */   }
/*     */   
/*     */   private String getEndpointPath(JMXServiceURL url)
/*     */   {
/*  45 */     String address = url.toString();
/*  46 */     String prefix = "service:jmx:" + url.getProtocol();
/*  47 */     return address.substring(prefix.length());
/*     */   }
/*     */   
/*     */   public Object createServer(JMXServiceURL url, Map environment) throws IOException
/*     */   {
/*  52 */     WebContainer result = null;
/*  53 */     boolean useExternalWebContainer = environment == null ? false : Boolean.valueOf(String.valueOf(environment.get("jmx.remote.x.http.use.external.web.container"))).booleanValue();
/*  54 */     if (!useExternalWebContainer)
/*     */     {
/*     */ 
/*  57 */       String webContainerClassName = environment == null ? null : (String)environment.get("jmx.remote.x.http.embedded.web.container.class");
/*     */       
/*  59 */       if ((webContainerClassName == null) || (webContainerClassName.length() == 0)) { webContainerClassName = "mx4j.tools.remote.http.jetty.JettyWebContainer";
/*     */       }
/*  61 */       result = findWebContainer(url, webContainerClassName);
/*  62 */       if (result == null)
/*     */       {
/*  64 */         result = createWebContainer(url, webContainerClassName, environment);
/*  65 */         if (result != null) { result.start(url, environment);
/*     */         }
/*     */       }
/*     */       
/*  69 */       if (result == null) throw new IOException("Could not start embedded web container");
/*     */     }
/*  71 */     return result;
/*     */   }
/*     */   
/*     */   private WebContainer findWebContainer(JMXServiceURL url, String webContainerClassName)
/*     */   {
/*  76 */     String key = createWebContainerKey(url, webContainerClassName);
/*  77 */     return (WebContainer)webContainers.get(key);
/*     */   }
/*     */   
/*     */   private String createWebContainerKey(JMXServiceURL url, String webContainerClassName)
/*     */   {
/*  82 */     return webContainerClassName + "|" + url.getHost() + "|" + url.getPort();
/*     */   }
/*     */   
/*     */   public JMXServiceURL bindServer(Object server, JMXServiceURL url, Map environment) throws IOException
/*     */   {
/*  87 */     WebContainer webContainer = (WebContainer)server;
/*  88 */     if (!isDeployed(webContainer, url))
/*     */     {
/*  90 */       if (webContainer != null) webContainer.deploy(getServletClassName(), url, environment);
/*  91 */       if (!hasDeployed(webContainer))
/*     */       {
/*     */ 
/*  94 */         deploy(url, environment);
/*     */       }
/*  96 */       addDeployed(webContainer, url);
/*     */     }
/*  98 */     return url;
/*     */   }
/*     */   
/*     */   protected abstract String getServletClassName();
/*     */   
/*     */   protected void deploy(JMXServiceURL address, Map environment)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */   public void unbindServer(Object server, JMXServiceURL address, Map environment) throws IOException
/*     */   {
/* 109 */     WebContainer webContainer = (WebContainer)server;
/* 110 */     if (isDeployed(webContainer, address))
/*     */     {
/*     */ 
/* 113 */       removeDeployed(webContainer, address);
/* 114 */       if (!hasDeployed(webContainer))
/*     */       {
/* 116 */         undeploy(address, environment);
/*     */       }
/* 118 */       if (webContainer != null) webContainer.undeploy(getServletClassName(), address, environment);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void undeploy(JMXServiceURL address, Map environment)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */   public void destroyServer(Object server, JMXServiceURL url, Map environment) throws IOException
/*     */   {
/* 128 */     WebContainer webContainer = (WebContainer)server;
/* 129 */     if ((webContainer != null) && (!hasDeployed(webContainer)))
/*     */     {
/*     */ 
/* 132 */       String key = createWebContainerKey(url, server.getClass().getName());
/* 133 */       WebContainer container = (WebContainer)webContainers.remove(key);
/* 134 */       if (webContainer != container) throw new IOException("Trying to stop the wrong web container: " + server + " should be: " + container);
/* 135 */       webContainer.stop();
/*     */     }
/*     */   }
/*     */   
/*     */   private WebContainer createWebContainer(JMXServiceURL url, String webContainerClassName, Map environment)
/*     */   {
/* 141 */     ClassLoader loader = Thread.currentThread().getContextClassLoader();
/* 142 */     if (environment != null)
/*     */     {
/* 144 */       Object cl = environment.get("jmx.remote.protocol.provider.class.loader");
/* 145 */       if ((cl instanceof ClassLoader)) { loader = (ClassLoader)cl;
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 150 */       WebContainer webContainer = (WebContainer)loader.loadClass(webContainerClassName).newInstance();
/* 151 */       String key = createWebContainerKey(url, webContainerClassName);
/* 152 */       webContainers.put(key, webContainer);
/* 153 */       return webContainer;
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/*     */ 
/* 158 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isDeployed(WebContainer webContainer, JMXServiceURL url)
/*     */   {
/* 163 */     if (webContainer == null) webContainer = EXTERNAL_WEB_CONTAINER;
/* 164 */     Set urls = (Set)deployedURLs.get(webContainer);
/* 165 */     if (urls == null) return false;
/* 166 */     return urls.contains(url);
/*     */   }
/*     */   
/*     */   private boolean hasDeployed(WebContainer webContainer)
/*     */   {
/* 171 */     if (webContainer == null) webContainer = EXTERNAL_WEB_CONTAINER;
/* 172 */     Set urls = (Set)deployedURLs.get(webContainer);
/* 173 */     if (urls == null) return false;
/* 174 */     return !urls.isEmpty();
/*     */   }
/*     */   
/*     */   private void addDeployed(WebContainer webContainer, JMXServiceURL url)
/*     */   {
/* 179 */     if (webContainer == null) webContainer = EXTERNAL_WEB_CONTAINER;
/* 180 */     Set urls = (Set)deployedURLs.get(webContainer);
/* 181 */     if (urls == null)
/*     */     {
/* 183 */       urls = new HashSet();
/* 184 */       deployedURLs.put(webContainer, urls);
/*     */     }
/* 186 */     urls.add(url);
/*     */   }
/*     */   
/*     */   private void removeDeployed(WebContainer webContainer, JMXServiceURL url)
/*     */   {
/* 191 */     if (webContainer == null) webContainer = EXTERNAL_WEB_CONTAINER;
/* 192 */     Set urls = (Set)deployedURLs.get(webContainer);
/* 193 */     if (urls != null)
/*     */     {
/* 195 */       urls.remove(url);
/* 196 */       if (urls.isEmpty()) { deployedURLs.remove(webContainer);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ExternalWebContainer
/*     */     implements WebContainer
/*     */   {
/*     */     public void start(JMXServiceURL url, Map environment)
/*     */       throws IOException
/*     */     {}
/*     */     
/*     */     public void stop()
/*     */       throws IOException
/*     */     {}
/*     */     
/*     */     public void deploy(String servletClassName, JMXServiceURL url, Map environment)
/*     */       throws IOException
/*     */     {}
/*     */     
/*     */     public void undeploy(String servletClassName, JMXServiceURL url, Map environment) {}
/*     */     
/*     */     public String toString()
/*     */     {
/* 220 */       return "External WebContainer";
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/HTTPResolver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */