/*     */ package mx4j.tools.remote.http.jetty;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import mx4j.tools.remote.http.WebContainer;
/*     */ import org.mortbay.http.HttpListener;
/*     */ import org.mortbay.http.PathMap;
/*     */ import org.mortbay.jetty.Server;
/*     */ import org.mortbay.jetty.servlet.ServletHandler;
/*     */ import org.mortbay.jetty.servlet.ServletHttpContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JettyWebContainer
/*     */   implements WebContainer
/*     */ {
/*     */   private final Server server;
/*     */   
/*     */   public JettyWebContainer()
/*     */   {
/*  35 */     this.server = new Server();
/*     */   }
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/*  40 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */   
/*     */   public void start(JMXServiceURL url, Map environment)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  48 */       configure(url, environment);
/*  49 */       this.server.start();
/*     */     }
/*     */     catch (IOException x)
/*     */     {
/*  53 */       throw x;
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/*  57 */       throw new IOException(x.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private void configure(JMXServiceURL url, Map environment) throws IOException
/*     */   {
/*  63 */     Logger logger = getLogger();
/*     */     
/*  65 */     if (environment != null)
/*     */     {
/*  67 */       Object config = environment.get("jmx.remote.x.http.server.configuration");
/*  68 */       if ((config instanceof String))
/*     */       {
/*  70 */         if (logger.isEnabledFor(10)) logger.debug("Configuring Jetty with configuration " + config);
/*  71 */         this.server.configure((String)config);
/*     */         
/*     */ 
/*  74 */         HttpListener[] listeners = this.server.getListeners();
/*  75 */         if (listeners != null)
/*     */         {
/*  77 */           boolean found = false;
/*  78 */           for (int i = 0; i < listeners.length; i++)
/*     */           {
/*  80 */             HttpListener listener = listeners[i];
/*  81 */             if (listener.getPort() == url.getPort())
/*     */             {
/*  83 */               found = true;
/*  84 */               break;
/*     */             }
/*     */           }
/*  87 */           if (!found) { throw new IOException("No listener configured with configuration " + config + " matches JMXServiceURL " + url);
/*     */           }
/*  89 */           if (logger.isEnabledFor(10)) logger.debug("Configured Jetty successfully with configuration " + config);
/*  90 */           return;
/*     */         }
/*     */         
/*     */ 
/*  94 */         if (logger.isEnabledFor(10)) { logger.debug("Jetty configuration " + config + " does not have any listener");
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*  99 */       else if (logger.isEnabledFor(10)) { logger.debug("Skipping Jetty configuration " + config + " (must be a String)");
/*     */       }
/*     */     }
/*     */     
/* 103 */     if (logger.isEnabledFor(10)) logger.debug("Configuring Jetty with a default listener on port " + url.getPort());
/* 104 */     this.server.addListener(":" + url.getPort());
/*     */   }
/*     */   
/*     */   public void stop() throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 111 */       this.server.stop();
/*     */     }
/*     */     catch (InterruptedException x)
/*     */     {
/* 115 */       Thread.currentThread().interrupt();
/*     */     }
/*     */   }
/*     */   
/*     */   public void deploy(String servletClassName, JMXServiceURL url, Map environment) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 123 */       String urlPattern = resolveServletMapping(url);
/* 124 */       ServletHttpContext context = (ServletHttpContext)this.server.getContext("/");
/* 125 */       context.addServlet(urlPattern, servletClassName);
/*     */       
/* 127 */       if (!context.isStarted()) context.start();
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/* 131 */       throw new IOException(x.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   public void undeploy(String servletName, JMXServiceURL url, Map environment)
/*     */   {
/* 137 */     String urlPattern = resolveServletMapping(url);
/* 138 */     ServletHttpContext context = (ServletHttpContext)this.server.getContext("/");
/* 139 */     ServletHandler handler = context.getServletHandler();
/* 140 */     handler.getServletMap().remove(urlPattern);
/*     */   }
/*     */   
/*     */   private String resolveServletMapping(JMXServiceURL url)
/*     */   {
/* 145 */     String path = url.getURLPath();
/* 146 */     String urlPattern = null;
/* 147 */     if (path.endsWith("/")) {
/* 148 */       urlPattern = path + "*";
/*     */     } else
/* 150 */       urlPattern = path + "/*";
/* 151 */     if (!urlPattern.startsWith("/")) urlPattern = "/" + urlPattern;
/* 152 */     return urlPattern;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/jetty/JettyWebContainer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */