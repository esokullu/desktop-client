/*    */ package mx4j.tools.remote.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.InstanceNotFoundException;
/*    */ import javax.management.ListenerNotFoundException;
/*    */ import javax.management.ObjectName;
/*    */ import javax.management.remote.NotificationResult;
/*    */ import javax.security.auth.Subject;
/*    */ import mx4j.tools.remote.ConnectionManager;
/*    */ import mx4j.tools.remote.JMXConnection;
/*    */ import mx4j.tools.remote.JMXConnectionHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTTPConnectionHandler
/*    */   extends JMXConnectionHandler
/*    */   implements HTTPConnection
/*    */ {
/*    */   public HTTPConnectionHandler(JMXConnection connection, ConnectionManager manager, String connectionId)
/*    */   {
/* 29 */     super(connection, manager, connectionId);
/*    */   }
/*    */   
/*    */   public String connect(Object credentials) throws IOException, SecurityException
/*    */   {
/* 34 */     throw new Error("Method connect() must not be forwarded to the invocation chain");
/*    */   }
/*    */   
/*    */   public Integer addNotificationListener(ObjectName name, Object filter, Subject delegate) throws InstanceNotFoundException, IOException
/*    */   {
/* 39 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 40 */     return ((HTTPConnection)getConnection()).addNotificationListener(name, filter, delegate);
/*    */   }
/*    */   
/*    */   public void removeNotificationListeners(ObjectName name, Integer[] listenerIDs, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*    */   {
/* 45 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 46 */     ((HTTPConnection)getConnection()).removeNotificationListeners(name, listenerIDs, delegate);
/*    */   }
/*    */   
/*    */   public NotificationResult fetchNotifications(long clientSequenceNumber, int maxNotifications, long timeout) throws IOException
/*    */   {
/* 51 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 52 */     return ((HTTPConnection)getConnection()).fetchNotifications(clientSequenceNumber, maxNotifications, timeout);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/HTTPConnectionHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */