/*     */ package mx4j.tools.remote.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import mx4j.remote.ConnectionResolver;
/*     */ import mx4j.tools.remote.AbstractJMXConnectorServer;
/*     */ import mx4j.tools.remote.ConnectionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HTTPConnectorServer
/*     */   extends AbstractJMXConnectorServer
/*     */ {
/*     */   public static final String USE_EXTERNAL_WEB_CONTAINER = "jmx.remote.x.http.use.external.web.container";
/*     */   public static final String EMBEDDED_WEB_CONTAINER_CLASS = "jmx.remote.x.http.embedded.web.container.class";
/*  32 */   private static Map instances = new HashMap();
/*     */   
/*     */   private WebContainer webContainer;
/*     */   private ConnectionManager connectionManager;
/*     */   
/*     */   public HTTPConnectorServer(JMXServiceURL url, Map environment, MBeanServer server)
/*     */   {
/*  39 */     super(url, environment, server);
/*     */   }
/*     */   
/*     */   protected void doStart() throws IOException, IllegalStateException
/*     */   {
/*  44 */     MBeanServer server = getMBeanServer();
/*  45 */     if (server == null) { throw new IllegalStateException("This JMXConnectorServer is not attached to an MBeanServer");
/*     */     }
/*  47 */     JMXServiceURL address = getAddress();
/*  48 */     String protocol = address.getProtocol();
/*  49 */     Map environment = getEnvironment();
/*  50 */     ConnectionResolver resolver = ConnectionResolver.newConnectionResolver(protocol, environment);
/*  51 */     if (resolver == null) { throw new MalformedURLException("Unsupported protocol: " + protocol);
/*     */     }
/*  53 */     this.webContainer = ((WebContainer)resolver.createServer(address, environment));
/*     */     
/*  55 */     setAddress(resolver.bindServer(this.webContainer, address, environment));
/*     */     
/*  57 */     this.connectionManager = createConnectionManager(this, environment);
/*     */     
/*     */ 
/*  60 */     register(getAddress(), this.connectionManager);
/*     */   }
/*     */   
/*     */   protected abstract ConnectionManager createConnectionManager(AbstractJMXConnectorServer paramAbstractJMXConnectorServer, Map paramMap);
/*     */   
/*     */   private void register(JMXServiceURL url, ConnectionManager manager) throws IOException
/*     */   {
/*  67 */     synchronized (HTTPConnectorServer.class)
/*     */     {
/*     */ 
/*     */ 
/*  71 */       if (instances.get(url) != null) throw new IOException("A JMXConnectorServer is already serving at address " + url);
/*  72 */       instances.put(url, manager);
/*     */     }
/*     */   }
/*     */   
/*     */   private void unregister(JMXServiceURL url) throws IOException
/*     */   {
/*  78 */     synchronized (HTTPConnectorServer.class)
/*     */     {
/*  80 */       Object removed = instances.remove(url);
/*  81 */       if (removed == null) throw new IOException("No JMXConnectorServer is present for address " + url);
/*     */     }
/*     */   }
/*     */   
/*     */   static ConnectionManager find(JMXServiceURL address)
/*     */   {
/*  87 */     synchronized (HTTPConnectorServer.class)
/*     */     {
/*  89 */       ConnectionManager manager = (ConnectionManager)instances.get(address);
/*  90 */       if (manager != null) { return manager;
/*     */       }
/*  92 */       Logger logger = Log.getLogger(HTTPConnectorServer.class.getName());
/*  93 */       if (logger.isEnabledFor(10)) logger.debug("Known HTTPConnectorServers bound at " + instances.keySet());
/*  94 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void doStop() throws IOException
/*     */   {
/* 100 */     JMXServiceURL url = getAddress();
/* 101 */     unregister(url);
/*     */     
/* 103 */     if (this.connectionManager != null)
/*     */     {
/* 105 */       this.connectionManager.close();
/* 106 */       this.connectionManager = null;
/*     */     }
/*     */     
/* 109 */     String protocol = url.getProtocol();
/* 110 */     Map environment = getEnvironment();
/* 111 */     ConnectionResolver resolver = ConnectionResolver.newConnectionResolver(protocol, environment);
/* 112 */     if (resolver == null) { throw new MalformedURLException("Unsupported protocol: " + protocol);
/*     */     }
/* 114 */     resolver.unbindServer(this.webContainer, url, environment);
/*     */     
/* 116 */     resolver.destroyServer(this.webContainer, url, environment);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/HTTPConnectorServer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */