/*    */ package mx4j.tools.remote.http;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Proxy;
/*    */ import java.security.AccessControlContext;
/*    */ import java.util.Map;
/*    */ import javax.security.auth.Subject;
/*    */ import mx4j.tools.remote.SubjectInvoker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTTPSubjectInvoker
/*    */   extends SubjectInvoker
/*    */ {
/*    */   public static HTTPConnection newInstance(HTTPConnection target, Subject subject, AccessControlContext context, Map environment)
/*    */   {
/* 26 */     HTTPSubjectInvoker handler = new HTTPSubjectInvoker(target, subject, context, environment);
/* 27 */     return (HTTPConnection)Proxy.newProxyInstance(target.getClass().getClassLoader(), new Class[] { HTTPConnection.class }, handler);
/*    */   }
/*    */   
/*    */   private HTTPSubjectInvoker(HTTPConnection target, Subject subject, AccessControlContext context, Map environment)
/*    */   {
/* 32 */     super(target, subject, context, environment);
/*    */   }
/*    */   
/*    */   protected boolean isPlainInvoke(Method method)
/*    */   {
/* 37 */     boolean plain = super.isPlainInvoke(method);
/* 38 */     if (plain) { return plain;
/*    */     }
/* 40 */     String methodName = method.getName();
/*    */     
/* 42 */     if ("fetchNotifications".equals(methodName)) return true;
/* 43 */     if ("close".equals(methodName)) return true;
/* 44 */     return false;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/HTTPSubjectInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */