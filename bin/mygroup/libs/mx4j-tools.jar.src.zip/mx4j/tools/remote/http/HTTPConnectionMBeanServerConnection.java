/*    */ package mx4j.tools.remote.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.InstanceNotFoundException;
/*    */ import javax.management.ListenerNotFoundException;
/*    */ import javax.management.NotificationFilter;
/*    */ import javax.management.NotificationListener;
/*    */ import javax.management.ObjectName;
/*    */ import javax.security.auth.Subject;
/*    */ import mx4j.remote.NotificationTuple;
/*    */ import mx4j.remote.RemoteNotificationClientHandler;
/*    */ import mx4j.tools.remote.JMXConnection;
/*    */ import mx4j.tools.remote.JMXConnectionMBeanServerConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTTPConnectionMBeanServerConnection
/*    */   extends JMXConnectionMBeanServerConnection
/*    */ {
/*    */   private final RemoteNotificationClientHandler notificationHandler;
/*    */   
/*    */   public HTTPConnectionMBeanServerConnection(JMXConnection connection, Subject delegate, RemoteNotificationClientHandler notificationHandler)
/*    */   {
/* 39 */     super(connection, delegate);
/* 40 */     this.notificationHandler = notificationHandler;
/*    */   }
/*    */   
/*    */   public void addNotificationListener(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback) throws InstanceNotFoundException, IOException
/*    */   {
/* 45 */     NotificationTuple tuple = new NotificationTuple(observed, listener, filter, handback);
/*    */     
/* 47 */     tuple.setInvokeFilter(true);
/* 48 */     if (this.notificationHandler.contains(tuple)) return;
/* 49 */     Integer id = ((HTTPConnection)getConnection()).addNotificationListener(observed, null, getDelegateSubject());
/* 50 */     this.notificationHandler.addNotificationListener(id, tuple);
/*    */   }
/*    */   
/*    */   public void removeNotificationListener(ObjectName observed, NotificationListener listener) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*    */   {
/* 55 */     Integer[] ids = this.notificationHandler.getNotificationListeners(new NotificationTuple(observed, listener));
/* 56 */     if (ids == null) throw new ListenerNotFoundException("Could not find listener " + listener);
/* 57 */     ((HTTPConnection)getConnection()).removeNotificationListeners(observed, ids, getDelegateSubject());
/* 58 */     this.notificationHandler.removeNotificationListeners(ids);
/*    */   }
/*    */   
/*    */   public void removeNotificationListener(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*    */   {
/* 63 */     Integer id = this.notificationHandler.getNotificationListener(new NotificationTuple(observed, listener, filter, handback));
/* 64 */     if (id == null) throw new ListenerNotFoundException("Could not find listener " + listener + " with filter " + filter + " and handback " + handback);
/* 65 */     Integer[] ids = { id };
/* 66 */     ((HTTPConnection)getConnection()).removeNotificationListeners(observed, ids, getDelegateSubject());
/* 67 */     this.notificationHandler.removeNotificationListeners(ids);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/HTTPConnectionMBeanServerConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */