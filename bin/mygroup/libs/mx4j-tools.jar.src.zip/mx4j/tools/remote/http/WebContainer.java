package mx4j.tools.remote.http;

import java.io.IOException;
import java.util.Map;
import javax.management.remote.JMXServiceURL;

public abstract interface WebContainer
{
  public abstract void start(JMXServiceURL paramJMXServiceURL, Map paramMap)
    throws IOException;
  
  public abstract void stop()
    throws IOException;
  
  public abstract void deploy(String paramString, JMXServiceURL paramJMXServiceURL, Map paramMap)
    throws IOException;
  
  public abstract void undeploy(String paramString, JMXServiceURL paramJMXServiceURL, Map paramMap);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/WebContainer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */