/*    */ package mx4j.tools.remote.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import mx4j.remote.AbstractHeartBeat;
/*    */ import mx4j.remote.ConnectionNotificationEmitter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTTPHeartBeat
/*    */   extends AbstractHeartBeat
/*    */ {
/*    */   private final HTTPConnection connection;
/*    */   
/*    */   public HTTPHeartBeat(HTTPConnection connection, ConnectionNotificationEmitter emitter, Map environment)
/*    */   {
/* 26 */     super(emitter, environment);
/* 27 */     this.connection = connection;
/*    */   }
/*    */   
/*    */   protected void pulse() throws IOException
/*    */   {
/* 32 */     this.connection.getDefaultDomain(null);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/HTTPHeartBeat.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */