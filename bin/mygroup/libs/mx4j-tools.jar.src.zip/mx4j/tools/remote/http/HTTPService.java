/*     */ package mx4j.tools.remote.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import javax.management.remote.NotificationResult;
/*     */ import javax.security.auth.Subject;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import mx4j.tools.remote.Connection;
/*     */ import mx4j.tools.remote.ConnectionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HTTPService
/*     */   implements HTTPConnection
/*     */ {
/*  44 */   private final Map connections = new HashMap();
/*     */   
/*     */   protected Logger getLogger()
/*     */   {
/*  48 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */   
/*     */   public String connect(Object credentials) throws IOException, SecurityException
/*     */   {
/*  53 */     JMXServiceURL address = findJMXServiceURL();
/*     */     
/*     */ 
/*  56 */     ConnectionManager connectionManager = HTTPConnectorServer.find(address);
/*  57 */     if (connectionManager == null) { throw new IOException("Could not find ConnectionManager. Make sure a SOAPConnectorServer is in classloader scope and bound at this address " + address);
/*     */     }
/*  59 */     Connection connection = connectionManager.connect(credentials);
/*  60 */     addConnection(connection);
/*  61 */     return connection.getConnectionId();
/*     */   }
/*     */   
/*     */   protected JMXServiceURL findJMXServiceURL() throws MalformedURLException
/*     */   {
/*  66 */     String url = findRequestURL();
/*  67 */     JMXServiceURL temp = new JMXServiceURL("service:jmx:" + url);
/*  68 */     int port = temp.getPort();
/*  69 */     if (("http".equals(temp.getProtocol())) && (port == 0))
/*     */     {
/*     */ 
/*  72 */       port = 80;
/*     */     }
/*  74 */     else if (("https".equals(temp.getProtocol())) && (port == 0))
/*     */     {
/*     */ 
/*  77 */       port = 443;
/*     */     }
/*  79 */     return new JMXServiceURL(getProtocol(), temp.getHost(), port, temp.getURLPath());
/*     */   }
/*     */   
/*     */   protected abstract String findRequestURL();
/*     */   
/*     */   protected abstract String getProtocol();
/*     */   
/*     */   protected void addConnection(Connection connection) throws IOException
/*     */   {
/*  88 */     String connectionId = connection.getConnectionId();
/*  89 */     synchronized (this)
/*     */     {
/*  91 */       if (this.connections.containsKey(connectionId)) throw new IOException("Connection '" + connection + "' already connected");
/*  92 */       this.connections.put(connectionId, connection);
/*     */       
/*  94 */       Logger logger = getLogger();
/*  95 */       if (logger.isEnabledFor(10)) logger.debug("Added connection '" + connectionId + "', known connections are " + this.connections.keySet());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void removeConnection(Connection connection) throws IOException
/*     */   {
/* 101 */     String connectionId = connection.getConnectionId();
/* 102 */     synchronized (this)
/*     */     {
/* 104 */       if (!this.connections.containsKey(connectionId)) throw new IOException("Connection '" + connection + "' unknown");
/* 105 */       this.connections.remove(connectionId);
/*     */       
/* 107 */       Logger logger = getLogger();
/* 108 */       if (logger.isEnabledFor(10)) logger.debug("Removed connection '" + connectionId + "', known connections are " + this.connections.keySet());
/*     */     }
/*     */   }
/*     */   
/*     */   protected Connection findConnection() throws IOException
/*     */   {
/* 114 */     String connectionId = findConnectionId();
/* 115 */     synchronized (this)
/*     */     {
/* 117 */       Connection connection = (Connection)this.connections.get(connectionId);
/* 118 */       if (connection != null) { return connection;
/*     */       }
/* 120 */       Logger logger = getLogger();
/* 121 */       if (logger.isEnabledFor(10)) logger.debug("Unknown connection '" + connectionId + "', known connections are " + this.connections.keySet());
/* 122 */       throw new IOException("Connection ID '" + connectionId + "' unknown");
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract String findConnectionId();
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 130 */     Connection connection = findConnection();
/* 131 */     removeConnection(connection);
/* 132 */     connection.close();
/*     */   }
/*     */   
/*     */   public String getConnectionId() throws IOException
/*     */   {
/* 137 */     Connection connection = findConnection();
/* 138 */     return connection.getConnectionId();
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName name, Object params, String[] signature, Subject delegate) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException
/*     */   {
/* 143 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 144 */     return connection.createMBean(className, name, params, signature, delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName name, ObjectName loaderName, Object params, String[] signature, Subject delegate) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException
/*     */   {
/* 149 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 150 */     return connection.createMBean(className, name, loaderName, params, signature, delegate);
/*     */   }
/*     */   
/*     */   public void unregisterMBean(ObjectName name, Subject delegate) throws InstanceNotFoundException, MBeanRegistrationException, IOException
/*     */   {
/* 155 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 156 */     connection.unregisterMBean(name, delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance getObjectInstance(ObjectName name, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 161 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 162 */     return connection.getObjectInstance(name, delegate);
/*     */   }
/*     */   
/*     */   public Set queryMBeans(ObjectName name, Object query, Subject delegate) throws IOException
/*     */   {
/* 167 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 168 */     return connection.queryMBeans(name, query, delegate);
/*     */   }
/*     */   
/*     */   public Set queryNames(ObjectName name, Object query, Subject delegate) throws IOException
/*     */   {
/* 173 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 174 */     return connection.queryNames(name, query, delegate);
/*     */   }
/*     */   
/*     */   public boolean isRegistered(ObjectName name, Subject delegate) throws IOException
/*     */   {
/* 179 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 180 */     return connection.isRegistered(name, delegate);
/*     */   }
/*     */   
/*     */   public Integer getMBeanCount(Subject delegate) throws IOException
/*     */   {
/* 185 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 186 */     return connection.getMBeanCount(delegate);
/*     */   }
/*     */   
/*     */   public Object getAttribute(ObjectName name, String attribute, Subject delegate) throws MBeanException, AttributeNotFoundException, InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 191 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 192 */     return connection.getAttribute(name, attribute, delegate);
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(ObjectName name, String[] attributes, Subject delegate) throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 197 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 198 */     return connection.getAttributes(name, attributes, delegate);
/*     */   }
/*     */   
/*     */   public void setAttribute(ObjectName name, Object attribute, Subject delegate) throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException, IOException
/*     */   {
/* 203 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 204 */     connection.setAttribute(name, attribute, delegate);
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(ObjectName name, Object attributes, Subject delegate) throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 209 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 210 */     return connection.setAttributes(name, attributes, delegate);
/*     */   }
/*     */   
/*     */   public Object invoke(ObjectName name, String operationName, Object params, String[] signature, Subject delegate) throws InstanceNotFoundException, MBeanException, ReflectionException, IOException
/*     */   {
/* 215 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 216 */     return connection.invoke(name, operationName, params, signature, delegate);
/*     */   }
/*     */   
/*     */   public String getDefaultDomain(Subject delegate) throws IOException
/*     */   {
/* 221 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 222 */     return connection.getDefaultDomain(delegate);
/*     */   }
/*     */   
/*     */   public String[] getDomains(Subject delegate) throws IOException
/*     */   {
/* 227 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 228 */     return connection.getDomains(delegate);
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo(ObjectName name, Subject delegate) throws InstanceNotFoundException, IntrospectionException, ReflectionException, IOException
/*     */   {
/* 233 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 234 */     return connection.getMBeanInfo(name, delegate);
/*     */   }
/*     */   
/*     */   public boolean isInstanceOf(ObjectName name, String className, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 239 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 240 */     return connection.isInstanceOf(name, className, delegate);
/*     */   }
/*     */   
/*     */   public void addNotificationListener(ObjectName name, ObjectName listener, Object filter, Object handback, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 245 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 246 */     connection.addNotificationListener(name, listener, filter, handback, delegate);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName name, ObjectName listener, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 251 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 252 */     connection.removeNotificationListener(name, listener, delegate);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName name, ObjectName listener, Object filter, Object handback, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 257 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 258 */     connection.removeNotificationListener(name, listener, filter, handback, delegate);
/*     */   }
/*     */   
/*     */   public Integer addNotificationListener(ObjectName name, Object filter, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 263 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 264 */     return connection.addNotificationListener(name, filter, delegate);
/*     */   }
/*     */   
/*     */   public void removeNotificationListeners(ObjectName name, Integer[] listenerIDs, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 269 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 270 */     connection.removeNotificationListeners(name, listenerIDs, delegate);
/*     */   }
/*     */   
/*     */   public NotificationResult fetchNotifications(long clientSequenceNumber, int maxNotifications, long timeout) throws IOException
/*     */   {
/* 275 */     HTTPConnection connection = (HTTPConnection)findConnection();
/* 276 */     return connection.fetchNotifications(clientSequenceNumber, maxNotifications, timeout);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/HTTPService.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */