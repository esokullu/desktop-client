/*    */ package mx4j.tools.remote.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.management.MBeanServerConnection;
/*    */ import javax.security.auth.Subject;
/*    */ import mx4j.remote.DefaultRemoteNotificationServerHandler;
/*    */ import mx4j.remote.RemoteNotificationServerHandler;
/*    */ import mx4j.tools.remote.AbstractConnectionManager;
/*    */ import mx4j.tools.remote.AbstractJMXConnectorServer;
/*    */ import mx4j.tools.remote.Connection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTTPConnectionManager
/*    */   extends AbstractConnectionManager
/*    */ {
/*    */   private final MBeanServerConnection mbeanServerConnection;
/*    */   private final String protocol;
/*    */   
/*    */   public HTTPConnectionManager(AbstractJMXConnectorServer server, String protocol, Map environment)
/*    */   {
/* 32 */     super(server, environment);
/* 33 */     this.mbeanServerConnection = server.getMBeanServer();
/* 34 */     this.protocol = protocol;
/*    */   }
/*    */   
/*    */   public String getProtocol()
/*    */   {
/* 39 */     return this.protocol;
/*    */   }
/*    */   
/*    */   protected Connection doConnect(String connectionId, Subject subject) throws IOException
/*    */   {
/* 44 */     RemoteNotificationServerHandler notificationHandler = new DefaultRemoteNotificationServerHandler(getEnvironment());
/* 45 */     HTTPConnection invoker = new HTTPServerInvoker(this.mbeanServerConnection, notificationHandler);
/* 46 */     HTTPConnection subjectInvoker = HTTPSubjectInvoker.newInstance(invoker, subject, getSecurityContext(), getEnvironment());
/* 47 */     Connection handler = new HTTPConnectionHandler(subjectInvoker, this, connectionId);
/* 48 */     return handler;
/*    */   }
/*    */   
/*    */   protected void doClose()
/*    */     throws IOException
/*    */   {}
/*    */   
/*    */   protected void doCloseConnection(Connection connection)
/*    */     throws IOException
/*    */   {}
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/HTTPConnectionManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */