/*    */ package mx4j.tools.remote.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.InstanceNotFoundException;
/*    */ import javax.management.ListenerNotFoundException;
/*    */ import javax.management.MBeanServerConnection;
/*    */ import javax.management.NotificationListener;
/*    */ import javax.management.ObjectName;
/*    */ import javax.management.remote.NotificationResult;
/*    */ import javax.security.auth.Subject;
/*    */ import mx4j.remote.NotificationTuple;
/*    */ import mx4j.remote.RemoteNotificationServerHandler;
/*    */ import mx4j.tools.remote.AbstractServerInvoker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTTPServerInvoker
/*    */   extends AbstractServerInvoker
/*    */   implements HTTPConnection
/*    */ {
/*    */   private final RemoteNotificationServerHandler notificationHandler;
/*    */   
/*    */   public HTTPServerInvoker(MBeanServerConnection server, RemoteNotificationServerHandler handler)
/*    */   {
/* 38 */     super(server);
/* 39 */     this.notificationHandler = handler;
/*    */   }
/*    */   
/*    */   public String connect(Object credentials) throws IOException, SecurityException
/*    */   {
/* 44 */     return null;
/*    */   }
/*    */   
/*    */   public void close() throws IOException
/*    */   {
/* 49 */     NotificationTuple[] tuples = this.notificationHandler.close();
/* 50 */     for (int i = 0; i < tuples.length; i++)
/*    */     {
/* 52 */       NotificationTuple tuple = tuples[i];
/*    */       try
/*    */       {
/* 55 */         getServer().removeNotificationListener(tuple.getObjectName(), tuple.getNotificationListener(), tuple.getNotificationFilter(), tuple.getHandback());
/*    */       }
/*    */       catch (InstanceNotFoundException ignored) {}catch (ListenerNotFoundException ignored) {}
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Integer addNotificationListener(ObjectName name, Object filter, Subject delegate)
/*    */     throws InstanceNotFoundException, IOException
/*    */   {
/* 68 */     Integer id = this.notificationHandler.generateListenerID(name, null);
/* 69 */     NotificationListener listener = this.notificationHandler.getServerNotificationListener();
/* 70 */     getServer().addNotificationListener(name, listener, null, id);
/* 71 */     this.notificationHandler.addNotificationListener(id, new NotificationTuple(name, listener, null, id));
/* 72 */     return id;
/*    */   }
/*    */   
/*    */   public void removeNotificationListeners(ObjectName name, Integer[] listenerIDs, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*    */   {
/* 77 */     for (int i = 0; i < listenerIDs.length; i++)
/*    */     {
/* 79 */       Integer id = listenerIDs[i];
/* 80 */       NotificationTuple tuple = this.notificationHandler.removeNotificationListener(id);
/* 81 */       getServer().removeNotificationListener(name, tuple.getNotificationListener(), tuple.getNotificationFilter(), tuple.getHandback());
/*    */     }
/*    */   }
/*    */   
/*    */   public NotificationResult fetchNotifications(long clientSequenceNumber, int maxNotifications, long timeout) throws IOException
/*    */   {
/* 87 */     return this.notificationHandler.fetchNotifications(clientSequenceNumber, maxNotifications, timeout);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/HTTPServerInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */