/*    */ package mx4j.tools.remote.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.MalformedURLException;
/*    */ import java.util.Map;
/*    */ import javax.management.remote.JMXServiceURL;
/*    */ import mx4j.remote.ConnectionNotificationEmitter;
/*    */ import mx4j.remote.ConnectionResolver;
/*    */ import mx4j.remote.HeartBeat;
/*    */ import mx4j.remote.RemoteNotificationClientHandler;
/*    */ import mx4j.tools.remote.AbstractJMXConnector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class HTTPConnector
/*    */   extends AbstractJMXConnector
/*    */ {
/*    */   private transient HTTPConnection connection;
/*    */   private transient String connectionId;
/*    */   private transient HeartBeat heartbeat;
/*    */   private transient RemoteNotificationClientHandler notificationHandler;
/*    */   
/*    */   protected HTTPConnector(JMXServiceURL address)
/*    */     throws IOException
/*    */   {
/* 34 */     super(address);
/*    */   }
/*    */   
/*    */   protected void doConnect(Map environment) throws IOException, SecurityException
/*    */   {
/* 39 */     JMXServiceURL address = getAddress();
/* 40 */     String protocol = address.getProtocol();
/* 41 */     ConnectionResolver resolver = ConnectionResolver.newConnectionResolver(protocol, environment);
/* 42 */     if (resolver == null) { throw new MalformedURLException("Unsupported protocol: " + protocol);
/*    */     }
/* 44 */     HTTPConnection temp = (HTTPConnection)resolver.lookupClient(address, environment);
/* 45 */     this.connection = ((HTTPConnection)resolver.bindClient(temp, environment));
/*    */     
/* 47 */     Object credentials = environment == null ? null : environment.get("jmx.remote.credentials");
/* 48 */     this.connectionId = this.connection.connect(credentials);
/*    */     
/* 50 */     this.heartbeat = createHeartBeat(this.connection, getConnectionNotificationEmitter(), environment);
/* 51 */     this.notificationHandler = createRemoteNotificationClientHandler(this.connection, getConnectionNotificationEmitter(), this.heartbeat, environment);
/*    */     
/* 53 */     this.heartbeat.start();
/* 54 */     this.notificationHandler.start();
/*    */   }
/*    */   
/*    */   protected HeartBeat createHeartBeat(HTTPConnection connection, ConnectionNotificationEmitter emitter, Map environment)
/*    */   {
/* 59 */     return new HTTPHeartBeat(connection, emitter, environment);
/*    */   }
/*    */   
/*    */   protected RemoteNotificationClientHandler createRemoteNotificationClientHandler(HTTPConnection connection, ConnectionNotificationEmitter emitter, HeartBeat heartbeat, Map environment)
/*    */   {
/* 64 */     return new HTTPRemoteNotificationClientHandler(connection, emitter, heartbeat, environment);
/*    */   }
/*    */   
/*    */   protected void doClose() throws IOException
/*    */   {
/* 69 */     if (this.notificationHandler != null) this.notificationHandler.stop();
/* 70 */     if (this.heartbeat != null) this.heartbeat.stop();
/* 71 */     if (this.connection != null) this.connection.close();
/*    */   }
/*    */   
/*    */   public String getConnectionId() throws IOException
/*    */   {
/* 76 */     return this.connectionId;
/*    */   }
/*    */   
/*    */   protected HTTPConnection getHTTPConnection()
/*    */   {
/* 81 */     return this.connection;
/*    */   }
/*    */   
/*    */   public RemoteNotificationClientHandler getRemoteNotificationClientHandler()
/*    */   {
/* 86 */     return this.notificationHandler;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/HTTPConnector.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */