package mx4j.tools.remote.http;

import java.io.IOException;
import javax.management.InstanceNotFoundException;
import javax.management.ListenerNotFoundException;
import javax.management.ObjectName;
import javax.management.remote.NotificationResult;
import javax.security.auth.Subject;
import mx4j.tools.remote.JMXConnection;

public abstract interface HTTPConnection
  extends JMXConnection
{
  public abstract String connect(Object paramObject)
    throws IOException, SecurityException;
  
  public abstract Integer addNotificationListener(ObjectName paramObjectName, Object paramObject, Subject paramSubject)
    throws InstanceNotFoundException, IOException;
  
  public abstract void removeNotificationListeners(ObjectName paramObjectName, Integer[] paramArrayOfInteger, Subject paramSubject)
    throws InstanceNotFoundException, ListenerNotFoundException, IOException;
  
  public abstract NotificationResult fetchNotifications(long paramLong1, int paramInt, long paramLong2)
    throws IOException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/HTTPConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */