/*     */ package mx4j.tools.remote.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.remote.NotificationResult;
/*     */ import javax.security.auth.Subject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HTTPClientInvoker
/*     */   implements HTTPConnection
/*     */ {
/*     */   private String connectionId;
/*     */   
/*     */   protected abstract HTTPConnection getService();
/*     */   
/*     */   public String connect(Object credentials)
/*     */     throws IOException, SecurityException
/*     */   {
/*  41 */     this.connectionId = getService().connect(credentials);
/*  42 */     return this.connectionId;
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/*  47 */     getService().close();
/*     */   }
/*     */   
/*     */   public String getConnectionId() throws IOException
/*     */   {
/*  52 */     return this.connectionId;
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName name, Object params, String[] signature, Subject delegate) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException
/*     */   {
/*  57 */     return getService().createMBean(className, name, params, signature, delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName name, ObjectName loaderName, Object params, String[] signature, Subject delegate) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException
/*     */   {
/*  62 */     return getService().createMBean(className, name, loaderName, params, signature, delegate);
/*     */   }
/*     */   
/*     */   public void unregisterMBean(ObjectName name, Subject delegate) throws InstanceNotFoundException, MBeanRegistrationException, IOException
/*     */   {
/*  67 */     getService().unregisterMBean(name, delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance getObjectInstance(ObjectName name, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/*  72 */     return getService().getObjectInstance(name, delegate);
/*     */   }
/*     */   
/*     */   public Set queryMBeans(ObjectName name, Object query, Subject delegate) throws IOException
/*     */   {
/*  77 */     return getService().queryMBeans(name, query, delegate);
/*     */   }
/*     */   
/*     */   public Set queryNames(ObjectName name, Object query, Subject delegate) throws IOException
/*     */   {
/*  82 */     return getService().queryNames(name, query, delegate);
/*     */   }
/*     */   
/*     */   public boolean isRegistered(ObjectName name, Subject delegate) throws IOException
/*     */   {
/*  87 */     return getService().isRegistered(name, delegate);
/*     */   }
/*     */   
/*     */   public Integer getMBeanCount(Subject delegate) throws IOException
/*     */   {
/*  92 */     return getService().getMBeanCount(delegate);
/*     */   }
/*     */   
/*     */   public Object getAttribute(ObjectName name, String attribute, Subject delegate) throws MBeanException, AttributeNotFoundException, InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/*  97 */     return getService().getAttribute(name, attribute, delegate);
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(ObjectName name, String[] attributes, Subject delegate) throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 102 */     return getService().getAttributes(name, attributes, delegate);
/*     */   }
/*     */   
/*     */   public void setAttribute(ObjectName name, Object attribute, Subject delegate) throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException, IOException
/*     */   {
/* 107 */     getService().setAttribute(name, attribute, delegate);
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(ObjectName name, Object attributes, Subject delegate) throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 112 */     return getService().setAttributes(name, attributes, delegate);
/*     */   }
/*     */   
/*     */   public Object invoke(ObjectName name, String operationName, Object params, String[] signature, Subject delegate) throws InstanceNotFoundException, MBeanException, ReflectionException, IOException
/*     */   {
/* 117 */     return getService().invoke(name, operationName, params, signature, delegate);
/*     */   }
/*     */   
/*     */   public String getDefaultDomain(Subject delegate) throws IOException
/*     */   {
/* 122 */     return getService().getDefaultDomain(delegate);
/*     */   }
/*     */   
/*     */   public String[] getDomains(Subject delegate) throws IOException
/*     */   {
/* 127 */     return getService().getDomains(delegate);
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo(ObjectName name, Subject delegate) throws InstanceNotFoundException, IntrospectionException, ReflectionException, IOException
/*     */   {
/* 132 */     return getService().getMBeanInfo(name, delegate);
/*     */   }
/*     */   
/*     */   public boolean isInstanceOf(ObjectName name, String className, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 137 */     return getService().isInstanceOf(name, className, delegate);
/*     */   }
/*     */   
/*     */   public void addNotificationListener(ObjectName name, ObjectName listener, Object filter, Object handback, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 142 */     getService().addNotificationListener(name, listener, filter, handback, delegate);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName name, ObjectName listener, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 147 */     getService().removeNotificationListener(name, listener, delegate);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName name, ObjectName listener, Object filter, Object handback, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 152 */     getService().removeNotificationListener(name, listener, filter, handback, delegate);
/*     */   }
/*     */   
/*     */   public Integer addNotificationListener(ObjectName name, Object filter, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 157 */     return getService().addNotificationListener(name, filter, delegate);
/*     */   }
/*     */   
/*     */   public void removeNotificationListeners(ObjectName name, Integer[] listenerIDs, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 162 */     getService().removeNotificationListeners(name, listenerIDs, delegate);
/*     */   }
/*     */   
/*     */   public NotificationResult fetchNotifications(long clientSequenceNumber, int maxNotifications, long timeout) throws IOException
/*     */   {
/* 167 */     return getService().fetchNotifications(clientSequenceNumber, maxNotifications, timeout);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/http/HTTPClientInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */