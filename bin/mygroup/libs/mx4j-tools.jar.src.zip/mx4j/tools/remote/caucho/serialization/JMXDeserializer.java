/*    */ package mx4j.tools.remote.caucho.serialization;
/*    */ 
/*    */ import com.caucho.hessian.io.AbstractHessianInput;
/*    */ import com.caucho.hessian.io.Deserializer;
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JMXDeserializer
/*    */   extends Deserializer
/*    */ {
/*    */   public Object readMap(AbstractHessianInput in)
/*    */     throws IOException
/*    */   {
/*    */     try
/*    */     {
/* 27 */       byte[] bytes = in.readBytes();
/* 28 */       ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
/* 29 */       ObjectInputStream ois = new ObjectInputStream(bais);
/* 30 */       Object result = ois.readObject();
/* 31 */       ois.close();
/* 32 */       return result;
/*    */     }
/*    */     catch (ClassNotFoundException x)
/*    */     {
/* 36 */       throw new IOException(x.toString());
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/serialization/JMXDeserializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */