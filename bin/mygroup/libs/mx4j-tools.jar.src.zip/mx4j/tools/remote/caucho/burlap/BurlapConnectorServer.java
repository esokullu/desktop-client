/*    */ package mx4j.tools.remote.caucho.burlap;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.remote.JMXServiceURL;
/*    */ import mx4j.tools.remote.AbstractJMXConnectorServer;
/*    */ import mx4j.tools.remote.ConnectionManager;
/*    */ import mx4j.tools.remote.http.HTTPConnectionManager;
/*    */ import mx4j.tools.remote.http.HTTPConnectorServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BurlapConnectorServer
/*    */   extends HTTPConnectorServer
/*    */ {
/*    */   public BurlapConnectorServer(JMXServiceURL url, Map environment, MBeanServer server)
/*    */   {
/* 35 */     super(url, environment, server);
/*    */   }
/*    */   
/*    */   protected ConnectionManager createConnectionManager(AbstractJMXConnectorServer server, Map environment)
/*    */   {
/* 40 */     return new HTTPConnectionManager(server, "burlap", environment);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/burlap/BurlapConnectorServer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */