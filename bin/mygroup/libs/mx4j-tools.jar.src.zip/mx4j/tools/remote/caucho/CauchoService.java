/*    */ package mx4j.tools.remote.caucho;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import mx4j.tools.remote.http.HTTPService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CauchoService
/*    */   extends HTTPService
/*    */ {
/*    */   static final String CONNECTION_ID_HEADER_NAME = "connectionContext";
/* 22 */   private static ThreadLocal connectionContext = new ThreadLocal();
/*    */   
/*    */   private final String protocol;
/*    */   
/*    */   public CauchoService(String protocol)
/*    */   {
/* 28 */     this.protocol = protocol;
/*    */   }
/*    */   
/*    */   protected String getProtocol()
/*    */   {
/* 33 */     return this.protocol;
/*    */   }
/*    */   
/*    */   protected String findRequestURL()
/*    */   {
/* 38 */     ConnectionContext context = (ConnectionContext)connectionContext.get();
/* 39 */     return context == null ? null : context.url;
/*    */   }
/*    */   
/*    */   protected String findConnectionId()
/*    */   {
/* 44 */     ConnectionContext context = (ConnectionContext)connectionContext.get();
/* 45 */     return context == null ? null : context.connectionId;
/*    */   }
/*    */   
/*    */   static void setConnectionContext(String url, String connectionId)
/*    */   {
/* 50 */     connectionContext.set(new ConnectionContext(url, connectionId, null));
/*    */   }
/*    */   
/*    */   static void resetConnectionContext()
/*    */   {
/* 55 */     connectionContext.set(null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/* 60 */   static String mangleMethodName(Method method) { return method.getName() + "__" + method.getParameterTypes().length; }
/*    */   
/*    */   private static class ConnectionContext {
/* 63 */     ConnectionContext(String x0, String x1, CauchoService.1 x2) { this(x0, x1); }
/*    */     
/*    */ 
/*    */     private String url;
/*    */     private String connectionId;
/*    */     private ConnectionContext(String url, String connectionId)
/*    */     {
/* 70 */       this.url = url;
/* 71 */       this.connectionId = connectionId;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/CauchoService.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */