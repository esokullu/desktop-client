/*    */ package mx4j.tools.remote.caucho.burlap;
/*    */ 
/*    */ import com.caucho.burlap.io.BurlapOutput;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import mx4j.tools.remote.caucho.CauchoOutput;
/*    */ import mx4j.tools.remote.caucho.serialization.JMXSerializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BurlapCauchoOutput
/*    */   implements CauchoOutput
/*    */ {
/*    */   private final BurlapOutput output;
/*    */   
/*    */   BurlapCauchoOutput(OutputStream stream)
/*    */   {
/* 27 */     this.output = new BurlapOutput();
/* 28 */     this.output.setSerializerFactory(new JMXSerializerFactory());
/* 29 */     this.output.init(stream);
/*    */   }
/*    */   
/*    */   public void startReply() throws IOException
/*    */   {
/* 34 */     this.output.startReply();
/*    */   }
/*    */   
/*    */   public void completeReply() throws IOException
/*    */   {
/* 39 */     this.output.completeReply();
/*    */   }
/*    */   
/*    */   public void startCall() throws IOException
/*    */   {
/* 44 */     this.output.startCall();
/*    */   }
/*    */   
/*    */   public void completeCall() throws IOException
/*    */   {
/* 49 */     this.output.completeCall();
/*    */   }
/*    */   
/*    */   public void writeHeader(String header) throws IOException
/*    */   {
/* 54 */     this.output.writeHeader(header);
/*    */   }
/*    */   
/*    */   public void writeMethod(String methodName) throws IOException
/*    */   {
/* 59 */     this.output.writeMethod(methodName);
/*    */   }
/*    */   
/*    */   public void writeObject(Object object) throws IOException
/*    */   {
/* 64 */     this.output.writeObject(object);
/*    */   }
/*    */   
/*    */   public void writeFault(Throwable fault) throws IOException
/*    */   {
/* 69 */     this.output.writeFault(fault.getClass().getName(), fault.getMessage(), fault);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/burlap/BurlapCauchoOutput.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */