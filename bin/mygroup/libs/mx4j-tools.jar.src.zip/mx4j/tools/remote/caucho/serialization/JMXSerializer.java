/*    */ package mx4j.tools.remote.caucho.serialization;
/*    */ 
/*    */ import com.caucho.hessian.io.AbstractHessianOutput;
/*    */ import com.caucho.hessian.io.Serializer;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JMXSerializer
/*    */   extends Serializer
/*    */ {
/*    */   public void writeObject(Object obj, AbstractHessianOutput out)
/*    */     throws IOException
/*    */   {
/* 25 */     out.writeMapBegin(obj.getClass().getName());
/* 26 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 27 */     ObjectOutputStream oos = new ObjectOutputStream(baos);
/* 28 */     oos.writeObject(obj);
/* 29 */     oos.close();
/* 30 */     out.writeBytes(baos.toByteArray());
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/serialization/JMXSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */