/*    */ package mx4j.tools.remote.caucho.hessian;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import mx4j.tools.remote.caucho.CauchoClientInvoker;
/*    */ import mx4j.tools.remote.caucho.CauchoInput;
/*    */ import mx4j.tools.remote.caucho.CauchoOutput;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HessianClientInvoker
/*    */   extends CauchoClientInvoker
/*    */ {
/*    */   public HessianClientInvoker(String endpoint)
/*    */   {
/* 25 */     super(endpoint);
/*    */   }
/*    */   
/*    */   protected CauchoInput createCauchoInput(InputStream stream)
/*    */   {
/* 30 */     return new HessianCauchoInput(stream);
/*    */   }
/*    */   
/*    */   protected CauchoOutput createCauchoOutput(OutputStream stream)
/*    */   {
/* 35 */     return new HessianCauchoOutput(stream);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/hessian/HessianClientInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */