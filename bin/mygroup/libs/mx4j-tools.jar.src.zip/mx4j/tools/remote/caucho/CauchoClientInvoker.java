/*     */ package mx4j.tools.remote.caucho;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import mx4j.tools.remote.http.HTTPClientInvoker;
/*     */ import mx4j.tools.remote.http.HTTPConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CauchoClientInvoker
/*     */   extends HTTPClientInvoker
/*     */ {
/*     */   private final String endpoint;
/*     */   private final HTTPConnection service;
/*     */   
/*     */   public CauchoClientInvoker(String endpoint)
/*     */   {
/*  37 */     this.endpoint = endpoint;
/*  38 */     CauchoServiceProxy proxy = new CauchoServiceProxy(null);
/*  39 */     this.service = ((HTTPConnection)Proxy.newProxyInstance(proxy.getClass().getClassLoader(), new Class[] { HTTPConnection.class }, proxy));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  44 */   protected HTTPConnection getService() { return this.service; }
/*     */   
/*     */   protected abstract CauchoInput createCauchoInput(InputStream paramInputStream);
/*     */   
/*     */   protected abstract CauchoOutput createCauchoOutput(OutputStream paramOutputStream);
/*     */   
/*     */   private class CauchoServiceProxy implements InvocationHandler {
/*  51 */     CauchoServiceProxy(CauchoClientInvoker.1 x1) { this(); }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void startCall(CauchoOutput output)
/*     */       throws IOException
/*     */     {
/*  98 */       output.startCall();
/*     */     }
/*     */     
/*     */     private void writeHeaders(CauchoOutput output) throws IOException
/*     */     {
/* 103 */       output.writeHeader("connectionContext");
/* 104 */       output.writeObject(CauchoClientInvoker.this.getConnectionId());
/*     */     }
/*     */     
/*     */     private void writeMethod(CauchoOutput output, Method method) throws IOException
/*     */     {
/* 109 */       String methodName = mangleMethodName(method);
/* 110 */       output.writeMethod(methodName);
/*     */     }
/*     */     
/*     */     private String mangleMethodName(Method method)
/*     */     {
/* 115 */       return CauchoService.mangleMethodName(method);
/*     */     }
/*     */     
/*     */     private void writeArguments(CauchoOutput output, Object[] args) throws IOException
/*     */     {
/* 120 */       if (args != null) for (int i = 0; i < args.length; i++) output.writeObject(args[i]);
/*     */     }
/*     */     
/*     */     private void completeCall(CauchoOutput output) throws IOException
/*     */     {
/* 125 */       output.completeCall();
/*     */     }
/*     */     
/*     */     private CauchoServiceProxy() {}
/*     */     
/*     */     /* Error */
/*     */     public Object invoke(Object proxy, Method method, Object[] args)
/*     */       throws java.lang.Throwable
/*     */     {
/*     */       // Byte code:
/*     */       //   0: new 4	java/net/URL
/*     */       //   3: dup
/*     */       //   4: aload_0
/*     */       //   5: getfield 3	mx4j/tools/remote/caucho/CauchoClientInvoker$CauchoServiceProxy:this$0	Lmx4j/tools/remote/caucho/CauchoClientInvoker;
/*     */       //   8: invokestatic 5	mx4j/tools/remote/caucho/CauchoClientInvoker:access$100	(Lmx4j/tools/remote/caucho/CauchoClientInvoker;)Ljava/lang/String;
/*     */       //   11: invokespecial 6	java/net/URL:<init>	(Ljava/lang/String;)V
/*     */       //   14: invokevirtual 7	java/net/URL:openConnection	()Ljava/net/URLConnection;
/*     */       //   17: astore 4
/*     */       //   19: aload 4
/*     */       //   21: iconst_1
/*     */       //   22: invokevirtual 8	java/net/URLConnection:setDoInput	(Z)V
/*     */       //   25: aload 4
/*     */       //   27: iconst_1
/*     */       //   28: invokevirtual 9	java/net/URLConnection:setDoOutput	(Z)V
/*     */       //   31: aload 4
/*     */       //   33: iconst_0
/*     */       //   34: invokevirtual 10	java/net/URLConnection:setUseCaches	(Z)V
/*     */       //   37: new 11	java/io/BufferedOutputStream
/*     */       //   40: dup
/*     */       //   41: aload 4
/*     */       //   43: invokevirtual 12	java/net/URLConnection:getOutputStream	()Ljava/io/OutputStream;
/*     */       //   46: invokespecial 13	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
/*     */       //   49: astore 5
/*     */       //   51: aload_0
/*     */       //   52: getfield 3	mx4j/tools/remote/caucho/CauchoClientInvoker$CauchoServiceProxy:this$0	Lmx4j/tools/remote/caucho/CauchoClientInvoker;
/*     */       //   55: aload 5
/*     */       //   57: invokevirtual 14	mx4j/tools/remote/caucho/CauchoClientInvoker:createCauchoOutput	(Ljava/io/OutputStream;)Lmx4j/tools/remote/caucho/CauchoOutput;
/*     */       //   60: astore 6
/*     */       //   62: aload_0
/*     */       //   63: aload 6
/*     */       //   65: invokespecial 15	mx4j/tools/remote/caucho/CauchoClientInvoker$CauchoServiceProxy:startCall	(Lmx4j/tools/remote/caucho/CauchoOutput;)V
/*     */       //   68: aload_0
/*     */       //   69: aload 6
/*     */       //   71: invokespecial 16	mx4j/tools/remote/caucho/CauchoClientInvoker$CauchoServiceProxy:writeHeaders	(Lmx4j/tools/remote/caucho/CauchoOutput;)V
/*     */       //   74: aload_0
/*     */       //   75: aload 6
/*     */       //   77: aload_2
/*     */       //   78: invokespecial 17	mx4j/tools/remote/caucho/CauchoClientInvoker$CauchoServiceProxy:writeMethod	(Lmx4j/tools/remote/caucho/CauchoOutput;Ljava/lang/reflect/Method;)V
/*     */       //   81: aload_0
/*     */       //   82: aload 6
/*     */       //   84: aload_3
/*     */       //   85: invokespecial 18	mx4j/tools/remote/caucho/CauchoClientInvoker$CauchoServiceProxy:writeArguments	(Lmx4j/tools/remote/caucho/CauchoOutput;[Ljava/lang/Object;)V
/*     */       //   88: aload_0
/*     */       //   89: aload 6
/*     */       //   91: invokespecial 19	mx4j/tools/remote/caucho/CauchoClientInvoker$CauchoServiceProxy:completeCall	(Lmx4j/tools/remote/caucho/CauchoOutput;)V
/*     */       //   94: aload 5
/*     */       //   96: invokevirtual 20	java/io/OutputStream:flush	()V
/*     */       //   99: new 21	java/io/BufferedInputStream
/*     */       //   102: dup
/*     */       //   103: aload 4
/*     */       //   105: invokevirtual 22	java/net/URLConnection:getInputStream	()Ljava/io/InputStream;
/*     */       //   108: invokespecial 23	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
/*     */       //   111: astore 7
/*     */       //   113: aload_0
/*     */       //   114: getfield 3	mx4j/tools/remote/caucho/CauchoClientInvoker$CauchoServiceProxy:this$0	Lmx4j/tools/remote/caucho/CauchoClientInvoker;
/*     */       //   117: aload 7
/*     */       //   119: invokevirtual 24	mx4j/tools/remote/caucho/CauchoClientInvoker:createCauchoInput	(Ljava/io/InputStream;)Lmx4j/tools/remote/caucho/CauchoInput;
/*     */       //   122: astore 8
/*     */       //   124: aload 8
/*     */       //   126: invokeinterface 25 1 0
/*     */       //   131: aload 8
/*     */       //   133: aconst_null
/*     */       //   134: invokeinterface 26 2 0
/*     */       //   139: astore 9
/*     */       //   141: aload 8
/*     */       //   143: invokeinterface 27 1 0
/*     */       //   148: aload 9
/*     */       //   150: astore 10
/*     */       //   152: aload 7
/*     */       //   154: invokevirtual 28	java/io/InputStream:close	()V
/*     */       //   157: aload 5
/*     */       //   159: invokevirtual 29	java/io/OutputStream:close	()V
/*     */       //   162: aload 10
/*     */       //   164: areturn
/*     */       //   165: astore 8
/*     */       //   167: getstatic 31	mx4j/tools/remote/caucho/CauchoClientInvoker:class$mx4j$tools$remote$caucho$CauchoClientInvoker	Ljava/lang/Class;
/*     */       //   170: ifnonnull +15 -> 185
/*     */       //   173: ldc 32
/*     */       //   175: invokestatic 33	mx4j/tools/remote/caucho/CauchoClientInvoker:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*     */       //   178: dup
/*     */       //   179: putstatic 31	mx4j/tools/remote/caucho/CauchoClientInvoker:class$mx4j$tools$remote$caucho$CauchoClientInvoker	Ljava/lang/Class;
/*     */       //   182: goto +6 -> 188
/*     */       //   185: getstatic 31	mx4j/tools/remote/caucho/CauchoClientInvoker:class$mx4j$tools$remote$caucho$CauchoClientInvoker	Ljava/lang/Class;
/*     */       //   188: invokevirtual 34	java/lang/Class:getName	()Ljava/lang/String;
/*     */       //   191: invokestatic 35	mx4j/log/Log:getLogger	(Ljava/lang/String;)Lmx4j/log/Logger;
/*     */       //   194: astore 9
/*     */       //   196: aload 9
/*     */       //   198: bipush 10
/*     */       //   200: invokevirtual 36	mx4j/log/Logger:isEnabledFor	(I)Z
/*     */       //   203: ifeq +12 -> 215
/*     */       //   206: aload 9
/*     */       //   208: ldc 37
/*     */       //   210: aload 8
/*     */       //   212: invokevirtual 38	mx4j/log/Logger:debug	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/*     */       //   215: aload 8
/*     */       //   217: athrow
/*     */       //   218: astore 11
/*     */       //   220: aload 7
/*     */       //   222: invokevirtual 28	java/io/InputStream:close	()V
/*     */       //   225: aload 11
/*     */       //   227: athrow
/*     */       //   228: astore 12
/*     */       //   230: aload 5
/*     */       //   232: invokevirtual 29	java/io/OutputStream:close	()V
/*     */       //   235: aload 12
/*     */       //   237: athrow
/*     */       // Line number table:
/*     */       //   Java source line #55	-> byte code offset #0
/*     */       //   Java source line #56	-> byte code offset #19
/*     */       //   Java source line #57	-> byte code offset #25
/*     */       //   Java source line #58	-> byte code offset #31
/*     */       //   Java source line #59	-> byte code offset #37
/*     */       //   Java source line #62	-> byte code offset #51
/*     */       //   Java source line #63	-> byte code offset #62
/*     */       //   Java source line #64	-> byte code offset #68
/*     */       //   Java source line #65	-> byte code offset #74
/*     */       //   Java source line #66	-> byte code offset #81
/*     */       //   Java source line #67	-> byte code offset #88
/*     */       //   Java source line #68	-> byte code offset #94
/*     */       //   Java source line #70	-> byte code offset #99
/*     */       //   Java source line #73	-> byte code offset #113
/*     */       //   Java source line #74	-> byte code offset #124
/*     */       //   Java source line #75	-> byte code offset #131
/*     */       //   Java source line #76	-> byte code offset #141
/*     */       //   Java source line #77	-> byte code offset #148
/*     */       //   Java source line #87	-> byte code offset #152
/*     */       //   Java source line #92	-> byte code offset #157
/*     */       //   Java source line #79	-> byte code offset #165
/*     */       //   Java source line #81	-> byte code offset #167
/*     */       //   Java source line #82	-> byte code offset #196
/*     */       //   Java source line #83	-> byte code offset #215
/*     */       //   Java source line #87	-> byte code offset #218
/*     */       //   Java source line #92	-> byte code offset #228
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	238	0	this	CauchoServiceProxy
/*     */       //   0	238	1	proxy	Object
/*     */       //   0	238	2	method	Method
/*     */       //   0	238	3	args	Object[]
/*     */       //   17	87	4	connection	java.net.URLConnection
/*     */       //   49	182	5	os	OutputStream
/*     */       //   60	30	6	output	CauchoOutput
/*     */       //   111	110	7	is	InputStream
/*     */       //   122	20	8	input	CauchoInput
/*     */       //   165	51	8	x	Throwable
/*     */       //   139	10	9	result	Object
/*     */       //   194	13	9	logger	mx4j.log.Logger
/*     */       //   150	13	10	localObject1	Object
/*     */       //   218	8	11	localObject2	Object
/*     */       //   228	8	12	localObject3	Object
/*     */       // Exception table:
/*     */       //   from	to	target	type
/*     */       //   113	152	165	java/lang/Throwable
/*     */       //   113	152	218	finally
/*     */       //   165	220	218	finally
/*     */       //   51	157	228	finally
/*     */       //   165	230	228	finally
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/CauchoClientInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */