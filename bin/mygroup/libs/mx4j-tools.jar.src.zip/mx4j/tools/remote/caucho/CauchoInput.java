package mx4j.tools.remote.caucho;

import java.io.IOException;

public abstract interface CauchoInput
{
  public abstract void startCall()
    throws IOException;
  
  public abstract void completeCall()
    throws IOException;
  
  public abstract String readHeader()
    throws IOException;
  
  public abstract String readMethod()
    throws IOException;
  
  public abstract Object readObject(Class paramClass)
    throws IOException;
  
  public abstract void startReply()
    throws Exception;
  
  public abstract void completeReply()
    throws IOException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/CauchoInput.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */