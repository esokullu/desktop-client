/*    */ package mx4j.tools.remote.caucho.hessian;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.servlet.ServletException;
/*    */ import mx4j.tools.remote.caucho.CauchoInput;
/*    */ import mx4j.tools.remote.caucho.CauchoOutput;
/*    */ import mx4j.tools.remote.caucho.CauchoService;
/*    */ import mx4j.tools.remote.caucho.CauchoServlet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HessianServlet
/*    */   extends CauchoServlet
/*    */ {
/*    */   private CauchoService service;
/*    */   
/*    */   public void init()
/*    */     throws ServletException
/*    */   {
/* 29 */     super.init();
/* 30 */     this.service = new CauchoService("hessian");
/*    */   }
/*    */   
/*    */   public void destroy()
/*    */   {
/* 35 */     this.service = null;
/*    */   }
/*    */   
/*    */   protected Object getService()
/*    */   {
/* 40 */     return this.service;
/*    */   }
/*    */   
/*    */   protected CauchoInput createCauchoInput(InputStream stream)
/*    */   {
/* 45 */     return new HessianCauchoInput(stream);
/*    */   }
/*    */   
/*    */   protected CauchoOutput createCauchoOutput(OutputStream stream)
/*    */   {
/* 50 */     return new HessianCauchoOutput(stream);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/hessian/HessianServlet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */