/*    */ package mx4j.tools.remote.caucho.serialization;
/*    */ 
/*    */ import com.caucho.hessian.io.Deserializer;
/*    */ import com.caucho.hessian.io.Serializer;
/*    */ import com.caucho.hessian.io.SerializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMXSerializerFactory
/*    */   extends SerializerFactory
/*    */ {
/*    */   protected Serializer getDefaultSerializer(Class cls)
/*    */   {
/* 22 */     if (!cls.getName().startsWith("javax.management.")) return super.getDefaultSerializer(cls);
/* 23 */     return new JMXSerializer();
/*    */   }
/*    */   
/*    */   protected Deserializer getDefaultDeserializer(Class cls)
/*    */   {
/* 28 */     if (!cls.getName().startsWith("javax.management.")) { return super.getDefaultDeserializer(cls);
/*    */     }
/* 30 */     if (Throwable.class.isAssignableFrom(cls)) return super.getDefaultDeserializer(cls);
/* 31 */     return new JMXDeserializer();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/serialization/JMXSerializerFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */