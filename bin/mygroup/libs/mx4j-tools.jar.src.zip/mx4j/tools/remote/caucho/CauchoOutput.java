package mx4j.tools.remote.caucho;

import java.io.IOException;

public abstract interface CauchoOutput
{
  public abstract void startCall()
    throws IOException;
  
  public abstract void completeCall()
    throws IOException;
  
  public abstract void startReply()
    throws IOException;
  
  public abstract void completeReply()
    throws IOException;
  
  public abstract void writeHeader(String paramString)
    throws IOException;
  
  public abstract void writeMethod(String paramString)
    throws IOException;
  
  public abstract void writeObject(Object paramObject)
    throws IOException;
  
  public abstract void writeFault(Throwable paramThrowable)
    throws IOException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/CauchoOutput.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */