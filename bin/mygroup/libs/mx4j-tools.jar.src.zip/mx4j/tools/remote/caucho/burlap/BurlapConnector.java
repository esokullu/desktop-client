/*    */ package mx4j.tools.remote.caucho.burlap;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.management.MBeanServerConnection;
/*    */ import javax.management.remote.JMXServiceURL;
/*    */ import javax.security.auth.Subject;
/*    */ import mx4j.tools.remote.http.HTTPConnectionMBeanServerConnection;
/*    */ import mx4j.tools.remote.http.HTTPConnector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BurlapConnector
/*    */   extends HTTPConnector
/*    */ {
/*    */   public BurlapConnector(JMXServiceURL address, Map environment)
/*    */     throws IOException
/*    */   {
/* 35 */     super(address);
/*    */   }
/*    */   
/*    */   protected MBeanServerConnection doGetMBeanServerConnection(Subject delegate) throws IOException
/*    */   {
/* 40 */     return new HTTPConnectionMBeanServerConnection(getHTTPConnection(), delegate, getRemoteNotificationClientHandler());
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/burlap/BurlapConnector.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */