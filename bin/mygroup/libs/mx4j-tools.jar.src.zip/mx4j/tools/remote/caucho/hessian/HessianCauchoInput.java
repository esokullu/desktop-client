/*    */ package mx4j.tools.remote.caucho.hessian;
/*    */ 
/*    */ import com.caucho.hessian.io.HessianInput;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import mx4j.tools.remote.caucho.CauchoInput;
/*    */ import mx4j.tools.remote.caucho.serialization.JMXSerializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HessianCauchoInput
/*    */   implements CauchoInput
/*    */ {
/*    */   private final HessianInput input;
/*    */   
/*    */   HessianCauchoInput(InputStream stream)
/*    */   {
/* 27 */     this.input = new HessianInput();
/* 28 */     this.input.setSerializerFactory(new JMXSerializerFactory());
/* 29 */     this.input.init(stream);
/*    */   }
/*    */   
/*    */   public void startCall() throws IOException
/*    */   {
/* 34 */     this.input.readCall();
/*    */   }
/*    */   
/*    */   public void completeCall() throws IOException
/*    */   {
/* 39 */     this.input.completeCall();
/*    */   }
/*    */   
/*    */   public void startReply() throws Exception
/*    */   {
/*    */     try
/*    */     {
/* 46 */       this.input.startReply();
/*    */     }
/*    */     catch (Throwable x)
/*    */     {
/* 50 */       if ((x instanceof Exception)) throw ((Exception)x);
/* 51 */       throw ((Error)x);
/*    */     }
/*    */   }
/*    */   
/*    */   public void completeReply() throws IOException
/*    */   {
/* 57 */     this.input.completeReply();
/*    */   }
/*    */   
/*    */   public String readHeader() throws IOException
/*    */   {
/* 62 */     return this.input.readHeader();
/*    */   }
/*    */   
/*    */   public String readMethod() throws IOException
/*    */   {
/* 67 */     return this.input.readMethod();
/*    */   }
/*    */   
/*    */   public Object readObject(Class cls) throws IOException
/*    */   {
/* 72 */     return cls == null ? this.input.readObject() : this.input.readObject(cls);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/hessian/HessianCauchoInput.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */