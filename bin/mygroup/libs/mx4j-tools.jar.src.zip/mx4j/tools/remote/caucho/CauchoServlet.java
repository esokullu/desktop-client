/*     */ package mx4j.tools.remote.caucho;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import mx4j.tools.remote.http.HTTPConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CauchoServlet
/*     */   extends HttpServlet
/*     */ {
/*     */   private Map methods;
/*     */   
/*     */   public void init()
/*     */     throws ServletException
/*     */   {
/*  36 */     this.methods = new HashMap();
/*  37 */     mapMethods(HTTPConnection.class, this.methods);
/*     */   }
/*     */   
/*     */   protected void mapMethods(Class cls, Map methods)
/*     */   {
/*  42 */     Method[] mthds = cls.getMethods();
/*  43 */     for (int i = 0; i < mthds.length; i++)
/*     */     {
/*  45 */       Method mthd = mthds[i];
/*  46 */       String key = mangleMethodName(mthd);
/*  47 */       methods.put(key, mthd);
/*     */     }
/*     */   }
/*     */   
/*     */   protected Method findMethod(String methodName)
/*     */   {
/*  53 */     return (Method)this.methods.get(methodName);
/*     */   }
/*     */   
/*     */   protected String mangleMethodName(Method method)
/*     */   {
/*  58 */     return CauchoService.mangleMethodName(method);
/*     */   }
/*     */   
/*     */   protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
/*     */   {
/*  63 */     if (!"POST".equalsIgnoreCase(request.getMethod())) { throw new ServletException("Caucho protocol requires POST");
/*     */     }
/*  65 */     BufferedInputStream is = new BufferedInputStream(request.getInputStream(), 48);
/*  66 */     CauchoInput input = createCauchoInput(is);
/*  67 */     BufferedOutputStream bos = new BufferedOutputStream(response.getOutputStream(), 48);
/*  68 */     CauchoOutput output = createCauchoOutput(bos);
/*     */     
/*  70 */     invoke(request, input, output);
/*     */     
/*  72 */     bos.flush();
/*     */   }
/*     */   
/*     */   protected abstract CauchoInput createCauchoInput(InputStream paramInputStream);
/*     */   
/*     */   protected abstract CauchoOutput createCauchoOutput(OutputStream paramOutputStream);
/*     */   
/*     */   protected abstract Object getService();
/*     */   
/*     */   protected void invoke(HttpServletRequest request, CauchoInput input, CauchoOutput output) throws IOException
/*     */   {
/*  83 */     input.startCall();
/*  84 */     Map headers = readHeaders(input);
/*  85 */     String methodName = input.readMethod();
/*  86 */     Method method = findMethod(methodName);
/*  87 */     if (method == null)
/*     */     {
/*  89 */       output.startReply();
/*  90 */       NoSuchMethodException x = new NoSuchMethodException(methodName);
/*  91 */       output.writeFault(x);
/*  92 */       output.completeReply();
/*     */     }
/*     */     else
/*     */     {
/*  96 */       Object[] values = readArguments(input, method);
/*  97 */       input.completeCall();
/*     */       
/*  99 */       Object result = null;
/*     */       try
/*     */       {
/* 102 */         result = invoke(request.getRequestURL().toString(), getService(), method, headers, values);
/*     */       }
/*     */       catch (Throwable x)
/*     */       {
/* 106 */         output.startReply();
/* 107 */         output.writeFault(x);
/* 108 */         output.completeReply();
/* 109 */         return;
/*     */       }
/* 111 */       output.startReply();
/* 112 */       output.writeObject(result);
/* 113 */       output.completeReply();
/*     */     }
/*     */   }
/*     */   
/*     */   protected Map readHeaders(CauchoInput input) throws IOException
/*     */   {
/* 119 */     Map headers = new HashMap();
/* 120 */     String header = null;
/* 121 */     while ((header = input.readHeader()) != null) headers.put(header, input.readObject(null));
/* 122 */     return headers;
/*     */   }
/*     */   
/*     */   protected Object[] readArguments(CauchoInput input, Method method) throws IOException
/*     */   {
/* 127 */     Class[] types = method.getParameterTypes();
/* 128 */     Object[] values = new Object[types.length];
/* 129 */     for (int i = 0; i < types.length; i++) values[i] = input.readObject(types[i]);
/* 130 */     return values;
/*     */   }
/*     */   
/*     */   protected Object invoke(String url, Object target, Method method, Map headers, Object[] values) throws Exception
/*     */   {
/* 135 */     if (target == null) throw new IOException("Service is not available");
/* 136 */     String connectionId = (String)headers.get("connectionContext");
/* 137 */     CauchoService.setConnectionContext(url, connectionId);
/*     */     try
/*     */     {
/* 140 */       return method.invoke(target, values);
/*     */     }
/*     */     catch (InvocationTargetException x)
/*     */     {
/* 144 */       Throwable t = x.getTargetException();
/* 145 */       if ((t instanceof Exception)) throw ((Exception)t);
/* 146 */       throw ((Error)t);
/*     */     }
/*     */     finally
/*     */     {
/* 150 */       CauchoService.resetConnectionContext();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/CauchoServlet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */