/*    */ package mx4j.tools.remote.caucho.hessian;
/*    */ 
/*    */ import com.caucho.hessian.io.HessianOutput;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import mx4j.tools.remote.caucho.CauchoOutput;
/*    */ import mx4j.tools.remote.caucho.serialization.JMXSerializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HessianCauchoOutput
/*    */   implements CauchoOutput
/*    */ {
/*    */   private final OutputStream stream;
/*    */   private final HessianOutput output;
/*    */   
/*    */   HessianCauchoOutput(OutputStream stream)
/*    */   {
/* 28 */     this.stream = stream;
/* 29 */     this.output = new HessianOutput();
/* 30 */     this.output.setSerializerFactory(new JMXSerializerFactory());
/* 31 */     this.output.init(stream);
/*    */   }
/*    */   
/*    */   public void startReply() throws IOException
/*    */   {
/* 36 */     this.output.startReply();
/*    */   }
/*    */   
/*    */   public void completeReply() throws IOException
/*    */   {
/* 41 */     this.output.completeReply();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void startCall()
/*    */     throws IOException
/*    */   {
/* 53 */     this.stream.write(99);
/* 54 */     this.stream.write(0);
/* 55 */     this.stream.write(1);
/*    */   }
/*    */   
/*    */   public void completeCall() throws IOException
/*    */   {
/* 60 */     this.output.completeCall();
/*    */   }
/*    */   
/*    */   public void writeHeader(String header) throws IOException
/*    */   {
/* 65 */     this.output.writeHeader(header);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void writeMethod(String methodName)
/*    */     throws IOException
/*    */   {
/* 73 */     this.stream.write(109);
/* 74 */     int len = methodName.length();
/* 75 */     this.stream.write(len >> 8);
/* 76 */     this.stream.write(len);
/* 77 */     this.output.printString(methodName, 0, len);
/*    */   }
/*    */   
/*    */   public void writeObject(Object object) throws IOException
/*    */   {
/* 82 */     this.output.writeObject(object);
/*    */   }
/*    */   
/*    */   public void writeFault(Throwable fault) throws IOException
/*    */   {
/* 87 */     this.output.writeFault(fault.getClass().getName(), fault.getMessage(), fault);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/caucho/hessian/HessianCauchoOutput.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */