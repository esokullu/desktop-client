/*     */ package mx4j.tools.remote;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.security.auth.Subject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JMXConnectionHandler
/*     */   extends AbstractConnection
/*     */   implements JMXConnection
/*     */ {
/*     */   private final JMXConnection connection;
/*     */   private volatile boolean closed;
/*     */   
/*     */   public JMXConnectionHandler(JMXConnection connection, ConnectionManager manager, String connectionId)
/*     */   {
/*  45 */     super(connectionId, manager);
/*  46 */     this.connection = connection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*  55 */     if (isClosed()) return;
/*  56 */     this.closed = true;
/*  57 */     getConnection().close();
/*  58 */     super.close();
/*     */   }
/*     */   
/*     */   protected boolean isClosed()
/*     */   {
/*  63 */     return this.closed;
/*     */   }
/*     */   
/*     */   protected JMXConnection getConnection()
/*     */   {
/*  68 */     return this.connection;
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName name, Object params, String[] signature, Subject delegate) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException
/*     */   {
/*  73 */     if (isClosed()) throw new IOException("Connection has been closed");
/*  74 */     return getConnection().createMBean(className, name, params, signature, delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName name, ObjectName loaderName, Object params, String[] signature, Subject delegate) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException
/*     */   {
/*  79 */     if (isClosed()) throw new IOException("Connection has been closed");
/*  80 */     return getConnection().createMBean(className, name, loaderName, params, signature, delegate);
/*     */   }
/*     */   
/*     */   public void unregisterMBean(ObjectName name, Subject delegate) throws InstanceNotFoundException, MBeanRegistrationException, IOException
/*     */   {
/*  85 */     if (isClosed()) throw new IOException("Connection has been closed");
/*  86 */     getConnection().unregisterMBean(name, delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance getObjectInstance(ObjectName name, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/*  91 */     if (isClosed()) throw new IOException("Connection has been closed");
/*  92 */     return getConnection().getObjectInstance(name, delegate);
/*     */   }
/*     */   
/*     */   public Set queryMBeans(ObjectName name, Object query, Subject delegate) throws IOException
/*     */   {
/*  97 */     if (isClosed()) throw new IOException("Connection has been closed");
/*  98 */     return getConnection().queryMBeans(name, query, delegate);
/*     */   }
/*     */   
/*     */   public Set queryNames(ObjectName name, Object query, Subject delegate) throws IOException
/*     */   {
/* 103 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 104 */     return getConnection().queryNames(name, query, delegate);
/*     */   }
/*     */   
/*     */   public boolean isRegistered(ObjectName name, Subject delegate) throws IOException
/*     */   {
/* 109 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 110 */     return getConnection().isRegistered(name, delegate);
/*     */   }
/*     */   
/*     */   public Integer getMBeanCount(Subject delegate) throws IOException
/*     */   {
/* 115 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 116 */     return getConnection().getMBeanCount(delegate);
/*     */   }
/*     */   
/*     */   public Object getAttribute(ObjectName name, String attribute, Subject delegate) throws MBeanException, AttributeNotFoundException, InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 121 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 122 */     return getConnection().getAttribute(name, attribute, delegate);
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(ObjectName name, String[] attributes, Subject delegate) throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 127 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 128 */     return getConnection().getAttributes(name, attributes, delegate);
/*     */   }
/*     */   
/*     */   public void setAttribute(ObjectName name, Object attribute, Subject delegate) throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException, IOException
/*     */   {
/* 133 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 134 */     getConnection().setAttribute(name, attribute, delegate);
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(ObjectName name, Object attributes, Subject delegate) throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 139 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 140 */     return getConnection().setAttributes(name, attributes, delegate);
/*     */   }
/*     */   
/*     */   public Object invoke(ObjectName name, String operationName, Object params, String[] signature, Subject delegate) throws InstanceNotFoundException, MBeanException, ReflectionException, IOException
/*     */   {
/* 145 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 146 */     return getConnection().invoke(name, operationName, params, signature, delegate);
/*     */   }
/*     */   
/*     */   public String getDefaultDomain(Subject delegate) throws IOException
/*     */   {
/* 151 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 152 */     return getConnection().getDefaultDomain(delegate);
/*     */   }
/*     */   
/*     */   public String[] getDomains(Subject delegate) throws IOException
/*     */   {
/* 157 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 158 */     return getConnection().getDomains(delegate);
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo(ObjectName name, Subject delegate) throws InstanceNotFoundException, IntrospectionException, ReflectionException, IOException
/*     */   {
/* 163 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 164 */     return getConnection().getMBeanInfo(name, delegate);
/*     */   }
/*     */   
/*     */   public boolean isInstanceOf(ObjectName name, String className, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 169 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 170 */     return getConnection().isInstanceOf(name, className, delegate);
/*     */   }
/*     */   
/*     */   public void addNotificationListener(ObjectName name, ObjectName listener, Object filter, Object handback, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 175 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 176 */     getConnection().addNotificationListener(name, listener, filter, handback, delegate);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName name, ObjectName listener, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 181 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 182 */     getConnection().removeNotificationListener(name, listener, delegate);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName name, ObjectName listener, Object filter, Object handback, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 187 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 188 */     getConnection().removeNotificationListener(name, listener, filter, handback, delegate);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/JMXConnectionHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */