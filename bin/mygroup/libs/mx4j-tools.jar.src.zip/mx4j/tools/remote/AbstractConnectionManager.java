/*     */ package mx4j.tools.remote;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.management.remote.JMXAuthenticator;
/*     */ import javax.security.auth.Subject;
/*     */ import mx4j.remote.MX4JRemoteUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractConnectionManager
/*     */   implements ConnectionManager
/*     */ {
/*     */   private final AbstractJMXConnectorServer server;
/*     */   private final Map environment;
/*     */   private final AccessControlContext context;
/*  35 */   private final Map connections = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   private volatile boolean closed;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractConnectionManager(AbstractJMXConnectorServer server, Map environment)
/*     */   {
/*  46 */     this.server = server;
/*  47 */     this.environment = environment;
/*  48 */     this.context = AccessController.getContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Connection connect(Object credentials)
/*     */     throws IOException, SecurityException
/*     */   {
/*  61 */     if (isClosed()) { throw new IOException("This connection manager is already closed " + this);
/*     */     }
/*  63 */     Subject subject = authenticate(credentials);
/*  64 */     String connectionId = createConnectionID(subject);
/*     */     
/*  66 */     Connection client = doConnect(connectionId, subject);
/*  67 */     WeakReference weak = new WeakReference(client);
/*     */     
/*  69 */     synchronized (this.connections)
/*     */     {
/*  71 */       this.connections.put(connectionId, weak);
/*     */     }
/*     */     
/*  74 */     this.server.connectionOpened(connectionId, "Connection opened " + client, null);
/*     */     
/*  76 */     return client;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String createConnectionID(Subject subject)
/*     */   {
/*  86 */     return MX4JRemoteUtils.createConnectionID(getProtocol(), null, -1, subject);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract Connection doConnect(String paramString, Subject paramSubject)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void close()
/*     */     throws IOException
/*     */   {
/* 111 */     if (isClosed()) return;
/* 112 */     this.closed = true;
/* 113 */     doClose();
/* 114 */     closeConnections();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract void doClose()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */   private void closeConnections()
/*     */     throws IOException
/*     */   {
/* 126 */     IOException clientException = null;
/* 127 */     synchronized (this.connections)
/*     */     {
/* 129 */       while (!this.connections.isEmpty())
/*     */       {
/*     */ 
/* 132 */         Iterator entries = this.connections.entrySet().iterator();
/* 133 */         Map.Entry entry = (Map.Entry)entries.next();
/* 134 */         WeakReference weak = (WeakReference)entry.getValue();
/* 135 */         Connection connection = (Connection)weak.get();
/* 136 */         if (connection == null)
/*     */         {
/*     */ 
/* 139 */           entries.remove();
/*     */         }
/*     */         else
/*     */         {
/*     */           try
/*     */           {
/*     */ 
/* 146 */             connection.close();
/*     */           }
/*     */           catch (IOException x)
/*     */           {
/* 150 */             if (clientException == null) clientException = x;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 155 */     if (clientException != null) { throw clientException;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void closeConnection(Connection connection)
/*     */     throws IOException
/*     */   {
/* 167 */     String connectionID = connection.getConnectionId();
/* 168 */     WeakReference weak = null;
/* 169 */     synchronized (this.connections)
/*     */     {
/* 171 */       weak = (WeakReference)this.connections.remove(connectionID);
/*     */     }
/*     */     
/* 174 */     if (weak == null) { return;
/*     */     }
/* 176 */     Connection client = (Connection)weak.get();
/* 177 */     if (connection != client) { throw new IOException("Could not find active connection " + connection + ", expecting " + client);
/*     */     }
/* 179 */     doCloseConnection(connection);
/*     */     
/* 181 */     this.server.connectionClosed(connectionID, "Closed connection " + connection, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void doCloseConnection(Connection paramConnection)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isClosed()
/*     */   {
/* 194 */     return this.closed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map getEnvironment()
/*     */   {
/* 202 */     return this.environment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AccessControlContext getSecurityContext()
/*     */   {
/* 212 */     return this.context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Subject authenticate(Object credentials)
/*     */     throws IOException, SecurityException
/*     */   {
/* 221 */     Map environment = getEnvironment();
/* 222 */     if (environment != null)
/*     */     {
/* 224 */       JMXAuthenticator authenticator = (JMXAuthenticator)environment.get("jmx.remote.authenticator");
/* 225 */       if (authenticator != null)
/*     */       {
/* 227 */         return authenticator.authenticate(credentials);
/*     */       }
/*     */     }
/* 230 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/AbstractConnectionManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */