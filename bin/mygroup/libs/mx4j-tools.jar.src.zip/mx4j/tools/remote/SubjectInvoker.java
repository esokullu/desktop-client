/*    */ package mx4j.tools.remote;
/*    */ 
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.security.AccessControlContext;
/*    */ import java.security.PrivilegedExceptionAction;
/*    */ import java.util.Map;
/*    */ import javax.management.remote.JMXServerErrorException;
/*    */ import javax.security.auth.Subject;
/*    */ import mx4j.remote.MX4JRemoteUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SubjectInvoker
/*    */   implements InvocationHandler
/*    */ {
/*    */   private final Object target;
/*    */   private final Subject subject;
/*    */   private final AccessControlContext context;
/*    */   private Map environment;
/*    */   
/*    */   protected SubjectInvoker(Object target, Subject subject, AccessControlContext context, Map environment)
/*    */   {
/* 34 */     this.target = target;
/* 35 */     this.subject = subject;
/* 36 */     this.context = context;
/* 37 */     this.environment = environment;
/*    */   }
/*    */   
/*    */   protected boolean isPlainInvoke(Method method)
/*    */   {
/* 42 */     String methodName = method.getName();
/*    */     
/* 44 */     if ("toString".equals(methodName)) return true;
/* 45 */     if ("hashCode".equals(methodName)) return true;
/* 46 */     if ("equals".equals(methodName)) return true;
/* 47 */     return false;
/*    */   }
/*    */   
/*    */   protected Object handleSpecialInvoke(Object target, Method method, Object[] args) throws Exception
/*    */   {
/* 52 */     throw new NoSuchMethodException(method.toString());
/*    */   }
/*    */   
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*    */   {
/* 57 */     if (isPlainInvoke(method)) return chain(this.target, method, args);
/* 58 */     if (method.getParameterTypes()[(args.length - 1)] == Subject.class)
/*    */     {
/* 60 */       Subject delegate = (Subject)args[(args.length - 1)];
/* 61 */       return subjectInvoke(this.target, method, args, delegate);
/*    */     }
/*    */     
/*    */ 
/* 65 */     return handleSpecialInvoke(this.target, method, args);
/*    */   }
/*    */   
/*    */   protected Object subjectInvoke(Object proxy, Method method, Object[] args, Subject delegate)
/*    */     throws Exception
/*    */   {
/* 71 */     MX4JRemoteUtils.subjectInvoke(this.subject, delegate, this.context, this.environment, new PrivilegedExceptionAction() { private final Object val$proxy;
/*    */       private final Method val$method;
/*    */       private final Object[] val$args;
/*    */       
/* 75 */       public Object run() throws Exception { return SubjectInvoker.this.chain(this.val$proxy, this.val$method, this.val$args); }
/*    */     });
/*    */   }
/*    */   
/*    */   protected Object chain(Object proxy, Method method, Object[] args)
/*    */     throws Exception
/*    */   {
/*    */     try
/*    */     {
/* 84 */       return method.invoke(proxy, args);
/*    */     }
/*    */     catch (InvocationTargetException x)
/*    */     {
/* 88 */       Throwable t = x.getTargetException();
/* 89 */       if ((t instanceof Exception)) throw ((Exception)t);
/* 90 */       throw new JMXServerErrorException("Error thrown during invocation", (Error)t);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/SubjectInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */