/*    */ package mx4j.tools.remote;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractConnection
/*    */   implements Connection
/*    */ {
/*    */   private final String connectionId;
/*    */   private final ConnectionManager manager;
/*    */   
/*    */   protected AbstractConnection(String connectionId, ConnectionManager manager)
/*    */   {
/* 25 */     this.connectionId = connectionId;
/* 26 */     this.manager = manager;
/*    */   }
/*    */   
/*    */   public void close() throws IOException
/*    */   {
/* 31 */     this.manager.closeConnection(this);
/*    */   }
/*    */   
/*    */   public String getConnectionId() throws IOException
/*    */   {
/* 36 */     return this.connectionId;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/AbstractConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */