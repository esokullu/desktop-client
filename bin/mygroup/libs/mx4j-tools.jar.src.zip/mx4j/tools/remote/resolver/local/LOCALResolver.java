/*     */ package mx4j.tools.remote.resolver.local;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MBeanServerFactory;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import mx4j.remote.ConnectionResolver;
/*     */ import mx4j.tools.remote.local.LocalConnectorServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LOCALResolver
/*     */   extends ConnectionResolver
/*     */ {
/*     */   private static final String ID_CONTEXT = "/id/";
/*     */   private static int connectorID;
/*  32 */   private final Map mbeanServerIds = new HashMap();
/*     */   
/*     */   public Object createServer(JMXServiceURL url, Map environment) throws IOException
/*     */   {
/*  36 */     String connectorID = findConnectorID(url);
/*  37 */     if (connectorID == null) { return null;
/*     */     }
/*  39 */     String mbeanServerId = findMBeanServerId(connectorID);
/*  40 */     if (mbeanServerId == null) { return null;
/*     */     }
/*  42 */     List servers = MBeanServerFactory.findMBeanServer(mbeanServerId);
/*  43 */     if (servers.size() == 1) return servers.get(0);
/*  44 */     return null;
/*     */   }
/*     */   
/*     */   private String findConnectorID(JMXServiceURL url)
/*     */   {
/*  49 */     String path = url.getURLPath();
/*  50 */     if ((path == null) || (!path.startsWith("/id/"))) return null;
/*  51 */     return path.substring("/id/".length());
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private String findMBeanServerId(String connectorID)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 9	mx4j/tools/remote/resolver/local/LOCALResolver:mbeanServerIds	Ljava/util/Map;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 9	mx4j/tools/remote/resolver/local/LOCALResolver:mbeanServerIds	Ljava/util/Map;
/*     */     //   11: aload_1
/*     */     //   12: invokeinterface 20 2 0
/*     */     //   17: checkcast 21	java/lang/String
/*     */     //   20: aload_2
/*     */     //   21: monitorexit
/*     */     //   22: areturn
/*     */     //   23: astore_3
/*     */     //   24: aload_2
/*     */     //   25: monitorexit
/*     */     //   26: aload_3
/*     */     //   27: athrow
/*     */     // Line number table:
/*     */     //   Java source line #56	-> byte code offset #0
/*     */     //   Java source line #58	-> byte code offset #7
/*     */     //   Java source line #59	-> byte code offset #23
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	28	0	this	LOCALResolver
/*     */     //   0	28	1	connectorID	String
/*     */     //   5	20	2	Ljava/lang/Object;	Object
/*     */     //   23	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	22	23	finally
/*     */     //   23	26	23	finally
/*     */   }
/*     */   
/*     */   public JMXServiceURL bindServer(Object server, JMXServiceURL url, Map environment)
/*     */     throws IOException
/*     */   {
/*  64 */     String connectorID = findConnectorID(url);
/*  65 */     if (connectorID == null) { connectorID = generateConnectorID();
/*     */     }
/*  67 */     MBeanServer mbeanServer = (MBeanServer)server;
/*     */     try
/*     */     {
/*  70 */       String mbeanServerId = (String)mbeanServer.getAttribute(new ObjectName("JMImplementation:type=MBeanServerDelegate"), "MBeanServerId");
/*  71 */       synchronized (this.mbeanServerIds)
/*     */       {
/*  73 */         String existing = findMBeanServerId(connectorID);
/*  74 */         if ((existing != null) && (!existing.equals(mbeanServerId))) throw new IOException("LocalConnectorServer with ID " + connectorID + " is already attached to MBeanServer with ID " + existing);
/*  75 */         this.mbeanServerIds.put(connectorID, mbeanServerId);
/*     */       }
/*     */     }
/*     */     catch (JMException x)
/*     */     {
/*  80 */       throw new IOException("Cannot retrieve MBeanServer ID " + x.toString());
/*     */     }
/*     */     
/*  83 */     return new JMXServiceURL(url.getProtocol(), url.getHost(), url.getPort(), "/id/" + connectorID);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private String generateConnectorID()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 47	mx4j/tools/remote/resolver/local/LOCALResolver:class$mx4j$tools$remote$resolver$local$LOCALResolver	Ljava/lang/Class;
/*     */     //   3: ifnonnull +15 -> 18
/*     */     //   6: ldc 48
/*     */     //   8: invokestatic 49	mx4j/tools/remote/resolver/local/LOCALResolver:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   11: dup
/*     */     //   12: putstatic 47	mx4j/tools/remote/resolver/local/LOCALResolver:class$mx4j$tools$remote$resolver$local$LOCALResolver	Ljava/lang/Class;
/*     */     //   15: goto +6 -> 21
/*     */     //   18: getstatic 47	mx4j/tools/remote/resolver/local/LOCALResolver:class$mx4j$tools$remote$resolver$local$LOCALResolver	Ljava/lang/Class;
/*     */     //   21: dup
/*     */     //   22: astore_1
/*     */     //   23: monitorenter
/*     */     //   24: getstatic 50	mx4j/tools/remote/resolver/local/LOCALResolver:connectorID	I
/*     */     //   27: iconst_1
/*     */     //   28: iadd
/*     */     //   29: dup
/*     */     //   30: putstatic 50	mx4j/tools/remote/resolver/local/LOCALResolver:connectorID	I
/*     */     //   33: invokestatic 51	java/lang/String:valueOf	(I)Ljava/lang/String;
/*     */     //   36: aload_1
/*     */     //   37: monitorexit
/*     */     //   38: areturn
/*     */     //   39: astore_2
/*     */     //   40: aload_1
/*     */     //   41: monitorexit
/*     */     //   42: aload_2
/*     */     //   43: athrow
/*     */     // Line number table:
/*     */     //   Java source line #88	-> byte code offset #0
/*     */     //   Java source line #90	-> byte code offset #24
/*     */     //   Java source line #91	-> byte code offset #39
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	44	0	this	LOCALResolver
/*     */     //   22	19	1	Ljava/lang/Object;	Object
/*     */     //   39	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   24	38	39	finally
/*     */     //   39	42	39	finally
/*     */   }
/*     */   
/*     */   public void unbindServer(Object server, JMXServiceURL address, Map environment)
/*     */     throws IOException
/*     */   {
/*  96 */     String connectorID = findConnectorID(address);
/*  97 */     if (connectorID == null) throw new IOException("Unknown LocalConnectorServer ID: " + address);
/*  98 */     synchronized (this.mbeanServerIds)
/*     */     {
/* 100 */       this.mbeanServerIds.remove(connectorID);
/*     */     }
/*     */   }
/*     */   
/*     */   public void destroyServer(Object server, JMXServiceURL url, Map environment)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */   public Object lookupClient(JMXServiceURL url, Map environment) throws IOException
/*     */   {
/* 110 */     return LocalConnectorServer.find(url);
/*     */   }
/*     */   
/*     */   public Object bindClient(Object client, Map environment) throws IOException
/*     */   {
/* 115 */     return client;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/resolver/local/LOCALResolver.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */