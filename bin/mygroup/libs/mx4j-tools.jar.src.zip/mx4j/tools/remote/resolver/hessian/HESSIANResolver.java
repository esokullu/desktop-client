/*    */ package mx4j.tools.remote.resolver.hessian;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.management.remote.JMXServiceURL;
/*    */ import mx4j.tools.remote.caucho.hessian.HessianClientInvoker;
/*    */ import mx4j.tools.remote.caucho.hessian.HessianServlet;
/*    */ import mx4j.tools.remote.http.HTTPResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HESSIANResolver
/*    */   extends HTTPResolver
/*    */ {
/*    */   public Object lookupClient(JMXServiceURL url, Map environment)
/*    */     throws IOException
/*    */   {
/* 26 */     String endpoint = getEndpoint(url, environment);
/* 27 */     return new HessianClientInvoker(endpoint);
/*    */   }
/*    */   
/*    */   protected String getServletClassName()
/*    */   {
/* 32 */     return HessianServlet.class.getName();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/resolver/hessian/HESSIANResolver.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */