/*    */ package mx4j.tools.remote.resolver.burlap;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.management.remote.JMXServiceURL;
/*    */ import mx4j.tools.remote.caucho.burlap.BurlapClientInvoker;
/*    */ import mx4j.tools.remote.caucho.burlap.BurlapServlet;
/*    */ import mx4j.tools.remote.http.HTTPResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BURLAPResolver
/*    */   extends HTTPResolver
/*    */ {
/*    */   public Object lookupClient(JMXServiceURL url, Map environment)
/*    */     throws IOException
/*    */   {
/* 26 */     String endpoint = getEndpoint(url, environment);
/* 27 */     return new BurlapClientInvoker(endpoint);
/*    */   }
/*    */   
/*    */   protected String getServletClassName()
/*    */   {
/* 32 */     return BurlapServlet.class.getName();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/resolver/burlap/BURLAPResolver.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */