/*     */ package mx4j.tools.remote.resolver.soap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import mx4j.log.Logger;
/*     */ import mx4j.tools.remote.http.HTTPResolver;
/*     */ import mx4j.tools.remote.soap.SOAPClientInvoker;
/*     */ import org.apache.axis.AxisProperties;
/*     */ import org.apache.axis.MessageContext;
/*     */ import org.apache.axis.client.AdminClient;
/*     */ import org.apache.axis.client.Call;
/*     */ import org.apache.axis.client.Service;
/*     */ import org.apache.axis.components.net.SecureSocketFactory;
/*     */ import org.apache.axis.components.net.SocketFactoryFactory;
/*     */ import org.apache.axis.configuration.FileProvider;
/*     */ import org.apache.axis.transport.http.AxisServlet;
/*     */ import org.apache.axis.utils.Options;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPResolver
/*     */   extends HTTPResolver
/*     */ {
/*     */   private static final String SERVER_DEPLOY_WSDD = "server-deploy.wsdd";
/*     */   private static final String SERVER_UNDEPLOY_WSDD = "server-undeploy.wsdd";
/*     */   private static final String CLIENT_WSDD = "client.wsdd";
/*     */   private static final String AXIS_DEPLOY_SERVICE = "AdminService";
/*     */   
/*     */   public Object lookupClient(JMXServiceURL address, Map environment)
/*     */     throws IOException
/*     */   {
/*  42 */     String endpoint = getEndpoint(address, environment);
/*     */     
/*  44 */     InputStream wsdd = getClass().getResourceAsStream("client.wsdd");
/*  45 */     if (wsdd == null) throw new IOException("Could not find AXIS deployment descriptor");
/*  46 */     Service service = new Service(new FileProvider(wsdd));
/*  47 */     service.setMaintainSession(true);
/*     */     
/*  49 */     return new SOAPClientInvoker(endpoint, service);
/*     */   }
/*     */   
/*     */   protected String getServletClassName()
/*     */   {
/*  54 */     return AxisServlet.class.getName();
/*     */   }
/*     */   
/*     */   protected void deploy(JMXServiceURL address, Map environment) throws IOException
/*     */   {
/*  59 */     String path = address.getURLPath();
/*  60 */     if (!path.endsWith("/")) path = path + "/";
/*  61 */     String deployPath = path + "AdminService";
/*     */     
/*  63 */     JMXServiceURL temp = new JMXServiceURL(address.getProtocol(), address.getHost(), address.getPort(), deployPath);
/*  64 */     String deployEndpoint = getEndpoint(temp, environment);
/*     */     
/*     */     try
/*     */     {
/*  68 */       if (deployEndpoint.startsWith("https://"))
/*     */       {
/*  70 */         String factory = (String)environment.get("jmx.remote.x.https.axis.socket.factory");
/*  71 */         if (factory != null)
/*     */         {
/*     */ 
/*  74 */           SocketFactoryFactory.getFactory("foo", null);
/*  75 */           AxisProperties.setClassDefault(SecureSocketFactory.class, factory);
/*     */         }
/*     */       }
/*  78 */       AdminClient deployer = new AdminClient();
/*  79 */       Options options = new Options(null);
/*  80 */       options.setDefaultURL(deployEndpoint);
/*  81 */       InputStream wsdd = getClass().getResourceAsStream("server-deploy.wsdd");
/*  82 */       if (wsdd == null) throw new IOException("Could not find AXIS deployment descriptor");
/*  83 */       deployer.getCall().getMessageContext().setProperty("keyStore", "foo");
/*  84 */       deployer.process(options, wsdd);
/*     */     }
/*     */     catch (RuntimeException x)
/*     */     {
/*  88 */       throw x;
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/*  92 */       Logger logger = getLogger();
/*  93 */       if (logger.isEnabledFor(20)) logger.info("Exception while deploying AXIS service", x);
/*  94 */       throw new IOException("Could not deploy SOAPConnectorServer to AXIS " + x.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void undeploy(JMXServiceURL address, Map environment) throws IOException
/*     */   {
/* 100 */     String path = address.getURLPath();
/* 101 */     if (!path.endsWith("/")) path = path + "/";
/* 102 */     String undeployPath = path + "AdminService";
/*     */     
/* 104 */     JMXServiceURL temp = new JMXServiceURL(address.getProtocol(), address.getHost(), address.getPort(), undeployPath);
/* 105 */     String undeployEndpoint = getEndpoint(temp, environment);
/*     */     
/*     */     try
/*     */     {
/* 109 */       AdminClient deployer = new AdminClient();
/* 110 */       Options options = new Options(null);
/* 111 */       options.setDefaultURL(undeployEndpoint);
/* 112 */       InputStream wsdd = getClass().getResourceAsStream("server-undeploy.wsdd");
/* 113 */       if (wsdd == null) throw new IOException("Could not find AXIS deployment descriptor server-undeploy.wsdd");
/* 114 */       deployer.process(options, wsdd);
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/* 118 */       Logger logger = getLogger();
/* 119 */       if (logger.isEnabledFor(20)) logger.info("Exception while undeploying AXIS service", x);
/* 120 */       throw new IOException("Could not undeploy SOAPConnectorServer " + x.toString());
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/resolver/soap/SOAPResolver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */