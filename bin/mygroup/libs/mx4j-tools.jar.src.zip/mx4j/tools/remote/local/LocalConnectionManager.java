/*    */ package mx4j.tools.remote.local;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.security.auth.Subject;
/*    */ import mx4j.tools.remote.AbstractConnectionManager;
/*    */ import mx4j.tools.remote.Connection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LocalConnectionManager
/*    */   extends AbstractConnectionManager
/*    */ {
/*    */   private final MBeanServer mbeanServer;
/*    */   
/*    */   LocalConnectionManager(LocalConnectorServer server, Map environment)
/*    */   {
/* 28 */     super(server, environment);
/* 29 */     this.mbeanServer = server.getMBeanServer();
/*    */   }
/*    */   
/*    */   public String getProtocol()
/*    */   {
/* 34 */     return "local";
/*    */   }
/*    */   
/*    */   public Connection doConnect(String connectionId, Subject subject) throws IOException
/*    */   {
/* 39 */     LocalConnection serverInvoker = new LocalServerInvoker(this.mbeanServer);
/* 40 */     LocalConnection subjectInvoker = LocalSubjectInvoker.newInstance(serverInvoker, subject, getSecurityContext(), getEnvironment());
/* 41 */     return new LocalConnectionHandler(connectionId, this, subjectInvoker);
/*    */   }
/*    */   
/*    */   protected void doClose()
/*    */     throws IOException
/*    */   {}
/*    */   
/*    */   protected void doCloseConnection(Connection connection)
/*    */     throws IOException
/*    */   {}
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/local/LocalConnectionManager.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */