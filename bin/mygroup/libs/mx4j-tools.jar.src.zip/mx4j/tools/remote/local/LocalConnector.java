/*    */ package mx4j.tools.remote.local;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.MalformedURLException;
/*    */ import java.util.Map;
/*    */ import javax.management.MBeanServerConnection;
/*    */ import javax.management.remote.JMXServiceURL;
/*    */ import javax.security.auth.Subject;
/*    */ import mx4j.remote.ConnectionResolver;
/*    */ import mx4j.tools.remote.AbstractJMXConnector;
/*    */ import mx4j.tools.remote.Connection;
/*    */ import mx4j.tools.remote.ConnectionManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalConnector
/*    */   extends AbstractJMXConnector
/*    */ {
/*    */   private transient Connection connection;
/*    */   
/*    */   public LocalConnector(JMXServiceURL url, Map environment)
/*    */     throws IOException
/*    */   {
/* 32 */     super(url);
/*    */   }
/*    */   
/*    */   protected void doConnect(Map environment) throws IOException, SecurityException
/*    */   {
/* 37 */     JMXServiceURL address = getAddress();
/* 38 */     String protocol = address.getProtocol();
/* 39 */     ConnectionResolver resolver = ConnectionResolver.newConnectionResolver(protocol, environment);
/* 40 */     if (resolver == null) { throw new MalformedURLException("Unsupported protocol: " + protocol);
/*    */     }
/* 42 */     ConnectionManager server = (ConnectionManager)resolver.lookupClient(address, environment);
/* 43 */     server = (ConnectionManager)resolver.bindClient(server, environment);
/*    */     
/* 45 */     Object credentials = environment == null ? null : environment.get("jmx.remote.credentials");
/* 46 */     this.connection = server.connect(credentials);
/*    */   }
/*    */   
/*    */   protected void doClose() throws IOException
/*    */   {
/* 51 */     this.connection.close();
/*    */   }
/*    */   
/*    */   protected MBeanServerConnection doGetMBeanServerConnection(Subject delegate) throws IOException
/*    */   {
/* 56 */     return new LocalConnectionMBeanServerConnection((LocalConnection)this.connection, delegate);
/*    */   }
/*    */   
/*    */   public String getConnectionId() throws IOException
/*    */   {
/* 61 */     return this.connection.getConnectionId();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/local/LocalConnector.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */