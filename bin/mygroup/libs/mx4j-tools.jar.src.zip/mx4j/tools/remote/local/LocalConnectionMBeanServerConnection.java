/*     */ package mx4j.tools.remote.local;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.QueryExp;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.security.auth.Subject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LocalConnectionMBeanServerConnection
/*     */   implements MBeanServerConnection
/*     */ {
/*     */   private final LocalConnection connection;
/*     */   private final Subject delegate;
/*     */   
/*     */   LocalConnectionMBeanServerConnection(LocalConnection connection, Subject delegate)
/*     */   {
/*  44 */     this.connection = connection;
/*  45 */     this.delegate = delegate;
/*     */   }
/*     */   
/*     */   public void addNotificationListener(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback)
/*     */     throws InstanceNotFoundException, IOException
/*     */   {
/*  51 */     this.connection.addNotificationListener(observed, listener, filter, handback, this.delegate);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName observed, NotificationListener listener)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/*  57 */     this.connection.removeNotificationListener(observed, listener, this.delegate);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/*  63 */     this.connection.removeNotificationListener(observed, listener, filter, handback, this.delegate);
/*     */   }
/*     */   
/*     */   public void addNotificationListener(ObjectName observed, ObjectName listener, NotificationFilter filter, Object handback)
/*     */     throws InstanceNotFoundException, IOException
/*     */   {
/*  69 */     this.connection.addNotificationListener(observed, listener, filter, handback, this.delegate);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName observed, ObjectName listener)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/*  75 */     this.connection.removeNotificationListener(observed, listener, this.delegate);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName observed, ObjectName listener, NotificationFilter filter, Object handback)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/*  81 */     this.connection.removeNotificationListener(observed, listener, filter, handback, this.delegate);
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo(ObjectName objectName)
/*     */     throws InstanceNotFoundException, IntrospectionException, ReflectionException, IOException
/*     */   {
/*  87 */     return this.connection.getMBeanInfo(objectName, this.delegate);
/*     */   }
/*     */   
/*     */   public boolean isInstanceOf(ObjectName objectName, String className)
/*     */     throws InstanceNotFoundException, IOException
/*     */   {
/*  93 */     return this.connection.isInstanceOf(objectName, className, this.delegate);
/*     */   }
/*     */   
/*     */   public String[] getDomains()
/*     */     throws IOException
/*     */   {
/*  99 */     return this.connection.getDomains(this.delegate);
/*     */   }
/*     */   
/*     */   public String getDefaultDomain()
/*     */     throws IOException
/*     */   {
/* 105 */     return this.connection.getDefaultDomain(this.delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException
/*     */   {
/* 111 */     return this.connection.createMBean(className, objectName, null, null, this.delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName, Object[] args, String[] parameters)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException
/*     */   {
/* 117 */     return this.connection.createMBean(className, objectName, args, parameters, this.delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName, ObjectName loaderName)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException
/*     */   {
/* 123 */     return this.connection.createMBean(className, objectName, loaderName, null, null, this.delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName, ObjectName loaderName, Object[] args, String[] parameters)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException
/*     */   {
/* 129 */     return this.connection.createMBean(className, objectName, loaderName, args, parameters, this.delegate);
/*     */   }
/*     */   
/*     */   public void unregisterMBean(ObjectName objectName)
/*     */     throws InstanceNotFoundException, MBeanRegistrationException, IOException
/*     */   {
/* 135 */     this.connection.unregisterMBean(objectName, this.delegate);
/*     */   }
/*     */   
/*     */   public Object getAttribute(ObjectName objectName, String attribute)
/*     */     throws MBeanException, AttributeNotFoundException, InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 141 */     return this.connection.getAttribute(objectName, attribute, this.delegate);
/*     */   }
/*     */   
/*     */   public void setAttribute(ObjectName objectName, Attribute attribute)
/*     */     throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException, IOException
/*     */   {
/* 147 */     this.connection.setAttribute(objectName, attribute, this.delegate);
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(ObjectName objectName, String[] attributes)
/*     */     throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 153 */     return this.connection.getAttributes(objectName, attributes, this.delegate);
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(ObjectName objectName, AttributeList attributes)
/*     */     throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 159 */     return this.connection.setAttributes(objectName, attributes, this.delegate);
/*     */   }
/*     */   
/*     */   public Object invoke(ObjectName objectName, String methodName, Object[] args, String[] parameters)
/*     */     throws InstanceNotFoundException, MBeanException, ReflectionException, IOException
/*     */   {
/* 165 */     return this.connection.invoke(objectName, methodName, args, parameters, this.delegate);
/*     */   }
/*     */   
/*     */   public Integer getMBeanCount()
/*     */     throws IOException
/*     */   {
/* 171 */     return this.connection.getMBeanCount(this.delegate);
/*     */   }
/*     */   
/*     */   public boolean isRegistered(ObjectName objectName)
/*     */     throws IOException
/*     */   {
/* 177 */     return this.connection.isRegistered(objectName, this.delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance getObjectInstance(ObjectName objectName)
/*     */     throws InstanceNotFoundException, IOException
/*     */   {
/* 183 */     return this.connection.getObjectInstance(objectName, this.delegate);
/*     */   }
/*     */   
/*     */   public Set queryMBeans(ObjectName patternName, QueryExp filter)
/*     */     throws IOException
/*     */   {
/* 189 */     return this.connection.queryMBeans(patternName, filter, this.delegate);
/*     */   }
/*     */   
/*     */   public Set queryNames(ObjectName patternName, QueryExp filter)
/*     */     throws IOException
/*     */   {
/* 195 */     return this.connection.queryNames(patternName, filter, this.delegate);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/local/LocalConnectionMBeanServerConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */