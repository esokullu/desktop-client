/*    */ package mx4j.tools.remote.local;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.InstanceNotFoundException;
/*    */ import javax.management.ListenerNotFoundException;
/*    */ import javax.management.NotificationFilter;
/*    */ import javax.management.NotificationListener;
/*    */ import javax.management.ObjectName;
/*    */ import javax.security.auth.Subject;
/*    */ import mx4j.tools.remote.JMXConnectionHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LocalConnectionHandler
/*    */   extends JMXConnectionHandler
/*    */   implements LocalConnection
/*    */ {
/*    */   LocalConnectionHandler(String connectionId, LocalConnectionManager manager, LocalConnection target)
/*    */   {
/* 28 */     super(target, manager, connectionId);
/*    */   }
/*    */   
/*    */   public void addNotificationListener(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback, Subject delegate) throws InstanceNotFoundException, IOException
/*    */   {
/* 33 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 34 */     ((LocalConnection)getConnection()).addNotificationListener(observed, listener, filter, handback, delegate);
/*    */   }
/*    */   
/*    */   public void removeNotificationListener(ObjectName observed, NotificationListener listener, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*    */   {
/* 39 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 40 */     ((LocalConnection)getConnection()).removeNotificationListener(observed, listener, delegate);
/*    */   }
/*    */   
/*    */   public void removeNotificationListener(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*    */   {
/* 45 */     if (isClosed()) throw new IOException("Connection has been closed");
/* 46 */     ((LocalConnection)getConnection()).removeNotificationListener(observed, listener, filter, handback, delegate);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/local/LocalConnectionHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */