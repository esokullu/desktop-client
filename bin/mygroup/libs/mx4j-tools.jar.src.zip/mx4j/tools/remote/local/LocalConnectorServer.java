/*     */ package mx4j.tools.remote.local;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import mx4j.remote.ConnectionResolver;
/*     */ import mx4j.tools.remote.AbstractJMXConnectorServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalConnectorServer
/*     */   extends AbstractJMXConnectorServer
/*     */ {
/*  26 */   private static Map instances = new HashMap();
/*     */   private MBeanServer mbeanServer;
/*     */   private LocalConnectionManager connectionManager;
/*     */   
/*     */   /* Error */
/*     */   public static LocalConnectionManager find(JMXServiceURL url)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 6	mx4j/tools/remote/local/LocalConnectorServer:class$mx4j$tools$remote$local$LocalConnectorServer	Ljava/lang/Class;
/*     */     //   3: ifnonnull +15 -> 18
/*     */     //   6: ldc 7
/*     */     //   8: invokestatic 8	mx4j/tools/remote/local/LocalConnectorServer:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   11: dup
/*     */     //   12: putstatic 6	mx4j/tools/remote/local/LocalConnectorServer:class$mx4j$tools$remote$local$LocalConnectorServer	Ljava/lang/Class;
/*     */     //   15: goto +6 -> 21
/*     */     //   18: getstatic 6	mx4j/tools/remote/local/LocalConnectorServer:class$mx4j$tools$remote$local$LocalConnectorServer	Ljava/lang/Class;
/*     */     //   21: dup
/*     */     //   22: astore_1
/*     */     //   23: monitorenter
/*     */     //   24: getstatic 9	mx4j/tools/remote/local/LocalConnectorServer:instances	Ljava/util/Map;
/*     */     //   27: aload_0
/*     */     //   28: invokeinterface 10 2 0
/*     */     //   33: checkcast 11	mx4j/tools/remote/local/LocalConnectionManager
/*     */     //   36: aload_1
/*     */     //   37: monitorexit
/*     */     //   38: areturn
/*     */     //   39: astore_2
/*     */     //   40: aload_1
/*     */     //   41: monitorexit
/*     */     //   42: aload_2
/*     */     //   43: athrow
/*     */     // Line number table:
/*     */     //   Java source line #30	-> byte code offset #0
/*     */     //   Java source line #32	-> byte code offset #24
/*     */     //   Java source line #33	-> byte code offset #39
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	44	0	url	JMXServiceURL
/*     */     //   22	19	1	Ljava/lang/Object;	Object
/*     */     //   39	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   24	38	39	finally
/*     */     //   39	42	39	finally
/*     */   }
/*     */   
/*     */   public LocalConnectorServer(JMXServiceURL url, Map environment, MBeanServer server)
/*     */   {
/*  41 */     super(url, environment, server);
/*     */   }
/*     */   
/*     */   public MBeanServer getMBeanServer()
/*     */   {
/*  46 */     return this.mbeanServer;
/*     */   }
/*     */   
/*     */   protected void doStart() throws IOException
/*     */   {
/*  51 */     JMXServiceURL address = getAddress();
/*  52 */     String protocol = address.getProtocol();
/*  53 */     Map environment = getEnvironment();
/*  54 */     ConnectionResolver resolver = ConnectionResolver.newConnectionResolver(protocol, environment);
/*  55 */     if (resolver == null) { throw new MalformedURLException("Unsupported protocol: " + protocol);
/*     */     }
/*  57 */     MBeanServer realServer = null;
/*  58 */     MBeanServer server = super.getMBeanServer();
/*     */     
/*  60 */     MBeanServer resolvedServer = (MBeanServer)resolver.createServer(address, environment);
/*  61 */     if (resolvedServer == null)
/*     */     {
/*  63 */       if (server == null) throw new IllegalStateException("This LocalConnectorServer is not attached to an MBeanServer");
/*  64 */       realServer = server;
/*     */ 
/*     */ 
/*     */     }
/*  68 */     else if (server == null)
/*     */     {
/*  70 */       realServer = resolvedServer;
/*     */     }
/*     */     else
/*     */     {
/*  74 */       if (server != resolvedServer) throw new IllegalStateException("This LocalConnectorServer cannot be attached to 2 MBeanServers");
/*  75 */       realServer = server;
/*     */     }
/*     */     
/*  78 */     this.mbeanServer = realServer;
/*     */     
/*  80 */     this.connectionManager = new LocalConnectionManager(this, environment);
/*     */     
/*  82 */     setAddress(resolver.bindServer(realServer, address, environment));
/*     */     
/*     */ 
/*  85 */     register(getAddress(), this.connectionManager);
/*     */   }
/*     */   
/*     */   private void register(JMXServiceURL url, LocalConnectionManager manager) throws IOException
/*     */   {
/*  90 */     synchronized (LocalConnectorServer.class)
/*     */     {
/*  92 */       if (instances.get(url) != null) throw new IOException("A LocalConnectorServer is already serving at address " + url);
/*  93 */       instances.put(url, manager);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void doStop() throws IOException
/*     */   {
/*  99 */     this.connectionManager.close();
/*     */     
/* 101 */     JMXServiceURL address = getAddress();
/* 102 */     String protocol = address.getProtocol();
/* 103 */     Map environment = getEnvironment();
/* 104 */     ConnectionResolver resolver = ConnectionResolver.newConnectionResolver(protocol, environment);
/* 105 */     if (resolver == null) throw new MalformedURLException("Unsupported protocol: " + protocol);
/* 106 */     MBeanServer server = getMBeanServer();
/* 107 */     resolver.unbindServer(server, address, environment);
/* 108 */     resolver.destroyServer(server, address, environment);
/*     */     
/* 110 */     unregister(address);
/*     */   }
/*     */   
/*     */   private void unregister(JMXServiceURL url) throws IOException
/*     */   {
/* 115 */     synchronized (LocalConnectorServer.class)
/*     */     {
/* 117 */       Object removed = instances.remove(url);
/* 118 */       if (removed == null) throw new IOException("No LocalConnectorServer is present for address " + url);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/local/LocalConnectorServer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */