package mx4j.tools.remote.local;

import java.io.IOException;
import javax.management.InstanceNotFoundException;
import javax.management.ListenerNotFoundException;
import javax.management.NotificationFilter;
import javax.management.NotificationListener;
import javax.management.ObjectName;
import javax.security.auth.Subject;
import mx4j.tools.remote.JMXConnection;

public abstract interface LocalConnection
  extends JMXConnection
{
  public abstract void addNotificationListener(ObjectName paramObjectName, NotificationListener paramNotificationListener, NotificationFilter paramNotificationFilter, Object paramObject, Subject paramSubject)
    throws InstanceNotFoundException, IOException;
  
  public abstract void removeNotificationListener(ObjectName paramObjectName, NotificationListener paramNotificationListener, Subject paramSubject)
    throws InstanceNotFoundException, ListenerNotFoundException, IOException;
  
  public abstract void removeNotificationListener(ObjectName paramObjectName, NotificationListener paramNotificationListener, NotificationFilter paramNotificationFilter, Object paramObject, Subject paramSubject)
    throws InstanceNotFoundException, ListenerNotFoundException, IOException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/local/LocalConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */