/*    */ package mx4j.tools.remote.local;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import javax.management.InstanceNotFoundException;
/*    */ import javax.management.ListenerNotFoundException;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.MBeanServerConnection;
/*    */ import javax.management.NotificationFilter;
/*    */ import javax.management.NotificationListener;
/*    */ import javax.management.ObjectName;
/*    */ import javax.security.auth.Subject;
/*    */ import mx4j.remote.NotificationTuple;
/*    */ import mx4j.tools.remote.AbstractServerInvoker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LocalServerInvoker
/*    */   extends AbstractServerInvoker
/*    */   implements LocalConnection
/*    */ {
/* 30 */   private final Set listeners = new HashSet();
/*    */   
/*    */   LocalServerInvoker(MBeanServer server)
/*    */   {
/* 34 */     super(server);
/*    */   }
/*    */   
/*    */   public void close() throws IOException
/*    */   {
/* 39 */     NotificationTuple[] tuples = null;
/* 40 */     synchronized (this.listeners)
/*    */     {
/* 42 */       tuples = (NotificationTuple[])this.listeners.toArray(new NotificationTuple[this.listeners.size()]);
/* 43 */       this.listeners.clear();
/*    */     }
/* 45 */     for (int i = 0; i < tuples.length; i++)
/*    */     {
/* 47 */       NotificationTuple tuple = tuples[i];
/*    */       try
/*    */       {
/* 50 */         getServer().removeNotificationListener(tuple.getObjectName(), tuple.getNotificationListener(), tuple.getNotificationFilter(), tuple.getHandback());
/*    */       }
/*    */       catch (InstanceNotFoundException ignored) {}catch (ListenerNotFoundException ignored) {}
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addNotificationListener(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback, Subject delegate)
/*    */     throws InstanceNotFoundException, IOException
/*    */   {
/* 64 */     NotificationTuple tuple = new NotificationTuple(observed, listener, filter, handback);
/* 65 */     synchronized (this.listeners)
/*    */     {
/* 67 */       this.listeners.add(tuple);
/*    */     }
/* 69 */     getServer().addNotificationListener(observed, listener, filter, handback);
/*    */   }
/*    */   
/*    */   public void removeNotificationListener(ObjectName observed, NotificationListener listener, Subject delegate)
/*    */     throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*    */   {
/* 75 */     NotificationTuple tuple = new NotificationTuple(observed, listener);
/* 76 */     synchronized (this.listeners)
/*    */     {
/* 78 */       this.listeners.remove(tuple);
/*    */     }
/* 80 */     getServer().removeNotificationListener(observed, listener);
/*    */   }
/*    */   
/*    */   public void removeNotificationListener(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback, Subject delegate)
/*    */     throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*    */   {
/* 86 */     NotificationTuple tuple = new NotificationTuple(observed, listener, filter, handback);
/* 87 */     synchronized (this.listeners)
/*    */     {
/* 89 */       this.listeners.remove(tuple);
/*    */     }
/* 91 */     getServer().removeNotificationListener(observed, listener, filter, handback);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/local/LocalServerInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */