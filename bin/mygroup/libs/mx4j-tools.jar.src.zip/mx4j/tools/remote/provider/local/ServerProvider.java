/*    */ package mx4j.tools.remote.provider.local;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.remote.JMXConnectorServer;
/*    */ import javax.management.remote.JMXConnectorServerProvider;
/*    */ import javax.management.remote.JMXServiceURL;
/*    */ import mx4j.tools.remote.local.LocalConnectorServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerProvider
/*    */   implements JMXConnectorServerProvider
/*    */ {
/*    */   public JMXConnectorServer newJMXConnectorServer(JMXServiceURL url, Map environment, MBeanServer server)
/*    */     throws IOException
/*    */   {
/* 27 */     return new LocalConnectorServer(url, environment, server);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/provider/local/ServerProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */