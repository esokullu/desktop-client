/*     */ package mx4j.tools.remote;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.QueryExp;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.security.auth.Subject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractServerInvoker
/*     */   implements JMXConnection
/*     */ {
/*     */   private final MBeanServerConnection server;
/*     */   
/*     */   protected AbstractServerInvoker(MBeanServerConnection server)
/*     */   {
/*  49 */     this.server = server;
/*     */   }
/*     */   
/*     */   public MBeanServerConnection getServer()
/*     */   {
/*  54 */     return this.server;
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName name, Object params, String[] signature, Subject delegate) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException
/*     */   {
/*  59 */     return getServer().createMBean(className, name, (Object[])params, signature);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName name, ObjectName loaderName, Object params, String[] signature, Subject delegate) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException
/*     */   {
/*  64 */     return getServer().createMBean(className, name, loaderName, (Object[])params, signature);
/*     */   }
/*     */   
/*     */   public void unregisterMBean(ObjectName name, Subject delegate) throws InstanceNotFoundException, MBeanRegistrationException, IOException
/*     */   {
/*  69 */     getServer().unregisterMBean(name);
/*     */   }
/*     */   
/*     */   public ObjectInstance getObjectInstance(ObjectName name, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/*  74 */     return getServer().getObjectInstance(name);
/*     */   }
/*     */   
/*     */   public Set queryMBeans(ObjectName name, Object query, Subject delegate) throws IOException
/*     */   {
/*  79 */     return getServer().queryMBeans(name, (QueryExp)query);
/*     */   }
/*     */   
/*     */   public Set queryNames(ObjectName name, Object query, Subject delegate) throws IOException
/*     */   {
/*  84 */     return getServer().queryNames(name, (QueryExp)query);
/*     */   }
/*     */   
/*     */   public boolean isRegistered(ObjectName name, Subject delegate) throws IOException
/*     */   {
/*  89 */     return getServer().isRegistered(name);
/*     */   }
/*     */   
/*     */   public Integer getMBeanCount(Subject delegate) throws IOException
/*     */   {
/*  94 */     return getServer().getMBeanCount();
/*     */   }
/*     */   
/*     */   public Object getAttribute(ObjectName name, String attribute, Subject delegate) throws MBeanException, AttributeNotFoundException, InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/*  99 */     return getServer().getAttribute(name, attribute);
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(ObjectName name, String[] attributes, Subject delegate) throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 104 */     return getServer().getAttributes(name, attributes);
/*     */   }
/*     */   
/*     */   public void setAttribute(ObjectName name, Object attribute, Subject delegate) throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException, IOException
/*     */   {
/* 109 */     getServer().setAttribute(name, (Attribute)attribute);
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(ObjectName name, Object attributes, Subject delegate) throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 114 */     return getServer().setAttributes(name, (AttributeList)attributes);
/*     */   }
/*     */   
/*     */   public Object invoke(ObjectName name, String operationName, Object params, String[] signature, Subject delegate) throws InstanceNotFoundException, MBeanException, ReflectionException, IOException
/*     */   {
/* 119 */     return getServer().invoke(name, operationName, (Object[])params, signature);
/*     */   }
/*     */   
/*     */   public String getDefaultDomain(Subject delegate) throws IOException
/*     */   {
/* 124 */     return getServer().getDefaultDomain();
/*     */   }
/*     */   
/*     */   public String[] getDomains(Subject delegate) throws IOException
/*     */   {
/* 129 */     return getServer().getDomains();
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo(ObjectName name, Subject delegate) throws InstanceNotFoundException, IntrospectionException, ReflectionException, IOException
/*     */   {
/* 134 */     return getServer().getMBeanInfo(name);
/*     */   }
/*     */   
/*     */   public boolean isInstanceOf(ObjectName name, String className, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 139 */     return getServer().isInstanceOf(name, className);
/*     */   }
/*     */   
/*     */   public void addNotificationListener(ObjectName name, ObjectName listener, Object filter, Object handback, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 144 */     getServer().addNotificationListener(name, listener, (NotificationFilter)filter, handback);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName name, ObjectName listener, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 149 */     getServer().removeNotificationListener(name, listener);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName name, ObjectName listener, Object filter, Object handback, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 154 */     getServer().removeNotificationListener(name, listener, (NotificationFilter)filter, handback);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/AbstractServerInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */