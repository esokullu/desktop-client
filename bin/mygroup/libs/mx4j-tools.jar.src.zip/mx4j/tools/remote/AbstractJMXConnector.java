/*     */ package mx4j.tools.remote;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.remote.JMXConnector;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import javax.security.auth.Subject;
/*     */ import mx4j.remote.ConnectionNotificationEmitter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJMXConnector
/*     */   implements JMXConnector, Serializable
/*     */ {
/*     */   private final JMXServiceURL address;
/*     */   private transient boolean connected;
/*     */   private transient boolean closed;
/*     */   private transient ConnectionNotificationEmitter emitter;
/*     */   
/*     */   protected AbstractJMXConnector(JMXServiceURL address)
/*     */     throws IOException
/*     */   {
/*  46 */     if (address == null) throw new IOException("JMXServiceURL cannot be null");
/*  47 */     this.address = address;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JMXServiceURL getAddress()
/*     */   {
/*  55 */     return this.address;
/*     */   }
/*     */   
/*     */   public void connect() throws IOException, SecurityException
/*     */   {
/*  60 */     connect(null);
/*     */   }
/*     */   
/*     */   public void connect(Map environment) throws IOException, SecurityException
/*     */   {
/*  65 */     synchronized (this)
/*     */     {
/*  67 */       if (isConnected()) return;
/*  68 */       if (isClosed()) { throw new IOException("This connector has already been closed");
/*     */       }
/*  70 */       doConnect(environment);
/*     */       
/*  72 */       this.connected = true;
/*     */     }
/*     */     
/*  75 */     sendConnectionNotificationOpened();
/*     */   }
/*     */   
/*     */   protected abstract void doConnect(Map paramMap) throws IOException, SecurityException;
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/*  82 */     synchronized (this)
/*     */     {
/*  84 */       if (isClosed()) return;
/*  85 */       this.closed = true;
/*  86 */       this.connected = false;
/*     */       
/*  88 */       doClose();
/*     */     }
/*     */     
/*  91 */     sendConnectionNotificationClosed();
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract void doClose()
/*     */     throws IOException;
/*     */   
/*     */   public MBeanServerConnection getMBeanServerConnection()
/*     */     throws IOException
/*     */   {
/* 101 */     return getMBeanServerConnection(null);
/*     */   }
/*     */   
/*     */   public MBeanServerConnection getMBeanServerConnection(Subject delegate) throws IOException
/*     */   {
/* 106 */     if (!isConnected()) throw new IOException("Connection has not been established");
/* 107 */     return doGetMBeanServerConnection(delegate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract MBeanServerConnection doGetMBeanServerConnection(Subject paramSubject)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addConnectionNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback)
/*     */   {
/* 124 */     getConnectionNotificationEmitter().addNotificationListener(listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void removeConnectionNotificationListener(NotificationListener listener) throws ListenerNotFoundException
/*     */   {
/* 129 */     getConnectionNotificationEmitter().removeNotificationListener(listener);
/*     */   }
/*     */   
/*     */   public void removeConnectionNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback) throws ListenerNotFoundException
/*     */   {
/* 134 */     getConnectionNotificationEmitter().removeNotificationListener(listener, filter, handback);
/*     */   }
/*     */   
/*     */   private void sendConnectionNotificationOpened()
/*     */   {
/* 139 */     getConnectionNotificationEmitter().sendConnectionNotificationOpened();
/*     */   }
/*     */   
/*     */   protected void sendConnectionNotificationClosed()
/*     */   {
/* 144 */     getConnectionNotificationEmitter().sendConnectionNotificationClosed();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ConnectionNotificationEmitter createConnectionNotificationEmitter()
/*     */   {
/* 153 */     return new ConnectionNotificationEmitter(this);
/*     */   }
/*     */   
/*     */   protected ConnectionNotificationEmitter getConnectionNotificationEmitter()
/*     */   {
/* 158 */     synchronized (this)
/*     */     {
/* 160 */       if (this.emitter == null) this.emitter = createConnectionNotificationEmitter();
/*     */     }
/* 162 */     return this.emitter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized boolean isConnected()
/*     */   {
/* 170 */     return this.connected;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized boolean isClosed()
/*     */   {
/* 178 */     return this.closed;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/AbstractJMXConnector.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */