/*     */ package mx4j.tools.remote.proxy;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.DynamicMBean;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.MBeanRegistration;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.NotificationEmitter;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.remote.JMXConnector;
/*     */ import javax.management.remote.JMXConnectorFactory;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import javax.security.auth.Subject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RemoteMBeanProxy
/*     */   implements DynamicMBean, NotificationEmitter, MBeanRegistration
/*     */ {
/*     */   private final ObjectName remoteObjectName;
/*     */   private final JMXConnector connector;
/*     */   private final MBeanServerConnection connection;
/*     */   
/*     */   public RemoteMBeanProxy(ObjectName remoteObjectName, JMXServiceURL url, Map environment, Subject delegate)
/*     */     throws IOException
/*     */   {
/*  47 */     this(remoteObjectName, JMXConnectorFactory.newJMXConnector(url, environment), environment, delegate);
/*     */   }
/*     */   
/*     */   public RemoteMBeanProxy(ObjectName remoteObjectName, JMXConnector connector, Map environment, Subject delegate) throws IOException
/*     */   {
/*  52 */     this.remoteObjectName = remoteObjectName;
/*  53 */     this.connector = connector;
/*  54 */     this.connector.connect(environment);
/*  55 */     this.connection = connector.getMBeanServerConnection(delegate);
/*     */   }
/*     */   
/*     */   public RemoteMBeanProxy(ObjectName remoteObjectName, MBeanServerConnection connection)
/*     */   {
/*  60 */     this.remoteObjectName = remoteObjectName;
/*  61 */     this.connector = null;
/*  62 */     this.connection = connection;
/*     */   }
/*     */   
/*     */   public ObjectName preRegister(MBeanServer server, ObjectName name) throws Exception
/*     */   {
/*  67 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */   public void postRegister(Boolean registrationDone) {}
/*     */   
/*     */   public void preDeregister()
/*     */     throws Exception
/*     */   {
/*  76 */     JMXConnector cntor = getJMXConnector();
/*  77 */     if (cntor != null) { cntor.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void postDeregister() {}
/*     */   
/*     */   protected ObjectName getRemoteObjectName()
/*     */   {
/*  86 */     return this.remoteObjectName;
/*     */   }
/*     */   
/*     */   protected MBeanServerConnection getMBeanServerConnection()
/*     */   {
/*  91 */     return this.connection;
/*     */   }
/*     */   
/*     */   protected JMXConnector getJMXConnector()
/*     */   {
/*  96 */     return this.connector;
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo()
/*     */   {
/*     */     try
/*     */     {
/* 103 */       return getMBeanServerConnection().getMBeanInfo(getRemoteObjectName());
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/* 107 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getAttribute(String attribute) throws AttributeNotFoundException, MBeanException, ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 115 */       return getMBeanServerConnection().getAttribute(getRemoteObjectName(), attribute);
/*     */     }
/*     */     catch (InstanceNotFoundException x)
/*     */     {
/* 119 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */     catch (IOException x)
/*     */     {
/* 123 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setAttribute(Attribute attribute) throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 131 */       getMBeanServerConnection().setAttribute(getRemoteObjectName(), attribute);
/*     */     }
/*     */     catch (InstanceNotFoundException x)
/*     */     {
/* 135 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */     catch (IOException x)
/*     */     {
/* 139 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(String[] attributes)
/*     */   {
/*     */     try
/*     */     {
/* 147 */       return getMBeanServerConnection().getAttributes(getRemoteObjectName(), attributes);
/*     */     }
/*     */     catch (InstanceNotFoundException x)
/*     */     {
/* 151 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */     catch (ReflectionException x)
/*     */     {
/* 155 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */     catch (IOException x)
/*     */     {
/* 159 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(AttributeList attributes)
/*     */   {
/*     */     try
/*     */     {
/* 167 */       return getMBeanServerConnection().setAttributes(getRemoteObjectName(), attributes);
/*     */     }
/*     */     catch (InstanceNotFoundException x)
/*     */     {
/* 171 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */     catch (ReflectionException x)
/*     */     {
/* 175 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */     catch (IOException x)
/*     */     {
/* 179 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object invoke(String method, Object[] arguments, String[] params) throws MBeanException, ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 187 */       return getMBeanServerConnection().invoke(getRemoteObjectName(), method, arguments, params);
/*     */     }
/*     */     catch (InstanceNotFoundException x)
/*     */     {
/* 191 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */     catch (IOException x)
/*     */     {
/* 195 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */   }
/*     */   
/*     */   public MBeanNotificationInfo[] getNotificationInfo()
/*     */   {
/* 201 */     return getMBeanInfo().getNotifications();
/*     */   }
/*     */   
/*     */   public void addNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback) throws IllegalArgumentException
/*     */   {
/*     */     try
/*     */     {
/* 208 */       getMBeanServerConnection().addNotificationListener(getRemoteObjectName(), listener, filter, handback);
/*     */     }
/*     */     catch (InstanceNotFoundException x)
/*     */     {
/* 212 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */     catch (IOException x)
/*     */     {
/* 216 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(NotificationListener listener) throws ListenerNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 224 */       getMBeanServerConnection().removeNotificationListener(getRemoteObjectName(), listener);
/*     */     }
/*     */     catch (InstanceNotFoundException x)
/*     */     {
/* 228 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */     catch (IOException x)
/*     */     {
/* 232 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback) throws ListenerNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 240 */       getMBeanServerConnection().removeNotificationListener(getRemoteObjectName(), listener, filter, handback);
/*     */     }
/*     */     catch (InstanceNotFoundException x)
/*     */     {
/* 244 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */     catch (IOException x)
/*     */     {
/* 248 */       throw new RemoteMBeanProxyException(x);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/proxy/RemoteMBeanProxy.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */