/*    */ package mx4j.tools.remote.proxy;
/*    */ 
/*    */ import javax.management.JMRuntimeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RemoteMBeanProxyException
/*    */   extends JMRuntimeException
/*    */ {
/*    */   private final Exception exception;
/*    */   
/*    */   public RemoteMBeanProxyException()
/*    */   {
/* 22 */     this(null, null);
/*    */   }
/*    */   
/*    */   public RemoteMBeanProxyException(String message)
/*    */   {
/* 27 */     this(message, null);
/*    */   }
/*    */   
/*    */   public RemoteMBeanProxyException(Exception exception)
/*    */   {
/* 32 */     this(null, exception);
/*    */   }
/*    */   
/*    */   public RemoteMBeanProxyException(String message, Exception exception)
/*    */   {
/* 37 */     super(message);
/* 38 */     this.exception = exception;
/*    */   }
/*    */   
/*    */   public Throwable getCause()
/*    */   {
/* 43 */     return this.exception;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/proxy/RemoteMBeanProxyException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */