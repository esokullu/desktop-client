/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.MBeanParameterInfo;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanParameterInfoDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private String name;
/*    */   private String className;
/*    */   private String description;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 26 */     if ("name".equals(hint)) {
/* 27 */       this.name = ((String)value);
/* 28 */     } else if ("type".equals(hint)) {
/* 29 */       this.className = ((String)value);
/* 30 */     } else if ("description".equals(hint)) this.description = ((String)value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 35 */     return new MBeanParameterInfo(this.name, this.className, this.description);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanParameterInfoDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */