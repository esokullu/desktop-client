/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.MBeanServerNotification;
/*    */ import javax.management.Notification;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanServerNotificationSer
/*    */   extends NotificationSer
/*    */ {
/*    */   static final String MBEAN_NAME = "mbeanName";
/* 26 */   private static final QName MBEAN_NAME_QNAME = new QName("", "mbeanName");
/*    */   
/*    */   protected void onSerialize(SerializationContext context, Notification notification) throws IOException
/*    */   {
/* 30 */     super.onSerialize(context, notification);
/* 31 */     MBeanServerNotification serverNotification = (MBeanServerNotification)notification;
/* 32 */     context.serialize(MBEAN_NAME_QNAME, null, serverNotification.getMBeanName());
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types)
/*    */     throws Exception
/*    */   {
/* 38 */     return super.writeSchema(aClass, types);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanServerNotificationSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */