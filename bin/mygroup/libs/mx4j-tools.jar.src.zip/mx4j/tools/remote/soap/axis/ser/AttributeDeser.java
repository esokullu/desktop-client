/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.Attribute;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private String attributeName;
/*    */   private Object attributeValue;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 25 */     if ("name".equals(hint)) {
/* 26 */       this.attributeName = ((String)value);
/* 27 */     } else if ("value".equals(hint)) {
/* 28 */       this.attributeValue = value;
/*    */     }
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException {
/* 33 */     return new Attribute(this.attributeName, this.attributeValue);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/AttributeDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */