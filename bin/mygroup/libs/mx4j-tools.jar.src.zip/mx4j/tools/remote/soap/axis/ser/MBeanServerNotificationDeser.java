/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.MBeanServerNotification;
/*    */ import javax.management.ObjectName;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanServerNotificationDeser
/*    */   extends NotificationDeser
/*    */ {
/*    */   private ObjectName mbeanName;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 25 */     super.onSetChildValue(value, hint);
/* 26 */     if ("mbeanName".equals(hint)) this.mbeanName = ((ObjectName)value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 31 */     MBeanServerNotification notification = new MBeanServerNotification(getType(), getSource(), getSequenceNumber(), this.mbeanName);
/* 32 */     notification.setTimeStamp(getTimeStamp());
/* 33 */     notification.setUserData(getUserData());
/* 34 */     return notification;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanServerNotificationDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */