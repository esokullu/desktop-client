/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.Notification;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotificationSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "Notification";
/*    */   static final String CLASS_NAME = "type";
/*    */   static final String SOURCE = "source";
/*    */   static final String SEQUENCE_NUMBER = "sequenceNumber";
/*    */   static final String TIMESTAMP = "timeStamp";
/*    */   static final String MESSAGE = "message";
/*    */   static final String USER_DATA = "userData";
/* 33 */   private static final QName CLASS_NAME_QNAME = new QName("", "type");
/* 34 */   private static final QName SOURCE_QNAME = new QName("", "source");
/* 35 */   private static final QName SEQUENCE_NUMBER_QNAME = new QName("", "sequenceNumber");
/* 36 */   private static final QName TIMESTAMP_QNAME = new QName("", "timeStamp");
/* 37 */   private static final QName MESSAGE_QNAME = new QName("", "message");
/* 38 */   private static final QName USER_DATA_QNAME = new QName("", "userData");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 42 */     Notification notification = (Notification)value;
/* 43 */     context.startElement(name, attributes);
/* 44 */     onSerialize(context, notification);
/* 45 */     context.endElement();
/*    */   }
/*    */   
/*    */   protected void onSerialize(SerializationContext context, Notification notification) throws IOException
/*    */   {
/* 50 */     context.serialize(CLASS_NAME_QNAME, null, notification.getType());
/* 51 */     context.serialize(SOURCE_QNAME, null, notification.getSource());
/* 52 */     context.serialize(SEQUENCE_NUMBER_QNAME, null, new Long(notification.getSequenceNumber()));
/* 53 */     context.serialize(TIMESTAMP_QNAME, null, new Long(notification.getTimeStamp()));
/* 54 */     context.serialize(MESSAGE_QNAME, null, notification.getMessage());
/* 55 */     context.serialize(USER_DATA_QNAME, null, notification.getUserData());
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types) throws Exception
/*    */   {
/* 60 */     Element complexType = types.createElement("complexType");
/* 61 */     complexType.setAttribute("name", "Notification");
/* 62 */     Element allElement = types.createElement("all");
/* 63 */     complexType.appendChild(allElement);
/*    */     
/* 65 */     Element typeElement = types.createElement("element");
/* 66 */     typeElement.setAttribute("name", "type");
/* 67 */     typeElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 68 */     allElement.appendChild(typeElement);
/*    */     
/* 70 */     Element sourceElement = types.createElement("element");
/* 71 */     sourceElement.setAttribute("name", "source");
/* 72 */     sourceElement.setAttribute("type", XMLType.XSD_ANYTYPE.getLocalPart());
/* 73 */     allElement.appendChild(sourceElement);
/*    */     
/* 75 */     Element sequenceNumberElement = types.createElement("element");
/* 76 */     sequenceNumberElement.setAttribute("name", "sequenceNumber");
/* 77 */     sequenceNumberElement.setAttribute("type", XMLType.XSD_LONG.getLocalPart());
/* 78 */     allElement.appendChild(sequenceNumberElement);
/*    */     
/* 80 */     Element timeStampElement = types.createElement("element");
/* 81 */     timeStampElement.setAttribute("name", "timeStamp");
/* 82 */     timeStampElement.setAttribute("type", XMLType.XSD_LONG.getLocalPart());
/* 83 */     allElement.appendChild(timeStampElement);
/*    */     
/* 85 */     Element messageElement = types.createElement("element");
/* 86 */     messageElement.setAttribute("name", "message");
/* 87 */     messageElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 88 */     allElement.appendChild(messageElement);
/*    */     
/* 90 */     Element userDataElement = types.createElement("element");
/* 91 */     userDataElement.setAttribute("name", "userData");
/* 92 */     userDataElement.setAttribute("type", XMLType.XSD_ANYTYPE.getLocalPart());
/* 93 */     allElement.appendChild(userDataElement);
/*    */     
/* 95 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/NotificationSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */