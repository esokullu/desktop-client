/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.MBeanOperationInfo;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanOperationInfoSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "MBeanOperationInfo";
/*    */   static final String NAME = "name";
/*    */   static final String CLASS_NAME = "type";
/*    */   static final String DESCRIPTION = "description";
/*    */   static final String SIGNATURE = "signature";
/*    */   static final String IMPACT = "impact";
/* 32 */   private static final QName NAME_QNAME = new QName("", "name");
/* 33 */   private static final QName CLASS_NAME_QNAME = new QName("", "type");
/* 34 */   private static final QName DESCRIPTION_QNAME = new QName("", "description");
/* 35 */   private static final QName SIGNATURE_QNAME = new QName("", "signature");
/* 36 */   private static final QName IMPACT_QNAME = new QName("", "impact");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 40 */     MBeanOperationInfo info = (MBeanOperationInfo)value;
/* 41 */     context.startElement(name, attributes);
/* 42 */     context.serialize(NAME_QNAME, null, info.getName());
/* 43 */     context.serialize(DESCRIPTION_QNAME, null, info.getDescription());
/* 44 */     context.serialize(SIGNATURE_QNAME, null, info.getSignature());
/* 45 */     context.serialize(CLASS_NAME_QNAME, null, info.getReturnType());
/* 46 */     context.serialize(IMPACT_QNAME, null, new Integer(info.getImpact()));
/* 47 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class javaType, Types types) throws Exception
/*    */   {
/* 52 */     Element complexType = types.createElement("complexType");
/* 53 */     complexType.setAttribute("name", "MBeanOperationInfo");
/* 54 */     Element allElement = types.createElement("all");
/* 55 */     complexType.appendChild(allElement);
/*    */     
/* 57 */     Element nameElement = types.createElement("element");
/* 58 */     nameElement.setAttribute("name", "name");
/* 59 */     nameElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 60 */     allElement.appendChild(nameElement);
/*    */     
/* 62 */     Element descrElement = types.createElement("element");
/* 63 */     descrElement.setAttribute("name", "description");
/* 64 */     descrElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 65 */     allElement.appendChild(descrElement);
/*    */     
/* 67 */     Element signatureElement = types.createElement("element");
/* 68 */     signatureElement.setAttribute("name", "signature");
/* 69 */     signatureElement.setAttribute("type", XMLType.SOAP_ARRAY.getLocalPart());
/* 70 */     allElement.appendChild(signatureElement);
/*    */     
/* 72 */     Element typeElement = types.createElement("element");
/* 73 */     typeElement.setAttribute("name", "type");
/* 74 */     typeElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 75 */     allElement.appendChild(typeElement);
/*    */     
/* 77 */     Element impactElement = types.createElement("element");
/* 78 */     impactElement.setAttribute("name", "impact");
/* 79 */     impactElement.setAttribute("type", XMLType.XSD_INT.getLocalPart());
/* 80 */     allElement.appendChild(impactElement);
/*    */     
/* 82 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanOperationInfoSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */