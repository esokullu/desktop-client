/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.Attribute;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "Attribute";
/*    */   static final String NAME = "name";
/*    */   static final String VALUE = "value";
/* 29 */   private static final QName NAME_QNAME = new QName("", "name");
/* 30 */   private static final QName VALUE_QNAME = new QName("", "value");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 34 */     Attribute attribute = (Attribute)value;
/* 35 */     context.startElement(name, attributes);
/* 36 */     context.serialize(NAME_QNAME, null, attribute.getName());
/* 37 */     context.serialize(VALUE_QNAME, null, attribute.getValue());
/* 38 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types) throws Exception
/*    */   {
/* 43 */     Element complexType = types.createElement("complexType");
/* 44 */     complexType.setAttribute("name", "Attribute");
/* 45 */     Element allElement = types.createElement("all");
/* 46 */     complexType.appendChild(allElement);
/*    */     
/* 48 */     Element nameElement = types.createElement("element");
/* 49 */     nameElement.setAttribute("name", "name");
/* 50 */     nameElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 51 */     allElement.appendChild(nameElement);
/*    */     
/* 53 */     Element valueElement = types.createElement("element");
/* 54 */     valueElement.setAttribute("name", "value");
/* 55 */     valueElement.setAttribute("type", XMLType.XSD_ANYTYPE.getLocalPart());
/* 56 */     allElement.appendChild(valueElement);
/*    */     
/* 58 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/AttributeSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */