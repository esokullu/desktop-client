/*    */ package mx4j.tools.remote.soap;
/*    */ 
/*    */ import org.apache.axis.AxisFault;
/*    */ import org.apache.axis.Message;
/*    */ import org.apache.axis.MessageContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.handlers.BasicHandler;
/*    */ import org.apache.axis.message.SOAPEnvelope;
/*    */ import org.apache.axis.message.SOAPHeaderElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectionIDRequestHandler
/*    */   extends BasicHandler
/*    */ {
/*    */   public void invoke(MessageContext context)
/*    */     throws AxisFault
/*    */   {
/* 29 */     Message message = context.getRequestMessage();
/* 30 */     SOAPEnvelope envelope = message.getSOAPEnvelope();
/* 31 */     SOAPHeaderElement header = envelope.getHeaderByName("http://mx4j.sourceforge.net/remote/soap/1.0", "connectionId");
/* 32 */     if (header == null) { throw new AxisFault("Could not find mandatory header connectionId");
/*    */     }
/*    */     try
/*    */     {
/* 36 */       String id = (String)header.getValueAsType(XMLType.XSD_STRING);
/* 37 */       if ((id != null) && (id.length() > 0)) context.setProperty("connectionId", id);
/*    */     }
/*    */     catch (Exception x)
/*    */     {
/* 41 */       throw AxisFault.makeFault(x);
/*    */     }
/*    */     finally
/*    */     {
/* 45 */       header.setProcessed(true);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/ConnectionIDRequestHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */