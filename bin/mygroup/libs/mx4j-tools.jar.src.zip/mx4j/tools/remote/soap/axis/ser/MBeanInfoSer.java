/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.MBeanInfo;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanInfoSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "MBeanInfo";
/*    */   static final String CLASS_NAME = "className";
/*    */   static final String DESCRIPTION = "description";
/*    */   static final String ATTRIBUTES = "attributes";
/*    */   static final String CONSTRUCTORS = "constructors";
/*    */   static final String OPERATIONS = "operations";
/*    */   static final String NOTIFICATIONS = "notifications";
/* 33 */   private static final QName CLASS_NAME_QNAME = new QName("", "className");
/* 34 */   private static final QName DESCRIPTION_QNAME = new QName("", "description");
/* 35 */   private static final QName ATTRIBUTES_QNAME = new QName("", "attributes");
/* 36 */   private static final QName CONSTRUCTORS_QNAME = new QName("", "constructors");
/* 37 */   private static final QName OPERATIONS_QNAME = new QName("", "operations");
/* 38 */   private static final QName NOTIFICATIONS_QNAME = new QName("", "notifications");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 42 */     MBeanInfo info = (MBeanInfo)value;
/* 43 */     context.startElement(name, attributes);
/* 44 */     context.serialize(CLASS_NAME_QNAME, null, info.getClassName());
/* 45 */     context.serialize(DESCRIPTION_QNAME, null, info.getDescription());
/* 46 */     context.serialize(ATTRIBUTES_QNAME, null, info.getAttributes());
/* 47 */     context.serialize(CONSTRUCTORS_QNAME, null, info.getConstructors());
/* 48 */     context.serialize(OPERATIONS_QNAME, null, info.getOperations());
/* 49 */     context.serialize(NOTIFICATIONS_QNAME, null, info.getNotifications());
/* 50 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class javaType, Types types) throws Exception
/*    */   {
/* 55 */     Element complexType = types.createElement("complexType");
/* 56 */     complexType.setAttribute("name", "MBeanInfo");
/* 57 */     Element allElement = types.createElement("all");
/* 58 */     complexType.appendChild(allElement);
/*    */     
/* 60 */     Element typeElement = types.createElement("element");
/* 61 */     typeElement.setAttribute("name", "className");
/* 62 */     typeElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 63 */     allElement.appendChild(typeElement);
/*    */     
/* 65 */     Element descrElement = types.createElement("element");
/* 66 */     descrElement.setAttribute("name", "description");
/* 67 */     descrElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 68 */     allElement.appendChild(descrElement);
/*    */     
/* 70 */     Element attributesElement = types.createElement("element");
/* 71 */     attributesElement.setAttribute("name", "attributes");
/* 72 */     attributesElement.setAttribute("type", XMLType.SOAP_ARRAY.getLocalPart());
/* 73 */     allElement.appendChild(attributesElement);
/*    */     
/* 75 */     Element constructorsElement = types.createElement("element");
/* 76 */     constructorsElement.setAttribute("name", "constructors");
/* 77 */     constructorsElement.setAttribute("type", XMLType.SOAP_ARRAY.getLocalPart());
/* 78 */     allElement.appendChild(constructorsElement);
/*    */     
/* 80 */     Element operationsElement = types.createElement("element");
/* 81 */     operationsElement.setAttribute("name", "operations");
/* 82 */     operationsElement.setAttribute("type", XMLType.SOAP_ARRAY.getLocalPart());
/* 83 */     allElement.appendChild(operationsElement);
/*    */     
/* 85 */     Element notificationsElement = types.createElement("element");
/* 86 */     notificationsElement.setAttribute("name", "notifications");
/* 87 */     notificationsElement.setAttribute("type", XMLType.SOAP_ARRAY.getLocalPart());
/* 88 */     allElement.appendChild(notificationsElement);
/*    */     
/* 90 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanInfoSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */