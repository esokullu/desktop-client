/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.management.relation.RelationTypeSupport;
/*    */ import javax.management.relation.RoleInfo;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.Constants;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelationTypeSupportDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   String relationName;
/* 25 */   List roleInfos = new ArrayList();
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint) throws SAXException
/*    */   {
/* 29 */     if ("name".equals(hint)) this.relationName = ((String)value);
/* 30 */     if (Constants.QNAME_LITERAL_ITEM.getLocalPart().equals(hint)) this.roleInfos.add(value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/*    */     try
/*    */     {
/* 37 */       RoleInfo[] infAry = new RoleInfo[this.roleInfos.size()];
/* 38 */       this.roleInfos.toArray(infAry);
/* 39 */       return new RelationTypeSupport(this.relationName, infAry);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 43 */       throw new SAXException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/RelationTypeSupportDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */