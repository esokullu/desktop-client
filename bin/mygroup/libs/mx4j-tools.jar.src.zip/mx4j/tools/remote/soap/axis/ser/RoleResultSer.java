/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.relation.RoleResult;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleResultSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "RoleResult";
/*    */   static final String ROLE_LIST = "roleList";
/*    */   static final String ROLE_UNRESOLVED_LIST = "roleUnresolvedList";
/* 28 */   protected static final QName ROLE_LIST_QNAME = new QName("", "roleList");
/* 29 */   protected static final QName ROLE_UNRESOLVED_LIST_QNAME = new QName("", "roleUnresolvedList");
/*    */   
/*    */ 
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context)
/*    */     throws IOException
/*    */   {
/* 35 */     RoleResult role = (RoleResult)value;
/* 36 */     context.startElement(name, attributes);
/* 37 */     context.serialize(ROLE_LIST_QNAME, null, role.getRoles());
/* 38 */     context.serialize(ROLE_UNRESOLVED_LIST_QNAME, null, role.getRolesUnresolved());
/* 39 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types) throws Exception
/*    */   {
/* 44 */     Element complexType = types.createElement("complexType");
/* 45 */     complexType.setAttribute("name", "RoleResult");
/*    */     
/* 47 */     Element roleListElement = types.createElement("element");
/* 48 */     roleListElement.setAttribute("name", "roleList");
/* 49 */     roleListElement.setAttribute("type", "RoleList");
/* 50 */     complexType.appendChild(roleListElement);
/*    */     
/* 52 */     Element roleUnresolvedListElement = types.createElement("element");
/* 53 */     roleUnresolvedListElement.setAttribute("name", "roleList");
/* 54 */     roleUnresolvedListElement.setAttribute("type", "RoleUnresolvedList");
/* 55 */     complexType.appendChild(roleUnresolvedListElement);
/*    */     
/* 57 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/RoleResultSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */