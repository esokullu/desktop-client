/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.relation.RoleList;
/*    */ import javax.management.relation.RoleResult;
/*    */ import javax.management.relation.RoleUnresolvedList;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleResultDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private RoleList roleList;
/*    */   private RoleUnresolvedList roleUnresolvedList;
/*    */   
/*    */   protected void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 27 */     if ("roleList".equals(hint))
/* 28 */       this.roleList = ((RoleList)value);
/* 29 */     if ("roleUnresolvedList".equals(hint)) {
/* 30 */       this.roleUnresolvedList = ((RoleUnresolvedList)value);
/*    */     }
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException {
/* 35 */     return new RoleResult(this.roleList, this.roleUnresolvedList);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/RoleResultDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */