/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import org.apache.axis.encoding.Serializer;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AxisSerializer
/*    */   implements Serializer
/*    */ {
/*    */   protected static final String SCHEMA_COMPLEX_TYPE = "complexType";
/*    */   protected static final String SCHEMA_ALL = "all";
/*    */   protected static final String SCHEMA_ELEMENT = "element";
/*    */   protected static final String SCHEMA_SEQUENCE = "sequence";
/*    */   
/*    */   public Element writeSchema(Class javaType, Types types)
/*    */     throws Exception
/*    */   {
/* 28 */     return null;
/*    */   }
/*    */   
/*    */   public String getMechanismType()
/*    */   {
/* 33 */     return "Axis SAX Mechanism";
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/AxisSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */