/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrincipalDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private String className;
/*    */   private String name;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 25 */     if ("className".equals(hint)) {
/* 26 */       this.className = ((String)value);
/* 27 */     } else if ("name".equals(hint)) this.name = ((String)value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/*    */     try
/*    */     {
/* 34 */       Class principalClass = Thread.currentThread().getContextClassLoader().loadClass(this.className);
/* 35 */       Constructor ctor = principalClass.getConstructor(new Class[] { String.class });
/* 36 */       return ctor.newInstance(new Object[] { this.name });
/*    */     }
/*    */     catch (Exception x)
/*    */     {
/* 40 */       throw new SAXException(x);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/PrincipalDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */