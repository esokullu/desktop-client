/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.MBeanAttributeInfo;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanAttributeInfoDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private String name;
/*    */   private String className;
/*    */   private String description;
/*    */   private boolean isReadable;
/*    */   private boolean isWritable;
/*    */   private boolean isIs;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 29 */     if ("name".equals(hint)) {
/* 30 */       this.name = ((String)value);
/* 31 */     } else if ("type".equals(hint)) {
/* 32 */       this.className = ((String)value);
/* 33 */     } else if ("description".equals(hint)) {
/* 34 */       this.description = ((String)value);
/* 35 */     } else if ("isReadable".equals(hint)) {
/* 36 */       this.isReadable = ((Boolean)value).booleanValue();
/* 37 */     } else if ("isWritable".equals(hint)) {
/* 38 */       this.isWritable = ((Boolean)value).booleanValue();
/* 39 */     } else if ("isIs".equals(hint)) this.isIs = ((Boolean)value).booleanValue();
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 44 */     return new MBeanAttributeInfo(this.name, this.className, this.description, this.isReadable, this.isWritable, this.isIs);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanAttributeInfoDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */