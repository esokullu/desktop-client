/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.MBeanConstructorInfo;
/*    */ import javax.management.MBeanParameterInfo;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanConstructorInfoDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private String name;
/*    */   private String description;
/*    */   private MBeanParameterInfo[] signature;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 27 */     if ("name".equals(hint)) {
/* 28 */       this.name = ((String)value);
/* 29 */     } else if ("description".equals(hint)) {
/* 30 */       this.description = ((String)value);
/* 31 */     } else if ("signature".equals(hint)) this.signature = ((MBeanParameterInfo[])value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 36 */     return new MBeanConstructorInfo(this.name, this.description, this.signature);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanConstructorInfoDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */