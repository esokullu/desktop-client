/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.remote.NotificationResult;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotificationResultSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "NotificationResult";
/*    */   static final String EARLIEST_NUMBER = "earliestSequenceNumber";
/*    */   static final String NEXT_NUMBER = "nextSequenceNumber";
/*    */   static final String NOTIFICATIONS = "targetedNotifications";
/* 30 */   private static final QName EARLIEST_NUMBER_QNAME = new QName("", "earliestSequenceNumber");
/* 31 */   private static final QName NEXT_NUMBER_QNAME = new QName("", "nextSequenceNumber");
/* 32 */   private static final QName NOTIFICATIONS_QNAME = new QName("", "targetedNotifications");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 36 */     NotificationResult notificationResult = (NotificationResult)value;
/* 37 */     context.startElement(name, attributes);
/* 38 */     context.serialize(EARLIEST_NUMBER_QNAME, null, new Long(notificationResult.getEarliestSequenceNumber()));
/* 39 */     context.serialize(NEXT_NUMBER_QNAME, null, new Long(notificationResult.getNextSequenceNumber()));
/* 40 */     context.serialize(NOTIFICATIONS_QNAME, null, notificationResult.getTargetedNotifications());
/* 41 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types) throws Exception
/*    */   {
/* 46 */     Element complexType = types.createElement("complexType");
/* 47 */     complexType.setAttribute("name", "NotificationResult");
/* 48 */     Element allElement = types.createElement("all");
/* 49 */     complexType.appendChild(allElement);
/*    */     
/* 51 */     Element typeElement = types.createElement("element");
/* 52 */     typeElement.setAttribute("name", "earliestSequenceNumber");
/* 53 */     typeElement.setAttribute("type", XMLType.XSD_LONG.getLocalPart());
/* 54 */     allElement.appendChild(typeElement);
/*    */     
/* 56 */     Element sourceElement = types.createElement("element");
/* 57 */     sourceElement.setAttribute("name", "nextSequenceNumber");
/* 58 */     sourceElement.setAttribute("type", XMLType.XSD_LONG.getLocalPart());
/* 59 */     allElement.appendChild(sourceElement);
/*    */     
/* 61 */     Element sequenceNumberElement = types.createElement("element");
/* 62 */     sequenceNumberElement.setAttribute("name", "targetedNotifications");
/* 63 */     sequenceNumberElement.setAttribute("type", XMLType.SOAP_ARRAY.getLocalPart());
/* 64 */     allElement.appendChild(sequenceNumberElement);
/*    */     
/* 66 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/NotificationResultSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */