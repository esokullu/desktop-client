/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ import javax.management.relation.RoleUnresolved;
/*    */ import javax.management.relation.RoleUnresolvedList;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.Constants;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleUnresolvedListSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "RoleUnresolvedList";
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context)
/*    */     throws IOException
/*    */   {
/* 32 */     RoleUnresolvedList list = (RoleUnresolvedList)value;
/* 33 */     context.startElement(name, attributes);
/* 34 */     for (Iterator i = list.iterator(); i.hasNext();)
/*    */     {
/* 36 */       RoleUnresolved item = (RoleUnresolved)i.next();
/* 37 */       context.serialize(Constants.QNAME_LITERAL_ITEM, null, item);
/*    */     }
/* 39 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types) throws Exception
/*    */   {
/* 44 */     Element complexType = types.createElement("complexType");
/* 45 */     complexType.setAttribute("name", "RoleUnresolvedList");
/* 46 */     types.writeSchemaElement(Constants.SOAP_VECTOR, complexType);
/* 47 */     Element sequence = types.createElement("sequence");
/* 48 */     complexType.appendChild(sequence);
/* 49 */     Element element = types.createElement("element");
/* 50 */     element.setAttribute("name", Constants.QNAME_LITERAL_ITEM.getLocalPart());
/* 51 */     element.setAttribute("minOccurs", "0");
/* 52 */     element.setAttribute("maxOccurs", "unbounded");
/* 53 */     element.setAttribute("type", "RoleUnresolved");
/* 54 */     sequence.appendChild(element);
/* 55 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/RoleUnresolvedListSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */