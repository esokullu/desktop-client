/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.Constants;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetDeser
/*    */   extends AxisDeserializer
/*    */ {
/* 22 */   private Set set = new HashSet();
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint) throws SAXException
/*    */   {
/* 26 */     if (Constants.QNAME_LITERAL_ITEM.getLocalPart().equals(hint)) this.set.add(value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 31 */     return this.set;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/SetDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */