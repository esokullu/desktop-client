/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.MBeanOperationInfo;
/*    */ import javax.management.MBeanParameterInfo;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanOperationInfoDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private String name;
/*    */   private String description;
/*    */   private MBeanParameterInfo[] signature;
/*    */   private String className;
/*    */   private int impact;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 29 */     if ("name".equals(hint)) {
/* 30 */       this.name = ((String)value);
/* 31 */     } else if ("description".equals(hint)) {
/* 32 */       this.description = ((String)value);
/* 33 */     } else if ("signature".equals(hint)) {
/* 34 */       this.signature = ((MBeanParameterInfo[])value);
/* 35 */     } else if ("type".equals(hint)) {
/* 36 */       this.className = ((String)value);
/* 37 */     } else if ("impact".equals(hint)) this.impact = ((Integer)value).intValue();
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 42 */     return new MBeanOperationInfo(this.name, this.description, this.signature, this.className, this.impact);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanOperationInfoDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */