/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.MalformedObjectNameException;
/*    */ import javax.management.ObjectName;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectNameDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private String canonicalName;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 25 */     if ("canonicalName".equals(hint)) this.canonicalName = ((String)value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/*    */     try
/*    */     {
/* 32 */       return new ObjectName(this.canonicalName);
/*    */     }
/*    */     catch (MalformedObjectNameException x)
/*    */     {
/* 36 */       throw new SAXException(x);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/ObjectNameDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */