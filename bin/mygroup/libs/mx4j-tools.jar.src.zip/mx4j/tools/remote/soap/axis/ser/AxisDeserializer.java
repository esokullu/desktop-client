/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import mx4j.log.Log;
/*    */ import mx4j.log.Logger;
/*    */ import org.apache.axis.encoding.DeserializationContext;
/*    */ import org.apache.axis.encoding.Deserializer;
/*    */ import org.apache.axis.encoding.DeserializerImpl;
/*    */ import org.apache.axis.encoding.DeserializerTarget;
/*    */ import org.apache.axis.message.SOAPHandler;
/*    */ import org.xml.sax.Attributes;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AxisDeserializer
/*    */   extends DeserializerImpl
/*    */ {
/*    */   protected Logger getLogger()
/*    */   {
/* 30 */     return Log.getLogger(getClass().getName());
/*    */   }
/*    */   
/*    */   public void onStartElement(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException
/*    */   {
/* 35 */     Logger logger = getLogger();
/* 36 */     if (logger.isEnabledFor(0))
/*    */     {
/* 38 */       logger.trace("Enter: " + getClass().getName() + ".onStartElement()");
/* 39 */       logger.trace("namespace: " + namespace);
/* 40 */       logger.trace("localName: " + localName);
/* 41 */       logger.trace("prefix: " + prefix);
/*    */     }
/*    */   }
/*    */   
/*    */   public SOAPHandler onStartChild(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException
/*    */   {
/* 47 */     Logger logger = getLogger();
/* 48 */     if (logger.isEnabledFor(0))
/*    */     {
/* 50 */       logger.trace("Enter: " + getClass().getName() + ".onStartChild()");
/* 51 */       logger.trace("namespace: " + namespace);
/* 52 */       logger.trace("localName: " + localName);
/* 53 */       logger.trace("prefix: " + prefix);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 62 */     QName itemType = context.getTypeFromAttributes(namespace, localName, attributes);
/* 63 */     Deserializer deserializer = null;
/* 64 */     if (itemType != null) deserializer = context.getDeserializerForType(itemType);
/* 65 */     if (deserializer == null) { deserializer = new DeserializerImpl();
/*    */     }
/* 67 */     deserializer.registerValueTarget(new DeserializerTarget(this, localName));
/* 68 */     addChildDeserializer(deserializer);
/*    */     
/* 70 */     return (SOAPHandler)deserializer;
/*    */   }
/*    */   
/*    */   public void setChildValue(Object value, Object hint) throws SAXException
/*    */   {
/* 75 */     Logger logger = getLogger();
/* 76 */     if (logger.isEnabledFor(0))
/*    */     {
/* 78 */       logger.trace("Enter: " + getClass().getName() + ".setChildValue()");
/* 79 */       logger.trace("value: " + value);
/* 80 */       logger.trace("hint: " + hint);
/*    */     }
/* 82 */     onSetChildValue(value, hint);
/*    */   }
/*    */   
/*    */   protected abstract void onSetChildValue(Object paramObject1, Object paramObject2) throws SAXException;
/*    */   
/*    */   public void onEndElement(String namespace, String localName, DeserializationContext context) throws SAXException
/*    */   {
/* 89 */     Logger logger = getLogger();
/* 90 */     if (logger.isEnabledFor(0))
/*    */     {
/* 92 */       logger.trace("Enter: " + getClass().getName() + ".onEndElement()");
/* 93 */       logger.trace("namespace: " + namespace);
/* 94 */       logger.trace("localName: " + localName);
/*    */     }
/* 96 */     setValue(createObject());
/*    */   }
/*    */   
/*    */   protected abstract Object createObject()
/*    */     throws SAXException;
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/AxisDeserializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */