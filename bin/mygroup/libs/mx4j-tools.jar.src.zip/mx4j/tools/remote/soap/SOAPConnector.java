/*    */ package mx4j.tools.remote.soap;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.management.MBeanServerConnection;
/*    */ import javax.management.remote.JMXServiceURL;
/*    */ import javax.security.auth.Subject;
/*    */ import mx4j.tools.remote.http.HTTPConnection;
/*    */ import mx4j.tools.remote.http.HTTPConnectionMBeanServerConnection;
/*    */ import mx4j.tools.remote.http.HTTPConnector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SOAPConnector
/*    */   extends HTTPConnector
/*    */ {
/*    */   public SOAPConnector(JMXServiceURL url, Map environment)
/*    */     throws IOException
/*    */   {
/* 27 */     super(url);
/*    */   }
/*    */   
/*    */   protected MBeanServerConnection doGetMBeanServerConnection(Subject delegate) throws IOException
/*    */   {
/* 32 */     HTTPConnection catcher = ClientExceptionCatcher.newInstance(getHTTPConnection());
/* 33 */     return new HTTPConnectionMBeanServerConnection(catcher, delegate, getRemoteNotificationClientHandler());
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/SOAPConnector.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */