/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ import java.util.Vector;
/*    */ import javax.management.NotificationFilterSupport;
/*    */ import javax.management.ObjectName;
/*    */ import javax.management.relation.MBeanServerNotificationFilter;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanServerNotificationFilterSer
/*    */   extends NotificationFilterSupportSer
/*    */ {
/*    */   static final String ENABLED_OBJECT_NAME = "enabledObjectName";
/*    */   static final String DISABLED_OBJECT_NAME = "disabledObjectName";
/*    */   static final String ALL_DISABLED = "allDisabled";
/*    */   static final String ALL_ENABLED = "allEnabled";
/* 32 */   private static final QName ENABLED_OBJECT_NAME_QNAME = new QName("", "enabledObjectName");
/* 33 */   private static final QName DISABLED_OBJECT_NAME_QNAME = new QName("", "disabledObjectName");
/* 34 */   private static final QName ALL_DISABLED_QNAME = new QName("", "allDisabled");
/* 35 */   private static final QName ALL_ENABLED_QNAME = new QName("", "allEnabled");
/*    */   
/*    */   protected void onSerialize(SerializationContext context, NotificationFilterSupport filter) throws IOException
/*    */   {
/* 39 */     super.onSerialize(context, filter);
/*    */     
/* 41 */     MBeanServerNotificationFilter serverFilter = (MBeanServerNotificationFilter)filter;
/* 42 */     Vector enabledNames = serverFilter.getEnabledObjectNames();
/* 43 */     Vector disabledNames = serverFilter.getDisabledObjectNames();
/*    */     
/*    */     Iterator i;
/*    */     
/* 47 */     if (enabledNames != null)
/*    */     {
/* 49 */       if (enabledNames.size() == 0)
/*    */       {
/* 51 */         context.serialize(ALL_DISABLED_QNAME, null, Boolean.TRUE);
/*    */       }
/*    */       else
/*    */       {
/* 55 */         context.serialize(ALL_DISABLED_QNAME, null, Boolean.FALSE);
/*    */       }
/* 57 */       for (i = enabledNames.iterator(); i.hasNext();)
/*    */       {
/* 59 */         ObjectName enabled = (ObjectName)i.next();
/* 60 */         context.serialize(ENABLED_OBJECT_NAME_QNAME, null, enabled);
/*    */       } }
/*    */     Iterator i;
/* 63 */     if (disabledNames != null)
/*    */     {
/* 65 */       if (disabledNames.size() == 0)
/*    */       {
/* 67 */         context.serialize(ALL_ENABLED_QNAME, null, Boolean.TRUE);
/*    */       }
/*    */       else
/*    */       {
/* 71 */         context.serialize(ALL_ENABLED_QNAME, null, Boolean.FALSE);
/*    */       }
/* 73 */       for (i = disabledNames.iterator(); i.hasNext();)
/*    */       {
/* 75 */         ObjectName disabled = (ObjectName)i.next();
/* 76 */         context.serialize(DISABLED_OBJECT_NAME_QNAME, null, disabled);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class javaType, Types types)
/*    */     throws Exception
/*    */   {
/* 84 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanServerNotificationFilterSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */