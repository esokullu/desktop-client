/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.ObjectInstance;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectInstanceSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "ObjectInstance";
/*    */   static final String OBJECT_NAME = "objectName";
/*    */   static final String CLASS_NAME = "className";
/* 29 */   private static final QName OBJECTNAME_QNAME = new QName("", "objectName");
/* 30 */   private static final QName CLASS_NAME_QNAME = new QName("", "className");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 34 */     ObjectInstance instance = (ObjectInstance)value;
/* 35 */     context.startElement(name, attributes);
/* 36 */     context.serialize(OBJECTNAME_QNAME, null, instance.getObjectName());
/* 37 */     context.serialize(CLASS_NAME_QNAME, null, instance.getClassName());
/* 38 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types) throws Exception
/*    */   {
/* 43 */     Element complexType = types.createElement("complexType");
/* 44 */     complexType.setAttribute("name", "ObjectInstance");
/* 45 */     Element allElement = types.createElement("all");
/* 46 */     complexType.appendChild(allElement);
/*    */     
/* 48 */     Element objectNameElement = types.createElement("element");
/* 49 */     objectNameElement.setAttribute("name", "objectName");
/* 50 */     objectNameElement.setAttribute("type", "ObjectName");
/* 51 */     allElement.appendChild(objectNameElement);
/*    */     
/* 53 */     Element classNameElement = types.createElement("element");
/* 54 */     classNameElement.setAttribute("name", "className");
/* 55 */     classNameElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 56 */     allElement.appendChild(classNameElement);
/*    */     
/* 58 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/ObjectInstanceSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */