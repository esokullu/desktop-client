/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.ObjectName;
/*    */ import javax.management.relation.MBeanServerNotificationFilter;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanServerNotificationFilterDeser
/*    */   extends AxisDeserializer
/*    */ {
/* 21 */   private MBeanServerNotificationFilter filter = new MBeanServerNotificationFilter();
/*    */   
/*    */   protected void onSetChildValue(Object value, Object hint) throws SAXException
/*    */   {
/* 25 */     if ("notificationType".equals(hint)) {
/* 26 */       this.filter.enableType((String)value);
/* 27 */     } else if (("allDisabled".equals(hint)) && (((Boolean)value).booleanValue())) {
/* 28 */       this.filter.disableAllObjectNames();
/* 29 */     } else if (("allEnabled".equals(hint)) && (((Boolean)value).booleanValue())) {
/* 30 */       this.filter.enableAllObjectNames();
/* 31 */     } else if ("enabledObjectName".equals(hint)) {
/* 32 */       this.filter.enableObjectName((ObjectName)value);
/* 33 */     } else if ("disabledObjectName".equals(hint)) this.filter.disableObjectName((ObjectName)value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 38 */     return this.filter;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanServerNotificationFilterDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */