/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ import java.util.Vector;
/*    */ import javax.management.NotificationFilterSupport;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.Constants;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotificationFilterSupportSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "NotificationFilterSupport";
/*    */   static final String NOTIFICATION_TYPE = "notificationType";
/* 30 */   private static final QName NOTIFICATION_TYPE_QNAME = new QName("", "notificationType");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 34 */     NotificationFilterSupport filter = (NotificationFilterSupport)value;
/* 35 */     context.startElement(name, attributes);
/* 36 */     onSerialize(context, filter);
/* 37 */     context.endElement();
/*    */   }
/*    */   
/*    */   protected void onSerialize(SerializationContext context, NotificationFilterSupport filter) throws IOException
/*    */   {
/* 42 */     Vector types = filter.getEnabledTypes();
/* 43 */     for (Iterator i = types.iterator(); i.hasNext();)
/*    */     {
/* 45 */       String type = (String)i.next();
/* 46 */       context.serialize(NOTIFICATION_TYPE_QNAME, null, type);
/*    */     }
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class javaType, Types types) throws Exception
/*    */   {
/* 52 */     Element complexType = types.createElement("complexType");
/* 53 */     complexType.setAttribute("name", "NotificationFilterSupport");
/* 54 */     types.writeSchemaElement(Constants.SOAP_VECTOR, complexType);
/* 55 */     Element allElement = types.createElement("all");
/* 56 */     complexType.appendChild(allElement);
/* 57 */     Element element = types.createElement("element");
/* 58 */     element.setAttribute("name", "notificationType");
/* 59 */     element.setAttribute("minOccurs", "0");
/* 60 */     element.setAttribute("maxOccurs", "unbounded");
/* 61 */     element.setAttribute("type", Constants.XSD_STRING.getLocalPart());
/* 62 */     allElement.appendChild(element);
/* 63 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/NotificationFilterSupportSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */