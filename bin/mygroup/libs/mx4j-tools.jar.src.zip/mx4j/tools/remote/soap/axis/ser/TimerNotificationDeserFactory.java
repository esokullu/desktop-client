/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.ser.BaseDeserializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimerNotificationDeserFactory
/*    */   extends BaseDeserializerFactory
/*    */ {
/*    */   public TimerNotificationDeserFactory(Class javaType, QName xmlType)
/*    */   {
/* 22 */     super(TimerNotificationDeser.class, xmlType, javaType);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/TimerNotificationDeserFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */