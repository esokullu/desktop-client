/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.management.relation.Role;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.Constants;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   String roleName;
/* 24 */   List roleValue = new ArrayList();
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint) throws SAXException
/*    */   {
/* 28 */     if ("roleName".equals(hint)) this.roleName = ((String)value);
/* 29 */     if (Constants.QNAME_LITERAL_ITEM.getLocalPart().equals(hint)) this.roleValue.add(value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 34 */     return new Role(this.roleName, this.roleValue);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/RoleDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */