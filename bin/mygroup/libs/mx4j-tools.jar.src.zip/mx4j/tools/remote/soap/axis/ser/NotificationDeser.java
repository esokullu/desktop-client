/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.Notification;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotificationDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private String type;
/*    */   private Object source;
/*    */   private long sequenceNumber;
/*    */   private long timeStamp;
/*    */   private String message;
/*    */   private Object userData;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 29 */     if ("type".equals(hint)) {
/* 30 */       this.type = ((String)value);
/* 31 */     } else if ("source".equals(hint)) {
/* 32 */       this.source = value;
/* 33 */     } else if ("sequenceNumber".equals(hint)) {
/* 34 */       this.sequenceNumber = ((Long)value).longValue();
/* 35 */     } else if ("timeStamp".equals(hint)) {
/* 36 */       this.timeStamp = ((Long)value).longValue();
/* 37 */     } else if ("message".equals(hint)) {
/* 38 */       this.message = ((String)value);
/* 39 */     } else if ("userData".equals(hint)) this.userData = value;
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 44 */     Notification notification = new Notification(getType(), getSource(), getSequenceNumber(), getTimeStamp(), getMessage());
/* 45 */     notification.setUserData(getUserData());
/* 46 */     return notification;
/*    */   }
/*    */   
/*    */   protected String getType()
/*    */   {
/* 51 */     return this.type;
/*    */   }
/*    */   
/*    */   protected Object getSource()
/*    */   {
/* 56 */     return this.source;
/*    */   }
/*    */   
/*    */   protected long getSequenceNumber()
/*    */   {
/* 61 */     return this.sequenceNumber;
/*    */   }
/*    */   
/*    */   protected long getTimeStamp()
/*    */   {
/* 66 */     return this.timeStamp;
/*    */   }
/*    */   
/*    */   protected String getMessage()
/*    */   {
/* 71 */     return this.message;
/*    */   }
/*    */   
/*    */   protected Object getUserData()
/*    */   {
/* 76 */     return this.userData;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/NotificationDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */