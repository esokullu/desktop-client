/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.ser.BaseDeserializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanConstructorInfoDeserFactory
/*    */   extends BaseDeserializerFactory
/*    */ {
/*    */   public MBeanConstructorInfoDeserFactory(Class javaType, QName xmlType)
/*    */   {
/* 22 */     super(MBeanConstructorInfoDeser.class, xmlType, javaType);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanConstructorInfoDeserFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */