/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.remote.NotificationResult;
/*    */ import javax.management.remote.TargetedNotification;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotificationResultDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private long earliestSequenceNumber;
/*    */   private long nextSequenceNumber;
/*    */   private TargetedNotification[] targetedNotifications;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 27 */     if ("earliestSequenceNumber".equals(hint)) {
/* 28 */       this.earliestSequenceNumber = ((Long)value).longValue();
/* 29 */     } else if ("nextSequenceNumber".equals(hint)) {
/* 30 */       this.nextSequenceNumber = ((Long)value).longValue();
/* 31 */     } else if ("targetedNotifications".equals(hint)) this.targetedNotifications = ((TargetedNotification[])value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 36 */     return new NotificationResult(this.earliestSequenceNumber, this.nextSequenceNumber, this.targetedNotifications);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/NotificationResultDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */