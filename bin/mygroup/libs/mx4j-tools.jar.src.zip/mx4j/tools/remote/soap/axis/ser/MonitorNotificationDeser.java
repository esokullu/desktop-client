/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.security.AccessController;
/*    */ import java.security.PrivilegedActionException;
/*    */ import java.security.PrivilegedExceptionAction;
/*    */ import javax.management.ObjectName;
/*    */ import javax.management.monitor.MonitorNotification;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MonitorNotificationDeser
/*    */   extends NotificationDeser
/*    */ {
/*    */   private ObjectName monitoredName;
/*    */   private String monitoredAttribute;
/*    */   private Object gaugeValue;
/*    */   private Object triggerValue;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 32 */     super.onSetChildValue(value, hint);
/* 33 */     if ("derivedGauge".equals(hint)) {
/* 34 */       this.gaugeValue = value;
/* 35 */     } else if ("observedAttribute".equals(hint)) {
/* 36 */       this.monitoredAttribute = ((String)value);
/* 37 */     } else if ("observedObject".equals(hint)) {
/* 38 */       this.monitoredName = ((ObjectName)value);
/* 39 */     } else if ("trigger".equals(hint)) { this.triggerValue = value;
/*    */     }
/*    */   }
/*    */   
/*    */   protected Object createObject()
/*    */     throws SAXException
/*    */   {
/*    */     try
/*    */     {
/* 48 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*    */       {
/*    */         public Object run() throws Exception
/*    */         {
/* 52 */           Constructor ctor = MonitorNotificationDeser.class$javax$management$monitor$MonitorNotification.getDeclaredConstructor(new Class[] { String.class, Object.class, Long.TYPE, Long.TYPE, String.class, ObjectName.class, String.class, Object.class, Object.class });
/*    */           
/* 54 */           ctor.setAccessible(true);
/* 55 */           return ctor.newInstance(new Object[] { MonitorNotificationDeser.this.getType(), MonitorNotificationDeser.this.getSource(), new Long(MonitorNotificationDeser.this.getSequenceNumber()), new Long(MonitorNotificationDeser.this.getTimeStamp()), MonitorNotificationDeser.this.getMessage(), MonitorNotificationDeser.this.monitoredName, MonitorNotificationDeser.this.monitoredAttribute, MonitorNotificationDeser.this.gaugeValue, MonitorNotificationDeser.this.triggerValue });
/*    */         }
/*    */       });
/*    */     }
/*    */     catch (PrivilegedActionException x)
/*    */     {
/* 61 */       throw new SAXException(x.getException());
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MonitorNotificationDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */