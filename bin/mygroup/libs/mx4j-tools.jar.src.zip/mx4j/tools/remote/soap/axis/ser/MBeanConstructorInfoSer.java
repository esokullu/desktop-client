/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.MBeanConstructorInfo;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanConstructorInfoSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "MBeanConstructorInfo";
/*    */   static final String NAME = "name";
/*    */   static final String DESCRIPTION = "description";
/*    */   static final String SIGNATURE = "signature";
/* 30 */   private static final QName NAME_QNAME = new QName("", "name");
/* 31 */   private static final QName DESCRIPTION_QNAME = new QName("", "description");
/* 32 */   private static final QName SIGNATURE_QNAME = new QName("", "signature");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 36 */     MBeanConstructorInfo info = (MBeanConstructorInfo)value;
/* 37 */     context.startElement(name, attributes);
/* 38 */     context.serialize(NAME_QNAME, null, info.getName());
/* 39 */     context.serialize(DESCRIPTION_QNAME, null, info.getDescription());
/* 40 */     context.serialize(SIGNATURE_QNAME, null, info.getSignature());
/* 41 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class javaType, Types types) throws Exception
/*    */   {
/* 46 */     Element complexType = types.createElement("complexType");
/* 47 */     complexType.setAttribute("name", "MBeanConstructorInfo");
/* 48 */     Element allElement = types.createElement("all");
/* 49 */     complexType.appendChild(allElement);
/*    */     
/* 51 */     Element nameElement = types.createElement("element");
/* 52 */     nameElement.setAttribute("name", "name");
/* 53 */     nameElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 54 */     allElement.appendChild(nameElement);
/*    */     
/* 56 */     Element descrElement = types.createElement("element");
/* 57 */     descrElement.setAttribute("name", "description");
/* 58 */     descrElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 59 */     allElement.appendChild(descrElement);
/*    */     
/* 61 */     Element signatureElement = types.createElement("element");
/* 62 */     signatureElement.setAttribute("name", "signature");
/* 63 */     signatureElement.setAttribute("type", XMLType.SOAP_ARRAY.getLocalPart());
/* 64 */     allElement.appendChild(signatureElement);
/*    */     
/* 66 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanConstructorInfoSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */