/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.NotificationFilterSupport;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotificationFilterSupportDeser
/*    */   extends AxisDeserializer
/*    */ {
/* 20 */   private NotificationFilterSupport filter = new NotificationFilterSupport();
/*    */   
/*    */   protected void onSetChildValue(Object value, Object hint) throws SAXException
/*    */   {
/* 24 */     if ("notificationType".equals(hint)) this.filter.enableType((String)value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 29 */     return this.filter;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/NotificationFilterSupportDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */