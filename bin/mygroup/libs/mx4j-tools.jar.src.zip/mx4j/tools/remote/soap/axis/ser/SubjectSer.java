/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.security.auth.Subject;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubjectSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "Subject";
/*    */   static final String READ_ONLY = "readOnly";
/*    */   static final String PRINCIPALS = "principals";
/*    */   static final String PUBLIC_CREDENTIALS = "publicCredentials";
/*    */   static final String PRIVATE_CREDENTIALS = "privateCredentials";
/* 31 */   private static final QName READ_ONLY_QNAME = new QName("", "readOnly");
/* 32 */   private static final QName PRINCIPALS_QNAME = new QName("", "principals");
/* 33 */   private static final QName PUBLIC_CREDENTIALS_QNAME = new QName("", "publicCredentials");
/* 34 */   private static final QName PRIVATE_CREDENTIALS_QNAME = new QName("", "privateCredentials");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 38 */     Subject subject = (Subject)value;
/* 39 */     context.startElement(name, attributes);
/* 40 */     context.serialize(READ_ONLY_QNAME, null, new Boolean(subject.isReadOnly()));
/* 41 */     context.serialize(PRINCIPALS_QNAME, null, subject.getPrincipals());
/* 42 */     context.serialize(PUBLIC_CREDENTIALS_QNAME, null, subject.getPublicCredentials());
/* 43 */     context.serialize(PRIVATE_CREDENTIALS_QNAME, null, subject.getPrivateCredentials());
/* 44 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types) throws Exception
/*    */   {
/* 49 */     Element complexType = types.createElement("complexType");
/* 50 */     complexType.setAttribute("name", "Subject");
/* 51 */     Element allElement = types.createElement("all");
/* 52 */     complexType.appendChild(allElement);
/*    */     
/* 54 */     Element readOnlyElement = types.createElement("element");
/* 55 */     readOnlyElement.setAttribute("name", "readOnly");
/* 56 */     readOnlyElement.setAttribute("type", XMLType.XSD_BOOLEAN.getLocalPart());
/* 57 */     allElement.appendChild(readOnlyElement);
/*    */     
/* 59 */     Element principalsElement = types.createElement("element");
/* 60 */     principalsElement.setAttribute("name", "principals");
/* 61 */     principalsElement.setAttribute("type", "Set");
/* 62 */     allElement.appendChild(principalsElement);
/*    */     
/* 64 */     Element publicCredentialsElement = types.createElement("element");
/* 65 */     publicCredentialsElement.setAttribute("name", "publicCredentials");
/* 66 */     publicCredentialsElement.setAttribute("type", "Set");
/* 67 */     allElement.appendChild(publicCredentialsElement);
/*    */     
/* 69 */     Element privateCredentialsElement = types.createElement("element");
/* 70 */     privateCredentialsElement.setAttribute("name", "privateCredentials");
/* 71 */     privateCredentialsElement.setAttribute("type", "Set");
/* 72 */     allElement.appendChild(privateCredentialsElement);
/*    */     
/* 74 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/SubjectSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */