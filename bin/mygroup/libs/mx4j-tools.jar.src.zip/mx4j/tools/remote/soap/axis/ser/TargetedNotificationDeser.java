/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.Notification;
/*    */ import javax.management.remote.TargetedNotification;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TargetedNotificationDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private Notification notification;
/*    */   private Integer listenerID;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 26 */     if ("notification".equals(hint)) {
/* 27 */       this.notification = ((Notification)value);
/* 28 */     } else if ("listenerID".equals(hint)) this.listenerID = ((Integer)value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 33 */     return new TargetedNotification(this.notification, this.listenerID);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/TargetedNotificationDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */