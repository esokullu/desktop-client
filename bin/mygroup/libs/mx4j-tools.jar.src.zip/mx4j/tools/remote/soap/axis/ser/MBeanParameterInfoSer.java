/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.MBeanParameterInfo;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanParameterInfoSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "MBeanParameterInfo";
/*    */   static final String NAME = "name";
/*    */   static final String CLASS_NAME = "type";
/*    */   static final String DESCRIPTION = "description";
/* 30 */   private static final QName NAME_QNAME = new QName("", "name");
/* 31 */   private static final QName CLASS_NAME_QNAME = new QName("", "type");
/* 32 */   private static final QName DESCRIPTION_QNAME = new QName("", "description");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 36 */     MBeanParameterInfo info = (MBeanParameterInfo)value;
/* 37 */     context.startElement(name, attributes);
/* 38 */     context.serialize(NAME_QNAME, null, info.getName());
/* 39 */     context.serialize(CLASS_NAME_QNAME, null, info.getType());
/* 40 */     context.serialize(DESCRIPTION_QNAME, null, info.getDescription());
/* 41 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types) throws Exception
/*    */   {
/* 46 */     Element complexType = types.createElement("complexType");
/* 47 */     complexType.setAttribute("name", "MBeanParameterInfo");
/* 48 */     Element allElement = types.createElement("all");
/* 49 */     complexType.appendChild(allElement);
/*    */     
/* 51 */     Element nameElement = types.createElement("element");
/* 52 */     nameElement.setAttribute("name", "name");
/* 53 */     nameElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 54 */     allElement.appendChild(nameElement);
/*    */     
/* 56 */     Element typeElement = types.createElement("element");
/* 57 */     typeElement.setAttribute("name", "type");
/* 58 */     typeElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 59 */     allElement.appendChild(typeElement);
/*    */     
/* 61 */     Element descrElement = types.createElement("element");
/* 62 */     descrElement.setAttribute("name", "description");
/* 63 */     descrElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 64 */     allElement.appendChild(descrElement);
/*    */     
/* 66 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanParameterInfoSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */