/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.ser.BaseDeserializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleResultDeserFactory
/*    */   extends BaseDeserializerFactory
/*    */ {
/*    */   public RoleResultDeserFactory(Class javaType, QName xmlType)
/*    */   {
/* 22 */     super(RoleResultDeser.class, xmlType, javaType);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/RoleResultDeserFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */