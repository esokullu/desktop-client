/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.Notification;
/*    */ import javax.management.timer.TimerNotification;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimerNotificationSer
/*    */   extends NotificationSer
/*    */ {
/*    */   static final String NOTIFICATION_ID = "notificationID";
/* 27 */   private static final QName NOTIFICATION_ID_QNAME = new QName("", "notificationID");
/*    */   
/*    */   protected void onSerialize(SerializationContext context, Notification notification) throws IOException
/*    */   {
/* 31 */     super.onSerialize(context, notification);
/* 32 */     TimerNotification serverNotification = (TimerNotification)notification;
/* 33 */     context.serialize(NOTIFICATION_ID_QNAME, null, serverNotification.getNotificationID());
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types) throws Exception
/*    */   {
/* 38 */     Element elem = super.writeSchema(aClass, types);
/*    */     
/* 40 */     Element notID = types.createElement("element");
/* 41 */     notID.setAttribute("name", "notificationID");
/* 42 */     notID.setAttribute("type", XMLType.XSD_INT.getLocalPart());
/* 43 */     elem.appendChild(notID);
/*    */     
/* 45 */     return elem;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/TimerNotificationSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */