/*    */ package mx4j.tools.remote.soap;
/*    */ 
/*    */ import mx4j.tools.remote.http.HTTPService;
/*    */ import org.apache.axis.MessageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SOAPService
/*    */   extends HTTPService
/*    */ {
/*    */   protected String findRequestURL()
/*    */   {
/* 26 */     MessageContext context = MessageContext.getCurrentContext();
/* 27 */     return (String)context.getProperty("transport.url");
/*    */   }
/*    */   
/*    */   protected String getProtocol()
/*    */   {
/* 32 */     return "soap";
/*    */   }
/*    */   
/*    */   protected String findConnectionId()
/*    */   {
/* 37 */     MessageContext context = MessageContext.getCurrentContext();
/* 38 */     return (String)context.getProperty("connectionId");
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/SOAPService.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */