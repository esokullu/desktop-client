/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.Constants;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "Set";
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context)
/*    */     throws IOException
/*    */   {
/* 31 */     Set set = (Set)value;
/* 32 */     context.startElement(name, attributes);
/* 33 */     for (Iterator i = set.iterator(); i.hasNext();)
/*    */     {
/* 35 */       Object item = i.next();
/* 36 */       context.serialize(Constants.QNAME_LITERAL_ITEM, null, item);
/*    */     }
/* 38 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class javaType, Types types) throws Exception
/*    */   {
/* 43 */     Element complexType = types.createElement("complexType");
/* 44 */     complexType.setAttribute("name", "Set");
/* 45 */     types.writeSchemaElement(Constants.SOAP_VECTOR, complexType);
/* 46 */     Element allElement = types.createElement("all");
/* 47 */     complexType.appendChild(allElement);
/* 48 */     Element element = types.createElement("element");
/* 49 */     element.setAttribute("name", Constants.QNAME_LITERAL_ITEM.getLocalPart());
/* 50 */     element.setAttribute("minOccurs", "0");
/* 51 */     element.setAttribute("maxOccurs", "unbounded");
/* 52 */     element.setAttribute("type", Constants.XSD_ANYTYPE.getLocalPart());
/* 53 */     allElement.appendChild(element);
/* 54 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/SetSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */