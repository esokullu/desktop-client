/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.ser.BaseSerializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanOperationInfoSerFactory
/*    */   extends BaseSerializerFactory
/*    */ {
/*    */   public MBeanOperationInfoSerFactory(Class javaType, QName xmlType)
/*    */   {
/* 22 */     super(MBeanOperationInfoSer.class, xmlType, javaType);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanOperationInfoSerFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */