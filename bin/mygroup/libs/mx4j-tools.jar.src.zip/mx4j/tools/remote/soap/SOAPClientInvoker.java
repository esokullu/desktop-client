/*     */ package mx4j.tools.remote.soap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.remote.NotificationResult;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.ParameterMode;
/*     */ import javax.xml.rpc.ServiceException;
/*     */ import mx4j.tools.remote.http.HTTPConnection;
/*     */ import org.apache.axis.client.Call;
/*     */ import org.apache.axis.client.Service;
/*     */ import org.apache.axis.encoding.XMLType;
/*     */ import org.apache.axis.message.SOAPHeaderElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPClientInvoker
/*     */   implements HTTPConnection
/*     */ {
/*  44 */   private static final QName qObjectName = new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "ObjectName");
/*  45 */   private static final QName qObjectInstance = new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "ObjectInstance");
/*  46 */   private static final QName qSubject = new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "Subject");
/*     */   
/*     */   private final String endpoint;
/*     */   private final Service service;
/*     */   private String connectionId;
/*     */   
/*     */   public SOAPClientInvoker(String endpoint, Service service)
/*     */   {
/*  54 */     this.endpoint = endpoint;
/*  55 */     this.service = service;
/*     */   }
/*     */   
/*     */   public String connect(Object credentials) throws IOException, SecurityException
/*     */   {
/*  60 */     Call call = createCall();
/*     */     
/*  62 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "connect"));
/*  63 */     call.addParameter("credentials", XMLType.XSD_ANY, ParameterMode.IN);
/*  64 */     call.setReturnType(XMLType.XSD_STRING);
/*     */     
/*     */ 
/*  67 */     this.connectionId = ((String)call.invoke(new Object[] { credentials }));
/*  68 */     return this.connectionId;
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/*  73 */     Call call = createCall();
/*     */     
/*  75 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "close"));
/*  76 */     call.setReturnType(XMLType.AXIS_VOID);
/*     */     
/*  78 */     call.invoke(new Object[0]);
/*     */   }
/*     */   
/*     */   public String getConnectionId() throws IOException
/*     */   {
/*  83 */     return this.connectionId;
/*     */   }
/*     */   
/*     */   public Integer addNotificationListener(ObjectName name, Object filter, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/*  88 */     Call call = createCall();
/*     */     
/*  90 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "addNotificationListener"));
/*  91 */     call.addParameter("observed", qObjectName, ParameterMode.IN);
/*  92 */     call.addParameter("filter", XMLType.XSD_ANY, ParameterMode.IN);
/*  93 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/*  94 */     call.setReturnType(XMLType.XSD_INT);
/*     */     
/*  96 */     return (Integer)call.invoke(new Object[] { name, filter, delegate });
/*     */   }
/*     */   
/*     */   public void removeNotificationListeners(ObjectName observed, Integer[] ids, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 101 */     Call call = createCall();
/*     */     
/* 103 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "removeNotificationListeners"));
/* 104 */     call.addParameter("observed", qObjectName, ParameterMode.IN);
/* 105 */     call.addParameter("ids", XMLType.SOAP_ARRAY, ParameterMode.IN);
/* 106 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 107 */     call.setReturnType(XMLType.AXIS_VOID);
/*     */     
/* 109 */     call.invoke(new Object[] { observed, ids, delegate });
/*     */   }
/*     */   
/*     */   public NotificationResult fetchNotifications(long clientSequenceNumber, int maxNotifications, long timeout) throws IOException
/*     */   {
/* 114 */     Call call = createCall();
/*     */     
/* 116 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "fetchNotifications"));
/* 117 */     call.addParameter("sequence", XMLType.XSD_LONG, ParameterMode.IN);
/* 118 */     call.addParameter("maxNumber", XMLType.XSD_INT, ParameterMode.IN);
/* 119 */     call.addParameter("timeout", XMLType.XSD_LONG, ParameterMode.IN);
/* 120 */     call.setReturnType(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "NotificationResult"));
/*     */     
/* 122 */     NotificationResult result = (NotificationResult)call.invoke(new Object[] { new Long(clientSequenceNumber), new Integer(maxNotifications), new Long(timeout) });
/* 123 */     return result;
/*     */   }
/*     */   
/*     */   public void addNotificationListener(ObjectName name, ObjectName listener, Object filter, Object handback, Subject delegate)
/*     */     throws InstanceNotFoundException, IOException
/*     */   {
/* 129 */     Call call = createCall();
/*     */     
/* 131 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "addNotificationListener"));
/* 132 */     call.addParameter("observed", qObjectName, ParameterMode.IN);
/* 133 */     call.addParameter("listener", qObjectName, ParameterMode.IN);
/* 134 */     call.addParameter("filter", XMLType.XSD_ANY, ParameterMode.IN);
/* 135 */     call.addParameter("handback", XMLType.XSD_ANY, ParameterMode.IN);
/* 136 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 137 */     call.setReturnType(XMLType.AXIS_VOID);
/*     */     
/* 139 */     call.invoke(new Object[] { name, listener, filter, handback, delegate });
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName name, ObjectName listener, Subject delegate)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 145 */     Call call = createCall();
/*     */     
/* 147 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "removeNotificationListener"));
/* 148 */     call.addParameter("observed", qObjectName, ParameterMode.IN);
/* 149 */     call.addParameter("listener", qObjectName, ParameterMode.IN);
/* 150 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 151 */     call.setReturnType(XMLType.AXIS_VOID);
/*     */     
/* 153 */     call.invoke(new Object[] { name, listener, delegate });
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName name, ObjectName listener, Object filter, Object handback, Subject delegate)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 159 */     Call call = createCall();
/*     */     
/* 161 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "removeNotificationListener"));
/* 162 */     call.addParameter("observed", qObjectName, ParameterMode.IN);
/* 163 */     call.addParameter("listener", qObjectName, ParameterMode.IN);
/* 164 */     call.addParameter("filter", XMLType.XSD_ANY, ParameterMode.IN);
/* 165 */     call.addParameter("handback", XMLType.XSD_ANY, ParameterMode.IN);
/* 166 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 167 */     call.setReturnType(XMLType.AXIS_VOID);
/*     */     
/* 169 */     call.invoke(new Object[] { name, listener, filter, handback, delegate });
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo(ObjectName objectName, Subject delegate) throws InstanceNotFoundException, IntrospectionException, ReflectionException, IOException
/*     */   {
/* 174 */     Call call = createCall();
/*     */     
/* 176 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "getMBeanInfo"));
/* 177 */     call.addParameter("objectName", qObjectName, ParameterMode.IN);
/* 178 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 179 */     call.setReturnType(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "MBeanInfo"));
/*     */     
/* 181 */     MBeanInfo info = (MBeanInfo)call.invoke(new Object[] { objectName, delegate });
/* 182 */     return info;
/*     */   }
/*     */   
/*     */   public boolean isInstanceOf(ObjectName objectName, String className, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 187 */     Call call = createCall();
/*     */     
/* 189 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "isInstanceOf"));
/* 190 */     call.addParameter("objectName", qObjectName, ParameterMode.IN);
/* 191 */     call.addParameter("className", XMLType.XSD_STRING, ParameterMode.IN);
/* 192 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 193 */     call.setReturnType(XMLType.XSD_BOOLEAN);
/*     */     
/* 195 */     Boolean isinstanceof = (Boolean)call.invoke(new Object[] { objectName, className, delegate });
/* 196 */     return isinstanceof.booleanValue();
/*     */   }
/*     */   
/*     */   public String[] getDomains(Subject delegate) throws IOException
/*     */   {
/* 201 */     Call call = createCall();
/*     */     
/* 203 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "getDomains"));
/* 204 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 205 */     call.setReturnType(XMLType.SOAP_ARRAY);
/*     */     
/* 207 */     String[] domains = (String[])call.invoke(new Object[] { delegate });
/* 208 */     return domains;
/*     */   }
/*     */   
/*     */   public String getDefaultDomain(Subject delegate) throws IOException
/*     */   {
/* 213 */     Call call = createCall();
/*     */     
/* 215 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "getDefaultDomain"));
/* 216 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 217 */     call.setReturnType(XMLType.XSD_STRING);
/*     */     
/* 219 */     String domain = (String)call.invoke(new Object[] { delegate });
/* 220 */     return domain;
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName, Object args, String[] parameters, Subject delegate) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException
/*     */   {
/* 225 */     Call call = createCall();
/*     */     
/* 227 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "createMBean"));
/*     */     
/* 229 */     call.addParameter("className", XMLType.XSD_STRING, ParameterMode.IN);
/* 230 */     call.addParameter("objectName", qObjectName, ParameterMode.IN);
/* 231 */     call.addParameter("arguments", XMLType.SOAP_ARRAY, ParameterMode.IN);
/* 232 */     call.addParameter("signature", XMLType.SOAP_ARRAY, ParameterMode.IN);
/* 233 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 234 */     call.setReturnType(qObjectInstance);
/*     */     
/* 236 */     ObjectInstance instance = (ObjectInstance)call.invoke(new Object[] { className, objectName, args, parameters, delegate });
/* 237 */     return instance;
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName, ObjectName loaderName, Object args, String[] parameters, Subject delegate) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException
/*     */   {
/* 242 */     Call call = createCall();
/*     */     
/* 244 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "createMBean"));
/*     */     
/* 246 */     call.addParameter("className", XMLType.XSD_STRING, ParameterMode.IN);
/* 247 */     call.addParameter("objectName", qObjectName, ParameterMode.IN);
/* 248 */     call.addParameter("loaderName", qObjectName, ParameterMode.IN);
/* 249 */     call.addParameter("arguments", XMLType.SOAP_ARRAY, ParameterMode.IN);
/* 250 */     call.addParameter("signature", XMLType.SOAP_ARRAY, ParameterMode.IN);
/* 251 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 252 */     call.setReturnType(qObjectInstance);
/*     */     
/* 254 */     ObjectInstance instance = (ObjectInstance)call.invoke(new Object[] { className, objectName, loaderName, args, parameters, delegate });
/* 255 */     return instance;
/*     */   }
/*     */   
/*     */   public void unregisterMBean(ObjectName objectName, Subject delegate) throws InstanceNotFoundException, MBeanRegistrationException, IOException
/*     */   {
/* 260 */     Call call = createCall();
/*     */     
/* 262 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "unregisterMBean"));
/* 263 */     call.addParameter("objectName", qObjectName, ParameterMode.IN);
/* 264 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 265 */     call.setReturnType(XMLType.AXIS_VOID);
/*     */     
/* 267 */     call.invoke(new Object[] { objectName, delegate });
/*     */   }
/*     */   
/*     */   public Object getAttribute(ObjectName objectName, String attribute, Subject delegate) throws MBeanException, AttributeNotFoundException, InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 272 */     Call call = createCall();
/*     */     
/* 274 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "getAttribute"));
/* 275 */     call.addParameter("objectName", qObjectName, ParameterMode.IN);
/* 276 */     call.addParameter("attributeName", XMLType.XSD_STRING, ParameterMode.IN);
/* 277 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 278 */     call.setReturnType(XMLType.XSD_ANY);
/*     */     
/* 280 */     Object result = call.invoke(new Object[] { objectName, attribute, delegate });
/* 281 */     return result;
/*     */   }
/*     */   
/*     */   public void setAttribute(ObjectName objectName, Object attribute, Subject delegate) throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException, IOException
/*     */   {
/* 286 */     Call call = createCall();
/*     */     
/* 288 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "setAttribute"));
/*     */     
/* 290 */     call.addParameter("objectName", qObjectName, ParameterMode.IN);
/* 291 */     call.addParameter("attribute", new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "Attribute"), ParameterMode.IN);
/* 292 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 293 */     call.setReturnType(XMLType.AXIS_VOID);
/*     */     
/* 295 */     call.invoke(new Object[] { objectName, attribute, delegate });
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(ObjectName objectName, String[] attributes, Subject delegate) throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 300 */     Call call = createCall();
/*     */     
/* 302 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "getAttributes"));
/* 303 */     call.addParameter("objectName", qObjectName, ParameterMode.IN);
/* 304 */     call.addParameter("attributeNames", XMLType.SOAP_ARRAY, ParameterMode.IN);
/* 305 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 306 */     call.setReturnType(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "AttributeList"));
/*     */     
/* 308 */     AttributeList list = (AttributeList)call.invoke(new Object[] { objectName, attributes, delegate });
/* 309 */     return list;
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(ObjectName objectName, Object attributes, Subject delegate) throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 314 */     Call call = createCall();
/*     */     
/* 316 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "setAttributes"));
/* 317 */     QName qAttributeList = new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "AttributeList");
/* 318 */     call.addParameter("objectName", qObjectName, ParameterMode.IN);
/* 319 */     call.addParameter("attributeList", qAttributeList, ParameterMode.IN);
/* 320 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 321 */     call.setReturnType(qAttributeList);
/*     */     
/* 323 */     AttributeList list = (AttributeList)call.invoke(new Object[] { objectName, attributes, delegate });
/* 324 */     return list;
/*     */   }
/*     */   
/*     */   public Object invoke(ObjectName objectName, String methodName, Object args, String[] parameters, Subject delegate) throws InstanceNotFoundException, MBeanException, ReflectionException, IOException
/*     */   {
/* 329 */     Call call = createCall();
/*     */     
/* 331 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "invoke"));
/* 332 */     call.addParameter("objectName", qObjectName, ParameterMode.IN);
/* 333 */     call.addParameter("operationName", XMLType.XSD_STRING, ParameterMode.IN);
/* 334 */     call.addParameter("arguments", XMLType.SOAP_ARRAY, ParameterMode.IN);
/* 335 */     call.addParameter("signature", XMLType.SOAP_ARRAY, ParameterMode.IN);
/* 336 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 337 */     call.setReturnType(XMLType.XSD_ANY);
/*     */     
/* 339 */     Object object = call.invoke(new Object[] { objectName, methodName, args, parameters, delegate });
/* 340 */     return object;
/*     */   }
/*     */   
/*     */   public Integer getMBeanCount(Subject delegate) throws IOException
/*     */   {
/* 345 */     Call call = createCall();
/*     */     
/* 347 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "getMBeanCount"));
/* 348 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 349 */     call.setReturnType(XMLType.XSD_INT);
/*     */     
/* 351 */     Integer count = (Integer)call.invoke(new Object[] { delegate });
/* 352 */     return count;
/*     */   }
/*     */   
/*     */   public boolean isRegistered(ObjectName objectName, Subject delegate) throws IOException
/*     */   {
/* 357 */     Call call = createCall();
/*     */     
/* 359 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "isRegistered"));
/*     */     
/* 361 */     call.addParameter("objectName", qObjectName, ParameterMode.IN);
/* 362 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 363 */     call.setReturnType(XMLType.XSD_BOOLEAN);
/*     */     
/* 365 */     Boolean registered = (Boolean)call.invoke(new Object[] { objectName, delegate });
/* 366 */     return registered.booleanValue();
/*     */   }
/*     */   
/*     */   public ObjectInstance getObjectInstance(ObjectName objectName, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 371 */     Call call = createCall();
/*     */     
/* 373 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "getObjectInstance"));
/* 374 */     call.addParameter("objectName", qObjectName, ParameterMode.IN);
/* 375 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 376 */     call.setReturnType(qObjectInstance);
/*     */     
/* 378 */     ObjectInstance instance = (ObjectInstance)call.invoke(new Object[] { objectName, delegate });
/* 379 */     return instance;
/*     */   }
/*     */   
/*     */   public Set queryMBeans(ObjectName patternName, Object filter, Subject delegate) throws IOException
/*     */   {
/* 384 */     Call call = createCall();
/*     */     
/* 386 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "queryMBeans"));
/* 387 */     call.addParameter("pattern", qObjectName, ParameterMode.IN);
/* 388 */     call.addParameter("query", XMLType.XSD_ANY, ParameterMode.IN);
/* 389 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 390 */     call.setReturnType(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "Set"));
/*     */     
/* 392 */     Set set = (Set)call.invoke(new Object[] { patternName, filter, delegate });
/* 393 */     return set;
/*     */   }
/*     */   
/*     */   public Set queryNames(ObjectName patternName, Object filter, Subject delegate) throws IOException
/*     */   {
/* 398 */     Call call = createCall();
/*     */     
/* 400 */     call.setOperationName(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "queryNames"));
/* 401 */     call.addParameter("pattern", qObjectName, ParameterMode.IN);
/* 402 */     call.addParameter("query", XMLType.XSD_ANY, ParameterMode.IN);
/* 403 */     call.addParameter("delegate", qSubject, ParameterMode.IN);
/* 404 */     call.setReturnType(new QName("http://mx4j.sourceforge.net/remote/soap/1.0", "Set"));
/*     */     
/* 406 */     Set set = (Set)call.invoke(new Object[] { patternName, filter, delegate });
/* 407 */     return set;
/*     */   }
/*     */   
/*     */   private Call createCall() throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 414 */       Call call = (Call)this.service.createCall();
/*     */       
/* 416 */       call.setTargetEndpointAddress(this.endpoint);
/*     */       
/* 418 */       SOAPHeaderElement connectionIDHeader = new SOAPHeaderElement("http://mx4j.sourceforge.net/remote/soap/1.0", "connectionId", this.connectionId);
/* 419 */       connectionIDHeader.setMustUnderstand(true);
/* 420 */       call.addHeader(connectionIDHeader);
/*     */       
/* 422 */       return call;
/*     */     }
/*     */     catch (ServiceException x)
/*     */     {
/* 426 */       throw new IOException(x.toString());
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/SOAPClientInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */