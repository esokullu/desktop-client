/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.MBeanAttributeInfo;
/*    */ import javax.management.MBeanConstructorInfo;
/*    */ import javax.management.MBeanInfo;
/*    */ import javax.management.MBeanNotificationInfo;
/*    */ import javax.management.MBeanOperationInfo;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanInfoDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private String className;
/*    */   private String description;
/*    */   private MBeanAttributeInfo[] attributes;
/*    */   private MBeanConstructorInfo[] constructors;
/*    */   private MBeanOperationInfo[] operations;
/*    */   private MBeanNotificationInfo[] notifications;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 33 */     if ("className".equals(hint)) {
/* 34 */       this.className = ((String)value);
/* 35 */     } else if ("description".equals(hint)) {
/* 36 */       this.description = ((String)value);
/* 37 */     } else if ("attributes".equals(hint)) {
/* 38 */       this.attributes = ((MBeanAttributeInfo[])value);
/* 39 */     } else if ("constructors".equals(hint)) {
/* 40 */       this.constructors = ((MBeanConstructorInfo[])value);
/* 41 */     } else if ("operations".equals(hint)) {
/* 42 */       this.operations = ((MBeanOperationInfo[])value);
/* 43 */     } else if ("notifications".equals(hint)) this.notifications = ((MBeanNotificationInfo[])value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 48 */     return new MBeanInfo(this.className, this.description, this.attributes, this.constructors, this.operations, this.notifications);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanInfoDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */