/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.remote.TargetedNotification;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TargetedNotificationSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String NOTIFICATION = "notification";
/*    */   static final String LISTENER_ID = "listenerID";
/* 28 */   private static final QName NOTIFICATION_QNAME = new QName("", "notification");
/* 29 */   private static final QName LISTENER_ID_QNAME = new QName("", "listenerID");
/*    */   static final String TYPE = "TargetedNotification";
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 34 */     TargetedNotification targetedNotification = (TargetedNotification)value;
/* 35 */     context.startElement(name, attributes);
/* 36 */     context.serialize(NOTIFICATION_QNAME, null, targetedNotification.getNotification());
/* 37 */     context.serialize(LISTENER_ID_QNAME, null, targetedNotification.getListenerID());
/* 38 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types) throws Exception
/*    */   {
/* 43 */     Element complexType = types.createElement("complexType");
/* 44 */     complexType.setAttribute("name", "TargetedNotification");
/* 45 */     Element allElement = types.createElement("all");
/* 46 */     complexType.appendChild(allElement);
/*    */     
/* 48 */     Element typeElement = types.createElement("element");
/* 49 */     typeElement.setAttribute("name", "notification");
/* 50 */     typeElement.setAttribute("type", "Notification");
/* 51 */     allElement.appendChild(typeElement);
/*    */     
/* 53 */     Element sourceElement = types.createElement("element");
/* 54 */     sourceElement.setAttribute("name", "listenerID");
/* 55 */     sourceElement.setAttribute("type", XMLType.XSD_INT.getLocalPart());
/* 56 */     allElement.appendChild(sourceElement);
/*    */     
/* 58 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/TargetedNotificationSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */