/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.ObjectInstance;
/*    */ import javax.management.ObjectName;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectInstanceDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private ObjectName objectName;
/*    */   private String className;
/*    */   
/*    */   protected void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 26 */     if ("className".equals(hint)) {
/* 27 */       this.className = ((String)value);
/* 28 */     } else if ("objectName".equals(hint)) this.objectName = ((ObjectName)value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 33 */     return new ObjectInstance(this.objectName, this.className);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/ObjectInstanceDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */