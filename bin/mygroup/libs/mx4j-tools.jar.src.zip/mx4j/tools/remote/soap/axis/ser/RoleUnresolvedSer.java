/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import javax.management.ObjectName;
/*    */ import javax.management.relation.RoleUnresolved;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.Constants;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleUnresolvedSer
/*    */   extends RoleSer
/*    */ {
/*    */   static final String TYPE = "RoleUnresolved";
/*    */   static final String PROBLEM_TYPE = "problemType";
/* 31 */   private static final QName PROBLEM_TYPE_QNAME = new QName("", "problemType");
/*    */   
/*    */ 
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context)
/*    */     throws IOException
/*    */   {
/* 37 */     RoleUnresolved role = (RoleUnresolved)value;
/* 38 */     context.startElement(name, attributes);
/* 39 */     context.serialize(ROLE_NAME_QNAME, null, role.getRoleName());
/* 40 */     for (Iterator i = role.getRoleValue().iterator(); i.hasNext();)
/*    */     {
/* 42 */       ObjectName on = (ObjectName)i.next();
/* 43 */       context.serialize(Constants.QNAME_LITERAL_ITEM, null, on);
/*    */     }
/* 45 */     context.serialize(PROBLEM_TYPE_QNAME, null, new Integer(role.getProblemType()));
/* 46 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types) throws Exception
/*    */   {
/* 51 */     Element complexType = super.writeSchema(aClass, types);
/* 52 */     Element problemType = types.createElement("element");
/* 53 */     problemType.setAttribute("name", "problemType");
/* 54 */     problemType.setAttribute("type", XMLType.XSD_INT.getLocalPart());
/* 55 */     complexType.appendChild(problemType);
/* 56 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/RoleUnresolvedSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */