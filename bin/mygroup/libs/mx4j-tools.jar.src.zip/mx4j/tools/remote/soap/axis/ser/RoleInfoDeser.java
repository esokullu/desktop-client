/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.relation.RoleInfo;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleInfoDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private String name;
/*    */   private String description;
/*    */   private String refMBeanClassName;
/*    */   private boolean readable;
/*    */   private boolean writeable;
/*    */   private int minDegree;
/*    */   private int maxDegree;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 30 */     if ("name".equals(hint)) this.name = ((String)value);
/* 31 */     if ("description".equals(hint)) this.description = ((String)value);
/* 32 */     if ("refMBeanClassName".equals(hint)) this.refMBeanClassName = ((String)value);
/* 33 */     if ("readable".equals(hint)) this.readable = ((Boolean)value).booleanValue();
/* 34 */     if ("writeable".equals(hint)) this.writeable = ((Boolean)value).booleanValue();
/* 35 */     if ("minDegree".equals(hint)) this.minDegree = ((Integer)value).intValue();
/* 36 */     if ("maxDegree".equals(hint)) this.maxDegree = ((Integer)value).intValue();
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/*    */     try
/*    */     {
/* 43 */       return new RoleInfo(this.name, this.refMBeanClassName, this.readable, this.writeable, this.minDegree, this.maxDegree, this.description);
/*    */ 
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */ 
/* 49 */       throw new SAXException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/RoleInfoDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */