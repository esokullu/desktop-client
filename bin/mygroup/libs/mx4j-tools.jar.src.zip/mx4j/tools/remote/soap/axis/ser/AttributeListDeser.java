/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.AttributeList;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.Constants;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeListDeser
/*    */   extends AxisDeserializer
/*    */ {
/* 21 */   private AttributeList attributes = new AttributeList();
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint) throws SAXException
/*    */   {
/* 25 */     if (Constants.QNAME_LITERAL_ITEM.getLocalPart().equals(hint)) this.attributes.add(value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 30 */     return this.attributes;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/AttributeListDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */