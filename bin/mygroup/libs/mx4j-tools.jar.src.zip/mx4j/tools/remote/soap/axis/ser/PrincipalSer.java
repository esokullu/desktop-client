/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.security.Principal;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrincipalSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "Principal";
/*    */   static final String CLASS_NAME = "className";
/*    */   static final String NAME = "name";
/* 29 */   private static final QName CLASS_NAME_QNAME = new QName("", "className");
/* 30 */   private static final QName NAME_QNAME = new QName("", "name");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 34 */     Principal principal = (Principal)value;
/* 35 */     context.startElement(name, attributes);
/* 36 */     context.serialize(CLASS_NAME_QNAME, null, principal.getClass().getName());
/* 37 */     context.serialize(NAME_QNAME, null, principal.getName());
/* 38 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class javaType, Types types) throws Exception
/*    */   {
/* 43 */     Element complexType = types.createElement("complexType");
/* 44 */     complexType.setAttribute("name", "Principal");
/* 45 */     Element allElement = types.createElement("all");
/* 46 */     complexType.appendChild(allElement);
/* 47 */     Element classNameElement = types.createElement("element");
/* 48 */     classNameElement.setAttribute("name", "className");
/* 49 */     classNameElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 50 */     allElement.appendChild(classNameElement);
/* 51 */     Element nameElement = types.createElement("element");
/* 52 */     nameElement.setAttribute("name", "name");
/* 53 */     nameElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 54 */     allElement.appendChild(nameElement);
/* 55 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/PrincipalSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */