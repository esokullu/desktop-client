/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.MBeanNotificationInfo;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanNotificationInfoSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "MBeanNotificationInfo";
/*    */   static final String NAME = "name";
/*    */   static final String DESCRIPTION = "description";
/*    */   static final String NOTIFICATION_TYPES = "notificationTypes";
/* 30 */   private static final QName NAME_QNAME = new QName("", "name");
/* 31 */   private static final QName DESCRIPTION_QNAME = new QName("", "description");
/* 32 */   private static final QName NOTIFICATION_TYPES_QNAME = new QName("", "notificationTypes");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 36 */     MBeanNotificationInfo info = (MBeanNotificationInfo)value;
/* 37 */     context.startElement(name, attributes);
/* 38 */     context.serialize(NAME_QNAME, null, info.getName());
/* 39 */     context.serialize(DESCRIPTION_QNAME, null, info.getDescription());
/* 40 */     context.serialize(NOTIFICATION_TYPES_QNAME, null, info.getNotifTypes());
/* 41 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class javaType, Types types) throws Exception
/*    */   {
/* 46 */     Element complexType = types.createElement("complexType");
/* 47 */     complexType.setAttribute("name", "MBeanNotificationInfo");
/* 48 */     Element allElement = types.createElement("all");
/* 49 */     complexType.appendChild(allElement);
/*    */     
/* 51 */     Element nameElement = types.createElement("element");
/* 52 */     nameElement.setAttribute("name", "name");
/* 53 */     nameElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 54 */     allElement.appendChild(nameElement);
/*    */     
/* 56 */     Element descrElement = types.createElement("element");
/* 57 */     descrElement.setAttribute("name", "description");
/* 58 */     descrElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 59 */     allElement.appendChild(descrElement);
/*    */     
/* 61 */     Element typesElement = types.createElement("element");
/* 62 */     typesElement.setAttribute("name", "notificationTypes");
/* 63 */     typesElement.setAttribute("type", XMLType.SOAP_ARRAY.getLocalPart());
/* 64 */     allElement.appendChild(typesElement);
/*    */     
/* 66 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanNotificationInfoSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */