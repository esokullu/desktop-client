/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import javax.management.ObjectName;
/*    */ import javax.management.relation.Role;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.Constants;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "Role";
/*    */   static final String ROLE_NAME = "roleName";
/*    */   static final String ROLE_VALUE = "roleValue";
/* 32 */   protected static final QName ROLE_NAME_QNAME = new QName("", "roleName");
/* 33 */   protected static final QName ROLE_VALUE_QNAME = new QName("", "roleValue");
/*    */   
/*    */ 
/*    */ 
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context)
/*    */     throws IOException
/*    */   {
/* 40 */     Role role = (Role)value;
/* 41 */     context.startElement(name, attributes);
/* 42 */     context.serialize(ROLE_NAME_QNAME, null, role.getRoleName());
/* 43 */     for (Iterator i = role.getRoleValue().iterator(); i.hasNext();)
/*    */     {
/* 45 */       ObjectName on = (ObjectName)i.next();
/* 46 */       context.serialize(Constants.QNAME_LITERAL_ITEM, null, on);
/*    */     }
/* 48 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types) throws Exception
/*    */   {
/* 53 */     Element complexType = types.createElement("complexType");
/* 54 */     complexType.setAttribute("name", "Role");
/*    */     
/* 56 */     Element nameElement = types.createElement("element");
/* 57 */     nameElement.setAttribute("name", "roleName");
/* 58 */     nameElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 59 */     complexType.appendChild(nameElement);
/*    */     
/* 61 */     types.writeSchemaElement(Constants.SOAP_VECTOR, complexType);
/* 62 */     Element sequence = types.createElement("sequence");
/* 63 */     complexType.appendChild(sequence);
/* 64 */     Element element = types.createElement("element");
/* 65 */     element.setAttribute("name", Constants.QNAME_LITERAL_ITEM.getLocalPart());
/* 66 */     element.setAttribute("minOccurs", "0");
/* 67 */     element.setAttribute("maxOccurs", "unbounded");
/* 68 */     element.setAttribute("type", "Attribute");
/* 69 */     sequence.appendChild(element);
/* 70 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/RoleSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */