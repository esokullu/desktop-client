/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.util.Set;
/*    */ import javax.security.auth.Subject;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubjectDeser
/*    */   extends AxisDeserializer
/*    */ {
/*    */   private boolean readOnly;
/*    */   private Set principals;
/*    */   private Set publicCredentials;
/*    */   private Set privateCredentials;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 28 */     if ("readOnly".equals(hint)) {
/* 29 */       this.readOnly = ((Boolean)value).booleanValue();
/* 30 */     } else if ("principals".equals(hint)) {
/* 31 */       this.principals = ((Set)value);
/* 32 */     } else if ("publicCredentials".equals(hint)) {
/* 33 */       this.publicCredentials = ((Set)value);
/* 34 */     } else if ("privateCredentials".equals(hint)) this.privateCredentials = ((Set)value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 39 */     return new Subject(this.readOnly, this.principals, this.publicCredentials, this.privateCredentials);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/SubjectDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */