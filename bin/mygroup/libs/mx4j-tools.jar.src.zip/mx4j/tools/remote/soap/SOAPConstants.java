package mx4j.tools.remote.soap;

class SOAPConstants
{
  static final String NAMESPACE_URI = "http://mx4j.sourceforge.net/remote/soap/1.0";
  static final String CONNECTION_ID_HEADER_NAME = "connectionId";
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/SOAPConstants.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */