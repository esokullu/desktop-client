/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.ser.BaseDeserializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanAttributeInfoDeserFactory
/*    */   extends BaseDeserializerFactory
/*    */ {
/*    */   public MBeanAttributeInfoDeserFactory(Class javaType, QName xmlType)
/*    */   {
/* 22 */     super(MBeanAttributeInfoDeser.class, xmlType, javaType);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanAttributeInfoDeserFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */