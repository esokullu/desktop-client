/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.ObjectName;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectNameSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "ObjectName";
/*    */   static final String NAME = "canonicalName";
/* 28 */   private static final QName NAME_QNAME = new QName("", "canonicalName");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 32 */     ObjectName objectName = (ObjectName)value;
/* 33 */     context.startElement(name, attributes);
/* 34 */     context.serialize(NAME_QNAME, null, objectName.getCanonicalName());
/* 35 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class javaType, Types types) throws Exception
/*    */   {
/* 40 */     Element complexType = types.createElement("complexType");
/* 41 */     complexType.setAttribute("name", "ObjectName");
/* 42 */     Element allElement = types.createElement("all");
/* 43 */     complexType.appendChild(allElement);
/* 44 */     Element element = types.createElement("element");
/* 45 */     element.setAttribute("name", "canonicalName");
/* 46 */     element.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 47 */     allElement.appendChild(element);
/* 48 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/ObjectNameSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */