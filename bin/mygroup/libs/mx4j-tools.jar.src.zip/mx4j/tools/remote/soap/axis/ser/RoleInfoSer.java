/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.relation.RoleInfo;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleInfoSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "RoleInfo";
/*    */   static final String MAX_DEGREE = "maxDegree";
/*    */   static final String MIN_DEGREE = "minDegree";
/*    */   static final String NAME = "name";
/*    */   static final String DESCRIPTION = "description";
/*    */   static final String REF_MBEAN_CLASS_NAME = "refMBeanClassName";
/*    */   static final String READABLE = "readable";
/*    */   static final String WRITEABLE = "writeable";
/* 35 */   private static final QName MAX_DEGREE_QNAME = new QName("", "maxDegree");
/* 36 */   private static final QName MIN_DEGREE_QNAME = new QName("", "minDegree");
/* 37 */   private static final QName NAME_QNAME = new QName("", "name");
/* 38 */   private static final QName DESCRIPTION_QNAME = new QName("", "description");
/* 39 */   private static final QName REF_MBEAN_CLASS_NAME_QNAME = new QName("", "refMBeanClassName");
/* 40 */   private static final QName READABLE_QNAME = new QName("", "readable");
/* 41 */   private static final QName WRITABLE_QNAME = new QName("", "writeable");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 45 */     RoleInfo roleInfo = (RoleInfo)value;
/* 46 */     context.startElement(name, attributes);
/* 47 */     context.serialize(MAX_DEGREE_QNAME, null, new Integer(roleInfo.getMaxDegree()));
/* 48 */     context.serialize(MIN_DEGREE_QNAME, null, new Integer(roleInfo.getMaxDegree()));
/* 49 */     context.serialize(NAME_QNAME, null, roleInfo.getName());
/* 50 */     context.serialize(DESCRIPTION_QNAME, null, roleInfo.getDescription());
/* 51 */     context.serialize(REF_MBEAN_CLASS_NAME_QNAME, null, roleInfo.getRefMBeanClassName());
/* 52 */     context.serialize(READABLE_QNAME, null, roleInfo.isReadable() ? Boolean.TRUE : Boolean.FALSE);
/* 53 */     context.serialize(WRITABLE_QNAME, null, roleInfo.isWritable() ? Boolean.TRUE : Boolean.FALSE);
/* 54 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class javaType, Types types) throws Exception
/*    */   {
/* 59 */     Element complexType = types.createElement("complexType");
/* 60 */     complexType.setAttribute("name", "RoleInfo");
/* 61 */     Element allElement = types.createElement("all");
/* 62 */     complexType.appendChild(allElement);
/*    */     
/* 64 */     Element maxDegreeElement = types.createElement("element");
/* 65 */     maxDegreeElement.setAttribute("name", "maxDegree");
/* 66 */     maxDegreeElement.setAttribute("type", XMLType.XSD_INT.getLocalPart());
/* 67 */     allElement.appendChild(maxDegreeElement);
/*    */     
/* 69 */     Element minDegreeElement = types.createElement("element");
/* 70 */     minDegreeElement.setAttribute("name", "minDegree");
/* 71 */     minDegreeElement.setAttribute("type", XMLType.XSD_INT.getLocalPart());
/* 72 */     allElement.appendChild(minDegreeElement);
/*    */     
/* 74 */     Element nameElement = types.createElement("element");
/* 75 */     nameElement.setAttribute("name", "name");
/* 76 */     nameElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 77 */     allElement.appendChild(nameElement);
/*    */     
/* 79 */     Element descriptionElement = types.createElement("element");
/* 80 */     descriptionElement.setAttribute("name", "description");
/* 81 */     descriptionElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 82 */     allElement.appendChild(descriptionElement);
/*    */     
/* 84 */     Element refMBeanClassNameElement = types.createElement("element");
/* 85 */     refMBeanClassNameElement.setAttribute("name", "refMBeanClassName");
/* 86 */     refMBeanClassNameElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 87 */     allElement.appendChild(refMBeanClassNameElement);
/*    */     
/* 89 */     Element readableElement = types.createElement("element");
/* 90 */     readableElement.setAttribute("name", "readable");
/* 91 */     readableElement.setAttribute("type", XMLType.XSD_BOOLEAN.getLocalPart());
/* 92 */     allElement.appendChild(readableElement);
/*    */     
/* 94 */     Element writeableElement = types.createElement("element");
/* 95 */     writeableElement.setAttribute("name", "writeable");
/* 96 */     writeableElement.setAttribute("type", XMLType.XSD_BOOLEAN.getLocalPart());
/* 97 */     allElement.appendChild(writeableElement);
/*    */     
/* 99 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/RoleInfoSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */