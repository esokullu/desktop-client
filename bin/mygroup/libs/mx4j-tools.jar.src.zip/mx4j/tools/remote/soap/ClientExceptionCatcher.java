/*     */ package mx4j.tools.remote.soap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.RuntimeMBeanException;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import mx4j.tools.remote.http.HTTPConnection;
/*     */ import org.apache.axis.AxisFault;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClientExceptionCatcher
/*     */   implements InvocationHandler
/*     */ {
/*     */   private final HTTPConnection target;
/*     */   
/*     */   public static HTTPConnection newInstance(HTTPConnection target)
/*     */   {
/*  37 */     ClientExceptionCatcher handler = new ClientExceptionCatcher(target);
/*  38 */     return (HTTPConnection)Proxy.newProxyInstance(handler.getClass().getClassLoader(), new Class[] { HTTPConnection.class }, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private ClientExceptionCatcher(HTTPConnection target)
/*     */   {
/*  45 */     this.target = target;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object proxy, Method method, Object[] args)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/*  54 */       return method.invoke(this.target, args);
/*     */     }
/*     */     catch (InvocationTargetException x)
/*     */     {
/*  58 */       throw x.getTargetException();
/*     */ 
/*     */     }
/*     */     catch (Throwable x)
/*     */     {
/*  63 */       throw handleException(x, method.getExceptionTypes());
/*     */     }
/*     */   }
/*     */   
/*     */   private Throwable handleException(Throwable x, Class[] declared)
/*     */   {
/*  69 */     if ((x instanceof Error)) return x;
/*  70 */     if ((x instanceof AxisFault)) x = extractThrowable((AxisFault)x);
/*  71 */     if (isDeclaredOrRuntime(x, declared)) return x;
/*  72 */     return new IOException(x.toString());
/*     */   }
/*     */   
/*     */   private Throwable extractThrowable(AxisFault fault)
/*     */   {
/*  77 */     String name = fault.getFaultString();
/*  78 */     if (name == null) { return fault;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  83 */     int colon = name.indexOf(':');
/*  84 */     String className = colon < 0 ? name : name.substring(0, colon).trim();
/*  85 */     String message = colon < 0 ? null : name.substring(colon + 1).trim();
/*     */     
/*  87 */     Class cls = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  92 */       cls = getClass().getClassLoader().loadClass(className);
/*     */     }
/*     */     catch (ClassNotFoundException x)
/*     */     {
/*  96 */       Logger logger = getLogger();
/*  97 */       if (logger.isEnabledFor(0)) { logger.trace("Cannot load Throwable class " + className, x);
/*     */       }
/*     */     }
/* 100 */     if (cls == null) { return fault;
/*     */     }
/* 102 */     Object exception = null;
/* 103 */     if (message != null)
/*     */     {
/*     */       try
/*     */       {
/*     */ 
/* 108 */         Constructor ctor = cls.getConstructor(new Class[] { String.class });
/* 109 */         exception = ctor.newInstance(new Object[] { message });
/*     */       }
/*     */       catch (Throwable x)
/*     */       {
/* 113 */         Logger logger = getLogger();
/* 114 */         if (logger.isEnabledFor(0)) { logger.trace("Cannot find constructor " + className + "(String message)", x);
/*     */         }
/*     */       }
/*     */     }
/* 118 */     if (exception == null)
/*     */     {
/*     */       try
/*     */       {
/* 122 */         exception = cls.newInstance();
/*     */       }
/*     */       catch (Throwable x)
/*     */       {
/* 126 */         Logger logger = getLogger();
/* 127 */         if (logger.isEnabledFor(0)) { logger.trace("Cannot find constructor " + className + "()", x);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 132 */     if (MBeanException.class.getName().equals(className))
/*     */     {
/* 134 */       exception = new MBeanException(null, message);
/*     */     }
/* 136 */     else if (RuntimeMBeanException.class.getName().equals(className))
/*     */     {
/* 138 */       exception = new RuntimeMBeanException(null, message);
/*     */     }
/*     */     
/* 141 */     if (!(exception instanceof Throwable))
/*     */     {
/* 143 */       Logger logger = getLogger();
/* 144 */       if (logger.isEnabledFor(0)) logger.trace("Could not recreate exception thrown on server side: " + className);
/* 145 */       return fault;
/*     */     }
/*     */     
/* 148 */     return (Throwable)exception;
/*     */   }
/*     */   
/*     */   private boolean isDeclaredOrRuntime(Throwable x, Class[] declared)
/*     */   {
/* 153 */     if ((x instanceof RuntimeException)) { return true;
/*     */     }
/* 155 */     for (int i = 0; i < declared.length; i++)
/*     */     {
/* 157 */       Class exception = declared[i];
/* 158 */       if (exception.isInstance(x)) return true;
/*     */     }
/* 160 */     return false;
/*     */   }
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/* 165 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/ClientExceptionCatcher.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */