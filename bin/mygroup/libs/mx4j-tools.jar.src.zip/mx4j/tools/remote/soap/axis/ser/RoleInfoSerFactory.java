/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.ser.BaseSerializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleInfoSerFactory
/*    */   extends BaseSerializerFactory
/*    */ {
/*    */   public RoleInfoSerFactory(Class javaType, QName xmlType)
/*    */   {
/* 22 */     super(RoleInfoSer.class, xmlType, javaType);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/RoleInfoSerFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */