/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.management.timer.TimerNotification;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimerNotificationDeser
/*    */   extends NotificationDeser
/*    */ {
/*    */   private Integer notificationID;
/*    */   
/*    */   public void onSetChildValue(Object value, Object hint)
/*    */     throws SAXException
/*    */   {
/* 24 */     super.onSetChildValue(value, hint);
/* 25 */     if ("notificationID".equals(hint)) this.notificationID = ((Integer)value);
/*    */   }
/*    */   
/*    */   protected Object createObject() throws SAXException
/*    */   {
/* 30 */     TimerNotification notification = new TimerNotification(getType(), getSource(), getSequenceNumber(), getTimeStamp(), getMessage(), this.notificationID);
/* 31 */     return notification;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/TimerNotificationDeser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */