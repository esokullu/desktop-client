/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.MBeanAttributeInfo;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanAttributeInfoSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "MBeanAttributeInfo";
/*    */   static final String NAME = "name";
/*    */   static final String CLASS_NAME = "type";
/*    */   static final String DESCRIPTION = "description";
/*    */   static final String IS_READABLE = "isReadable";
/*    */   static final String IS_WRITABLE = "isWritable";
/*    */   static final String IS_IS = "isIs";
/* 33 */   private static final QName NAME_QNAME = new QName("", "name");
/* 34 */   private static final QName TYPE_QNAME = new QName("", "type");
/* 35 */   private static final QName DESCRIPTION_QNAME = new QName("", "description");
/* 36 */   private static final QName IS_READABLE_QNAME = new QName("", "isReadable");
/* 37 */   private static final QName IS_WRITABLE_QNAME = new QName("", "isWritable");
/* 38 */   private static final QName IS_IS_QNAME = new QName("", "isIs");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 42 */     MBeanAttributeInfo info = (MBeanAttributeInfo)value;
/* 43 */     context.startElement(name, attributes);
/* 44 */     context.serialize(NAME_QNAME, null, info.getName());
/* 45 */     context.serialize(TYPE_QNAME, null, info.getType());
/* 46 */     context.serialize(DESCRIPTION_QNAME, null, info.getDescription());
/* 47 */     context.serialize(IS_READABLE_QNAME, null, info.isReadable() ? Boolean.TRUE : Boolean.FALSE);
/* 48 */     context.serialize(IS_WRITABLE_QNAME, null, info.isWritable() ? Boolean.TRUE : Boolean.FALSE);
/* 49 */     context.serialize(IS_IS_QNAME, null, info.isIs() ? Boolean.TRUE : Boolean.FALSE);
/* 50 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types) throws Exception
/*    */   {
/* 55 */     Element complexType = types.createElement("complexType");
/* 56 */     complexType.setAttribute("name", "MBeanAttributeInfo");
/* 57 */     Element allElement = types.createElement("all");
/* 58 */     complexType.appendChild(allElement);
/*    */     
/* 60 */     Element nameElement = types.createElement("element");
/* 61 */     nameElement.setAttribute("name", "name");
/* 62 */     nameElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 63 */     allElement.appendChild(nameElement);
/*    */     
/* 65 */     Element typeElement = types.createElement("element");
/* 66 */     typeElement.setAttribute("name", "type");
/* 67 */     typeElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 68 */     allElement.appendChild(typeElement);
/*    */     
/* 70 */     Element descrElement = types.createElement("element");
/* 71 */     descrElement.setAttribute("name", "description");
/* 72 */     descrElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 73 */     allElement.appendChild(descrElement);
/*    */     
/* 75 */     Element readableElement = types.createElement("element");
/* 76 */     readableElement.setAttribute("name", "isReadable");
/* 77 */     readableElement.setAttribute("type", XMLType.XSD_BOOLEAN.getLocalPart());
/* 78 */     allElement.appendChild(readableElement);
/*    */     
/* 80 */     Element writableElement = types.createElement("element");
/* 81 */     writableElement.setAttribute("name", "isWritable");
/* 82 */     writableElement.setAttribute("type", XMLType.XSD_BOOLEAN.getLocalPart());
/* 83 */     allElement.appendChild(writableElement);
/*    */     
/* 85 */     Element isElement = types.createElement("element");
/* 86 */     isElement.setAttribute("name", "isIs");
/* 87 */     isElement.setAttribute("type", XMLType.XSD_BOOLEAN.getLocalPart());
/* 88 */     allElement.appendChild(isElement);
/*    */     
/* 90 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanAttributeInfoSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */