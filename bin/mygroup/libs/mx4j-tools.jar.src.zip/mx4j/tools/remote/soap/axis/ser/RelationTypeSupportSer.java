/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import javax.management.relation.RelationTypeSupport;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.Constants;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelationTypeSupportSer
/*    */   extends AxisSerializer
/*    */ {
/*    */   static final String TYPE = "RelationTypeSupport";
/*    */   static final String NAME = "name";
/*    */   static final String ROLE_INFOS = "roleInfos";
/* 32 */   private static final QName NAME_QNAME = new QName("", "name");
/* 33 */   private static final QName ROLE_INFOS_QNAME = new QName("", "roleInfos");
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException
/*    */   {
/* 37 */     RelationTypeSupport relTypeSup = (RelationTypeSupport)value;
/* 38 */     context.startElement(name, attributes);
/* 39 */     context.serialize(NAME_QNAME, null, relTypeSup.getRelationTypeName());
/* 40 */     for (Iterator i = relTypeSup.getRoleInfos().iterator(); i.hasNext();)
/*    */     {
/* 42 */       context.serialize(Constants.QNAME_LITERAL_ITEM, null, i.next());
/*    */     }
/* 44 */     context.endElement();
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class javaType, Types types) throws Exception
/*    */   {
/* 49 */     Element complexType = types.createElement("complexType");
/* 50 */     complexType.setAttribute("name", "RelationTypeSupport");
/* 51 */     Element allElement = types.createElement("all");
/* 52 */     complexType.appendChild(allElement);
/*    */     
/* 54 */     Element nameElement = types.createElement("element");
/* 55 */     nameElement.setAttribute("name", "name");
/* 56 */     nameElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 57 */     allElement.appendChild(nameElement);
/*    */     
/* 59 */     types.writeSchemaElement(Constants.SOAP_VECTOR, complexType);
/* 60 */     Element sequence = types.createElement("sequence");
/* 61 */     complexType.appendChild(sequence);
/* 62 */     Element element = types.createElement("element");
/* 63 */     element.setAttribute("name", Constants.QNAME_LITERAL_ITEM.getLocalPart());
/* 64 */     element.setAttribute("minOccurs", "0");
/* 65 */     element.setAttribute("maxOccurs", "unbounded");
/* 66 */     element.setAttribute("type", "RoleInfo");
/* 67 */     sequence.appendChild(element);
/*    */     
/* 69 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/RelationTypeSupportSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */