/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.ser.BaseSerializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MBeanAttributeInfoSerFactory
/*    */   extends BaseSerializerFactory
/*    */ {
/*    */   public MBeanAttributeInfoSerFactory(Class javaType, QName xmlType)
/*    */   {
/* 22 */     super(MBeanAttributeInfoSer.class, xmlType, javaType);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MBeanAttributeInfoSerFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */