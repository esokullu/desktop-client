/*    */ package mx4j.tools.remote.soap.axis.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.Notification;
/*    */ import javax.management.monitor.MonitorNotification;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.encoding.XMLType;
/*    */ import org.apache.axis.wsdl.fromJava.Types;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MonitorNotificationSer
/*    */   extends NotificationSer
/*    */ {
/*    */   static final String TYPE = "MonitorNotification";
/*    */   static final String DERIVED_GAUGE = "derivedGauge";
/*    */   static final String OBSERVED_ATTRIBUTE = "observedAttribute";
/*    */   static final String OBSERVED_OBJECT = "observedObject";
/*    */   static final String TRIGGER = "trigger";
/* 31 */   private static final QName DERIVED_GAUGE_QNAME = new QName("", "derivedGauge");
/* 32 */   private static final QName OBSERVED_ATTRIBUTE_QNAME = new QName("", "observedAttribute");
/* 33 */   private static final QName OBSERVED_OBJECT_QNAME = new QName("", "observedObject");
/* 34 */   private static final QName TRIGGER_QNAME = new QName("", "trigger");
/*    */   
/*    */   protected void onSerialize(SerializationContext context, Notification notification) throws IOException
/*    */   {
/* 38 */     super.onSerialize(context, notification);
/* 39 */     MonitorNotification monNot = (MonitorNotification)notification;
/* 40 */     context.serialize(DERIVED_GAUGE_QNAME, null, monNot.getDerivedGauge());
/* 41 */     context.serialize(OBSERVED_ATTRIBUTE_QNAME, null, monNot.getObservedAttribute());
/* 42 */     context.serialize(OBSERVED_OBJECT_QNAME, null, monNot.getObservedObject());
/* 43 */     context.serialize(TRIGGER_QNAME, null, monNot.getTrigger());
/*    */   }
/*    */   
/*    */   public Element writeSchema(Class aClass, Types types) throws Exception
/*    */   {
/* 48 */     Element complexType = super.writeSchema(aClass, types);
/*    */     
/* 50 */     Element derivedGaugeElement = types.createElement("element");
/* 51 */     derivedGaugeElement.setAttribute("name", "derivedGauge");
/* 52 */     derivedGaugeElement.setAttribute("type", XMLType.XSD_ANYTYPE.getLocalPart());
/* 53 */     complexType.appendChild(derivedGaugeElement);
/*    */     
/* 55 */     Element observedAttElement = types.createElement("element");
/* 56 */     observedAttElement.setAttribute("name", "observedAttribute");
/* 57 */     observedAttElement.setAttribute("type", XMLType.XSD_STRING.getLocalPart());
/* 58 */     complexType.appendChild(observedAttElement);
/*    */     
/* 60 */     Element observedObjectElement = types.createElement("element");
/* 61 */     observedObjectElement.setAttribute("name", "observedObject");
/* 62 */     observedObjectElement.setAttribute("type", "ObjectName");
/* 63 */     complexType.appendChild(observedObjectElement);
/*    */     
/* 65 */     Element triggerElement = types.createElement("element");
/* 66 */     triggerElement.setAttribute("name", "trigger");
/* 67 */     triggerElement.setAttribute("type", XMLType.XSD_ANYTYPE.getLocalPart());
/* 68 */     complexType.appendChild(triggerElement);
/*    */     
/* 70 */     return complexType;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/soap/axis/ser/MonitorNotificationSer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */