/*     */ package mx4j.tools.remote;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.QueryExp;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.security.auth.Subject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JMXConnectionMBeanServerConnection
/*     */   implements MBeanServerConnection
/*     */ {
/*     */   private final JMXConnection connection;
/*     */   private final Subject delegate;
/*     */   
/*     */   protected JMXConnectionMBeanServerConnection(JMXConnection connection, Subject delegate)
/*     */   {
/*  49 */     this.connection = connection;
/*  50 */     this.delegate = delegate;
/*     */   }
/*     */   
/*     */   protected JMXConnection getConnection()
/*     */   {
/*  55 */     return this.connection;
/*     */   }
/*     */   
/*     */   protected Subject getDelegateSubject()
/*     */   {
/*  60 */     return this.delegate;
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo(ObjectName objectName) throws InstanceNotFoundException, IntrospectionException, ReflectionException, IOException
/*     */   {
/*  65 */     return getConnection().getMBeanInfo(objectName, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public boolean isInstanceOf(ObjectName objectName, String className) throws InstanceNotFoundException, IOException
/*     */   {
/*  70 */     return getConnection().isInstanceOf(objectName, className, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public String[] getDomains() throws IOException
/*     */   {
/*  75 */     return getConnection().getDomains(getDelegateSubject());
/*     */   }
/*     */   
/*     */   public String getDefaultDomain() throws IOException
/*     */   {
/*  80 */     return getConnection().getDefaultDomain(getDelegateSubject());
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException
/*     */   {
/*  85 */     return createMBean(className, objectName, null, null);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName, Object[] args, String[] parameters) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException
/*     */   {
/*  90 */     return getConnection().createMBean(className, objectName, args, parameters, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName, ObjectName loaderName) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException
/*     */   {
/*  95 */     return createMBean(className, objectName, loaderName, null, null);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName, ObjectName loaderName, Object[] args, String[] parameters) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException
/*     */   {
/* 100 */     return getConnection().createMBean(className, objectName, loaderName, args, parameters, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public void unregisterMBean(ObjectName objectName) throws InstanceNotFoundException, MBeanRegistrationException, IOException
/*     */   {
/* 105 */     getConnection().unregisterMBean(objectName, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public Object getAttribute(ObjectName objectName, String attribute) throws MBeanException, AttributeNotFoundException, InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 110 */     return getConnection().getAttribute(objectName, attribute, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public void setAttribute(ObjectName objectName, Attribute attribute) throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException, IOException
/*     */   {
/* 115 */     getConnection().setAttribute(objectName, attribute, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(ObjectName objectName, String[] attributes) throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 120 */     return getConnection().getAttributes(objectName, attributes, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(ObjectName objectName, AttributeList attributes) throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 125 */     return getConnection().setAttributes(objectName, attributes, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public Object invoke(ObjectName objectName, String methodName, Object[] args, String[] parameters) throws InstanceNotFoundException, MBeanException, ReflectionException, IOException
/*     */   {
/* 130 */     return getConnection().invoke(objectName, methodName, args, parameters, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public Integer getMBeanCount() throws IOException
/*     */   {
/* 135 */     return getConnection().getMBeanCount(getDelegateSubject());
/*     */   }
/*     */   
/*     */   public boolean isRegistered(ObjectName objectName) throws IOException
/*     */   {
/* 140 */     return getConnection().isRegistered(objectName, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public ObjectInstance getObjectInstance(ObjectName objectName) throws InstanceNotFoundException, IOException
/*     */   {
/* 145 */     return getConnection().getObjectInstance(objectName, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public Set queryMBeans(ObjectName patternName, QueryExp filter) throws IOException
/*     */   {
/* 150 */     return getConnection().queryMBeans(patternName, filter, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public Set queryNames(ObjectName patternName, QueryExp filter) throws IOException
/*     */   {
/* 155 */     return getConnection().queryNames(patternName, filter, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public void addNotificationListener(ObjectName observed, ObjectName listener, NotificationFilter filter, Object handback) throws InstanceNotFoundException, IOException
/*     */   {
/* 160 */     getConnection().addNotificationListener(observed, listener, filter, handback, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName observed, ObjectName listener) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 165 */     getConnection().removeNotificationListener(observed, listener, getDelegateSubject());
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName observed, ObjectName listener, NotificationFilter filter, Object handback) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 170 */     getConnection().removeNotificationListener(observed, listener, filter, handback, getDelegateSubject());
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/JMXConnectionMBeanServerConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */