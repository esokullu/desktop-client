/*     */ package mx4j.tools.remote;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.remote.JMXConnectorServer;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import mx4j.remote.MX4JRemoteUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJMXConnectorServer
/*     */   extends JMXConnectorServer
/*     */ {
/*     */   private JMXServiceURL url;
/*     */   private final Map environment;
/*     */   private volatile boolean active;
/*     */   private volatile boolean stopped;
/*     */   
/*     */   public AbstractJMXConnectorServer(JMXServiceURL url, Map environment, MBeanServer server)
/*     */   {
/*  39 */     super(server);
/*  40 */     this.url = url;
/*  41 */     this.environment = environment;
/*     */   }
/*     */   
/*     */   public synchronized JMXServiceURL getAddress()
/*     */   {
/*  46 */     return this.url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void setAddress(JMXServiceURL url)
/*     */   {
/*  54 */     this.url = url;
/*     */   }
/*     */   
/*     */   public synchronized Map getAttributes()
/*     */   {
/*  59 */     Map env = MX4JRemoteUtils.removeNonSerializableEntries(getEnvironment());
/*  60 */     return Collections.unmodifiableMap(env);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized Map getEnvironment()
/*     */   {
/*  68 */     return this.environment;
/*     */   }
/*     */   
/*     */   public boolean isActive()
/*     */   {
/*  73 */     return this.active;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isStopped()
/*     */   {
/*  81 */     return this.stopped;
/*     */   }
/*     */   
/*     */   public synchronized void start() throws IOException, IllegalStateException
/*     */   {
/*  86 */     Logger logger = getLogger();
/*     */     
/*  88 */     if (isActive())
/*     */     {
/*  90 */       if (logger.isEnabledFor(0)) logger.trace("This JMXConnectorServer has already been started");
/*  91 */       return;
/*     */     }
/*  93 */     if (isStopped())
/*     */     {
/*  95 */       if (logger.isEnabledFor(0)) logger.trace("This JMXConnectorServer has already been stopped");
/*  96 */       throw new IOException("This RMIConnectorServer has already been stopped");
/*     */     }
/*     */     
/*  99 */     doStart();
/*     */     
/* 101 */     this.active = true;
/*     */     
/* 103 */     if (logger.isEnabledFor(20)) { logger.info("JMXConnectorServer started at: " + getAddress());
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void doStart()
/*     */     throws IOException, IllegalStateException;
/*     */   
/*     */   public synchronized void stop()
/*     */     throws IOException
/*     */   {
/* 113 */     if ((!isActive()) || (isStopped())) { return;
/*     */     }
/* 115 */     this.stopped = true;
/* 116 */     this.active = false;
/*     */     
/* 118 */     doStop();
/*     */     
/* 120 */     Logger logger = getLogger();
/* 121 */     if (logger.isEnabledFor(20)) { logger.info("JMXConnectorServer stopped at: " + getAddress());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract void doStop()
/*     */     throws IOException;
/*     */   
/*     */   protected Logger getLogger()
/*     */   {
/* 131 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */   
/*     */   public void connectionOpened(String connectionId, String message, Object userData)
/*     */   {
/* 136 */     super.connectionOpened(connectionId, message, userData);
/*     */   }
/*     */   
/*     */   public void connectionClosed(String connectionId, String message, Object userData)
/*     */   {
/* 141 */     super.connectionClosed(connectionId, message, userData);
/*     */   }
/*     */   
/*     */   public void connectionFailed(String connectionId, String message, Object userData)
/*     */   {
/* 146 */     super.connectionFailed(connectionId, message, userData);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/AbstractJMXConnectorServer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */