/*     */ package mx4j.tools.remote;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.management.remote.JMXAuthenticator;
/*     */ import javax.management.remote.JMXPrincipal;
/*     */ import javax.security.auth.Subject;
/*     */ import mx4j.util.Base64Codec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PasswordAuthenticator
/*     */   implements JMXAuthenticator
/*     */ {
/*     */   private static final String LEFT_DELIMITER = "OBF(";
/*     */   private static final String RIGHT_DELIMITER = "):";
/*     */   private Map passwords;
/*     */   
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*  90 */     if (args.length == 1)
/*     */     {
/*  92 */       if (!"-help".equals(args[0]))
/*     */       {
/*  94 */         printPassword("MD5", args[0]);
/*     */       }
/*     */       
/*     */     }
/*  98 */     else if (args.length == 3)
/*     */     {
/* 100 */       if ("-alg".equals(args[0]))
/*     */       {
/* 102 */         printPassword(args[1], args[2]);
/* 103 */         return;
/*     */       }
/*     */     }
/* 106 */     printUsage();
/*     */   }
/*     */   
/*     */   private static void printPassword(String algorithm, String input)
/*     */   {
/* 111 */     String password = obfuscatePassword(input, algorithm);
/* 112 */     System.out.println(password);
/*     */   }
/*     */   
/*     */   private static void printUsage()
/*     */   {
/* 117 */     System.out.println();
/* 118 */     System.out.println("Usage: java -cp <lib>/mx4j-tools.jar mx4j.tools.remote.PasswordAuthenticator <options> <password>");
/* 119 */     System.out.println("Where <options> is one of the following:");
/* 120 */     System.out.println("   -help                     Prints this message");
/* 121 */     System.out.println("   -alg <digest algorithm>   Specifies the digest algorithm (default is MD5)");
/* 122 */     System.out.println();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String obfuscatePassword(String password)
/*     */   {
/* 132 */     return obfuscatePassword(password, "MD5");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String obfuscatePassword(String password, String algorithm)
/*     */   {
/*     */     try
/*     */     {
/* 147 */       MessageDigest digest = MessageDigest.getInstance(algorithm);
/* 148 */       byte[] digestedBytes = digest.digest(password.getBytes());
/* 149 */       byte[] obfuscatedBytes = Base64Codec.encodeBase64(digestedBytes);
/* 150 */       return "OBF(" + algorithm + "):" + new String(obfuscatedBytes);
/*     */     }
/*     */     catch (NoSuchAlgorithmException x)
/*     */     {
/* 154 */       throw new SecurityException("Could not find digest algorithm " + algorithm);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PasswordAuthenticator(File passwordFile)
/*     */     throws IOException
/*     */   {
/* 168 */     this(new FileInputStream(passwordFile));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PasswordAuthenticator(InputStream is)
/*     */     throws IOException
/*     */   {
/* 179 */     this.passwords = readPasswords(is);
/*     */   }
/*     */   
/*     */   private Map readPasswords(InputStream is) throws IOException
/*     */   {
/* 184 */     Properties properties = new Properties();
/*     */     try
/*     */     {
/* 187 */       properties.load(is);
/*     */     }
/*     */     finally
/*     */     {
/* 191 */       is.close();
/*     */     }
/* 193 */     return new HashMap(properties);
/*     */   }
/*     */   
/*     */   public Subject authenticate(Object credentials) throws SecurityException
/*     */   {
/* 198 */     if (!(credentials instanceof String[])) throw new SecurityException("Bad credentials");
/* 199 */     String[] creds = (String[])credentials;
/* 200 */     if (creds.length != 2) { throw new SecurityException("Bad credentials");
/*     */     }
/* 202 */     String user = creds[0];
/* 203 */     String password = creds[1];
/*     */     
/* 205 */     if (password == null) { throw new SecurityException("Bad password");
/*     */     }
/* 207 */     if (!this.passwords.containsKey(user)) { throw new SecurityException("Unknown user " + user);
/*     */     }
/* 209 */     String storedPassword = (String)this.passwords.get(user);
/* 210 */     if (!isPasswordCorrect(password, storedPassword)) { throw new SecurityException("Bad password");
/*     */     }
/* 212 */     Set principals = new HashSet();
/* 213 */     principals.add(new JMXPrincipal(user));
/* 214 */     return new Subject(true, principals, Collections.EMPTY_SET, Collections.EMPTY_SET);
/*     */   }
/*     */   
/*     */   private boolean isPasswordCorrect(String password, String storedPassword)
/*     */   {
/* 219 */     if (password.startsWith("OBF("))
/*     */     {
/* 221 */       if (storedPassword.startsWith("OBF("))
/*     */       {
/* 223 */         return password.equals(storedPassword);
/*     */       }
/*     */       
/*     */ 
/* 227 */       String algorithm = getAlgorithm(password);
/* 228 */       String obfuscated = obfuscatePassword(storedPassword, algorithm);
/* 229 */       return password.equals(obfuscated);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 234 */     if (storedPassword.startsWith("OBF("))
/*     */     {
/*     */ 
/* 237 */       String algorithm = getAlgorithm(storedPassword);
/* 238 */       String obfuscated = obfuscatePassword(password, algorithm);
/* 239 */       return obfuscated.equals(storedPassword);
/*     */     }
/*     */     
/*     */ 
/* 243 */     return password.equals(storedPassword);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String getAlgorithm(String obfuscatedPassword)
/*     */   {
/*     */     try
/*     */     {
/* 252 */       return obfuscatedPassword.substring("OBF(".length(), obfuscatedPassword.indexOf("):"));
/*     */     }
/*     */     catch (IndexOutOfBoundsException x)
/*     */     {
/* 256 */       throw new SecurityException("Bad password");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/remote/PasswordAuthenticator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */