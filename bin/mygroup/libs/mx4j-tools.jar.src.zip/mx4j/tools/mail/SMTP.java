/*     */ package mx4j.tools.mail;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Properties;
/*     */ import javax.mail.Address;
/*     */ import javax.mail.Message.RecipientType;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Transport;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanRegistration;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SMTP
/*     */   implements SMTPMBean, NotificationListener, MBeanRegistration
/*     */ {
/*     */   private MBeanServer server;
/*     */   private ObjectName targetMBeanName;
/*     */   private ObjectName objectName;
/*     */   private String notificationName;
/*     */   private Properties sessionProperties;
/*     */   private Session session;
/*     */   private String content;
/*     */   private String mimeType;
/*     */   private String subject;
/*     */   private String fromAddress;
/*     */   private String fromName;
/*     */   private String toAddresses;
/*     */   private String ccAddresses;
/*     */   private String bccAddresses;
/*     */   private String serverHost;
/*     */   private String serverPassword;
/*     */   private String serverUserName;
/*     */   private int serverPort;
/*     */   private int timeout;
/*     */   private boolean doLogin;
/*     */   private Object sessionLock;
/*     */   
/*     */   public SMTP()
/*     */   {
/*  56 */     this.server = null;
/*     */     
/*     */ 
/*  59 */     this.sessionProperties = new Properties();
/*     */     
/*  61 */     this.content = "Empty default mail";
/*  62 */     this.mimeType = "text/plain";
/*  63 */     this.subject = "Empty Subject";
/*  64 */     this.fromAddress = "noreply";
/*  65 */     this.fromName = "MX4J default";
/*  66 */     this.toAddresses = null;
/*  67 */     this.ccAddresses = null;
/*  68 */     this.bccAddresses = null;
/*     */     
/*     */ 
/*     */ 
/*  72 */     this.serverPort = 25;
/*  73 */     this.timeout = 10000;
/*     */     
/*  75 */     this.sessionLock = new Object();
/*     */   }
/*     */   
/*     */   public void handleNotification(Notification notification, Object handback) {
/*  79 */     if ((this.notificationName != null) && (!notification.getType().equals(this.notificationName))) { return;
/*     */     }
/*  81 */     Logger log = getLogger();
/*  82 */     log.debug("Notification " + notification + " hit, sending message");
/*  83 */     sendMail();
/*     */   }
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/*  88 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */   public void sendMail()
/*     */   {
/*  94 */     new Thread(new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/*  98 */         if (SMTP.this.validState())
/*     */         {
/* 100 */           Logger logger = SMTP.this.getLogger();
/*     */           
/* 102 */           synchronized (SMTP.this.sessionLock)
/*     */           {
/* 104 */             SMTP.this.createSession();
/*     */             try
/*     */             {
/* 107 */               MimeMessage message = new MimeMessage(SMTP.this.session);
/* 108 */               message.setContent(SMTP.this.doKeywordExpansion(SMTP.this.content), SMTP.this.mimeType);
/* 109 */               message.setSubject(SMTP.this.doKeywordExpansion(SMTP.this.subject));
/*     */               
/* 111 */               Address from = new InternetAddress(SMTP.this.fromAddress, SMTP.this.fromName);
/* 112 */               message.setFrom(from);
/* 113 */               message.setReplyTo(new Address[] { from });
/*     */               
/* 115 */               if (SMTP.this.toAddresses != null)
/*     */               {
/* 117 */                 message.addRecipients(Message.RecipientType.TO, InternetAddress.parse(SMTP.this.toAddresses));
/*     */               }
/*     */               
/* 120 */               if (SMTP.this.ccAddresses != null)
/*     */               {
/* 122 */                 message.addRecipients(Message.RecipientType.CC, InternetAddress.parse(SMTP.this.ccAddresses));
/*     */               }
/*     */               
/* 125 */               if (SMTP.this.bccAddresses != null)
/*     */               {
/* 127 */                 message.addRecipients(Message.RecipientType.BCC, InternetAddress.parse(SMTP.this.bccAddresses));
/*     */               }
/* 129 */               Transport transport = SMTP.this.session.getTransport("smtp");
/* 130 */               if (SMTP.this.doLogin)
/*     */               {
/* 132 */                 transport.connect(SMTP.this.serverHost, SMTP.this.serverPort, SMTP.this.serverUserName, SMTP.this.serverPassword);
/*     */               }
/*     */               else
/*     */               {
/* 136 */                 transport.connect();
/*     */               }
/* 138 */               message.saveChanges();
/*     */               
/* 140 */               if (logger.isEnabledFor(10)) logger.debug("Sending message");
/* 141 */               transport.sendMessage(message, message.getAllRecipients());
/* 142 */               transport.close();
/* 143 */               if (logger.isEnabledFor(10)) logger.debug("Message sent");
/*     */             }
/*     */             catch (Exception e)
/*     */             {
/* 147 */               logger.error("Exception during message sending ", e);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }).start();
/*     */   }
/*     */   
/*     */   private String doKeywordExpansion(String source)
/*     */   {
/* 157 */     StringBuffer sourceCopy = new StringBuffer();
/* 158 */     int index = -1;
/* 159 */     int lastIndex = 0;
/* 160 */     int length = source.length();
/* 161 */     while ((index = source.indexOf("$", lastIndex)) > 0)
/*     */     {
/* 163 */       sourceCopy.append(source.substring(lastIndex, index));
/* 164 */       if (index >= length - 1) {
/*     */         break;
/*     */       }
/*     */       
/* 168 */       index++;lastIndex = index;
/* 169 */       if (source.charAt(index) == '$')
/*     */       {
/* 171 */         sourceCopy.append('$');
/* 172 */         lastIndex++;
/*     */       }
/* 174 */       if (source.startsWith("date$", index))
/*     */       {
/* 176 */         sourceCopy.append(DateFormat.getDateInstance().format(new Date()));
/* 177 */         lastIndex += 5;
/*     */       }
/* 179 */       if (source.startsWith("time$", index))
/*     */       {
/* 181 */         sourceCopy.append(DateFormat.getTimeInstance().format(new Date()));
/* 182 */         lastIndex += 5;
/*     */       }
/* 184 */       if (source.startsWith("datetime$", index))
/*     */       {
/* 186 */         sourceCopy.append(DateFormat.getDateTimeInstance().format(new Date()));
/* 187 */         lastIndex += 9;
/*     */       }
/* 189 */       if (source.startsWith("observed$", index))
/*     */       {
/* 191 */         if (this.targetMBeanName != null)
/*     */         {
/* 193 */           sourceCopy.append(this.targetMBeanName);
/* 194 */           lastIndex += 9;
/*     */         }
/*     */       }
/* 197 */       if (source.startsWith("objectname$", index))
/*     */       {
/* 199 */         if (this.objectName != null)
/*     */         {
/* 201 */           sourceCopy.append(this.objectName);
/* 202 */           lastIndex += 11;
/*     */         }
/*     */       }
/* 205 */       if ((source.startsWith("notification$", index)) && 
/*     */       
/* 207 */         (this.notificationName != null))
/*     */       {
/* 209 */         sourceCopy.append(this.notificationName);
/* 210 */         lastIndex += 13;
/*     */       }
/*     */     }
/*     */     
/* 214 */     sourceCopy.append(source.substring(lastIndex, length));
/* 215 */     return sourceCopy.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean validState()
/*     */   {
/* 223 */     return (this.serverHost != null) && (this.toAddresses != null) && ((!this.doLogin) || (this.serverUserName != null) || (this.serverPassword != null));
/*     */   }
/*     */   
/*     */   private void createSession()
/*     */   {
/* 228 */     synchronized (this.sessionLock)
/*     */     {
/* 230 */       if (this.session == null)
/*     */       {
/* 232 */         this.sessionProperties.setProperty("mail.smtp.host", this.serverHost);
/* 233 */         this.sessionProperties.setProperty("mail.smtp.port", Integer.toString(this.serverPort));
/* 234 */         this.sessionProperties.setProperty("mail.smtp.timeout", Integer.toString(this.timeout));
/* 235 */         this.sessionProperties.setProperty("mail.smtp.connectiontimeout", Integer.toString(this.timeout));
/* 236 */         this.sessionProperties.setProperty("mail.smtp.sendpartial", "true");
/* 237 */         this.session = Session.getInstance(this.sessionProperties, null);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String getBCC()
/*     */   {
/* 244 */     return this.bccAddresses;
/*     */   }
/*     */   
/*     */   public void setBCC(String bccAddresses)
/*     */   {
/* 249 */     this.bccAddresses = bccAddresses;
/*     */   }
/*     */   
/*     */   public void setCC(String ccAddresses)
/*     */   {
/* 254 */     this.ccAddresses = ccAddresses;
/*     */   }
/*     */   
/*     */   public String getCC()
/*     */   {
/* 259 */     return this.ccAddresses;
/*     */   }
/*     */   
/*     */   public String getFromAddress()
/*     */   {
/* 264 */     return this.fromAddress;
/*     */   }
/*     */   
/*     */   public void setFromAddress(String fromAddress)
/*     */   {
/* 269 */     this.fromAddress = fromAddress;
/*     */   }
/*     */   
/*     */   public void setServerHost(String host)
/*     */   {
/* 274 */     synchronized (this.sessionLock)
/*     */     {
/* 276 */       this.serverHost = host;
/* 277 */       this.session = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public String getServerHost()
/*     */   {
/* 283 */     return this.serverHost;
/*     */   }
/*     */   
/*     */   public void setServerPort(int port)
/*     */   {
/* 288 */     synchronized (this.sessionLock)
/*     */     {
/* 290 */       this.serverPort = port;
/* 291 */       this.session = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public int getServerPort()
/*     */   {
/* 297 */     return this.serverPort;
/*     */   }
/*     */   
/*     */   public void setServerUsername(String username)
/*     */   {
/* 302 */     this.serverUserName = username;
/*     */   }
/*     */   
/*     */   public String getServerUsername()
/*     */   {
/* 307 */     return this.serverUserName;
/*     */   }
/*     */   
/*     */   public void setServerPassword(String password)
/*     */   {
/* 312 */     this.serverPassword = password;
/*     */   }
/*     */   
/*     */   public void setLoginToServer(boolean login)
/*     */   {
/* 317 */     this.doLogin = login;
/*     */   }
/*     */   
/*     */   public boolean isLoginToServer()
/*     */   {
/* 322 */     return this.doLogin;
/*     */   }
/*     */   
/*     */   public String getFromName()
/*     */   {
/* 327 */     return this.fromName;
/*     */   }
/*     */   
/*     */   public void setFromName(String fromName)
/*     */   {
/* 332 */     this.fromName = fromName;
/*     */   }
/*     */   
/*     */   public String getMimeType()
/*     */   {
/* 337 */     return this.mimeType;
/*     */   }
/*     */   
/*     */   public void setMimeType(String mimeType)
/*     */   {
/* 342 */     this.mimeType = mimeType;
/*     */   }
/*     */   
/*     */   public String getNotificationName()
/*     */   {
/* 347 */     return this.notificationName;
/*     */   }
/*     */   
/*     */   public void setNotificationName(String notificationName)
/*     */   {
/* 352 */     this.notificationName = notificationName;
/*     */   }
/*     */   
/*     */   public String getSubject()
/*     */   {
/* 357 */     return this.subject;
/*     */   }
/*     */   
/*     */   public void setSubject(String subject)
/*     */   {
/* 362 */     this.subject = subject;
/*     */   }
/*     */   
/*     */   public String getContent()
/*     */   {
/* 367 */     return this.content;
/*     */   }
/*     */   
/*     */   public void setContent(String content)
/*     */   {
/* 372 */     this.content = content;
/*     */   }
/*     */   
/*     */   public void setTimeout(int timeout)
/*     */   {
/* 377 */     synchronized (this.sessionLock)
/*     */     {
/* 379 */       this.timeout = timeout;
/* 380 */       this.session = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public int getTimeout()
/*     */   {
/* 386 */     return this.timeout;
/*     */   }
/*     */   
/*     */   public void setObservedObject(ObjectName targetMBeanName)
/*     */   {
/* 391 */     this.targetMBeanName = targetMBeanName;
/* 392 */     registerListener();
/*     */   }
/*     */   
/*     */ 
/*     */   public ObjectName getObservedObject()
/*     */   {
/* 398 */     return this.targetMBeanName;
/*     */   }
/*     */   
/*     */   public String getTo()
/*     */   {
/* 403 */     return this.toAddresses;
/*     */   }
/*     */   
/*     */   public void setTo(String toAddresses)
/*     */   {
/* 408 */     this.toAddresses = toAddresses;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName preRegister(MBeanServer server, ObjectName name)
/*     */     throws Exception
/*     */   {
/* 417 */     this.server = server;
/* 418 */     this.objectName = name;
/* 419 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void postRegister(Boolean registrationDone) {}
/*     */   
/*     */ 
/*     */   public void preDeregister()
/*     */     throws Exception
/*     */   {
/* 430 */     unregisterListener();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void postDeregister() {}
/*     */   
/*     */ 
/*     */   protected void registerListener()
/*     */   {
/*     */     try
/*     */     {
/* 442 */       if ((this.targetMBeanName != null) && (this.server.isInstanceOf(this.targetMBeanName, "javax.management.NotificationBroadcaster")))
/*     */       {
/* 444 */         this.server.addNotificationListener(this.targetMBeanName, this, new MessageFilter(null), null);
/*     */       }
/*     */     }
/*     */     catch (InstanceNotFoundException e)
/*     */     {
/* 449 */       Logger log = getLogger();
/* 450 */       log.error("Exception during notification registration", e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void unregisterListener()
/*     */   {
/*     */     try
/*     */     {
/* 458 */       if ((this.targetMBeanName != null) && (this.server.isInstanceOf(this.targetMBeanName, "javax.management.NotificationBroadcaster")))
/*     */       {
/* 460 */         this.server.removeNotificationListener(this.targetMBeanName, this);
/*     */       }
/*     */     }
/*     */     catch (InstanceNotFoundException e)
/*     */     {
/* 465 */       Logger log = getLogger();
/* 466 */       log.error("Exception during notification unregistration", e);
/*     */     }
/*     */     catch (ListenerNotFoundException e) {}
/*     */   }
/*     */   
/*     */   private class MessageFilter implements NotificationFilter {
/*     */     MessageFilter(SMTP.1 x1) {
/* 473 */       this();
/*     */     }
/*     */     
/*     */     public boolean isNotificationEnabled(Notification notification) {
/* 477 */       return (SMTP.this.notificationName == null) || ((notification.getType() != null) && (notification.getType().equals(SMTP.this.notificationName)));
/*     */     }
/*     */     
/*     */     private MessageFilter() {}
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/mail/SMTP.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */