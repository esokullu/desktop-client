package mx4j.tools.mail;

import javax.management.ObjectName;

public abstract interface SMTPMBean
{
  public abstract ObjectName getObservedObject();
  
  public abstract void setObservedObject(ObjectName paramObjectName);
  
  public abstract String getNotificationName();
  
  public abstract void setNotificationName(String paramString);
  
  public abstract String getServerHost();
  
  public abstract void setServerHost(String paramString);
  
  public abstract void setServerPort(int paramInt);
  
  public abstract int getServerPort();
  
  public abstract void setServerUsername(String paramString);
  
  public abstract String getServerUsername();
  
  public abstract void setServerPassword(String paramString);
  
  public abstract void setLoginToServer(boolean paramBoolean);
  
  public abstract boolean isLoginToServer();
  
  public abstract void setTimeout(int paramInt);
  
  public abstract int getTimeout();
  
  public abstract String getFromAddress();
  
  public abstract void setFromAddress(String paramString);
  
  public abstract String getFromName();
  
  public abstract void setFromName(String paramString);
  
  public abstract String getMimeType();
  
  public abstract void setMimeType(String paramString);
  
  public abstract String getTo();
  
  public abstract void setTo(String paramString);
  
  public abstract String getBCC();
  
  public abstract void setBCC(String paramString);
  
  public abstract String getCC();
  
  public abstract void setCC(String paramString);
  
  public abstract String getSubject();
  
  public abstract void setSubject(String paramString);
  
  public abstract String getContent();
  
  public abstract void setContent(String paramString);
  
  public abstract void sendMail();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/mail/SMTPMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */