package mx4j.tools.naming;

import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;

public abstract interface NamingServiceMBean
{
  public abstract void setPort(int paramInt);
  
  public abstract int getPort();
  
  public abstract boolean isRunning();
  
  public abstract void start()
    throws RemoteException;
  
  public abstract void stop()
    throws NoSuchObjectException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/naming/NamingServiceMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */