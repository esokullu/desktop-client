/*     */ package mx4j.tools.naming;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CosNamingService
/*     */   implements CosNamingServiceMBean
/*     */ {
/*     */   private int m_port;
/*     */   private volatile boolean m_running;
/*     */   private Process m_process;
/*     */   private InputStreamConsumer m_output;
/*     */   private InputStreamConsumer m_error;
/*     */   private volatile Exception exception;
/*     */   
/*     */   public CosNamingService()
/*     */   {
/*  43 */     this(900);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CosNamingService(int port)
/*     */   {
/*  51 */     this.m_port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/*  61 */     this.m_port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/*  71 */     return this.m_port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRunning()
/*     */   {
/*  81 */     return this.m_running;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void start()
/*     */     throws Exception
/*     */   {
/*  92 */     if (isRunning()) { return;
/*     */     }
/*  94 */     Logger logger = getLogger();
/*     */     
/*     */ 
/*  97 */     Thread thread = new Thread(new Runnable() {
/*     */       private final Logger val$logger;
/*     */       
/*     */       public void run() {
/* 101 */         String home = CosNamingService.this.getJavaHomeBin();
/*     */         
/* 103 */         String command = (home == null ? "" : home) + "tnameserv -ORBInitialPort " + CosNamingService.this.getPort();
/*     */         try
/*     */         {
/* 106 */           CosNamingService.this.m_process = Runtime.getRuntime().exec(command);
/* 107 */           if (this.val$logger.isEnabledFor(10)) this.val$logger.debug("Process created: " + CosNamingService.this.m_process);
/*     */         }
/*     */         catch (IOException x)
/*     */         {
/* 111 */           if (this.val$logger.isEnabledFor(10)) this.val$logger.debug("Could not create process", x);
/* 112 */           CosNamingService.this.exception = x;
/* 113 */           return;
/*     */         }
/*     */         
/* 116 */         CosNamingService.this.m_output = new CosNamingService.InputStreamConsumer(CosNamingService.this, CosNamingService.this.m_process.getInputStream());
/* 117 */         CosNamingService.this.m_error = new CosNamingService.InputStreamConsumer(CosNamingService.this, CosNamingService.this.m_process.getErrorStream());
/* 118 */         CosNamingService.this.m_output.start();
/* 119 */         CosNamingService.this.m_error.start();
/*     */         
/* 121 */         CosNamingService.this.m_running = true;
/*     */         
/*     */ 
/*     */         try
/*     */         {
/* 126 */           int result = CosNamingService.this.m_process.waitFor();
/* 127 */           if (this.val$logger.isEnabledFor(10)) { this.val$logger.debug("Exit value is: " + result);
/*     */           }
/*     */           
/*     */ 
/* 131 */           if (CosNamingService.this.isRunning())
/*     */           {
/* 133 */             CosNamingService.this.stop();
/* 134 */             if (this.val$logger.isEnabledFor(20)) this.val$logger.info("Unexpected exception (maybe the port " + CosNamingService.this.getPort() + " is already in use)");
/*     */           }
/*     */         }
/*     */         catch (InterruptedException x)
/*     */         {
/* 139 */           if (this.val$logger.isEnabledFor(10)) this.val$logger.debug("Process has been interrupted", x);
/* 140 */           CosNamingService.this.stop(); } } }, "CosNamingService Thread");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 145 */     thread.setDaemon(true);
/* 146 */     thread.start();
/*     */     
/* 148 */     while ((!this.m_running) && (this.exception == null)) { wait(10L);
/*     */     }
/* 150 */     if (this.exception != null) { throw this.exception;
/*     */     }
/* 152 */     if (logger.isEnabledFor(0)) logger.trace("CosNamingService started");
/*     */   }
/*     */   
/*     */   private String getJavaHomeBin()
/*     */   {
/* 157 */     String home = (String)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public Object run()
/*     */       {
/* 161 */         return System.getProperty("java.home");
/*     */       }
/*     */     });
/* 164 */     if ((home != null) && (!home.endsWith(File.separator))) home = home + File.separator;
/* 165 */     if (home != null) home = home + "bin" + File.separator;
/* 166 */     return home;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void stop()
/*     */   {
/* 176 */     if (!isRunning()) { return;
/*     */     }
/* 178 */     this.m_running = false;
/* 179 */     this.m_output.interrupt();
/* 180 */     this.m_error.interrupt();
/* 181 */     this.m_process.destroy();
/*     */   }
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/* 186 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */   
/*     */   private class InputStreamConsumer extends Thread
/*     */   {
/*     */     private final InputStream m_stream;
/* 192 */     private final byte[] m_buffer = new byte[''];
/*     */     
/*     */     public InputStreamConsumer(InputStream stream)
/*     */     {
/* 196 */       super();
/* 197 */       this.m_stream = new BufferedInputStream(stream);
/* 198 */       setDaemon(true);
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 203 */       Logger logger = CosNamingService.this.getLogger();
/* 204 */       for (;;) { if (!isInterrupted())
/*     */         {
/*     */           try
/*     */           {
/* 208 */             int read = -1;
/* 209 */             while ((read = this.m_stream.read(this.m_buffer)) >= 0)
/*     */             {
/* 211 */               if (logger.isEnabledFor(20)) logger.info(new String(this.m_buffer, 0, read));
/*     */             }
/*     */           }
/*     */           catch (InterruptedIOException x)
/*     */           {
/* 216 */             Thread.currentThread().interrupt();
/*     */ 
/*     */           }
/*     */           catch (IOException x)
/*     */           {
/* 221 */             if (logger.isEnabledFor(20)) logger.info("Error while consuming process stream", x);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/naming/CosNamingService.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */