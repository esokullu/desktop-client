/*     */ package mx4j.tools.naming;
/*     */ 
/*     */ import java.rmi.NoSuchObjectException;
/*     */ import java.rmi.Remote;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.registry.LocateRegistry;
/*     */ import java.rmi.server.UnicastRemoteObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamingService
/*     */   implements NamingServiceMBean
/*     */ {
/*     */   private int m_port;
/*     */   private Remote m_registry;
/*     */   private boolean m_running;
/*     */   
/*     */   public NamingService()
/*     */   {
/*  36 */     this(1099);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamingService(int port)
/*     */   {
/*  44 */     this.m_port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/*  54 */     this.m_port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/*  64 */     return this.m_port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRunning()
/*     */   {
/*  74 */     return this.m_running;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */     throws RemoteException
/*     */   {
/*  85 */     if (!isRunning())
/*     */     {
/*  87 */       this.m_registry = LocateRegistry.createRegistry(getPort());
/*  88 */       this.m_running = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */     throws NoSuchObjectException
/*     */   {
/*  99 */     if (isRunning())
/*     */     {
/* 101 */       this.m_running = (!UnicastRemoteObject.unexportObject(this.m_registry, true));
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/naming/NamingService.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */