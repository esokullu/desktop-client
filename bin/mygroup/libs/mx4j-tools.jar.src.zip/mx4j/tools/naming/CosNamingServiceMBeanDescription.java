/*    */ package mx4j.tools.naming;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Method;
/*    */ import mx4j.MBeanDescriptionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CosNamingServiceMBeanDescription
/*    */   extends MBeanDescriptionAdapter
/*    */ {
/*    */   public String getMBeanDescription()
/*    */   {
/* 25 */     return "MBean that wraps tnameserv";
/*    */   }
/*    */   
/*    */   public String getConstructorDescription(Constructor ctor)
/*    */   {
/* 30 */     if (ctor.toString().equals("public mx4j.tools.naming.CosNamingService()"))
/*    */     {
/* 32 */       return "Creates a new instance of CosNamingService with the default port (900)";
/*    */     }
/* 34 */     if (ctor.toString().equals("public mx4j.tools.naming.CosNamingService(int)"))
/*    */     {
/* 36 */       return "Creates a new instance of CosNamingService with the specified port";
/*    */     }
/* 38 */     return super.getConstructorDescription(ctor);
/*    */   }
/*    */   
/*    */   public String getConstructorParameterName(Constructor ctor, int index)
/*    */   {
/* 43 */     if (ctor.toString().equals("public mx4j.tools.naming.CosNamingService(int)"))
/*    */     {
/* 45 */       switch (index)
/*    */       {
/*    */       case 0: 
/* 48 */         return "port";
/*    */       }
/*    */     }
/* 51 */     return super.getConstructorParameterName(ctor, index);
/*    */   }
/*    */   
/*    */   public String getConstructorParameterDescription(Constructor ctor, int index)
/*    */   {
/* 56 */     if (ctor.toString().equals("public mx4j.tools.naming.CosNamingService(int)"))
/*    */     {
/* 58 */       switch (index)
/*    */       {
/*    */       case 0: 
/* 61 */         return "The port on which tnameserv will listen for incoming connections";
/*    */       }
/*    */     }
/* 64 */     return super.getConstructorParameterDescription(ctor, index);
/*    */   }
/*    */   
/*    */   public String getAttributeDescription(String attribute)
/*    */   {
/* 69 */     if (attribute.equals("Port"))
/*    */     {
/* 71 */       return "The port on which tnameserv listens for incoming connections";
/*    */     }
/* 73 */     if (attribute.equals("Running"))
/*    */     {
/* 75 */       return "The running status of this MBean";
/*    */     }
/* 77 */     if (attribute.equals("Delay"))
/*    */     {
/* 79 */       return "The delay (ms) for the start() and stop() methods";
/*    */     }
/* 81 */     return super.getAttributeDescription(attribute);
/*    */   }
/*    */   
/*    */   public String getOperationDescription(Method operation)
/*    */   {
/* 86 */     String name = operation.getName();
/* 87 */     if (name.equals("start"))
/*    */     {
/* 89 */       return "Starts tnameserv";
/*    */     }
/* 91 */     if (name.equals("stop"))
/*    */     {
/* 93 */       return "Stops tnameserv";
/*    */     }
/* 95 */     return super.getOperationDescription(operation);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/naming/CosNamingServiceMBeanDescription.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */