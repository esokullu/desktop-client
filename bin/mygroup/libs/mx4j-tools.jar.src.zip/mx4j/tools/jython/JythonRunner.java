/*     */ package mx4j.tools.jython;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanRegistration;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import org.python.core.Py;
/*     */ import org.python.core.PyCode;
/*     */ import org.python.core.PySystemState;
/*     */ import org.python.util.PythonInterpreter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JythonRunner
/*     */   implements JythonRunnerMBean, NotificationListener, MBeanRegistration
/*     */ {
/*     */   private MBeanServer server;
/*     */   private ObjectName targetMBeanName;
/*     */   private ObjectName objectName;
/*     */   private String notificationName;
/*     */   private boolean useText;
/*     */   private boolean useCache;
/*     */   private String scriptText;
/*     */   private URL scriptFile;
/*     */   private PyCode cache;
/*     */   private static PythonInterpreter interpreter;
/*     */   
/*     */   public JythonRunner()
/*     */   {
/*  53 */     this.server = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  59 */     this.useText = true;
/*     */     
/*  61 */     this.useCache = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */     this.cache = null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void handleNotification(Notification notification, Object handback)
/*     */   {
/*  73 */     if ((this.notificationName != null) && (!notification.getType().equals(this.notificationName))) { return;
/*     */     }
/*  75 */     Logger logger = getLogger();
/*  76 */     if (logger.isEnabledFor(10)) logger.debug("Notification " + notification + " hit, sending message");
/*  77 */     runScript();
/*     */   }
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/*  82 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void runScript()
/*     */   {
/*  91 */     PythonInterpreter interp = getPythonInterpreter();
/*  92 */     interp.set("server", this.server);
/*  93 */     String script = null;
/*  94 */     if (this.useText)
/*     */     {
/*  96 */       script = this.scriptText;
/*     */     }
/*     */     else
/*     */     {
/*     */       try
/*     */       {
/* 102 */         script = loadStream(this.scriptFile.openStream());
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 106 */         Logger log = getLogger();
/* 107 */         log.error("Exception during url opening", e);
/*     */       }
/*     */     }
/* 110 */     interp.exec(script);
/*     */   }
/*     */   
/*     */   public static PythonInterpreter getPythonInterpreter()
/*     */   {
/* 115 */     if (interpreter == null)
/*     */     {
/* 117 */       interpreter = new PythonInterpreter();
/* 118 */       PySystemState sys = Py.getSystemState();
/* 119 */       PySystemState.add_package("javax.management");
/* 120 */       PySystemState.add_package("javax.management.loading");
/* 121 */       PySystemState.add_package("javax.management.modelmbean");
/* 122 */       PySystemState.add_package("javax.management.monitor");
/* 123 */       PySystemState.add_package("javax.management.openmbean");
/* 124 */       PySystemState.add_package("javax.management.remote");
/* 125 */       PySystemState.add_package("javax.management.remote.rmi");
/* 126 */       PySystemState.add_package("javax.management.relation");
/* 127 */       PySystemState.add_package("javax.management.timer");
/*     */       try
/*     */       {
/* 130 */         String script = loadStream(JythonRunner.class.getClassLoader().getResourceAsStream("mx4j/tools/jython/jmxUtils.py"));
/* 131 */         interpreter.exec(script);
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 135 */         e.printStackTrace();
/*     */       }
/*     */     }
/* 138 */     return interpreter;
/*     */   }
/*     */   
/*     */   protected static String loadStream(InputStream in) throws IOException
/*     */   {
/* 143 */     BufferedReader reader = new BufferedReader(new InputStreamReader(in));
/* 144 */     String line = null;
/* 145 */     StringBuffer buffer = new StringBuffer();
/* 146 */     while ((line = reader.readLine()) != null)
/*     */     {
/* 148 */       buffer.append(line);
/* 149 */       buffer.append("\n");
/*     */     }
/* 151 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNotificationType()
/*     */   {
/* 159 */     return this.notificationName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNotificationType(String notificationName)
/*     */   {
/* 169 */     this.notificationName = notificationName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setObservedObject(ObjectName targetMBeanName)
/*     */   {
/* 178 */     this.targetMBeanName = targetMBeanName;
/* 179 */     registerListener();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getObservedObject()
/*     */   {
/* 187 */     return this.targetMBeanName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getUseText()
/*     */   {
/* 196 */     return this.useText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScript(String text)
/*     */   {
/* 205 */     this.scriptText = text;
/* 206 */     this.useText = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getScript()
/*     */   {
/* 214 */     return this.scriptText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getScriptURL()
/*     */   {
/* 222 */     return this.scriptFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScriptURL(URL file)
/*     */   {
/* 232 */     this.scriptFile = file;
/* 233 */     this.useText = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getCacheScript()
/*     */   {
/* 242 */     return this.useCache;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheScript(boolean useCache)
/*     */   {
/* 251 */     this.useCache = useCache;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName preRegister(MBeanServer server, ObjectName name)
/*     */     throws Exception
/*     */   {
/* 260 */     this.server = server;
/* 261 */     this.objectName = name;
/* 262 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void postRegister(Boolean registrationDone) {}
/*     */   
/*     */ 
/*     */   public void preDeregister()
/*     */     throws Exception
/*     */   {
/* 273 */     unregisterListener();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void postDeregister() {}
/*     */   
/*     */ 
/*     */   protected void registerListener()
/*     */   {
/*     */     try
/*     */     {
/* 285 */       if ((this.targetMBeanName != null) && (this.server.isInstanceOf(this.targetMBeanName, "javax.management.NotificationBroadcaster")))
/*     */       {
/* 287 */         this.server.addNotificationListener(this.targetMBeanName, this, new MessageFilter(null), null);
/*     */       }
/*     */     }
/*     */     catch (InstanceNotFoundException e)
/*     */     {
/* 292 */       Logger log = getLogger();
/* 293 */       log.error("Exception during notification registration", e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void unregisterListener()
/*     */   {
/*     */     try
/*     */     {
/* 301 */       if ((this.targetMBeanName != null) && (this.server.isInstanceOf(this.targetMBeanName, "javax.management.NotificationBroadcaster")))
/*     */       {
/* 303 */         this.server.removeNotificationListener(this.targetMBeanName, this);
/*     */       }
/*     */     }
/*     */     catch (InstanceNotFoundException e)
/*     */     {
/* 308 */       Logger log = getLogger();
/* 309 */       log.error("Exception during notification unregistration", e);
/*     */     }
/*     */     catch (ListenerNotFoundException e) {}
/*     */   }
/*     */   
/*     */   private class MessageFilter implements NotificationFilter {
/*     */     MessageFilter(JythonRunner.1 x1) {
/* 316 */       this();
/*     */     }
/*     */     
/*     */     public boolean isNotificationEnabled(Notification notification) {
/* 320 */       return (JythonRunner.this.notificationName == null) || ((notification.getType() != null) && (notification.getType().equals(JythonRunner.this.notificationName)));
/*     */     }
/*     */     
/*     */     private MessageFilter() {}
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/jython/JythonRunner.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */