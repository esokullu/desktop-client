package mx4j.tools.jython;

import java.net.URL;
import javax.management.ObjectName;

public abstract interface JythonRunnerMBean
{
  public abstract void runScript();
  
  public abstract String getNotificationType();
  
  public abstract void setNotificationType(String paramString);
  
  public abstract void setObservedObject(ObjectName paramObjectName);
  
  public abstract ObjectName getObservedObject();
  
  public abstract boolean getUseText();
  
  public abstract void setScript(String paramString);
  
  public abstract String getScript();
  
  public abstract URL getScriptURL();
  
  public abstract void setScriptURL(URL paramURL);
  
  public abstract boolean getCacheScript();
  
  public abstract void setCacheScript(boolean paramBoolean);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/jython/JythonRunnerMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */