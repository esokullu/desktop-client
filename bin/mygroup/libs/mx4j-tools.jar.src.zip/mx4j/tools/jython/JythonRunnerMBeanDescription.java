/*    */ package mx4j.tools.jython;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import mx4j.MBeanDescriptionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JythonRunnerMBeanDescription
/*    */   extends MBeanDescriptionAdapter
/*    */ {
/*    */   public String getMBeanDescription()
/*    */   {
/* 24 */     return "Runs a jython script for management purposes";
/*    */   }
/*    */   
/*    */   public String getAttributeDescription(String attribute)
/*    */   {
/* 29 */     if (attribute.equals("NotificationType"))
/*    */     {
/* 31 */       return "The Notification type that triggers the script execution";
/*    */     }
/* 33 */     if (attribute.equals("ObservedObject"))
/*    */     {
/* 35 */       return "The ObjectName being observed";
/*    */     }
/* 37 */     if (attribute.equals("UseText"))
/*    */     {
/* 39 */       return "Indicates wether a text based or file based script is used";
/*    */     }
/* 41 */     if (attribute.equals("Script"))
/*    */     {
/* 43 */       return "The script text";
/*    */     }
/* 45 */     if (attribute.equals("ScriptURL"))
/*    */     {
/* 47 */       return "The script's URL";
/*    */     }
/* 49 */     if (attribute.equals("CacheScript"))
/*    */     {
/* 51 */       return "Indicates whether the script is read every time or only once";
/*    */     }
/* 53 */     return super.getAttributeDescription(attribute);
/*    */   }
/*    */   
/*    */   public String getOperationDescription(Method operation)
/*    */   {
/* 58 */     String name = operation.getName();
/* 59 */     if (name.equals("runScript"))
/*    */     {
/* 61 */       return "Runs the jython script";
/*    */     }
/* 63 */     return super.getOperationDescription(operation);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/jython/JythonRunnerMBeanDescription.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */