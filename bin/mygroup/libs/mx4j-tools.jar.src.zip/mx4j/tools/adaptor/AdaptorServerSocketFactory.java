package mx4j.tools.adaptor;

import java.io.IOException;
import java.net.ServerSocket;

public abstract interface AdaptorServerSocketFactory
{
  public abstract ServerSocket createServerSocket(int paramInt1, int paramInt2, String paramString)
    throws IOException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/AdaptorServerSocketFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */