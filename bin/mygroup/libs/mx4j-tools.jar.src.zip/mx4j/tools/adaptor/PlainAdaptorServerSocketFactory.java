/*    */ package mx4j.tools.adaptor;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.InetAddress;
/*    */ import java.net.ServerSocket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlainAdaptorServerSocketFactory
/*    */   implements AdaptorServerSocketFactory
/*    */ {
/*    */   public ServerSocket createServerSocket(int port, int backlog, String host)
/*    */     throws IOException
/*    */   {
/* 24 */     return new ServerSocket(port, backlog, InetAddress.getByName(host));
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/PlainAdaptorServerSocketFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */