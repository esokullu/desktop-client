/*     */ package mx4j.tools.adaptor.ssl;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import mx4j.MBeanDescriptionAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLAdaptorServerSocketFactoryMBeanDescription
/*     */   extends MBeanDescriptionAdapter
/*     */ {
/*     */   public String getMBeanDescription()
/*     */   {
/*  25 */     return "Factory for SSLServerSockets used by adaptors";
/*     */   }
/*     */   
/*     */   public String getConstructorDescription(Constructor ctor)
/*     */   {
/*  30 */     return "Creates a new SSLServerSocket factory for adaptors";
/*     */   }
/*     */   
/*     */   public String getAttributeDescription(String attribute)
/*     */   {
/*  35 */     if (attribute.equals("WantClientAuth"))
/*     */     {
/*  37 */       return "Want SSL client sockets to provide an X509 certificate";
/*     */     }
/*  39 */     if (attribute.equals("NeedClientAuth"))
/*     */     {
/*  41 */       return "Need ( or session will fail ) SSL client sockets to provide an X509 certificate";
/*     */     }
/*  43 */     if (attribute.equals("KeyStoreType"))
/*     */     {
/*  45 */       return "The type of the keystore, default is 'JKS'";
/*     */     }
/*  47 */     if (attribute.equals("TrustStoreType"))
/*     */     {
/*  49 */       return "The type of the truststore, default is 'JKS'";
/*     */     }
/*  51 */     if (attribute.equals("KeyStoreName"))
/*     */     {
/*  53 */       return "The keystore name";
/*     */     }
/*  55 */     if (attribute.equals("TrustStoreName"))
/*     */     {
/*  57 */       return "The truststore name";
/*     */     }
/*  59 */     if (attribute.equals("KeyStorePassword"))
/*     */     {
/*  61 */       return "The keystore password";
/*     */     }
/*  63 */     if (attribute.equals("TrustStorePassword"))
/*     */     {
/*  65 */       return "The truststore password";
/*     */     }
/*  67 */     if (attribute.equals("KeyManagerAlgorithm"))
/*     */     {
/*  69 */       return "The key algorithm, default is 'SunX509'";
/*     */     }
/*  71 */     if (attribute.equals("TrustManagerAlgorithm"))
/*     */     {
/*  73 */       return "The trust algorithm, default is 'SunX509'";
/*     */     }
/*  75 */     if (attribute.equals("KeyManagerPassword"))
/*     */     {
/*  77 */       return "The key password";
/*     */     }
/*  79 */     if (attribute.equals("SSLProtocol"))
/*     */     {
/*  81 */       return "The SSL protocol version, default is 'TLS'";
/*     */     }
/*  83 */     if (attribute.equals("SSLCOntext"))
/*     */     {
/*  85 */       return "The SSL context object'";
/*     */     }
/*  87 */     return super.getAttributeDescription(attribute);
/*     */   }
/*     */   
/*     */   public String getOperationDescription(Method operation)
/*     */   {
/*  92 */     String name = operation.getName();
/*  93 */     if (name.equals("createServerSocket"))
/*     */     {
/*  95 */       return "Creates a new SSLServerSocket";
/*     */     }
/*  97 */     return super.getOperationDescription(operation);
/*     */   }
/*     */   
/*     */   public String getOperationParameterName(Method method, int index)
/*     */   {
/* 102 */     String name = method.getName();
/* 103 */     if (name.equals("createServerSocket"))
/*     */     {
/* 105 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 108 */         return "port";
/*     */       case 1: 
/* 110 */         return "backlog";
/*     */       case 2: 
/* 112 */         return "host";
/*     */       }
/*     */     }
/* 115 */     return super.getOperationParameterName(method, index);
/*     */   }
/*     */   
/*     */   public String getOperationParameterDescription(Method method, int index)
/*     */   {
/* 120 */     String name = method.getName();
/* 121 */     if (name.equals("createServerSocket"))
/*     */     {
/* 123 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 126 */         return "The port on which the SSLServerSocket listens for incoming connections";
/*     */       case 1: 
/* 128 */         return "The backlog for this SSLServerSocket";
/*     */       case 2: 
/* 130 */         return "The host name or IP address on which the SSLServerSocket is opened";
/*     */       }
/*     */     }
/* 133 */     return super.getOperationParameterDescription(method, index);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/ssl/SSLAdaptorServerSocketFactoryMBeanDescription.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */