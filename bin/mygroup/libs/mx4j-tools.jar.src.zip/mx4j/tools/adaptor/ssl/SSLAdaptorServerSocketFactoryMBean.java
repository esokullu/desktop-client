package mx4j.tools.adaptor.ssl;

import javax.net.ssl.SSLContext;
import mx4j.tools.adaptor.AdaptorServerSocketFactory;

public abstract interface SSLAdaptorServerSocketFactoryMBean
  extends AdaptorServerSocketFactory
{
  public abstract void setWantClientAuth(boolean paramBoolean);
  
  public abstract void setNeedClientAuth(boolean paramBoolean);
  
  public abstract void setKeyStoreType(String paramString);
  
  public abstract void setTrustStoreType(String paramString);
  
  public abstract void setKeyStoreName(String paramString);
  
  public abstract void setTrustStoreName(String paramString);
  
  public abstract void setKeyStorePassword(String paramString);
  
  public abstract void setTrustStorePassword(String paramString);
  
  public abstract void setKeyManagerAlgorithm(String paramString);
  
  public abstract void setTrustManagerAlgorithm(String paramString);
  
  public abstract void setKeyManagerPassword(String paramString);
  
  public abstract void setSSLProtocol(String paramString);
  
  public abstract void setSSLContext(SSLContext paramSSLContext);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/ssl/SSLAdaptorServerSocketFactoryMBean.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */