/*     */ package mx4j.tools.adaptor.ssl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.security.KeyStore;
/*     */ import java.security.Provider;
/*     */ import java.security.Security;
/*     */ import java.security.UnrecoverableKeyException;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLServerSocket;
/*     */ import javax.net.ssl.SSLServerSocketFactory;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLAdaptorServerSocketFactory
/*     */   implements SSLAdaptorServerSocketFactoryMBean
/*     */ {
/*  69 */   private String m_keyStoreType = "JKS";
/*  70 */   private String m_trustStoreType = "JKS";
/*     */   private String m_keyStoreName;
/*     */   private String m_trustStoreName;
/*     */   private String m_keyStorePassword;
/*     */   private String m_trustStorePassword;
/*  75 */   private String m_keyManagerAlgorithm = "SunX509";
/*  76 */   private String m_trustManagerAlgorithm = "SunX509";
/*     */   private String m_keyManagerPassword;
/*  78 */   private String m_sslProtocol = "TLS";
/*     */   
/*     */   private SSLContext sslContext;
/*     */   
/*  82 */   private boolean m_wantClientAuth = false;
/*  83 */   private boolean m_needClientAuth = false;
/*     */   
/*     */   public static void addProvider(Provider provider)
/*     */   {
/*  87 */     Security.addProvider(provider);
/*     */   }
/*     */   
/*     */   public void setWantClientAuth(boolean wantClientAuth)
/*     */   {
/*  92 */     this.m_wantClientAuth = wantClientAuth;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setNeedClientAuth(boolean needClientAuth)
/*     */   {
/*  98 */     this.m_needClientAuth = needClientAuth;
/*     */   }
/*     */   
/*     */   public void setKeyStoreType(String keyStoreType)
/*     */   {
/* 103 */     if ((keyStoreType == null) || (keyStoreType.trim().length() == 0))
/*     */     {
/* 105 */       throw new IllegalArgumentException("Invalid KeyStore type");
/*     */     }
/* 107 */     this.m_keyStoreType = keyStoreType;
/*     */   }
/*     */   
/*     */   public void setTrustStoreType(String trustStoreType)
/*     */   {
/* 112 */     if ((trustStoreType == null) || (trustStoreType.trim().length() == 0))
/*     */     {
/* 114 */       throw new IllegalArgumentException("Invalid TrustStore type");
/*     */     }
/* 116 */     this.m_trustStoreType = trustStoreType;
/*     */   }
/*     */   
/*     */   public void setKeyStoreName(String name)
/*     */   {
/* 121 */     if ((name == null) || (name.trim().length() == 0))
/*     */     {
/* 123 */       throw new IllegalArgumentException("Invalid KeyStore name");
/*     */     }
/* 125 */     this.m_keyStoreName = name;
/*     */   }
/*     */   
/*     */   public void setTrustStoreName(String name)
/*     */   {
/* 130 */     if ((name == null) || (name.trim().length() == 0))
/*     */     {
/* 132 */       throw new IllegalArgumentException("Invalid TrustStore name");
/*     */     }
/* 134 */     this.m_trustStoreName = name;
/*     */   }
/*     */   
/*     */   public void setKeyStorePassword(String password)
/*     */   {
/* 139 */     if ((password == null) || (password.trim().length() == 0))
/*     */     {
/* 141 */       throw new IllegalArgumentException("Invalid KeyStore password");
/*     */     }
/* 143 */     this.m_keyStorePassword = password;
/*     */   }
/*     */   
/*     */   public void setTrustStorePassword(String password)
/*     */   {
/* 148 */     if ((password == null) || (password.trim().length() == 0))
/*     */     {
/* 150 */       throw new IllegalArgumentException("Invalid TrustStore password");
/*     */     }
/* 152 */     this.m_trustStorePassword = password;
/*     */   }
/*     */   
/*     */   public void setKeyManagerAlgorithm(String algorithm)
/*     */   {
/* 157 */     if ((algorithm == null) || (algorithm.trim().length() == 0))
/*     */     {
/* 159 */       throw new IllegalArgumentException("Invalid KeyManager algorithm");
/*     */     }
/* 161 */     this.m_keyManagerAlgorithm = algorithm;
/*     */   }
/*     */   
/*     */   public void setTrustManagerAlgorithm(String algorithm)
/*     */   {
/* 166 */     if ((algorithm == null) || (algorithm.trim().length() == 0))
/*     */     {
/* 168 */       throw new IllegalArgumentException("Invalid TrustManager algorithm");
/*     */     }
/* 170 */     this.m_trustManagerAlgorithm = algorithm;
/*     */   }
/*     */   
/*     */   public void setKeyManagerPassword(String password)
/*     */   {
/* 175 */     if ((password == null) || (password.trim().length() == 0))
/*     */     {
/* 177 */       throw new IllegalArgumentException("Invalid KeyManager password");
/*     */     }
/* 179 */     this.m_keyManagerPassword = password;
/*     */   }
/*     */   
/*     */   public void setSSLProtocol(String protocol)
/*     */   {
/* 184 */     if ((protocol == null) || (protocol.trim().length() == 0))
/*     */     {
/* 186 */       throw new IllegalArgumentException("Invalid SSL protocol");
/*     */     }
/* 188 */     this.m_sslProtocol = protocol;
/*     */   }
/*     */   
/*     */   public void setSSLContext(SSLContext sslContext)
/*     */   {
/* 193 */     this.sslContext = sslContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServerSocket createServerSocket(int port, int backlog, String host)
/*     */     throws IOException
/*     */   {
/* 202 */     Logger logger = getLogger();
/*     */     
/*     */     try
/*     */     {
/* 206 */       if (this.sslContext == null)
/*     */       {
/*     */ 
/* 209 */         if (this.m_keyStoreName == null)
/*     */         {
/* 211 */           throw new IOException("KeyStore file name cannot be null");
/*     */         }
/* 213 */         if (this.m_keyStorePassword == null)
/*     */         {
/* 215 */           throw new IOException("KeyStore password cannot be null");
/*     */         }
/*     */         
/* 218 */         if (logger.isEnabledFor(0))
/*     */         {
/* 220 */           logger.trace("Creating SSLServerSocket");
/* 221 */           logger.trace("\tKeyStore " + this.m_keyStoreName + ", type " + this.m_keyStoreType);
/* 222 */           logger.trace("\tKeyManager algorithm is " + this.m_keyManagerAlgorithm);
/* 223 */           logger.trace("\tTrustStore " + this.m_trustStoreName + ", type " + this.m_trustStoreType);
/* 224 */           logger.trace("\tTrustManager algorithm is " + this.m_trustManagerAlgorithm);
/* 225 */           logger.trace("\tSSL protocol version is " + this.m_sslProtocol);
/*     */         }
/*     */         
/* 228 */         KeyStore keystore = KeyStore.getInstance(this.m_keyStoreType);
/* 229 */         InputStream keyStoreStream = getClass().getClassLoader().getResourceAsStream(this.m_keyStoreName);
/*     */         
/* 231 */         if (keyStoreStream == null)
/*     */         {
/*     */ 
/* 234 */           File fle = new File(this.m_keyStoreName);
/* 235 */           if (fle.exists()) keyStoreStream = new FileInputStream(fle);
/*     */         }
/* 237 */         if (keyStoreStream == null) throw new IOException("Cannot find KeyStore " + this.m_keyStoreName);
/* 238 */         keystore.load(keyStoreStream, this.m_keyStorePassword.toCharArray());
/*     */         try
/*     */         {
/* 241 */           keyStoreStream.close();
/*     */         }
/*     */         catch (IOException localIOException1) {}
/*     */         
/*     */ 
/*     */ 
/* 247 */         KeyManagerFactory keyFactory = KeyManagerFactory.getInstance(this.m_keyManagerAlgorithm);
/*     */         
/* 249 */         keyFactory.init(keystore, this.m_keyManagerPassword == null ? this.m_keyStorePassword.toCharArray() : this.m_keyManagerPassword.toCharArray());
/*     */         
/* 251 */         TrustManagerFactory trustFactory = null;
/* 252 */         if (this.m_trustStoreName != null)
/*     */         {
/*     */ 
/*     */ 
/* 256 */           if (this.m_trustStorePassword == null)
/*     */           {
/* 258 */             throw new IOException("TrustStore password cannot be null");
/*     */           }
/*     */           
/* 261 */           KeyStore trustStore = KeyStore.getInstance(this.m_trustStoreType);
/* 262 */           InputStream trustStoreStream = getClass().getClassLoader().getResourceAsStream(this.m_trustStoreName);
/*     */           
/* 264 */           if (trustStoreStream == null)
/*     */           {
/*     */ 
/* 267 */             File fle = new File(this.m_trustStoreName);
/* 268 */             if (fle.exists()) trustStoreStream = new FileInputStream(fle);
/* 269 */             if (trustStoreStream == null) throw new IOException("Cannot find TrustStore " + this.m_trustStoreName);
/*     */           }
/* 271 */           trustStore.load(trustStoreStream, this.m_trustStorePassword.toCharArray());
/*     */           try {
/* 273 */             trustStoreStream.close();
/*     */           }
/*     */           catch (IOException localIOException2) {}
/*     */           
/* 277 */           trustFactory = TrustManagerFactory.getInstance(this.m_trustManagerAlgorithm);
/* 278 */           trustFactory.init(trustStore);
/*     */         }
/*     */         
/* 281 */         this.sslContext = SSLContext.getInstance(this.m_sslProtocol);
/*     */         
/* 283 */         this.sslContext.init(keyFactory.getKeyManagers(), trustFactory == null ? null : trustFactory.getTrustManagers(), null);
/*     */       }
/* 285 */       SSLServerSocketFactory ssf = this.sslContext.getServerSocketFactory();
/* 286 */       SSLServerSocket serverSocket = (SSLServerSocket)ssf.createServerSocket(port, backlog, InetAddress.getByName(host));
/* 287 */       serverSocket.setWantClientAuth(this.m_wantClientAuth);
/* 288 */       serverSocket.setNeedClientAuth(this.m_needClientAuth);
/* 289 */       return serverSocket;
/*     */     }
/*     */     catch (IOException x)
/*     */     {
/* 293 */       logger.error("IOException occured during SSLContext creation", x);
/* 294 */       throw x;
/*     */ 
/*     */     }
/*     */     catch (UnrecoverableKeyException x)
/*     */     {
/* 299 */       logger.error("Probably a bad key password", x);
/* 300 */       throw new IOException("Probably a bad key password: " + x.toString());
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/* 304 */       logger.error("Unexpected exception", x);
/* 305 */       throw new IOException(x.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/* 311 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/ssl/SSLAdaptorServerSocketFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */