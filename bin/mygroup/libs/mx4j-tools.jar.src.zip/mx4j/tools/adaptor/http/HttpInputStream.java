/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpInputStream
/*     */   extends BufferedInputStream
/*     */ {
/*     */   private String method;
/*     */   private String path;
/*     */   private String queryString;
/*     */   private float version;
/*  81 */   private Map headers = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*  85 */   private Map variables = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpInputStream(InputStream in)
/*     */   {
/* 103 */     super(in);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMethod()
/*     */   {
/* 125 */     return this.method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPath()
/*     */   {
/* 147 */     return this.path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getQueryString()
/*     */   {
/* 169 */     return this.queryString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getVersion()
/*     */   {
/* 191 */     return this.version;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHeader(String name)
/*     */   {
/* 215 */     return (String)this.headers.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map getHeaders()
/*     */   {
/* 237 */     return this.headers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean readRequest()
/*     */     throws IOException
/*     */   {
/* 259 */     String request = readLine();
/*     */     
/* 261 */     if (request == null)
/*     */     {
/*     */ 
/*     */ 
/* 265 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 272 */     StringTokenizer parts = new StringTokenizer(request);
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 278 */       parseMethod(parts.nextToken());
/*     */       
/* 280 */       parseRequest(parts.nextToken());
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (NoSuchElementException ex)
/*     */     {
/*     */ 
/*     */ 
/* 288 */       throw new HttpException(400, request);
/*     */     }
/*     */     
/*     */ 
/* 292 */     if (parts.hasMoreTokens())
/*     */     {
/*     */ 
/*     */ 
/* 296 */       parseVersion(parts.nextToken());
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/* 304 */       this.version = 0.9F;
/*     */     }
/*     */     
/*     */ 
/* 308 */     if (this.version >= 1.0F)
/*     */     {
/*     */ 
/*     */ 
/* 312 */       readHeaders();
/*     */       
/* 314 */       parseVariables();
/*     */     }
/*     */     
/*     */ 
/* 318 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String readLine()
/*     */     throws IOException
/*     */   {
/* 341 */     StringBuffer line = new StringBuffer(64);
/*     */     
/* 343 */     line.delete(0, line.length());
/*     */     
/*     */     int c;
/*     */     
/* 347 */     while (((c = read()) != -1) && (c != 10) && (c != 13))
/*     */     {
/*     */       int c;
/*     */       
/* 351 */       line.append((char)c);
/*     */     }
/*     */     
/*     */ 
/* 355 */     if ((c == 13) && ((c = read()) != 10) && (c != -1))
/*     */     {
/*     */ 
/*     */ 
/* 359 */       this.pos -= 1;
/*     */     }
/*     */     
/*     */ 
/* 363 */     if ((c == -1) && (line.length() == 0))
/*     */     {
/*     */ 
/*     */ 
/* 367 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 375 */     return line.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map getVariables()
/*     */   {
/* 401 */     return this.variables;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getVariable(String name)
/*     */   {
/* 423 */     if (this.variables.containsKey(name))
/*     */     {
/*     */ 
/*     */ 
/* 427 */       Object variable = this.variables.get(name);
/*     */       
/* 429 */       if ((variable instanceof String))
/*     */       {
/*     */ 
/*     */ 
/* 433 */         return (String)variable;
/*     */       }
/*     */       
/*     */ 
/* 437 */       if ((variable instanceof String[]))
/*     */       {
/*     */ 
/*     */ 
/* 441 */         return ((String[])variable)[0];
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 447 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getVariableValues(String name)
/*     */   {
/* 467 */     if (this.variables.containsKey(name))
/*     */     {
/*     */ 
/*     */ 
/* 471 */       Object variable = this.variables.get(name);
/*     */       
/* 473 */       if ((variable instanceof String[]))
/*     */       {
/*     */ 
/*     */ 
/* 477 */         return (String[])variable;
/*     */       }
/* 479 */       if ((variable instanceof String))
/*     */       {
/*     */ 
/*     */ 
/* 483 */         String[] result = new String[1];
/*     */         
/* 485 */         result[0] = ((String)variable);
/*     */         
/* 487 */         return result;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 493 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void parseVariables()
/*     */     throws HttpException
/*     */   {
/*     */     try
/*     */     {
/* 515 */       String variableHolder = "";
/*     */       
/* 517 */       if ((this.method.equals("POST")) && ("application/x-www-form-urlencoded".equals(this.headers.get("content-type"))))
/*     */       {
/* 519 */         if (this.headers.get("content-length") != null)
/*     */         {
/*     */ 
/*     */ 
/* 523 */           if ("chunked".equals(this.headers.get("transfer-encoding")))
/*     */           {
/*     */ 
/*     */ 
/* 527 */             throw new HttpException(400, "Sorry I don't understand chunked requests");
/*     */           }
/*     */           
/*     */ 
/* 531 */           StringBuffer buffer = new StringBuffer();
/*     */           
/* 533 */           int size = Integer.parseInt((String)this.headers.get("content-length"));
/*     */           
/* 535 */           mark(size);
/*     */           
/* 537 */           for (int i = 0; i < size; i++)
/*     */           {
/*     */ 
/*     */ 
/* 541 */             int j = read();
/*     */             
/* 543 */             if (j >= 0)
/*     */             {
/*     */ 
/*     */ 
/* 547 */               buffer.append((char)j);
/*     */ 
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/*     */ 
/*     */ 
/* 555 */               throw new HttpException(400, "Request not understood");
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 561 */           variableHolder = buffer.toString();
/*     */           
/* 563 */           reset();
/*     */           break label206;
/*     */         }
/*     */       }
/* 567 */       if (this.method.equals("GET"))
/*     */       {
/*     */ 
/*     */ 
/* 571 */         variableHolder = getQueryString();
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/* 579 */         throw new HttpException(400, "Request not understood");
/*     */       }
/*     */       
/*     */       label206:
/* 583 */       StringTokenizer parser = new StringTokenizer(variableHolder, "&");
/*     */       
/* 585 */       while (parser.hasMoreTokens())
/*     */       {
/*     */ 
/*     */ 
/* 589 */         String command = parser.nextToken();
/*     */         
/* 591 */         int equalIndex = command.indexOf('=');
/*     */         
/* 593 */         if (equalIndex > 0)
/*     */         {
/*     */ 
/*     */ 
/* 597 */           String variableName = URLDecoder.decode(command.substring(0, equalIndex));
/*     */           
/* 599 */           String variableValue = URLDecoder.decode(command.substring(equalIndex + 1, command.length()));
/*     */           
/* 601 */           variableValue = new String(variableValue.getBytes(), "UTF-8");
/*     */           
/* 603 */           if (this.variables.get(variableName) != null)
/*     */           {
/* 605 */             Object value = this.variables.get(variableName);
/*     */             
/* 607 */             String[] newValue = (String[])null;
/*     */             
/* 609 */             if ((value instanceof String))
/*     */             {
/*     */ 
/*     */ 
/* 613 */               newValue = new String[2];
/*     */               
/* 615 */               newValue[0] = variableValue;
/*     */               
/* 617 */               newValue[1] = ((String)value);
/*     */ 
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/*     */ 
/*     */ 
/* 625 */               String[] oldValue = (String[])value;
/*     */               
/* 627 */               newValue = new String[oldValue.length + 1];
/*     */               
/* 629 */               System.arraycopy(oldValue, 0, newValue, 1, oldValue.length);
/*     */               
/* 631 */               newValue[0] = variableValue;
/*     */             }
/*     */             
/*     */ 
/* 635 */             this.variables.put(variableName, newValue);
/*     */ 
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/*     */ 
/* 643 */             this.variables.put(variableName, variableValue);
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */ 
/* 657 */       throw new HttpException(400, getQueryString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void parseMethod(String method)
/*     */     throws HttpException
/*     */   {
/* 683 */     if (method.equals("GET"))
/*     */     {
/*     */ 
/*     */ 
/* 687 */       this.method = "GET";
/*     */ 
/*     */ 
/*     */     }
/* 691 */     else if (method.equals("POST"))
/*     */     {
/*     */ 
/*     */ 
/* 695 */       this.method = "POST";
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/* 703 */       throw new HttpException(501, method);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void parseRequest(String request)
/*     */     throws HttpException
/*     */   {
/* 729 */     if (!request.startsWith("/"))
/*     */     {
/*     */ 
/*     */ 
/* 733 */       throw new HttpException(400, request);
/*     */     }
/*     */     
/*     */ 
/* 737 */     int queryIdx = request.indexOf('?');
/*     */     
/* 739 */     if (queryIdx == -1)
/*     */     {
/*     */ 
/*     */ 
/* 743 */       this.path = HttpUtil.canonicalizePath(request);
/*     */       
/* 745 */       this.queryString = "";
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/* 753 */       this.path = HttpUtil.canonicalizePath(request.substring(0, queryIdx));
/*     */       
/* 755 */       this.queryString = request.substring(queryIdx + 1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void parseVersion(String verStr)
/*     */     throws HttpException
/*     */   {
/* 781 */     if (!verStr.startsWith("HTTP/"))
/*     */     {
/*     */ 
/*     */ 
/* 785 */       throw new HttpException(400, verStr);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 793 */       this.version = Float.valueOf(verStr.substring(5)).floatValue();
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (NumberFormatException ex)
/*     */     {
/*     */ 
/*     */ 
/* 801 */       throw new HttpException(400, verStr);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void readHeaders()
/*     */     throws IOException
/*     */   {
/*     */     String header;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 827 */     while (((header = readLine()) != null) && (!header.equals("")))
/*     */     {
/*     */       String header;
/*     */       
/* 831 */       int colonIdx = header.indexOf(':');
/*     */       
/* 833 */       if (colonIdx != -1)
/*     */       {
/*     */ 
/*     */ 
/* 837 */         String name = header.substring(0, colonIdx);
/*     */         
/* 839 */         String value = header.substring(colonIdx + 1);
/*     */         
/* 841 */         this.headers.put(name.toLowerCase(), value.trim());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/HttpInputStream.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */