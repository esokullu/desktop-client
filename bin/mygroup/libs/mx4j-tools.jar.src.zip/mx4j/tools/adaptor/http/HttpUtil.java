/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpUtil
/*     */ {
/*     */   public static String getCodeMessage(int code)
/*     */   {
/*  27 */     switch (code)
/*     */     {
/*     */     case 200: 
/*  30 */       return "OK";
/*     */     case 204: 
/*  32 */       return "No Content";
/*     */     case 301: 
/*  34 */       return "Moved Permanently";
/*     */     case 302: 
/*  36 */       return "Moved Temporarily";
/*     */     case 400: 
/*  38 */       return "Bad Request";
/*     */     case 403: 
/*  40 */       return "Forbidden";
/*     */     case 404: 
/*  42 */       return "Not Found";
/*     */     case 405: 
/*  44 */       return "Method Not Allowed";
/*     */     case 500: 
/*  46 */       return "Internal Server Error";
/*     */     case 401: 
/*  48 */       return "Authentication requested";
/*     */     case 501: 
/*  50 */       return "Not Implemented";
/*     */     }
/*  52 */     return "Unknown Code (" + code + ")";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String canonicalizePath(String path)
/*     */   {
/*  65 */     char[] chars = path.toCharArray();
/*  66 */     int length = chars.length;
/*     */     
/*  68 */     int odx = 0;
/*  69 */     int idx; while ((idx = indexOf(chars, length, '/', odx)) < length - 1)
/*     */     {
/*  71 */       int ndx = indexOf(chars, length, '/', idx + 1);
/*  72 */       int kill = -1;
/*  73 */       if (ndx == idx + 1)
/*     */       {
/*  75 */         kill = 1;
/*     */       }
/*  77 */       else if ((ndx >= idx + 2) && (chars[(idx + 1)] == '.'))
/*     */       {
/*  79 */         if (ndx == idx + 2)
/*     */         {
/*  81 */           kill = 2;
/*     */         }
/*  83 */         else if ((ndx == idx + 3) && (chars[(idx + 2)] == '.'))
/*     */         {
/*  85 */           kill = 3;
/*  86 */           while ((idx > 0) && (chars[(--idx)] != '/'))
/*     */           {
/*  88 */             kill++;
/*     */           }
/*     */         }
/*     */       }
/*  92 */       if (kill == -1)
/*     */       {
/*  94 */         odx = ndx;
/*     */       }
/*  96 */       else if (idx + kill >= length)
/*     */       {
/*  98 */         length = odx = idx + 1;
/*     */       }
/*     */       else
/*     */       {
/* 102 */         length -= kill;
/* 103 */         System.arraycopy(chars, idx + 1 + kill, chars, idx + 1, length - idx - 1);
/*     */         
/* 105 */         odx = idx;
/*     */       }
/*     */     }
/* 108 */     return new String(chars, 0, length);
/*     */   }
/*     */   
/*     */ 
/*     */   protected static int indexOf(char[] chars, int length, char chr, int from)
/*     */   {
/* 114 */     while ((from < length) && (chars[from] != chr))
/*     */     {
/* 116 */       from++;
/*     */     }
/* 118 */     return from;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean booleanVariableValue(HttpInputStream in, String variable, boolean defaultValue)
/*     */   {
/* 129 */     if (in.getVariables().containsKey(variable))
/*     */     {
/* 131 */       String result = (String)in.getVariables().get(variable);
/* 132 */       return (result.equals("true")) || (result.equals("1"));
/*     */     }
/* 134 */     return defaultValue;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/HttpUtil.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */