/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.RuntimeMBeanException;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Templates;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.URIResolver;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XSLTProcessor
/*     */   implements ProcessorMBean, XSLTProcessorMBean, URIResolver
/*     */ {
/*  52 */   private String path = "mx4j/tools/adaptor/http/xsl";
/*  53 */   private String defaultPage = "serverbydomain";
/*     */   private TransformerFactory factory;
/*  55 */   private Map templatesCache = new HashMap();
/*     */   private File root;
/*  57 */   private Map mimeTypes = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*  61 */   private boolean useJar = true;
/*  62 */   private volatile boolean useCache = true;
/*  63 */   private ClassLoader targetClassLoader = ClassLoader.getSystemClassLoader();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  68 */   private Locale locale = new Locale("en", "");
/*     */   
/*     */   public XSLTProcessor()
/*     */   {
/*  72 */     this.factory = TransformerFactory.newInstance();
/*  73 */     this.factory.setURIResolver(this);
/*  74 */     this.mimeTypes.put(".gif", "image/gif");
/*  75 */     this.mimeTypes.put(".jpg", "image/jpg");
/*  76 */     this.mimeTypes.put(".png", "image/png");
/*  77 */     this.mimeTypes.put(".tif", "image/tiff");
/*  78 */     this.mimeTypes.put(".tiff", "image/tiff");
/*  79 */     this.mimeTypes.put(".ico", "image/ico");
/*  80 */     this.mimeTypes.put(".html", "text/html");
/*  81 */     this.mimeTypes.put(".htm", "text/html");
/*  82 */     this.mimeTypes.put(".txt", "text/plain");
/*  83 */     this.mimeTypes.put(".xml", "text/xml");
/*  84 */     this.mimeTypes.put(".xsl", "text/xsl");
/*  85 */     this.mimeTypes.put(".css", "text/css");
/*  86 */     this.mimeTypes.put(".js", "text/x-javascript");
/*  87 */     this.mimeTypes.put(".jar", "application/java-archive");
/*     */   }
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/*  92 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */   
/*     */   public void writeResponse(HttpOutputStream out, HttpInputStream in, Document document) throws IOException
/*     */   {
/*  97 */     Logger log = getLogger();
/*     */     
/*  99 */     out.setCode(200);
/* 100 */     out.setHeader("Content-Type", "text/html");
/*     */     
/* 102 */     out.setHeader("Cache-Control", "no-cache");
/* 103 */     out.setHeader("expires", "now");
/* 104 */     out.setHeader("pragma", "no-cache");
/* 105 */     out.sendHeaders();
/* 106 */     Transformer transformer = null;
/* 107 */     String path = preProcess(in.getPath());
/*     */     
/* 109 */     if (in.getVariable("template") != null)
/*     */     {
/* 111 */       transformer = createTransformer(in.getVariable("template") + ".xsl");
/*     */     }
/*     */     else
/*     */     {
/* 115 */       transformer = createTransformer(path + ".xsl");
/*     */     }
/*     */     
/* 118 */     if (transformer != null)
/*     */     {
/*     */ 
/* 121 */       transformer.setURIResolver(this);
/*     */       
/* 123 */       Map variables = in.getVariables();
/* 124 */       Iterator j = variables.keySet().iterator();
/* 125 */       while (j.hasNext())
/*     */       {
/* 127 */         String key = (String)j.next();
/* 128 */         Object value = variables.get(key);
/* 129 */         if ((value instanceof String))
/*     */         {
/* 131 */           transformer.setParameter("request." + key, value);
/*     */         }
/* 133 */         if ((value instanceof String[]))
/*     */         {
/* 135 */           String[] allvalues = (String[])value;
/*     */           
/* 137 */           transformer.setParameter("request." + key, allvalues[0]);
/*     */         }
/*     */       }
/*     */       
/* 141 */       if (!variables.containsKey("locale"))
/*     */       {
/* 143 */         transformer.setParameter("request.locale", this.locale.toString());
/*     */       }
/*     */       try
/*     */       {
/* 147 */         ByteArrayOutputStream output = new ByteArrayOutputStream();
/* 148 */         if (log.isEnabledFor(0)) log.trace("transforming " + path);
/* 149 */         transformer.transform(new DOMSource(document), new StreamResult(output));
/* 150 */         output.writeTo(out);
/*     */       }
/*     */       catch (TransformerException e)
/*     */       {
/* 154 */         log.error("Transformation exception ", e);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 159 */       log.warn("Transformer for path " + path + " not found");
/*     */     }
/*     */   }
/*     */   
/*     */   protected Transformer createTransformer(String path)
/*     */   {
/* 165 */     Logger logger = getLogger();
/*     */     try
/*     */     {
/* 168 */       synchronized (this)
/*     */       {
/* 170 */         if ((this.useCache) && (this.templatesCache.containsKey(path)))
/*     */         {
/* 172 */           return ((Templates)this.templatesCache.get(path)).newTransformer();
/*     */         }
/*     */         
/*     */ 
/* 176 */         InputStream stream = getInputStream(path);
/* 177 */         if (stream != null)
/*     */         {
/* 179 */           if (logger.isEnabledFor(10)) logger.debug("Creating template for path " + path);
/* 180 */           Templates template = this.factory.newTemplates(new StreamSource(stream));
/* 181 */           if (this.useCache) this.templatesCache.put(path, template);
/* 182 */           return template.newTransformer();
/*     */         }
/*     */         
/*     */ 
/* 186 */         if (logger.isEnabledFor(20)) { logger.info("XSL template for path '" + path + "' not found");
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     catch (TransformerConfigurationException e)
/*     */     {
/* 193 */       logger.error("Exception during XSL template construction", e);
/*     */     }
/* 195 */     return null;
/*     */   }
/*     */   
/*     */   protected void processHttpException(HttpInputStream in, HttpOutputStream out, HttpException e) throws IOException
/*     */   {
/* 200 */     out.setCode(e.getCode());
/* 201 */     out.setHeader("Content-Type", "text/html");
/* 202 */     out.sendHeaders();
/*     */     
/* 204 */     Transformer transformer = createTransformer("error.xsl");
/* 205 */     transformer.setURIResolver(this);
/* 206 */     Document doc = e.getResponseDoc();
/* 207 */     if (doc != null)
/*     */     {
/*     */       try
/*     */       {
/* 211 */         if (!in.getVariables().containsKey("locale"))
/*     */         {
/* 213 */           transformer.setParameter("request.locale", this.locale.toString());
/*     */         }
/* 215 */         ByteArrayOutputStream output = new ByteArrayOutputStream();
/* 216 */         transformer.transform(new DOMSource(doc), new StreamResult(output));
/* 217 */         output.writeTo(out);
/*     */       }
/*     */       catch (TransformerException ex)
/*     */       {
/* 221 */         Logger log = getLogger();
/* 222 */         log.error("Exception during error output", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeError(HttpOutputStream out, HttpInputStream in, Exception e) throws IOException
/*     */   {
/* 229 */     Logger log = getLogger();
/* 230 */     Exception t = e;
/* 231 */     if ((e instanceof RuntimeMBeanException))
/*     */     {
/* 233 */       t = ((RuntimeMBeanException)e).getTargetException();
/*     */     }
/* 235 */     if (log.isEnabledFor(10)) log.debug("Processing error " + t.getMessage());
/* 236 */     if ((t instanceof HttpException))
/*     */     {
/* 238 */       processHttpException(in, out, (HttpException)t);
/*     */     }
/* 240 */     else if (((t instanceof MBeanException)) && ((((MBeanException)t).getTargetException() instanceof HttpException)))
/*     */     {
/* 242 */       processHttpException(in, out, (HttpException)((MBeanException)t).getTargetException());
/*     */     }
/* 244 */     else if (((t instanceof ReflectionException)) && ((((ReflectionException)t).getTargetException() instanceof HttpException)))
/*     */     {
/* 246 */       processHttpException(in, out, (HttpException)((ReflectionException)t).getTargetException());
/*     */     }
/*     */     else
/*     */     {
/* 250 */       out.setCode(500);
/* 251 */       out.setHeader("Content-Type", "text/html");
/* 252 */       out.sendHeaders();
/*     */     }
/*     */   }
/*     */   
/*     */   public String preProcess(String path)
/*     */   {
/* 258 */     if (path.equals("/"))
/*     */     {
/* 260 */       path = "/" + this.defaultPage;
/*     */     }
/* 262 */     return path;
/*     */   }
/*     */   
/*     */   public String notFoundElement(String path, HttpOutputStream out, HttpInputStream in) throws IOException, HttpException
/*     */   {
/* 267 */     Logger log = getLogger();
/*     */     
/* 269 */     File file = new File(this.path, path);
/* 270 */     if (log.isEnabledFor(10)) log.debug("Processing file request " + file);
/* 271 */     String name = file.getName();
/* 272 */     int extensionIndex = name.lastIndexOf('.');
/* 273 */     String mime = null;
/* 274 */     if (extensionIndex < 0)
/*     */     {
/* 276 */       log.warn("Filename has no extensions " + file.toString());
/* 277 */       mime = "text/plain";
/*     */     }
/*     */     else
/*     */     {
/* 281 */       String extension = name.substring(extensionIndex, name.length());
/* 282 */       if (this.mimeTypes.containsKey(extension))
/*     */       {
/* 284 */         mime = (String)this.mimeTypes.get(extension);
/*     */       }
/*     */       else
/*     */       {
/* 288 */         log.warn("MIME type not found " + extension);
/* 289 */         mime = "text/plain";
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 294 */       if (log.isEnabledFor(10)) log.debug("Trying to read file " + file);
/* 295 */       BufferedInputStream fileIn = new BufferedInputStream(getInputStream(path));
/* 296 */       ByteArrayOutputStream outArray = new ByteArrayOutputStream();
/* 297 */       BufferedOutputStream outBuffer = new BufferedOutputStream(outArray);
/* 298 */       int piece = 0;
/* 299 */       while ((piece = fileIn.read()) >= 0)
/*     */       {
/* 301 */         outBuffer.write(piece);
/*     */       }
/* 303 */       outBuffer.flush();
/* 304 */       out.setCode(200);
/* 305 */       out.setHeader("Content-type", mime);
/* 306 */       out.sendHeaders();
/* 307 */       if (log.isEnabledFor(10)) log.debug("File output " + mime);
/* 308 */       outArray.writeTo(out);
/* 309 */       fileIn.close();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 313 */       log.warn("Exception loading file " + file, e);
/* 314 */       throw new HttpException(404, "file " + file + " not found");
/*     */     }
/* 316 */     return null;
/*     */   }
/*     */   
/*     */   protected InputStream getInputStream(String path)
/*     */   {
/* 321 */     InputStream file = null;
/* 322 */     if (!this.useJar)
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/* 327 */         file = new FileInputStream(new File(this.root, path));
/*     */       }
/*     */       catch (FileNotFoundException e)
/*     */       {
/* 331 */         Logger log = getLogger();
/* 332 */         log.error("File not found", e);
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/* 338 */       String targetFile = this.path;
/*     */       
/* 340 */       if (path.startsWith("/"))
/*     */       {
/* 342 */         targetFile = targetFile + path;
/*     */       }
/*     */       else
/*     */       {
/* 346 */         targetFile = targetFile + "/" + path;
/*     */       }
/* 348 */       if (this.root != null)
/*     */       {
/* 350 */         file = this.targetClassLoader.getResourceAsStream(targetFile);
/*     */       }
/* 352 */       if (file == null)
/*     */       {
/* 354 */         ClassLoader cl = getClass().getClassLoader();
/* 355 */         if (cl == null)
/*     */         {
/* 357 */           file = ClassLoader.getSystemClassLoader().getResourceAsStream(targetFile);
/*     */         }
/*     */         else
/*     */         {
/* 361 */           file = getClass().getClassLoader().getResourceAsStream(targetFile);
/*     */         }
/* 363 */         file = getClass().getClassLoader().getResourceAsStream(targetFile);
/*     */       }
/*     */     }
/*     */     
/* 367 */     return file;
/*     */   }
/*     */   
/*     */   public Source resolve(String href, String base)
/*     */   {
/* 372 */     StreamSource source = new StreamSource(getInputStream(href));
/*     */     
/* 374 */     source.setSystemId(href);
/* 375 */     return source;
/*     */   }
/*     */   
/*     */   public void setFile(String file)
/*     */   {
/* 380 */     if (file != null)
/*     */     {
/* 382 */       Logger log = getLogger();
/*     */       
/* 384 */       File target = new File(file);
/* 385 */       if (!target.exists())
/*     */       {
/* 387 */         log.warn("Target file " + file + " does not exist, defaulting to previous");
/* 388 */         return;
/*     */       }
/* 390 */       if (target.isDirectory())
/*     */       {
/* 392 */         this.useJar = false;
/* 393 */         if (log.isEnabledFor(10)) log.debug("Using " + file + " as the root dir");
/* 394 */         this.root = target;
/* 395 */         return;
/*     */       }
/* 397 */       if ((target.isFile()) && ((target.getName().endsWith(".jar")) || (target.getName().endsWith(".zip"))))
/*     */       {
/*     */         try
/*     */         {
/*     */ 
/* 402 */           URL url = target.toURL();
/* 403 */           this.targetClassLoader = new URLClassLoader(new URL[] { url });
/* 404 */           if (log.isEnabledFor(10)) log.debug("Using compressed file " + url + " as the root file");
/* 405 */           this.root = target;
/* 406 */           this.useJar = true;
/*     */         }
/*     */         catch (MalformedURLException e)
/*     */         {
/* 410 */           log.warn("Unable to create class loader", e);
/*     */         }
/*     */         
/*     */       }
/*     */       else {
/* 415 */         log.warn("Target file " + file + " does not exist, defaulting to previous");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String getFile()
/*     */   {
/* 422 */     return this.root != null ? this.root.getName() : null;
/*     */   }
/*     */   
/*     */   public String getPathInJar()
/*     */   {
/* 427 */     return this.path;
/*     */   }
/*     */   
/*     */   public void setPathInJar(String path)
/*     */   {
/* 432 */     this.path = path;
/*     */   }
/*     */   
/*     */   public String getDefaultPage()
/*     */   {
/* 437 */     return this.defaultPage;
/*     */   }
/*     */   
/*     */   public void setDefaultPage(String defaultPage)
/*     */   {
/* 442 */     this.defaultPage = defaultPage;
/*     */   }
/*     */   
/*     */   public boolean isUseJar()
/*     */   {
/* 447 */     return this.useJar;
/*     */   }
/*     */   
/*     */   public boolean isUsePath()
/*     */   {
/* 452 */     return !this.useJar;
/*     */   }
/*     */   
/*     */   public void addMimeType(String extension, String type)
/*     */   {
/* 457 */     if ((extension != null) && (type != null))
/*     */     {
/* 459 */       Logger log = getLogger();
/* 460 */       if (log.isEnabledFor(10)) log.debug("Added MIME type " + type + " for extension " + extension);
/* 461 */       this.mimeTypes.put(extension, type);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setUseCache(boolean useCache)
/*     */   {
/* 467 */     this.useCache = useCache;
/*     */   }
/*     */   
/*     */   public boolean isUseCache()
/*     */   {
/* 472 */     return this.useCache;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 477 */     return "XSLT Processor";
/*     */   }
/*     */   
/*     */   public Locale getLocale()
/*     */   {
/* 482 */     return this.locale;
/*     */   }
/*     */   
/*     */   public void setLocale(Locale locale)
/*     */   {
/* 487 */     this.locale = locale;
/*     */   }
/*     */   
/*     */   public void setLocaleString(String locale)
/*     */   {
/* 492 */     if ((locale == null) || (locale.length() == 0))
/*     */     {
/* 494 */       this.locale = new Locale("en", "");
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 499 */       StringTokenizer tknzr = new StringTokenizer(locale, "_");
/* 500 */       String language = tknzr.nextToken();
/* 501 */       String country = "";
/* 502 */       String variant = "";
/* 503 */       if (tknzr.hasMoreTokens())
/* 504 */         country = tknzr.nextToken();
/* 505 */       if (tknzr.hasMoreTokens())
/* 506 */         variant = tknzr.nextToken();
/* 507 */       this.locale = new Locale(language, country, variant);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/XSLTProcessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */