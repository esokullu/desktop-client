/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GetAttributeCommandProcessor
/*     */   extends HttpCommandProcessorAdaptor
/*     */ {
/*     */   public Document executeRequest(HttpInputStream in)
/*     */     throws IOException, JMException
/*     */   {
/*  38 */     Document document = this.builder.newDocument();
/*     */     
/*  40 */     String name = in.getVariable("objectname");
/*  41 */     String attributeVariable = in.getVariable("attribute");
/*  42 */     String formatVariable = in.getVariable("format");
/*  43 */     ObjectName objectName = null;
/*  44 */     MBeanAttributeInfo targetAttribute = null;
/*     */     
/*  46 */     boolean validMBean = false;
/*  47 */     if (name != null)
/*     */     {
/*  49 */       objectName = new ObjectName(name);
/*  50 */       if (this.server.isRegistered(objectName))
/*     */       {
/*  52 */         validMBean = true;
/*     */       }
/*     */     }
/*  55 */     if ((validMBean) && (attributeVariable != null))
/*     */     {
/*  57 */       validMBean = false;
/*  58 */       MBeanInfo info = this.server.getMBeanInfo(objectName);
/*  59 */       MBeanAttributeInfo[] attributes = info.getAttributes();
/*     */       
/*  61 */       if (attributes != null)
/*     */       {
/*  63 */         for (int i = 0; i < attributes.length; i++)
/*     */         {
/*  65 */           if (attributes[i].getName().equals(attributeVariable))
/*     */           {
/*  67 */             targetAttribute = attributes[i];
/*  68 */             validMBean = true;
/*  69 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  74 */     if (validMBean)
/*     */     {
/*  76 */       Element root = document.createElement("MBean");
/*  77 */       document.appendChild(root);
/*     */       
/*  79 */       root.setAttribute("objectname", objectName.toString());
/*  80 */       MBeanInfo info = this.server.getMBeanInfo(objectName);
/*  81 */       root.setAttribute("classname", info.getClassName());
/*  82 */       root.setAttribute("description", info.getDescription());
/*     */       
/*  84 */       Element attribute = document.createElement("Attribute");
/*  85 */       attribute.setAttribute("name", attributeVariable);
/*  86 */       attribute.setAttribute("classname", targetAttribute.getType());
/*  87 */       Object attributeValue = this.server.getAttribute(objectName, attributeVariable);
/*  88 */       attribute.setAttribute("isnull", attributeValue == null ? "true" : "false");
/*  89 */       root.appendChild(attribute);
/*     */       
/*  91 */       if (("array".equals(formatVariable)) && (attributeValue.getClass().isArray()))
/*     */       {
/*  93 */         Element array = document.createElement("Array");
/*  94 */         array.setAttribute("componentclass", attributeValue.getClass().getComponentType().getName());
/*  95 */         int length = Array.getLength(attributeValue);
/*  96 */         array.setAttribute("length", "" + length);
/*  97 */         for (int i = 0; i < length; i++)
/*     */         {
/*  99 */           Element arrayElement = document.createElement("Element");
/* 100 */           arrayElement.setAttribute("index", "" + i);
/* 101 */           if (Array.get(attributeValue, i) != null)
/*     */           {
/* 103 */             arrayElement.setAttribute("element", Array.get(attributeValue, i).toString());
/* 104 */             arrayElement.setAttribute("isnull", "false");
/*     */           }
/*     */           else
/*     */           {
/* 108 */             arrayElement.setAttribute("element", "null");
/* 109 */             arrayElement.setAttribute("isnull", "true");
/*     */           }
/* 111 */           array.appendChild(arrayElement);
/*     */         }
/* 113 */         attribute.appendChild(array);
/*     */       }
/* 115 */       else if (("collection".equals(formatVariable)) && ((attributeValue instanceof Collection)))
/*     */       {
/* 117 */         Collection collection = (Collection)attributeValue;
/* 118 */         Element collectionElement = document.createElement("Collection");
/* 119 */         collectionElement.setAttribute("length", "" + collection.size());
/* 120 */         Iterator i = collection.iterator();
/* 121 */         int j = 0;
/* 122 */         while (i.hasNext())
/*     */         {
/* 124 */           Element collectionEntry = document.createElement("Element");
/* 125 */           collectionEntry.setAttribute("index", "" + j++);
/* 126 */           Object obj = i.next();
/* 127 */           if (obj != null)
/*     */           {
/* 129 */             collectionEntry.setAttribute("elementclass", obj.getClass().getName());
/* 130 */             collectionEntry.setAttribute("element", obj.toString());
/*     */           }
/*     */           else
/*     */           {
/* 134 */             collectionEntry.setAttribute("elementclass", "null");
/* 135 */             collectionEntry.setAttribute("element", "null");
/*     */           }
/* 137 */           collectionElement.appendChild(collectionEntry);
/*     */         }
/* 139 */         attribute.appendChild(collectionElement);
/*     */       }
/* 141 */       else if (("map".equals(formatVariable)) && ((attributeValue instanceof Map)))
/*     */       {
/* 143 */         Map map = (Map)attributeValue;
/* 144 */         Element mapElement = document.createElement("Map");
/* 145 */         mapElement.setAttribute("length", "" + map.size());
/* 146 */         Iterator i = map.keySet().iterator();
/* 147 */         int j = 0;
/* 148 */         while (i.hasNext())
/*     */         {
/* 150 */           Element mapEntry = document.createElement("Element");
/* 151 */           mapEntry.setAttribute("index", "" + j++);
/* 152 */           Object key = i.next();
/* 153 */           Object entry = map.get(key);
/* 154 */           if ((entry != null) && (key != null))
/*     */           {
/* 156 */             mapEntry.setAttribute("keyclass", key.getClass().getName());
/* 157 */             mapEntry.setAttribute("key", key.toString());
/* 158 */             mapEntry.setAttribute("elementclass", entry.getClass().getName());
/* 159 */             mapEntry.setAttribute("element", entry.toString());
/*     */           }
/*     */           else
/*     */           {
/* 163 */             mapEntry.setAttribute("keyclass", "null");
/* 164 */             mapEntry.setAttribute("key", "null");
/* 165 */             mapEntry.setAttribute("elementclass", "null");
/* 166 */             mapEntry.setAttribute("element", "null");
/*     */           }
/* 168 */           mapElement.appendChild(mapEntry);
/*     */         }
/* 170 */         attribute.appendChild(mapElement);
/*     */       }
/*     */       else
/*     */       {
/* 174 */         attribute.setAttribute("value", attributeValue == null ? "null" : attributeValue.toString());
/*     */       }
/*     */     }
/*     */     
/* 178 */     return document;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/GetAttributeCommandProcessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */