/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetAttributeCommandProcessor
/*     */   extends HttpCommandProcessorAdaptor
/*     */ {
/*     */   public Document executeRequest(HttpInputStream in)
/*     */     throws IOException, JMException
/*     */   {
/*  36 */     Document document = this.builder.newDocument();
/*     */     
/*  38 */     Element root = document.createElement("MBeanOperation");
/*  39 */     document.appendChild(root);
/*  40 */     Element operationElement = document.createElement("Operation");
/*  41 */     operationElement.setAttribute("operation", "setattribute");
/*  42 */     root.appendChild(operationElement);
/*     */     
/*  44 */     String objectVariable = in.getVariable("objectname");
/*  45 */     String attributeVariable = in.getVariable("attribute");
/*  46 */     String valueVariable = in.getVariable("value");
/*  47 */     if ((objectVariable == null) || (objectVariable.equals("")) || (attributeVariable == null) || (attributeVariable.equals("")) || (valueVariable == null))
/*     */     {
/*     */ 
/*     */ 
/*  51 */       operationElement.setAttribute("result", "error");
/*  52 */       operationElement.setAttribute("errorMsg", "Incorrect parameters in the request");
/*  53 */       return document;
/*     */     }
/*  55 */     operationElement.setAttribute("objectname", objectVariable);
/*  56 */     ObjectName name = null;
/*     */     try
/*     */     {
/*  59 */       name = new ObjectName(objectVariable);
/*     */     }
/*     */     catch (MalformedObjectNameException e)
/*     */     {
/*  63 */       operationElement.setAttribute("result", "error");
/*  64 */       operationElement.setAttribute("errorMsg", "Malformed object name");
/*  65 */       return document;
/*     */     }
/*     */     
/*  68 */     if (this.server.isRegistered(name))
/*     */     {
/*  70 */       MBeanInfo info = this.server.getMBeanInfo(name);
/*  71 */       MBeanAttributeInfo[] attributes = info.getAttributes();
/*  72 */       MBeanAttributeInfo targetAttribute = null;
/*  73 */       if (attributes != null)
/*     */       {
/*  75 */         for (int i = 0; i < attributes.length; i++)
/*     */         {
/*  77 */           if (attributes[i].getName().equals(attributeVariable))
/*     */           {
/*  79 */             targetAttribute = attributes[i];
/*  80 */             break;
/*     */           }
/*     */         }
/*     */       }
/*  84 */       if (targetAttribute != null)
/*     */       {
/*  86 */         String type = targetAttribute.getType();
/*  87 */         Object value = null;
/*  88 */         if (valueVariable != null)
/*     */         {
/*     */           try
/*     */           {
/*  92 */             value = CommandProcessorUtil.createParameterValue(type, valueVariable);
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/*  96 */             operationElement.setAttribute("result", "error");
/*  97 */             operationElement.setAttribute("errorMsg", "Value: " + valueVariable + " could not be converted to " + type);
/*     */           }
/*  99 */           if (value != null)
/*     */           {
/*     */             try
/*     */             {
/* 103 */               this.server.setAttribute(name, new Attribute(attributeVariable, value));
/* 104 */               operationElement.setAttribute("result", "success");
/*     */             }
/*     */             catch (Exception e)
/*     */             {
/* 108 */               operationElement.setAttribute("result", "error");
/* 109 */               operationElement.setAttribute("errorMsg", e.getMessage());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 116 */         operationElement.setAttribute("result", "error");
/* 117 */         operationElement.setAttribute("errorMsg", "Attribute " + attributeVariable + " not found");
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 122 */     else if (name != null)
/*     */     {
/* 124 */       operationElement.setAttribute("result", "error");
/* 125 */       operationElement.setAttribute("errorMsg", "MBean " + name + " not registered");
/*     */     }
/*     */     
/* 128 */     return document;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/SetAttributeCommandProcessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */