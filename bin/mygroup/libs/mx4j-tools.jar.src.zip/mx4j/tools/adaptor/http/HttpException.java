/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpException
/*     */   extends IOException
/*     */ {
/*     */   protected int code;
/*     */   
/*     */   public HttpException(int code, String description)
/*     */   {
/*  55 */     super(description);
/*     */     
/*  57 */     this.code = code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCode()
/*     */   {
/*  70 */     return this.code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Document getResponseDoc()
/*     */   {
/*     */     try
/*     */     {
/*  82 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*     */       
/*  84 */       DocumentBuilder builder = factory.newDocumentBuilder();
/*     */       
/*  86 */       Document document = builder.newDocument();
/*     */       
/*     */ 
/*  89 */       Element root = document.createElement("HttpException");
/*     */       
/*  91 */       root.setAttribute("code", Integer.toString(this.code));
/*     */       
/*  93 */       root.setAttribute("description", getMessage());
/*     */       
/*  95 */       document.appendChild(root);
/*     */       
/*  97 */       return document;
/*     */     }
/*     */     catch (ParserConfigurationException e) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/HttpException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */