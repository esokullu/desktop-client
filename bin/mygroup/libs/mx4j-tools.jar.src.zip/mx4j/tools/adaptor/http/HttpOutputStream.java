/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpOutputStream
/*     */   extends BufferedOutputStream
/*     */ {
/*     */   protected int code;
/*     */   protected boolean sendHeaders;
/*  55 */   protected Map headers = new HashMap(7);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpOutputStream(OutputStream out, HttpInputStream in)
/*     */   {
/*  71 */     super(out);
/*     */     
/*  73 */     this.code = 200;
/*     */     
/*  75 */     setHeader("Server", "MX4J-HTTPD/1.0");
/*     */     
/*  77 */     this.sendHeaders = (in.getVersion() >= 1.0D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCode(int code)
/*     */   {
/*  92 */     this.code = code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeader(String attr, String value)
/*     */   {
/* 108 */     this.headers.put(attr, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean sendHeaders()
/*     */     throws IOException
/*     */   {
/* 124 */     if (this.sendHeaders)
/*     */     {
/*     */ 
/*     */ 
/* 128 */       StringBuffer buffer = new StringBuffer(512);
/*     */       
/* 130 */       buffer.append("HTTP/1.0 ");
/*     */       
/* 132 */       buffer.append(this.code);
/*     */       
/* 134 */       buffer.append(" ");
/*     */       
/* 136 */       buffer.append(HttpUtil.getCodeMessage(this.code));
/*     */       
/* 138 */       buffer.append("\r\n");
/*     */       
/* 140 */       Iterator attrs = this.headers.keySet().iterator();
/*     */       
/* 142 */       int size = this.headers.size();
/*     */       
/*     */ 
/* 145 */       for (int i = 0; i < size; i++)
/*     */       {
/*     */ 
/*     */ 
/* 149 */         String attr = (String)attrs.next();
/*     */         
/* 151 */         buffer.append(attr);
/*     */         
/* 153 */         buffer.append(": ");
/*     */         
/* 155 */         buffer.append(this.headers.get(attr));
/*     */         
/* 157 */         buffer.append("\r\n");
/*     */       }
/*     */       
/*     */ 
/* 161 */       buffer.append("\r\n");
/*     */       
/* 163 */       write(buffer.toString());
/*     */     }
/*     */     
/*     */ 
/* 167 */     return this.sendHeaders;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(String msg)
/*     */     throws IOException
/*     */   {
/* 183 */     write(msg.getBytes("latin1"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(InputStream in)
/*     */     throws IOException
/*     */   {
/* 201 */     int length = this.buf.length;
/*     */     int n;
/* 203 */     while ((n = in.read(this.buf, this.count, length - this.count)) >= 0)
/*     */     {
/*     */ 
/*     */ 
/* 207 */       if (this.count += n >= length)
/*     */       {
/*     */ 
/*     */ 
/* 211 */         this.out.write(this.buf, this.count = 0, length);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/HttpOutputStream.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */