/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetAttributesCommandProcessor
/*     */   extends HttpCommandProcessorAdaptor
/*     */ {
/*     */   public Document executeRequest(HttpInputStream in)
/*     */     throws IOException, JMException
/*     */   {
/*  42 */     Document document = this.builder.newDocument();
/*     */     
/*  44 */     Element root = document.createElement("MBeanOperation");
/*  45 */     document.appendChild(root);
/*  46 */     Element operationElement = document.createElement("Operation");
/*  47 */     operationElement.setAttribute("operation", "setattributes");
/*  48 */     root.appendChild(operationElement);
/*     */     
/*  50 */     String objectVariable = in.getVariable("objectname");
/*  51 */     if ((objectVariable == null) || (objectVariable.equals("")))
/*     */     {
/*  53 */       operationElement.setAttribute("result", "error");
/*  54 */       operationElement.setAttribute("errorMsg", "Missing objectname in the request");
/*  55 */       return document;
/*     */     }
/*  57 */     operationElement.setAttribute("objectname", objectVariable);
/*  58 */     ObjectName name = null;
/*     */     try
/*     */     {
/*  61 */       name = new ObjectName(objectVariable);
/*     */     }
/*     */     catch (MalformedObjectNameException e)
/*     */     {
/*  65 */       operationElement.setAttribute("result", "error");
/*  66 */       operationElement.setAttribute("errorMsg", "Malformed object name");
/*  67 */       return document;
/*     */     }
/*  69 */     if (this.server.isRegistered(name))
/*     */     {
/*  71 */       Map variables = in.getVariables();
/*  72 */       if (variables.containsKey("setall"))
/*     */       {
/*  74 */         Iterator keys = variables.keySet().iterator();
/*  75 */         SortedMap allAttributes = new TreeMap();
/*  76 */         while (keys.hasNext())
/*     */         {
/*  78 */           String key = (String)keys.next();
/*  79 */           if (key.startsWith("value_"))
/*     */           {
/*  81 */             String attributeVariable = key.substring(6, key.length());
/*  82 */             String valueVariable = in.getVariable(key);
/*  83 */             Element attributeElement = setAttribute(document, attributeVariable, valueVariable, name);
/*  84 */             allAttributes.put(attributeVariable, attributeElement);
/*  85 */             operationElement.appendChild(attributeElement);
/*     */           }
/*     */         }
/*  88 */         keys = allAttributes.keySet().iterator();
/*  89 */         while (keys.hasNext())
/*     */         {
/*  91 */           Element attributeElement = (Element)allAttributes.get(keys.next());
/*  92 */           operationElement.appendChild(attributeElement);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  97 */         Iterator keys = variables.keySet().iterator();
/*  98 */         SortedMap allAttributes = new TreeMap();
/*  99 */         while (keys.hasNext())
/*     */         {
/* 101 */           String key = (String)keys.next();
/* 102 */           if (key.startsWith("set_"))
/*     */           {
/* 104 */             String attributeVariable = key.substring(4, key.length());
/* 105 */             String valueVariable = in.getVariable("value_" + attributeVariable);
/* 106 */             Element attributeElement = setAttribute(document, attributeVariable, valueVariable, name);
/* 107 */             allAttributes.put(attributeVariable, attributeElement);
/*     */           }
/*     */         }
/* 110 */         keys = allAttributes.keySet().iterator();
/* 111 */         while (keys.hasNext())
/*     */         {
/* 113 */           Element attributeElement = (Element)allAttributes.get(keys.next());
/* 114 */           operationElement.appendChild(attributeElement);
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 121 */     else if (name != null)
/*     */     {
/* 123 */       operationElement.setAttribute("result", "error");
/* 124 */       operationElement.setAttribute("errorMsg", "MBean " + name + " not registered");
/*     */     }
/*     */     
/* 127 */     return document;
/*     */   }
/*     */   
/*     */   private Element setAttribute(Document document, String attributeVariable, String valueVariable, ObjectName name) throws JMException
/*     */   {
/* 132 */     Element attributeElement = document.createElement("Attribute");
/* 133 */     attributeElement.setAttribute("attribute", attributeVariable);
/* 134 */     MBeanInfo info = this.server.getMBeanInfo(name);
/* 135 */     MBeanAttributeInfo[] attributes = info.getAttributes();
/* 136 */     MBeanAttributeInfo targetAttribute = null;
/* 137 */     if (attributes != null)
/*     */     {
/* 139 */       for (int i = 0; i < attributes.length; i++)
/*     */       {
/* 141 */         if (attributes[i].getName().equals(attributeVariable))
/*     */         {
/* 143 */           targetAttribute = attributes[i];
/* 144 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 148 */     if (targetAttribute != null)
/*     */     {
/* 150 */       String type = targetAttribute.getType();
/* 151 */       Object value = null;
/* 152 */       if (valueVariable != null)
/*     */       {
/*     */         try
/*     */         {
/* 156 */           value = CommandProcessorUtil.createParameterValue(type, valueVariable);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 160 */           attributeElement.setAttribute("result", "error");
/* 161 */           attributeElement.setAttribute("errorMsg", "Value: " + valueVariable + " could not be converted to " + type);
/*     */         }
/* 163 */         if (value != null)
/*     */         {
/*     */           try
/*     */           {
/* 167 */             this.server.setAttribute(name, new Attribute(attributeVariable, value));
/* 168 */             attributeElement.setAttribute("result", "success");
/* 169 */             attributeElement.setAttribute("value", valueVariable);
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 173 */             attributeElement.setAttribute("result", "error");
/* 174 */             attributeElement.setAttribute("errorMsg", e.getMessage());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 181 */       attributeElement.setAttribute("result", "error");
/* 182 */       attributeElement.setAttribute("errorMsg", "Attribute " + attributeVariable + " not found");
/*     */     }
/* 184 */     return attributeElement;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/SetAttributesCommandProcessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */