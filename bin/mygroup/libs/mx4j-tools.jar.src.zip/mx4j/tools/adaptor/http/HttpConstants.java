package mx4j.tools.adaptor.http;

public class HttpConstants
{
  public static final String SERVER_INFO = "MX4J-HTTPD/1.0";
  public static final String HTTP_VERSION = "HTTP/1.0 ";
  public static final String METHOD_GET = "GET";
  public static final String METHOD_POST = "POST";
  public static final int STATUS_OKAY = 200;
  public static final int STATUS_NO_CONTENT = 204;
  public static final int STATUS_MOVED_PERMANENTLY = 301;
  public static final int STATUS_MOVED_TEMPORARILY = 302;
  public static final int STATUS_BAD_REQUEST = 400;
  public static final int STATUS_AUTHENTICATE = 401;
  public static final int STATUS_FORBIDDEN = 403;
  public static final int STATUS_NOT_FOUND = 404;
  public static final int STATUS_NOT_ALLOWED = 405;
  public static final int STATUS_INTERNAL_ERROR = 500;
  public static final int STATUS_NOT_IMPLEMENTED = 501;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/HttpConstants.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */