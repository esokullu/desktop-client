/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CreateMBeanCommandProcessor
/*     */   extends HttpCommandProcessorAdaptor
/*     */ {
/*     */   public Document executeRequest(HttpInputStream in)
/*     */     throws IOException, JMException
/*     */   {
/*  40 */     Document document = this.builder.newDocument();
/*     */     
/*  42 */     Element root = document.createElement("MBeanOperation");
/*  43 */     document.appendChild(root);
/*  44 */     Element operationElement = document.createElement("Operation");
/*  45 */     operationElement.setAttribute("name", "create");
/*  46 */     root.appendChild(operationElement);
/*     */     
/*  48 */     String objectVariable = in.getVariable("objectname");
/*  49 */     String classVariable = in.getVariable("class");
/*  50 */     if ((objectVariable == null) || (objectVariable.equals("")) || (classVariable == null) || (classVariable.equals("")))
/*     */     {
/*     */ 
/*  53 */       operationElement.setAttribute("result", "error");
/*  54 */       operationElement.setAttribute("errorMsg", "Incorrect parameters in the request");
/*  55 */       return document;
/*     */     }
/*  57 */     operationElement.setAttribute("objectname", objectVariable);
/*  58 */     List types = new ArrayList();
/*  59 */     List values = new ArrayList();
/*  60 */     int i = 0;
/*  61 */     boolean unmatchedParameters = false;
/*  62 */     boolean valid = false;
/*     */     do
/*     */     {
/*  65 */       String parameterType = in.getVariable("type" + i);
/*  66 */       String parameterValue = in.getVariable("value" + i);
/*  67 */       valid = (parameterType != null) && (parameterValue != null);
/*  68 */       if (valid)
/*     */       {
/*  70 */         types.add(parameterType);
/*  71 */         Object value = null;
/*     */         try
/*     */         {
/*  74 */           value = CommandProcessorUtil.createParameterValue(parameterType, parameterValue);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*  78 */           operationElement.setAttribute("result", "error");
/*  79 */           operationElement.setAttribute("errorMsg", "Parameter " + i + ": " + parameterValue + " cannot be converted to type " + parameterType);
/*  80 */           return document;
/*     */         }
/*  82 */         if (value != null)
/*     */         {
/*  84 */           values.add(value);
/*     */         }
/*     */       }
/*  87 */       if (((parameterType == null ? 1 : 0) ^ (parameterValue == null ? 1 : 0)) != 0)
/*     */       {
/*  89 */         unmatchedParameters = true;
/*  90 */         break;
/*     */       }
/*  92 */       i++;
/*     */     }
/*  94 */     while (valid);
/*  95 */     if ((objectVariable == null) || (objectVariable.equals("")))
/*     */     {
/*  97 */       operationElement.setAttribute("result", "error");
/*  98 */       operationElement.setAttribute("errorMsg", "Incorrect parameters in the request");
/*  99 */       return document;
/*     */     }
/* 101 */     if (unmatchedParameters)
/*     */     {
/* 103 */       operationElement.setAttribute("result", "error");
/* 104 */       operationElement.setAttribute("errorMsg", "count of parameter types doesn't match count of parameter values");
/* 105 */       return document;
/*     */     }
/* 107 */     ObjectName name = null;
/*     */     try
/*     */     {
/* 110 */       name = new ObjectName(objectVariable);
/*     */     }
/*     */     catch (MalformedObjectNameException e)
/*     */     {
/* 114 */       operationElement.setAttribute("result", "error");
/* 115 */       operationElement.setAttribute("errorMsg", "Malformed object name");
/* 116 */       return document;
/*     */     }
/*     */     
/* 119 */     if (this.server.isRegistered(name))
/*     */     {
/* 121 */       operationElement.setAttribute("result", "error");
/* 122 */       operationElement.setAttribute("errorMsg", "A MBean with name " + name + " is already registered");
/* 123 */       return document;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 129 */       if (types.size() > 0)
/*     */       {
/* 131 */         Object[] params = values.toArray();
/* 132 */         String[] signature = new String[types.size()];
/* 133 */         types.toArray(signature);
/* 134 */         this.server.createMBean(classVariable, name, null, params, signature);
/*     */       }
/*     */       else
/*     */       {
/* 138 */         this.server.createMBean(classVariable, name, null);
/*     */       }
/* 140 */       operationElement.setAttribute("result", "success");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 144 */       operationElement.setAttribute("result", "error");
/* 145 */       operationElement.setAttribute("errorMsg", e.getMessage());
/*     */     }
/*     */     
/* 148 */     return document;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/CreateMBeanCommandProcessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */