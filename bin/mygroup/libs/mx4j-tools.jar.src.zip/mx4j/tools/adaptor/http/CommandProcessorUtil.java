/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.util.Comparator;
/*     */ import java.util.Date;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.openmbean.OpenType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommandProcessorUtil
/*     */ {
/*  28 */   private static final DateFormat[] allFormats = {
/*  29 */     DateFormat.getDateInstance(), 
/*  30 */     DateFormat.getTimeInstance(), 
/*  31 */     DateFormat.getDateTimeInstance(), 
/*     */     
/*  33 */     DateFormat.getDateInstance(3), 
/*  34 */     DateFormat.getDateInstance(2), 
/*  35 */     DateFormat.getDateInstance(1), 
/*  36 */     DateFormat.getDateInstance(0), 
/*     */     
/*  38 */     DateFormat.getTimeInstance(3), 
/*  39 */     DateFormat.getTimeInstance(2), 
/*  40 */     DateFormat.getTimeInstance(1), 
/*  41 */     DateFormat.getTimeInstance(0), 
/*     */     
/*  43 */     DateFormat.getDateTimeInstance(3, 3), 
/*  44 */     DateFormat.getDateTimeInstance(3, 2), 
/*  45 */     DateFormat.getDateTimeInstance(3, 1), 
/*  46 */     DateFormat.getDateTimeInstance(3, 0), 
/*     */     
/*  48 */     DateFormat.getDateTimeInstance(2, 3), 
/*  49 */     DateFormat.getDateTimeInstance(2, 2), 
/*  50 */     DateFormat.getDateTimeInstance(2, 1), 
/*  51 */     DateFormat.getDateTimeInstance(2, 0), 
/*     */     
/*  53 */     DateFormat.getDateTimeInstance(1, 3), 
/*  54 */     DateFormat.getDateTimeInstance(1, 2), 
/*  55 */     DateFormat.getDateTimeInstance(1, 1), 
/*  56 */     DateFormat.getDateTimeInstance(1, 0), 
/*     */     
/*  58 */     DateFormat.getDateTimeInstance(0, 3), 
/*  59 */     DateFormat.getDateTimeInstance(0, 2), 
/*  60 */     DateFormat.getDateTimeInstance(0, 1), 
/*  61 */     DateFormat.getDateTimeInstance(0, 0) };
/*     */   
/*     */ 
/*  64 */   private static final String[] BASIC_TYPES = {
/*  65 */     "int", "long", "short", "byte", "float", "double", "boolean" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static Object createParameterValue(String parameterType, String parameterValue)
/*     */     throws Exception
/*     */   {
/*  80 */     if (parameterType.equals("java.lang.String"))
/*     */     {
/*  82 */       return parameterValue;
/*     */     }
/*  84 */     if ((parameterType.equals("java.lang.Integer")) || (parameterType.equals("int")))
/*     */     {
/*  86 */       parameterValue = (parameterValue == null) || (parameterValue.trim().length() == 0) ? "0" : parameterValue;
/*  87 */       return Integer.valueOf(parameterValue);
/*     */     }
/*  89 */     if ((parameterType.equals("java.lang.Long")) || (parameterType.equals("long")))
/*     */     {
/*  91 */       parameterValue = (parameterValue == null) || (parameterValue.trim().length() == 0) ? "0" : parameterValue;
/*  92 */       return Long.valueOf(parameterValue);
/*     */     }
/*  94 */     if ((parameterType.equals("java.lang.Short")) || (parameterType.equals("short")))
/*     */     {
/*  96 */       parameterValue = (parameterValue == null) || (parameterValue.trim().length() == 0) ? "0" : parameterValue;
/*  97 */       return Short.valueOf(parameterValue);
/*     */     }
/*  99 */     if ((parameterType.equals("java.lang.Byte")) || (parameterType.equals("byte")))
/*     */     {
/* 101 */       parameterValue = (parameterValue == null) || (parameterValue.trim().length() == 0) ? "0" : parameterValue;
/* 102 */       return Byte.valueOf(parameterValue);
/*     */     }
/* 104 */     if ((parameterType.equals("java.lang.Float")) || (parameterType.equals("float")))
/*     */     {
/* 106 */       parameterValue = (parameterValue == null) || (parameterValue.trim().length() == 0) ? "0" : parameterValue;
/* 107 */       return Float.valueOf(parameterValue);
/*     */     }
/*     */     
/* 110 */     if ((parameterType.equals("java.lang.Double")) || (parameterType.equals("double")))
/*     */     {
/* 112 */       parameterValue = (parameterValue == null) || (parameterValue.trim().length() == 0) ? "0" : parameterValue;
/* 113 */       return Double.valueOf(parameterValue);
/*     */     }
/* 115 */     if ((parameterType.equals("java.lang.Boolean")) || (parameterType.equals("boolean")))
/*     */     {
/* 117 */       parameterValue = (parameterValue == null) || (parameterValue.trim().length() == 0) ? "0" : parameterValue;
/* 118 */       return Boolean.valueOf(parameterValue);
/*     */     }
/* 120 */     if (parameterType.equals("java.lang.Void"))
/*     */     {
/* 122 */       return Void.TYPE;
/*     */     }
/* 124 */     if (parameterType.equals("java.util.Date"))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 129 */       Date value = null;
/* 130 */       for (int i = 0; i < allFormats.length; i++)
/*     */       {
/* 132 */         synchronized (allFormats[i])
/*     */         {
/*     */           try
/*     */           {
/* 136 */             System.out.println(parameterValue + " " + allFormats[i]);
/* 137 */             value = allFormats[i].parse(parameterValue);
/*     */           }
/*     */           catch (ParseException localParseException) {}
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 147 */       if (value == null)
/*     */       {
/* 149 */         throw new ParseException("Not possible to parse", 0);
/*     */       }
/* 151 */       return value;
/*     */     }
/* 153 */     if (parameterType.equals("java.lang.Number"))
/*     */     {
/* 155 */       Number value = null;
/*     */       
/*     */       try
/*     */       {
/* 159 */         parameterValue = (parameterValue == null) || (parameterValue.trim().length() == 0) ? "0" : parameterValue;
/* 160 */         value = Long.valueOf(parameterValue);
/*     */       }
/*     */       catch (NumberFormatException localNumberFormatException) {}
/*     */       
/*     */ 
/*     */ 
/* 166 */       if (value == null)
/*     */       {
/*     */         try
/*     */         {
/* 170 */           value = Double.valueOf(parameterValue);
/*     */         }
/*     */         catch (NumberFormatException localNumberFormatException1) {}
/*     */       }
/*     */       
/*     */ 
/* 176 */       if (value == null)
/*     */       {
/* 178 */         throw new NumberFormatException("Not possible to parse");
/*     */       }
/* 180 */       return value;
/*     */     }
/* 182 */     if ((parameterType.equals("java.lang.Character")) || (parameterType.equals("char")))
/*     */     {
/* 184 */       if (parameterValue.length() > 0)
/*     */       {
/* 186 */         return new Character(parameterValue.charAt(0));
/*     */       }
/*     */       
/*     */ 
/* 190 */       throw new NumberFormatException("Can not initialize Character from empty String");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 199 */     Class cls = null;
/* 200 */     Constructor ctor = null;
/*     */     try
/*     */     {
/* 203 */       cls = Class.forName(parameterType);
/* 204 */       ctor = cls.getConstructor(new Class[] { String.class });
/* 205 */       return ctor.newInstance(new Object[] { parameterValue });
/*     */ 
/*     */     }
/*     */     catch (ClassNotFoundException cnfe)
/*     */     {
/*     */ 
/* 211 */       throw new IllegalArgumentException("Invalid parameter type: " + parameterType);
/*     */ 
/*     */     }
/*     */     catch (NoSuchMethodException nsme)
/*     */     {
/* 216 */       throw new IllegalArgumentException("Invalid parameter type: " + parameterType);
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */ 
/*     */ 
/* 225 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static boolean canCreateParameterValue(String parameterType)
/*     */   {
/* 240 */     int count = OpenType.ALLOWED_CLASSNAMES.length;
/* 241 */     for (int i = 0; i < count; i++)
/*     */     {
/* 243 */       if (OpenType.ALLOWED_CLASSNAMES[i].equals(parameterType))
/*     */       {
/* 245 */         return true;
/*     */       }
/*     */     }
/* 248 */     count = BASIC_TYPES.length;
/* 249 */     for (int i = 0; i < count; i++)
/*     */     {
/* 251 */       if (BASIC_TYPES[i].equals(parameterType))
/*     */       {
/* 253 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 257 */     Class cls = null;
/*     */     try
/*     */     {
/* 260 */       cls = Class.forName(parameterType);
/* 261 */       cls.getConstructor(new Class[] { String.class });
/*     */       
/* 263 */       return true;
/*     */ 
/*     */     }
/*     */     catch (ClassNotFoundException cnfe)
/*     */     {
/*     */ 
/* 269 */       return false;
/*     */ 
/*     */     }
/*     */     catch (NoSuchMethodException nsme)
/*     */     {
/* 274 */       return false;
/*     */     }
/*     */     catch (Exception ex) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 283 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public static Comparator createObjectNameComparator()
/*     */   {
/* 289 */     return new ToStringComparator();
/*     */   }
/*     */   
/*     */   public static Comparator createObjectInstanceComparator()
/*     */   {
/* 294 */     return new ObjectInstanceComparator();
/*     */   }
/*     */   
/*     */   public static Comparator createConstructorComparator()
/*     */   {
/* 299 */     return new ConstructorComparator();
/*     */   }
/*     */   
/*     */   public static Comparator createClassComparator()
/*     */   {
/* 304 */     return new ToStringComparator();
/*     */   }
/*     */   
/*     */   private static class ToStringComparator implements Comparator
/*     */   {
/*     */     public int compare(Object o1, Object o2)
/*     */     {
/* 311 */       return o1.toString().compareTo(o2.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ObjectInstanceComparator implements Comparator
/*     */   {
/* 317 */     private CommandProcessorUtil.ToStringComparator comp = new CommandProcessorUtil.ToStringComparator();
/*     */     
/*     */     public int compare(Object o1, Object o2)
/*     */     {
/* 321 */       ObjectInstance oi1 = (ObjectInstance)o1;
/* 322 */       ObjectInstance oi2 = (ObjectInstance)o2;
/* 323 */       return this.comp.compare(oi1.getObjectName(), oi2.getObjectName());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ConstructorComparator implements Comparator
/*     */   {
/*     */     public int compare(Object o1, Object o2)
/*     */     {
/* 331 */       Constructor c1 = (Constructor)o1;
/* 332 */       Constructor c2 = (Constructor)o2;
/*     */       
/* 334 */       Class[] params1 = c1.getParameterTypes();
/* 335 */       Class[] params2 = c2.getParameterTypes();
/* 336 */       if (params1.length == params2.length)
/*     */       {
/* 338 */         for (int i = 0; i < params1.length; i++)
/*     */         {
/* 340 */           if (!params1[i].equals(params2[i]))
/*     */           {
/* 342 */             return params2[i].toString().compareTo(params1[i].toString());
/*     */           }
/*     */         }
/* 345 */         return 0;
/*     */       }
/*     */       
/*     */ 
/* 349 */       return params1.length - params2.length;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/CommandProcessorUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */