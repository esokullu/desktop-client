/*    */ package mx4j.tools.adaptor.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.JMException;
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptyCommandProcessor
/*    */   extends HttpCommandProcessorAdaptor
/*    */ {
/*    */   public Document executeRequest(HttpInputStream in)
/*    */     throws IOException, JMException
/*    */   {
/* 35 */     Document document = this.builder.newDocument();
/*    */     
/* 37 */     Element root = document.createElement("empty");
/* 38 */     document.appendChild(root);
/*    */     
/* 40 */     return document;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/EmptyCommandProcessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */