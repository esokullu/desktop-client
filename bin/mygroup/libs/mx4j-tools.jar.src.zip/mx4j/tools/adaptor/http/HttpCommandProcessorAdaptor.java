/*    */ package mx4j.tools.adaptor.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.JMException;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import org.w3c.dom.Document;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class HttpCommandProcessorAdaptor
/*    */   implements HttpCommandProcessor
/*    */ {
/*    */   protected MBeanServer server;
/*    */   protected DocumentBuilder builder;
/*    */   
/*    */   public abstract Document executeRequest(HttpInputStream paramHttpInputStream)
/*    */     throws IOException, JMException;
/*    */   
/*    */   public void setMBeanServer(MBeanServer server)
/*    */   {
/* 36 */     this.server = server;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setDocumentBuilder(DocumentBuilder builder)
/*    */   {
/* 44 */     this.builder = builder;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/HttpCommandProcessorAdaptor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */