/*    */ package mx4j.tools.adaptor.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.management.JMException;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.MalformedObjectNameException;
/*    */ import javax.management.ObjectName;
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeleteMBeanCommandProcessor
/*    */   extends HttpCommandProcessorAdaptor
/*    */ {
/*    */   public Document executeRequest(HttpInputStream in)
/*    */     throws IOException, JMException
/*    */   {
/* 34 */     Document document = this.builder.newDocument();
/*    */     
/* 36 */     Element root = document.createElement("MBeanOperation");
/* 37 */     document.appendChild(root);
/* 38 */     Element operationElement = document.createElement("Operation");
/* 39 */     operationElement.setAttribute("operation", "delete");
/* 40 */     root.appendChild(operationElement);
/*    */     
/* 42 */     String objectVariable = in.getVariable("objectname");
/* 43 */     operationElement.setAttribute("objectname", objectVariable);
/* 44 */     if ((objectVariable == null) || (objectVariable.equals("")))
/*    */     {
/* 46 */       operationElement.setAttribute("result", "error");
/* 47 */       operationElement.setAttribute("errorMsg", "Incorrect parameters in the request");
/* 48 */       return document;
/*    */     }
/* 50 */     ObjectName name = null;
/*    */     try
/*    */     {
/* 53 */       name = new ObjectName(objectVariable);
/*    */     }
/*    */     catch (MalformedObjectNameException e)
/*    */     {
/* 57 */       operationElement.setAttribute("result", "error");
/* 58 */       operationElement.setAttribute("errorMsg", "Malformed object name");
/* 59 */       return document;
/*    */     }
/*    */     
/* 62 */     if (this.server.isRegistered(name))
/*    */     {
/*    */       try
/*    */       {
/* 66 */         this.server.unregisterMBean(name);
/* 67 */         operationElement.setAttribute("result", "success");
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 71 */         operationElement.setAttribute("result", "error");
/* 72 */         operationElement.setAttribute("errorMsg", e.getMessage());
/*    */       }
/*    */       
/*    */ 
/*    */     }
/* 77 */     else if (name != null)
/*    */     {
/* 79 */       operationElement.setAttribute("result", "error");
/* 80 */       operationElement.setAttribute("errorMsg", "MBean " + name + " not registered");
/*    */     }
/*    */     
/* 83 */     return document;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/DeleteMBeanCommandProcessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */