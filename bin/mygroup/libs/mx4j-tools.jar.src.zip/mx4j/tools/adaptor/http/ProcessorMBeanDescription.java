/*    */ package mx4j.tools.adaptor.http;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import mx4j.MBeanDescriptionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProcessorMBeanDescription
/*    */   extends MBeanDescriptionAdapter
/*    */ {
/*    */   public String getAttributeDescription(String attribute)
/*    */   {
/* 24 */     if (attribute.equals("Name"))
/*    */     {
/* 26 */       return "Name of the ProcessorMBean";
/*    */     }
/* 28 */     return super.getAttributeDescription(attribute);
/*    */   }
/*    */   
/*    */   public String getOperationDescription(Method operation)
/*    */   {
/* 33 */     if (operation.getName().equals("writeResponse"))
/*    */     {
/* 35 */       return "The method process a xml result document into a suitable response";
/*    */     }
/* 37 */     if (operation.getName().equals("writeError"))
/*    */     {
/* 39 */       return "The method process a xml error into a suitable response";
/*    */     }
/* 41 */     if (operation.getName().equals("preProcess"))
/*    */     {
/* 43 */       return "Processes paths allowing for the replacement of a certain path with another";
/*    */     }
/* 45 */     if (operation.getName().equals("notFoundElement"))
/*    */     {
/* 47 */       return "Method invoked when a path is not found";
/*    */     }
/* 49 */     return super.getOperationDescription(operation);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/ProcessorMBeanDescription.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */