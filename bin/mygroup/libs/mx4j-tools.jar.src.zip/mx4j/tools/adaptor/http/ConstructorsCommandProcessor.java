/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Arrays;
/*     */ import javax.management.JMException;
/*     */ import javax.management.loading.DefaultLoaderRepository;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstructorsCommandProcessor
/*     */   extends HttpCommandProcessorAdaptor
/*     */ {
/*     */   public Document executeRequest(HttpInputStream in)
/*     */     throws IOException, JMException
/*     */   {
/*  33 */     Document document = this.builder.newDocument();
/*     */     
/*  35 */     String classname = in.getVariable("classname");
/*  36 */     if ((classname == null) || (classname.trim().length() == 0))
/*     */     {
/*  38 */       return createException(document, "", "classname parameter required");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  43 */     Class targetClass = null;
/*     */     try
/*     */     {
/*  46 */       targetClass = DefaultLoaderRepository.loadClass(classname);
/*     */     }
/*     */     catch (ClassNotFoundException e) {}
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  53 */       if (targetClass == null)
/*     */       {
/*  55 */         targetClass = ClassLoader.getSystemClassLoader().loadClass(classname);
/*     */       }
/*     */     }
/*     */     catch (ClassNotFoundException e) {}
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  63 */       if (targetClass == null)
/*     */       {
/*  65 */         targetClass = getClass().getClassLoader().loadClass(classname);
/*     */       }
/*     */     }
/*     */     catch (ClassNotFoundException e) {}
/*     */     
/*     */ 
/*     */ 
/*  72 */     if (targetClass == null)
/*     */     {
/*  74 */       return createException(document, classname, "class " + classname + " not found");
/*     */     }
/*     */     
/*  77 */     Element root = document.createElement("Class");
/*  78 */     root.setAttribute("classname", classname);
/*  79 */     document.appendChild(root);
/*  80 */     Constructor[] constructors = targetClass.getConstructors();
/*  81 */     Arrays.sort(constructors, CommandProcessorUtil.createConstructorComparator());
/*  82 */     for (int i = 0; i < constructors.length; i++)
/*     */     {
/*  84 */       System.out.println("Constructor " + constructors[i]);
/*  85 */       Element constructor = document.createElement("Constructor");
/*  86 */       constructor.setAttribute("name", constructors[i].getName());
/*  87 */       addParameters(constructor, document, constructors[i].getParameterTypes());
/*  88 */       root.appendChild(constructor);
/*     */     }
/*     */     
/*  91 */     return document;
/*     */   }
/*     */   
/*     */   protected void addParameters(Element node, Document document, Class[] parameters)
/*     */   {
/*  96 */     for (int j = 0; j < parameters.length; j++)
/*     */     {
/*  98 */       Element parameter = document.createElement("Parameter");
/*  99 */       parameter.setAttribute("type", parameters[j].getName());
/* 100 */       parameter.setAttribute("strinit", String.valueOf(CommandProcessorUtil.canCreateParameterValue(parameters[j].getName())));
/*     */       
/* 102 */       parameter.setAttribute("id", "" + j);
/* 103 */       node.appendChild(parameter);
/*     */     }
/*     */   }
/*     */   
/*     */   private Document createException(Document document, String classname, String message)
/*     */   {
/* 109 */     Element exceptionElement = document.createElement("Exception");
/* 110 */     document.appendChild(exceptionElement);
/* 111 */     exceptionElement.setAttribute("classname", classname);
/* 112 */     exceptionElement.setAttribute("errorMsg", message);
/* 113 */     return document;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/ConstructorsCommandProcessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */