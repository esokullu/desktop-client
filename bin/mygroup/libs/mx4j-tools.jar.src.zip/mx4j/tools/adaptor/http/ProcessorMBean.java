package mx4j.tools.adaptor.http;

import java.io.IOException;
import org.w3c.dom.Document;

public abstract interface ProcessorMBean
{
  public abstract String getName();
  
  public abstract void writeResponse(HttpOutputStream paramHttpOutputStream, HttpInputStream paramHttpInputStream, Document paramDocument)
    throws IOException;
  
  public abstract void writeError(HttpOutputStream paramHttpOutputStream, HttpInputStream paramHttpInputStream, Exception paramException)
    throws IOException;
  
  public abstract String preProcess(String paramString);
  
  public abstract String notFoundElement(String paramString, HttpOutputStream paramHttpOutputStream, HttpInputStream paramHttpInputStream)
    throws IOException, HttpException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/ProcessorMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */