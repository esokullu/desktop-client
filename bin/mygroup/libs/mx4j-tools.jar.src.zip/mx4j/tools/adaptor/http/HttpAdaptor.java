/*      */ package mx4j.tools.adaptor.http;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InterruptedIOException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.net.ServerSocket;
/*      */ import java.net.Socket;
/*      */ import java.security.Security;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.management.JMException;
/*      */ import javax.management.MBeanRegistration;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.MalformedObjectNameException;
/*      */ import javax.management.ObjectName;
/*      */ import javax.security.auth.Subject;
/*      */ import javax.security.auth.callback.Callback;
/*      */ import javax.security.auth.callback.CallbackHandler;
/*      */ import javax.security.auth.callback.NameCallback;
/*      */ import javax.security.auth.callback.PasswordCallback;
/*      */ import javax.security.auth.callback.UnsupportedCallbackException;
/*      */ import javax.security.auth.login.Configuration;
/*      */ import javax.security.auth.login.LoginContext;
/*      */ import javax.security.auth.login.LoginException;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import mx4j.log.Log;
/*      */ import mx4j.log.Logger;
/*      */ import mx4j.tools.adaptor.AdaptorServerSocketFactory;
/*      */ import mx4j.tools.adaptor.PlainAdaptorServerSocketFactory;
/*      */ import mx4j.util.Base64Codec;
/*      */ import org.w3c.dom.Document;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HttpAdaptor
/*      */   implements HttpAdaptorMBean, MBeanRegistration
/*      */ {
/*      */   private static final String VERSION = "2.1.0";
/*   54 */   private int port = 8080;
/*      */   
/*      */ 
/*   57 */   private String host = "localhost";
/*      */   
/*      */ 
/*      */   private MBeanServer server;
/*      */   
/*      */ 
/*      */   private ServerSocket serverSocket;
/*      */   
/*      */ 
/*      */   private boolean alive;
/*      */   
/*      */ 
/*   69 */   private Map commands = new HashMap();
/*      */   
/*      */ 
/*   72 */   private ProcessorMBean processor = null;
/*      */   
/*      */ 
/*   75 */   private ObjectName processorName = null;
/*      */   
/*      */ 
/*   78 */   private ProcessorMBean defaultProcessor = new DefaultProcessor();
/*      */   
/*   80 */   private String authenticationMethod = "none";
/*      */   
/*      */ 
/*   83 */   private String realm = "MX4J";
/*      */   
/*   85 */   private Map authorizations = new HashMap();
/*      */   
/*   87 */   private HashSet JAASAuthorizedUsernames = new HashSet();
/*      */   
/*   89 */   private String JAASLoginModuleName = null;
/*      */   
/*   91 */   private AdaptorServerSocketFactory socketFactory = null;
/*      */   
/*      */   private ObjectName factoryName;
/*      */   
/*      */   private String processorClass;
/*      */   
/*      */   private Date startDate;
/*      */   
/*      */   private long requestsCount;
/*      */   
/*  101 */   private Constructor JDK15LoginContext = null;
/*      */   
/*  103 */   private Configuration conf = null;
/*      */   
/*  105 */   private String[][] defaultCommandProcessors = {
/*  106 */     { "server", "mx4j.tools.adaptor.http.ServerCommandProcessor" }, 
/*  107 */     { "serverbydomain", "mx4j.tools.adaptor.http.ServerByDomainCommandProcessor" }, 
/*  108 */     { "mbean", "mx4j.tools.adaptor.http.MBeanCommandProcessor" }, 
/*  109 */     { "setattributes", "mx4j.tools.adaptor.http.SetAttributesCommandProcessor" }, 
/*  110 */     { "setattribute", "mx4j.tools.adaptor.http.SetAttributeCommandProcessor" }, 
/*  111 */     { "getattribute", "mx4j.tools.adaptor.http.GetAttributeCommandProcessor" }, 
/*  112 */     { "delete", "mx4j.tools.adaptor.http.DeleteMBeanCommandProcessor" }, 
/*  113 */     { "invoke", "mx4j.tools.adaptor.http.InvokeOperationCommandProcessor" }, 
/*  114 */     { "create", "mx4j.tools.adaptor.http.CreateMBeanCommandProcessor" }, 
/*  115 */     { "constructors", "mx4j.tools.adaptor.http.ConstructorsCommandProcessor" }, 
/*  116 */     { "relation", "mx4j.tools.adaptor.http.RelationCommandProcessor" }, 
/*  117 */     { "empty", "mx4j.tools.adaptor.http.EmptyCommandProcessor" } };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private DocumentBuilder builder;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpAdaptor() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpAdaptor(int port)
/*      */   {
/*  145 */     this.port = port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpAdaptor(String host)
/*      */   {
/*  165 */     this.host = host;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpAdaptor(int port, String host)
/*      */   {
/*  187 */     this.port = port;
/*  188 */     this.host = host;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPort(int port)
/*      */   {
/*  199 */     if (this.alive)
/*      */     {
/*  201 */       throw new IllegalArgumentException("Not possible to change port with the server running");
/*      */     }
/*  203 */     this.port = port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPort()
/*      */   {
/*  214 */     return this.port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHost(String host)
/*      */   {
/*  225 */     if (this.alive)
/*      */     {
/*  227 */       throw new IllegalArgumentException("Not possible to change port with the server running");
/*      */     }
/*  229 */     this.host = host;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getHost()
/*      */   {
/*  241 */     return this.host;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAuthenticationMethod(String method)
/*      */   {
/*  251 */     if (this.alive)
/*      */     {
/*  253 */       throw new IllegalArgumentException("Not possible to change authentication method with the server running");
/*      */     }
/*  255 */     if ((method == null) || ((!method.equals("none")) && (!method.equals("basic")) && (!method.equals("digest"))))
/*      */     {
/*  257 */       throw new IllegalArgumentException("Only accept methods none/basic/digest");
/*      */     }
/*  259 */     this.authenticationMethod = method;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAuthenticationMethod()
/*      */   {
/*  270 */     return this.authenticationMethod;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProcessor(ProcessorMBean processor)
/*      */   {
/*  282 */     this.processor = processor;
/*  283 */     this.processorName = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProcessorClass(String processorClass)
/*      */   {
/*  296 */     this.processorClass = processorClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProcessorNameString(String processorName)
/*      */     throws MalformedObjectNameException
/*      */   {
/*  307 */     this.processorName = new ObjectName(processorName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProcessorName(ObjectName processorName)
/*      */   {
/*  319 */     this.processor = null;
/*  320 */     this.processorName = processorName;
/*      */   }
/*      */   
/*      */   public ProcessorMBean getProcessor()
/*      */   {
/*  325 */     return this.processor;
/*      */   }
/*      */   
/*      */   public ObjectName getProcessorName()
/*      */   {
/*  330 */     return this.processorName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSocketFactory(AdaptorServerSocketFactory factory)
/*      */   {
/*  340 */     this.factoryName = null;
/*  341 */     this.socketFactory = factory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSocketFactoryName(ObjectName factoryName)
/*      */   {
/*  352 */     this.socketFactory = null;
/*  353 */     this.factoryName = factoryName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSocketFactoryNameString(String factoryName)
/*      */     throws MalformedObjectNameException
/*      */   {
/*  364 */     this.socketFactory = null;
/*  365 */     this.factoryName = new ObjectName(factoryName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isActive()
/*      */   {
/*  376 */     return this.alive;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getStartDate()
/*      */   {
/*  387 */     return this.startDate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getRequestsCount()
/*      */   {
/*  398 */     return this.requestsCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getVersion()
/*      */   {
/*  409 */     return "2.1.0";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addCommandProcessor(String path, HttpCommandProcessor processor)
/*      */   {
/*  418 */     this.commands.put(path, processor);
/*  419 */     if (this.alive)
/*      */     {
/*  421 */       processor.setMBeanServer(this.server);
/*  422 */       processor.setDocumentBuilder(this.builder);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addCommandProcessor(String path, String processorClass)
/*      */   {
/*      */     try
/*      */     {
/*  434 */       HttpCommandProcessor processor = (HttpCommandProcessor)Class.forName(processorClass).newInstance();
/*  435 */       addCommandProcessor(path, processor);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  439 */       Logger log = getLogger();
/*  440 */       log.error("Exception creating Command Processor of class " + processorClass, e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeCommandProcessor(String path)
/*      */   {
/*  450 */     if (this.commands.containsKey(path))
/*      */     {
/*  452 */       this.commands.remove(path);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void start()
/*      */     throws IOException
/*      */   {
/*  463 */     final Logger logger = getLogger();
/*      */     
/*  465 */     if (this.server != null)
/*      */     {
/*  467 */       this.serverSocket = createServerSocket();
/*      */       
/*  469 */       if (this.serverSocket == null)
/*      */       {
/*  471 */         logger.error("Server socket is null");
/*  472 */         return;
/*      */       }
/*      */       
/*  475 */       if ((this.processorClass != null) && (this.processorName != null))
/*      */       {
/*  477 */         if (logger.isEnabledFor(10)) logger.debug("Building processor class of type " + this.processorClass + " and name " + this.processorName);
/*      */         try
/*      */         {
/*  480 */           this.server.createMBean(this.processorClass, this.processorName, null);
/*      */         } catch (JMException e) {
/*  482 */           logger.error("Exception creating processor class", e);
/*      */         }
/*      */       }
/*      */       
/*  486 */       Iterator i = this.commands.values().iterator();
/*  487 */       while (i.hasNext())
/*      */       {
/*  489 */         HttpCommandProcessor processor = (HttpCommandProcessor)i.next();
/*  490 */         processor.setMBeanServer(this.server);
/*  491 */         processor.setDocumentBuilder(this.builder);
/*      */       }
/*      */       
/*  494 */       if (logger.isEnabledFor(10)) logger.debug("HttpAdaptor server listening on port " + this.port);
/*  495 */       this.alive = true;
/*  496 */       Thread serverThread = new Thread(
/*  497 */         new Runnable()
/*      */         {
/*      */           public void run()
/*      */           {
/*  501 */             if (logger.isEnabledFor(20)) { logger.info("HttpAdaptor version 2.1.0 started on port " + HttpAdaptor.this.port);
/*      */             }
/*  503 */             HttpAdaptor.this.startDate = new Date();
/*  504 */             HttpAdaptor.this.requestsCount = 0L;
/*      */             
/*  506 */             while (HttpAdaptor.this.alive)
/*      */             {
/*      */               try
/*      */               {
/*  510 */                 Socket client = null;
/*  511 */                 client = HttpAdaptor.this.serverSocket.accept();
/*  512 */                 if (!HttpAdaptor.this.alive)
/*      */                 {
/*  514 */                   client.close();
/*  515 */                   break;
/*      */                 }
/*  517 */                 HttpAdaptor.this.requestsCount += 1L;
/*  518 */                 new HttpAdaptor.HttpClient(HttpAdaptor.this, client).start();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               }
/*      */               catch (InterruptedIOException e) {}catch (IOException e) {}catch (Exception e)
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  530 */                 logger.warn("Exception during request processing", e);
/*      */ 
/*      */               }
/*      */               catch (Error e)
/*      */               {
/*  535 */                 logger.error("Error during request processing", e);
/*      */               }
/*      */             }
/*      */             
/*      */             try
/*      */             {
/*  541 */               HttpAdaptor.this.serverSocket.close();
/*      */             }
/*      */             catch (IOException e)
/*      */             {
/*  545 */               logger.warn("Exception closing the server", e);
/*      */             }
/*  547 */             HttpAdaptor.this.serverSocket = null;
/*  548 */             HttpAdaptor.this.alive = false;
/*  549 */             if (logger.isEnabledFor(20)) logger.info("HttpAdaptor version 2.1.0 stopped on port " + HttpAdaptor.this.port);
/*      */           }
/*  551 */         });
/*  552 */       serverThread.start();
/*      */ 
/*      */ 
/*      */     }
/*  556 */     else if (logger.isEnabledFor(20)) { logger.info("Start failed, no server target server has been set");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public void restart()
/*      */     throws IOException
/*      */   {
/*  569 */     stop();
/*  570 */     start();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stop()
/*      */   {
/*      */     try
/*      */     {
/*  581 */       if (this.alive)
/*      */       {
/*  583 */         this.alive = false;
/*      */         
/*  585 */         new Socket(this.host, this.port);
/*      */       }
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*  590 */       getLogger().warn(e.getMessage());
/*      */     }
/*      */     try {
/*  593 */       if (this.serverSocket != null)
/*      */       {
/*  595 */         this.serverSocket.close();
/*      */       }
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*  600 */       getLogger().warn(e.getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addAuthorization(String username, String password)
/*      */   {
/*  610 */     if ((username == null) || (password == null))
/*      */     {
/*  612 */       throw new IllegalArgumentException("username and passwords cannot be null");
/*      */     }
/*  614 */     this.authorizations.put(username, password);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAuthorization(String username)
/*      */   {
/*  622 */     if (username == null)
/*      */     {
/*  624 */       throw new IllegalArgumentException("username cannot be null");
/*      */     }
/*  626 */     this.authorizations.remove(username);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setJAASLoginModule(String JAASLoginModuleName, String JAASConfigProviderClassName)
/*      */   {
/*  639 */     Class[] jdk15Const = { String.class, Subject.class, CallbackHandler.class, Configuration.class };
/*      */     try {
/*  641 */       this.JDK15LoginContext = LoginContext.class.getDeclaredConstructor(jdk15Const);
/*      */     }
/*      */     catch (NoSuchMethodException localNoSuchMethodException) {}
/*      */     
/*  645 */     if ((JAASConfigProviderClassName != null) && (jdk15Const == null))
/*      */     {
/*  647 */       Security.setProperty("login.configuration.provider", JAASConfigProviderClassName);
/*      */     }
/*      */     
/*  650 */     if (JAASConfigProviderClassName != null) {
/*      */       try {
/*  652 */         Class configCl = getClass().getClassLoader().loadClass(JAASConfigProviderClassName);
/*  653 */         this.conf = ((Configuration)configCl.newInstance());
/*      */       } catch (Exception ex) {
/*  655 */         IllegalArgumentException illegArgEx = new IllegalArgumentException("Unable to create JAAS login config " + JAASConfigProviderClassName);
/*  656 */         illegArgEx.initCause(ex);
/*  657 */         throw illegArgEx;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  665 */       BasicCallbackHandler handler = new BasicCallbackHandler("foo", "bar");
/*  666 */       getLoginContext(JAASLoginModuleName, handler);
/*      */     }
/*      */     catch (LoginException ex)
/*      */     {
/*  670 */       IllegalArgumentException illegArgEx = new IllegalArgumentException("Unable to create JAAS login context for setting " + JAASLoginModuleName);
/*  671 */       illegArgEx.initCause(ex);
/*  672 */       throw illegArgEx;
/*      */     }
/*  674 */     this.JAASLoginModuleName = JAASLoginModuleName;
/*      */   }
/*      */   
/*      */   public LoginContext getLoginContext(String configName, CallbackHandler handler) throws LoginException
/*      */   {
/*  679 */     LoginContext context = null;
/*  680 */     if ((this.JDK15LoginContext != null) && (this.conf != null)) {
/*  681 */       Object[] args = { configName, new Subject(), handler, this.conf };
/*      */       try {
/*  683 */         context = (LoginContext)this.JDK15LoginContext.newInstance(args);
/*      */       } catch (Exception ex) {
/*  685 */         LoginException lcEx = new LoginException("Error during loginContext creation");
/*  686 */         lcEx.initCause(ex);
/*  687 */         throw lcEx;
/*      */       }
/*      */     } else {
/*  690 */       context = new LoginContext(configName, new Subject(), handler);
/*      */     }
/*  692 */     return context;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void disableJAASLoginModule()
/*      */   {
/*  701 */     this.JAASLoginModuleName = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addJAASAuthorization(String JAASUsername)
/*      */   {
/*  712 */     if (this.JAASLoginModuleName == null)
/*      */     {
/*  714 */       throw new IllegalArgumentException("no JAAS realm defined");
/*      */     }
/*  716 */     if (JAASUsername == null)
/*      */     {
/*  718 */       throw new IllegalArgumentException("JAASUsername cannot be null");
/*      */     }
/*  720 */     this.JAASAuthorizedUsernames.add(JAASUsername.toLowerCase());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeJAASAuthorization(String JAASUsername)
/*      */   {
/*  729 */     if (this.JAASLoginModuleName == null)
/*      */     {
/*  731 */       throw new IllegalArgumentException("no JAAS realm defined");
/*      */     }
/*  733 */     if (JAASUsername == null)
/*      */     {
/*  735 */       throw new IllegalArgumentException("JAASUsername cannot be null");
/*      */     }
/*  737 */     this.JAASAuthorizedUsernames.remove(JAASUsername.toLowerCase());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectName preRegister(MBeanServer server, ObjectName name)
/*      */     throws Exception
/*      */   {
/*  746 */     this.server = server;
/*  747 */     buildCommands();
/*  748 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void postRegister(Boolean registrationDone) {}
/*      */   
/*      */ 
/*      */   public void preDeregister()
/*      */     throws Exception
/*      */   {
/*  759 */     stop();
/*      */   }
/*      */   
/*      */ 
/*      */   public void postDeregister() {}
/*      */   
/*      */   private Logger getLogger()
/*      */   {
/*  767 */     return Log.getLogger(getClass().getName());
/*      */   }
/*      */   
/*      */   private ServerSocket createServerSocket() throws IOException
/*      */   {
/*  772 */     if (this.socketFactory == null)
/*      */     {
/*  774 */       if (this.factoryName == null)
/*      */       {
/*  776 */         this.socketFactory = new PlainAdaptorServerSocketFactory();
/*  777 */         return this.socketFactory.createServerSocket(this.port, 50, this.host);
/*      */       }
/*      */       
/*      */ 
/*      */       try
/*      */       {
/*  783 */         return (ServerSocket)this.server.invoke(this.factoryName, "createServerSocket", new Object[] { new Integer(this.port), new Integer(50), this.host }, new String[] { "int", "int", "java.lang.String" });
/*      */       }
/*      */       catch (Exception x)
/*      */       {
/*  787 */         Logger log = getLogger();
/*  788 */         log.error("Exception invoking AdaptorServerSocketFactory via MBeanServer", x);
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/*  794 */       return this.socketFactory.createServerSocket(this.port, 50, this.host);
/*      */     }
/*      */     
/*  797 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean isUsernameValid(String username, String password)
/*      */   {
/*  803 */     if (this.authorizations.containsKey(username))
/*      */     {
/*  805 */       return password.equals(this.authorizations.get(username));
/*      */     }
/*  807 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   protected HttpCommandProcessor getProcessor(String path)
/*      */   {
/*  813 */     return (HttpCommandProcessor)this.commands.get(path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void buildCommands()
/*      */   {
/*  822 */     Logger log = getLogger();
/*      */     try
/*      */     {
/*  825 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*  826 */       this.builder = factory.newDocumentBuilder();
/*  827 */       for (int i = 0; i < this.defaultCommandProcessors.length; i++)
/*      */       {
/*      */         try
/*      */         {
/*  831 */           HttpCommandProcessor processor = (HttpCommandProcessor)Class.forName(this.defaultCommandProcessors[i][1]).newInstance();
/*  832 */           this.commands.put(this.defaultCommandProcessors[i][0], processor);
/*      */         } catch (Exception e) {
/*  834 */           log.warn("Exception building command procesor", e);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (ParserConfigurationException e)
/*      */     {
/*  840 */       log.error("Exception building the Document Factories", e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void postProcess(HttpOutputStream out, HttpInputStream in, Document document)
/*      */     throws IOException, JMException
/*      */   {
/*  848 */     boolean processed = false;
/*      */     
/*  850 */     if (this.processorName != null)
/*      */     {
/*  852 */       if ((this.server.isRegistered(this.processorName)) && 
/*  853 */         (this.server.isInstanceOf(this.processorName, "mx4j.tools.adaptor.http.ProcessorMBean")))
/*      */       {
/*  855 */         this.server.invoke(this.processorName, 
/*  856 */           "writeResponse", 
/*  857 */           new Object[] { out, in, document }, 
/*  858 */           new String[] { "mx4j.tools.adaptor.http.HttpOutputStream", "mx4j.tools.adaptor.http.HttpInputStream", "org.w3c.dom.Document" });
/*  859 */         processed = true;
/*      */       }
/*      */       else
/*      */       {
/*  863 */         Logger log = getLogger();
/*  864 */         if (log.isEnabledFor(0)) log.trace(this.processorName + " not found");
/*      */       }
/*      */     }
/*  867 */     if ((!processed) && (this.processor != null))
/*      */     {
/*  869 */       this.processor.writeResponse(out, in, document);
/*  870 */       processed = true;
/*      */     }
/*  872 */     if (!processed)
/*      */     {
/*  874 */       this.defaultProcessor.writeResponse(out, in, document);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void findUnknownElement(String path, HttpOutputStream out, HttpInputStream in)
/*      */     throws IOException, JMException
/*      */   {
/*  882 */     boolean processed = false;
/*      */     
/*  884 */     if (this.processorName != null)
/*      */     {
/*  886 */       if ((this.server.isRegistered(this.processorName)) && 
/*  887 */         (this.server.isInstanceOf(this.processorName, "mx4j.tools.adaptor.http.ProcessorMBean")))
/*      */       {
/*  889 */         this.server.invoke(this.processorName, 
/*  890 */           "notFoundElement", 
/*  891 */           new Object[] { path, out, in }, 
/*  892 */           new String[] { "java.lang.String", "mx4j.tools.adaptor.http.HttpOutputStream", "mx4j.tools.adaptor.http.HttpInputStream" });
/*  893 */         processed = true;
/*      */       }
/*      */       else
/*      */       {
/*  897 */         Logger log = getLogger();
/*  898 */         if (log.isEnabledFor(0)) log.trace(this.processorName + " not found");
/*      */       }
/*      */     }
/*  901 */     if ((!processed) && (this.processor != null))
/*      */     {
/*  903 */       this.processor.notFoundElement(path, out, in);
/*  904 */       processed = true;
/*      */     }
/*  906 */     if (!processed)
/*      */     {
/*  908 */       this.defaultProcessor.notFoundElement(path, out, in);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected String preProcess(String path)
/*      */     throws IOException, JMException
/*      */   {
/*  916 */     boolean processed = false;
/*      */     
/*  918 */     if (this.processorName != null)
/*      */     {
/*  920 */       Logger log = getLogger();
/*  921 */       if (log.isEnabledFor(0)) log.trace("Preprocess using " + this.processorName);
/*  922 */       if ((this.server.isRegistered(this.processorName)) && 
/*  923 */         (this.server.isInstanceOf(this.processorName, "mx4j.tools.adaptor.http.ProcessorMBean")))
/*      */       {
/*  925 */         if (log.isEnabledFor(0)) log.trace("Preprocessing");
/*  926 */         path = (String)this.server.invoke(this.processorName, 
/*  927 */           "preProcess", 
/*  928 */           new Object[] { path }, 
/*  929 */           new String[] { "java.lang.String" });
/*  930 */         processed = true;
/*      */ 
/*      */ 
/*      */       }
/*  934 */       else if (log.isEnabledFor(0)) { log.trace(this.processorName + " not found");
/*      */       }
/*      */     }
/*  937 */     if ((!processed) && (this.processor != null))
/*      */     {
/*  939 */       path = this.processor.preProcess(path);
/*  940 */       processed = true;
/*      */     }
/*  942 */     if (!processed)
/*      */     {
/*  944 */       path = this.defaultProcessor.preProcess(path);
/*      */     }
/*  946 */     return path;
/*      */   }
/*      */   
/*      */ 
/*      */   protected void postProcess(HttpOutputStream out, HttpInputStream in, Exception e)
/*      */     throws IOException, JMException
/*      */   {
/*  953 */     boolean processed = false;
/*      */     
/*  955 */     if (this.processorName != null)
/*      */     {
/*  957 */       if ((this.server.isRegistered(this.processorName)) && 
/*  958 */         (this.server.isInstanceOf(this.processorName, "mx4j.tools.adaptor.http.ProcessorMBean")))
/*      */       {
/*  960 */         this.server.invoke(this.processorName, 
/*  961 */           "writeError", 
/*  962 */           new Object[] { out, in, e }, 
/*  963 */           new String[] { "mx4j.tools.adaptor.http.HttpOutputStream", "mx4j.tools.adaptor.http.HttpInputStream", "java.lang.Exception" });
/*  964 */         processed = true;
/*      */       }
/*      */       else
/*      */       {
/*  968 */         Logger log = getLogger();
/*  969 */         if (log.isEnabledFor(0)) log.trace(this.processorName + " not found");
/*      */       }
/*      */     }
/*  972 */     if ((!processed) && (this.processor != null))
/*      */     {
/*  974 */       this.processor.writeError(out, in, e);
/*  975 */       processed = true;
/*      */     }
/*  977 */     if (!processed)
/*      */     {
/*  979 */       this.defaultProcessor.writeError(out, in, e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private class BasicCallbackHandler
/*      */     implements CallbackHandler
/*      */   {
/*      */     private String userName;
/*      */     
/*      */ 
/*      */     private String password;
/*      */     
/*      */ 
/*      */     BasicCallbackHandler(String userName, String password)
/*      */     {
/*  996 */       this.userName = userName;
/*  997 */       this.password = password;
/*      */     }
/*      */     
/*      */     public void handle(Callback[] callbacks)
/*      */       throws IOException, UnsupportedCallbackException
/*      */     {
/* 1003 */       for (int i = 0; i < callbacks.length; i++)
/*      */       {
/* 1005 */         Callback cb = callbacks[i];
/* 1006 */         if ((cb instanceof NameCallback))
/*      */         {
/*      */ 
/* 1009 */           NameCallback nc = (NameCallback)cb;
/* 1010 */           nc.setName(this.userName);
/*      */         }
/* 1012 */         else if ((cb instanceof PasswordCallback))
/*      */         {
/*      */ 
/* 1015 */           PasswordCallback pc = (PasswordCallback)cb;
/* 1016 */           pc.setPassword(this.password.toCharArray());
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1021 */           Logger log = HttpAdaptor.this.getLogger();
/* 1022 */           if (log.isEnabledFor(10)) log.warn("Ignoring login module callback " + cb.getClass().getName());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private class HttpClient
/*      */     extends Thread
/*      */   {
/*      */     private Socket client;
/*      */     private String providedUsername;
/*      */     private String providedPassword;
/*      */     
/*      */     HttpClient(Socket client)
/*      */     {
/* 1037 */       this.client = client;
/*      */     }
/*      */     
/*      */     private boolean isValid(String authorizationString) {
/* 1041 */       if (HttpAdaptor.this.authenticationMethod.startsWith("basic"))
/*      */       {
/* 1043 */         authorizationString = authorizationString.substring(5, authorizationString.length());
/* 1044 */         String decodeString = new String(Base64Codec.decodeBase64(authorizationString.getBytes()));
/* 1045 */         if (decodeString.indexOf(":") > 0)
/*      */         {
/*      */           try
/*      */           {
/* 1049 */             StringTokenizer tokens = new StringTokenizer(decodeString, ":");
/* 1050 */             this.providedUsername = tokens.nextToken();
/* 1051 */             this.providedPassword = tokens.nextToken();
/*      */             
/*      */ 
/* 1054 */             boolean auth = HttpAdaptor.this.isUsernameValid(this.providedUsername, this.providedPassword);
/*      */             
/*      */ 
/* 1057 */             if ((!auth) && (HttpAdaptor.this.JAASLoginModuleName != null))
/*      */             {
/* 1059 */               boolean makeJAASLookup = (HttpAdaptor.this.JAASAuthorizedUsernames.size() == 0) || (HttpAdaptor.this.JAASAuthorizedUsernames.contains(this.providedUsername.toLowerCase()));
/* 1060 */               if (makeJAASLookup)
/*      */               {
/* 1062 */                 HttpAdaptor.BasicCallbackHandler handler = new HttpAdaptor.BasicCallbackHandler(HttpAdaptor.this, this.providedUsername, this.providedPassword);
/* 1063 */                 LoginContext context = HttpAdaptor.this.getLoginContext(HttpAdaptor.this.JAASLoginModuleName, handler);
/*      */                 try
/*      */                 {
/* 1066 */                   context.login();
/* 1067 */                   auth = true;
/*      */ 
/*      */ 
/*      */                 }
/*      */                 catch (LoginException ex)
/*      */                 {
/*      */ 
/* 1074 */                   if ((ex.getCause() != null) && (!(ex.getCause() instanceof LoginException)))
/*      */                   {
/* 1076 */                     throw ex;
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/* 1081 */             return auth;
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/* 1085 */             Logger log = HttpAdaptor.this.getLogger();
/* 1086 */             if (log.isEnabledFor(40)) log.error("Error during authentication", e);
/* 1087 */             return false;
/*      */           }
/*      */         }
/*      */       }
/* 1091 */       return false;
/*      */     }
/*      */     
/*      */     private boolean handleAuthentication(HttpInputStream in, HttpOutputStream out) throws IOException {
/* 1095 */       if (HttpAdaptor.this.authenticationMethod.equals("basic"))
/*      */       {
/* 1097 */         String result = in.getHeader("authorization");
/* 1098 */         if (result != null)
/*      */         {
/* 1100 */           if (isValid(result))
/*      */           {
/* 1102 */             return true;
/*      */           }
/* 1104 */           out.setCode(403);
/* 1105 */           throw new HttpException(403, "Authentication failed (" + this.providedUsername + "/" + this.providedPassword + ") for remote host " + this.client.getInetAddress());
/*      */         }
/*      */         
/* 1108 */         out.setCode(401);
/* 1109 */         if (HttpAdaptor.this.JAASLoginModuleName != null) {
/* 1110 */           out.setHeader("WWW-Authenticate", "Basic realm=\"" + HttpAdaptor.this.JAASLoginModuleName + "\"");
/*      */         } else {
/* 1112 */           out.setHeader("WWW-Authenticate", "Basic realm=\"" + HttpAdaptor.this.realm + "\"");
/*      */         }
/* 1114 */         out.sendHeaders();
/* 1115 */         out.flush();
/* 1116 */         return false;
/*      */       }
/* 1118 */       HttpAdaptor.this.authenticationMethod.equals("digest");
/*      */       
/*      */ 
/*      */ 
/* 1122 */       return true;
/*      */     }
/*      */     
/*      */     /* Error */
/*      */     public void run()
/*      */     {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: getfield 17	mx4j/tools/adaptor/http/HttpAdaptor$HttpClient:this$0	Lmx4j/tools/adaptor/http/HttpAdaptor;
/*      */       //   4: invokestatic 128	mx4j/tools/adaptor/http/HttpAdaptor:access$0	(Lmx4j/tools/adaptor/http/HttpAdaptor;)Lmx4j/log/Logger;
/*      */       //   7: astore_1
/*      */       //   8: aconst_null
/*      */       //   9: astore_2
/*      */       //   10: aconst_null
/*      */       //   11: astore_3
/*      */       //   12: aload_0
/*      */       //   13: getfield 22	mx4j/tools/adaptor/http/HttpAdaptor$HttpClient:client	Ljava/net/Socket;
/*      */       //   16: invokevirtual 246	java/net/Socket:getInputStream	()Ljava/io/InputStream;
/*      */       //   19: astore 4
/*      */       //   21: new 171	mx4j/tools/adaptor/http/HttpInputStream
/*      */       //   24: dup
/*      */       //   25: aload 4
/*      */       //   27: invokespecial 249	mx4j/tools/adaptor/http/HttpInputStream:<init>	(Ljava/io/InputStream;)V
/*      */       //   30: astore_2
/*      */       //   31: aload_2
/*      */       //   32: invokevirtual 252	mx4j/tools/adaptor/http/HttpInputStream:readRequest	()Z
/*      */       //   35: ifeq +478 -> 513
/*      */       //   38: aload_2
/*      */       //   39: invokevirtual 255	mx4j/tools/adaptor/http/HttpInputStream:getPath	()Ljava/lang/String;
/*      */       //   42: astore 5
/*      */       //   44: aload_2
/*      */       //   45: invokevirtual 258	mx4j/tools/adaptor/http/HttpInputStream:getQueryString	()Ljava/lang/String;
/*      */       //   48: astore 6
/*      */       //   50: aload_1
/*      */       //   51: bipush 10
/*      */       //   53: invokevirtual 134	mx4j/log/Logger:isEnabledFor	(I)Z
/*      */       //   56: ifeq +57 -> 113
/*      */       //   59: aload_1
/*      */       //   60: new 187	java/lang/StringBuffer
/*      */       //   63: dup
/*      */       //   64: ldc_w 260
/*      */       //   67: invokespecial 192	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*      */       //   70: aload 5
/*      */       //   72: invokevirtual 196	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */       //   75: aload 6
/*      */       //   77: ifnonnull +9 -> 86
/*      */       //   80: ldc_w 262
/*      */       //   83: goto +21 -> 104
/*      */       //   86: new 187	java/lang/StringBuffer
/*      */       //   89: dup
/*      */       //   90: ldc_w 264
/*      */       //   93: invokespecial 192	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*      */       //   96: aload 6
/*      */       //   98: invokevirtual 196	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */       //   101: invokevirtual 212	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */       //   104: invokevirtual 196	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */       //   107: invokevirtual 212	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */       //   110: invokevirtual 268	mx4j/log/Logger:debug	(Ljava/lang/Object;)V
/*      */       //   113: aload_0
/*      */       //   114: getfield 17	mx4j/tools/adaptor/http/HttpAdaptor$HttpClient:this$0	Lmx4j/tools/adaptor/http/HttpAdaptor;
/*      */       //   117: aload 5
/*      */       //   119: invokevirtual 271	mx4j/tools/adaptor/http/HttpAdaptor:preProcess	(Ljava/lang/String;)Ljava/lang/String;
/*      */       //   122: astore 7
/*      */       //   124: aload 7
/*      */       //   126: aload 5
/*      */       //   128: invokevirtual 167	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */       //   131: ifne +49 -> 180
/*      */       //   134: aload_1
/*      */       //   135: bipush 10
/*      */       //   137: invokevirtual 134	mx4j/log/Logger:isEnabledFor	(I)Z
/*      */       //   140: ifeq +36 -> 176
/*      */       //   143: aload_1
/*      */       //   144: new 187	java/lang/StringBuffer
/*      */       //   147: dup
/*      */       //   148: ldc_w 273
/*      */       //   151: invokespecial 192	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*      */       //   154: aload 5
/*      */       //   156: invokevirtual 196	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */       //   159: ldc_w 275
/*      */       //   162: invokevirtual 196	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */       //   165: aload 7
/*      */       //   167: invokevirtual 196	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */       //   170: invokevirtual 212	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */       //   173: invokevirtual 268	mx4j/log/Logger:debug	(Ljava/lang/Object;)V
/*      */       //   176: aload 7
/*      */       //   178: astore 5
/*      */       //   180: aload_0
/*      */       //   181: getfield 22	mx4j/tools/adaptor/http/HttpAdaptor$HttpClient:client	Ljava/net/Socket;
/*      */       //   184: invokevirtual 279	java/net/Socket:getOutputStream	()Ljava/io/OutputStream;
/*      */       //   187: astore 8
/*      */       //   189: new 179	mx4j/tools/adaptor/http/HttpOutputStream
/*      */       //   192: dup
/*      */       //   193: aload 8
/*      */       //   195: aload_2
/*      */       //   196: invokespecial 282	mx4j/tools/adaptor/http/HttpOutputStream:<init>	(Ljava/io/OutputStream;Lmx4j/tools/adaptor/http/HttpInputStream;)V
/*      */       //   199: astore_3
/*      */       //   200: aload_0
/*      */       //   201: aload_2
/*      */       //   202: aload_3
/*      */       //   203: invokespecial 284	mx4j/tools/adaptor/http/HttpAdaptor$HttpClient:handleAuthentication	(Lmx4j/tools/adaptor/http/HttpInputStream;Lmx4j/tools/adaptor/http/HttpOutputStream;)Z
/*      */       //   206: ifne +7 -> 213
/*      */       //   209: jsr +239 -> 448
/*      */       //   212: return
/*      */       //   213: aload_0
/*      */       //   214: getfield 17	mx4j/tools/adaptor/http/HttpAdaptor$HttpClient:this$0	Lmx4j/tools/adaptor/http/HttpAdaptor;
/*      */       //   217: aload 5
/*      */       //   219: iconst_1
/*      */       //   220: aload 5
/*      */       //   222: invokevirtual 45	java/lang/String:length	()I
/*      */       //   225: invokevirtual 49	java/lang/String:substring	(II)Ljava/lang/String;
/*      */       //   228: invokevirtual 288	mx4j/tools/adaptor/http/HttpAdaptor:getProcessor	(Ljava/lang/String;)Lmx4j/tools/adaptor/http/HttpCommandProcessor;
/*      */       //   231: astore 9
/*      */       //   233: aload 9
/*      */       //   235: ifnonnull +48 -> 283
/*      */       //   238: aload_1
/*      */       //   239: bipush 10
/*      */       //   241: invokevirtual 134	mx4j/log/Logger:isEnabledFor	(I)Z
/*      */       //   244: ifeq +25 -> 269
/*      */       //   247: aload_1
/*      */       //   248: new 187	java/lang/StringBuffer
/*      */       //   251: dup
/*      */       //   252: ldc_w 290
/*      */       //   255: invokespecial 192	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*      */       //   258: aload 5
/*      */       //   260: invokevirtual 196	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */       //   263: invokevirtual 212	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */       //   266: invokevirtual 268	mx4j/log/Logger:debug	(Ljava/lang/Object;)V
/*      */       //   269: aload_0
/*      */       //   270: getfield 17	mx4j/tools/adaptor/http/HttpAdaptor$HttpClient:this$0	Lmx4j/tools/adaptor/http/HttpAdaptor;
/*      */       //   273: aload 5
/*      */       //   275: aload_3
/*      */       //   276: aload_2
/*      */       //   277: invokevirtual 294	mx4j/tools/adaptor/http/HttpAdaptor:findUnknownElement	(Ljava/lang/String;Lmx4j/tools/adaptor/http/HttpOutputStream;Lmx4j/tools/adaptor/http/HttpInputStream;)V
/*      */       //   280: goto +233 -> 513
/*      */       //   283: aload 9
/*      */       //   285: aload_2
/*      */       //   286: invokeinterface 300 2 0
/*      */       //   291: astore 10
/*      */       //   293: aload_0
/*      */       //   294: getfield 17	mx4j/tools/adaptor/http/HttpAdaptor$HttpClient:this$0	Lmx4j/tools/adaptor/http/HttpAdaptor;
/*      */       //   297: aload_3
/*      */       //   298: aload_2
/*      */       //   299: aload 10
/*      */       //   301: invokevirtual 304	mx4j/tools/adaptor/http/HttpAdaptor:postProcess	(Lmx4j/tools/adaptor/http/HttpOutputStream;Lmx4j/tools/adaptor/http/HttpInputStream;Lorg/w3c/dom/Document;)V
/*      */       //   304: goto +209 -> 513
/*      */       //   307: astore 4
/*      */       //   309: aload 4
/*      */       //   311: instanceof 164
/*      */       //   314: ifeq +15 -> 329
/*      */       //   317: aload_1
/*      */       //   318: ldc_w 306
/*      */       //   321: aload 4
/*      */       //   323: invokevirtual 308	mx4j/log/Logger:debug	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/*      */       //   326: goto +12 -> 338
/*      */       //   329: aload_1
/*      */       //   330: ldc_w 310
/*      */       //   333: aload 4
/*      */       //   335: invokevirtual 313	mx4j/log/Logger:warn	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/*      */       //   338: aload_3
/*      */       //   339: ifnull +174 -> 513
/*      */       //   342: aload_0
/*      */       //   343: getfield 17	mx4j/tools/adaptor/http/HttpAdaptor$HttpClient:this$0	Lmx4j/tools/adaptor/http/HttpAdaptor;
/*      */       //   346: aload_3
/*      */       //   347: aload_2
/*      */       //   348: aload 4
/*      */       //   350: invokevirtual 316	mx4j/tools/adaptor/http/HttpAdaptor:postProcess	(Lmx4j/tools/adaptor/http/HttpOutputStream;Lmx4j/tools/adaptor/http/HttpInputStream;Ljava/lang/Exception;)V
/*      */       //   353: goto +160 -> 513
/*      */       //   356: astore 5
/*      */       //   358: aload_1
/*      */       //   359: ldc_w 306
/*      */       //   362: aload 5
/*      */       //   364: invokevirtual 313	mx4j/log/Logger:warn	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/*      */       //   367: goto +146 -> 513
/*      */       //   370: astore 5
/*      */       //   372: aload_1
/*      */       //   373: ldc_w 318
/*      */       //   376: aload 5
/*      */       //   378: invokevirtual 313	mx4j/log/Logger:warn	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/*      */       //   381: goto +132 -> 513
/*      */       //   384: astore 5
/*      */       //   386: aload_1
/*      */       //   387: ldc_w 320
/*      */       //   390: aload 5
/*      */       //   392: invokevirtual 140	mx4j/log/Logger:error	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/*      */       //   395: goto +118 -> 513
/*      */       //   398: astore 5
/*      */       //   400: aload_1
/*      */       //   401: ldc_w 322
/*      */       //   404: aload 5
/*      */       //   406: invokevirtual 140	mx4j/log/Logger:error	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/*      */       //   409: goto +104 -> 513
/*      */       //   412: astore 5
/*      */       //   414: aload_1
/*      */       //   415: ldc_w 324
/*      */       //   418: aload 5
/*      */       //   420: invokevirtual 327	mx4j/log/Logger:fatal	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/*      */       //   423: goto +90 -> 513
/*      */       //   426: astore 4
/*      */       //   428: aload_1
/*      */       //   429: ldc_w 322
/*      */       //   432: aload 4
/*      */       //   434: invokevirtual 140	mx4j/log/Logger:error	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/*      */       //   437: goto +76 -> 513
/*      */       //   440: astore 12
/*      */       //   442: jsr +6 -> 448
/*      */       //   445: aload 12
/*      */       //   447: athrow
/*      */       //   448: astore 11
/*      */       //   450: aload_3
/*      */       //   451: ifnull +57 -> 508
/*      */       //   454: aload_3
/*      */       //   455: invokevirtual 234	mx4j/tools/adaptor/http/HttpOutputStream:flush	()V
/*      */       //   458: goto +50 -> 508
/*      */       //   461: astore 13
/*      */       //   463: aload_1
/*      */       //   464: ldc_w 329
/*      */       //   467: aload 13
/*      */       //   469: invokevirtual 313	mx4j/log/Logger:warn	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/*      */       //   472: goto +36 -> 508
/*      */       //   475: astore 15
/*      */       //   477: jsr +6 -> 483
/*      */       //   480: aload 15
/*      */       //   482: athrow
/*      */       //   483: astore 14
/*      */       //   485: aload_0
/*      */       //   486: getfield 22	mx4j/tools/adaptor/http/HttpAdaptor$HttpClient:client	Ljava/net/Socket;
/*      */       //   489: invokevirtual 332	java/net/Socket:close	()V
/*      */       //   492: goto +14 -> 506
/*      */       //   495: astore 16
/*      */       //   497: aload_1
/*      */       //   498: ldc_w 329
/*      */       //   501: aload 16
/*      */       //   503: invokevirtual 313	mx4j/log/Logger:warn	(Ljava/lang/Object;Ljava/lang/Throwable;)V
/*      */       //   506: ret 14
/*      */       //   508: jsr -25 -> 483
/*      */       //   511: ret 11
/*      */       //   513: jsr -65 -> 448
/*      */       //   516: return
/*      */       // Line number table:
/*      */       //   Java source line #1128	-> byte code offset #0
/*      */       //   Java source line #1129	-> byte code offset #8
/*      */       //   Java source line #1130	-> byte code offset #10
/*      */       //   Java source line #1134	-> byte code offset #12
/*      */       //   Java source line #1135	-> byte code offset #21
/*      */       //   Java source line #1136	-> byte code offset #31
/*      */       //   Java source line #1138	-> byte code offset #38
/*      */       //   Java source line #1139	-> byte code offset #44
/*      */       //   Java source line #1140	-> byte code offset #50
/*      */       //   Java source line #1141	-> byte code offset #113
/*      */       //   Java source line #1142	-> byte code offset #124
/*      */       //   Java source line #1144	-> byte code offset #134
/*      */       //   Java source line #1145	-> byte code offset #176
/*      */       //   Java source line #1147	-> byte code offset #180
/*      */       //   Java source line #1148	-> byte code offset #189
/*      */       //   Java source line #1149	-> byte code offset #200
/*      */       //   Java source line #1150	-> byte code offset #209
/*      */       //   Java source line #1152	-> byte code offset #213
/*      */       //   Java source line #1153	-> byte code offset #233
/*      */       //   Java source line #1155	-> byte code offset #238
/*      */       //   Java source line #1156	-> byte code offset #269
/*      */       //   Java source line #1160	-> byte code offset #283
/*      */       //   Java source line #1161	-> byte code offset #293
/*      */       //   Java source line #1165	-> byte code offset #307
/*      */       //   Java source line #1168	-> byte code offset #309
/*      */       //   Java source line #1171	-> byte code offset #317
/*      */       //   Java source line #1173	-> byte code offset #329
/*      */       //   Java source line #1175	-> byte code offset #338
/*      */       //   Java source line #1179	-> byte code offset #342
/*      */       //   Java source line #1181	-> byte code offset #356
/*      */       //   Java source line #1183	-> byte code offset #358
/*      */       //   Java source line #1185	-> byte code offset #370
/*      */       //   Java source line #1187	-> byte code offset #372
/*      */       //   Java source line #1189	-> byte code offset #384
/*      */       //   Java source line #1191	-> byte code offset #386
/*      */       //   Java source line #1193	-> byte code offset #398
/*      */       //   Java source line #1195	-> byte code offset #400
/*      */       //   Java source line #1197	-> byte code offset #412
/*      */       //   Java source line #1199	-> byte code offset #414
/*      */       //   Java source line #1205	-> byte code offset #426
/*      */       //   Java source line #1207	-> byte code offset #428
/*      */       //   Java source line #1210	-> byte code offset #440
/*      */       //   Java source line #1232	-> byte code offset #445
/*      */       //   Java source line #1210	-> byte code offset #448
/*      */       //   Java source line #1213	-> byte code offset #450
/*      */       //   Java source line #1215	-> byte code offset #454
/*      */       //   Java source line #1218	-> byte code offset #461
/*      */       //   Java source line #1220	-> byte code offset #463
/*      */       //   Java source line #1222	-> byte code offset #475
/*      */       //   Java source line #1231	-> byte code offset #480
/*      */       //   Java source line #1222	-> byte code offset #483
/*      */       //   Java source line #1225	-> byte code offset #485
/*      */       //   Java source line #1227	-> byte code offset #495
/*      */       //   Java source line #1229	-> byte code offset #497
/*      */       //   Java source line #1231	-> byte code offset #506
/*      */       //   Java source line #1232	-> byte code offset #511
/*      */       //   Java source line #1233	-> byte code offset #516
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	signature
/*      */       //   0	517	0	this	HttpClient
/*      */       //   7	491	1	log	Logger
/*      */       //   9	339	2	httpIn	HttpInputStream
/*      */       //   11	444	3	httpOut	HttpOutputStream
/*      */       //   19	7	4	in	java.io.InputStream
/*      */       //   307	42	4	ex	Exception
/*      */       //   426	7	4	ex	Error
/*      */       //   42	232	5	path	String
/*      */       //   356	7	5	e	IOException
/*      */       //   370	7	5	e	JMException
/*      */       //   384	7	5	rte	RuntimeException
/*      */       //   398	7	5	er	Error
/*      */       //   412	7	5	t	Throwable
/*      */       //   48	49	6	queryString	String
/*      */       //   122	55	7	postPath	String
/*      */       //   187	7	8	out	java.io.OutputStream
/*      */       //   231	53	9	processor	HttpCommandProcessor
/*      */       //   291	9	10	document	Document
/*      */       //   448	1	11	localObject1	Object
/*      */       //   440	6	12	localObject2	Object
/*      */       //   461	7	13	e	IOException
/*      */       //   483	1	14	localObject3	Object
/*      */       //   475	6	15	localObject4	Object
/*      */       //   495	7	16	e	IOException
/*      */       // Exception table:
/*      */       //   from	to	target	type
/*      */       //   12	307	307	java/lang/Exception
/*      */       //   342	356	356	java/io/IOException
/*      */       //   342	356	370	javax/management/JMException
/*      */       //   342	356	384	java/lang/RuntimeException
/*      */       //   342	356	398	java/lang/Error
/*      */       //   342	356	412	java/lang/Throwable
/*      */       //   12	307	426	java/lang/Error
/*      */       //   12	212	440	finally
/*      */       //   213	440	440	finally
/*      */       //   513	516	440	finally
/*      */       //   450	461	461	java/io/IOException
/*      */       //   450	475	475	finally
/*      */       //   508	511	475	finally
/*      */       //   485	495	495	java/io/IOException
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/HttpAdaptor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */