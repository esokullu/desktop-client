package mx4j.tools.adaptor.http;

import java.io.IOException;
import java.util.Date;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import mx4j.tools.adaptor.AdaptorServerSocketFactory;

public abstract interface HttpAdaptorMBean
{
  public abstract void setPort(int paramInt);
  
  public abstract int getPort();
  
  public abstract void setHost(String paramString);
  
  public abstract String getHost();
  
  public abstract void setAuthenticationMethod(String paramString);
  
  public abstract String getAuthenticationMethod();
  
  public abstract void setProcessor(ProcessorMBean paramProcessorMBean);
  
  public abstract ProcessorMBean getProcessor();
  
  public abstract void setProcessorClass(String paramString);
  
  public abstract void setProcessorNameString(String paramString)
    throws MalformedObjectNameException;
  
  public abstract void setProcessorName(ObjectName paramObjectName);
  
  public abstract ObjectName getProcessorName();
  
  public abstract void setSocketFactory(AdaptorServerSocketFactory paramAdaptorServerSocketFactory);
  
  public abstract void setSocketFactoryName(ObjectName paramObjectName);
  
  public abstract void setSocketFactoryNameString(String paramString)
    throws MalformedObjectNameException;
  
  public abstract boolean isActive();
  
  public abstract Date getStartDate();
  
  public abstract long getRequestsCount();
  
  public abstract String getVersion();
  
  public abstract void addCommandProcessor(String paramString, HttpCommandProcessor paramHttpCommandProcessor);
  
  public abstract void addCommandProcessor(String paramString1, String paramString2);
  
  public abstract void removeCommandProcessor(String paramString);
  
  public abstract void start()
    throws IOException;
  
  public abstract void stop();
  
  public abstract void addAuthorization(String paramString1, String paramString2);
  
  public abstract void setJAASLoginModule(String paramString1, String paramString2);
  
  public abstract void removeAuthorization(String paramString);
  
  public abstract void addJAASAuthorization(String paramString);
  
  public abstract void removeJAASAuthorization(String paramString);
  
  public abstract void disableJAASLoginModule();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/HttpAdaptorMBean.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */