package mx4j.tools.adaptor.http;

import java.io.IOException;
import javax.management.JMException;
import javax.management.MBeanServer;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;

public abstract interface HttpCommandProcessor
{
  public abstract Document executeRequest(HttpInputStream paramHttpInputStream)
    throws IOException, JMException;
  
  public abstract void setMBeanServer(MBeanServer paramMBeanServer);
  
  public abstract void setDocumentBuilder(DocumentBuilder paramDocumentBuilder);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/HttpCommandProcessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */