/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.relation.RelationServiceMBean;
/*     */ import javax.management.relation.RoleInfo;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import mx4j.util.StandardMBeanProxy;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RelationCommandProcessor
/*     */   extends HttpCommandProcessorAdaptor
/*     */ {
/*  35 */   private ObjectName m_relationObjectName = null;
/*  36 */   private RelationServiceMBean m_proxy = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Document executeRequest(HttpInputStream in)
/*     */     throws IOException, JMException
/*     */   {
/*  44 */     Document document = this.builder.newDocument();
/*  45 */     Element root = document.createElement("RelationServer");
/*  46 */     document.appendChild(root);
/*     */     
/*     */ 
/*  49 */     if (!checkRelationServiceIsRegistered())
/*     */     {
/*  51 */       Element defaultElement = document.createElement("default");
/*  52 */       Text defaultNode = document.createTextNode("RelationService is not registered!");
/*  53 */       defaultElement.appendChild(defaultNode);
/*  54 */       root.appendChild(defaultElement);
/*  55 */       return document;
/*     */     }
/*  57 */     this.m_proxy = ((RelationServiceMBean)StandardMBeanProxy.create(RelationServiceMBean.class, this.server, this.m_relationObjectName));
/*     */     
/*     */ 
/*  60 */     List allRelationNames = this.m_proxy.getAllRelationTypeNames();
/*  61 */     addRelationTypeNames(root, document, allRelationNames);
/*  62 */     return document;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addRelationTypeNames(Element node, Document document, List allRelationNames)
/*     */     throws JMException
/*     */   {
/*  71 */     Map namesMap = new HashMap();
/*  72 */     Iterator i = allRelationNames.iterator();
/*  73 */     while (i.hasNext())
/*     */     {
/*  75 */       String name = (String)i.next();
/*  76 */       List values = this.m_proxy.findRelationsOfType(name);
/*  77 */       if (namesMap.containsKey(name))
/*     */       {
/*     */ 
/*  80 */         ((List)namesMap.get(name)).add(values);
/*     */       }
/*     */       else
/*     */       {
/*  84 */         namesMap.put(name, values);
/*     */       }
/*     */     }
/*     */     
/*  88 */     i = namesMap.keySet().iterator();
/*  89 */     while (i.hasNext())
/*     */     {
/*  91 */       String relationName = (String)i.next();
/*  92 */       Element typeNameElement = document.createElement("relation-type-name");
/*  93 */       typeNameElement.setAttribute("name", relationName);
/*  94 */       node.appendChild(typeNameElement);
/*     */       
/*  96 */       List infos = this.m_proxy.getRoleInfos(relationName);
/*  97 */       Iterator x = infos.iterator();
/*     */       
/*  99 */       while (x.hasNext())
/*     */       {
/*     */ 
/* 102 */         RoleInfo roleInfo = (RoleInfo)x.next();
/* 103 */         String roleName = roleInfo.getName();
/* 104 */         String mbeanClassName = roleInfo.getRefMBeanClassName();
/* 105 */         String description = roleInfo.getDescription();
/* 106 */         int minDegree = roleInfo.getMinDegree();
/* 107 */         int maxDegree = roleInfo.getMaxDegree();
/* 108 */         boolean reading = roleInfo.isReadable();
/* 109 */         boolean writing = roleInfo.isWritable();
/*     */         
/*     */ 
/* 112 */         Element roleInfoElement = document.createElement("relation-meta-data");
/*     */         
/*     */ 
/* 115 */         Element roleNameElement = document.createElement("role-name");
/* 116 */         Text roleNameNode = document.createTextNode(roleName);
/* 117 */         roleNameElement.appendChild(roleNameNode);
/* 118 */         roleInfoElement.appendChild(roleNameElement);
/*     */         
/*     */ 
/* 121 */         Element mbeanClassElement = document.createElement("mbean-classname");
/* 122 */         Text mbeanClassNode = document.createTextNode(mbeanClassName);
/* 123 */         mbeanClassElement.appendChild(mbeanClassNode);
/* 124 */         roleInfoElement.appendChild(mbeanClassElement);
/*     */         
/*     */ 
/* 127 */         Element descriptionElement = document.createElement("description");
/* 128 */         if (description == null) description = "no description";
/* 129 */         Text descriptionNode = document.createTextNode(description);
/* 130 */         descriptionElement.appendChild(descriptionNode);
/* 131 */         roleInfoElement.appendChild(descriptionElement);
/*     */         
/*     */ 
/* 134 */         Element minDegreeElement = document.createElement("min-degree");
/* 135 */         Text minDegreeNode = document.createTextNode(Integer.toString(minDegree));
/* 136 */         minDegreeElement.appendChild(minDegreeNode);
/* 137 */         roleInfoElement.appendChild(minDegreeElement);
/*     */         
/* 139 */         Element maxDegreeElement = document.createElement("max-degree");
/* 140 */         Text maxDegreeNode = document.createTextNode(Integer.toString(maxDegree));
/* 141 */         maxDegreeElement.appendChild(maxDegreeNode);
/* 142 */         roleInfoElement.appendChild(maxDegreeElement);
/*     */         
/* 144 */         Element readingElement = document.createElement("is-readable");
/* 145 */         String readable = null;
/* 146 */         if (reading) {
/* 147 */           readable = "true";
/*     */         } else
/* 149 */           readable = "false";
/* 150 */         Text readingNode = document.createTextNode(readable);
/* 151 */         readingElement.appendChild(readingNode);
/* 152 */         roleInfoElement.appendChild(readingElement);
/*     */         
/* 154 */         Element writingElement = document.createElement("is-writable");
/* 155 */         String writable = null;
/* 156 */         if (writing) {
/* 157 */           writable = "true";
/*     */         } else
/* 159 */           writable = "false";
/* 160 */         Text writingNode = document.createTextNode(writable);
/* 161 */         writingElement.appendChild(writingNode);
/* 162 */         roleInfoElement.appendChild(writingElement);
/*     */         
/* 164 */         typeNameElement.appendChild(roleInfoElement);
/*     */       }
/*     */       
/*     */ 
/* 168 */       List references = (List)namesMap.get(relationName);
/* 169 */       Iterator j = references.iterator();
/* 170 */       while (j.hasNext())
/*     */       {
/* 172 */         String relationId = (String)j.next();
/* 173 */         Element idElement = document.createElement("relation-id");
/* 174 */         Text idNode = document.createTextNode(relationId);
/* 175 */         idElement.appendChild(idNode);
/* 176 */         typeNameElement.appendChild(idElement);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean checkRelationServiceIsRegistered()
/*     */   {
/* 184 */     Set allMBeans = this.server.queryMBeans(null, null);
/* 185 */     for (Iterator i = allMBeans.iterator(); i.hasNext();)
/*     */     {
/* 187 */       ObjectInstance instance = (ObjectInstance)i.next();
/* 188 */       if (instance.getClassName().equals("javax.management.relation.RelationService"))
/*     */       {
/*     */ 
/* 191 */         this.m_relationObjectName = instance.getObjectName();
/* 192 */         return true;
/*     */       }
/*     */     }
/* 195 */     return false;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/RelationCommandProcessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */