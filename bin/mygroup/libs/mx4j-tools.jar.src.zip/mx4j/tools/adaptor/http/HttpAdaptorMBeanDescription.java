/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import mx4j.MBeanDescriptionAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpAdaptorMBeanDescription
/*     */   extends MBeanDescriptionAdapter
/*     */ {
/*     */   public String getMBeanDescription()
/*     */   {
/*  25 */     return "HttpAdaptor MBean";
/*     */   }
/*     */   
/*     */   public String getConstructorDescription(Constructor ctor)
/*     */   {
/*  30 */     if (ctor.toString().equals("public mx4j.tools.adaptor.http.HttpAdaptor()"))
/*     */     {
/*  32 */       return "Parameterless constructor";
/*     */     }
/*  34 */     if (ctor.toString().equals("public mx4j.tools.adaptor.http.HttpAdaptor(int)"))
/*     */     {
/*  36 */       return "Constructor with a given port";
/*     */     }
/*  38 */     if (ctor.toString().equals("public mx4j.tools.adaptor.http.HttpAdaptor(java.lang.String)"))
/*     */     {
/*  40 */       return "Constructor with a given host";
/*     */     }
/*  42 */     if (ctor.toString().equals("public mx4j.tools.adaptor.http.HttpAdaptor(int,java.lang.String)"))
/*     */     {
/*  44 */       return "Constructor with a given port and host";
/*     */     }
/*  46 */     return super.getConstructorDescription(ctor);
/*     */   }
/*     */   
/*     */   public String getConstructorParameterName(Constructor ctor, int index)
/*     */   {
/*  51 */     if (ctor.toString().equals("public mx4j.tools.adaptor.http.HttpAdaptor(int)"))
/*     */     {
/*  53 */       switch (index)
/*     */       {
/*     */       case 0: 
/*  56 */         return "port";
/*     */       }
/*     */     }
/*  59 */     if (ctor.toString().equals("public mx4j.tools.adaptor.http.HttpAdaptor(java.lang.String)"))
/*     */     {
/*  61 */       switch (index)
/*     */       {
/*     */       case 0: 
/*  64 */         return "host";
/*     */       }
/*     */     }
/*  67 */     if (ctor.toString().equals("public mx4j.tools.adaptor.http.HttpAdaptor(int,java.lang.String)"))
/*     */     {
/*  69 */       switch (index)
/*     */       {
/*     */       case 0: 
/*  72 */         return "port";
/*     */       case 1: 
/*  74 */         return "host";
/*     */       }
/*     */     }
/*  77 */     return super.getConstructorParameterName(ctor, index);
/*     */   }
/*     */   
/*     */   public String getConstructorParameterDescription(Constructor ctor, int index)
/*     */   {
/*  82 */     if (ctor.toString().equals("public mx4j.tools.adaptor.http.HttpAdaptor(int)"))
/*     */     {
/*  84 */       switch (index)
/*     */       {
/*     */       case 0: 
/*  87 */         return "Listening port";
/*     */       }
/*     */     }
/*  90 */     if (ctor.toString().equals("public mx4j.tools.adaptor.http.HttpAdaptor(java.lang.String)"))
/*     */     {
/*  92 */       switch (index)
/*     */       {
/*     */       case 0: 
/*  95 */         return "Listening host";
/*     */       }
/*     */     }
/*  98 */     if (ctor.toString().equals("public mx4j.tools.adaptor.http.HttpAdaptor(int,java.lang.String)"))
/*     */     {
/* 100 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 103 */         return "Listening port";
/*     */       case 1: 
/* 105 */         return "Listening host";
/*     */       }
/*     */     }
/* 108 */     return super.getConstructorParameterDescription(ctor, index);
/*     */   }
/*     */   
/*     */   public String getAttributeDescription(String attribute)
/*     */   {
/* 113 */     if (attribute.equals("AuthenticationMethod"))
/*     */     {
/* 115 */       return "Authentication method (none/basic/digest)";
/*     */     }
/* 117 */     if (attribute.equals("ProcessorClass"))
/*     */     {
/* 119 */       return "PostProcessor MBean";
/*     */     }
/* 121 */     if (attribute.equals("ProcessorNameString"))
/*     */     {
/* 123 */       return "PostProcessor MBean's object name as string";
/*     */     }
/* 125 */     if (attribute.equals("Processor"))
/*     */     {
/* 127 */       return "PostProcessor MBean";
/*     */     }
/* 129 */     if (attribute.equals("ProcessorName"))
/*     */     {
/* 131 */       return "PostProcessor MBean's object name";
/*     */     }
/* 133 */     if (attribute.equals("SocketFactory"))
/*     */     {
/* 135 */       return "Server Socket factory";
/*     */     }
/* 137 */     if (attribute.equals("SocketFactoryName"))
/*     */     {
/* 139 */       return "Server Socket factory's objectname";
/*     */     }
/* 141 */     if (attribute.equals("SocketFactoryNameString"))
/*     */     {
/* 143 */       return "Server Socket factory's objectname as string";
/*     */     }
/* 145 */     if (attribute.equals("Active"))
/*     */     {
/* 147 */       return "Indicates whether the server is active";
/*     */     }
/* 149 */     if (attribute.equals("StartDate"))
/*     */     {
/* 151 */       return "Indicates the date when the server was started";
/*     */     }
/* 153 */     if (attribute.equals("RequestsCount"))
/*     */     {
/* 155 */       return "Total of requested served so far";
/*     */     }
/* 157 */     if (attribute.equals("Version"))
/*     */     {
/* 159 */       return "HttpAdaptor's version";
/*     */     }
/* 161 */     return super.getAttributeDescription(attribute);
/*     */   }
/*     */   
/*     */   public String getOperationDescription(Method operation)
/*     */   {
/* 166 */     String name = operation.getName();
/* 167 */     if (name.equals("addCommandProcessor"))
/*     */     {
/* 169 */       return "Adds a command processor object assigned to a given path";
/*     */     }
/* 171 */     if (name.equals("addCommandProcessor"))
/*     */     {
/* 173 */       return "Adds a command processor object (given a classname) assigned to a given path";
/*     */     }
/* 175 */     if (name.equals("removeCommandProcessor"))
/*     */     {
/* 177 */       return "Removes a command processor for a given path";
/*     */     }
/* 179 */     if (name.equals("start"))
/*     */     {
/* 181 */       return "Starts the HttpAdaptor";
/*     */     }
/* 183 */     if (name.equals("stop"))
/*     */     {
/* 185 */       return "Stops the HttpAdaptor";
/*     */     }
/* 187 */     if (name.equals("addAuthorization"))
/*     */     {
/* 189 */       return "Adds an authorized pair name/password";
/*     */     }
/* 191 */     if (name.equals("removeAuthorization"))
/*     */     {
/* 193 */       return "Removes an authorized user";
/*     */     }
/* 195 */     if (name.equals("setJAASLoginModule"))
/*     */     {
/* 197 */       return "Define the JAAS login module to authenticate users";
/*     */     }
/* 199 */     if (name.equals("addJAASAuthorization"))
/*     */     {
/* 201 */       return "Adds an JAAS login module user name, all users accepted when never called";
/*     */     }
/* 203 */     if (name.equals("removeJAASAuthorization"))
/*     */     {
/* 205 */       return "Removes an authorized JAAS login module user name";
/*     */     }
/* 207 */     if (name.equals("disableJAASLoginModule"))
/*     */     {
/* 209 */       return "Disable the defined JAAS login module functionality";
/*     */     }
/* 211 */     return super.getOperationDescription(operation);
/*     */   }
/*     */   
/*     */   public String getOperationParameterName(Method method, int index)
/*     */   {
/* 216 */     String name = method.getName();
/* 217 */     if (name.equals("addCommandProcessor"))
/*     */     {
/* 219 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 222 */         return "path";
/*     */       case 1: 
/* 224 */         return "processor";
/*     */       }
/*     */     }
/* 227 */     else if (name.equals("addCommandProcessor"))
/*     */     {
/* 229 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 232 */         return "path";
/*     */       case 1: 
/* 234 */         return "processorClass";
/*     */       }
/*     */     }
/* 237 */     else if (name.equals("removeCommandProcessor"))
/*     */     {
/* 239 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 242 */         return "path";
/*     */       }
/*     */     }
/* 245 */     else if (name.equals("addAuthorization"))
/*     */     {
/* 247 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 250 */         return "username";
/*     */       case 1: 
/* 252 */         return "password";
/*     */       }
/*     */     } else {
/* 255 */       if (name.equals("removeAuthorization"))
/*     */       {
/* 257 */         return "username";
/*     */       }
/* 259 */       if (name.equals("setJAASLoginModule"))
/*     */       {
/* 261 */         switch (index)
/*     */         {
/*     */         case 0: 
/* 264 */           return "the JAAS configuration login module name";
/*     */         case 1: 
/* 266 */           return "the JAAS configuration provider class name, null for default provider";
/*     */         }
/*     */         
/* 269 */       } else if (name.equals("addJAASAuthorization"))
/*     */       {
/* 271 */         switch (index)
/*     */         {
/*     */         case 0: 
/* 274 */           return "username";
/*     */         case 1: 
/* 276 */           return "password";
/*     */         }
/*     */         
/* 279 */       } else if (name.equals("removeJAASAuthorization"))
/*     */       {
/* 281 */         return "username"; }
/*     */     }
/* 283 */     return super.getOperationParameterName(method, index);
/*     */   }
/*     */   
/*     */   public String getOperationParameterDescription(Method method, int index)
/*     */   {
/* 288 */     String name = method.getName();
/* 289 */     if (name.equals("addCommandProcessor"))
/*     */     {
/* 291 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 294 */         return "Path assigned to the new command processor";
/*     */       case 1: 
/* 296 */         return "HttpCommandProcessor object";
/*     */       }
/*     */     }
/* 299 */     if (name.equals("addCommandProcessor"))
/*     */     {
/* 301 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 304 */         return "Path assigned to the new command processor";
/*     */       case 1: 
/* 306 */         return "HttpCommandProcessor classname to be instantiated and assigned to the give path";
/*     */       }
/*     */     }
/* 309 */     if (name.equals("removeCommandProcessor"))
/*     */     {
/* 311 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 314 */         return "Path to be removed";
/*     */       }
/*     */     }
/* 317 */     if (name.equals("addAuthorization"))
/*     */     {
/* 319 */       switch (index)
/*     */       {
/*     */       case 0: 
/* 322 */         return "Username";
/*     */       case 1: 
/* 324 */         return "Password";
/*     */       }
/*     */     }
/* 327 */     return super.getOperationParameterDescription(method, index);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/HttpAdaptorMBeanDescription.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */