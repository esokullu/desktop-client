/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanConstructorInfo;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.modelmbean.ModelMBeanInfo;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanCommandProcessor
/*     */   extends HttpCommandProcessorAdaptor
/*     */ {
/*     */   public Document executeRequest(HttpInputStream in)
/*     */     throws IOException, JMException
/*     */   {
/*  43 */     Document document = this.builder.newDocument();
/*     */     
/*  45 */     String name = in.getVariable("objectname");
/*  46 */     ObjectName objectName = null;
/*     */     
/*  48 */     if (name != null)
/*     */     {
/*  50 */       objectName = new ObjectName(name);
/*  51 */       if (!objectName.isPattern())
/*     */       {
/*     */ 
/*  54 */         if (this.server.isRegistered(objectName))
/*     */         {
/*  56 */           Element mb = createMBeanElement(document, objectName, in);
/*  57 */           document.appendChild(mb);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/*  63 */         Set names = new TreeSet(CommandProcessorUtil.createObjectNameComparator());
/*  64 */         names.addAll(this.server.queryNames(objectName, null));
/*  65 */         Element root = document.createElement("Server");
/*  66 */         root.setAttribute("pattern", objectName.toString());
/*  67 */         for (Iterator it = names.iterator(); it.hasNext();)
/*     */         {
/*  69 */           Element mb = createMBeanElement(document, (ObjectName)it.next(), in);
/*  70 */           root.appendChild(mb);
/*     */         }
/*  72 */         document.appendChild(root);
/*     */       }
/*     */     }
/*  75 */     return document;
/*     */   }
/*     */   
/*     */   private Element createMBeanElement(Document document, ObjectName objectName, HttpInputStream in)
/*     */     throws JMException
/*     */   {
/*  81 */     Element root = document.createElement("MBean");
/*     */     
/*  83 */     MBeanInfo info = this.server.getMBeanInfo(objectName);
/*  84 */     root.setAttribute("description", info.getDescription());
/*  85 */     root.setAttribute("classname", info.getClassName());
/*  86 */     root.setAttribute("objectname", objectName.toString());
/*     */     
/*  88 */     if ((info instanceof ModelMBeanInfo))
/*     */     {
/*  90 */       root.setAttribute("model", "true");
/*     */     }
/*  92 */     if (HttpUtil.booleanVariableValue(in, "attributes", true))
/*     */     {
/*  94 */       MBeanAttributeInfo[] attributes = info.getAttributes();
/*  95 */       if (attributes != null)
/*     */       {
/*  97 */         SortedMap sortedAttributes = new TreeMap();
/*  98 */         for (int i = 0; i < attributes.length; i++)
/*     */         {
/* 100 */           Element attribute = document.createElement("Attribute");
/* 101 */           attribute.setAttribute("name", attributes[i].getName());
/* 102 */           attribute.setAttribute("type", attributes[i].getType());
/* 103 */           attribute.setAttribute("description", attributes[i].getDescription());
/* 104 */           attribute.setAttribute("strinit", String.valueOf(CommandProcessorUtil.canCreateParameterValue(attributes[i].getType())));
/* 105 */           if ((attributes[i].isReadable()) && (attributes[i].isWritable()))
/*     */           {
/* 107 */             attribute.setAttribute("availability", "RW");
/*     */           }
/* 109 */           if ((attributes[i].isReadable()) && (!attributes[i].isWritable()))
/*     */           {
/* 111 */             attribute.setAttribute("availability", "RO");
/*     */           }
/* 113 */           if ((!attributes[i].isReadable()) && (attributes[i].isWritable()))
/*     */           {
/* 115 */             attribute.setAttribute("availability", "WO");
/*     */           }
/*     */           try
/*     */           {
/* 119 */             Object attributeValue = this.server.getAttribute(objectName, attributes[i].getName());
/* 120 */             attribute.setAttribute("isnull", attributeValue == null ? "true" : "false");
/* 121 */             if (attributeValue != null)
/*     */             {
/* 123 */               attribute.setAttribute("value", attributeValue.toString());
/* 124 */               if (attributeValue.getClass().isArray())
/*     */               {
/* 126 */                 attribute.setAttribute("aggregation", "array");
/*     */               }
/* 128 */               if ((attributeValue instanceof Collection))
/*     */               {
/* 130 */                 attribute.setAttribute("aggregation", "collection");
/*     */               }
/* 132 */               if ((attributeValue instanceof Map))
/*     */               {
/* 134 */                 attribute.setAttribute("aggregation", "map");
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/* 139 */               attribute.setAttribute("value", "null");
/*     */             }
/*     */             
/*     */           }
/*     */           catch (JMException e)
/*     */           {
/* 145 */             attribute.setAttribute("value", e.getMessage());
/*     */           }
/* 147 */           sortedAttributes.put(attributes[i].getName(), attribute);
/*     */         }
/* 149 */         Iterator keys = sortedAttributes.keySet().iterator();
/* 150 */         while (keys.hasNext())
/*     */         {
/* 152 */           root.appendChild((Element)sortedAttributes.get(keys.next()));
/*     */         }
/*     */       }
/*     */     }
/* 156 */     if (HttpUtil.booleanVariableValue(in, "constructors", true))
/*     */     {
/* 158 */       MBeanConstructorInfo[] constructors = info.getConstructors();
/* 159 */       if (constructors != null)
/*     */       {
/*     */ 
/* 162 */         for (int i = 0; i < constructors.length; i++)
/*     */         {
/* 164 */           Element constructor = document.createElement("Constructor");
/* 165 */           constructor.setAttribute("name", constructors[i].getName());
/* 166 */           constructor.setAttribute("description", constructors[i].getDescription());
/* 167 */           addParameters(constructor, document, constructors[i].getSignature());
/* 168 */           root.appendChild(constructor);
/*     */         }
/*     */       }
/*     */     }
/* 172 */     if (HttpUtil.booleanVariableValue(in, "operations", true))
/*     */     {
/* 174 */       MBeanOperationInfo[] operations = info.getOperations();
/* 175 */       if (operations != null)
/*     */       {
/* 177 */         for (int i = 0; i < operations.length; i++)
/*     */         {
/* 179 */           Element operation = document.createElement("Operation");
/* 180 */           operation.setAttribute("name", operations[i].getName());
/* 181 */           operation.setAttribute("description", operations[i].getDescription());
/* 182 */           operation.setAttribute("return", operations[i].getReturnType());
/* 183 */           switch (operations[i].getImpact())
/*     */           {
/*     */           case 3: 
/* 186 */             operation.setAttribute("impact", "unknown");
/* 187 */             break;
/*     */           case 1: 
/* 189 */             operation.setAttribute("impact", "action");
/* 190 */             break;
/*     */           case 0: 
/* 192 */             operation.setAttribute("impact", "info");
/* 193 */             break;
/*     */           case 2: 
/* 195 */             operation.setAttribute("impact", "action_info");
/*     */           }
/*     */           
/* 198 */           addParameters(operation, document, operations[i].getSignature());
/* 199 */           root.appendChild(operation);
/*     */         }
/*     */       }
/*     */     }
/* 203 */     if (HttpUtil.booleanVariableValue(in, "notifications", true))
/*     */     {
/* 205 */       MBeanNotificationInfo[] notifications = info.getNotifications();
/* 206 */       if (notifications != null)
/*     */       {
/* 208 */         for (int i = 0; i < notifications.length; i++)
/*     */         {
/* 210 */           Element notification = document.createElement("Notification");
/* 211 */           notification.setAttribute("name", notifications[i].getName());
/* 212 */           notification.setAttribute("description", notifications[i].getDescription());
/* 213 */           String[] types = notifications[i].getNotifTypes();
/* 214 */           for (int j = 0; j < types.length; j++)
/*     */           {
/* 216 */             Element type = document.createElement("Type");
/* 217 */             type.setAttribute("name", types[j]);
/* 218 */             notification.appendChild(type);
/*     */           }
/* 220 */           root.appendChild(notification);
/*     */         }
/*     */       }
/*     */     }
/* 224 */     return root;
/*     */   }
/*     */   
/*     */   protected void addParameters(Element node, Document document, MBeanParameterInfo[] parameters)
/*     */   {
/* 229 */     for (int j = 0; j < parameters.length; j++)
/*     */     {
/* 231 */       Element parameter = document.createElement("Parameter");
/* 232 */       parameter.setAttribute("name", parameters[j].getName());
/* 233 */       parameter.setAttribute("description", parameters[j].getDescription());
/* 234 */       parameter.setAttribute("type", parameters[j].getType());
/* 235 */       parameter.setAttribute("strinit", String.valueOf(CommandProcessorUtil.canCreateParameterValue(parameters[j].getType())));
/*     */       
/* 237 */       parameter.setAttribute("id", "" + j);
/* 238 */       node.appendChild(parameter);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/MBeanCommandProcessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */