/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InvokeOperationCommandProcessor
/*     */   extends HttpCommandProcessorAdaptor
/*     */ {
/*     */   public Document executeRequest(HttpInputStream in)
/*     */     throws IOException, JMException
/*     */   {
/*  37 */     Document document = this.builder.newDocument();
/*     */     
/*  39 */     Element root = document.createElement("MBeanOperation");
/*  40 */     document.appendChild(root);
/*  41 */     Element operationElement = document.createElement("Operation");
/*  42 */     operationElement.setAttribute("operation", "invoke");
/*  43 */     root.appendChild(operationElement);
/*     */     
/*  45 */     String objectVariable = in.getVariable("objectname");
/*  46 */     String operationVariable = in.getVariable("operation");
/*  47 */     if ((objectVariable == null) || (objectVariable.equals("")) || 
/*  48 */       (operationVariable == null) || (operationVariable.equals("")))
/*     */     {
/*  50 */       operationElement.setAttribute("result", "error");
/*  51 */       operationElement.setAttribute("errorMsg", "Incorrect parameters in the request");
/*  52 */       return document;
/*     */     }
/*  54 */     operationElement.setAttribute("objectname", objectVariable);
/*  55 */     List types = new ArrayList();
/*  56 */     List values = new ArrayList();
/*  57 */     int i = 0;
/*  58 */     boolean unmatchedParameters = false;
/*  59 */     boolean valid = false;
/*     */     do
/*     */     {
/*  62 */       String parameterType = in.getVariable("type" + i);
/*  63 */       String parameterValue = in.getVariable("value" + i);
/*  64 */       valid = (parameterType != null) && (parameterValue != null);
/*  65 */       if (valid)
/*     */       {
/*  67 */         types.add(parameterType);
/*  68 */         Object value = null;
/*     */         try
/*     */         {
/*  71 */           value = CommandProcessorUtil.createParameterValue(parameterType, parameterValue);
/*     */ 
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*  76 */           operationElement.setAttribute("result", "error");
/*  77 */           operationElement.setAttribute("errorMsg", "Parameter " + i + ": " + parameterValue + " cannot be converted to type " + parameterType);
/*  78 */           return document;
/*     */         }
/*  80 */         if (value != null)
/*     */         {
/*  82 */           values.add(value);
/*     */         }
/*     */       }
/*  85 */       if (((parameterType == null ? 1 : 0) ^ (parameterValue == null ? 1 : 0)) != 0)
/*     */       {
/*  87 */         unmatchedParameters = true;
/*  88 */         break;
/*     */       }
/*  90 */       i++;
/*  60 */     } while (
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */       valid);
/*  93 */     if ((objectVariable == null) || (objectVariable.equals("")) || 
/*  94 */       (operationVariable == null) || (operationVariable.equals("")))
/*     */     {
/*  96 */       operationElement.setAttribute("result", "error");
/*  97 */       operationElement.setAttribute("errorMsg", "Incorrect parameters in the request");
/*  98 */       return document;
/*     */     }
/* 100 */     if (unmatchedParameters)
/*     */     {
/* 102 */       operationElement.setAttribute("result", "error");
/* 103 */       operationElement.setAttribute("errorMsg", "count of parameter types doesn't match count of parameter values");
/* 104 */       return document;
/*     */     }
/* 106 */     ObjectName name = null;
/*     */     try
/*     */     {
/* 109 */       name = new ObjectName(objectVariable);
/*     */     }
/*     */     catch (MalformedObjectNameException e)
/*     */     {
/* 113 */       operationElement.setAttribute("result", "error");
/* 114 */       operationElement.setAttribute("errorMsg", "Malformed object name");
/* 115 */       return document;
/*     */     }
/*     */     
/* 118 */     if (this.server.isRegistered(name))
/*     */     {
/* 120 */       MBeanInfo info = this.server.getMBeanInfo(name);
/* 121 */       MBeanOperationInfo[] operations = info.getOperations();
/* 122 */       boolean match = false;
/* 123 */       if (operations != null)
/*     */       {
/* 125 */         for (int j = 0; j < operations.length; j++)
/*     */         {
/* 127 */           if (operations[j].getName().equals(operationVariable))
/*     */           {
/* 129 */             MBeanParameterInfo[] parameters = operations[j].getSignature();
/* 130 */             if (parameters.length == types.size())
/*     */             {
/*     */ 
/*     */ 
/* 134 */               Iterator k = types.iterator();
/* 135 */               boolean signatureMatch = true;
/* 136 */               for (int p = 0; p < types.size(); p++)
/*     */               {
/* 138 */                 if (!parameters[p].getType().equals(k.next()))
/*     */                 {
/* 140 */                   signatureMatch = false;
/* 141 */                   break;
/*     */                 }
/*     */               }
/* 144 */               match = signatureMatch;
/*     */             }
/* 146 */           } else { if (match) {
/*     */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 152 */       if (!match)
/*     */       {
/* 154 */         operationElement.setAttribute("result", "error");
/* 155 */         operationElement.setAttribute("errorMsg", "Operation singature has no match in the MBean");
/*     */       }
/*     */       else
/*     */       {
/*     */         try
/*     */         {
/* 161 */           Object[] params = values.toArray();
/* 162 */           String[] signature = new String[types.size()];
/* 163 */           types.toArray(signature);
/* 164 */           Object returnValue = this.server.invoke(name, operationVariable, params, signature);
/* 165 */           operationElement.setAttribute("result", "success");
/* 166 */           if (returnValue != null)
/*     */           {
/* 168 */             operationElement.setAttribute("returnclass", returnValue.getClass().getName());
/*     */             
/* 170 */             operationElement.setAttribute("return", getResultAsString(returnValue));
/*     */           }
/*     */           else
/*     */           {
/* 174 */             operationElement.setAttribute("returnclass", null);
/* 175 */             operationElement.setAttribute("return", null);
/*     */           }
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 180 */           operationElement.setAttribute("result", "error");
/* 181 */           operationElement.setAttribute("errorMsg", e.getMessage());
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */     }
/* 187 */     else if (name != null)
/*     */     {
/* 189 */       operationElement.setAttribute("result", "error");
/* 190 */       operationElement.setAttribute("errorMsg", "MBean " + name + " not registered");
/*     */     }
/*     */     
/* 193 */     return document;
/*     */   }
/*     */   
/*     */   private String getResultAsString(Object result) {
/* 197 */     if (result == null) return "";
/* 198 */     String rtrVal = null;
/*     */     
/* 200 */     if ((result instanceof Object[])) {
/* 201 */       StringBuffer tmp = new StringBuffer();
/* 202 */       Object[] array = (Object[])result;
/* 203 */       for (int i = 0; i < array.length; i++) {
/* 204 */         if (array[i] != null) {
/* 205 */           tmp.append(array[i].toString());
/*     */         } else {
/* 207 */           tmp.append("null");
/*     */         }
/* 209 */         if (i < array.length) tmp.append("\n");
/*     */       }
/* 211 */       rtrVal = tmp.toString();
/* 212 */     } else if ((result instanceof long[])) {
/* 213 */       StringBuffer tmp = new StringBuffer();
/* 214 */       long[] array = (long[])result;
/* 215 */       for (int i = 0; i < array.length; i++) {
/* 216 */         tmp.append(array[i]);
/* 217 */         if (i < array.length) tmp.append("\n");
/*     */       }
/* 219 */       rtrVal = tmp.toString();
/* 220 */     } else if ((result instanceof double[])) {
/* 221 */       StringBuffer tmp = new StringBuffer();
/* 222 */       double[] array = (double[])result;
/* 223 */       for (int i = 0; i < array.length; i++) {
/* 224 */         tmp.append(array[i]);
/* 225 */         if (i < array.length) tmp.append("\n");
/*     */       }
/* 227 */       rtrVal = tmp.toString();
/* 228 */     } else if ((result instanceof float[])) {
/* 229 */       StringBuffer tmp = new StringBuffer();
/* 230 */       float[] array = (float[])result;
/* 231 */       for (int i = 0; i < array.length; i++) {
/* 232 */         tmp.append(array[i]);
/* 233 */         if (i < array.length) tmp.append("\n");
/*     */       }
/* 235 */       rtrVal = tmp.toString();
/* 236 */     } else if ((result instanceof short[])) {
/* 237 */       StringBuffer tmp = new StringBuffer();
/* 238 */       short[] array = (short[])result;
/* 239 */       for (int i = 0; i < array.length; i++) {
/* 240 */         tmp.append(array[i]);
/* 241 */         if (i < array.length) tmp.append("\n");
/*     */       }
/* 243 */       rtrVal = tmp.toString();
/* 244 */     } else if ((result instanceof int[])) {
/* 245 */       StringBuffer tmp = new StringBuffer();
/* 246 */       int[] array = (int[])result;
/* 247 */       for (int i = 0; i < array.length; i++) {
/* 248 */         tmp.append(array[i]);
/* 249 */         if (i < array.length) tmp.append("\n");
/*     */       }
/* 251 */       rtrVal = tmp.toString();
/* 252 */     } else if ((result instanceof byte[])) {
/* 253 */       StringBuffer tmp = new StringBuffer();
/* 254 */       byte[] array = (byte[])result;
/* 255 */       for (int i = 0; i < array.length; i++) {
/* 256 */         tmp.append(array[i]);
/* 257 */         if (i < array.length) tmp.append("\n");
/*     */       }
/* 259 */       rtrVal = tmp.toString();
/* 260 */     } else if ((result instanceof char[])) {
/* 261 */       rtrVal = new String((char[])result);
/*     */     } else {
/* 263 */       rtrVal = result.toString();
/*     */     }
/* 265 */     return rtrVal;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/InvokeOperationCommandProcessor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */