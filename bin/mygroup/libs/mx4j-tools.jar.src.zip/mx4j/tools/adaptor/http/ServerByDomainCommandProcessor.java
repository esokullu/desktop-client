/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerByDomainCommandProcessor
/*     */   extends HttpCommandProcessorAdaptor
/*     */ {
/*     */   public Document executeRequest(HttpInputStream in)
/*     */     throws IOException, JMException
/*     */   {
/*  39 */     Document document = this.builder.newDocument();
/*     */     
/*  41 */     Element root = document.createElement("Server");
/*  42 */     document.appendChild(root);
/*     */     
/*  44 */     String targetClass = in.getVariable("instanceof");
/*  45 */     String queryNames = in.getVariable("querynames");
/*  46 */     ObjectName query = null;
/*  47 */     if (queryNames != null)
/*     */     {
/*     */       try
/*     */       {
/*  51 */         query = new ObjectName(queryNames);
/*     */       }
/*     */       catch (MalformedObjectNameException e)
/*     */       {
/*  55 */         Element exceptionElement = document.createElement("Exception");
/*  56 */         exceptionElement.setAttribute("errorMsg", e.getMessage());
/*  57 */         root.appendChild(exceptionElement);
/*  58 */         return document;
/*     */       }
/*     */     }
/*  61 */     Set mbeans = this.server.queryMBeans(query, null);
/*  62 */     Iterator i = mbeans.iterator();
/*     */     
/*  64 */     Map domains = new TreeMap();
/*  65 */     while (i.hasNext())
/*     */     {
/*  67 */       ObjectInstance instance = (ObjectInstance)i.next();
/*  68 */       ObjectName name = instance.getObjectName();
/*  69 */       String domain = name.getDomain();
/*  70 */       if (domains.containsKey(domain))
/*     */       {
/*  72 */         ((Set)domains.get(domain)).add(name);
/*     */       }
/*     */       else
/*     */       {
/*  76 */         Set objects = new TreeSet(CommandProcessorUtil.createObjectNameComparator());
/*  77 */         objects.add(name);
/*  78 */         domains.put(domain, objects);
/*     */       }
/*     */     }
/*  81 */     i = domains.keySet().iterator();
/*  82 */     while (i.hasNext())
/*     */     {
/*  84 */       String domain = (String)i.next();
/*  85 */       Element domainElement = document.createElement("Domain");
/*  86 */       root.appendChild(domainElement);
/*  87 */       domainElement.setAttribute("name", domain);
/*  88 */       Set names = (Set)domains.get(domain);
/*  89 */       Iterator j = names.iterator();
/*  90 */       while (j.hasNext())
/*     */       {
/*  92 */         ObjectName targetName = (ObjectName)j.next();
/*  93 */         if ((targetClass == null) || (this.server.isInstanceOf(targetName, targetClass)))
/*     */         {
/*     */ 
/*     */ 
/*  97 */           Element mBeanElement = document.createElement("MBean");
/*  98 */           mBeanElement.setAttribute("objectname", targetName.toString());
/*  99 */           MBeanInfo info = this.server.getMBeanInfo(targetName);
/* 100 */           mBeanElement.setAttribute("description", info.getDescription());
/* 101 */           mBeanElement.setAttribute("classname", info.getClassName());
/* 102 */           domainElement.appendChild(mBeanElement);
/*     */         }
/*     */       } }
/* 105 */     return document;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/ServerByDomainCommandProcessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */