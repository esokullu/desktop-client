/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultProcessor
/*     */   implements ProcessorMBean
/*     */ {
/*     */   private static final String ENCODING = "UTF-8";
/*  34 */   private boolean canonical = false;
/*     */   
/*     */   public String getName()
/*     */   {
/*  38 */     return "Default XML Processor";
/*     */   }
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/*  43 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */   
/*     */   public void writeResponse(HttpOutputStream out, HttpInputStream in, Document document)
/*     */     throws IOException
/*     */   {
/*  49 */     out.setCode(200);
/*  50 */     out.setHeader("Content-Type", "text/xml");
/*  51 */     out.sendHeaders();
/*     */     
/*  53 */     print(new PrintWriter(out), document);
/*     */     
/*  55 */     ByteArrayOutputStream o = new ByteArrayOutputStream();
/*     */     
/*  57 */     print(new PrintWriter(o), document);
/*     */     
/*  59 */     Logger logger = getLogger();
/*  60 */     if (logger.isEnabledFor(10)) logger.debug(new String(o.toByteArray()));
/*     */   }
/*     */   
/*     */   public void writeError(HttpOutputStream out, HttpInputStream in, Exception e)
/*     */     throws IOException
/*     */   {
/*  66 */     if ((e instanceof HttpException))
/*     */     {
/*  68 */       out.setCode(((HttpException)e).getCode());
/*  69 */       out.setHeader("Content-Type", "text/xml");
/*  70 */       out.sendHeaders();
/*  71 */       print(new PrintWriter(out), ((HttpException)e).getResponseDoc());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String preProcess(String path)
/*     */   {
/*  78 */     if (path.equals("/"))
/*     */     {
/*  80 */       path = "/server";
/*     */     }
/*  82 */     return path;
/*     */   }
/*     */   
/*     */ 
/*     */   public String notFoundElement(String path, HttpOutputStream out, HttpInputStream in)
/*     */     throws IOException, HttpException
/*     */   {
/*  89 */     throw new HttpException(404, "Path " + path + " not found");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void print(PrintWriter out, Node node)
/*     */   {
/*  96 */     if (node == null) { return;
/*     */     }
/*  98 */     int type = node.getNodeType();
/*  99 */     switch (type)
/*     */     {
/*     */ 
/*     */ 
/*     */     case 9: 
/* 104 */       if (!this.canonical)
/*     */       {
/* 106 */         out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
/*     */       }
/*     */       
/* 109 */       NodeList children = node.getChildNodes();
/* 110 */       for (int iChild = 0; iChild < children.getLength(); iChild++)
/*     */       {
/* 112 */         print(out, children.item(iChild));
/*     */       }
/* 114 */       out.flush();
/* 115 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     case 1: 
/* 121 */       out.print('<');
/* 122 */       out.print(node.getNodeName());
/*     */       
/* 124 */       Attr[] attrs = sortAttributes(node.getAttributes());
/* 125 */       for (int i = 0; i < attrs.length; i++)
/*     */       {
/* 127 */         Attr attr = attrs[i];
/* 128 */         out.print(' ');
/* 129 */         out.print(attr.getNodeName());
/* 130 */         out.print("=\"");
/* 131 */         out.print(normalize(attr.getNodeValue()));
/* 132 */         out.print('"');
/*     */       }
/* 134 */       out.print('>');
/*     */       
/* 136 */       NodeList children = node.getChildNodes();
/* 137 */       if (children != null)
/*     */       {
/* 139 */         int len = children.getLength();
/* 140 */         for (int i = 0; i < len; i++)
/*     */         {
/* 142 */           print(out, children.item(i));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       break;
/*     */     case 5: 
/* 151 */       if (this.canonical)
/*     */       {
/* 153 */         NodeList children = node.getChildNodes();
/* 154 */         if (children != null)
/*     */         {
/* 156 */           int len = children.getLength();
/* 157 */           for (int i = 0; i < len; i++)
/*     */           {
/* 159 */             print(out, children.item(i));
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 165 */         out.print('&');
/* 166 */         out.print(node.getNodeName());
/* 167 */         out.print(';');
/*     */       }
/* 169 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     case 4: 
/* 175 */       if (this.canonical)
/*     */       {
/* 177 */         out.print(normalize(node.getNodeValue()));
/*     */       }
/*     */       else
/*     */       {
/* 181 */         out.print("<![CDATA[");
/* 182 */         out.print(node.getNodeValue());
/* 183 */         out.print("]]>");
/*     */       }
/* 185 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     case 3: 
/* 191 */       out.print(normalize(node.getNodeValue()));
/* 192 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     case 7: 
/* 198 */       out.print("<?");
/* 199 */       out.print(node.getNodeName());
/* 200 */       String data = node.getNodeValue();
/* 201 */       if ((data != null) && (data.length() > 0))
/*     */       {
/* 203 */         out.print(' ');
/* 204 */         out.print(data);
/*     */       }
/* 206 */       out.println("?>");
/* 207 */       break;
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 212 */     if (type == 1)
/*     */     {
/* 214 */       out.print("</");
/* 215 */       out.print(node.getNodeName());
/* 216 */       out.print('>');
/*     */     }
/*     */     
/* 219 */     out.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Attr[] sortAttributes(NamedNodeMap attrs)
/*     */   {
/* 230 */     int len = attrs != null ? attrs.getLength() : 0;
/* 231 */     Attr[] array = new Attr[len];
/* 232 */     for (int i = 0; i < len; i++) { array[i] = ((Attr)attrs.item(i));
/*     */     }
/* 234 */     Arrays.sort(array, new Comparator()
/*     */     {
/*     */       public int compare(Object o1, Object o2)
/*     */       {
/* 238 */         Attr attr1 = (Attr)o1;
/* 239 */         Attr attr2 = (Attr)o2;
/* 240 */         return attr1.getNodeName().compareTo(attr2.getNodeName());
/*     */       }
/* 242 */     });
/* 243 */     return array;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String normalize(String s)
/*     */   {
/* 254 */     StringBuffer str = new StringBuffer();
/*     */     
/* 256 */     int len = s != null ? s.length() : 0;
/* 257 */     for (int i = 0; i < len; i++)
/*     */     {
/* 259 */       char ch = s.charAt(i);
/* 260 */       switch (ch)
/*     */       {
/*     */ 
/*     */       case '<': 
/* 264 */         str.append("&lt;");
/* 265 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */       case '>': 
/* 270 */         str.append("&gt;");
/* 271 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */       case '&': 
/* 276 */         str.append("&amp;");
/* 277 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */       case '"': 
/* 282 */         str.append("&quot;");
/* 283 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */       case '\'': 
/* 288 */         str.append("&apos;");
/* 289 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */       case '\n': 
/*     */       case '\r': 
/* 295 */         if (this.canonical)
/*     */         {
/* 297 */           str.append("&#");
/* 298 */           str.append(Integer.toString(ch));
/* 299 */           str.append(';');
/*     */         }
/*     */         else
/*     */         {
/* 303 */           str.append(ch);
/*     */         }
/* 305 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */       default: 
/* 310 */         str.append(ch);
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 315 */     return str.toString();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/DefaultProcessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */