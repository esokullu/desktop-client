/*     */ package mx4j.tools.adaptor.http;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XSLTProcessorMBeanDescription
/*     */   extends ProcessorMBeanDescription
/*     */ {
/*     */   public String getMBeanDescription()
/*     */   {
/*  22 */     return "XSLTPostProcessor which passes the XML message from the HttpAdaptor through a XSL transformation";
/*     */   }
/*     */   
/*     */   public String getAttributeDescription(String attribute)
/*     */   {
/*  27 */     if (attribute.equals("File"))
/*     */     {
/*  29 */       return "The jar/zip file or the directory where to find the XSL files";
/*     */     }
/*  31 */     if (attribute.equals("PathInJar"))
/*     */     {
/*  33 */       return "The path of the XSL templates inside a jar file";
/*     */     }
/*  35 */     if (attribute.equals("DefaultPage"))
/*     */     {
/*  37 */       return "The default start page";
/*     */     }
/*  39 */     if (attribute.equals("UseJar"))
/*     */     {
/*  41 */       return "Indicates whether XSL files are contained in an external jar/zip file";
/*     */     }
/*  43 */     if (attribute.equals("UsePath"))
/*     */     {
/*  45 */       return "Indicates whether XSL files are contained in an external path";
/*     */     }
/*  47 */     if (attribute.equals("UseCache"))
/*     */     {
/*  49 */       return "Indicates whether the XSL Templates are cached";
/*     */     }
/*  51 */     if (attribute.equals("Locale"))
/*     */     {
/*  53 */       return "The locale used to internationalize the output";
/*     */     }
/*  55 */     if (attribute.equals("LocaleString"))
/*     */     {
/*  57 */       return "Sets the locale used to internationalize the output, as a string";
/*     */     }
/*  59 */     return super.getAttributeDescription(attribute);
/*     */   }
/*     */   
/*     */   public String getOperationDescription(Method operation)
/*     */   {
/*  64 */     String name = operation.getName();
/*  65 */     if (name.equals("addMimeType"))
/*     */     {
/*  67 */       return "Adds a MIME type to the default list";
/*     */     }
/*  69 */     return super.getOperationDescription(operation);
/*     */   }
/*     */   
/*     */   public String getOperationParameterName(Method method, int index)
/*     */   {
/*  74 */     String name = method.getName();
/*  75 */     if (name.equals("addMimeType"))
/*     */     {
/*  77 */       switch (index)
/*     */       {
/*     */       case 0: 
/*  80 */         return "extension";
/*     */       case 1: 
/*  82 */         return "mimeType";
/*     */       }
/*     */     }
/*  85 */     return super.getOperationParameterName(method, index);
/*     */   }
/*     */   
/*     */   public String getOperationParameterDescription(Method method, int index)
/*     */   {
/*  90 */     String name = method.getName();
/*  91 */     if (name.equals("addMimeType"))
/*     */     {
/*  93 */       switch (index)
/*     */       {
/*     */       case 0: 
/*  96 */         return "The extension of the file";
/*     */       case 1: 
/*  98 */         return "The MIME type for the extension";
/*     */       }
/*     */     }
/* 101 */     return super.getOperationParameterDescription(method, index);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/XSLTProcessorMBeanDescription.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */