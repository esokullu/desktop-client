package mx4j.tools.adaptor.http;

import java.util.Locale;

public abstract interface XSLTProcessorMBean
  extends ProcessorMBean
{
  public abstract void setFile(String paramString);
  
  public abstract String getFile();
  
  public abstract String getPathInJar();
  
  public abstract void setPathInJar(String paramString);
  
  public abstract String getDefaultPage();
  
  public abstract void setDefaultPage(String paramString);
  
  public abstract boolean isUseJar();
  
  public abstract boolean isUsePath();
  
  public abstract void addMimeType(String paramString1, String paramString2);
  
  public abstract void setUseCache(boolean paramBoolean);
  
  public abstract boolean isUseCache();
  
  public abstract Locale getLocale();
  
  public abstract void setLocale(Locale paramLocale);
  
  public abstract void setLocaleString(String paramString);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/XSLTProcessorMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */