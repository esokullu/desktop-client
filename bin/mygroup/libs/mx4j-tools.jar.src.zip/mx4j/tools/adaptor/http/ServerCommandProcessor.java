/*    */ package mx4j.tools.adaptor.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ import javax.management.JMException;
/*    */ import javax.management.MBeanInfo;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.MalformedObjectNameException;
/*    */ import javax.management.ObjectInstance;
/*    */ import javax.management.ObjectName;
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerCommandProcessor
/*    */   extends HttpCommandProcessorAdaptor
/*    */ {
/*    */   public Document executeRequest(HttpInputStream in)
/*    */     throws IOException, JMException
/*    */   {
/* 37 */     Document document = this.builder.newDocument();
/*    */     
/* 39 */     Element root = document.createElement("Server");
/* 40 */     document.appendChild(root);
/*    */     
/* 42 */     String classVariable = in.getVariable("instanceof");
/* 43 */     String queryNames = in.getVariable("querynames");
/* 44 */     Set mbeans = null;
/* 45 */     ObjectName query = null;
/* 46 */     if (queryNames != null)
/*    */     {
/*    */       try
/*    */       {
/* 50 */         query = new ObjectName(queryNames);
/* 51 */         mbeans = new TreeSet(CommandProcessorUtil.createObjectInstanceComparator());
/* 52 */         mbeans.addAll(this.server.queryMBeans(query, null));
/*    */       }
/*    */       catch (MalformedObjectNameException e)
/*    */       {
/* 56 */         Element exceptionElement = document.createElement("Exception");
/* 57 */         exceptionElement.setAttribute("errorMsg", e.getMessage());
/* 58 */         root.appendChild(exceptionElement);
/* 59 */         return document;
/*    */       }
/*    */     }
/*    */     else
/*    */     {
/* 64 */       mbeans = new TreeSet(CommandProcessorUtil.createObjectInstanceComparator());
/* 65 */       mbeans.addAll(this.server.queryMBeans(null, null));
/*    */     }
/* 67 */     Iterator i = mbeans.iterator();
/* 68 */     while (i.hasNext())
/*    */     {
/* 70 */       ObjectInstance instance = (ObjectInstance)i.next();
/* 71 */       if ((classVariable == null) || (classVariable.equals(instance.getClassName())))
/*    */       {
/*    */ 
/*    */ 
/* 75 */         Element mBeanElement = document.createElement("MBean");
/* 76 */         mBeanElement.setAttribute("objectname", instance.getObjectName().toString());
/* 77 */         mBeanElement.setAttribute("classname", instance.getClassName());
/* 78 */         MBeanInfo info = this.server.getMBeanInfo(instance.getObjectName());
/* 79 */         mBeanElement.setAttribute("description", info.getDescription());
/* 80 */         root.appendChild(mBeanElement);
/*    */       } }
/* 82 */     return document;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/adaptor/http/ServerCommandProcessor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */