/*    */ package mx4j.tools.config;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigurationException
/*    */   extends Exception
/*    */ {
/*    */   private Throwable cause;
/*    */   
/*    */   public ConfigurationException()
/*    */   {
/* 23 */     this(null, null);
/*    */   }
/*    */   
/*    */   public ConfigurationException(String message)
/*    */   {
/* 28 */     this(message, null);
/*    */   }
/*    */   
/*    */   public ConfigurationException(Throwable cause)
/*    */   {
/* 33 */     this(null, cause);
/*    */   }
/*    */   
/*    */   public ConfigurationException(String message, Throwable cause)
/*    */   {
/* 38 */     super(message);
/* 39 */     this.cause = cause;
/*    */   }
/*    */   
/*    */   public Throwable getCause()
/*    */   {
/* 44 */     return this.cause;
/*    */   }
/*    */   
/*    */   public void printStackTrace()
/*    */   {
/* 49 */     if (this.cause == null)
/*    */     {
/* 51 */       super.printStackTrace();
/*    */     }
/*    */     else
/*    */     {
/* 55 */       synchronized (System.err)
/*    */       {
/* 57 */         System.err.println(this);
/* 58 */         this.cause.printStackTrace();
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void printStackTrace(PrintStream stream)
/*    */   {
/* 65 */     if (this.cause == null)
/*    */     {
/* 67 */       super.printStackTrace(stream);
/*    */     }
/*    */     else
/*    */     {
/* 71 */       synchronized (stream)
/*    */       {
/* 73 */         stream.println(this);
/* 74 */         this.cause.printStackTrace(stream);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void printStackTrace(PrintWriter writer)
/*    */   {
/* 81 */     if (this.cause == null)
/*    */     {
/* 83 */       super.printStackTrace(writer);
/*    */     }
/*    */     else
/*    */     {
/* 87 */       synchronized (writer)
/*    */       {
/* 89 */         writer.println(this);
/* 90 */         this.cause.printStackTrace(writer);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/config/ConfigurationException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */