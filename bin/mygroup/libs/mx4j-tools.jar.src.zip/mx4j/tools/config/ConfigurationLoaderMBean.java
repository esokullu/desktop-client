package mx4j.tools.config;

import java.io.Reader;

public abstract interface ConfigurationLoaderMBean
{
  public abstract void startup(Reader paramReader)
    throws ConfigurationException;
  
  public abstract void shutdown()
    throws ConfigurationException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/config/ConfigurationLoaderMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */