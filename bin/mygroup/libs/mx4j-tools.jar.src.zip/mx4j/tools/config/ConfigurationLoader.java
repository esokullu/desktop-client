/*     */ package mx4j.tools.config;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.management.MBeanRegistration;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationLoader
/*     */   implements ConfigurationLoaderMBean, MBeanRegistration
/*     */ {
/*     */   private MBeanServer server;
/*     */   private ConfigurationBuilder builder;
/*     */   private ConfigurationBuilder.Node root;
/*     */   
/*     */   public ConfigurationLoader()
/*     */   {
/*  38 */     this(null, new DefaultConfigurationBuilder());
/*     */   }
/*     */   
/*     */   public ConfigurationLoader(ConfigurationBuilder builder)
/*     */   {
/*  43 */     this(null, builder);
/*     */   }
/*     */   
/*     */   public ConfigurationLoader(MBeanServer server)
/*     */   {
/*  48 */     this(server, new DefaultConfigurationBuilder());
/*     */   }
/*     */   
/*     */   public ConfigurationLoader(MBeanServer server, ConfigurationBuilder builder)
/*     */   {
/*  53 */     this.server = server;
/*  54 */     if (builder == null) throw new IllegalArgumentException("ConfigurationBuilder cannot be null");
/*  55 */     this.builder = builder;
/*     */   }
/*     */   
/*     */   public ObjectName preRegister(MBeanServer server, ObjectName name) throws Exception
/*     */   {
/*  60 */     this.server = server;
/*  61 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */   public void postRegister(Boolean registered) {}
/*     */   
/*     */ 
/*     */   public void preDeregister()
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */ 
/*     */   public void postDeregister() {}
/*     */   
/*     */   public void startup(Reader source)
/*     */     throws ConfigurationException
/*     */   {
/*  78 */     if (this.server == null) { throw new ConfigurationException("Cannot startup the configuration, MBeanServer is not specified");
/*     */     }
/*     */     try
/*     */     {
/*  82 */       DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
/*  83 */       DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
/*  84 */       InputSource src = new InputSource(source);
/*  85 */       Document document = documentBuilder.parse(src);
/*     */       
/*  87 */       Element xmlRoot = document.getDocumentElement();
/*  88 */       this.root = this.builder.createConfigurationNode(xmlRoot);
/*  89 */       parse(xmlRoot, this.root);
/*  90 */       this.root.configure(this.server);
/*     */     }
/*     */     catch (ConfigurationException x)
/*     */     {
/*  94 */       throw x;
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/*  98 */       throw new ConfigurationException(x);
/*     */     }
/*     */   }
/*     */   
/*     */   public void shutdown() throws ConfigurationException
/*     */   {
/* 104 */     this.root.configure(null);
/*     */   }
/*     */   
/*     */   private void parse(Element xmlNode, ConfigurationBuilder.Node node) throws ConfigurationException
/*     */   {
/* 109 */     NamedNodeMap attributes = xmlNode.getAttributes();
/* 110 */     if ((attributes != null) && (attributes.getLength() > 0))
/*     */     {
/* 112 */       node.setAttributes(attributes);
/*     */     }
/*     */     
/* 115 */     List elements = getChildrenElements(xmlNode);
/* 116 */     if (elements != null)
/*     */     {
/* 118 */       for (int i = 0; i < elements.size(); i++)
/*     */       {
/* 120 */         Element xmlChild = (Element)elements.get(i);
/* 121 */         ConfigurationBuilder.Node child = this.builder.createConfigurationNode(xmlChild);
/* 122 */         node.addChild(child);
/* 123 */         parse(xmlChild, child);
/*     */       }
/*     */     }
/*     */     
/* 127 */     String value = getNodeValue(xmlNode);
/* 128 */     node.setText(value);
/*     */   }
/*     */   
/*     */   private List getChildrenElements(Element xmlNode)
/*     */   {
/* 133 */     NodeList xmlChildren = xmlNode.getChildNodes();
/* 134 */     if (xmlChildren == null) { return null;
/*     */     }
/* 136 */     ArrayList children = new ArrayList();
/* 137 */     for (int i = 0; i < xmlChildren.getLength(); i++)
/*     */     {
/* 139 */       Node xmlChild = xmlChildren.item(i);
/* 140 */       if (xmlChild.getNodeType() == 1) children.add(xmlChild);
/*     */     }
/* 142 */     return children;
/*     */   }
/*     */   
/*     */   private String getNodeValue(Element xmlNode)
/*     */   {
/* 147 */     NodeList xmlChildren = xmlNode.getChildNodes();
/* 148 */     if (xmlChildren == null) { return null;
/*     */     }
/* 150 */     for (int i = 0; i < xmlChildren.getLength(); i++)
/*     */     {
/* 152 */       Node xmlChild = xmlChildren.item(i);
/* 153 */       if (xmlChild.getNodeType() == 3)
/*     */       {
/* 155 */         return xmlChild.getNodeValue();
/*     */       }
/*     */     }
/* 158 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/config/ConfigurationLoader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */