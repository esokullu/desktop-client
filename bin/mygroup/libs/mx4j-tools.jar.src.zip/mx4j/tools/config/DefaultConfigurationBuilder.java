/*     */ package mx4j.tools.config;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultConfigurationBuilder
/*     */   implements ConfigurationBuilder
/*     */ {
/*     */   public static final String SHUTDOWN_COMMAND = "shutdown";
/*     */   public static final String RESTART_COMMAND = "restart";
/*     */   private static final String NULL = "null";
/*     */   
/*     */   public ConfigurationBuilder.Node createConfigurationNode(Element node)
/*     */     throws ConfigurationException
/*     */   {
/*  47 */     String loweredName = node.getNodeName().toLowerCase();
/*  48 */     StringBuffer buffer = new StringBuffer(loweredName);
/*  49 */     buffer.replace(0, 1, loweredName.substring(0, 1).toUpperCase());
/*  50 */     String className = getClass().getName() + "$" + buffer.toString();
/*     */     try
/*     */     {
/*  53 */       Logger logger = getLogger();
/*  54 */       if (logger.isEnabledFor(0)) logger.trace("Creating configuration node " + className);
/*  55 */       return (ConfigurationBuilder.Node)getClass().getClassLoader().loadClass(className).newInstance();
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/*  59 */       throw new ConfigurationException(x);
/*     */     }
/*     */   }
/*     */   
/*     */   private static Logger getLogger()
/*     */   {
/*  65 */     return Log.getLogger(DefaultConfigurationBuilder.class.getName());
/*     */   }
/*     */   
/*     */   public static abstract class AbstractNode implements ConfigurationBuilder.Node
/*     */   {
/*     */     private String text;
/*     */     private ConfigurationBuilder.Node parent;
/*     */     private List children;
/*     */     
/*     */     public void setText(String text)
/*     */     {
/*  76 */       this.text = text;
/*     */     }
/*     */     
/*     */     public void setParent(ConfigurationBuilder.Node parent)
/*     */     {
/*  81 */       this.parent = parent;
/*     */     }
/*     */     
/*     */     public void addChild(ConfigurationBuilder.Node child)
/*     */     {
/*  86 */       if (this.children == null) this.children = new ArrayList();
/*  87 */       child.setParent(this);
/*  88 */       this.children.add(child);
/*     */     }
/*     */     
/*     */     protected String getText()
/*     */     {
/*  93 */       return this.text;
/*     */     }
/*     */     
/*     */     public ConfigurationBuilder.Node getParent()
/*     */     {
/*  98 */       return this.parent;
/*     */     }
/*     */     
/*     */     public List getChildren()
/*     */     {
/* 103 */       return this.children;
/*     */     }
/*     */     
/*     */     public void setAttributes(NamedNodeMap attributes) throws ConfigurationException
/*     */     {
/* 108 */       Logger logger = DefaultConfigurationBuilder.access$000();
/* 109 */       for (int i = 0; i < attributes.getLength(); i++)
/*     */       {
/* 111 */         Node attribute = attributes.item(i);
/* 112 */         String name = attribute.getNodeName();
/* 113 */         String value = attribute.getNodeValue();
/* 114 */         String setterName = "set" + name.substring(0, 1).toUpperCase() + name.substring(1);
/*     */         try
/*     */         {
/* 117 */           if (logger.isEnabledFor(0)) logger.trace("Calling " + setterName + " with " + value + " on " + this);
/* 118 */           Method setter = getClass().getMethod(setterName, new Class[] { String.class });
/* 119 */           setter.invoke(this, new Object[] { value });
/*     */         }
/*     */         catch (InvocationTargetException x)
/*     */         {
/* 123 */           throw new ConfigurationException(x.getTargetException());
/*     */         }
/*     */         catch (Exception x)
/*     */         {
/* 127 */           throw new ConfigurationException(x);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Configuration extends DefaultConfigurationBuilder.AbstractNode implements ConfigurationBuilder.ObjectsHolder, Runnable
/*     */   {
/*     */     private Map objects;
/* 136 */     private int port = -1;
/*     */     private MBeanServer server;
/*     */     private Thread thread;
/*     */     
/*     */     public void setPort(String portString)
/*     */     {
/* 142 */       this.port = Integer.parseInt(portString);
/*     */     }
/*     */     
/*     */     public Object configure(MBeanServer server) throws ConfigurationException
/*     */     {
/* 147 */       if (server != null)
/*     */       {
/* 149 */         this.server = server;
/* 150 */         return startup(server);
/*     */       }
/*     */       
/*     */ 
/* 154 */       return shutdown(this.server);
/*     */     }
/*     */     
/*     */     private Object startup(MBeanServer server)
/*     */       throws ConfigurationException
/*     */     {
/* 160 */       Logger logger = DefaultConfigurationBuilder.access$000();
/* 161 */       List children = getChildren();
/* 162 */       if (children != null)
/*     */       {
/* 164 */         for (int i = 0; i < children.size(); i++)
/*     */         {
/* 166 */           ConfigurationBuilder.Node child = (ConfigurationBuilder.Node)children.get(i);
/* 167 */           if ((child instanceof DefaultConfigurationBuilder.Startup)) child.configure(server);
/*     */         }
/*     */       }
/* 170 */       if (this.port > 0)
/*     */       {
/* 172 */         this.thread = new Thread(this, "Configuration Shutdown");
/* 173 */         if (logger.isEnabledFor(0)) logger.trace("Starting " + this.thread.getName() + " Thread on port " + this.port);
/* 174 */         this.thread.start();
/*     */       }
/* 176 */       return null;
/*     */     }
/*     */     
/*     */     private Object shutdown(MBeanServer server) throws ConfigurationException
/*     */     {
/* 181 */       Logger logger = DefaultConfigurationBuilder.access$000();
/* 182 */       List children = getChildren();
/* 183 */       if (children != null)
/*     */       {
/* 185 */         for (int i = 0; i < children.size(); i++)
/*     */         {
/* 187 */           ConfigurationBuilder.Node child = (ConfigurationBuilder.Node)children.get(i);
/* 188 */           if ((child instanceof DefaultConfigurationBuilder.Shutdown)) child.configure(server);
/*     */         }
/*     */       }
/* 191 */       if (this.port > 0)
/*     */       {
/* 193 */         if (logger.isEnabledFor(0)) logger.trace("Stopping " + this.thread.getName() + " Thread on port " + this.port);
/* 194 */         this.thread.interrupt();
/*     */       }
/* 196 */       return null;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 201 */       Logger logger = DefaultConfigurationBuilder.access$000();
/* 202 */       ServerSocket server = null;
/*     */       try
/*     */       {
/* 205 */         if (logger.isEnabledFor(0)) { logger.trace("Started " + this.thread.getName() + " Thread on port " + this.port);
/*     */         }
/* 207 */         server = new ServerSocket(this.port, 50, InetAddress.getByName(null));
/* 208 */         server.setSoTimeout(1000);
/*     */         
/* 210 */         byte[] buffer = new byte[64];
/* 211 */         StringBuffer command = new StringBuffer();
/* 212 */         while (!this.thread.isInterrupted())
/*     */         {
/* 214 */           Socket client = null;
/*     */           try
/*     */           {
/* 217 */             client = server.accept();
/*     */           }
/*     */           catch (InterruptedIOException x) {}
/*     */           
/* 221 */           continue;
/*     */           
/* 223 */           if (logger.isEnabledFor(0)) logger.trace("Client connected " + client);
/* 224 */           InputStream is = new BufferedInputStream(client.getInputStream());
/*     */           
/* 226 */           command.setLength(0);
/* 227 */           int read = -1;
/* 228 */           while ((read = is.read(buffer)) >= 0) { command.append(new String(buffer, 0, read));
/*     */           }
/* 230 */           String cmd = command.toString();
/* 231 */           if (logger.isEnabledFor(0)) { logger.trace("Got command '" + cmd + "'");
/*     */           }
/* 233 */           if ("shutdown".equals(cmd))
/*     */           {
/*     */             try
/*     */             {
/* 237 */               configure(null);
/*     */ 
/*     */             }
/*     */             catch (ConfigurationException x)
/*     */             {
/* 242 */               if (logger.isEnabledFor(30)) logger.warn("Bad configuration for shutdown", x);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception x)
/*     */       {
/* 249 */         if (logger.isEnabledFor(20)) logger.info("Caught Exception in " + this.thread.getName() + " Thread, exiting", x);
/*     */       }
/*     */       finally
/*     */       {
/* 253 */         if (logger.isEnabledFor(0)) logger.trace("Stopped " + this.thread.getName() + " Thread on port " + this.port);
/*     */         try
/*     */         {
/* 256 */           if (server != null) { server.close();
/*     */           }
/*     */         }
/*     */         catch (IOException x) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public Object getObject(String key)
/*     */     {
/* 266 */       if (this.objects == null) return null;
/* 267 */       return this.objects.get(key);
/*     */     }
/*     */     
/*     */     public Object putObject(String key, Object value)
/*     */     {
/* 272 */       if (this.objects == null) this.objects = new HashMap();
/* 273 */       return this.objects.put(key, value);
/*     */     }
/*     */     
/*     */     public boolean containsKey(String key)
/*     */     {
/* 278 */       if (this.objects == null) return false;
/* 279 */       return this.objects.containsKey(key);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Startup extends DefaultConfigurationBuilder.AbstractNode
/*     */   {
/*     */     public Object configure(MBeanServer server) throws ConfigurationException
/*     */     {
/* 287 */       List children = getChildren();
/* 288 */       if (children != null)
/*     */       {
/* 290 */         for (int i = 0; i < children.size(); i++)
/*     */         {
/* 292 */           ConfigurationBuilder.Node child = (ConfigurationBuilder.Node)children.get(i);
/* 293 */           child.configure(server);
/*     */         }
/*     */       }
/* 296 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Shutdown extends DefaultConfigurationBuilder.AbstractNode
/*     */   {
/*     */     public Object configure(MBeanServer server) throws ConfigurationException
/*     */     {
/* 304 */       List children = getChildren();
/* 305 */       if (children != null)
/*     */       {
/* 307 */         for (int i = 0; i < children.size(); i++)
/*     */         {
/* 309 */           ConfigurationBuilder.Node child = (ConfigurationBuilder.Node)children.get(i);
/* 310 */           child.configure(server);
/*     */         }
/*     */       }
/* 313 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Object extends DefaultConfigurationBuilder.AbstractNode
/*     */   {
/*     */     private String id;
/*     */     
/*     */     public void setObjectid(String id)
/*     */     {
/* 323 */       this.id = id;
/*     */     }
/*     */     
/*     */     public String getObjectid()
/*     */     {
/* 328 */       return this.id;
/*     */     }
/*     */     
/*     */     public Object configure(MBeanServer server) throws ConfigurationException
/*     */     {
/* 333 */       List children = getChildren();
/* 334 */       Object result = null;
/* 335 */       if ((children != null) && (children.size() > 0))
/*     */       {
/* 337 */         ConfigurationBuilder.Node child = (ConfigurationBuilder.Node)children.get(0);
/* 338 */         result = child.configure(server);
/*     */       }
/* 340 */       DefaultConfigurationBuilder.putObject(this, this.id, result);
/* 341 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class New extends DefaultConfigurationBuilder.AbstractNode
/*     */   {
/*     */     private String classname;
/*     */     
/*     */     public void setClassname(String classname)
/*     */     {
/* 351 */       this.classname = classname;
/*     */     }
/*     */     
/*     */     public Object configure(MBeanServer server) throws ConfigurationException
/*     */     {
/*     */       try
/*     */       {
/* 358 */         Class cls = DefaultConfigurationBuilder.loadClass(this.classname);
/* 359 */         Constructor ctor = cls.getConstructor(DefaultConfigurationBuilder.getMethodSignature(this));
/* 360 */         return ctor.newInstance(DefaultConfigurationBuilder.getMethodArguments(this, server));
/*     */       }
/*     */       catch (InvocationTargetException x)
/*     */       {
/* 364 */         throw new ConfigurationException(x.getTargetException());
/*     */       }
/*     */       catch (ConfigurationException x)
/*     */       {
/* 368 */         throw x;
/*     */       }
/*     */       catch (Exception x)
/*     */       {
/* 372 */         throw new ConfigurationException(x);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Arg
/*     */     extends DefaultConfigurationBuilder.AbstractNode
/*     */   {
/*     */     private static final String OBJECT_TYPE = "object";
/*     */     private static final String STRING_TYPE = "string";
/*     */     private static final String BOOLEAN_TYPE = "boolean";
/*     */     private static final String BYTE_TYPE = "byte";
/*     */     private static final String CHAR_TYPE = "char";
/*     */     private static final String DOUBLE_TYPE = "double";
/*     */     private static final String FLOAT_TYPE = "float";
/*     */     private static final String INT_TYPE = "int";
/*     */     private static final String LONG_TYPE = "long";
/*     */     private static final String SHORT_TYPE = "short";
/*     */     private String type;
/*     */     private String refobjectid;
/*     */     
/*     */     public void setType(String type)
/*     */     {
/* 395 */       this.type = type;
/*     */     }
/*     */     
/*     */     public void setRefobjectid(String refobjectid)
/*     */     {
/* 400 */       this.refobjectid = refobjectid;
/*     */     }
/*     */     
/*     */     public Class getJavaType() throws ConfigurationException
/*     */     {
/* 405 */       if ("string".equalsIgnoreCase(this.type)) return String.class;
/* 406 */       if ("object".equalsIgnoreCase(this.type)) return DefaultConfigurationBuilder.Object.class;
/* 407 */       if ("boolean".equalsIgnoreCase(this.type)) return Boolean.TYPE;
/* 408 */       if ("byte".equalsIgnoreCase(this.type)) return Byte.TYPE;
/* 409 */       if ("char".equalsIgnoreCase(this.type)) return Character.TYPE;
/* 410 */       if ("double".equalsIgnoreCase(this.type)) return Double.TYPE;
/* 411 */       if ("float".equalsIgnoreCase(this.type)) return Float.TYPE;
/* 412 */       if ("int".equalsIgnoreCase(this.type)) return Integer.TYPE;
/* 413 */       if ("long".equalsIgnoreCase(this.type)) return Long.TYPE;
/* 414 */       if ("short".equalsIgnoreCase(this.type)) return Short.TYPE;
/* 415 */       return DefaultConfigurationBuilder.loadClass(this.type);
/*     */     }
/*     */     
/*     */     public Object configure(MBeanServer server) throws ConfigurationException
/*     */     {
/* 420 */       if (this.refobjectid != null) { return DefaultConfigurationBuilder.getObject(this, this.refobjectid);
/*     */       }
/* 422 */       List children = getChildren();
/* 423 */       if ((children != null) && (children.size() > 0))
/*     */       {
/* 425 */         ConfigurationBuilder.Node child = (ConfigurationBuilder.Node)children.get(0);
/* 426 */         return child.configure(server);
/*     */       }
/*     */       
/* 429 */       String text = getText();
/* 430 */       if ((text == null) || ("null".equals(text))) { return null;
/*     */       }
/* 432 */       if ("string".equalsIgnoreCase(this.type)) return text;
/* 433 */       if ("object".equalsIgnoreCase(this.type)) return text;
/* 434 */       if ("boolean".equalsIgnoreCase(this.type)) return Boolean.valueOf(text);
/* 435 */       if ("byte".equalsIgnoreCase(this.type)) return Byte.valueOf(text);
/* 436 */       if ("char".equalsIgnoreCase(this.type)) return new Character(text.length() < 1 ? '\000' : text.charAt(0));
/* 437 */       if ("double".equalsIgnoreCase(this.type)) return Double.valueOf(text);
/* 438 */       if ("float".equalsIgnoreCase(this.type)) return Float.valueOf(text);
/* 439 */       if ("int".equalsIgnoreCase(this.type)) return Integer.valueOf(text);
/* 440 */       if ("long".equalsIgnoreCase(this.type)) return Long.valueOf(text);
/* 441 */       if ("short".equalsIgnoreCase(this.type)) { return Short.valueOf(text);
/*     */       }
/*     */       try
/*     */       {
/* 445 */         Constructor ctor = getJavaType().getConstructor(new Class[] { String.class });
/* 446 */         return ctor.newInstance(new Object[] { text });
/*     */       }
/*     */       catch (InvocationTargetException x)
/*     */       {
/* 450 */         throw new ConfigurationException(x.getTargetException());
/*     */       }
/*     */       catch (ConfigurationException x)
/*     */       {
/* 454 */         throw x;
/*     */       }
/*     */       catch (Exception x)
/*     */       {
/* 458 */         throw new ConfigurationException(x);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Register extends DefaultConfigurationBuilder.AbstractNode
/*     */   {
/*     */     private ObjectName objectname;
/*     */     
/*     */     public void setObjectname(String name) throws MalformedObjectNameException
/*     */     {
/* 469 */       if ((name != null) && (!"null".equals(name))) this.objectname = ObjectName.getInstance(name);
/*     */     }
/*     */     
/*     */     public Object configure(MBeanServer server) throws ConfigurationException
/*     */     {
/* 474 */       List children = getChildren();
/* 475 */       if ((children != null) && (children.size() > 0))
/*     */       {
/* 477 */         ConfigurationBuilder.Node child = (ConfigurationBuilder.Node)children.get(0);
/*     */         try
/*     */         {
/* 480 */           return server.registerMBean(child.configure(server), this.objectname);
/*     */         }
/*     */         catch (ConfigurationException x)
/*     */         {
/* 484 */           throw x;
/*     */         }
/*     */         catch (Exception x)
/*     */         {
/* 488 */           throw new ConfigurationException(x);
/*     */         }
/*     */       }
/* 491 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Unregister extends DefaultConfigurationBuilder.AbstractNode
/*     */   {
/*     */     private ObjectName objectname;
/*     */     
/*     */     public void setObjectname(String name) throws MalformedObjectNameException
/*     */     {
/* 501 */       this.objectname = ObjectName.getInstance(name);
/*     */     }
/*     */     
/*     */     public Object configure(MBeanServer server) throws ConfigurationException
/*     */     {
/*     */       try
/*     */       {
/* 508 */         server.unregisterMBean(this.objectname);
/* 509 */         return null;
/*     */       }
/*     */       catch (Exception x)
/*     */       {
/* 513 */         throw new ConfigurationException(x);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Create extends DefaultConfigurationBuilder.AbstractNode
/*     */   {
/*     */     private String classname;
/*     */     private ObjectName objectname;
/*     */     private String loadername;
/*     */     
/*     */     public void setClassname(String classname)
/*     */     {
/* 526 */       this.classname = classname;
/*     */     }
/*     */     
/*     */     public void setObjectname(String name) throws MalformedObjectNameException
/*     */     {
/* 531 */       if ((name != null) && (!"null".equals(name))) this.objectname = ObjectName.getInstance(name);
/*     */     }
/*     */     
/*     */     public void setLoadername(String name) throws MalformedObjectNameException
/*     */     {
/* 536 */       this.loadername = name;
/*     */     }
/*     */     
/*     */     public Object configure(MBeanServer server) throws ConfigurationException
/*     */     {
/*     */       try
/*     */       {
/* 543 */         if (this.loadername != null)
/*     */         {
/* 545 */           ObjectName loader = null;
/* 546 */           if (!"null".equals(this.loadername)) loader = ObjectName.getInstance(this.loadername);
/* 547 */           return server.createMBean(this.classname, this.objectname, loader, DefaultConfigurationBuilder.getMethodArguments(this, server), DefaultConfigurationBuilder.getJMXMethodSignature(this));
/*     */         }
/*     */         
/*     */ 
/* 551 */         return server.createMBean(this.classname, this.objectname, DefaultConfigurationBuilder.getMethodArguments(this, server), DefaultConfigurationBuilder.getJMXMethodSignature(this));
/*     */ 
/*     */       }
/*     */       catch (ConfigurationException x)
/*     */       {
/* 556 */         throw x;
/*     */       }
/*     */       catch (Exception x)
/*     */       {
/* 560 */         throw new ConfigurationException(x);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Call extends DefaultConfigurationBuilder.AbstractNode
/*     */   {
/*     */     private String classname;
/*     */     private ObjectName objectname;
/*     */     private String refobjectid;
/*     */     private String method;
/*     */     private String operation;
/*     */     private String attribute;
/*     */     
/*     */     public void setClassname(String classname)
/*     */     {
/* 576 */       this.classname = classname;
/*     */     }
/*     */     
/*     */     public void setObjectname(String name) throws MalformedObjectNameException
/*     */     {
/* 581 */       if ((name != null) && (!"null".equals(name))) this.objectname = ObjectName.getInstance(name);
/*     */     }
/*     */     
/*     */     public void setRefobjectid(String refid)
/*     */     {
/* 586 */       this.refobjectid = refid;
/*     */     }
/*     */     
/*     */     public void setMethod(String method)
/*     */     {
/* 591 */       this.method = method;
/*     */     }
/*     */     
/*     */     public void setOperation(String operation)
/*     */     {
/* 596 */       this.operation = operation;
/*     */     }
/*     */     
/*     */     public void setAttribute(String attribute)
/*     */     {
/* 601 */       this.attribute = attribute;
/*     */     }
/*     */     
/*     */     public Object configure(MBeanServer server) throws ConfigurationException
/*     */     {
/* 606 */       if (this.classname != null)
/*     */       {
/*     */ 
/* 609 */         Class cls = DefaultConfigurationBuilder.loadClass(this.classname);
/*     */         try
/*     */         {
/* 612 */           Method mthd = cls.getMethod(this.method, DefaultConfigurationBuilder.getMethodSignature(this));
/* 613 */           return mthd.invoke(null, DefaultConfigurationBuilder.getMethodArguments(this, server));
/*     */         }
/*     */         catch (InvocationTargetException x)
/*     */         {
/* 617 */           throw new ConfigurationException(x.getTargetException());
/*     */         }
/*     */         catch (ConfigurationException x)
/*     */         {
/* 621 */           throw x;
/*     */         }
/*     */         catch (Exception x)
/*     */         {
/* 625 */           throw new ConfigurationException(x);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 630 */       if (this.objectname != null)
/*     */       {
/*     */ 
/* 633 */         if (this.operation != null)
/*     */         {
/*     */           try
/*     */           {
/* 637 */             return server.invoke(this.objectname, this.operation, DefaultConfigurationBuilder.getMethodArguments(this, server), DefaultConfigurationBuilder.getJMXMethodSignature(this));
/*     */           }
/*     */           catch (ConfigurationException x)
/*     */           {
/* 641 */             throw x;
/*     */           }
/*     */           catch (Exception x)
/*     */           {
/* 645 */             throw new ConfigurationException(x);
/*     */           }
/*     */         }
/* 648 */         if (this.attribute != null)
/*     */         {
/*     */           try
/*     */           {
/* 652 */             List children = getChildren();
/* 653 */             if ((children == null) || (children.size() < 1))
/*     */             {
/* 655 */               return server.getAttribute(this.objectname, this.attribute);
/*     */             }
/*     */             
/*     */ 
/* 659 */             Object arg = DefaultConfigurationBuilder.getMethodArguments(this, server)[0];
/* 660 */             server.setAttribute(this.objectname, new Attribute(this.attribute, arg));
/* 661 */             return null;
/*     */ 
/*     */           }
/*     */           catch (ConfigurationException x)
/*     */           {
/* 666 */             throw x;
/*     */           }
/*     */           catch (Exception x)
/*     */           {
/* 670 */             throw new ConfigurationException(x);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 675 */         throw new ConfigurationException("Missing 'attribute' or 'operation' attribute in JMX call");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 681 */       Object target = null;
/* 682 */       if (this.refobjectid != null)
/*     */       {
/* 684 */         target = DefaultConfigurationBuilder.getObject(this, this.refobjectid);
/* 685 */         if (target == null) throw new ConfigurationException("Could not find object with id " + this.refobjectid);
/*     */         try
/*     */         {
/* 688 */           Method mthd = target.getClass().getMethod(this.method, DefaultConfigurationBuilder.getMethodSignature(this));
/* 689 */           return mthd.invoke(target, DefaultConfigurationBuilder.getMethodArguments(this, server));
/*     */         }
/*     */         catch (InvocationTargetException x)
/*     */         {
/* 693 */           throw new ConfigurationException(x.getTargetException());
/*     */         }
/*     */         catch (ConfigurationException x)
/*     */         {
/* 697 */           throw x;
/*     */         }
/*     */         catch (Exception x)
/*     */         {
/* 701 */           throw new ConfigurationException(x);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 706 */       throw new ConfigurationException("Missing 'refobjectid' attribute in call element");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static Class[] getMethodSignature(ConfigurationBuilder.Node node)
/*     */     throws ConfigurationException
/*     */   {
/* 715 */     List children = node.getChildren();
/* 716 */     if (children == null) return null;
/* 717 */     ArrayList signature = new ArrayList();
/* 718 */     for (int i = 0; i < children.size(); i++)
/*     */     {
/* 720 */       ConfigurationBuilder.Node child = (ConfigurationBuilder.Node)children.get(i);
/* 721 */       if ((child instanceof Arg))
/*     */       {
/* 723 */         Arg arg = (Arg)child;
/* 724 */         signature.add(arg.getJavaType());
/*     */       }
/*     */     }
/* 727 */     return (Class[])signature.toArray(new Class[signature.size()]);
/*     */   }
/*     */   
/*     */   private static String[] getJMXMethodSignature(ConfigurationBuilder.Node node) throws ConfigurationException
/*     */   {
/* 732 */     Class[] signature = getMethodSignature(node);
/* 733 */     if (signature == null) { return null;
/*     */     }
/* 735 */     ArrayList jmxSignature = new ArrayList();
/* 736 */     for (int i = 0; i < signature.length; i++)
/*     */     {
/* 738 */       jmxSignature.add(signature[i].getName());
/*     */     }
/* 740 */     return (String[])jmxSignature.toArray(new String[jmxSignature.size()]);
/*     */   }
/*     */   
/*     */   private static Object[] getMethodArguments(ConfigurationBuilder.Node node, MBeanServer server) throws ConfigurationException
/*     */   {
/* 745 */     List children = node.getChildren();
/* 746 */     if (children == null) return null;
/* 747 */     ArrayList arguments = new ArrayList();
/* 748 */     for (int i = 0; i < children.size(); i++)
/*     */     {
/* 750 */       ConfigurationBuilder.Node child = (ConfigurationBuilder.Node)children.get(i);
/* 751 */       if ((child instanceof Arg))
/*     */       {
/* 753 */         Arg arg = (Arg)child;
/* 754 */         arguments.add(arg.configure(server));
/*     */       }
/*     */     }
/* 757 */     return arguments.toArray();
/*     */   }
/*     */   
/*     */   private static Class loadClass(String className) throws ConfigurationException
/*     */   {
/*     */     try
/*     */     {
/* 764 */       return Thread.currentThread().getContextClassLoader().loadClass(className);
/*     */     }
/*     */     catch (ClassNotFoundException x)
/*     */     {
/* 768 */       throw new ConfigurationException(x);
/*     */     }
/*     */   }
/*     */   
/*     */   private static Object getObject(ConfigurationBuilder.Node node, String key)
/*     */   {
/* 774 */     while (node != null)
/*     */     {
/* 776 */       if ((node instanceof ConfigurationBuilder.ObjectsHolder))
/*     */       {
/* 778 */         ConfigurationBuilder.ObjectsHolder holder = (ConfigurationBuilder.ObjectsHolder)node;
/* 779 */         if (holder.containsKey(key)) return holder.getObject(key);
/*     */       }
/* 781 */       node = node.getParent();
/*     */     }
/* 783 */     return null;
/*     */   }
/*     */   
/*     */   private static void putObject(ConfigurationBuilder.Node node, String key, Object value)
/*     */   {
/* 788 */     while (node != null)
/*     */     {
/* 790 */       if ((node instanceof ConfigurationBuilder.ObjectsHolder))
/*     */       {
/* 792 */         ConfigurationBuilder.ObjectsHolder holder = (ConfigurationBuilder.ObjectsHolder)node;
/* 793 */         holder.putObject(key, value);
/*     */       }
/* 795 */       node = node.getParent();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/config/DefaultConfigurationBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */