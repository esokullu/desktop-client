package mx4j.tools.config;

import java.util.List;
import javax.management.MBeanServer;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;

public abstract interface ConfigurationBuilder
{
  public abstract Node createConfigurationNode(Element paramElement)
    throws ConfigurationException;
  
  public static abstract interface ObjectsHolder
  {
    public abstract Object getObject(String paramString);
    
    public abstract Object putObject(String paramString, Object paramObject);
    
    public abstract boolean containsKey(String paramString);
  }
  
  public static abstract interface Node
  {
    public abstract void setAttributes(NamedNodeMap paramNamedNodeMap)
      throws ConfigurationException;
    
    public abstract void setText(String paramString);
    
    public abstract Object configure(MBeanServer paramMBeanServer)
      throws ConfigurationException;
    
    public abstract Node getParent();
    
    public abstract void setParent(Node paramNode);
    
    public abstract List getChildren();
    
    public abstract void addChild(Node paramNode);
  }
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/config/ConfigurationBuilder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */