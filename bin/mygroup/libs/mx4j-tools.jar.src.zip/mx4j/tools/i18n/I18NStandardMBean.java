/*     */ package mx4j.tools.i18n;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanConstructorInfo;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.StandardMBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class I18NStandardMBean
/*     */   extends StandardMBean
/*     */ {
/*     */   private static final String IDPROP_DEFAULT_LOCALE = "mx4j.descriptionLocale";
/*     */   private static final String RESOURCE_SUFFIX = "MBeanResources";
/*     */   private static final String KEY_DESCR = "descr";
/*     */   private static final String KEY_CONS = "cons";
/*     */   private static final String KEY_ATTR = "attr";
/*     */   private static final String KEY_OP = "op";
/*     */   private static final String KEY_PARAM = "param";
/*     */   private static final String KEY_PARAM_NAME = "paramName";
/*     */   private static final String KEY_SIG = "sig";
/* 154 */   private static Locale g_defaultLocale = null;
/*     */   
/*     */   private NestedResourceBundle m_bundle;
/*     */   private Map m_mapConstructorSignatureToResourceIndex;
/*     */   private Map m_mapConstructorParamCountToResourceIndex;
/* 159 */   private Map m_mapConstructorToResourceIndex = new HashMap();
/* 160 */   private Map m_mapOperationNameToSignatures = new HashMap();
/* 161 */   private Map m_mapOperationNameToParamCounts = new HashMap();
/* 162 */   private Set m_setAmbiguousConstructors = new HashSet();
/* 163 */   private Set m_setAmbiguousOperations = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public I18NStandardMBean(Object implementation, Class mbeanInterface)
/*     */     throws NotCompliantMBeanException
/*     */   {
/* 173 */     this(implementation, mbeanInterface, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public I18NStandardMBean(Object implementation, Class mbeanInterface, Locale locale)
/*     */     throws NotCompliantMBeanException
/*     */   {
/* 186 */     super(implementation, mbeanInterface);
/* 187 */     setupBundle(implementation, locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected I18NStandardMBean(Class mbeanInterface)
/*     */     throws NotCompliantMBeanException
/*     */   {
/* 198 */     super(mbeanInterface);
/* 199 */     setupBundle(this, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected I18NStandardMBean(Class mbeanInterface, Locale locale)
/*     */     throws NotCompliantMBeanException
/*     */   {
/* 210 */     super(mbeanInterface);
/* 211 */     setupBundle(this, locale);
/*     */   }
/*     */   
/*     */ 
/*     */   private void setupBundle(Object implementation, Locale locale)
/*     */   {
/* 217 */     if (locale == null)
/*     */     {
/* 219 */       locale = g_defaultLocale;
/*     */     }
/* 221 */     if (locale == null)
/*     */     {
/* 223 */       locale = getLocaleFromSystemProperties();
/*     */     }
/*     */     
/*     */ 
/* 227 */     NestedResourceBundle cur = null;
/* 228 */     MissingResourceException ex = null;
/* 229 */     for (Class c = implementation.getClass(); c != null; c = c.getSuperclass())
/*     */     {
/* 231 */       String bundleName = c.getName() + "MBeanResources";
/*     */       try
/*     */       {
/* 234 */         ResourceBundle b = ResourceBundle.getBundle(bundleName, locale);
/* 235 */         NestedResourceBundle nb = new NestedResourceBundle(b);
/* 236 */         if (cur == null)
/*     */         {
/* 238 */           this.m_bundle = nb;
/*     */         }
/*     */         else
/*     */         {
/* 242 */           cur.setParent(nb);
/*     */         }
/* 244 */         cur = nb;
/*     */       }
/*     */       catch (MissingResourceException e)
/*     */       {
/* 248 */         if (this.m_bundle == null) ex = e;
/*     */       }
/*     */     }
/* 251 */     if (this.m_bundle == null)
/*     */     {
/* 253 */       ex.fillInStackTrace();
/* 254 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private Locale getLocaleFromSystemProperties()
/*     */   {
/* 261 */     Locale locale = Locale.getDefault();
/* 262 */     String stdLocale = System.getProperty("mx4j.descriptionLocale");
/* 263 */     if ((stdLocale != null) && (stdLocale.length() > 0))
/*     */     {
/* 265 */       StringTokenizer st = new StringTokenizer(stdLocale, "_");
/* 266 */       switch (st.countTokens())
/*     */       {
/*     */       case 2: 
/* 269 */         locale = new Locale(st.nextToken(), st.nextToken());
/* 270 */         break;
/*     */       case 3: 
/* 272 */         locale = new Locale(st.nextToken(), st.nextToken(), st.nextToken());
/*     */         
/*     */ 
/*     */ 
/* 276 */         break;
/*     */       default: 
/* 278 */         throw new IllegalArgumentException("Invalid locale in mx4j.descriptionLocale:" + stdLocale);
/*     */       }
/*     */       
/*     */     }
/*     */     
/*     */ 
/* 284 */     return locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setDefaultLocale(Locale locale)
/*     */   {
/* 298 */     g_defaultLocale = locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanInfo getCachedMBeanInfo()
/*     */   {
/* 310 */     MBeanInfo info = super.getCachedMBeanInfo();
/* 311 */     if (info == null)
/*     */     {
/*     */ 
/* 314 */       this.m_mapConstructorToResourceIndex = new HashMap();
/* 315 */       this.m_mapOperationNameToSignatures = new HashMap();
/* 316 */       this.m_mapOperationNameToParamCounts = new HashMap();
/* 317 */       this.m_setAmbiguousConstructors = new HashSet();
/* 318 */       this.m_setAmbiguousOperations = new HashSet();
/* 319 */       this.m_mapConstructorSignatureToResourceIndex = getSignatureMap("cons");
/*     */       
/* 321 */       this.m_mapConstructorParamCountToResourceIndex = getParamCountMap("cons");
/*     */     }
/*     */     
/* 324 */     return info;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void cacheMBeanInfo(MBeanInfo info)
/*     */   {
/* 334 */     super.cacheMBeanInfo(info);
/* 335 */     this.m_mapConstructorToResourceIndex = null;
/* 336 */     this.m_mapOperationNameToSignatures = null;
/* 337 */     this.m_mapOperationNameToParamCounts = null;
/* 338 */     this.m_setAmbiguousConstructors = null;
/* 339 */     this.m_setAmbiguousOperations = null;
/* 340 */     this.m_mapConstructorSignatureToResourceIndex = null;
/* 341 */     this.m_mapConstructorParamCountToResourceIndex = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanConstructorInfo[] getConstructors(MBeanConstructorInfo[] cstrs, Object impl)
/*     */   {
/* 358 */     Map argCountToCstr = new HashMap();
/* 359 */     for (int i = 0; i < cstrs.length; i++)
/*     */     {
/* 361 */       MBeanConstructorInfo ci = cstrs[i];
/* 362 */       MBeanParameterInfo[] params = ci.getSignature();
/*     */       
/*     */ 
/* 365 */       Integer count = new Integer(params.length);
/* 366 */       Object first = argCountToCstr.get(count);
/* 367 */       if (first != null)
/*     */       {
/*     */ 
/* 370 */         this.m_setAmbiguousConstructors.add(first);
/* 371 */         this.m_setAmbiguousConstructors.add(ci);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 376 */         argCountToCstr.put(count, ci);
/*     */       }
/*     */       
/*     */ 
/* 380 */       String sig = makeSignatureString(params);
/* 381 */       Integer idx = (Integer)this.m_mapConstructorSignatureToResourceIndex.get(sig);
/*     */       
/* 383 */       if (idx != null)
/*     */       {
/* 385 */         this.m_mapConstructorToResourceIndex.put(ci, idx);
/*     */       }
/*     */     }
/* 388 */     return super.getConstructors(cstrs, impl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanInfo info)
/*     */   {
/* 403 */     findAmbiguousOperations(info);
/* 404 */     return getValueFromBundle("descr");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanConstructorInfo cstr)
/*     */   {
/* 418 */     int idx = getConstructorIndex(cstr);
/* 419 */     if (idx < 1)
/*     */     {
/* 421 */       return "ambiguous constructor";
/*     */     }
/* 423 */     return getValueFromBundle("cons." + idx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanConstructorInfo cstr, MBeanParameterInfo param, int seq)
/*     */   {
/* 439 */     int idx = getConstructorIndex(cstr);
/* 440 */     if (idx < 1)
/*     */     {
/* 442 */       return "parameter for ambiguous constructor";
/*     */     }
/* 444 */     return getValueFromBundle("cons." + idx + ".param." + (seq + 1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getParameterName(MBeanConstructorInfo cstr, MBeanParameterInfo param, int seq)
/*     */   {
/* 460 */     int idx = getConstructorIndex(cstr);
/* 461 */     String name = null;
/* 462 */     if (idx >= 1)
/*     */     {
/* 464 */       name = getValueOrNullFromBundle("cons." + idx + ".paramName." + (seq + 1));
/*     */     }
/*     */     
/* 467 */     if (name == null)
/*     */     {
/* 469 */       name = super.getParameterName(cstr, param, seq);
/*     */     }
/* 471 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanAttributeInfo attr)
/*     */   {
/* 482 */     return getValueFromBundle("attr." + attr.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanOperationInfo op)
/*     */   {
/*     */     try
/*     */     {
/* 498 */       return getValueFromBundle(getOperationKey(op));
/*     */     }
/*     */     catch (IllegalStateException e)
/*     */     {
/* 502 */       return e.getMessage();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(MBeanOperationInfo op, MBeanParameterInfo param, int seq)
/*     */   {
/*     */     try
/*     */     {
/* 521 */       return getValueFromBundle(getOperationKey(op) + "." + "param" + "." + (seq + 1));
/*     */     }
/*     */     catch (IllegalStateException e)
/*     */     {
/* 525 */       return "parameter for " + e.getMessage();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getParameterName(MBeanOperationInfo op, MBeanParameterInfo param, int seq)
/*     */   {
/* 543 */     String name = null;
/*     */     try
/*     */     {
/* 546 */       name = getValueOrNullFromBundle(getOperationKey(op) + "." + "paramName" + "." + (seq + 1));
/*     */     }
/*     */     catch (IllegalStateException e) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 557 */     if (name == null)
/*     */     {
/* 559 */       name = super.getParameterName(op, param, seq);
/*     */     }
/* 561 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getConstructorIndex(MBeanConstructorInfo cons)
/*     */   {
/* 574 */     Integer idx = (Integer)this.m_mapConstructorToResourceIndex.get(cons);
/* 575 */     if (idx != null)
/*     */     {
/* 577 */       return idx.intValue();
/*     */     }
/*     */     
/*     */ 
/* 581 */     if (this.m_setAmbiguousConstructors.contains(cons)) {
/* 582 */       return -1;
/*     */     }
/*     */     
/* 585 */     int nbParams = cons.getSignature().length;
/* 586 */     idx = (Integer)this.m_mapConstructorParamCountToResourceIndex.get(new Integer(nbParams));
/*     */     
/* 588 */     if (idx != null)
/*     */     {
/* 590 */       return idx.intValue();
/*     */     }
/* 592 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getOperationKey(MBeanOperationInfo op)
/*     */   {
/* 605 */     String operationName = op.getName();
/*     */     
/*     */ 
/* 608 */     Map sigMap = getOperationSignatureMap(operationName);
/* 609 */     MBeanParameterInfo[] params = op.getSignature();
/* 610 */     String sig = makeSignatureString(params);
/* 611 */     Integer idx = (Integer)sigMap.get(sig);
/*     */     
/* 613 */     StringBuffer sbRet = new StringBuffer("op.");
/* 614 */     sbRet.append(operationName);
/*     */     
/* 616 */     if (idx == null)
/*     */     {
/* 618 */       if (this.m_setAmbiguousOperations.contains(op))
/*     */       {
/* 620 */         throw new IllegalStateException("ambiguous operation");
/*     */       }
/*     */       
/*     */ 
/* 624 */       Map countMap = getOperationParamCountMap(operationName);
/* 625 */       idx = (Integer)countMap.get(new Integer(params.length));
/* 626 */       if ((idx != null) && (idx.intValue() < 1))
/*     */       {
/* 628 */         throw new IllegalStateException("ambiguous operation");
/*     */       }
/*     */     }
/*     */     
/* 632 */     if (idx != null)
/*     */     {
/* 634 */       sbRet.append(".");
/* 635 */       sbRet.append(idx);
/*     */     }
/* 637 */     return sbRet.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void findAmbiguousOperations(MBeanInfo info)
/*     */   {
/* 647 */     MBeanOperationInfo[] ops = info.getOperations();
/* 648 */     Map mapNameToArgCountMap = new HashMap();
/* 649 */     for (int i = 0; i < ops.length; i++)
/*     */     {
/* 651 */       MBeanOperationInfo op = ops[i];
/* 652 */       String name = op.getName();
/* 653 */       Map argCountToOp = (Map)mapNameToArgCountMap.get(name);
/* 654 */       if (argCountToOp == null)
/*     */       {
/* 656 */         argCountToOp = new HashMap();
/* 657 */         mapNameToArgCountMap.put(name, argCountToOp);
/*     */       }
/*     */       
/* 660 */       Integer count = new Integer(op.getSignature().length);
/* 661 */       Object first = argCountToOp.get(count);
/* 662 */       if (first != null)
/*     */       {
/*     */ 
/* 665 */         this.m_setAmbiguousOperations.add(first);
/* 666 */         this.m_setAmbiguousOperations.add(op);
/*     */       }
/*     */       else
/*     */       {
/* 670 */         argCountToOp.put(count, op);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map getOperationSignatureMap(String operationName)
/*     */   {
/* 687 */     Map m = (Map)this.m_mapOperationNameToSignatures.get(operationName);
/* 688 */     if (m != null)
/*     */     {
/* 690 */       return m;
/*     */     }
/*     */     
/*     */ 
/* 694 */     m = getSignatureMap("op." + operationName);
/* 695 */     this.m_mapOperationNameToSignatures.put(operationName, m);
/* 696 */     return m;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map getOperationParamCountMap(String operationName)
/*     */   {
/* 706 */     Map m = (Map)this.m_mapOperationNameToParamCounts.get(operationName);
/* 707 */     if (m != null)
/*     */     {
/* 709 */       return m;
/*     */     }
/*     */     
/*     */ 
/* 713 */     m = getParamCountMap("op." + operationName);
/* 714 */     this.m_mapOperationNameToParamCounts.put(operationName, m);
/* 715 */     return m;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map getParamCountMap(String prefix)
/*     */   {
/* 731 */     Map m = new HashMap();
/*     */     
/* 733 */     for (int i = 1;; i++)
/*     */     {
/* 735 */       String key = prefix + "." + i;
/* 736 */       String sig = getValueOrNullFromBundle(key);
/* 737 */       if (sig == null) {
/*     */         break;
/*     */       }
/*     */       
/* 741 */       int nb = 0;
/* 742 */       for (int j = 1;; j++)
/*     */       {
/* 744 */         key = prefix + "." + i + "." + "param" + "." + j;
/* 745 */         if (getValueOrNullFromBundle(key) == null)
/*     */           break;
/* 747 */         nb = j;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 754 */       Integer nbObj = new Integer(nb);
/* 755 */       int idx = m.containsKey(nbObj) ? -1 : i;
/* 756 */       m.put(nbObj, new Integer(idx));
/*     */     }
/* 758 */     return m;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map getSignatureMap(String prefix)
/*     */   {
/* 773 */     Map m = new HashMap();
/* 774 */     for (int i = 1;; i++)
/*     */     {
/* 776 */       String key = prefix + "." + i + "." + "sig";
/* 777 */       String sig = getValueOrNullFromBundle(key);
/* 778 */       if (sig == null) {
/*     */         break;
/*     */       }
/*     */       
/* 782 */       m.put(sig, new Integer(i));
/*     */     }
/* 784 */     return m;
/*     */   }
/*     */   
/*     */ 
/*     */   private String makeSignatureString(MBeanParameterInfo[] params)
/*     */   {
/* 790 */     StringBuffer sb = new StringBuffer();
/* 791 */     for (int i = 0; i < params.length; i++)
/*     */     {
/* 793 */       if (i > 0)
/*     */       {
/* 795 */         sb.append(",");
/*     */       }
/* 797 */       sb.append(params[i].getType());
/*     */     }
/* 799 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private String getValueFromBundle(String key)
/*     */   {
/*     */     String value;
/*     */     try
/*     */     {
/* 807 */       value = this.m_bundle.getString(key);
/*     */     }
/*     */     catch (MissingResourceException e) {
/*     */       String value;
/* 811 */       value = "??(" + key + ")";
/*     */     }
/* 813 */     return value;
/*     */   }
/*     */   
/*     */   private String getValueOrNullFromBundle(String key)
/*     */   {
/* 818 */     String value = null;
/*     */     try
/*     */     {
/* 821 */       value = this.m_bundle.getString(key);
/*     */     }
/*     */     catch (MissingResourceException e) {}
/*     */     
/*     */ 
/* 826 */     return value;
/*     */   }
/*     */   
/*     */   private static class NestedResourceBundle extends ResourceBundle
/*     */   {
/*     */     private ResourceBundle _impl;
/*     */     
/*     */     NestedResourceBundle(ResourceBundle impl)
/*     */     {
/* 835 */       this._impl = impl;
/*     */     }
/*     */     
/*     */     void setParent(NestedResourceBundle parent)
/*     */     {
/* 840 */       super.setParent(parent);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected Object handleGetObject(String key)
/*     */     {
/*     */       try
/*     */       {
/* 850 */         return this._impl.getString(key);
/*     */       }
/*     */       catch (MissingResourceException e) {}
/*     */       
/* 854 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Enumeration getKeys()
/*     */     {
/* 864 */       HashSet hs = new HashSet();
/* 865 */       addEnumeration(hs, this._impl.getKeys());
/* 866 */       if (this.parent != null)
/*     */       {
/* 868 */         addEnumeration(hs, this.parent.getKeys());
/*     */       }
/* 870 */       return Collections.enumeration(hs);
/*     */     }
/*     */     
/*     */     private void addEnumeration(Collection col, Enumeration e)
/*     */     {
/* 875 */       while (e.hasMoreElements())
/*     */       {
/* 877 */         col.add(e.nextElement());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/i18n/I18NStandardMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */