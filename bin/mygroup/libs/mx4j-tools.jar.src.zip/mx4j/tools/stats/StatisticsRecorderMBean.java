package mx4j.tools.stats;

import java.util.Date;
import java.util.SortedMap;

public abstract interface StatisticsRecorderMBean
{
  public abstract Number getMax();
  
  public abstract Number getAverage();
  
  public abstract Number getMin();
  
  public abstract int getMaxEntries();
  
  public abstract void setMaxEntries(int paramInt);
  
  public abstract Date getRecordingStart();
  
  public abstract SortedMap getEntries();
  
  public abstract boolean isActive();
  
  public abstract void start();
  
  public abstract void stop();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/stats/StatisticsRecorderMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */