/*    */ package mx4j.tools.stats;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PointTime
/*    */   implements Comparable
/*    */ {
/*    */   private Date date;
/*    */   private long index;
/*    */   
/*    */   public PointTime(Date date, long index)
/*    */   {
/* 29 */     this.date = date;
/* 30 */     this.index = index;
/*    */   }
/*    */   
/*    */   public Date getDate()
/*    */   {
/* 35 */     return this.date;
/*    */   }
/*    */   
/*    */   public long getIndex()
/*    */   {
/* 40 */     return this.index;
/*    */   }
/*    */   
/*    */   public int compareTo(Object o)
/*    */   {
/* 45 */     PointTime p = (PointTime)o;
/* 46 */     if (this.date.equals(p.date))
/*    */     {
/* 48 */       return (int)(this.index - p.index);
/*    */     }
/*    */     
/*    */ 
/* 52 */     return this.date.compareTo(p.date);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 58 */     if (o == null)
/*    */     {
/* 60 */       throw new NullPointerException();
/*    */     }
/* 62 */     if (!(o instanceof PointTime))
/*    */     {
/* 64 */       return false;
/*    */     }
/* 66 */     PointTime p = (PointTime)o;
/* 67 */     return (p.date.equals(this.date)) && (p.index == this.index);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/stats/PointTime.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */