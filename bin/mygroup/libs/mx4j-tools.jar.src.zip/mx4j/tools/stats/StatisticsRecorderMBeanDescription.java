/*    */ package mx4j.tools.stats;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import mx4j.MBeanDescriptionAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatisticsRecorderMBeanDescription
/*    */   extends MBeanDescriptionAdapter
/*    */ {
/*    */   public String getAttributeDescription(String attribute)
/*    */   {
/* 25 */     if (attribute.equals("Max"))
/*    */     {
/* 27 */       return "Maximum observed value";
/*    */     }
/* 29 */     if (attribute.equals("Min"))
/*    */     {
/* 31 */       return "Minimum observed value";
/*    */     }
/* 33 */     if (attribute.equals("Average"))
/*    */     {
/* 35 */       return "Average of the observed values";
/*    */     }
/* 37 */     if (attribute.equals("MaxEntries"))
/*    */     {
/* 39 */       return "Amount of values stored in memory";
/*    */     }
/* 41 */     if (attribute.equals("RecordingStart"))
/*    */     {
/* 43 */       return "Date when the recording was inited";
/*    */     }
/* 45 */     if (attribute.equals("Entries"))
/*    */     {
/* 47 */       return "SortedMap of the recorded values indexed by PointTime values";
/*    */     }
/* 49 */     if (attribute.equals("Active"))
/*    */     {
/* 51 */       return "Indicates whether the MBean is recording";
/*    */     }
/* 53 */     return super.getAttributeDescription(attribute);
/*    */   }
/*    */   
/*    */   public String getOperationDescription(Method operation)
/*    */   {
/* 58 */     if (operation.equals("start"))
/*    */     {
/* 60 */       return "Starts the recording";
/*    */     }
/* 62 */     if (operation.equals("stop"))
/*    */     {
/* 64 */       return "Stops the recording";
/*    */     }
/* 66 */     return super.getOperationDescription(operation);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/stats/StatisticsRecorderMBeanDescription.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */