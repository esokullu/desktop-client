/*     */ package mx4j.tools.stats;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import javax.management.MBeanRegistration;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractStatisticsRecorder
/*     */   implements StatisticsRecorderMBean, MBeanRegistration
/*     */ {
/*  31 */   protected boolean isActive = false;
/*     */   
/*     */ 
/*     */   protected MBeanServer server;
/*     */   
/*     */ 
/*  37 */   protected int maxEntries = 256;
/*     */   
/*     */ 
/*  40 */   protected SortedMap entries = new TreeMap();
/*     */   
/*     */ 
/*     */   protected Date recordingStart;
/*     */   
/*     */ 
/*  46 */   protected boolean isDouble = false;
/*     */   
/*     */   protected double minimumValue;
/*     */   
/*     */   protected double maximumValue;
/*     */   protected double averageValue;
/*  52 */   protected long count = 0L;
/*     */   
/*     */   protected Logger getLogger()
/*     */   {
/*  56 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */   
/*     */   public void start()
/*     */   {
/*  61 */     Logger logger = getLogger();
/*  62 */     if (!this.isActive)
/*     */     {
/*  64 */       if (logger.isEnabledFor(10)) logger.debug("Starting statistics recorder " + this);
/*  65 */       this.isActive = true;
/*  66 */       this.recordingStart = new Date();
/*  67 */       this.entries.clear();
/*  68 */       this.minimumValue = (this.maximumValue = this.averageValue = 0.0D);
/*  69 */       this.count = 0L;
/*  70 */       this.isDouble = false;
/*     */       try
/*     */       {
/*  73 */         doStart();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*  77 */         logger.error("Exception while starting recorder " + this, e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/*  84 */     Logger logger = getLogger();
/*  85 */     if (this.isActive)
/*     */     {
/*  87 */       if (logger.isEnabledFor(10)) logger.debug("Starting statistics recorder " + this);
/*  88 */       this.isActive = false;
/*     */       try
/*     */       {
/*  91 */         doStop();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*  95 */         logger.error("Exception starting recorder " + this, e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Number getAverage()
/*     */   {
/* 102 */     return createValue(this.averageValue);
/*     */   }
/*     */   
/*     */   public Number getMin()
/*     */   {
/* 107 */     return createValue(this.minimumValue);
/*     */   }
/*     */   
/*     */   public Number getMax()
/*     */   {
/* 112 */     return createValue(this.maximumValue);
/*     */   }
/*     */   
/*     */   public synchronized boolean isActive()
/*     */   {
/* 117 */     return this.isActive;
/*     */   }
/*     */   
/*     */   public int getMaxEntries()
/*     */   {
/* 122 */     return this.maxEntries;
/*     */   }
/*     */   
/*     */   public void setMaxEntries(int maxEntries)
/*     */   {
/* 127 */     if (maxEntries <= 0)
/*     */     {
/* 129 */       throw new IllegalArgumentException("Max entries has to be bigger than 0");
/*     */     }
/* 131 */     this.maxEntries = maxEntries;
/*     */   }
/*     */   
/*     */   public SortedMap getEntries()
/*     */   {
/* 136 */     return (SortedMap)((TreeMap)this.entries).clone();
/*     */   }
/*     */   
/*     */   public Date getRecordingStart()
/*     */   {
/* 141 */     return this.recordingStart;
/*     */   }
/*     */   
/*     */   public ObjectName preRegister(MBeanServer server, ObjectName name) throws Exception
/*     */   {
/* 146 */     this.server = server;
/* 147 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */   public void postRegister(Boolean registrationDone) {}
/*     */   
/*     */   public void preDeregister()
/*     */     throws Exception
/*     */   {
/* 156 */     stop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void postDeregister() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doStart()
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doStop()
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void addEntry(Date key, Number value)
/*     */   {
/* 183 */     if (this.isActive)
/*     */     {
/* 185 */       this.entries.put(new PointTime(key, this.count++), value);
/* 186 */       if (this.entries.size() > this.maxEntries)
/*     */       {
/* 188 */         while (this.entries.size() > this.maxEntries)
/*     */         {
/* 190 */           this.entries.remove(this.entries.firstKey());
/*     */         }
/*     */       }
/* 193 */       calculateStats(value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void calculateStats(Number value)
/*     */   {
/* 202 */     if ((!this.isDouble) && (((value instanceof Double)) || ((value instanceof Float))))
/*     */     {
/* 204 */       this.isDouble = true;
/*     */     }
/* 206 */     double newValue = value.doubleValue();
/*     */     
/* 208 */     if (this.count == 1L)
/*     */     {
/* 210 */       this.maximumValue = (this.minimumValue = this.averageValue = newValue);
/* 211 */       return;
/*     */     }
/* 213 */     if (newValue > this.maximumValue)
/*     */     {
/* 215 */       this.maximumValue = newValue;
/*     */     }
/* 217 */     if (newValue < this.minimumValue)
/*     */     {
/* 219 */       this.minimumValue = newValue;
/*     */     }
/* 221 */     this.averageValue = ((1.0D - 1.0D / this.count) * this.averageValue + 1.0D / this.count * newValue);
/*     */   }
/*     */   
/*     */   private Number createValue(double targetValue)
/*     */   {
/* 226 */     if (this.isDouble)
/*     */     {
/* 228 */       return new Double(targetValue);
/*     */     }
/*     */     
/*     */ 
/* 232 */     return new Long(targetValue);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/stats/AbstractStatisticsRecorder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */