/*    */ package mx4j.tools.stats;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValueStatisticsRecorder
/*    */   extends AbstractStatisticsRecorder
/*    */   implements ValueStatisticsRecorderMBean
/*    */ {
/* 31 */   protected Number value = null;
/*    */   
/*    */   public void setValue(Number value)
/*    */   {
/* 35 */     this.value = value;
/* 36 */     addEntry(new Date(), value);
/*    */   }
/*    */   
/*    */   public Number getValue()
/*    */   {
/* 41 */     return this.value;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 46 */     return "ValueStatisticsRecorder";
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/stats/ValueStatisticsRecorder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */