/*     */ package mx4j.tools.stats;
/*     */ 
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ObserverStatisticsRecorder
/*     */   extends AbstractStatisticsRecorder
/*     */   implements ObserverStatisticsRecorderMBean
/*     */ {
/*  20 */   protected ObjectName observedName = null;
/*     */   
/*  22 */   protected String observedAttribute = null;
/*     */   
/*     */   public void setObservedObject(ObjectName object)
/*     */   {
/*  26 */     this.observedName = object;
/*     */   }
/*     */   
/*     */   public ObjectName getObservedObject()
/*     */   {
/*  31 */     return this.observedName;
/*     */   }
/*     */   
/*     */   public String getObservedAttribute()
/*     */   {
/*  36 */     return this.observedAttribute;
/*     */   }
/*     */   
/*     */   public void setObservedAttribute(String attribute)
/*     */   {
/*  41 */     this.observedAttribute = attribute;
/*     */   }
/*     */   
/*     */   protected void doStart() throws Exception
/*     */   {
/*  46 */     if ((this.observedName == null) || (this.observedAttribute == null))
/*     */     {
/*  48 */       getLogger().warn(toString() + " cannot start with objectName " + this.observedName + " and attribute " + this.observedAttribute);
/*  49 */       stop();
/*  50 */       return;
/*     */     }
/*  52 */     if (!this.server.isRegistered(this.observedName))
/*     */     {
/*  54 */       getLogger().warn(toString() + " cannot start since objectName is not registered");
/*  55 */       stop();
/*  56 */       return;
/*     */     }
/*     */     
/*  59 */     MBeanInfo info = this.server.getMBeanInfo(this.observedName);
/*  60 */     MBeanAttributeInfo[] attributes = info.getAttributes();
/*  61 */     MBeanAttributeInfo theAttribute = null;
/*  62 */     boolean found = false;
/*  63 */     for (int i = 0; i < attributes.length; i++)
/*     */     {
/*  65 */       if (attributes[i].getName().equals(this.observedAttribute))
/*     */       {
/*  67 */         theAttribute = attributes[i];
/*  68 */         found = true;
/*  69 */         break;
/*     */       }
/*     */     }
/*  72 */     if (!found)
/*     */     {
/*  74 */       getLogger().warn(toString() + " cannot start with objectName " + this.observedName + " since attribute " + this.observedAttribute + " does not belong to the MBean interface");
/*  75 */       stop();
/*  76 */       return;
/*     */     }
/*  78 */     if (!theAttribute.isReadable())
/*     */     {
/*  80 */       getLogger().warn(toString() + " cannot start with objectName " + this.observedName + " since attribute " + this.observedAttribute + " is not readable");
/*  81 */       stop();
/*  82 */       return;
/*     */     }
/*  84 */     Object value = this.server.getAttribute(this.observedName, this.observedAttribute);
/*  85 */     if (!(value instanceof Number))
/*     */     {
/*  87 */       getLogger().warn(toString() + " cannot start with objectName " + this.observedName + " since attribute " + this.observedAttribute + " is not a number");
/*  88 */       stop();
/*  89 */       return;
/*     */     }
/*  91 */     startObserving();
/*     */   }
/*     */   
/*     */   protected abstract void startObserving() throws Exception;
/*     */   
/*     */   protected abstract void stopObserving() throws Exception;
/*     */   
/*     */   protected void doStop() throws Exception
/*     */   {
/* 100 */     stopObserving();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/stats/ObserverStatisticsRecorder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */