package mx4j.tools.stats;

import javax.management.ObjectName;

public abstract interface ObserverStatisticsRecorderMBean
  extends StatisticsRecorderMBean
{
  public abstract void setObservedObject(ObjectName paramObjectName);
  
  public abstract ObjectName getObservedObject();
  
  public abstract String getObservedAttribute();
  
  public abstract void setObservedAttribute(String paramString);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/stats/ObserverStatisticsRecorderMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */