/*    */ package mx4j.tools.stats;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObserverStatisticsRecorderMBeanDescription
/*    */   extends StatisticsRecorderMBeanDescription
/*    */ {
/*    */   public String getAttributeDescription(String attribute)
/*    */   {
/* 21 */     if (attribute.equals("ObservedAttribute"))
/*    */     {
/* 23 */       return "The Attribute to be observed";
/*    */     }
/* 25 */     if (attribute.equals("ObservedObject"))
/*    */     {
/* 27 */       return "The ObjectName to be observed";
/*    */     }
/* 29 */     return super.getAttributeDescription(attribute);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/stats/ObserverStatisticsRecorderMBeanDescription.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */