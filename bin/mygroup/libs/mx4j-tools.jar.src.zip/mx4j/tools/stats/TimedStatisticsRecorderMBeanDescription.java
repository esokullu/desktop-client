/*    */ package mx4j.tools.stats;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimedStatisticsRecorderMBeanDescription
/*    */   extends ObserverStatisticsRecorderMBeanDescription
/*    */ {
/*    */   public String getAttributeDescription(String attribute)
/*    */   {
/* 20 */     if ("Granularity".equals(attribute))
/*    */     {
/* 22 */       return "How often the MBean will poll the variable value";
/*    */     }
/* 24 */     return super.getAttributeDescription(attribute);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/stats/TimedStatisticsRecorderMBeanDescription.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */