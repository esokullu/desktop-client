/*    */ package mx4j.tools.stats;
/*    */ 
/*    */ import java.util.Date;
/*    */ import java.util.Timer;
/*    */ import java.util.TimerTask;
/*    */ import javax.management.MBeanServer;
/*    */ import mx4j.log.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimedStatisticsRecorder
/*    */   extends ObserverStatisticsRecorder
/*    */   implements TimedStatisticsRecorderMBean
/*    */ {
/* 23 */   protected boolean registered = false;
/*    */   
/* 25 */   protected static Timer timer = new Timer();
/*    */   
/* 27 */   protected CollectTask task = new CollectTask(null);
/*    */   
/* 29 */   protected long granularity = 1000L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setGranularity(long granularity)
/*    */   {
/* 37 */     this.granularity = granularity;
/*    */   }
/*    */   
/*    */   public long getGranularity()
/*    */   {
/* 42 */     return this.granularity;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 47 */     return "TimedStatisticsRecorder";
/*    */   }
/*    */   
/*    */   protected synchronized void startObserving() throws Exception
/*    */   {
/* 52 */     this.task = new CollectTask(null);
/* 53 */     timer.schedule(this.task, 0L, this.granularity);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/* 58 */   protected synchronized void stopObserving() throws Exception { this.task.cancel(); }
/*    */   
/*    */   private class CollectTask extends TimerTask {
/* 61 */     CollectTask(TimedStatisticsRecorder.1 x1) { this(); }
/*    */     
/*    */     public void run()
/*    */     {
/*    */       try
/*    */       {
/* 67 */         Number value = (Number)TimedStatisticsRecorder.this.server.getAttribute(TimedStatisticsRecorder.this.observedName, TimedStatisticsRecorder.this.observedAttribute);
/* 68 */         TimedStatisticsRecorder.this.addEntry(new Date(), value);
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 72 */         TimedStatisticsRecorder.this.getLogger().error(" Exception reading attribute " + TimedStatisticsRecorder.this.observedAttribute + " of MBean " + TimedStatisticsRecorder.this.observedName, e);
/*    */       }
/*    */     }
/*    */     
/*    */     private CollectTask() {}
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/stats/TimedStatisticsRecorder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */