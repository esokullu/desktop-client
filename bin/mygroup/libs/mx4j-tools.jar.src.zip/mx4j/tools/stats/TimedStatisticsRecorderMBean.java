package mx4j.tools.stats;

public abstract interface TimedStatisticsRecorderMBean
  extends ObserverStatisticsRecorderMBean
{
  public abstract void setGranularity(long paramLong);
  
  public abstract long getGranularity();
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/stats/TimedStatisticsRecorderMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */