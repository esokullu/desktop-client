/*    */ package mx4j.tools.stats;
/*    */ 
/*    */ import java.util.Date;
/*    */ import javax.management.AttributeChangeNotification;
/*    */ import javax.management.AttributeChangeNotificationFilter;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.Notification;
/*    */ import javax.management.NotificationListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotificationStatisticsRecorder
/*    */   extends ObserverStatisticsRecorder
/*    */   implements NotificationListener
/*    */ {
/* 26 */   protected boolean registered = false;
/*    */   
/*    */   protected void startObserving() throws Exception
/*    */   {
/* 30 */     AttributeChangeNotificationFilter filter = new AttributeChangeNotificationFilter();
/* 31 */     filter.enableAttribute(this.observedAttribute);
/* 32 */     this.server.addNotificationListener(this.observedName, this, filter, null);
/* 33 */     this.registered = true;
/*    */   }
/*    */   
/*    */   protected void stopObserving() throws Exception
/*    */   {
/* 38 */     if (this.registered)
/*    */     {
/* 40 */       this.server.removeNotificationListener(this.observedName, this);
/*    */     }
/*    */   }
/*    */   
/*    */   public void handleNotification(Notification notification, Object object)
/*    */   {
/* 46 */     AttributeChangeNotification anot = (AttributeChangeNotification)notification;
/* 47 */     addEntry(new Date(), (Number)anot.getNewValue());
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 52 */     return "NotificationStatisticsRecorder";
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/stats/NotificationStatisticsRecorder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */