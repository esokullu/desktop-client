/*    */ package mx4j.tools.stats;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValueStatisticsRecorderMBeanDescription
/*    */   extends StatisticsRecorderMBeanDescription
/*    */ {
/*    */   public String getAttributeDescription(String attribute)
/*    */   {
/* 21 */     if ("Value".equals(attribute))
/*    */     {
/* 23 */       return "The value to be recorded";
/*    */     }
/* 25 */     return super.getAttributeDescription(attribute);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-tools.jar!/mx4j/tools/stats/ValueStatisticsRecorderMBeanDescription.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */