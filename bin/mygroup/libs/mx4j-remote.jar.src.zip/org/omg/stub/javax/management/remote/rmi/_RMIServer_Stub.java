/*     */ package org.omg.stub.javax.management.remote.rmi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.UnexpectedException;
/*     */ import javax.management.remote.rmi.RMIConnection;
/*     */ import javax.management.remote.rmi.RMIServer;
/*     */ import javax.rmi.CORBA.Stub;
/*     */ import javax.rmi.CORBA.Util;
/*     */ import javax.rmi.PortableRemoteObject;
/*     */ import org.omg.CORBA.SystemException;
/*     */ import org.omg.CORBA.portable.ApplicationException;
/*     */ import org.omg.CORBA.portable.ObjectImpl;
/*     */ import org.omg.CORBA.portable.OutputStream;
/*     */ import org.omg.CORBA.portable.RemarshalException;
/*     */ import org.omg.CORBA.portable.ServantObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class _RMIServer_Stub
/*     */   extends Stub
/*     */   implements RMIServer
/*     */ {
/*  27 */   private static final String[] _type_ids = {
/*  28 */     "RMI:javax.management.remote.rmi.RMIServer:0000000000000000" };
/*     */   
/*     */ 
/*     */ 
/*  32 */   public String[] _ids() { return _type_ids; }
/*     */   
/*     */   public String getVersion() throws RemoteException {
/*     */     String str1;
/*  36 */     if (!Util.isLocal(this)) {
/*     */       try {
/*  38 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*     */         try {
/*  40 */           OutputStream out = _request("_get_version", true);
/*  41 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/*  42 */           return (String)in.read_value(String.class);
/*     */         } catch (ApplicationException ex) {
/*  44 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  45 */           String id = in.read_string();
/*  46 */           throw new UnexpectedException(id);
/*     */         } catch (RemarshalException localRemarshalException) {
/*  48 */           return getVersion();
/*     */         } finally {
/*  50 */           _releaseReply(in);
/*     */         }
/*     */       } catch (SystemException ex) {
/*  53 */         throw Util.mapSystemException(ex);
/*     */       }
/*     */     }
/*  56 */     ServantObject so = _servant_preinvoke("_get_version", RMIServer.class);
/*  57 */     if (so == null) {
/*  58 */       return getVersion();
/*     */     }
/*     */     try {
/*  61 */       return ((RMIServer)so.servant).getVersion();
/*     */     } catch (Throwable ex) {
/*  63 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*  64 */       throw Util.wrapException(exCopy);
/*     */     } finally {
/*  66 */       _servant_postinvoke(so);
/*     */     }
/*     */   }
/*     */   
/*     */   public RMIConnection newClient(Object arg0) throws IOException {
/*     */     RMIConnection localRMIConnection1;
/*  72 */     if (!Util.isLocal(this)) {
/*     */       try {
/*  74 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*     */         try {
/*  76 */           OutputStream out = _request("newClient", true);
/*  77 */           Util.writeAny(out, arg0);
/*  78 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/*  79 */           return (RMIConnection)PortableRemoteObject.narrow(in.read_Object(), RMIConnection.class);
/*     */         } catch (ApplicationException ex) {
/*  81 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  82 */           String id = in.read_string();
/*  83 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  84 */             throw ((IOException)in.read_value(IOException.class));
/*     */           }
/*  86 */           throw new UnexpectedException(id);
/*     */         } catch (RemarshalException localRemarshalException) {
/*  88 */           return newClient(arg0);
/*     */         } finally {
/*  90 */           _releaseReply(in);
/*     */         }
/*     */       } catch (SystemException ex) {
/*  93 */         throw Util.mapSystemException(ex);
/*     */       }
/*     */     }
/*  96 */     ServantObject so = _servant_preinvoke("newClient", RMIServer.class);
/*  97 */     if (so == null) {
/*  98 */       return newClient(arg0);
/*     */     }
/*     */     try {
/* 101 */       Object arg0Copy = Util.copyObject(arg0, _orb());
/* 102 */       RMIConnection result = ((RMIServer)so.servant).newClient(arg0Copy);
/* 103 */       return (RMIConnection)Util.copyObject(result, _orb());
/*     */     } catch (Throwable ex) {
/* 105 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/* 106 */       if ((exCopy instanceof IOException)) {
/* 107 */         throw ((IOException)exCopy);
/*     */       }
/* 109 */       throw Util.wrapException(exCopy);
/*     */     } finally {
/* 111 */       _servant_postinvoke(so);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/org/omg/stub/javax/management/remote/rmi/_RMIServer_Stub.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */