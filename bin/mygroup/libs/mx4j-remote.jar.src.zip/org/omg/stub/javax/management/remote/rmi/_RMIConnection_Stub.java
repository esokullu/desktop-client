/*      */ package org.omg.stub.javax.management.remote.rmi;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.rmi.MarshalledObject;
/*      */ import java.rmi.UnexpectedException;
/*      */ import java.util.Set;
/*      */ import javax.management.AttributeList;
/*      */ import javax.management.AttributeNotFoundException;
/*      */ import javax.management.InstanceAlreadyExistsException;
/*      */ import javax.management.InstanceNotFoundException;
/*      */ import javax.management.IntrospectionException;
/*      */ import javax.management.InvalidAttributeValueException;
/*      */ import javax.management.ListenerNotFoundException;
/*      */ import javax.management.MBeanException;
/*      */ import javax.management.MBeanInfo;
/*      */ import javax.management.MBeanRegistrationException;
/*      */ import javax.management.NotCompliantMBeanException;
/*      */ import javax.management.ObjectInstance;
/*      */ import javax.management.ObjectName;
/*      */ import javax.management.ReflectionException;
/*      */ import javax.management.remote.NotificationResult;
/*      */ import javax.management.remote.rmi.RMIConnection;
/*      */ import javax.rmi.CORBA.Stub;
/*      */ import javax.rmi.CORBA.Util;
/*      */ import javax.security.auth.Subject;
/*      */ import org.omg.CORBA.SystemException;
/*      */ import org.omg.CORBA.portable.ApplicationException;
/*      */ import org.omg.CORBA.portable.ObjectImpl;
/*      */ import org.omg.CORBA.portable.RemarshalException;
/*      */ import org.omg.CORBA.portable.ServantObject;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class _RMIConnection_Stub
/*      */   extends Stub
/*      */   implements RMIConnection
/*      */ {
/*   44 */   private static final String[] _type_ids = {
/*   45 */     "RMI:javax.management.remote.rmi.RMIConnection:0000000000000000" };
/*      */   
/*      */ 
/*      */ 
/*   49 */   public String[] _ids() { return _type_ids; }
/*      */   
/*      */   public String getConnectionId() throws IOException {
/*      */     String str1;
/*   53 */     if (!Util.isLocal(this)) {
/*      */       try {
/*   55 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*   57 */           org.omg.CORBA.portable.OutputStream out = _request("getConnectionId", true);
/*   58 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/*   59 */           return (String)in.read_value(String.class);
/*      */         } catch (ApplicationException ex) {
/*   61 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*   62 */           String id = in.read_string();
/*   63 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*   64 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*   66 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*   68 */           return getConnectionId();
/*      */         } finally {
/*   70 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*   73 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*   76 */     ServantObject so = _servant_preinvoke("getConnectionId", RMIConnection.class);
/*   77 */     if (so == null) {
/*   78 */       return getConnectionId();
/*      */     }
/*      */     try {
/*   81 */       return ((RMIConnection)so.servant).getConnectionId();
/*      */     } catch (Throwable ex) {
/*   83 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*   84 */       if ((exCopy instanceof IOException)) {
/*   85 */         throw ((IOException)exCopy);
/*      */       }
/*   87 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/*   89 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public void close() throws IOException
/*      */   {
/*   95 */     if (!Util.isLocal(this)) {
/*      */       try {
/*   97 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*   99 */           org.omg.CORBA.portable.OutputStream out = _request("close", true);
/*  100 */           _invoke(out);
/*      */         } catch (ApplicationException ex) {
/*  102 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  103 */           String id = in.read_string();
/*  104 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  105 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*  107 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*  109 */           close();
/*      */         } finally {
/*  111 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*  114 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*  117 */     ServantObject so = _servant_preinvoke("close", RMIConnection.class);
/*  118 */     if (so == null) {
/*  119 */       close();
/*  120 */       return;
/*      */     }
/*      */     try {
/*  123 */       ((RMIConnection)so.servant).close();
/*      */     } catch (Throwable ex) {
/*  125 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*  126 */       if ((exCopy instanceof IOException)) {
/*  127 */         throw ((IOException)exCopy);
/*      */       }
/*  129 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/*  131 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public ObjectInstance createMBean(String arg0, ObjectName arg1, Subject arg2) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException {
/*      */     ObjectInstance localObjectInstance1;
/*  137 */     if (!Util.isLocal(this)) {
/*      */       try {
/*  139 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*  141 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/*  142 */             (org.omg.CORBA_2_3.portable.OutputStream)
/*  143 */             _request("createMBean__CORBA_WStringValue__javax_management_ObjectName__javax_security_auth_Subject", true);
/*  144 */           out.write_value(arg0, String.class);
/*  145 */           out.write_value(arg1, ObjectName.class);
/*  146 */           out.write_value(arg2, Subject.class);
/*  147 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/*  148 */           return (ObjectInstance)in.read_value(ObjectInstance.class);
/*      */         } catch (ApplicationException ex) {
/*  150 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  151 */           String id = in.read_string();
/*  152 */           if (id.equals("IDL:javax/management/ReflectionEx:1.0")) {
/*  153 */             throw ((ReflectionException)in.read_value(ReflectionException.class));
/*      */           }
/*  155 */           if (id.equals("IDL:javax/management/InstanceAlreadyExistsEx:1.0")) {
/*  156 */             throw ((InstanceAlreadyExistsException)in.read_value(InstanceAlreadyExistsException.class));
/*      */           }
/*  158 */           if (id.equals("IDL:javax/management/MBeanRegistrationEx:1.0")) {
/*  159 */             throw ((MBeanRegistrationException)in.read_value(MBeanRegistrationException.class));
/*      */           }
/*  161 */           if (id.equals("IDL:javax/management/MBeanEx:1.0")) {
/*  162 */             throw ((MBeanException)in.read_value(MBeanException.class));
/*      */           }
/*  164 */           if (id.equals("IDL:javax/management/NotCompliantMBeanEx:1.0")) {
/*  165 */             throw ((NotCompliantMBeanException)in.read_value(NotCompliantMBeanException.class));
/*      */           }
/*  167 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  168 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*  170 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*  172 */           return createMBean(arg0, arg1, arg2);
/*      */         } finally {
/*  174 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*  177 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*  180 */     ServantObject so = _servant_preinvoke("createMBean__CORBA_WStringValue__javax_management_ObjectName__javax_security_auth_Subject", RMIConnection.class);
/*  181 */     if (so == null) {
/*  182 */       return createMBean(arg0, arg1, arg2);
/*      */     }
/*      */     try {
/*  185 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2 }, _orb());
/*  186 */       String arg0Copy = (String)copies[0];
/*  187 */       ObjectName arg1Copy = (ObjectName)copies[1];
/*  188 */       Subject arg2Copy = (Subject)copies[2];
/*  189 */       ObjectInstance result = ((RMIConnection)so.servant).createMBean(arg0Copy, arg1Copy, arg2Copy);
/*  190 */       return (ObjectInstance)Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/*  192 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*  193 */       if ((exCopy instanceof ReflectionException)) {
/*  194 */         throw ((ReflectionException)exCopy);
/*      */       }
/*  196 */       if ((exCopy instanceof InstanceAlreadyExistsException)) {
/*  197 */         throw ((InstanceAlreadyExistsException)exCopy);
/*      */       }
/*  199 */       if ((exCopy instanceof MBeanRegistrationException)) {
/*  200 */         throw ((MBeanRegistrationException)exCopy);
/*      */       }
/*  202 */       if ((exCopy instanceof MBeanException)) {
/*  203 */         throw ((MBeanException)exCopy);
/*      */       }
/*  205 */       if ((exCopy instanceof NotCompliantMBeanException)) {
/*  206 */         throw ((NotCompliantMBeanException)exCopy);
/*      */       }
/*  208 */       if ((exCopy instanceof IOException)) {
/*  209 */         throw ((IOException)exCopy);
/*      */       }
/*  211 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/*  213 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public ObjectInstance createMBean(String arg0, ObjectName arg1, ObjectName arg2, Subject arg3) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException {
/*      */     ObjectInstance localObjectInstance1;
/*  219 */     if (!Util.isLocal(this)) {
/*      */       try {
/*  221 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*  223 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/*  224 */             (org.omg.CORBA_2_3.portable.OutputStream)
/*  225 */             _request("createMBean__CORBA_WStringValue__javax_management_ObjectName__javax_management_ObjectName__javax_security_auth_Subject", true);
/*  226 */           out.write_value(arg0, String.class);
/*  227 */           out.write_value(arg1, ObjectName.class);
/*  228 */           out.write_value(arg2, ObjectName.class);
/*  229 */           out.write_value(arg3, Subject.class);
/*  230 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/*  231 */           return (ObjectInstance)in.read_value(ObjectInstance.class);
/*      */         } catch (ApplicationException ex) {
/*  233 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  234 */           String id = in.read_string();
/*  235 */           if (id.equals("IDL:javax/management/ReflectionEx:1.0")) {
/*  236 */             throw ((ReflectionException)in.read_value(ReflectionException.class));
/*      */           }
/*  238 */           if (id.equals("IDL:javax/management/InstanceAlreadyExistsEx:1.0")) {
/*  239 */             throw ((InstanceAlreadyExistsException)in.read_value(InstanceAlreadyExistsException.class));
/*      */           }
/*  241 */           if (id.equals("IDL:javax/management/MBeanRegistrationEx:1.0")) {
/*  242 */             throw ((MBeanRegistrationException)in.read_value(MBeanRegistrationException.class));
/*      */           }
/*  244 */           if (id.equals("IDL:javax/management/MBeanEx:1.0")) {
/*  245 */             throw ((MBeanException)in.read_value(MBeanException.class));
/*      */           }
/*  247 */           if (id.equals("IDL:javax/management/NotCompliantMBeanEx:1.0")) {
/*  248 */             throw ((NotCompliantMBeanException)in.read_value(NotCompliantMBeanException.class));
/*      */           }
/*  250 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/*  251 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/*  253 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  254 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*  256 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*  258 */           return createMBean(arg0, arg1, arg2, arg3);
/*      */         } finally {
/*  260 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*  263 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*  266 */     ServantObject so = _servant_preinvoke("createMBean__CORBA_WStringValue__javax_management_ObjectName__javax_management_ObjectName__javax_security_auth_Subject", RMIConnection.class);
/*  267 */     if (so == null) {
/*  268 */       return createMBean(arg0, arg1, arg2, arg3);
/*      */     }
/*      */     try {
/*  271 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2, arg3 }, _orb());
/*  272 */       String arg0Copy = (String)copies[0];
/*  273 */       ObjectName arg1Copy = (ObjectName)copies[1];
/*  274 */       ObjectName arg2Copy = (ObjectName)copies[2];
/*  275 */       Subject arg3Copy = (Subject)copies[3];
/*  276 */       ObjectInstance result = ((RMIConnection)so.servant).createMBean(arg0Copy, arg1Copy, arg2Copy, arg3Copy);
/*  277 */       return (ObjectInstance)Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/*  279 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*  280 */       if ((exCopy instanceof ReflectionException)) {
/*  281 */         throw ((ReflectionException)exCopy);
/*      */       }
/*  283 */       if ((exCopy instanceof InstanceAlreadyExistsException)) {
/*  284 */         throw ((InstanceAlreadyExistsException)exCopy);
/*      */       }
/*  286 */       if ((exCopy instanceof MBeanRegistrationException)) {
/*  287 */         throw ((MBeanRegistrationException)exCopy);
/*      */       }
/*  289 */       if ((exCopy instanceof MBeanException)) {
/*  290 */         throw ((MBeanException)exCopy);
/*      */       }
/*  292 */       if ((exCopy instanceof NotCompliantMBeanException)) {
/*  293 */         throw ((NotCompliantMBeanException)exCopy);
/*      */       }
/*  295 */       if ((exCopy instanceof InstanceNotFoundException)) {
/*  296 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/*  298 */       if ((exCopy instanceof IOException)) {
/*  299 */         throw ((IOException)exCopy);
/*      */       }
/*  301 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/*  303 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public ObjectInstance createMBean(String arg0, ObjectName arg1, MarshalledObject arg2, String[] arg3, Subject arg4) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException {
/*      */     ObjectInstance localObjectInstance1;
/*  309 */     if (!Util.isLocal(this)) {
/*      */       try {
/*  311 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*  313 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/*  314 */             (org.omg.CORBA_2_3.portable.OutputStream)
/*  315 */             _request("createMBean__CORBA_WStringValue__javax_management_ObjectName__java_rmi_MarshalledObject__org_omg_boxedRMI_CORBA_seq1_WStringValue__javax_security_auth_Subject", true);
/*  316 */           out.write_value(arg0, String.class);
/*  317 */           out.write_value(arg1, ObjectName.class);
/*  318 */           out.write_value(arg2, MarshalledObject.class);
/*  319 */           out.write_value(cast_array(arg3), new String[0].getClass());
/*  320 */           out.write_value(arg4, Subject.class);
/*  321 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/*  322 */           return (ObjectInstance)in.read_value(ObjectInstance.class);
/*      */         } catch (ApplicationException ex) {
/*  324 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  325 */           String id = in.read_string();
/*  326 */           if (id.equals("IDL:javax/management/ReflectionEx:1.0")) {
/*  327 */             throw ((ReflectionException)in.read_value(ReflectionException.class));
/*      */           }
/*  329 */           if (id.equals("IDL:javax/management/InstanceAlreadyExistsEx:1.0")) {
/*  330 */             throw ((InstanceAlreadyExistsException)in.read_value(InstanceAlreadyExistsException.class));
/*      */           }
/*  332 */           if (id.equals("IDL:javax/management/MBeanRegistrationEx:1.0")) {
/*  333 */             throw ((MBeanRegistrationException)in.read_value(MBeanRegistrationException.class));
/*      */           }
/*  335 */           if (id.equals("IDL:javax/management/MBeanEx:1.0")) {
/*  336 */             throw ((MBeanException)in.read_value(MBeanException.class));
/*      */           }
/*  338 */           if (id.equals("IDL:javax/management/NotCompliantMBeanEx:1.0")) {
/*  339 */             throw ((NotCompliantMBeanException)in.read_value(NotCompliantMBeanException.class));
/*      */           }
/*  341 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  342 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*  344 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*  346 */           return createMBean(arg0, arg1, arg2, arg3, arg4);
/*      */         } finally {
/*  348 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*  351 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*  354 */     ServantObject so = _servant_preinvoke("createMBean__CORBA_WStringValue__javax_management_ObjectName__java_rmi_MarshalledObject__org_omg_boxedRMI_CORBA_seq1_WStringValue__javax_security_auth_Subject", RMIConnection.class);
/*  355 */     if (so == null) {
/*  356 */       return createMBean(arg0, arg1, arg2, arg3, arg4);
/*      */     }
/*      */     try {
/*  359 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2, arg3, arg4 }, _orb());
/*  360 */       String arg0Copy = (String)copies[0];
/*  361 */       ObjectName arg1Copy = (ObjectName)copies[1];
/*  362 */       MarshalledObject arg2Copy = (MarshalledObject)copies[2];
/*  363 */       String[] arg3Copy = (String[])copies[3];
/*  364 */       Subject arg4Copy = (Subject)copies[4];
/*  365 */       ObjectInstance result = ((RMIConnection)so.servant).createMBean(arg0Copy, arg1Copy, arg2Copy, arg3Copy, arg4Copy);
/*  366 */       return (ObjectInstance)Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/*  368 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*  369 */       if ((exCopy instanceof ReflectionException)) {
/*  370 */         throw ((ReflectionException)exCopy);
/*      */       }
/*  372 */       if ((exCopy instanceof InstanceAlreadyExistsException)) {
/*  373 */         throw ((InstanceAlreadyExistsException)exCopy);
/*      */       }
/*  375 */       if ((exCopy instanceof MBeanRegistrationException)) {
/*  376 */         throw ((MBeanRegistrationException)exCopy);
/*      */       }
/*  378 */       if ((exCopy instanceof MBeanException)) {
/*  379 */         throw ((MBeanException)exCopy);
/*      */       }
/*  381 */       if ((exCopy instanceof NotCompliantMBeanException)) {
/*  382 */         throw ((NotCompliantMBeanException)exCopy);
/*      */       }
/*  384 */       if ((exCopy instanceof IOException)) {
/*  385 */         throw ((IOException)exCopy);
/*      */       }
/*  387 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/*  389 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public ObjectInstance createMBean(String arg0, ObjectName arg1, ObjectName arg2, MarshalledObject arg3, String[] arg4, Subject arg5) throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException {
/*      */     ObjectInstance localObjectInstance1;
/*  395 */     if (!Util.isLocal(this)) {
/*      */       try {
/*  397 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*  399 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/*  400 */             (org.omg.CORBA_2_3.portable.OutputStream)
/*  401 */             _request("createMBean__CORBA_WStringValue__javax_management_ObjectName__javax_management_ObjectName__java_rmi_MarshalledObject__org_omg_boxedRMI_CORBA_seq1_WStringValue__javax_security_auth_Subject", true);
/*  402 */           out.write_value(arg0, String.class);
/*  403 */           out.write_value(arg1, ObjectName.class);
/*  404 */           out.write_value(arg2, ObjectName.class);
/*  405 */           out.write_value(arg3, MarshalledObject.class);
/*  406 */           out.write_value(cast_array(arg4), new String[0].getClass());
/*  407 */           out.write_value(arg5, Subject.class);
/*  408 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/*  409 */           return (ObjectInstance)in.read_value(ObjectInstance.class);
/*      */         } catch (ApplicationException ex) {
/*  411 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  412 */           String id = in.read_string();
/*  413 */           if (id.equals("IDL:javax/management/ReflectionEx:1.0")) {
/*  414 */             throw ((ReflectionException)in.read_value(ReflectionException.class));
/*      */           }
/*  416 */           if (id.equals("IDL:javax/management/InstanceAlreadyExistsEx:1.0")) {
/*  417 */             throw ((InstanceAlreadyExistsException)in.read_value(InstanceAlreadyExistsException.class));
/*      */           }
/*  419 */           if (id.equals("IDL:javax/management/MBeanRegistrationEx:1.0")) {
/*  420 */             throw ((MBeanRegistrationException)in.read_value(MBeanRegistrationException.class));
/*      */           }
/*  422 */           if (id.equals("IDL:javax/management/MBeanEx:1.0")) {
/*  423 */             throw ((MBeanException)in.read_value(MBeanException.class));
/*      */           }
/*  425 */           if (id.equals("IDL:javax/management/NotCompliantMBeanEx:1.0")) {
/*  426 */             throw ((NotCompliantMBeanException)in.read_value(NotCompliantMBeanException.class));
/*      */           }
/*  428 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/*  429 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/*  431 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  432 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*  434 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*  436 */           return createMBean(arg0, arg1, arg2, arg3, arg4, arg5);
/*      */         } finally {
/*  438 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*  441 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*  444 */     ServantObject so = _servant_preinvoke("createMBean__CORBA_WStringValue__javax_management_ObjectName__javax_management_ObjectName__java_rmi_MarshalledObject__org_omg_boxedRMI_CORBA_seq1_WStringValue__javax_security_auth_Subject", RMIConnection.class);
/*  445 */     if (so == null) {
/*  446 */       return createMBean(arg0, arg1, arg2, arg3, arg4, arg5);
/*      */     }
/*      */     try {
/*  449 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2, arg3, arg4, arg5 }, _orb());
/*  450 */       String arg0Copy = (String)copies[0];
/*  451 */       ObjectName arg1Copy = (ObjectName)copies[1];
/*  452 */       ObjectName arg2Copy = (ObjectName)copies[2];
/*  453 */       MarshalledObject arg3Copy = (MarshalledObject)copies[3];
/*  454 */       String[] arg4Copy = (String[])copies[4];
/*  455 */       Subject arg5Copy = (Subject)copies[5];
/*  456 */       ObjectInstance result = ((RMIConnection)so.servant).createMBean(arg0Copy, arg1Copy, arg2Copy, arg3Copy, arg4Copy, arg5Copy);
/*  457 */       return (ObjectInstance)Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/*  459 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*  460 */       if ((exCopy instanceof ReflectionException)) {
/*  461 */         throw ((ReflectionException)exCopy);
/*      */       }
/*  463 */       if ((exCopy instanceof InstanceAlreadyExistsException)) {
/*  464 */         throw ((InstanceAlreadyExistsException)exCopy);
/*      */       }
/*  466 */       if ((exCopy instanceof MBeanRegistrationException)) {
/*  467 */         throw ((MBeanRegistrationException)exCopy);
/*      */       }
/*  469 */       if ((exCopy instanceof MBeanException)) {
/*  470 */         throw ((MBeanException)exCopy);
/*      */       }
/*  472 */       if ((exCopy instanceof NotCompliantMBeanException)) {
/*  473 */         throw ((NotCompliantMBeanException)exCopy);
/*      */       }
/*  475 */       if ((exCopy instanceof InstanceNotFoundException)) {
/*  476 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/*  478 */       if ((exCopy instanceof IOException)) {
/*  479 */         throw ((IOException)exCopy);
/*      */       }
/*  481 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/*  483 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public void unregisterMBean(ObjectName arg0, Subject arg1) throws InstanceNotFoundException, MBeanRegistrationException, IOException
/*      */   {
/*  489 */     if (!Util.isLocal(this)) {
/*      */       try {
/*  491 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*  493 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/*  494 */             (org.omg.CORBA_2_3.portable.OutputStream)
/*  495 */             _request("unregisterMBean", true);
/*  496 */           out.write_value(arg0, ObjectName.class);
/*  497 */           out.write_value(arg1, Subject.class);
/*  498 */           _invoke(out);
/*      */         } catch (ApplicationException ex) {
/*  500 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  501 */           String id = in.read_string();
/*  502 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/*  503 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/*  505 */           if (id.equals("IDL:javax/management/MBeanRegistrationEx:1.0")) {
/*  506 */             throw ((MBeanRegistrationException)in.read_value(MBeanRegistrationException.class));
/*      */           }
/*  508 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  509 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*  511 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*  513 */           unregisterMBean(arg0, arg1);
/*      */         } finally {
/*  515 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*  518 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*  521 */     ServantObject so = _servant_preinvoke("unregisterMBean", RMIConnection.class);
/*  522 */     if (so == null) {
/*  523 */       unregisterMBean(arg0, arg1);
/*  524 */       return;
/*      */     }
/*      */     try {
/*  527 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1 }, _orb());
/*  528 */       ObjectName arg0Copy = (ObjectName)copies[0];
/*  529 */       Subject arg1Copy = (Subject)copies[1];
/*  530 */       ((RMIConnection)so.servant).unregisterMBean(arg0Copy, arg1Copy);
/*      */     } catch (Throwable ex) {
/*  532 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*  533 */       if ((exCopy instanceof InstanceNotFoundException)) {
/*  534 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/*  536 */       if ((exCopy instanceof MBeanRegistrationException)) {
/*  537 */         throw ((MBeanRegistrationException)exCopy);
/*      */       }
/*  539 */       if ((exCopy instanceof IOException)) {
/*  540 */         throw ((IOException)exCopy);
/*      */       }
/*  542 */       throw Util.wrapException(exCopy); } finally { Subject arg1Copy;
/*      */       ObjectName arg0Copy;
/*  544 */       Object[] copies; _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public ObjectInstance getObjectInstance(ObjectName arg0, Subject arg1) throws InstanceNotFoundException, IOException {
/*      */     ObjectInstance localObjectInstance1;
/*  550 */     if (!Util.isLocal(this)) {
/*      */       try {
/*  552 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*  554 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/*  555 */             (org.omg.CORBA_2_3.portable.OutputStream)
/*  556 */             _request("getObjectInstance", true);
/*  557 */           out.write_value(arg0, ObjectName.class);
/*  558 */           out.write_value(arg1, Subject.class);
/*  559 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/*  560 */           return (ObjectInstance)in.read_value(ObjectInstance.class);
/*      */         } catch (ApplicationException ex) {
/*  562 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  563 */           String id = in.read_string();
/*  564 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/*  565 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/*  567 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  568 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*  570 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*  572 */           return getObjectInstance(arg0, arg1);
/*      */         } finally {
/*  574 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*  577 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*  580 */     ServantObject so = _servant_preinvoke("getObjectInstance", RMIConnection.class);
/*  581 */     if (so == null) {
/*  582 */       return getObjectInstance(arg0, arg1);
/*      */     }
/*      */     try {
/*  585 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1 }, _orb());
/*  586 */       ObjectName arg0Copy = (ObjectName)copies[0];
/*  587 */       Subject arg1Copy = (Subject)copies[1];
/*  588 */       ObjectInstance result = ((RMIConnection)so.servant).getObjectInstance(arg0Copy, arg1Copy);
/*  589 */       return (ObjectInstance)Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/*  591 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*  592 */       if ((exCopy instanceof InstanceNotFoundException)) {
/*  593 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/*  595 */       if ((exCopy instanceof IOException)) {
/*  596 */         throw ((IOException)exCopy);
/*      */       }
/*  598 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/*  600 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public Set queryMBeans(ObjectName arg0, MarshalledObject arg1, Subject arg2) throws IOException {
/*      */     Set localSet1;
/*  606 */     if (!Util.isLocal(this)) {
/*      */       try {
/*  608 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*  610 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/*  611 */             (org.omg.CORBA_2_3.portable.OutputStream)
/*  612 */             _request("queryMBeans", true);
/*  613 */           out.write_value(arg0, ObjectName.class);
/*  614 */           out.write_value(arg1, MarshalledObject.class);
/*  615 */           out.write_value(arg2, Subject.class);
/*  616 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/*  617 */           return (Set)in.read_value(Set.class);
/*      */         } catch (ApplicationException ex) {
/*  619 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  620 */           String id = in.read_string();
/*  621 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  622 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*  624 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*  626 */           return queryMBeans(arg0, arg1, arg2);
/*      */         } finally {
/*  628 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*  631 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*  634 */     ServantObject so = _servant_preinvoke("queryMBeans", RMIConnection.class);
/*  635 */     if (so == null) {
/*  636 */       return queryMBeans(arg0, arg1, arg2);
/*      */     }
/*      */     try {
/*  639 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2 }, _orb());
/*  640 */       ObjectName arg0Copy = (ObjectName)copies[0];
/*  641 */       MarshalledObject arg1Copy = (MarshalledObject)copies[1];
/*  642 */       Subject arg2Copy = (Subject)copies[2];
/*  643 */       Set result = ((RMIConnection)so.servant).queryMBeans(arg0Copy, arg1Copy, arg2Copy);
/*  644 */       return (Set)Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/*  646 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*  647 */       if ((exCopy instanceof IOException)) {
/*  648 */         throw ((IOException)exCopy);
/*      */       }
/*  650 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/*  652 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public Set queryNames(ObjectName arg0, MarshalledObject arg1, Subject arg2) throws IOException {
/*      */     Set localSet1;
/*  658 */     if (!Util.isLocal(this)) {
/*      */       try {
/*  660 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*  662 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/*  663 */             (org.omg.CORBA_2_3.portable.OutputStream)
/*  664 */             _request("queryNames", true);
/*  665 */           out.write_value(arg0, ObjectName.class);
/*  666 */           out.write_value(arg1, MarshalledObject.class);
/*  667 */           out.write_value(arg2, Subject.class);
/*  668 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/*  669 */           return (Set)in.read_value(Set.class);
/*      */         } catch (ApplicationException ex) {
/*  671 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  672 */           String id = in.read_string();
/*  673 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  674 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*  676 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*  678 */           return queryNames(arg0, arg1, arg2);
/*      */         } finally {
/*  680 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*  683 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*  686 */     ServantObject so = _servant_preinvoke("queryNames", RMIConnection.class);
/*  687 */     if (so == null) {
/*  688 */       return queryNames(arg0, arg1, arg2);
/*      */     }
/*      */     try {
/*  691 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2 }, _orb());
/*  692 */       ObjectName arg0Copy = (ObjectName)copies[0];
/*  693 */       MarshalledObject arg1Copy = (MarshalledObject)copies[1];
/*  694 */       Subject arg2Copy = (Subject)copies[2];
/*  695 */       Set result = ((RMIConnection)so.servant).queryNames(arg0Copy, arg1Copy, arg2Copy);
/*  696 */       return (Set)Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/*  698 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*  699 */       if ((exCopy instanceof IOException)) {
/*  700 */         throw ((IOException)exCopy);
/*      */       }
/*  702 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/*  704 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isRegistered(ObjectName arg0, Subject arg1) throws IOException {
/*      */     boolean bool;
/*  710 */     if (!Util.isLocal(this)) {
/*      */       try {
/*  712 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*  714 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/*  715 */             (org.omg.CORBA_2_3.portable.OutputStream)
/*  716 */             _request("isRegistered", true);
/*  717 */           out.write_value(arg0, ObjectName.class);
/*  718 */           out.write_value(arg1, Subject.class);
/*  719 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/*  720 */           return in.read_boolean();
/*      */         } catch (ApplicationException ex) {
/*  722 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  723 */           String id = in.read_string();
/*  724 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  725 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*  727 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*  729 */           return isRegistered(arg0, arg1);
/*      */         } finally {
/*  731 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*  734 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*  737 */     ServantObject so = _servant_preinvoke("isRegistered", RMIConnection.class);
/*  738 */     if (so == null) {
/*  739 */       return isRegistered(arg0, arg1);
/*      */     }
/*      */     try {
/*  742 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1 }, _orb());
/*  743 */       ObjectName arg0Copy = (ObjectName)copies[0];
/*  744 */       Subject arg1Copy = (Subject)copies[1];
/*  745 */       return ((RMIConnection)so.servant).isRegistered(arg0Copy, arg1Copy);
/*      */     } catch (Throwable ex) {
/*  747 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*  748 */       if ((exCopy instanceof IOException)) {
/*  749 */         throw ((IOException)exCopy);
/*      */       }
/*  751 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/*  753 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public Integer getMBeanCount(Subject arg0) throws IOException {
/*      */     Integer localInteger1;
/*  759 */     if (!Util.isLocal(this)) {
/*      */       try {
/*  761 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*  763 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/*  764 */             (org.omg.CORBA_2_3.portable.OutputStream)
/*  765 */             _request("getMBeanCount", true);
/*  766 */           out.write_value(arg0, Subject.class);
/*  767 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/*  768 */           return (Integer)in.read_value(Integer.class);
/*      */         } catch (ApplicationException ex) {
/*  770 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  771 */           String id = in.read_string();
/*  772 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  773 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*  775 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*  777 */           return getMBeanCount(arg0);
/*      */         } finally {
/*  779 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*  782 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*  785 */     ServantObject so = _servant_preinvoke("getMBeanCount", RMIConnection.class);
/*  786 */     if (so == null) {
/*  787 */       return getMBeanCount(arg0);
/*      */     }
/*      */     try {
/*  790 */       Subject arg0Copy = (Subject)Util.copyObject(arg0, _orb());
/*  791 */       Integer result = ((RMIConnection)so.servant).getMBeanCount(arg0Copy);
/*  792 */       return (Integer)Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/*  794 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*  795 */       if ((exCopy instanceof IOException)) {
/*  796 */         throw ((IOException)exCopy);
/*      */       }
/*  798 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/*  800 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public Object getAttribute(ObjectName arg0, String arg1, Subject arg2) throws MBeanException, AttributeNotFoundException, InstanceNotFoundException, ReflectionException, IOException {
/*      */     Object localObject1;
/*  806 */     if (!Util.isLocal(this)) {
/*      */       try {
/*  808 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*  810 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/*  811 */             (org.omg.CORBA_2_3.portable.OutputStream)
/*  812 */             _request("getAttribute", true);
/*  813 */           out.write_value(arg0, ObjectName.class);
/*  814 */           out.write_value(arg1, String.class);
/*  815 */           out.write_value(arg2, Subject.class);
/*  816 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/*  817 */           return Util.readAny(in);
/*      */         } catch (ApplicationException ex) {
/*  819 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  820 */           String id = in.read_string();
/*  821 */           if (id.equals("IDL:javax/management/MBeanEx:1.0")) {
/*  822 */             throw ((MBeanException)in.read_value(MBeanException.class));
/*      */           }
/*  824 */           if (id.equals("IDL:javax/management/AttributeNotFoundEx:1.0")) {
/*  825 */             throw ((AttributeNotFoundException)in.read_value(AttributeNotFoundException.class));
/*      */           }
/*  827 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/*  828 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/*  830 */           if (id.equals("IDL:javax/management/ReflectionEx:1.0")) {
/*  831 */             throw ((ReflectionException)in.read_value(ReflectionException.class));
/*      */           }
/*  833 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  834 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*  836 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*  838 */           return getAttribute(arg0, arg1, arg2);
/*      */         } finally {
/*  840 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*  843 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*  846 */     ServantObject so = _servant_preinvoke("getAttribute", RMIConnection.class);
/*  847 */     if (so == null) {
/*  848 */       return getAttribute(arg0, arg1, arg2);
/*      */     }
/*      */     try {
/*  851 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2 }, _orb());
/*  852 */       ObjectName arg0Copy = (ObjectName)copies[0];
/*  853 */       String arg1Copy = (String)copies[1];
/*  854 */       Subject arg2Copy = (Subject)copies[2];
/*  855 */       Object result = ((RMIConnection)so.servant).getAttribute(arg0Copy, arg1Copy, arg2Copy);
/*  856 */       return Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/*  858 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*  859 */       if ((exCopy instanceof MBeanException)) {
/*  860 */         throw ((MBeanException)exCopy);
/*      */       }
/*  862 */       if ((exCopy instanceof AttributeNotFoundException)) {
/*  863 */         throw ((AttributeNotFoundException)exCopy);
/*      */       }
/*  865 */       if ((exCopy instanceof InstanceNotFoundException)) {
/*  866 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/*  868 */       if ((exCopy instanceof ReflectionException)) {
/*  869 */         throw ((ReflectionException)exCopy);
/*      */       }
/*  871 */       if ((exCopy instanceof IOException)) {
/*  872 */         throw ((IOException)exCopy);
/*      */       }
/*  874 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/*  876 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public AttributeList getAttributes(ObjectName arg0, String[] arg1, Subject arg2) throws InstanceNotFoundException, ReflectionException, IOException {
/*      */     AttributeList localAttributeList1;
/*  882 */     if (!Util.isLocal(this)) {
/*      */       try {
/*  884 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*  886 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/*  887 */             (org.omg.CORBA_2_3.portable.OutputStream)
/*  888 */             _request("getAttributes", true);
/*  889 */           out.write_value(arg0, ObjectName.class);
/*  890 */           out.write_value(cast_array(arg1), new String[0].getClass());
/*  891 */           out.write_value(arg2, Subject.class);
/*  892 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/*  893 */           return (AttributeList)in.read_value(AttributeList.class);
/*      */         } catch (ApplicationException ex) {
/*  895 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  896 */           String id = in.read_string();
/*  897 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/*  898 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/*  900 */           if (id.equals("IDL:javax/management/ReflectionEx:1.0")) {
/*  901 */             throw ((ReflectionException)in.read_value(ReflectionException.class));
/*      */           }
/*  903 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  904 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*  906 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*  908 */           return getAttributes(arg0, arg1, arg2);
/*      */         } finally {
/*  910 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*  913 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*  916 */     ServantObject so = _servant_preinvoke("getAttributes", RMIConnection.class);
/*  917 */     if (so == null) {
/*  918 */       return getAttributes(arg0, arg1, arg2);
/*      */     }
/*      */     try {
/*  921 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2 }, _orb());
/*  922 */       ObjectName arg0Copy = (ObjectName)copies[0];
/*  923 */       String[] arg1Copy = (String[])copies[1];
/*  924 */       Subject arg2Copy = (Subject)copies[2];
/*  925 */       AttributeList result = ((RMIConnection)so.servant).getAttributes(arg0Copy, arg1Copy, arg2Copy);
/*  926 */       return (AttributeList)Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/*  928 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/*  929 */       if ((exCopy instanceof InstanceNotFoundException)) {
/*  930 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/*  932 */       if ((exCopy instanceof ReflectionException)) {
/*  933 */         throw ((ReflectionException)exCopy);
/*      */       }
/*  935 */       if ((exCopy instanceof IOException)) {
/*  936 */         throw ((IOException)exCopy);
/*      */       }
/*  938 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/*  940 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAttribute(ObjectName arg0, MarshalledObject arg1, Subject arg2) throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException, IOException
/*      */   {
/*  946 */     if (!Util.isLocal(this)) {
/*      */       try {
/*  948 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/*  950 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/*  951 */             (org.omg.CORBA_2_3.portable.OutputStream)
/*  952 */             _request("setAttribute", true);
/*  953 */           out.write_value(arg0, ObjectName.class);
/*  954 */           out.write_value(arg1, MarshalledObject.class);
/*  955 */           out.write_value(arg2, Subject.class);
/*  956 */           _invoke(out);
/*      */         } catch (ApplicationException ex) {
/*  958 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/*  959 */           String id = in.read_string();
/*  960 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/*  961 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/*  963 */           if (id.equals("IDL:javax/management/AttributeNotFoundEx:1.0")) {
/*  964 */             throw ((AttributeNotFoundException)in.read_value(AttributeNotFoundException.class));
/*      */           }
/*  966 */           if (id.equals("IDL:javax/management/InvalidAttributeValueEx:1.0")) {
/*  967 */             throw ((InvalidAttributeValueException)in.read_value(InvalidAttributeValueException.class));
/*      */           }
/*  969 */           if (id.equals("IDL:javax/management/MBeanEx:1.0")) {
/*  970 */             throw ((MBeanException)in.read_value(MBeanException.class));
/*      */           }
/*  972 */           if (id.equals("IDL:javax/management/ReflectionEx:1.0")) {
/*  973 */             throw ((ReflectionException)in.read_value(ReflectionException.class));
/*      */           }
/*  975 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/*  976 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/*  978 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/*  980 */           setAttribute(arg0, arg1, arg2);
/*      */         } finally {
/*  982 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/*  985 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/*  988 */     ServantObject so = _servant_preinvoke("setAttribute", RMIConnection.class);
/*  989 */     if (so == null) {
/*  990 */       setAttribute(arg0, arg1, arg2);
/*  991 */       return;
/*      */     }
/*      */     try {
/*  994 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2 }, _orb());
/*  995 */       ObjectName arg0Copy = (ObjectName)copies[0];
/*  996 */       MarshalledObject arg1Copy = (MarshalledObject)copies[1];
/*  997 */       Subject arg2Copy = (Subject)copies[2];
/*  998 */       ((RMIConnection)so.servant).setAttribute(arg0Copy, arg1Copy, arg2Copy);
/*      */     } catch (Throwable ex) {
/* 1000 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/* 1001 */       if ((exCopy instanceof InstanceNotFoundException)) {
/* 1002 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/* 1004 */       if ((exCopy instanceof AttributeNotFoundException)) {
/* 1005 */         throw ((AttributeNotFoundException)exCopy);
/*      */       }
/* 1007 */       if ((exCopy instanceof InvalidAttributeValueException)) {
/* 1008 */         throw ((InvalidAttributeValueException)exCopy);
/*      */       }
/* 1010 */       if ((exCopy instanceof MBeanException)) {
/* 1011 */         throw ((MBeanException)exCopy);
/*      */       }
/* 1013 */       if ((exCopy instanceof ReflectionException)) {
/* 1014 */         throw ((ReflectionException)exCopy);
/*      */       }
/* 1016 */       if ((exCopy instanceof IOException)) {
/* 1017 */         throw ((IOException)exCopy);
/*      */       }
/* 1019 */       throw Util.wrapException(exCopy); } finally { Subject arg2Copy;
/*      */       MarshalledObject arg1Copy;
/* 1021 */       ObjectName arg0Copy; Object[] copies; _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public AttributeList setAttributes(ObjectName arg0, MarshalledObject arg1, Subject arg2) throws InstanceNotFoundException, ReflectionException, IOException {
/*      */     AttributeList localAttributeList1;
/* 1027 */     if (!Util.isLocal(this)) {
/*      */       try {
/* 1029 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/* 1031 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 1032 */             (org.omg.CORBA_2_3.portable.OutputStream)
/* 1033 */             _request("setAttributes", true);
/* 1034 */           out.write_value(arg0, ObjectName.class);
/* 1035 */           out.write_value(arg1, MarshalledObject.class);
/* 1036 */           out.write_value(arg2, Subject.class);
/* 1037 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/* 1038 */           return (AttributeList)in.read_value(AttributeList.class);
/*      */         } catch (ApplicationException ex) {
/* 1040 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/* 1041 */           String id = in.read_string();
/* 1042 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/* 1043 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/* 1045 */           if (id.equals("IDL:javax/management/ReflectionEx:1.0")) {
/* 1046 */             throw ((ReflectionException)in.read_value(ReflectionException.class));
/*      */           }
/* 1048 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/* 1049 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/* 1051 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/* 1053 */           return setAttributes(arg0, arg1, arg2);
/*      */         } finally {
/* 1055 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/* 1058 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/* 1061 */     ServantObject so = _servant_preinvoke("setAttributes", RMIConnection.class);
/* 1062 */     if (so == null) {
/* 1063 */       return setAttributes(arg0, arg1, arg2);
/*      */     }
/*      */     try {
/* 1066 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2 }, _orb());
/* 1067 */       ObjectName arg0Copy = (ObjectName)copies[0];
/* 1068 */       MarshalledObject arg1Copy = (MarshalledObject)copies[1];
/* 1069 */       Subject arg2Copy = (Subject)copies[2];
/* 1070 */       AttributeList result = ((RMIConnection)so.servant).setAttributes(arg0Copy, arg1Copy, arg2Copy);
/* 1071 */       return (AttributeList)Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/* 1073 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/* 1074 */       if ((exCopy instanceof InstanceNotFoundException)) {
/* 1075 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/* 1077 */       if ((exCopy instanceof ReflectionException)) {
/* 1078 */         throw ((ReflectionException)exCopy);
/*      */       }
/* 1080 */       if ((exCopy instanceof IOException)) {
/* 1081 */         throw ((IOException)exCopy);
/*      */       }
/* 1083 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/* 1085 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public Object invoke(ObjectName arg0, String arg1, MarshalledObject arg2, String[] arg3, Subject arg4) throws InstanceNotFoundException, MBeanException, ReflectionException, IOException {
/*      */     Object localObject1;
/* 1091 */     if (!Util.isLocal(this)) {
/*      */       try {
/* 1093 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/* 1095 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 1096 */             (org.omg.CORBA_2_3.portable.OutputStream)
/* 1097 */             _request("invoke", true);
/* 1098 */           out.write_value(arg0, ObjectName.class);
/* 1099 */           out.write_value(arg1, String.class);
/* 1100 */           out.write_value(arg2, MarshalledObject.class);
/* 1101 */           out.write_value(cast_array(arg3), new String[0].getClass());
/* 1102 */           out.write_value(arg4, Subject.class);
/* 1103 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/* 1104 */           return Util.readAny(in);
/*      */         } catch (ApplicationException ex) {
/* 1106 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/* 1107 */           String id = in.read_string();
/* 1108 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/* 1109 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/* 1111 */           if (id.equals("IDL:javax/management/MBeanEx:1.0")) {
/* 1112 */             throw ((MBeanException)in.read_value(MBeanException.class));
/*      */           }
/* 1114 */           if (id.equals("IDL:javax/management/ReflectionEx:1.0")) {
/* 1115 */             throw ((ReflectionException)in.read_value(ReflectionException.class));
/*      */           }
/* 1117 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/* 1118 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/* 1120 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/* 1122 */           return invoke(arg0, arg1, arg2, arg3, arg4);
/*      */         } finally {
/* 1124 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/* 1127 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/* 1130 */     ServantObject so = _servant_preinvoke("invoke", RMIConnection.class);
/* 1131 */     if (so == null) {
/* 1132 */       return invoke(arg0, arg1, arg2, arg3, arg4);
/*      */     }
/*      */     try {
/* 1135 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2, arg3, arg4 }, _orb());
/* 1136 */       ObjectName arg0Copy = (ObjectName)copies[0];
/* 1137 */       String arg1Copy = (String)copies[1];
/* 1138 */       MarshalledObject arg2Copy = (MarshalledObject)copies[2];
/* 1139 */       String[] arg3Copy = (String[])copies[3];
/* 1140 */       Subject arg4Copy = (Subject)copies[4];
/* 1141 */       Object result = ((RMIConnection)so.servant).invoke(arg0Copy, arg1Copy, arg2Copy, arg3Copy, arg4Copy);
/* 1142 */       return Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/* 1144 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/* 1145 */       if ((exCopy instanceof InstanceNotFoundException)) {
/* 1146 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/* 1148 */       if ((exCopy instanceof MBeanException)) {
/* 1149 */         throw ((MBeanException)exCopy);
/*      */       }
/* 1151 */       if ((exCopy instanceof ReflectionException)) {
/* 1152 */         throw ((ReflectionException)exCopy);
/*      */       }
/* 1154 */       if ((exCopy instanceof IOException)) {
/* 1155 */         throw ((IOException)exCopy);
/*      */       }
/* 1157 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/* 1159 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public String getDefaultDomain(Subject arg0) throws IOException {
/*      */     String str1;
/* 1165 */     if (!Util.isLocal(this)) {
/*      */       try {
/* 1167 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/* 1169 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 1170 */             (org.omg.CORBA_2_3.portable.OutputStream)
/* 1171 */             _request("getDefaultDomain", true);
/* 1172 */           out.write_value(arg0, Subject.class);
/* 1173 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/* 1174 */           return (String)in.read_value(String.class);
/*      */         } catch (ApplicationException ex) {
/* 1176 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/* 1177 */           String id = in.read_string();
/* 1178 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/* 1179 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/* 1181 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/* 1183 */           return getDefaultDomain(arg0);
/*      */         } finally {
/* 1185 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/* 1188 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/* 1191 */     ServantObject so = _servant_preinvoke("getDefaultDomain", RMIConnection.class);
/* 1192 */     if (so == null) {
/* 1193 */       return getDefaultDomain(arg0);
/*      */     }
/*      */     try {
/* 1196 */       Subject arg0Copy = (Subject)Util.copyObject(arg0, _orb());
/* 1197 */       return ((RMIConnection)so.servant).getDefaultDomain(arg0Copy);
/*      */     } catch (Throwable ex) {
/* 1199 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/* 1200 */       if ((exCopy instanceof IOException)) {
/* 1201 */         throw ((IOException)exCopy);
/*      */       }
/* 1203 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/* 1205 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public String[] getDomains(Subject arg0) throws IOException {
/*      */     String[] arrayOfString1;
/* 1211 */     if (!Util.isLocal(this)) {
/*      */       try {
/* 1213 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/* 1215 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 1216 */             (org.omg.CORBA_2_3.portable.OutputStream)
/* 1217 */             _request("getDomains", true);
/* 1218 */           out.write_value(arg0, Subject.class);
/* 1219 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/* 1220 */           return (String[])in.read_value(new String[0].getClass());
/*      */         } catch (ApplicationException ex) {
/* 1222 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/* 1223 */           String id = in.read_string();
/* 1224 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/* 1225 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/* 1227 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/* 1229 */           return getDomains(arg0);
/*      */         } finally {
/* 1231 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/* 1234 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/* 1237 */     ServantObject so = _servant_preinvoke("getDomains", RMIConnection.class);
/* 1238 */     if (so == null) {
/* 1239 */       return getDomains(arg0);
/*      */     }
/*      */     try {
/* 1242 */       Subject arg0Copy = (Subject)Util.copyObject(arg0, _orb());
/* 1243 */       String[] result = ((RMIConnection)so.servant).getDomains(arg0Copy);
/* 1244 */       return (String[])Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/* 1246 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/* 1247 */       if ((exCopy instanceof IOException)) {
/* 1248 */         throw ((IOException)exCopy);
/*      */       }
/* 1250 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/* 1252 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public MBeanInfo getMBeanInfo(ObjectName arg0, Subject arg1) throws InstanceNotFoundException, IntrospectionException, ReflectionException, IOException {
/*      */     MBeanInfo localMBeanInfo1;
/* 1258 */     if (!Util.isLocal(this)) {
/*      */       try {
/* 1260 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/* 1262 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 1263 */             (org.omg.CORBA_2_3.portable.OutputStream)
/* 1264 */             _request("getMBeanInfo", true);
/* 1265 */           out.write_value(arg0, ObjectName.class);
/* 1266 */           out.write_value(arg1, Subject.class);
/* 1267 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/* 1268 */           return (MBeanInfo)in.read_value(MBeanInfo.class);
/*      */         } catch (ApplicationException ex) {
/* 1270 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/* 1271 */           String id = in.read_string();
/* 1272 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/* 1273 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/* 1275 */           if (id.equals("IDL:javax/management/IntrospectionEx:1.0")) {
/* 1276 */             throw ((IntrospectionException)in.read_value(IntrospectionException.class));
/*      */           }
/* 1278 */           if (id.equals("IDL:javax/management/ReflectionEx:1.0")) {
/* 1279 */             throw ((ReflectionException)in.read_value(ReflectionException.class));
/*      */           }
/* 1281 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/* 1282 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/* 1284 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/* 1286 */           return getMBeanInfo(arg0, arg1);
/*      */         } finally {
/* 1288 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/* 1291 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/* 1294 */     ServantObject so = _servant_preinvoke("getMBeanInfo", RMIConnection.class);
/* 1295 */     if (so == null) {
/* 1296 */       return getMBeanInfo(arg0, arg1);
/*      */     }
/*      */     try {
/* 1299 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1 }, _orb());
/* 1300 */       ObjectName arg0Copy = (ObjectName)copies[0];
/* 1301 */       Subject arg1Copy = (Subject)copies[1];
/* 1302 */       MBeanInfo result = ((RMIConnection)so.servant).getMBeanInfo(arg0Copy, arg1Copy);
/* 1303 */       return (MBeanInfo)Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/* 1305 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/* 1306 */       if ((exCopy instanceof InstanceNotFoundException)) {
/* 1307 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/* 1309 */       if ((exCopy instanceof IntrospectionException)) {
/* 1310 */         throw ((IntrospectionException)exCopy);
/*      */       }
/* 1312 */       if ((exCopy instanceof ReflectionException)) {
/* 1313 */         throw ((ReflectionException)exCopy);
/*      */       }
/* 1315 */       if ((exCopy instanceof IOException)) {
/* 1316 */         throw ((IOException)exCopy);
/*      */       }
/* 1318 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/* 1320 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isInstanceOf(ObjectName arg0, String arg1, Subject arg2) throws InstanceNotFoundException, IOException {
/*      */     boolean bool;
/* 1326 */     if (!Util.isLocal(this)) {
/*      */       try {
/* 1328 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/* 1330 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 1331 */             (org.omg.CORBA_2_3.portable.OutputStream)
/* 1332 */             _request("isInstanceOf", true);
/* 1333 */           out.write_value(arg0, ObjectName.class);
/* 1334 */           out.write_value(arg1, String.class);
/* 1335 */           out.write_value(arg2, Subject.class);
/* 1336 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/* 1337 */           return in.read_boolean();
/*      */         } catch (ApplicationException ex) {
/* 1339 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/* 1340 */           String id = in.read_string();
/* 1341 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/* 1342 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/* 1344 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/* 1345 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/* 1347 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/* 1349 */           return isInstanceOf(arg0, arg1, arg2);
/*      */         } finally {
/* 1351 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/* 1354 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/* 1357 */     ServantObject so = _servant_preinvoke("isInstanceOf", RMIConnection.class);
/* 1358 */     if (so == null) {
/* 1359 */       return isInstanceOf(arg0, arg1, arg2);
/*      */     }
/*      */     try {
/* 1362 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2 }, _orb());
/* 1363 */       ObjectName arg0Copy = (ObjectName)copies[0];
/* 1364 */       String arg1Copy = (String)copies[1];
/* 1365 */       Subject arg2Copy = (Subject)copies[2];
/* 1366 */       return ((RMIConnection)so.servant).isInstanceOf(arg0Copy, arg1Copy, arg2Copy);
/*      */     } catch (Throwable ex) {
/* 1368 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/* 1369 */       if ((exCopy instanceof InstanceNotFoundException)) {
/* 1370 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/* 1372 */       if ((exCopy instanceof IOException)) {
/* 1373 */         throw ((IOException)exCopy);
/*      */       }
/* 1375 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/* 1377 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public void addNotificationListener(ObjectName arg0, ObjectName arg1, MarshalledObject arg2, MarshalledObject arg3, Subject arg4) throws InstanceNotFoundException, IOException
/*      */   {
/* 1383 */     if (!Util.isLocal(this)) {
/*      */       try {
/* 1385 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/* 1387 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 1388 */             (org.omg.CORBA_2_3.portable.OutputStream)
/* 1389 */             _request("addNotificationListener", true);
/* 1390 */           out.write_value(arg0, ObjectName.class);
/* 1391 */           out.write_value(arg1, ObjectName.class);
/* 1392 */           out.write_value(arg2, MarshalledObject.class);
/* 1393 */           out.write_value(arg3, MarshalledObject.class);
/* 1394 */           out.write_value(arg4, Subject.class);
/* 1395 */           _invoke(out);
/*      */         } catch (ApplicationException ex) {
/* 1397 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/* 1398 */           String id = in.read_string();
/* 1399 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/* 1400 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/* 1402 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/* 1403 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/* 1405 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/* 1407 */           addNotificationListener(arg0, arg1, arg2, arg3, arg4);
/*      */         } finally {
/* 1409 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/* 1412 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/* 1415 */     ServantObject so = _servant_preinvoke("addNotificationListener", RMIConnection.class);
/* 1416 */     if (so == null) {
/* 1417 */       addNotificationListener(arg0, arg1, arg2, arg3, arg4);
/* 1418 */       return;
/*      */     }
/*      */     try {
/* 1421 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2, arg3, arg4 }, _orb());
/* 1422 */       ObjectName arg0Copy = (ObjectName)copies[0];
/* 1423 */       ObjectName arg1Copy = (ObjectName)copies[1];
/* 1424 */       MarshalledObject arg2Copy = (MarshalledObject)copies[2];
/* 1425 */       MarshalledObject arg3Copy = (MarshalledObject)copies[3];
/* 1426 */       Subject arg4Copy = (Subject)copies[4];
/* 1427 */       ((RMIConnection)so.servant).addNotificationListener(arg0Copy, arg1Copy, arg2Copy, arg3Copy, arg4Copy);
/*      */     } catch (Throwable ex) {
/* 1429 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/* 1430 */       if ((exCopy instanceof InstanceNotFoundException)) {
/* 1431 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/* 1433 */       if ((exCopy instanceof IOException)) {
/* 1434 */         throw ((IOException)exCopy);
/*      */       }
/* 1436 */       throw Util.wrapException(exCopy); } finally { Subject arg4Copy;
/*      */       MarshalledObject arg3Copy;
/* 1438 */       MarshalledObject arg2Copy; ObjectName arg1Copy; ObjectName arg0Copy; Object[] copies; _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeNotificationListener(ObjectName arg0, ObjectName arg1, Subject arg2) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*      */   {
/* 1444 */     if (!Util.isLocal(this)) {
/*      */       try {
/* 1446 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/* 1448 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 1449 */             (org.omg.CORBA_2_3.portable.OutputStream)
/* 1450 */             _request("removeNotificationListener__javax_management_ObjectName__javax_management_ObjectName__javax_security_auth_Subject", true);
/* 1451 */           out.write_value(arg0, ObjectName.class);
/* 1452 */           out.write_value(arg1, ObjectName.class);
/* 1453 */           out.write_value(arg2, Subject.class);
/* 1454 */           _invoke(out);
/*      */         } catch (ApplicationException ex) {
/* 1456 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/* 1457 */           String id = in.read_string();
/* 1458 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/* 1459 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/* 1461 */           if (id.equals("IDL:javax/management/ListenerNotFoundEx:1.0")) {
/* 1462 */             throw ((ListenerNotFoundException)in.read_value(ListenerNotFoundException.class));
/*      */           }
/* 1464 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/* 1465 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/* 1467 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/* 1469 */           removeNotificationListener(arg0, arg1, arg2);
/*      */         } finally {
/* 1471 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/* 1474 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/* 1477 */     ServantObject so = _servant_preinvoke("removeNotificationListener__javax_management_ObjectName__javax_management_ObjectName__javax_security_auth_Subject", RMIConnection.class);
/* 1478 */     if (so == null) {
/* 1479 */       removeNotificationListener(arg0, arg1, arg2);
/* 1480 */       return;
/*      */     }
/*      */     try {
/* 1483 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2 }, _orb());
/* 1484 */       ObjectName arg0Copy = (ObjectName)copies[0];
/* 1485 */       ObjectName arg1Copy = (ObjectName)copies[1];
/* 1486 */       Subject arg2Copy = (Subject)copies[2];
/* 1487 */       ((RMIConnection)so.servant).removeNotificationListener(arg0Copy, arg1Copy, arg2Copy);
/*      */     } catch (Throwable ex) {
/* 1489 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/* 1490 */       if ((exCopy instanceof InstanceNotFoundException)) {
/* 1491 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/* 1493 */       if ((exCopy instanceof ListenerNotFoundException)) {
/* 1494 */         throw ((ListenerNotFoundException)exCopy);
/*      */       }
/* 1496 */       if ((exCopy instanceof IOException)) {
/* 1497 */         throw ((IOException)exCopy);
/*      */       }
/* 1499 */       throw Util.wrapException(exCopy); } finally { Subject arg2Copy;
/*      */       ObjectName arg1Copy;
/* 1501 */       ObjectName arg0Copy; Object[] copies; _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeNotificationListener(ObjectName arg0, ObjectName arg1, MarshalledObject arg2, MarshalledObject arg3, Subject arg4) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*      */   {
/* 1507 */     if (!Util.isLocal(this)) {
/*      */       try {
/* 1509 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/* 1511 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 1512 */             (org.omg.CORBA_2_3.portable.OutputStream)
/* 1513 */             _request("removeNotificationListener__javax_management_ObjectName__javax_management_ObjectName__java_rmi_MarshalledObject__java_rmi_MarshalledObject__javax_security_auth_Subject", true);
/* 1514 */           out.write_value(arg0, ObjectName.class);
/* 1515 */           out.write_value(arg1, ObjectName.class);
/* 1516 */           out.write_value(arg2, MarshalledObject.class);
/* 1517 */           out.write_value(arg3, MarshalledObject.class);
/* 1518 */           out.write_value(arg4, Subject.class);
/* 1519 */           _invoke(out);
/*      */         } catch (ApplicationException ex) {
/* 1521 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/* 1522 */           String id = in.read_string();
/* 1523 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/* 1524 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/* 1526 */           if (id.equals("IDL:javax/management/ListenerNotFoundEx:1.0")) {
/* 1527 */             throw ((ListenerNotFoundException)in.read_value(ListenerNotFoundException.class));
/*      */           }
/* 1529 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/* 1530 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/* 1532 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/* 1534 */           removeNotificationListener(arg0, arg1, arg2, arg3, arg4);
/*      */         } finally {
/* 1536 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/* 1539 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/* 1542 */     ServantObject so = _servant_preinvoke("removeNotificationListener__javax_management_ObjectName__javax_management_ObjectName__java_rmi_MarshalledObject__java_rmi_MarshalledObject__javax_security_auth_Subject", RMIConnection.class);
/* 1543 */     if (so == null) {
/* 1544 */       removeNotificationListener(arg0, arg1, arg2, arg3, arg4);
/* 1545 */       return;
/*      */     }
/*      */     try {
/* 1548 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2, arg3, arg4 }, _orb());
/* 1549 */       ObjectName arg0Copy = (ObjectName)copies[0];
/* 1550 */       ObjectName arg1Copy = (ObjectName)copies[1];
/* 1551 */       MarshalledObject arg2Copy = (MarshalledObject)copies[2];
/* 1552 */       MarshalledObject arg3Copy = (MarshalledObject)copies[3];
/* 1553 */       Subject arg4Copy = (Subject)copies[4];
/* 1554 */       ((RMIConnection)so.servant).removeNotificationListener(arg0Copy, arg1Copy, arg2Copy, arg3Copy, arg4Copy);
/*      */     } catch (Throwable ex) {
/* 1556 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/* 1557 */       if ((exCopy instanceof InstanceNotFoundException)) {
/* 1558 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/* 1560 */       if ((exCopy instanceof ListenerNotFoundException)) {
/* 1561 */         throw ((ListenerNotFoundException)exCopy);
/*      */       }
/* 1563 */       if ((exCopy instanceof IOException)) {
/* 1564 */         throw ((IOException)exCopy);
/*      */       }
/* 1566 */       throw Util.wrapException(exCopy); } finally { Subject arg4Copy;
/*      */       MarshalledObject arg3Copy;
/* 1568 */       MarshalledObject arg2Copy; ObjectName arg1Copy; ObjectName arg0Copy; Object[] copies; _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public Integer[] addNotificationListeners(ObjectName[] arg0, MarshalledObject[] arg1, Subject[] arg2) throws InstanceNotFoundException, IOException {
/*      */     Integer[] arrayOfInteger1;
/* 1574 */     if (!Util.isLocal(this)) {
/*      */       try {
/* 1576 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/* 1578 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 1579 */             (org.omg.CORBA_2_3.portable.OutputStream)
/* 1580 */             _request("addNotificationListeners", true);
/* 1581 */           out.write_value(cast_array(arg0), new ObjectName[0].getClass());
/* 1582 */           out.write_value(cast_array(arg1), new MarshalledObject[0].getClass());
/* 1583 */           out.write_value(cast_array(arg2), new Subject[0].getClass());
/* 1584 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/* 1585 */           return (Integer[])in.read_value(new Integer[0].getClass());
/*      */         } catch (ApplicationException ex) {
/* 1587 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/* 1588 */           String id = in.read_string();
/* 1589 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/* 1590 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/* 1592 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/* 1593 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/* 1595 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/* 1597 */           return addNotificationListeners(arg0, arg1, arg2);
/*      */         } finally {
/* 1599 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/* 1602 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/* 1605 */     ServantObject so = _servant_preinvoke("addNotificationListeners", RMIConnection.class);
/* 1606 */     if (so == null) {
/* 1607 */       return addNotificationListeners(arg0, arg1, arg2);
/*      */     }
/*      */     try {
/* 1610 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2 }, _orb());
/* 1611 */       ObjectName[] arg0Copy = (ObjectName[])copies[0];
/* 1612 */       MarshalledObject[] arg1Copy = (MarshalledObject[])copies[1];
/* 1613 */       Subject[] arg2Copy = (Subject[])copies[2];
/* 1614 */       Integer[] result = ((RMIConnection)so.servant).addNotificationListeners(arg0Copy, arg1Copy, arg2Copy);
/* 1615 */       return (Integer[])Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/* 1617 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/* 1618 */       if ((exCopy instanceof InstanceNotFoundException)) {
/* 1619 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/* 1621 */       if ((exCopy instanceof IOException)) {
/* 1622 */         throw ((IOException)exCopy);
/*      */       }
/* 1624 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/* 1626 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeNotificationListeners(ObjectName arg0, Integer[] arg1, Subject arg2) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*      */   {
/* 1632 */     if (!Util.isLocal(this)) {
/*      */       try {
/* 1634 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/* 1636 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 1637 */             (org.omg.CORBA_2_3.portable.OutputStream)
/* 1638 */             _request("removeNotificationListeners", true);
/* 1639 */           out.write_value(arg0, ObjectName.class);
/* 1640 */           out.write_value(cast_array(arg1), new Integer[0].getClass());
/* 1641 */           out.write_value(arg2, Subject.class);
/* 1642 */           _invoke(out);
/*      */         } catch (ApplicationException ex) {
/* 1644 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/* 1645 */           String id = in.read_string();
/* 1646 */           if (id.equals("IDL:javax/management/InstanceNotFoundEx:1.0")) {
/* 1647 */             throw ((InstanceNotFoundException)in.read_value(InstanceNotFoundException.class));
/*      */           }
/* 1649 */           if (id.equals("IDL:javax/management/ListenerNotFoundEx:1.0")) {
/* 1650 */             throw ((ListenerNotFoundException)in.read_value(ListenerNotFoundException.class));
/*      */           }
/* 1652 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/* 1653 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/* 1655 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/* 1657 */           removeNotificationListeners(arg0, arg1, arg2);
/*      */         } finally {
/* 1659 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/* 1662 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/* 1665 */     ServantObject so = _servant_preinvoke("removeNotificationListeners", RMIConnection.class);
/* 1666 */     if (so == null) {
/* 1667 */       removeNotificationListeners(arg0, arg1, arg2);
/* 1668 */       return;
/*      */     }
/*      */     try {
/* 1671 */       Object[] copies = Util.copyObjects(new Object[] { arg0, arg1, arg2 }, _orb());
/* 1672 */       ObjectName arg0Copy = (ObjectName)copies[0];
/* 1673 */       Integer[] arg1Copy = (Integer[])copies[1];
/* 1674 */       Subject arg2Copy = (Subject)copies[2];
/* 1675 */       ((RMIConnection)so.servant).removeNotificationListeners(arg0Copy, arg1Copy, arg2Copy);
/*      */     } catch (Throwable ex) {
/* 1677 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/* 1678 */       if ((exCopy instanceof InstanceNotFoundException)) {
/* 1679 */         throw ((InstanceNotFoundException)exCopy);
/*      */       }
/* 1681 */       if ((exCopy instanceof ListenerNotFoundException)) {
/* 1682 */         throw ((ListenerNotFoundException)exCopy);
/*      */       }
/* 1684 */       if ((exCopy instanceof IOException)) {
/* 1685 */         throw ((IOException)exCopy);
/*      */       }
/* 1687 */       throw Util.wrapException(exCopy); } finally { Subject arg2Copy;
/*      */       Integer[] arg1Copy;
/* 1689 */       ObjectName arg0Copy; Object[] copies; _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */   public NotificationResult fetchNotifications(long arg0, int arg1, long arg2) throws IOException {
/*      */     NotificationResult localNotificationResult1;
/* 1695 */     if (!Util.isLocal(this)) {
/*      */       try {
/* 1697 */         org.omg.CORBA_2_3.portable.InputStream in = null;
/*      */         try {
/* 1699 */           org.omg.CORBA.portable.OutputStream out = _request("fetchNotifications", true);
/* 1700 */           out.write_longlong(arg0);
/* 1701 */           out.write_long(arg1);
/* 1702 */           out.write_longlong(arg2);
/* 1703 */           in = (org.omg.CORBA_2_3.portable.InputStream)_invoke(out);
/* 1704 */           return (NotificationResult)in.read_value(NotificationResult.class);
/*      */         } catch (ApplicationException ex) {
/* 1706 */           in = (org.omg.CORBA_2_3.portable.InputStream)ex.getInputStream();
/* 1707 */           String id = in.read_string();
/* 1708 */           if (id.equals("IDL:java/io/IOEx:1.0")) {
/* 1709 */             throw ((IOException)in.read_value(IOException.class));
/*      */           }
/* 1711 */           throw new UnexpectedException(id);
/*      */         } catch (RemarshalException localRemarshalException) {
/* 1713 */           return fetchNotifications(arg0, arg1, arg2);
/*      */         } finally {
/* 1715 */           _releaseReply(in);
/*      */         }
/*      */       } catch (SystemException ex) {
/* 1718 */         throw Util.mapSystemException(ex);
/*      */       }
/*      */     }
/* 1721 */     ServantObject so = _servant_preinvoke("fetchNotifications", RMIConnection.class);
/* 1722 */     if (so == null) {
/* 1723 */       return fetchNotifications(arg0, arg1, arg2);
/*      */     }
/*      */     try {
/* 1726 */       NotificationResult result = ((RMIConnection)so.servant).fetchNotifications(arg0, arg1, arg2);
/* 1727 */       return (NotificationResult)Util.copyObject(result, _orb());
/*      */     } catch (Throwable ex) {
/* 1729 */       Throwable exCopy = (Throwable)Util.copyObject(ex, _orb());
/* 1730 */       if ((exCopy instanceof IOException)) {
/* 1731 */         throw ((IOException)exCopy);
/*      */       }
/* 1733 */       throw Util.wrapException(exCopy);
/*      */     } finally {
/* 1735 */       _servant_postinvoke(so);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Serializable cast_array(Object obj)
/*      */   {
/* 1744 */     return (Serializable)obj;
/*      */   }
/*      */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/org/omg/stub/javax/management/remote/rmi/_RMIConnection_Stub.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */