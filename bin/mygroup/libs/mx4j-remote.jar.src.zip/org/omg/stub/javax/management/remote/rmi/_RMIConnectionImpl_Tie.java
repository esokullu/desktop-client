/*     */ package org.omg.stub.javax.management.remote.rmi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.rmi.MarshalledObject;
/*     */ import java.rmi.Remote;
/*     */ import java.util.Set;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.remote.NotificationResult;
/*     */ import javax.management.remote.rmi.RMIConnectionImpl;
/*     */ import javax.rmi.CORBA.Tie;
/*     */ import javax.rmi.CORBA.Util;
/*     */ import javax.security.auth.Subject;
/*     */ import org.omg.CORBA.BAD_OPERATION;
/*     */ import org.omg.CORBA.BAD_PARAM;
/*     */ import org.omg.CORBA.SystemException;
/*     */ import org.omg.CORBA.portable.ResponseHandler;
/*     */ import org.omg.CORBA.portable.UnknownException;
/*     */ import org.omg.PortableServer.POA;
/*     */ import org.omg.PortableServer.POAOperations;
/*     */ import org.omg.PortableServer.POAPackage.ObjectNotActive;
/*     */ import org.omg.PortableServer.POAPackage.ServantNotActive;
/*     */ import org.omg.PortableServer.POAPackage.WrongPolicy;
/*     */ import org.omg.PortableServer.Servant;
/*     */ 
/*     */ public class _RMIConnectionImpl_Tie
/*     */   extends Servant
/*     */   implements Tie
/*     */ {
/*  43 */   private RMIConnectionImpl target = null;
/*     */   
/*  45 */   private static final String[] _type_ids = {
/*  46 */     "RMI:javax.management.remote.rmi.RMIConnection:0000000000000000" };
/*     */   
/*     */   public void setTarget(Remote target)
/*     */   {
/*  50 */     this.target = ((RMIConnectionImpl)target);
/*     */   }
/*     */   
/*     */   public Remote getTarget() {
/*  54 */     return this.target;
/*     */   }
/*     */   
/*     */   public org.omg.CORBA.Object thisObject() {
/*  58 */     return _this_object();
/*     */   }
/*     */   
/*     */   public void deactivate() {
/*     */     try {
/*  63 */       _poa().deactivate_object(_poa().servant_to_id(this));
/*     */     }
/*     */     catch (WrongPolicy localWrongPolicy) {}catch (ObjectNotActive localObjectNotActive) {}catch (ServantNotActive localServantNotActive) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public org.omg.CORBA.ORB orb()
/*     */   {
/*  74 */     return _orb();
/*     */   }
/*     */   
/*     */   public void orb(org.omg.CORBA.ORB orb) {
/*     */     try {
/*  79 */       ((org.omg.CORBA_2_3.ORB)orb).set_delegate(this);
/*     */     }
/*     */     catch (ClassCastException localClassCastException) {
/*  82 */       throw new BAD_PARAM(
/*  83 */         "POA Servant requires an instance of org.omg.CORBA_2_3.ORB");
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] _all_interfaces(POA poa, byte[] objectId) {
/*  88 */     return _type_ids;
/*     */   }
/*     */   
/*     */   public org.omg.CORBA.portable.OutputStream _invoke(String method, org.omg.CORBA.portable.InputStream _in, ResponseHandler reply) throws SystemException {
/*     */     try {
/*  93 */       org.omg.CORBA_2_3.portable.InputStream in = 
/*  94 */         (org.omg.CORBA_2_3.portable.InputStream)_in;
/*  95 */       switch (method.charAt(3)) {
/*     */       case 'A': 
/*  97 */         if (method.equals("getAttribute")) {
/*  98 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/*  99 */           String arg1 = (String)in.read_value(String.class);
/* 100 */           Subject arg2 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 103 */             result = this.target.getAttribute(arg0, arg1, arg2);
/*     */           } catch (MBeanException ex) { Object result;
/* 105 */             String id = "IDL:javax/management/MBeanEx:1.0";
/* 106 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 107 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 108 */             out.write_string(id);
/* 109 */             out.write_value(ex, MBeanException.class);
/* 110 */             return out;
/*     */           } catch (AttributeNotFoundException ex) {
/* 112 */             String id = "IDL:javax/management/AttributeNotFoundEx:1.0";
/* 113 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 114 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 115 */             out.write_string(id);
/* 116 */             out.write_value(ex, AttributeNotFoundException.class);
/* 117 */             return out;
/*     */           } catch (InstanceNotFoundException ex) {
/* 119 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 120 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 121 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 122 */             out.write_string(id);
/* 123 */             out.write_value(ex, InstanceNotFoundException.class);
/* 124 */             return out;
/*     */           } catch (ReflectionException ex) {
/* 126 */             String id = "IDL:javax/management/ReflectionEx:1.0";
/* 127 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 128 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 129 */             out.write_string(id);
/* 130 */             out.write_value(ex, ReflectionException.class);
/* 131 */             return out;
/*     */           } catch (IOException ex) {
/* 133 */             String id = "IDL:java/io/IOEx:1.0";
/* 134 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 135 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 136 */             out.write_string(id);
/* 137 */             out.write_value(ex, IOException.class);
/* 138 */             return out; }
/*     */           Object result;
/* 140 */           org.omg.CORBA.portable.OutputStream out = reply.createReply();
/* 141 */           Util.writeAny(out, result);
/* 142 */           return out; }
/* 143 */         if (method.equals("getAttributes")) {
/* 144 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 145 */           String[] arg1 = (String[])in.read_value(new String[0].getClass());
/* 146 */           Subject arg2 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 149 */             result = this.target.getAttributes(arg0, arg1, arg2);
/*     */           } catch (InstanceNotFoundException ex) { AttributeList result;
/* 151 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 152 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 153 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 154 */             out.write_string(id);
/* 155 */             out.write_value(ex, InstanceNotFoundException.class);
/* 156 */             return out;
/*     */           } catch (ReflectionException ex) {
/* 158 */             String id = "IDL:javax/management/ReflectionEx:1.0";
/* 159 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 160 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 161 */             out.write_string(id);
/* 162 */             out.write_value(ex, ReflectionException.class);
/* 163 */             return out;
/*     */           } catch (IOException ex) {
/* 165 */             String id = "IDL:java/io/IOEx:1.0";
/* 166 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 167 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 168 */             out.write_string(id);
/* 169 */             out.write_value(ex, IOException.class);
/* 170 */             return out; }
/*     */           AttributeList result;
/* 172 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 173 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 174 */           out.write_value(result, AttributeList.class);
/* 175 */           return out; }
/* 176 */         if (method.equals("setAttribute")) {
/* 177 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 178 */           MarshalledObject arg1 = (MarshalledObject)in.read_value(MarshalledObject.class);
/* 179 */           Subject arg2 = (Subject)in.read_value(Subject.class);
/*     */           try {
/* 181 */             this.target.setAttribute(arg0, arg1, arg2);
/*     */           } catch (InstanceNotFoundException ex) {
/* 183 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 184 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 185 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 186 */             out.write_string(id);
/* 187 */             out.write_value(ex, InstanceNotFoundException.class);
/* 188 */             return out;
/*     */           } catch (AttributeNotFoundException ex) {
/* 190 */             String id = "IDL:javax/management/AttributeNotFoundEx:1.0";
/* 191 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 192 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 193 */             out.write_string(id);
/* 194 */             out.write_value(ex, AttributeNotFoundException.class);
/* 195 */             return out;
/*     */           } catch (InvalidAttributeValueException ex) {
/* 197 */             String id = "IDL:javax/management/InvalidAttributeValueEx:1.0";
/* 198 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 199 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 200 */             out.write_string(id);
/* 201 */             out.write_value(ex, InvalidAttributeValueException.class);
/* 202 */             return out;
/*     */           } catch (MBeanException ex) {
/* 204 */             String id = "IDL:javax/management/MBeanEx:1.0";
/* 205 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 206 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 207 */             out.write_string(id);
/* 208 */             out.write_value(ex, MBeanException.class);
/* 209 */             return out;
/*     */           } catch (ReflectionException ex) {
/* 211 */             String id = "IDL:javax/management/ReflectionEx:1.0";
/* 212 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 213 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 214 */             out.write_string(id);
/* 215 */             out.write_value(ex, ReflectionException.class);
/* 216 */             return out;
/*     */           } catch (IOException ex) {
/* 218 */             String id = "IDL:java/io/IOEx:1.0";
/* 219 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 220 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 221 */             out.write_string(id);
/* 222 */             out.write_value(ex, IOException.class);
/* 223 */             return out;
/*     */           }
/* 225 */           return reply.createReply();
/*     */         }
/* 227 */         if (method.equals("setAttributes")) {
/* 228 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 229 */           MarshalledObject arg1 = (MarshalledObject)in.read_value(MarshalledObject.class);
/* 230 */           Subject arg2 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 233 */             result = this.target.setAttributes(arg0, arg1, arg2);
/*     */           } catch (InstanceNotFoundException ex) { AttributeList result;
/* 235 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 236 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 237 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 238 */             out.write_string(id);
/* 239 */             out.write_value(ex, InstanceNotFoundException.class);
/* 240 */             return out;
/*     */           } catch (ReflectionException ex) {
/* 242 */             String id = "IDL:javax/management/ReflectionEx:1.0";
/* 243 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 244 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 245 */             out.write_string(id);
/* 246 */             out.write_value(ex, ReflectionException.class);
/* 247 */             return out;
/*     */           } catch (IOException ex) {
/* 249 */             String id = "IDL:java/io/IOEx:1.0";
/* 250 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 251 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 252 */             out.write_string(id);
/* 253 */             out.write_value(ex, IOException.class);
/* 254 */             return out; }
/*     */           AttributeList result;
/* 256 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 257 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 258 */           out.write_value(result, AttributeList.class);
/* 259 */           return out;
/*     */         }
/*     */       case 'C': 
/* 262 */         if (method.equals("getConnectionId"))
/*     */         {
/*     */           try {
/* 265 */             result = this.target.getConnectionId();
/*     */           } catch (IOException ex) { String result;
/* 267 */             String id = "IDL:java/io/IOEx:1.0";
/* 268 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 269 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 270 */             out.write_string(id);
/* 271 */             out.write_value(ex, IOException.class);
/* 272 */             return out; }
/*     */           String result;
/* 274 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 275 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 276 */           out.write_value(result, String.class);
/* 277 */           return out;
/*     */         }
/*     */       case 'D': 
/* 280 */         if (method.equals("getDefaultDomain")) {
/* 281 */           Subject arg0 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 284 */             result = this.target.getDefaultDomain(arg0);
/*     */           } catch (IOException ex) { String result;
/* 286 */             String id = "IDL:java/io/IOEx:1.0";
/* 287 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 288 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 289 */             out.write_string(id);
/* 290 */             out.write_value(ex, IOException.class);
/* 291 */             return out; }
/*     */           String result;
/* 293 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 294 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 295 */           out.write_value(result, String.class);
/* 296 */           return out; }
/* 297 */         if (method.equals("getDomains")) {
/* 298 */           Subject arg0 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 301 */             result = this.target.getDomains(arg0);
/*     */           } catch (IOException ex) { String[] result;
/* 303 */             String id = "IDL:java/io/IOEx:1.0";
/* 304 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 305 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 306 */             out.write_string(id);
/* 307 */             out.write_value(ex, IOException.class);
/* 308 */             return out; }
/*     */           String[] result;
/* 310 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 311 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 312 */           out.write_value(cast_array(result), new String[0].getClass());
/* 313 */           return out;
/*     */         }
/*     */       case 'M': 
/* 316 */         if (method.equals("getMBeanCount")) {
/* 317 */           Subject arg0 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 320 */             result = this.target.getMBeanCount(arg0);
/*     */           } catch (IOException ex) { Integer result;
/* 322 */             String id = "IDL:java/io/IOEx:1.0";
/* 323 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 324 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 325 */             out.write_string(id);
/* 326 */             out.write_value(ex, IOException.class);
/* 327 */             return out; }
/*     */           Integer result;
/* 329 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 330 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 331 */           out.write_value(result, Integer.class);
/* 332 */           return out; }
/* 333 */         if (method.equals("getMBeanInfo")) {
/* 334 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 335 */           Subject arg1 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 338 */             result = this.target.getMBeanInfo(arg0, arg1);
/*     */           } catch (InstanceNotFoundException ex) { MBeanInfo result;
/* 340 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 341 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 342 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 343 */             out.write_string(id);
/* 344 */             out.write_value(ex, InstanceNotFoundException.class);
/* 345 */             return out;
/*     */           } catch (IntrospectionException ex) {
/* 347 */             String id = "IDL:javax/management/IntrospectionEx:1.0";
/* 348 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 349 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 350 */             out.write_string(id);
/* 351 */             out.write_value(ex, IntrospectionException.class);
/* 352 */             return out;
/*     */           } catch (ReflectionException ex) {
/* 354 */             String id = "IDL:javax/management/ReflectionEx:1.0";
/* 355 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 356 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 357 */             out.write_string(id);
/* 358 */             out.write_value(ex, ReflectionException.class);
/* 359 */             return out;
/*     */           } catch (IOException ex) {
/* 361 */             String id = "IDL:java/io/IOEx:1.0";
/* 362 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 363 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 364 */             out.write_string(id);
/* 365 */             out.write_value(ex, IOException.class);
/* 366 */             return out; }
/*     */           MBeanInfo result;
/* 368 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 369 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 370 */           out.write_value(result, MBeanInfo.class);
/* 371 */           return out;
/*     */         }
/*     */       case 'N': 
/* 374 */         if (method.equals("addNotificationListener")) {
/* 375 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 376 */           ObjectName arg1 = (ObjectName)in.read_value(ObjectName.class);
/* 377 */           MarshalledObject arg2 = (MarshalledObject)in.read_value(MarshalledObject.class);
/* 378 */           MarshalledObject arg3 = (MarshalledObject)in.read_value(MarshalledObject.class);
/* 379 */           Subject arg4 = (Subject)in.read_value(Subject.class);
/*     */           try {
/* 381 */             this.target.addNotificationListener(arg0, arg1, arg2, arg3, arg4);
/*     */           } catch (InstanceNotFoundException ex) {
/* 383 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 384 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 385 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 386 */             out.write_string(id);
/* 387 */             out.write_value(ex, InstanceNotFoundException.class);
/* 388 */             return out;
/*     */           } catch (IOException ex) {
/* 390 */             String id = "IDL:java/io/IOEx:1.0";
/* 391 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 392 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 393 */             out.write_string(id);
/* 394 */             out.write_value(ex, IOException.class);
/* 395 */             return out;
/*     */           }
/* 397 */           return reply.createReply();
/*     */         }
/* 399 */         if (method.equals("addNotificationListeners")) {
/* 400 */           ObjectName[] arg0 = (ObjectName[])in.read_value(new ObjectName[0].getClass());
/* 401 */           MarshalledObject[] arg1 = (MarshalledObject[])in.read_value(new MarshalledObject[0].getClass());
/* 402 */           Subject[] arg2 = (Subject[])in.read_value(new Subject[0].getClass());
/*     */           try
/*     */           {
/* 405 */             result = this.target.addNotificationListeners(arg0, arg1, arg2);
/*     */           } catch (InstanceNotFoundException ex) { Integer[] result;
/* 407 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 408 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 409 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 410 */             out.write_string(id);
/* 411 */             out.write_value(ex, InstanceNotFoundException.class);
/* 412 */             return out;
/*     */           } catch (IOException ex) {
/* 414 */             String id = "IDL:java/io/IOEx:1.0";
/* 415 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 416 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 417 */             out.write_string(id);
/* 418 */             out.write_value(ex, IOException.class);
/* 419 */             return out; }
/*     */           Integer[] result;
/* 421 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 422 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 423 */           out.write_value(cast_array(result), new Integer[0].getClass());
/* 424 */           return out;
/*     */         }
/*     */       case 'O': 
/* 427 */         if (method.equals("getObjectInstance")) {
/* 428 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 429 */           Subject arg1 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 432 */             result = this.target.getObjectInstance(arg0, arg1);
/*     */           } catch (InstanceNotFoundException ex) { ObjectInstance result;
/* 434 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 435 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 436 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 437 */             out.write_string(id);
/* 438 */             out.write_value(ex, InstanceNotFoundException.class);
/* 439 */             return out;
/*     */           } catch (IOException ex) {
/* 441 */             String id = "IDL:java/io/IOEx:1.0";
/* 442 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 443 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 444 */             out.write_string(id);
/* 445 */             out.write_value(ex, IOException.class);
/* 446 */             return out; }
/*     */           ObjectInstance result;
/* 448 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 449 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 450 */           out.write_value(result, ObjectInstance.class);
/* 451 */           return out;
/*     */         }
/*     */       case 'a': 
/* 454 */         if (method.equals("createMBean__CORBA_WStringValue__javax_management_ObjectName__javax_security_auth_Subject")) {
/* 455 */           String arg0 = (String)in.read_value(String.class);
/* 456 */           ObjectName arg1 = (ObjectName)in.read_value(ObjectName.class);
/* 457 */           Subject arg2 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 460 */             result = this.target.createMBean(arg0, arg1, arg2);
/*     */           } catch (ReflectionException ex) { ObjectInstance result;
/* 462 */             String id = "IDL:javax/management/ReflectionEx:1.0";
/* 463 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 464 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 465 */             out.write_string(id);
/* 466 */             out.write_value(ex, ReflectionException.class);
/* 467 */             return out;
/*     */           } catch (InstanceAlreadyExistsException ex) {
/* 469 */             String id = "IDL:javax/management/InstanceAlreadyExistsEx:1.0";
/* 470 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 471 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 472 */             out.write_string(id);
/* 473 */             out.write_value(ex, InstanceAlreadyExistsException.class);
/* 474 */             return out;
/*     */           } catch (MBeanException ex) {
/* 476 */             String id = "IDL:javax/management/MBeanEx:1.0";
/* 477 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 478 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 479 */             out.write_string(id);
/* 480 */             out.write_value(ex, MBeanException.class);
/* 481 */             return out;
/*     */           } catch (NotCompliantMBeanException ex) {
/* 483 */             String id = "IDL:javax/management/NotCompliantMBeanEx:1.0";
/* 484 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 485 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 486 */             out.write_string(id);
/* 487 */             out.write_value(ex, NotCompliantMBeanException.class);
/* 488 */             return out;
/*     */           } catch (IOException ex) {
/* 490 */             String id = "IDL:java/io/IOEx:1.0";
/* 491 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 492 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 493 */             out.write_string(id);
/* 494 */             out.write_value(ex, IOException.class);
/* 495 */             return out; }
/*     */           ObjectInstance result;
/* 497 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 498 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 499 */           out.write_value(result, ObjectInstance.class);
/* 500 */           return out; }
/* 501 */         if (method.equals("createMBean__CORBA_WStringValue__javax_management_ObjectName__javax_management_ObjectName__javax_security_auth_Subject")) {
/* 502 */           String arg0 = (String)in.read_value(String.class);
/* 503 */           ObjectName arg1 = (ObjectName)in.read_value(ObjectName.class);
/* 504 */           ObjectName arg2 = (ObjectName)in.read_value(ObjectName.class);
/* 505 */           Subject arg3 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 508 */             result = this.target.createMBean(arg0, arg1, arg2, arg3);
/*     */           } catch (ReflectionException ex) { ObjectInstance result;
/* 510 */             String id = "IDL:javax/management/ReflectionEx:1.0";
/* 511 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 512 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 513 */             out.write_string(id);
/* 514 */             out.write_value(ex, ReflectionException.class);
/* 515 */             return out;
/*     */           } catch (InstanceAlreadyExistsException ex) {
/* 517 */             String id = "IDL:javax/management/InstanceAlreadyExistsEx:1.0";
/* 518 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 519 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 520 */             out.write_string(id);
/* 521 */             out.write_value(ex, InstanceAlreadyExistsException.class);
/* 522 */             return out;
/*     */           } catch (MBeanException ex) {
/* 524 */             String id = "IDL:javax/management/MBeanEx:1.0";
/* 525 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 526 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 527 */             out.write_string(id);
/* 528 */             out.write_value(ex, MBeanException.class);
/* 529 */             return out;
/*     */           } catch (NotCompliantMBeanException ex) {
/* 531 */             String id = "IDL:javax/management/NotCompliantMBeanEx:1.0";
/* 532 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 533 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 534 */             out.write_string(id);
/* 535 */             out.write_value(ex, NotCompliantMBeanException.class);
/* 536 */             return out;
/*     */           } catch (InstanceNotFoundException ex) {
/* 538 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 539 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 540 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 541 */             out.write_string(id);
/* 542 */             out.write_value(ex, InstanceNotFoundException.class);
/* 543 */             return out;
/*     */           } catch (IOException ex) {
/* 545 */             String id = "IDL:java/io/IOEx:1.0";
/* 546 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 547 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 548 */             out.write_string(id);
/* 549 */             out.write_value(ex, IOException.class);
/* 550 */             return out; }
/*     */           ObjectInstance result;
/* 552 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 553 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 554 */           out.write_value(result, ObjectInstance.class);
/* 555 */           return out; }
/* 556 */         if (method.equals("createMBean__CORBA_WStringValue__javax_management_ObjectName__java_rmi_MarshalledObject__org_omg_boxedRMI_CORBA_seq1_WStringValue__javax_security_auth_Subject")) {
/* 557 */           String arg0 = (String)in.read_value(String.class);
/* 558 */           ObjectName arg1 = (ObjectName)in.read_value(ObjectName.class);
/* 559 */           MarshalledObject arg2 = (MarshalledObject)in.read_value(MarshalledObject.class);
/* 560 */           String[] arg3 = (String[])in.read_value(new String[0].getClass());
/* 561 */           Subject arg4 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 564 */             result = this.target.createMBean(arg0, arg1, arg2, arg3, arg4);
/*     */           } catch (ReflectionException ex) { ObjectInstance result;
/* 566 */             String id = "IDL:javax/management/ReflectionEx:1.0";
/* 567 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 568 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 569 */             out.write_string(id);
/* 570 */             out.write_value(ex, ReflectionException.class);
/* 571 */             return out;
/*     */           } catch (InstanceAlreadyExistsException ex) {
/* 573 */             String id = "IDL:javax/management/InstanceAlreadyExistsEx:1.0";
/* 574 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 575 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 576 */             out.write_string(id);
/* 577 */             out.write_value(ex, InstanceAlreadyExistsException.class);
/* 578 */             return out;
/*     */           } catch (MBeanException ex) {
/* 580 */             String id = "IDL:javax/management/MBeanEx:1.0";
/* 581 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 582 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 583 */             out.write_string(id);
/* 584 */             out.write_value(ex, MBeanException.class);
/* 585 */             return out;
/*     */           } catch (NotCompliantMBeanException ex) {
/* 587 */             String id = "IDL:javax/management/NotCompliantMBeanEx:1.0";
/* 588 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 589 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 590 */             out.write_string(id);
/* 591 */             out.write_value(ex, NotCompliantMBeanException.class);
/* 592 */             return out;
/*     */           } catch (IOException ex) {
/* 594 */             String id = "IDL:java/io/IOEx:1.0";
/* 595 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 596 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 597 */             out.write_string(id);
/* 598 */             out.write_value(ex, IOException.class);
/* 599 */             return out; }
/*     */           ObjectInstance result;
/* 601 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 602 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 603 */           out.write_value(result, ObjectInstance.class);
/* 604 */           return out; }
/* 605 */         if (method.equals("createMBean__CORBA_WStringValue__javax_management_ObjectName__javax_management_ObjectName__java_rmi_MarshalledObject__org_omg_boxedRMI_CORBA_seq1_WStringValue__javax_security_auth_Subject")) {
/* 606 */           String arg0 = (String)in.read_value(String.class);
/* 607 */           ObjectName arg1 = (ObjectName)in.read_value(ObjectName.class);
/* 608 */           ObjectName arg2 = (ObjectName)in.read_value(ObjectName.class);
/* 609 */           MarshalledObject arg3 = (MarshalledObject)in.read_value(MarshalledObject.class);
/* 610 */           String[] arg4 = (String[])in.read_value(new String[0].getClass());
/* 611 */           Subject arg5 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 614 */             result = this.target.createMBean(arg0, arg1, arg2, arg3, arg4, arg5);
/*     */           } catch (ReflectionException ex) { ObjectInstance result;
/* 616 */             String id = "IDL:javax/management/ReflectionEx:1.0";
/* 617 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 618 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 619 */             out.write_string(id);
/* 620 */             out.write_value(ex, ReflectionException.class);
/* 621 */             return out;
/*     */           } catch (InstanceAlreadyExistsException ex) {
/* 623 */             String id = "IDL:javax/management/InstanceAlreadyExistsEx:1.0";
/* 624 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 625 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 626 */             out.write_string(id);
/* 627 */             out.write_value(ex, InstanceAlreadyExistsException.class);
/* 628 */             return out;
/*     */           } catch (MBeanException ex) {
/* 630 */             String id = "IDL:javax/management/MBeanEx:1.0";
/* 631 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 632 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 633 */             out.write_string(id);
/* 634 */             out.write_value(ex, MBeanException.class);
/* 635 */             return out;
/*     */           } catch (NotCompliantMBeanException ex) {
/* 637 */             String id = "IDL:javax/management/NotCompliantMBeanEx:1.0";
/* 638 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 639 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 640 */             out.write_string(id);
/* 641 */             out.write_value(ex, NotCompliantMBeanException.class);
/* 642 */             return out;
/*     */           } catch (InstanceNotFoundException ex) {
/* 644 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 645 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 646 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 647 */             out.write_string(id);
/* 648 */             out.write_value(ex, InstanceNotFoundException.class);
/* 649 */             return out;
/*     */           } catch (IOException ex) {
/* 651 */             String id = "IDL:java/io/IOEx:1.0";
/* 652 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 653 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 654 */             out.write_string(id);
/* 655 */             out.write_value(ex, IOException.class);
/* 656 */             return out; }
/*     */           ObjectInstance result;
/* 658 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 659 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 660 */           out.write_value(result, ObjectInstance.class);
/* 661 */           return out;
/*     */         }
/*     */       case 'c': 
/* 664 */         if (method.equals("fetchNotifications")) {
/* 665 */           long arg0 = in.read_longlong();
/* 666 */           int arg1 = in.read_long();
/* 667 */           long arg2 = in.read_longlong();
/*     */           try
/*     */           {
/* 670 */             result = this.target.fetchNotifications(arg0, arg1, arg2);
/*     */           } catch (IOException ex) { NotificationResult result;
/* 672 */             String id = "IDL:java/io/IOEx:1.0";
/* 673 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 674 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 675 */             out.write_string(id);
/* 676 */             out.write_value(ex, IOException.class);
/* 677 */             return out; }
/*     */           NotificationResult result;
/* 679 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 680 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 681 */           out.write_value(result, NotificationResult.class);
/* 682 */           return out;
/*     */         }
/*     */       case 'e': 
/* 685 */         if (method.equals("unregisterMBean")) {
/* 686 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 687 */           Subject arg1 = (Subject)in.read_value(Subject.class);
/*     */           try {
/* 689 */             this.target.unregisterMBean(arg0, arg1);
/*     */           } catch (InstanceNotFoundException ex) {
/* 691 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 692 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 693 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 694 */             out.write_string(id);
/* 695 */             out.write_value(ex, InstanceNotFoundException.class);
/* 696 */             return out;
/*     */           } catch (MBeanRegistrationException ex) {
/* 698 */             String id = "IDL:javax/management/MBeanRegistrationEx:1.0";
/* 699 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 700 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 701 */             out.write_string(id);
/* 702 */             out.write_value(ex, MBeanRegistrationException.class);
/* 703 */             return out;
/*     */           } catch (IOException ex) {
/* 705 */             String id = "IDL:java/io/IOEx:1.0";
/* 706 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 707 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 708 */             out.write_string(id);
/* 709 */             out.write_value(ex, IOException.class);
/* 710 */             return out;
/*     */           }
/* 712 */           return reply.createReply();
/*     */         }
/* 714 */         if (method.equals("isRegistered")) {
/* 715 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 716 */           Subject arg1 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 719 */             result = this.target.isRegistered(arg0, arg1);
/*     */           } catch (IOException ex) { boolean result;
/* 721 */             String id = "IDL:java/io/IOEx:1.0";
/* 722 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 723 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 724 */             out.write_string(id);
/* 725 */             out.write_value(ex, IOException.class);
/* 726 */             return out; }
/*     */           boolean result;
/* 728 */           org.omg.CORBA.portable.OutputStream out = reply.createReply();
/* 729 */           out.write_boolean(result);
/* 730 */           return out;
/*     */         }
/*     */       case 'n': 
/* 733 */         if (method.equals("isInstanceOf")) {
/* 734 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 735 */           String arg1 = (String)in.read_value(String.class);
/* 736 */           Subject arg2 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 739 */             result = this.target.isInstanceOf(arg0, arg1, arg2);
/*     */           } catch (InstanceNotFoundException ex) { boolean result;
/* 741 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 742 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 743 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 744 */             out.write_string(id);
/* 745 */             out.write_value(ex, InstanceNotFoundException.class);
/* 746 */             return out;
/*     */           } catch (IOException ex) {
/* 748 */             String id = "IDL:java/io/IOEx:1.0";
/* 749 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 750 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 751 */             out.write_string(id);
/* 752 */             out.write_value(ex, IOException.class);
/* 753 */             return out; }
/*     */           boolean result;
/* 755 */           org.omg.CORBA.portable.OutputStream out = reply.createReply();
/* 756 */           out.write_boolean(result);
/* 757 */           return out;
/*     */         }
/*     */       case 'o': 
/* 760 */         if (method.equals("invoke")) {
/* 761 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 762 */           String arg1 = (String)in.read_value(String.class);
/* 763 */           MarshalledObject arg2 = (MarshalledObject)in.read_value(MarshalledObject.class);
/* 764 */           String[] arg3 = (String[])in.read_value(new String[0].getClass());
/* 765 */           Subject arg4 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 768 */             result = this.target.invoke(arg0, arg1, arg2, arg3, arg4);
/*     */           } catch (InstanceNotFoundException ex) { Object result;
/* 770 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 771 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 772 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 773 */             out.write_string(id);
/* 774 */             out.write_value(ex, InstanceNotFoundException.class);
/* 775 */             return out;
/*     */           } catch (MBeanException ex) {
/* 777 */             String id = "IDL:javax/management/MBeanEx:1.0";
/* 778 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 779 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 780 */             out.write_string(id);
/* 781 */             out.write_value(ex, MBeanException.class);
/* 782 */             return out;
/*     */           } catch (ReflectionException ex) {
/* 784 */             String id = "IDL:javax/management/ReflectionEx:1.0";
/* 785 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 786 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 787 */             out.write_string(id);
/* 788 */             out.write_value(ex, ReflectionException.class);
/* 789 */             return out;
/*     */           } catch (IOException ex) {
/* 791 */             String id = "IDL:java/io/IOEx:1.0";
/* 792 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 793 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 794 */             out.write_string(id);
/* 795 */             out.write_value(ex, IOException.class);
/* 796 */             return out; }
/*     */           Object result;
/* 798 */           org.omg.CORBA.portable.OutputStream out = reply.createReply();
/* 799 */           Util.writeAny(out, result);
/* 800 */           return out; }
/* 801 */         if (method.equals("removeNotificationListener__javax_management_ObjectName__javax_management_ObjectName__javax_security_auth_Subject")) {
/* 802 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 803 */           ObjectName arg1 = (ObjectName)in.read_value(ObjectName.class);
/* 804 */           Subject arg2 = (Subject)in.read_value(Subject.class);
/*     */           try {
/* 806 */             this.target.removeNotificationListener(arg0, arg1, arg2);
/*     */           } catch (InstanceNotFoundException ex) {
/* 808 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 809 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 810 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 811 */             out.write_string(id);
/* 812 */             out.write_value(ex, InstanceNotFoundException.class);
/* 813 */             return out;
/*     */           } catch (ListenerNotFoundException ex) {
/* 815 */             String id = "IDL:javax/management/ListenerNotFoundEx:1.0";
/* 816 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 817 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 818 */             out.write_string(id);
/* 819 */             out.write_value(ex, ListenerNotFoundException.class);
/* 820 */             return out;
/*     */           } catch (IOException ex) {
/* 822 */             String id = "IDL:java/io/IOEx:1.0";
/* 823 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 824 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 825 */             out.write_string(id);
/* 826 */             out.write_value(ex, IOException.class);
/* 827 */             return out;
/*     */           }
/* 829 */           return reply.createReply();
/*     */         }
/* 831 */         if (method.equals("removeNotificationListener__javax_management_ObjectName__javax_management_ObjectName__java_rmi_MarshalledObject__java_rmi_MarshalledObject__javax_security_auth_Subject")) {
/* 832 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 833 */           ObjectName arg1 = (ObjectName)in.read_value(ObjectName.class);
/* 834 */           MarshalledObject arg2 = (MarshalledObject)in.read_value(MarshalledObject.class);
/* 835 */           MarshalledObject arg3 = (MarshalledObject)in.read_value(MarshalledObject.class);
/* 836 */           Subject arg4 = (Subject)in.read_value(Subject.class);
/*     */           try {
/* 838 */             this.target.removeNotificationListener(arg0, arg1, arg2, arg3, arg4);
/*     */           } catch (InstanceNotFoundException ex) {
/* 840 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 841 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 842 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 843 */             out.write_string(id);
/* 844 */             out.write_value(ex, InstanceNotFoundException.class);
/* 845 */             return out;
/*     */           } catch (ListenerNotFoundException ex) {
/* 847 */             String id = "IDL:javax/management/ListenerNotFoundEx:1.0";
/* 848 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 849 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 850 */             out.write_string(id);
/* 851 */             out.write_value(ex, ListenerNotFoundException.class);
/* 852 */             return out;
/*     */           } catch (IOException ex) {
/* 854 */             String id = "IDL:java/io/IOEx:1.0";
/* 855 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 856 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 857 */             out.write_string(id);
/* 858 */             out.write_value(ex, IOException.class);
/* 859 */             return out;
/*     */           }
/* 861 */           return reply.createReply();
/*     */         }
/* 863 */         if (method.equals("removeNotificationListeners")) {
/* 864 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 865 */           Integer[] arg1 = (Integer[])in.read_value(new Integer[0].getClass());
/* 866 */           Subject arg2 = (Subject)in.read_value(Subject.class);
/*     */           try {
/* 868 */             this.target.removeNotificationListeners(arg0, arg1, arg2);
/*     */           } catch (InstanceNotFoundException ex) {
/* 870 */             String id = "IDL:javax/management/InstanceNotFoundEx:1.0";
/* 871 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 872 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 873 */             out.write_string(id);
/* 874 */             out.write_value(ex, InstanceNotFoundException.class);
/* 875 */             return out;
/*     */           } catch (ListenerNotFoundException ex) {
/* 877 */             String id = "IDL:javax/management/ListenerNotFoundEx:1.0";
/* 878 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 879 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 880 */             out.write_string(id);
/* 881 */             out.write_value(ex, ListenerNotFoundException.class);
/* 882 */             return out;
/*     */           } catch (IOException ex) {
/* 884 */             String id = "IDL:java/io/IOEx:1.0";
/* 885 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 886 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 887 */             out.write_string(id);
/* 888 */             out.write_value(ex, IOException.class);
/* 889 */             return out;
/*     */           }
/* 891 */           return reply.createReply();
/*     */         }
/*     */       
/*     */       case 'r': 
/* 895 */         if (method.equals("queryMBeans")) {
/* 896 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 897 */           MarshalledObject arg1 = (MarshalledObject)in.read_value(MarshalledObject.class);
/* 898 */           Subject arg2 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 901 */             result = this.target.queryMBeans(arg0, arg1, arg2);
/*     */           } catch (IOException ex) { Set result;
/* 903 */             String id = "IDL:java/io/IOEx:1.0";
/* 904 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 905 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 906 */             out.write_string(id);
/* 907 */             out.write_value(ex, IOException.class);
/* 908 */             return out; }
/*     */           Set result;
/* 910 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 911 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 912 */           out.write_value((Serializable)result, Set.class);
/* 913 */           return out; }
/* 914 */         if (method.equals("queryNames")) {
/* 915 */           ObjectName arg0 = (ObjectName)in.read_value(ObjectName.class);
/* 916 */           MarshalledObject arg1 = (MarshalledObject)in.read_value(MarshalledObject.class);
/* 917 */           Subject arg2 = (Subject)in.read_value(Subject.class);
/*     */           try
/*     */           {
/* 920 */             result = this.target.queryNames(arg0, arg1, arg2);
/*     */           } catch (IOException ex) { Set result;
/* 922 */             String id = "IDL:java/io/IOEx:1.0";
/* 923 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 924 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 925 */             out.write_string(id);
/* 926 */             out.write_value(ex, IOException.class);
/* 927 */             return out; }
/*     */           Set result;
/* 929 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 930 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 931 */           out.write_value((Serializable)result, Set.class);
/* 932 */           return out;
/*     */         }
/*     */       case 's': 
/* 935 */         if (method.equals("close")) {
/*     */           try {
/* 937 */             this.target.close();
/*     */           } catch (IOException ex) {
/* 939 */             String id = "IDL:java/io/IOEx:1.0";
/* 940 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/* 941 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/* 942 */             out.write_string(id);
/* 943 */             out.write_value(ex, IOException.class);
/* 944 */             return out;
/*     */           }
/* 946 */           return reply.createReply();
/*     */         }
/*     */         break;
/*     */       }
/* 950 */       throw new BAD_OPERATION();
/*     */     } catch (SystemException ex) {
/* 952 */       throw ex;
/*     */     } catch (Throwable ex) {
/* 954 */       throw new UnknownException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Serializable cast_array(Object obj)
/*     */   {
/* 962 */     return (Serializable)obj;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/org/omg/stub/javax/management/remote/rmi/_RMIConnectionImpl_Tie.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */