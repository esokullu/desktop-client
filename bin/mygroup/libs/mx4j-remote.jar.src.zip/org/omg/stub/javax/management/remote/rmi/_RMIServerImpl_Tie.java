/*     */ package org.omg.stub.javax.management.remote.rmi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.rmi.Remote;
/*     */ import javax.management.remote.rmi.RMIConnection;
/*     */ import javax.management.remote.rmi.RMIServerImpl;
/*     */ import javax.rmi.CORBA.Tie;
/*     */ import javax.rmi.CORBA.Util;
/*     */ import org.omg.CORBA.BAD_OPERATION;
/*     */ import org.omg.CORBA.BAD_PARAM;
/*     */ import org.omg.CORBA.SystemException;
/*     */ import org.omg.CORBA.portable.ResponseHandler;
/*     */ import org.omg.CORBA.portable.UnknownException;
/*     */ import org.omg.PortableServer.POA;
/*     */ import org.omg.PortableServer.POAOperations;
/*     */ import org.omg.PortableServer.POAPackage.ObjectNotActive;
/*     */ import org.omg.PortableServer.POAPackage.ServantNotActive;
/*     */ import org.omg.PortableServer.POAPackage.WrongPolicy;
/*     */ import org.omg.PortableServer.Servant;
/*     */ 
/*     */ 
/*     */ public class _RMIServerImpl_Tie
/*     */   extends Servant
/*     */   implements Tie
/*     */ {
/*  26 */   private RMIServerImpl target = null;
/*     */   
/*  28 */   private static final String[] _type_ids = {
/*  29 */     "RMI:javax.management.remote.rmi.RMIServer:0000000000000000" };
/*     */   
/*     */   public void setTarget(Remote target)
/*     */   {
/*  33 */     this.target = ((RMIServerImpl)target);
/*     */   }
/*     */   
/*     */   public Remote getTarget() {
/*  37 */     return this.target;
/*     */   }
/*     */   
/*     */   public org.omg.CORBA.Object thisObject() {
/*  41 */     return _this_object();
/*     */   }
/*     */   
/*     */   public void deactivate() {
/*     */     try {
/*  46 */       _poa().deactivate_object(_poa().servant_to_id(this));
/*     */     }
/*     */     catch (WrongPolicy localWrongPolicy) {}catch (ObjectNotActive localObjectNotActive) {}catch (ServantNotActive localServantNotActive) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public org.omg.CORBA.ORB orb()
/*     */   {
/*  57 */     return _orb();
/*     */   }
/*     */   
/*     */   public void orb(org.omg.CORBA.ORB orb) {
/*     */     try {
/*  62 */       ((org.omg.CORBA_2_3.ORB)orb).set_delegate(this);
/*     */     }
/*     */     catch (ClassCastException localClassCastException) {
/*  65 */       throw new BAD_PARAM(
/*  66 */         "POA Servant requires an instance of org.omg.CORBA_2_3.ORB");
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] _all_interfaces(POA poa, byte[] objectId) {
/*  71 */     return _type_ids;
/*     */   }
/*     */   
/*     */   public org.omg.CORBA.portable.OutputStream _invoke(String method, org.omg.CORBA.portable.InputStream _in, ResponseHandler reply) throws SystemException {
/*     */     try {
/*  76 */       org.omg.CORBA_2_3.portable.InputStream in = 
/*  77 */         (org.omg.CORBA_2_3.portable.InputStream)_in;
/*  78 */       switch (method.length()) {
/*     */       case 9: 
/*  80 */         if (method.equals("newClient")) {
/*  81 */           Object arg0 = Util.readAny(in);
/*     */           try
/*     */           {
/*  84 */             result = this.target.newClient(arg0);
/*     */           } catch (IOException ex) { RMIConnection result;
/*  86 */             String id = "IDL:java/io/IOEx:1.0";
/*  87 */             org.omg.CORBA_2_3.portable.OutputStream out = 
/*  88 */               (org.omg.CORBA_2_3.portable.OutputStream)reply.createExceptionReply();
/*  89 */             out.write_string(id);
/*  90 */             out.write_value(ex, IOException.class);
/*  91 */             return out; }
/*     */           RMIConnection result;
/*  93 */           org.omg.CORBA.portable.OutputStream out = reply.createReply();
/*  94 */           Util.writeRemoteObject(out, result);
/*  95 */           return out;
/*     */         }
/*     */       case 12: 
/*  98 */         if (method.equals("_get_version")) {
/*  99 */           String result = this.target.getVersion();
/* 100 */           org.omg.CORBA_2_3.portable.OutputStream out = 
/* 101 */             (org.omg.CORBA_2_3.portable.OutputStream)reply.createReply();
/* 102 */           out.write_value(result, String.class);
/* 103 */           return out;
/*     */         }
/*     */         break; }
/* 106 */       throw new BAD_OPERATION();
/*     */     } catch (SystemException ex) {
/* 108 */       throw ex;
/*     */     } catch (Throwable ex) {
/* 110 */       throw new UnknownException(ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/org/omg/stub/javax/management/remote/rmi/_RMIServerImpl_Tie.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */