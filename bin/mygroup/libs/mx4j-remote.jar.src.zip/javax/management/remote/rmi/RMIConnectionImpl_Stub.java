/*     */ package javax.management.remote.rmi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.security.auth.Subject;
/*     */ 
/*     */ public final class RMIConnectionImpl_Stub extends java.rmi.server.RemoteStub implements RMIConnection
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   private static java.lang.reflect.Method $method_addNotificationListener_0;
/*     */   private static java.lang.reflect.Method $method_addNotificationListeners_1;
/*     */   private static java.lang.reflect.Method $method_close_2;
/*     */   private static java.lang.reflect.Method $method_createMBean_3;
/*     */   private static java.lang.reflect.Method $method_createMBean_4;
/*     */   private static java.lang.reflect.Method $method_createMBean_5;
/*     */   private static java.lang.reflect.Method $method_createMBean_6;
/*     */   private static java.lang.reflect.Method $method_fetchNotifications_7;
/*     */   private static java.lang.reflect.Method $method_getAttribute_8;
/*     */   private static java.lang.reflect.Method $method_getAttributes_9;
/*     */   private static java.lang.reflect.Method $method_getConnectionId_10;
/*     */   private static java.lang.reflect.Method $method_getDefaultDomain_11;
/*     */   private static java.lang.reflect.Method $method_getDomains_12;
/*     */   private static java.lang.reflect.Method $method_getMBeanCount_13;
/*     */   private static java.lang.reflect.Method $method_getMBeanInfo_14;
/*     */   private static java.lang.reflect.Method $method_getObjectInstance_15;
/*     */   private static java.lang.reflect.Method $method_invoke_16;
/*     */   private static java.lang.reflect.Method $method_isInstanceOf_17;
/*     */   private static java.lang.reflect.Method $method_isRegistered_18;
/*     */   private static java.lang.reflect.Method $method_queryMBeans_19;
/*     */   private static java.lang.reflect.Method $method_queryNames_20;
/*     */   private static java.lang.reflect.Method $method_removeNotificationListener_21;
/*     */   private static java.lang.reflect.Method $method_removeNotificationListener_22;
/*     */   private static java.lang.reflect.Method $method_removeNotificationListeners_23;
/*     */   private static java.lang.reflect.Method $method_setAttribute_24;
/*     */   private static java.lang.reflect.Method $method_setAttributes_25;
/*     */   private static java.lang.reflect.Method $method_unregisterMBean_26;
/*     */   
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  42 */       $method_addNotificationListener_0 = RMIConnection.class.getMethod("addNotificationListener", new Class[] { ObjectName.class, ObjectName.class, java.rmi.MarshalledObject.class, java.rmi.MarshalledObject.class, Subject.class });
/*  43 */       $method_addNotificationListeners_1 = RMIConnection.class.getMethod("addNotificationListeners", new Class[] { new ObjectName[0].getClass(), new java.rmi.MarshalledObject[0].getClass(), new Subject[0].getClass() });
/*  44 */       $method_close_2 = RMIConnection.class.getMethod("close", new Class[0]);
/*  45 */       $method_createMBean_3 = RMIConnection.class.getMethod("createMBean", new Class[] { String.class, ObjectName.class, java.rmi.MarshalledObject.class, new String[0].getClass(), Subject.class });
/*  46 */       $method_createMBean_4 = RMIConnection.class.getMethod("createMBean", new Class[] { String.class, ObjectName.class, ObjectName.class, java.rmi.MarshalledObject.class, new String[0].getClass(), Subject.class });
/*  47 */       $method_createMBean_5 = RMIConnection.class.getMethod("createMBean", new Class[] { String.class, ObjectName.class, ObjectName.class, Subject.class });
/*  48 */       $method_createMBean_6 = RMIConnection.class.getMethod("createMBean", new Class[] { String.class, ObjectName.class, Subject.class });
/*  49 */       $method_fetchNotifications_7 = RMIConnection.class.getMethod("fetchNotifications", new Class[] { Long.TYPE, Integer.TYPE, Long.TYPE });
/*  50 */       $method_getAttribute_8 = RMIConnection.class.getMethod("getAttribute", new Class[] { ObjectName.class, String.class, Subject.class });
/*  51 */       $method_getAttributes_9 = RMIConnection.class.getMethod("getAttributes", new Class[] { ObjectName.class, new String[0].getClass(), Subject.class });
/*  52 */       $method_getConnectionId_10 = RMIConnection.class.getMethod("getConnectionId", new Class[0]);
/*  53 */       $method_getDefaultDomain_11 = RMIConnection.class.getMethod("getDefaultDomain", new Class[] { Subject.class });
/*  54 */       $method_getDomains_12 = RMIConnection.class.getMethod("getDomains", new Class[] { Subject.class });
/*  55 */       $method_getMBeanCount_13 = RMIConnection.class.getMethod("getMBeanCount", new Class[] { Subject.class });
/*  56 */       $method_getMBeanInfo_14 = RMIConnection.class.getMethod("getMBeanInfo", new Class[] { ObjectName.class, Subject.class });
/*  57 */       $method_getObjectInstance_15 = RMIConnection.class.getMethod("getObjectInstance", new Class[] { ObjectName.class, Subject.class });
/*  58 */       $method_invoke_16 = RMIConnection.class.getMethod("invoke", new Class[] { ObjectName.class, String.class, java.rmi.MarshalledObject.class, new String[0].getClass(), Subject.class });
/*  59 */       $method_isInstanceOf_17 = RMIConnection.class.getMethod("isInstanceOf", new Class[] { ObjectName.class, String.class, Subject.class });
/*  60 */       $method_isRegistered_18 = RMIConnection.class.getMethod("isRegistered", new Class[] { ObjectName.class, Subject.class });
/*  61 */       $method_queryMBeans_19 = RMIConnection.class.getMethod("queryMBeans", new Class[] { ObjectName.class, java.rmi.MarshalledObject.class, Subject.class });
/*  62 */       $method_queryNames_20 = RMIConnection.class.getMethod("queryNames", new Class[] { ObjectName.class, java.rmi.MarshalledObject.class, Subject.class });
/*  63 */       $method_removeNotificationListener_21 = RMIConnection.class.getMethod("removeNotificationListener", new Class[] { ObjectName.class, ObjectName.class, java.rmi.MarshalledObject.class, java.rmi.MarshalledObject.class, Subject.class });
/*  64 */       $method_removeNotificationListener_22 = RMIConnection.class.getMethod("removeNotificationListener", new Class[] { ObjectName.class, ObjectName.class, Subject.class });
/*  65 */       $method_removeNotificationListeners_23 = RMIConnection.class.getMethod("removeNotificationListeners", new Class[] { ObjectName.class, new Integer[0].getClass(), Subject.class });
/*  66 */       $method_setAttribute_24 = RMIConnection.class.getMethod("setAttribute", new Class[] { ObjectName.class, java.rmi.MarshalledObject.class, Subject.class });
/*  67 */       $method_setAttributes_25 = RMIConnection.class.getMethod("setAttributes", new Class[] { ObjectName.class, java.rmi.MarshalledObject.class, Subject.class });
/*  68 */       $method_unregisterMBean_26 = RMIConnection.class.getMethod("unregisterMBean", new Class[] { ObjectName.class, Subject.class });
/*     */     } catch (NoSuchMethodException localNoSuchMethodException) {
/*  70 */       throw new NoSuchMethodError(
/*  71 */         "stub class initialization failed");
/*     */     }
/*     */   }
/*     */   
/*     */   public RMIConnectionImpl_Stub(java.rmi.server.RemoteRef ref)
/*     */   {
/*  77 */     super(ref);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addNotificationListener(ObjectName $param_ObjectName_1, ObjectName $param_ObjectName_2, java.rmi.MarshalledObject $param_MarshalledObject_3, java.rmi.MarshalledObject $param_MarshalledObject_4, Subject $param_Subject_5)
/*     */     throws IOException, javax.management.InstanceNotFoundException
/*     */   {
/*     */     try
/*     */     {
/*  87 */       this.ref.invoke(this, $method_addNotificationListener_0, new Object[] { $param_ObjectName_1, $param_ObjectName_2, $param_MarshalledObject_3, $param_MarshalledObject_4, $param_Subject_5 }, -8578317696269497109L);
/*     */     } catch (RuntimeException e) {
/*  89 */       throw e;
/*     */     } catch (IOException e) {
/*  91 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/*  93 */       throw e;
/*     */     } catch (Exception e) {
/*  95 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Integer[] addNotificationListeners(ObjectName[] $param_arrayOf_ObjectName_1, java.rmi.MarshalledObject[] $param_arrayOf_MarshalledObject_2, Subject[] $param_arrayOf_Subject_3)
/*     */     throws IOException, javax.management.InstanceNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 104 */       Object $result = this.ref.invoke(this, $method_addNotificationListeners_1, new Object[] { $param_arrayOf_ObjectName_1, $param_arrayOf_MarshalledObject_2, $param_arrayOf_Subject_3 }, -5321691879380783377L);
/* 105 */       return (Integer[])$result;
/*     */     } catch (RuntimeException e) {
/* 107 */       throw e;
/*     */     } catch (IOException e) {
/* 109 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 111 */       throw e;
/*     */     } catch (Exception e) {
/* 113 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 122 */       this.ref.invoke(this, $method_close_2, null, -4742752445160157748L);
/*     */     } catch (RuntimeException e) {
/* 124 */       throw e;
/*     */     } catch (IOException e) {
/* 126 */       throw e;
/*     */     } catch (Exception e) {
/* 128 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public javax.management.ObjectInstance createMBean(String $param_String_1, ObjectName $param_ObjectName_2, java.rmi.MarshalledObject $param_MarshalledObject_3, String[] $param_arrayOf_String_4, Subject $param_Subject_5)
/*     */     throws IOException, javax.management.InstanceAlreadyExistsException, javax.management.MBeanException, javax.management.MBeanRegistrationException, javax.management.NotCompliantMBeanException, javax.management.ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 137 */       Object $result = this.ref.invoke(this, $method_createMBean_3, new Object[] { $param_String_1, $param_ObjectName_2, $param_MarshalledObject_3, $param_arrayOf_String_4, $param_Subject_5 }, 4867822117947806114L);
/* 138 */       return (javax.management.ObjectInstance)$result;
/*     */     } catch (RuntimeException e) {
/* 140 */       throw e;
/*     */     } catch (IOException e) {
/* 142 */       throw e;
/*     */     } catch (javax.management.InstanceAlreadyExistsException e) {
/* 144 */       throw e;
/*     */     } catch (javax.management.MBeanException e) {
/* 146 */       throw e;
/*     */     } catch (javax.management.NotCompliantMBeanException e) {
/* 148 */       throw e;
/*     */     } catch (javax.management.ReflectionException e) {
/* 150 */       throw e;
/*     */     } catch (Exception e) {
/* 152 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public javax.management.ObjectInstance createMBean(String $param_String_1, ObjectName $param_ObjectName_2, ObjectName $param_ObjectName_3, java.rmi.MarshalledObject $param_MarshalledObject_4, String[] $param_arrayOf_String_5, Subject $param_Subject_6)
/*     */     throws IOException, javax.management.InstanceAlreadyExistsException, javax.management.InstanceNotFoundException, javax.management.MBeanException, javax.management.MBeanRegistrationException, javax.management.NotCompliantMBeanException, javax.management.ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 161 */       Object $result = this.ref.invoke(this, $method_createMBean_4, new Object[] { $param_String_1, $param_ObjectName_2, $param_ObjectName_3, $param_MarshalledObject_4, $param_arrayOf_String_5, $param_Subject_6 }, -6604955182088909937L);
/* 162 */       return (javax.management.ObjectInstance)$result;
/*     */     } catch (RuntimeException e) {
/* 164 */       throw e;
/*     */     } catch (IOException e) {
/* 166 */       throw e;
/*     */     } catch (javax.management.InstanceAlreadyExistsException e) {
/* 168 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 170 */       throw e;
/*     */     } catch (javax.management.MBeanException e) {
/* 172 */       throw e;
/*     */     } catch (javax.management.NotCompliantMBeanException e) {
/* 174 */       throw e;
/*     */     } catch (javax.management.ReflectionException e) {
/* 176 */       throw e;
/*     */     } catch (Exception e) {
/* 178 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public javax.management.ObjectInstance createMBean(String $param_String_1, ObjectName $param_ObjectName_2, ObjectName $param_ObjectName_3, Subject $param_Subject_4)
/*     */     throws IOException, javax.management.InstanceAlreadyExistsException, javax.management.InstanceNotFoundException, javax.management.MBeanException, javax.management.MBeanRegistrationException, javax.management.NotCompliantMBeanException, javax.management.ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 187 */       Object $result = this.ref.invoke(this, $method_createMBean_5, new Object[] { $param_String_1, $param_ObjectName_2, $param_ObjectName_3, $param_Subject_4 }, -8679469989872508324L);
/* 188 */       return (javax.management.ObjectInstance)$result;
/*     */     } catch (RuntimeException e) {
/* 190 */       throw e;
/*     */     } catch (IOException e) {
/* 192 */       throw e;
/*     */     } catch (javax.management.InstanceAlreadyExistsException e) {
/* 194 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 196 */       throw e;
/*     */     } catch (javax.management.MBeanException e) {
/* 198 */       throw e;
/*     */     } catch (javax.management.NotCompliantMBeanException e) {
/* 200 */       throw e;
/*     */     } catch (javax.management.ReflectionException e) {
/* 202 */       throw e;
/*     */     } catch (Exception e) {
/* 204 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public javax.management.ObjectInstance createMBean(String $param_String_1, ObjectName $param_ObjectName_2, Subject $param_Subject_3)
/*     */     throws IOException, javax.management.InstanceAlreadyExistsException, javax.management.MBeanException, javax.management.MBeanRegistrationException, javax.management.NotCompliantMBeanException, javax.management.ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 213 */       Object $result = this.ref.invoke(this, $method_createMBean_6, new Object[] { $param_String_1, $param_ObjectName_2, $param_Subject_3 }, 2510753813974665446L);
/* 214 */       return (javax.management.ObjectInstance)$result;
/*     */     } catch (RuntimeException e) {
/* 216 */       throw e;
/*     */     } catch (IOException e) {
/* 218 */       throw e;
/*     */     } catch (javax.management.InstanceAlreadyExistsException e) {
/* 220 */       throw e;
/*     */     } catch (javax.management.MBeanException e) {
/* 222 */       throw e;
/*     */     } catch (javax.management.NotCompliantMBeanException e) {
/* 224 */       throw e;
/*     */     } catch (javax.management.ReflectionException e) {
/* 226 */       throw e;
/*     */     } catch (Exception e) {
/* 228 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public javax.management.remote.NotificationResult fetchNotifications(long $param_long_1, int $param_int_2, long $param_long_3)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 237 */       Object $result = this.ref.invoke(this, $method_fetchNotifications_7, new Object[] { new Long($param_long_1), new Integer($param_int_2), new Long($param_long_3) }, -5037523307973544478L);
/* 238 */       return (javax.management.remote.NotificationResult)$result;
/*     */     } catch (RuntimeException e) {
/* 240 */       throw e;
/*     */     } catch (IOException e) {
/* 242 */       throw e;
/*     */     } catch (Exception e) {
/* 244 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getAttribute(ObjectName $param_ObjectName_1, String $param_String_2, Subject $param_Subject_3)
/*     */     throws IOException, javax.management.AttributeNotFoundException, javax.management.InstanceNotFoundException, javax.management.MBeanException, javax.management.ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 253 */       return this.ref.invoke(this, $method_getAttribute_8, new Object[] { $param_ObjectName_1, $param_String_2, $param_Subject_3 }, -1089783104982388203L);
/*     */     }
/*     */     catch (RuntimeException e) {
/* 256 */       throw e;
/*     */     } catch (IOException e) {
/* 258 */       throw e;
/*     */     } catch (javax.management.AttributeNotFoundException e) {
/* 260 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 262 */       throw e;
/*     */     } catch (javax.management.MBeanException e) {
/* 264 */       throw e;
/*     */     } catch (javax.management.ReflectionException e) {
/* 266 */       throw e;
/*     */     } catch (Exception e) {
/* 268 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public javax.management.AttributeList getAttributes(ObjectName $param_ObjectName_1, String[] $param_arrayOf_String_2, Subject $param_Subject_3)
/*     */     throws IOException, javax.management.InstanceNotFoundException, javax.management.ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 277 */       Object $result = this.ref.invoke(this, $method_getAttributes_9, new Object[] { $param_ObjectName_1, $param_arrayOf_String_2, $param_Subject_3 }, 6285293806596348999L);
/* 278 */       return (javax.management.AttributeList)$result;
/*     */     } catch (RuntimeException e) {
/* 280 */       throw e;
/*     */     } catch (IOException e) {
/* 282 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 284 */       throw e;
/*     */     } catch (javax.management.ReflectionException e) {
/* 286 */       throw e;
/*     */     } catch (Exception e) {
/* 288 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getConnectionId()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 297 */       Object $result = this.ref.invoke(this, $method_getConnectionId_10, null, -67907180346059933L);
/* 298 */       return (String)$result;
/*     */     } catch (RuntimeException e) {
/* 300 */       throw e;
/*     */     } catch (IOException e) {
/* 302 */       throw e;
/*     */     } catch (Exception e) {
/* 304 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getDefaultDomain(Subject $param_Subject_1)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 313 */       Object $result = this.ref.invoke(this, $method_getDefaultDomain_11, new Object[] { $param_Subject_1 }, 6047668923998658472L);
/* 314 */       return (String)$result;
/*     */     } catch (RuntimeException e) {
/* 316 */       throw e;
/*     */     } catch (IOException e) {
/* 318 */       throw e;
/*     */     } catch (Exception e) {
/* 320 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] getDomains(Subject $param_Subject_1)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 329 */       Object $result = this.ref.invoke(this, $method_getDomains_12, new Object[] { $param_Subject_1 }, -6662314179953625551L);
/* 330 */       return (String[])$result;
/*     */     } catch (RuntimeException e) {
/* 332 */       throw e;
/*     */     } catch (IOException e) {
/* 334 */       throw e;
/*     */     } catch (Exception e) {
/* 336 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Integer getMBeanCount(Subject $param_Subject_1)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 345 */       Object $result = this.ref.invoke(this, $method_getMBeanCount_13, new Object[] { $param_Subject_1 }, -2042362057335820635L);
/* 346 */       return (Integer)$result;
/*     */     } catch (RuntimeException e) {
/* 348 */       throw e;
/*     */     } catch (IOException e) {
/* 350 */       throw e;
/*     */     } catch (Exception e) {
/* 352 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public javax.management.MBeanInfo getMBeanInfo(ObjectName $param_ObjectName_1, Subject $param_Subject_2)
/*     */     throws IOException, javax.management.InstanceNotFoundException, javax.management.IntrospectionException, javax.management.ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 361 */       Object $result = this.ref.invoke(this, $method_getMBeanInfo_14, new Object[] { $param_ObjectName_1, $param_Subject_2 }, -7404813916326233354L);
/* 362 */       return (javax.management.MBeanInfo)$result;
/*     */     } catch (RuntimeException e) {
/* 364 */       throw e;
/*     */     } catch (IOException e) {
/* 366 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 368 */       throw e;
/*     */     } catch (javax.management.IntrospectionException e) {
/* 370 */       throw e;
/*     */     } catch (javax.management.ReflectionException e) {
/* 372 */       throw e;
/*     */     } catch (Exception e) {
/* 374 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public javax.management.ObjectInstance getObjectInstance(ObjectName $param_ObjectName_1, Subject $param_Subject_2)
/*     */     throws IOException, javax.management.InstanceNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 383 */       Object $result = this.ref.invoke(this, $method_getObjectInstance_15, new Object[] { $param_ObjectName_1, $param_Subject_2 }, 6950095694996159938L);
/* 384 */       return (javax.management.ObjectInstance)$result;
/*     */     } catch (RuntimeException e) {
/* 386 */       throw e;
/*     */     } catch (IOException e) {
/* 388 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 390 */       throw e;
/*     */     } catch (Exception e) {
/* 392 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object invoke(ObjectName $param_ObjectName_1, String $param_String_2, java.rmi.MarshalledObject $param_MarshalledObject_3, String[] $param_arrayOf_String_4, Subject $param_Subject_5)
/*     */     throws IOException, javax.management.InstanceNotFoundException, javax.management.MBeanException, javax.management.ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 401 */       return this.ref.invoke(this, $method_invoke_16, new Object[] { $param_ObjectName_1, $param_String_2, $param_MarshalledObject_3, $param_arrayOf_String_4, $param_Subject_5 }, 1434350937885235744L);
/*     */     }
/*     */     catch (RuntimeException e) {
/* 404 */       throw e;
/*     */     } catch (IOException e) {
/* 406 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 408 */       throw e;
/*     */     } catch (javax.management.MBeanException e) {
/* 410 */       throw e;
/*     */     } catch (javax.management.ReflectionException e) {
/* 412 */       throw e;
/*     */     } catch (Exception e) {
/* 414 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isInstanceOf(ObjectName $param_ObjectName_1, String $param_String_2, Subject $param_Subject_3)
/*     */     throws IOException, javax.management.InstanceNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 423 */       Object $result = this.ref.invoke(this, $method_isInstanceOf_17, new Object[] { $param_ObjectName_1, $param_String_2, $param_Subject_3 }, -2147516868461740814L);
/* 424 */       return ((Boolean)$result).booleanValue();
/*     */     } catch (RuntimeException e) {
/* 426 */       throw e;
/*     */     } catch (IOException e) {
/* 428 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 430 */       throw e;
/*     */     } catch (Exception e) {
/* 432 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isRegistered(ObjectName $param_ObjectName_1, Subject $param_Subject_2)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 441 */       Object $result = this.ref.invoke(this, $method_isRegistered_18, new Object[] { $param_ObjectName_1, $param_Subject_2 }, 8325683335228268564L);
/* 442 */       return ((Boolean)$result).booleanValue();
/*     */     } catch (RuntimeException e) {
/* 444 */       throw e;
/*     */     } catch (IOException e) {
/* 446 */       throw e;
/*     */     } catch (Exception e) {
/* 448 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public java.util.Set queryMBeans(ObjectName $param_ObjectName_1, java.rmi.MarshalledObject $param_MarshalledObject_2, Subject $param_Subject_3)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 457 */       Object $result = this.ref.invoke(this, $method_queryMBeans_19, new Object[] { $param_ObjectName_1, $param_MarshalledObject_2, $param_Subject_3 }, 2915881009400597976L);
/* 458 */       return (java.util.Set)$result;
/*     */     } catch (RuntimeException e) {
/* 460 */       throw e;
/*     */     } catch (IOException e) {
/* 462 */       throw e;
/*     */     } catch (Exception e) {
/* 464 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public java.util.Set queryNames(ObjectName $param_ObjectName_1, java.rmi.MarshalledObject $param_MarshalledObject_2, Subject $param_Subject_3)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 473 */       Object $result = this.ref.invoke(this, $method_queryNames_20, new Object[] { $param_ObjectName_1, $param_MarshalledObject_2, $param_Subject_3 }, 9152567528369059802L);
/* 474 */       return (java.util.Set)$result;
/*     */     } catch (RuntimeException e) {
/* 476 */       throw e;
/*     */     } catch (IOException e) {
/* 478 */       throw e;
/*     */     } catch (Exception e) {
/* 480 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName $param_ObjectName_1, ObjectName $param_ObjectName_2, java.rmi.MarshalledObject $param_MarshalledObject_3, java.rmi.MarshalledObject $param_MarshalledObject_4, Subject $param_Subject_5)
/*     */     throws IOException, javax.management.InstanceNotFoundException, javax.management.ListenerNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 489 */       this.ref.invoke(this, $method_removeNotificationListener_21, new Object[] { $param_ObjectName_1, $param_ObjectName_2, $param_MarshalledObject_3, $param_MarshalledObject_4, $param_Subject_5 }, 2578029900065214857L);
/*     */     } catch (RuntimeException e) {
/* 491 */       throw e;
/*     */     } catch (IOException e) {
/* 493 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 495 */       throw e;
/*     */     } catch (javax.management.ListenerNotFoundException e) {
/* 497 */       throw e;
/*     */     } catch (Exception e) {
/* 499 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName $param_ObjectName_1, ObjectName $param_ObjectName_2, Subject $param_Subject_3)
/*     */     throws IOException, javax.management.InstanceNotFoundException, javax.management.ListenerNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 508 */       this.ref.invoke(this, $method_removeNotificationListener_22, new Object[] { $param_ObjectName_1, $param_ObjectName_2, $param_Subject_3 }, 6604721169198089513L);
/*     */     } catch (RuntimeException e) {
/* 510 */       throw e;
/*     */     } catch (IOException e) {
/* 512 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 514 */       throw e;
/*     */     } catch (javax.management.ListenerNotFoundException e) {
/* 516 */       throw e;
/*     */     } catch (Exception e) {
/* 518 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeNotificationListeners(ObjectName $param_ObjectName_1, Integer[] $param_arrayOf_Integer_2, Subject $param_Subject_3)
/*     */     throws IOException, javax.management.InstanceNotFoundException, javax.management.ListenerNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 527 */       this.ref.invoke(this, $method_removeNotificationListeners_23, new Object[] { $param_ObjectName_1, $param_arrayOf_Integer_2, $param_Subject_3 }, 2549120024456183446L);
/*     */     } catch (RuntimeException e) {
/* 529 */       throw e;
/*     */     } catch (IOException e) {
/* 531 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 533 */       throw e;
/*     */     } catch (javax.management.ListenerNotFoundException e) {
/* 535 */       throw e;
/*     */     } catch (Exception e) {
/* 537 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setAttribute(ObjectName $param_ObjectName_1, java.rmi.MarshalledObject $param_MarshalledObject_2, Subject $param_Subject_3)
/*     */     throws IOException, javax.management.AttributeNotFoundException, javax.management.InstanceNotFoundException, javax.management.InvalidAttributeValueException, javax.management.MBeanException, javax.management.ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 546 */       this.ref.invoke(this, $method_setAttribute_24, new Object[] { $param_ObjectName_1, $param_MarshalledObject_2, $param_Subject_3 }, 6738606893952597516L);
/*     */     } catch (RuntimeException e) {
/* 548 */       throw e;
/*     */     } catch (IOException e) {
/* 550 */       throw e;
/*     */     } catch (javax.management.AttributeNotFoundException e) {
/* 552 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 554 */       throw e;
/*     */     } catch (javax.management.InvalidAttributeValueException e) {
/* 556 */       throw e;
/*     */     } catch (javax.management.MBeanException e) {
/* 558 */       throw e;
/*     */     } catch (javax.management.ReflectionException e) {
/* 560 */       throw e;
/*     */     } catch (Exception e) {
/* 562 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public javax.management.AttributeList setAttributes(ObjectName $param_ObjectName_1, java.rmi.MarshalledObject $param_MarshalledObject_2, Subject $param_Subject_3)
/*     */     throws IOException, javax.management.InstanceNotFoundException, javax.management.ReflectionException
/*     */   {
/*     */     try
/*     */     {
/* 571 */       Object $result = this.ref.invoke(this, $method_setAttributes_25, new Object[] { $param_ObjectName_1, $param_MarshalledObject_2, $param_Subject_3 }, -230470228399681820L);
/* 572 */       return (javax.management.AttributeList)$result;
/*     */     } catch (RuntimeException e) {
/* 574 */       throw e;
/*     */     } catch (IOException e) {
/* 576 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 578 */       throw e;
/*     */     } catch (javax.management.ReflectionException e) {
/* 580 */       throw e;
/*     */     } catch (Exception e) {
/* 582 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void unregisterMBean(ObjectName $param_ObjectName_1, Subject $param_Subject_2)
/*     */     throws IOException, javax.management.InstanceNotFoundException, javax.management.MBeanRegistrationException
/*     */   {
/*     */     try
/*     */     {
/* 591 */       this.ref.invoke(this, $method_unregisterMBean_26, new Object[] { $param_ObjectName_1, $param_Subject_2 }, -159498580868721452L);
/*     */     } catch (RuntimeException e) {
/* 593 */       throw e;
/*     */     } catch (IOException e) {
/* 595 */       throw e;
/*     */     } catch (javax.management.InstanceNotFoundException e) {
/* 597 */       throw e;
/*     */     } catch (javax.management.MBeanRegistrationException e) {
/* 599 */       throw e;
/*     */     } catch (Exception e) {
/* 601 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/rmi/RMIConnectionImpl_Stub.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */