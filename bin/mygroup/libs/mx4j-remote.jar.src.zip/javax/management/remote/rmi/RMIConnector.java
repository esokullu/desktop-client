/*     */ package javax.management.remote.rmi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.remote.JMXConnector;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import javax.security.auth.Subject;
/*     */ import mx4j.remote.ConnectionNotificationEmitter;
/*     */ import mx4j.remote.ConnectionResolver;
/*     */ import mx4j.remote.HeartBeat;
/*     */ import mx4j.remote.RemoteNotificationClientHandler;
/*     */ import mx4j.remote.rmi.ClientExceptionCatcher;
/*     */ import mx4j.remote.rmi.ClientInvoker;
/*     */ import mx4j.remote.rmi.ClientUnmarshaller;
/*     */ import mx4j.remote.rmi.RMIHeartBeat;
/*     */ import mx4j.remote.rmi.RMIRemoteNotificationClientHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RMIConnector
/*     */   implements JMXConnector, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 817323035842634473L;
/*     */   private final JMXServiceURL jmxServiceURL;
/*     */   private RMIServer rmiServer;
/*     */   private transient RMIConnection connection;
/*     */   private transient boolean connected;
/*     */   private transient boolean closed;
/*     */   private transient ClassLoader defaultClassLoader;
/*     */   private transient String connectionId;
/*     */   private transient ConnectionNotificationEmitter emitter;
/*     */   private transient HeartBeat heartbeat;
/*     */   private transient RemoteNotificationClientHandler notificationHandler;
/*     */   
/*     */   public RMIConnector(JMXServiceURL url, Map environment)
/*     */   {
/*  64 */     if (url == null) throw new IllegalArgumentException("JMXServiceURL cannot be null");
/*  65 */     this.jmxServiceURL = url;
/*  66 */     this.rmiServer = null;
/*  67 */     initialize(environment);
/*     */   }
/*     */   
/*     */   public RMIConnector(RMIServer server, Map environment)
/*     */   {
/*  72 */     if (server == null) throw new IllegalArgumentException("RMIServer cannot be null");
/*  73 */     this.jmxServiceURL = null;
/*  74 */     this.rmiServer = server;
/*  75 */     initialize(environment);
/*     */   }
/*     */   
/*     */   private void initialize(Map environment)
/*     */   {
/*  80 */     this.defaultClassLoader = findDefaultClassLoader(environment);
/*  81 */     this.emitter = new ConnectionNotificationEmitter(this);
/*     */   }
/*     */   
/*     */   private ClassLoader findDefaultClassLoader(Map environment)
/*     */   {
/*  86 */     if (environment == null) return null;
/*  87 */     Object loader = environment.get("jmx.remote.default.class.loader");
/*  88 */     if ((loader != null) && (!(loader instanceof ClassLoader))) throw new IllegalArgumentException("Environment property jmx.remote.default.class.loader must be a ClassLoader");
/*  89 */     return (ClassLoader)loader;
/*     */   }
/*     */   
/*     */   public void connect() throws IOException, SecurityException
/*     */   {
/*  94 */     connect(null);
/*     */   }
/*     */   
/*     */   public void connect(Map environment) throws IOException, SecurityException
/*     */   {
/*  99 */     synchronized (this)
/*     */     {
/* 101 */       if (this.connected) return;
/* 102 */       if (this.closed) { throw new IOException("This RMIConnector has already been closed");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 108 */       ClassLoader loader = findDefaultClassLoader(environment);
/* 109 */       if (loader != null) {
/* 110 */         this.defaultClassLoader = loader;
/* 111 */       } else if (this.defaultClassLoader == null) {
/* 112 */         this.defaultClassLoader = Thread.currentThread().getContextClassLoader();
/*     */       }
/* 114 */       Map env = environment == null ? new HashMap() : environment;
/*     */       
/* 116 */       String protocol = this.jmxServiceURL.getProtocol();
/* 117 */       ConnectionResolver resolver = ConnectionResolver.newConnectionResolver(protocol, env);
/* 118 */       if (resolver == null) throw new IOException("Unsupported protocol: " + protocol);
/* 119 */       if (this.rmiServer == null) this.rmiServer = ((RMIServer)resolver.lookupClient(this.jmxServiceURL, env));
/* 120 */       this.rmiServer = ((RMIServer)resolver.bindClient(this.rmiServer, env));
/*     */       
/* 122 */       Object credentials = env.get("jmx.remote.credentials");
/* 123 */       this.connection = this.rmiServer.newClient(credentials);
/*     */       
/* 125 */       this.connected = true;
/* 126 */       this.connectionId = this.connection.getConnectionId();
/*     */       
/* 128 */       this.heartbeat = new RMIHeartBeat(this.connection, this.emitter, env);
/* 129 */       this.notificationHandler = new RMIRemoteNotificationClientHandler(this.connection, this.emitter, this.heartbeat, env);
/*     */       
/* 131 */       this.heartbeat.start();
/* 132 */       this.notificationHandler.start();
/*     */     }
/*     */     
/* 135 */     this.emitter.sendConnectionNotificationOpened();
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 140 */     synchronized (this)
/*     */     {
/* 142 */       if (this.closed) return;
/* 143 */       this.connected = false;
/* 144 */       this.closed = true;
/*     */       
/* 146 */       if (this.notificationHandler != null) this.notificationHandler.stop();
/* 147 */       if (this.heartbeat != null) this.heartbeat.stop();
/* 148 */       if (this.connection != null) { this.connection.close();
/*     */       }
/* 150 */       this.connection = null;
/* 151 */       this.rmiServer = null;
/*     */     }
/*     */     
/* 154 */     this.emitter.sendConnectionNotificationClosed();
/*     */   }
/*     */   
/*     */   public String getConnectionId() throws IOException
/*     */   {
/* 159 */     return this.connectionId;
/*     */   }
/*     */   
/*     */   public MBeanServerConnection getMBeanServerConnection() throws IOException
/*     */   {
/* 164 */     return getMBeanServerConnection(null);
/*     */   }
/*     */   
/*     */   public MBeanServerConnection getMBeanServerConnection(Subject delegate) throws IOException
/*     */   {
/* 169 */     if (!this.connected) { throw new IOException("Connection has not been established");
/*     */     }
/*     */     
/* 172 */     ClientInvoker invoker = new ClientInvoker(this.connection, this.notificationHandler, delegate);
/* 173 */     MBeanServerConnection unmarshaller = ClientUnmarshaller.newInstance(invoker, this.defaultClassLoader);
/* 174 */     MBeanServerConnection catcher = ClientExceptionCatcher.newInstance(unmarshaller);
/*     */     
/* 176 */     return catcher;
/*     */   }
/*     */   
/*     */   public void addConnectionNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback)
/*     */   {
/* 181 */     this.emitter.addNotificationListener(listener, filter, handback);
/*     */   }
/*     */   
/*     */   public void removeConnectionNotificationListener(NotificationListener listener) throws ListenerNotFoundException
/*     */   {
/* 186 */     this.emitter.removeNotificationListener(listener);
/*     */   }
/*     */   
/*     */   public void removeConnectionNotificationListener(NotificationListener listener, NotificationFilter filter, Object handback) throws ListenerNotFoundException
/*     */   {
/* 191 */     this.emitter.removeNotificationListener(listener, filter, handback);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException
/*     */   {
/* 196 */     ois.defaultReadObject();
/* 197 */     if ((this.jmxServiceURL == null) && (this.rmiServer == null)) throw new InvalidObjectException("Nor the JMXServiceURL nor the RMIServer were specified for this RMIConnector");
/* 198 */     initialize(null);
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream oos) throws IOException
/*     */   {
/* 203 */     if ((this.jmxServiceURL == null) && (this.rmiServer == null)) throw new InvalidObjectException("Nor the JMXServiceURL nor the RMIServer were specified for this RMIConnector");
/* 204 */     oos.defaultWriteObject();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/rmi/RMIConnector.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */