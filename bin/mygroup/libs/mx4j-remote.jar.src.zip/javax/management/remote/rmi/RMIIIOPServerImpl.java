/*    */ package javax.management.remote.rmi;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.rmi.Remote;
/*    */ import java.util.Map;
/*    */ import javax.rmi.CORBA.Stub;
/*    */ import javax.rmi.PortableRemoteObject;
/*    */ import javax.security.auth.Subject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RMIIIOPServerImpl
/*    */   extends RMIServerImpl
/*    */ {
/*    */   public RMIIIOPServerImpl(Map env)
/*    */     throws IOException
/*    */   {
/* 25 */     super(env);
/*    */   }
/*    */   
/*    */   protected void export() throws IOException
/*    */   {
/* 30 */     PortableRemoteObject.exportObject(this);
/*    */   }
/*    */   
/*    */   protected String getProtocol()
/*    */   {
/* 35 */     return "iiop";
/*    */   }
/*    */   
/*    */   public Remote toStub() throws IOException
/*    */   {
/* 40 */     Remote remote = PortableRemoteObject.toStub(this);
/* 41 */     if (!(remote instanceof Stub)) throw new IOException("Could not find IIOP stub");
/* 42 */     return remote;
/*    */   }
/*    */   
/*    */   protected RMIConnection makeClient(String connectionId, Subject subject) throws IOException
/*    */   {
/* 47 */     RMIConnectionImpl client = new RMIConnectionImpl(this, connectionId, getDefaultClassLoader(), subject, getEnvironment());
/* 48 */     client.setContext(getContext());
/* 49 */     PortableRemoteObject.exportObject(client);
/* 50 */     return client;
/*    */   }
/*    */   
/*    */   protected void closeClient(RMIConnection client) throws IOException
/*    */   {
/* 55 */     PortableRemoteObject.unexportObject(client);
/*    */   }
/*    */   
/*    */   protected void closeServer() throws IOException
/*    */   {
/* 60 */     PortableRemoteObject.unexportObject(this);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/rmi/RMIIIOPServerImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */