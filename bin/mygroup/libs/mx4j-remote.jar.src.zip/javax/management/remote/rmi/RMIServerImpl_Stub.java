/*    */ package javax.management.remote.rmi;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.rmi.RemoteException;
/*    */ import java.rmi.server.RemoteRef;
/*    */ 
/*    */ public final class RMIServerImpl_Stub extends java.rmi.server.RemoteStub implements RMIServer
/*    */ {
/*    */   private static final long serialVersionUID = 2L;
/*    */   private static java.lang.reflect.Method $method_getVersion_0;
/*    */   private static java.lang.reflect.Method $method_newClient_1;
/*    */   
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 17 */       $method_getVersion_0 = RMIServer.class.getMethod("getVersion", new Class[0]);
/* 18 */       $method_newClient_1 = RMIServer.class.getMethod("newClient", new Class[] { Object.class });
/*    */     } catch (NoSuchMethodException localNoSuchMethodException) {
/* 20 */       throw new NoSuchMethodError(
/* 21 */         "stub class initialization failed");
/*    */     }
/*    */   }
/*    */   
/*    */   public RMIServerImpl_Stub(RemoteRef ref)
/*    */   {
/* 27 */     super(ref);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getVersion()
/*    */     throws RemoteException
/*    */   {
/*    */     try
/*    */     {
/* 37 */       Object $result = this.ref.invoke(this, $method_getVersion_0, null, -8081107751519807347L);
/* 38 */       return (String)$result;
/*    */     } catch (RuntimeException e) {
/* 40 */       throw e;
/*    */     } catch (RemoteException e) {
/* 42 */       throw e;
/*    */     } catch (Exception e) {
/* 44 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*    */     }
/*    */   }
/*    */   
/*    */   public RMIConnection newClient(Object $param_Object_1)
/*    */     throws IOException, SecurityException
/*    */   {
/*    */     try
/*    */     {
/* 53 */       Object $result = this.ref.invoke(this, $method_newClient_1, new Object[] { $param_Object_1 }, -1089742558549201240L);
/* 54 */       return (RMIConnection)$result;
/*    */     } catch (RuntimeException e) {
/* 56 */       throw e;
/*    */     } catch (IOException e) {
/* 58 */       throw e;
/*    */     } catch (Exception e) {
/* 60 */       throw new java.rmi.UnexpectedException("undeclared checked exception", e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/rmi/RMIServerImpl_Stub.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */