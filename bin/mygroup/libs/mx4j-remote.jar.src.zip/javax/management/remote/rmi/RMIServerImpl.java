/*     */ package javax.management.remote.rmi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.rmi.Remote;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.remote.JMXAuthenticator;
/*     */ import javax.security.auth.Subject;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import mx4j.remote.MX4JRemoteUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RMIServerImpl
/*     */   implements RMIServer
/*     */ {
/*     */   private ClassLoader defaultClassLoader;
/*     */   private MBeanServer server;
/*     */   private Map environment;
/*     */   private RMIConnectorServer connector;
/*  38 */   private Map connections = new HashMap();
/*     */   private final AccessControlContext context;
/*     */   
/*     */   public RMIServerImpl(Map environment)
/*     */   {
/*  43 */     this.environment = new HashMap(environment);
/*  44 */     this.context = AccessController.getContext();
/*     */   }
/*     */   
/*     */   AccessControlContext getContext()
/*     */   {
/*  49 */     return this.context;
/*     */   }
/*     */   
/*     */   public abstract Remote toStub() throws IOException;
/*     */   
/*     */   protected abstract void export() throws IOException;
/*     */   
/*     */   protected abstract String getProtocol();
/*     */   
/*     */   protected abstract RMIConnection makeClient(String paramString, Subject paramSubject) throws IOException;
/*     */   
/*     */   protected abstract void closeClient(RMIConnection paramRMIConnection) throws IOException;
/*     */   
/*     */   protected abstract void closeServer() throws IOException;
/*     */   
/*     */   public ClassLoader getDefaultClassLoader()
/*     */   {
/*  66 */     return this.defaultClassLoader;
/*     */   }
/*     */   
/*     */   public void setDefaultClassLoader(ClassLoader defaultClassLoader)
/*     */   {
/*  71 */     this.defaultClassLoader = defaultClassLoader;
/*     */   }
/*     */   
/*     */   public synchronized void setMBeanServer(MBeanServer server)
/*     */   {
/*  76 */     this.server = server;
/*     */   }
/*     */   
/*     */   public synchronized MBeanServer getMBeanServer()
/*     */   {
/*  81 */     return this.server;
/*     */   }
/*     */   
/*     */   public String getVersion()
/*     */   {
/*  86 */     return "1.0 MX4J";
/*     */   }
/*     */   
/*     */   public synchronized RMIConnection newClient(Object credentials) throws IOException, SecurityException
/*     */   {
/*  91 */     Subject subject = authenticate(getEnvironment(), credentials);
/*     */     
/*  93 */     String connectionId = MX4JRemoteUtils.createConnectionID(getProtocol(), null, -1, subject);
/*     */     
/*     */     try
/*     */     {
/*  97 */       RMIConnection client = makeClient(connectionId, subject);
/*     */       
/*  99 */       WeakReference weak = new WeakReference(client);
/*     */       
/* 101 */       synchronized (this.connections)
/*     */       {
/* 103 */         this.connections.put(connectionId, weak);
/*     */       }
/*     */       
/* 106 */       this.connector.connectionOpened(connectionId, "Opened connection " + client, null);
/*     */       
/* 108 */       return client;
/*     */     }
/*     */     catch (IOException x)
/*     */     {
/* 112 */       throw x;
/*     */     }
/*     */     catch (RuntimeException x)
/*     */     {
/* 116 */       throw x;
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/* 120 */       throw new IOException(x.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private Subject authenticate(Map env, Object credentials) throws SecurityException
/*     */   {
/* 126 */     Logger logger = getLogger();
/*     */     
/* 128 */     Subject subject = null;
/* 129 */     JMXAuthenticator authenticator = (JMXAuthenticator)env.get("jmx.remote.authenticator");
/* 130 */     if (authenticator != null)
/*     */     {
/* 132 */       if (logger.isEnabledFor(10)) { logger.debug("Authenticating new client using JMXAuthenticator " + authenticator);
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 137 */         subject = (Subject)AccessController.doPrivileged(new PrivilegedAction() {
/*     */           private final JMXAuthenticator val$authenticator;
/*     */           private final Object val$credentials;
/*     */           
/* 141 */           public Object run() { return this.val$authenticator.authenticate(this.val$credentials); } }, getContext());
/*     */         
/*     */ 
/* 144 */         if (subject == null) throw new SecurityException("JMXAuthenticator returned null Subject");
/* 145 */         if (logger.isEnabledFor(0)) logger.trace("Authentication successful");
/*     */       }
/*     */       catch (SecurityException x)
/*     */       {
/* 149 */         if (logger.isEnabledFor(0)) logger.trace("Authentication failed", x);
/* 150 */         throw x;
/*     */       }
/*     */       catch (Throwable x)
/*     */       {
/* 154 */         if (logger.isEnabledFor(0)) logger.trace("Authentication failed", x);
/* 155 */         throw new SecurityException(x.toString());
/*     */       }
/*     */     }
/* 158 */     return subject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void clientClosed(RMIConnection client)
/*     */     throws IOException
/*     */   {
/* 168 */     String connectionID = client.getConnectionId();
/* 169 */     WeakReference weak = null;
/* 170 */     synchronized (this.connections)
/*     */     {
/* 172 */       weak = (WeakReference)this.connections.remove(connectionID);
/*     */     }
/*     */     
/* 175 */     if (weak == null) { throw new IOException("Could not find active connection with ID " + connectionID);
/*     */     }
/* 177 */     RMIConnection connection = (RMIConnection)weak.get();
/* 178 */     if (connection != client) { throw new IOException("Could not find active connection " + client);
/*     */     }
/* 180 */     closeClient(client);
/* 181 */     this.connector.connectionClosed(client.getConnectionId(), "Closed connection " + client, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void close()
/*     */     throws IOException
/*     */   {
/* 198 */     IOException serverException = null;
/*     */     try
/*     */     {
/* 201 */       closeServer();
/*     */     }
/*     */     catch (IOException x)
/*     */     {
/* 205 */       serverException = x;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 210 */       closeConnections();
/*     */     }
/*     */     catch (IOException x)
/*     */     {
/* 214 */       if (serverException != null) throw serverException;
/* 215 */       throw x;
/*     */     }
/*     */   }
/*     */   
/*     */   private void closeConnections() throws IOException
/*     */   {
/* 221 */     IOException clientException = null;
/* 222 */     synchronized (this.connections)
/*     */     {
/* 224 */       while (!this.connections.isEmpty())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 230 */         Iterator entries = this.connections.entrySet().iterator();
/* 231 */         Map.Entry entry = (Map.Entry)entries.next();
/* 232 */         WeakReference weak = (WeakReference)entry.getValue();
/* 233 */         RMIConnection connection = (RMIConnection)weak.get();
/* 234 */         if (connection == null)
/*     */         {
/*     */ 
/*     */ 
/* 238 */           entries.remove();
/*     */         }
/*     */         else
/*     */         {
/*     */           try
/*     */           {
/*     */ 
/* 245 */             connection.close();
/*     */           }
/*     */           catch (IOException x)
/*     */           {
/* 249 */             if (clientException == null) clientException = x;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 254 */     if (clientException != null) throw clientException;
/*     */   }
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/* 259 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */   
/*     */   Map getEnvironment()
/*     */   {
/* 264 */     return this.environment;
/*     */   }
/*     */   
/*     */   void setRMIConnectorServer(RMIConnectorServer cntorServer)
/*     */   {
/* 269 */     this.connector = cntorServer;
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/rmi/RMIServerImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */