/*     */ package javax.management.remote.rmi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.remote.JMXConnector;
/*     */ import javax.management.remote.JMXConnectorServer;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ import mx4j.remote.ConnectionResolver;
/*     */ import mx4j.remote.MX4JRemoteUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RMIConnectorServer
/*     */   extends JMXConnectorServer
/*     */ {
/*     */   public static final String JNDI_REBIND_ATTRIBUTE = "jmx.remote.jndi.rebind";
/*     */   public static final String RMI_CLIENT_SOCKET_FACTORY_ATTRIBUTE = "jmx.remote.rmi.client.socket.factory";
/*     */   public static final String RMI_SERVER_SOCKET_FACTORY_ATTRIBUTE = "jmx.remote.rmi.server.socket.factory";
/*     */   private JMXServiceURL url;
/*     */   private final Map environment;
/*     */   private RMIServerImpl rmiServer;
/*     */   private final ClassLoader defaultClassLoader;
/*     */   private boolean active;
/*     */   private boolean stopped;
/*     */   
/*     */   public RMIConnectorServer(JMXServiceURL url, Map environment)
/*     */     throws IOException
/*     */   {
/*  47 */     this(url, environment, null, null);
/*     */   }
/*     */   
/*     */   public RMIConnectorServer(JMXServiceURL url, Map environment, MBeanServer server) throws IOException
/*     */   {
/*  52 */     this(url, environment, null, server);
/*     */   }
/*     */   
/*     */   public RMIConnectorServer(JMXServiceURL url, Map environment, RMIServerImpl rmiServer, MBeanServer server) throws IOException
/*     */   {
/*  57 */     super(server);
/*  58 */     if (url == null) throw new IllegalArgumentException("JMXServiceURL cannot be null");
/*  59 */     this.url = url;
/*  60 */     this.environment = (environment == null ? new HashMap() : new HashMap(environment));
/*  61 */     this.rmiServer = rmiServer;
/*  62 */     this.defaultClassLoader = findDefaultClassLoader(this.environment, server);
/*     */   }
/*     */   
/*     */   private ClassLoader findDefaultClassLoader(Map environment, MBeanServer server) throws IllegalArgumentException
/*     */   {
/*  67 */     Object loader = environment.get("jmx.remote.default.class.loader");
/*  68 */     Object loaderName = environment.get("jmx.remote.default.class.loader.name");
/*  69 */     if ((loader != null) && (loaderName != null)) { throw new IllegalArgumentException("Environment properties jmx.remote.default.class.loader and jmx.remote.default.class.loader.name cannot be both defined");
/*     */     }
/*  71 */     if (loader != null)
/*     */     {
/*  73 */       if (!(loader instanceof ClassLoader)) {
/*  74 */         throw new IllegalArgumentException("Environment property jmx.remote.default.class.loader must be a ClassLoader");
/*     */       }
/*  76 */       return (ClassLoader)loader;
/*     */     }
/*     */     
/*  79 */     if (loaderName != null)
/*     */     {
/*  81 */       if (!(loaderName instanceof ObjectName)) throw new IllegalArgumentException("Environment property jmx.remote.default.class.loader.name must be an ObjectName");
/*  82 */       ObjectName name = (ObjectName)loaderName;
/*     */       try
/*     */       {
/*  85 */         if (!server.isInstanceOf(name, ClassLoader.class.getName())) throw new InstanceNotFoundException();
/*  86 */         return server.getClassLoader((ObjectName)loader);
/*     */       }
/*     */       catch (InstanceNotFoundException x)
/*     */       {
/*  90 */         throw new IllegalArgumentException("ObjectName " + name + " defined by environment property " + "jmx.remote.default.class.loader.name" + " must name a ClassLoader");
/*     */       }
/*     */     }
/*     */     
/*  94 */     return Thread.currentThread().getContextClassLoader();
/*     */   }
/*     */   
/*     */   public JMXServiceURL getAddress()
/*     */   {
/*  99 */     return this.url;
/*     */   }
/*     */   
/*     */   public Map getAttributes()
/*     */   {
/* 104 */     Map env = MX4JRemoteUtils.removeNonSerializableEntries(this.environment);
/* 105 */     return Collections.unmodifiableMap(env);
/*     */   }
/*     */   
/*     */   public boolean isActive()
/*     */   {
/* 110 */     return this.active;
/*     */   }
/*     */   
/*     */   private boolean isStopped()
/*     */   {
/* 115 */     return this.stopped;
/*     */   }
/*     */   
/*     */   public synchronized void start() throws IOException
/*     */   {
/* 120 */     Logger logger = getLogger();
/*     */     
/* 122 */     if (isActive())
/*     */     {
/* 124 */       if (logger.isEnabledFor(0)) logger.trace("This RMIConnectorServer has already been started");
/* 125 */       return;
/*     */     }
/* 127 */     if (isStopped())
/*     */     {
/* 129 */       if (logger.isEnabledFor(0)) logger.trace("This RMIConnectorServer has already been stopped");
/* 130 */       throw new IOException("This RMIConnectorServer has already been stopped");
/*     */     }
/*     */     
/* 133 */     MBeanServer server = getMBeanServer();
/* 134 */     if (server == null) { throw new IllegalStateException("This RMIConnectorServer is not attached to an MBeanServer");
/*     */     }
/* 136 */     JMXServiceURL address = getAddress();
/* 137 */     String protocol = address.getProtocol();
/* 138 */     ConnectionResolver resolver = ConnectionResolver.newConnectionResolver(protocol, this.environment);
/* 139 */     if (this.rmiServer == null)
/*     */     {
/* 141 */       if (resolver == null) throw new MalformedURLException("Unsupported protocol: " + protocol);
/* 142 */       this.rmiServer = ((RMIServerImpl)resolver.createServer(address, this.environment));
/*     */     }
/*     */     
/* 145 */     this.rmiServer.setRMIConnectorServer(this);
/* 146 */     this.rmiServer.setMBeanServer(server);
/* 147 */     this.rmiServer.setDefaultClassLoader(this.defaultClassLoader);
/*     */     
/* 149 */     this.rmiServer.export();
/*     */     
/*     */ 
/* 152 */     this.url = resolver.bindServer(this.rmiServer, address, this.environment);
/*     */     
/* 154 */     this.active = true;
/*     */     
/* 156 */     if (logger.isEnabledFor(20)) logger.info("RMIConnectorServer started at: " + this.url);
/*     */   }
/*     */   
/*     */   public synchronized void stop() throws IOException
/*     */   {
/* 161 */     if (isStopped()) { return;
/*     */     }
/* 163 */     this.stopped = true;
/* 164 */     this.active = false;
/*     */     
/* 166 */     if (this.rmiServer != null) { this.rmiServer.close();
/*     */     }
/* 168 */     JMXServiceURL address = getAddress();
/* 169 */     String protocol = address.getProtocol();
/* 170 */     ConnectionResolver resolver = ConnectionResolver.newConnectionResolver(protocol, this.environment);
/* 171 */     if (resolver == null) throw new MalformedURLException("Unsupported protocol: " + protocol);
/* 172 */     resolver.unbindServer(this.rmiServer, address, this.environment);
/* 173 */     resolver.destroyServer(this.rmiServer, address, this.environment);
/*     */     
/* 175 */     Logger logger = getLogger();
/* 176 */     if (logger.isEnabledFor(20)) logger.info("RMIConnectorServer stopped at: " + address);
/*     */   }
/*     */   
/*     */   public JMXConnector toJMXConnector(Map env) throws IOException
/*     */   {
/* 181 */     if (!isActive()) throw new IllegalStateException("This JMXConnectorServer has not been started");
/* 182 */     return super.toJMXConnector(env);
/*     */   }
/*     */   
/*     */   protected void connectionOpened(String connectionId, String message, Object userData)
/*     */   {
/* 187 */     super.connectionOpened(connectionId, message, userData);
/*     */   }
/*     */   
/*     */   protected void connectionClosed(String connectionId, String message, Object userData)
/*     */   {
/* 192 */     super.connectionClosed(connectionId, message, userData);
/*     */   }
/*     */   
/*     */   protected void connectionFailed(String connectionId, String message, Object userData)
/*     */   {
/* 197 */     super.connectionFailed(connectionId, message, userData);
/*     */   }
/*     */   
/*     */   private Logger getLogger()
/*     */   {
/* 202 */     return Log.getLogger(getClass().getName());
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/rmi/RMIConnectorServer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */