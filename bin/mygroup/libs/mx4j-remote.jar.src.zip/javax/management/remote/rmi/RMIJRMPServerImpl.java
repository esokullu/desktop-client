/*    */ package javax.management.remote.rmi;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.rmi.Remote;
/*    */ import java.rmi.server.RMIClientSocketFactory;
/*    */ import java.rmi.server.RMIServerSocketFactory;
/*    */ import java.rmi.server.RemoteObject;
/*    */ import java.rmi.server.UnicastRemoteObject;
/*    */ import java.util.Map;
/*    */ import javax.security.auth.Subject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RMIJRMPServerImpl
/*    */   extends RMIServerImpl
/*    */ {
/*    */   private final int port;
/*    */   private final RMIClientSocketFactory clientFactory;
/*    */   private final RMIServerSocketFactory serverFactory;
/*    */   
/*    */   public RMIJRMPServerImpl(int port, RMIClientSocketFactory csf, RMIServerSocketFactory ssf, Map env)
/*    */     throws IOException
/*    */   {
/* 31 */     super(env);
/* 32 */     this.port = port;
/* 33 */     this.clientFactory = csf;
/* 34 */     this.serverFactory = ssf;
/*    */   }
/*    */   
/*    */   protected void export() throws IOException
/*    */   {
/* 39 */     UnicastRemoteObject.exportObject(this, this.port, this.clientFactory, this.serverFactory);
/*    */   }
/*    */   
/*    */   protected String getProtocol()
/*    */   {
/* 44 */     return "rmi";
/*    */   }
/*    */   
/*    */   public Remote toStub() throws IOException
/*    */   {
/* 49 */     return RemoteObject.toStub(this);
/*    */   }
/*    */   
/*    */   protected RMIConnection makeClient(String connectionId, Subject subject) throws IOException
/*    */   {
/* 54 */     RMIConnectionImpl client = new RMIConnectionImpl(this, connectionId, getDefaultClassLoader(), subject, getEnvironment());
/* 55 */     client.setContext(getContext());
/* 56 */     UnicastRemoteObject.exportObject(client, this.port, this.clientFactory, this.serverFactory);
/* 57 */     return client;
/*    */   }
/*    */   
/*    */ 
/*    */   protected void closeClient(RMIConnection client)
/*    */     throws IOException
/*    */   {
/* 64 */     UnicastRemoteObject.unexportObject(client, true);
/*    */   }
/*    */   
/*    */ 
/*    */   protected void closeServer()
/*    */     throws IOException
/*    */   {
/* 71 */     UnicastRemoteObject.unexportObject(this, true);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/rmi/RMIJRMPServerImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */