/*    */ package javax.management.remote;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotificationResult
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1191800228721395279L;
/*    */   private final long earliestSequenceNumber;
/*    */   private final long nextSequenceNumber;
/*    */   private final TargetedNotification[] targetedNotifications;
/*    */   
/*    */   public NotificationResult(long earliestSequenceNumber, long nextSequenceNumber, TargetedNotification[] targetedNotifications)
/*    */   {
/* 38 */     if (earliestSequenceNumber < 0L) throw new IllegalArgumentException("Earliest sequence number cannot be negative");
/* 39 */     if (nextSequenceNumber < 0L) throw new IllegalArgumentException("Next sequence number cannot be negative");
/* 40 */     if (targetedNotifications == null) throw new IllegalArgumentException("TargetedNotification array cannot be null");
/* 41 */     this.earliestSequenceNumber = earliestSequenceNumber;
/* 42 */     this.nextSequenceNumber = nextSequenceNumber;
/* 43 */     this.targetedNotifications = targetedNotifications;
/*    */   }
/*    */   
/*    */   public long getEarliestSequenceNumber()
/*    */   {
/* 48 */     return this.earliestSequenceNumber;
/*    */   }
/*    */   
/*    */   public long getNextSequenceNumber()
/*    */   {
/* 53 */     return this.nextSequenceNumber;
/*    */   }
/*    */   
/*    */   public TargetedNotification[] getTargetedNotifications()
/*    */   {
/* 58 */     return this.targetedNotifications;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 63 */     StringBuffer buffer = new StringBuffer("NotificationResult[earliest=");
/* 64 */     buffer.append(getEarliestSequenceNumber()).append(", next=");
/* 65 */     buffer.append(getNextSequenceNumber()).append(", notifications=");
/* 66 */     TargetedNotification[] notifs = getTargetedNotifications();
/* 67 */     List list = notifs == null ? null : Arrays.asList(notifs);
/* 68 */     buffer.append(list).append("]");
/* 69 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/NotificationResult.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */