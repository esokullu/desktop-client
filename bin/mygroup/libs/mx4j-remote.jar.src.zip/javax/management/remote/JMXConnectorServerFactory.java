/*    */ package javax.management.remote;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.management.MBeanServer;
/*    */ import mx4j.remote.ProviderFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMXConnectorServerFactory
/*    */ {
/*    */   public static final String DEFAULT_CLASS_LOADER = "jmx.remote.default.class.loader";
/*    */   public static final String DEFAULT_CLASS_LOADER_NAME = "jmx.remote.default.class.loader.name";
/*    */   public static final String PROTOCOL_PROVIDER_PACKAGES = "jmx.remote.protocol.provider.pkgs";
/*    */   public static final String PROTOCOL_PROVIDER_CLASS_LOADER = "jmx.remote.protocol.provider.class.loader";
/*    */   
/*    */   public static JMXConnectorServer newJMXConnectorServer(JMXServiceURL url, Map environment, MBeanServer server)
/*    */     throws IOException
/*    */   {
/* 35 */     Map env = environment == null ? new HashMap() : new HashMap(environment);
/* 36 */     JMXConnectorServerProvider provider = ProviderFactory.newJMXConnectorServerProvider(url, env);
/* 37 */     return provider.newJMXConnectorServer(url, Collections.unmodifiableMap(env), server);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/JMXConnectorServerFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */