/*    */ package javax.management.remote;
/*    */ 
/*    */ import java.security.BasicPermission;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SubjectDelegationPermission
/*    */   extends BasicPermission
/*    */ {
/*    */   public SubjectDelegationPermission(String name)
/*    */   {
/* 20 */     super(name);
/*    */   }
/*    */   
/*    */   public SubjectDelegationPermission(String name, String actions)
/*    */   {
/* 25 */     super(name, actions);
/* 26 */     if (actions != null) throw new IllegalArgumentException("The permission's actions must be null");
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/SubjectDelegationPermission.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */