package javax.management.remote;

import java.io.IOException;
import java.util.Map;

public abstract interface JMXConnectorServerMBean
{
  public abstract JMXServiceURL getAddress();
  
  public abstract Map getAttributes();
  
  public abstract String[] getConnectionIds();
  
  public abstract JMXConnector toJMXConnector(Map paramMap)
    throws IOException, UnsupportedOperationException, IllegalStateException;
  
  public abstract boolean isActive();
  
  public abstract void start()
    throws IOException, IllegalStateException;
  
  public abstract void stop()
    throws IOException;
  
  public abstract void setMBeanServerForwarder(MBeanServerForwarder paramMBeanServerForwarder)
    throws IllegalArgumentException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/JMXConnectorServerMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */