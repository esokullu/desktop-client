package javax.management.remote;

import javax.management.MBeanServer;

public abstract interface MBeanServerForwarder
  extends MBeanServer
{
  public abstract MBeanServer getMBeanServer();
  
  public abstract void setMBeanServer(MBeanServer paramMBeanServer)
    throws IllegalArgumentException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/MBeanServerForwarder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */