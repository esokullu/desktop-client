/*    */ package javax.management.remote;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.security.Principal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMXPrincipal
/*    */   implements Principal, Serializable
/*    */ {
/*    */   private String name;
/*    */   
/*    */   public JMXPrincipal(String name)
/*    */   {
/* 26 */     if (name == null) throw new NullPointerException("Principal name cannot be null");
/* 27 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 32 */     return this.name;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 37 */     return getName().hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 42 */     if (obj == null) return false;
/* 43 */     if (obj == this) { return true;
/*    */     }
/*    */     try
/*    */     {
/* 47 */       JMXPrincipal other = (JMXPrincipal)obj;
/* 48 */       return getName().equals(other.getName());
/*    */     }
/*    */     catch (ClassCastException x) {}
/*    */     
/*    */ 
/* 53 */     return false;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 58 */     return getName();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/JMXPrincipal.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */