/*    */ package javax.management.remote;
/*    */ 
/*    */ import javax.management.Notification;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMXConnectionNotification
/*    */   extends Notification
/*    */ {
/*    */   public static final String OPENED = "jmx.remote.connection.opened";
/*    */   public static final String CLOSED = "jmx.remote.connection.closed";
/*    */   public static final String FAILED = "jmx.remote.connection.failed";
/*    */   public static final String NOTIFS_LOST = "jmx.remote.connection.notifs.lost";
/*    */   private static final long serialVersionUID = -2331308725952627538L;
/*    */   private String connectionId;
/*    */   
/*    */   public JMXConnectionNotification(String type, Object source, String connectionId, long sequenceNumber, String message, Object userData)
/*    */   {
/* 32 */     super(type, source, sequenceNumber, System.currentTimeMillis(), message);
/* 33 */     setUserData(userData);
/* 34 */     this.connectionId = connectionId;
/*    */   }
/*    */   
/*    */   public String getConnectionId()
/*    */   {
/* 39 */     return this.connectionId;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/JMXConnectionNotification.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */