/*    */ package javax.management.remote;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMXProviderException
/*    */   extends IOException
/*    */ {
/*    */   private Throwable cause;
/*    */   private static final long serialVersionUID = -3166703627550447198L;
/*    */   
/*    */   public JMXProviderException() {}
/*    */   
/*    */   public JMXProviderException(String message)
/*    */   {
/* 31 */     super(message);
/*    */   }
/*    */   
/*    */   public JMXProviderException(String message, Throwable cause)
/*    */   {
/* 36 */     super(message);
/* 37 */     this.cause = cause;
/*    */   }
/*    */   
/*    */   public Throwable getCause()
/*    */   {
/* 42 */     return this.cause;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/JMXProviderException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */