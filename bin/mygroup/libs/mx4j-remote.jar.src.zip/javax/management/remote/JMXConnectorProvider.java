package javax.management.remote;

import java.io.IOException;
import java.util.Map;

public abstract interface JMXConnectorProvider
{
  public abstract JMXConnector newJMXConnector(JMXServiceURL paramJMXServiceURL, Map paramMap)
    throws IOException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/JMXConnectorProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */