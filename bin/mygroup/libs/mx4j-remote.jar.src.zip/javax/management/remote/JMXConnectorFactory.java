/*    */ package javax.management.remote;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import mx4j.remote.ProviderFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMXConnectorFactory
/*    */ {
/*    */   public static final String DEFAULT_CLASS_LOADER = "jmx.remote.default.class.loader";
/*    */   public static final String PROTOCOL_PROVIDER_PACKAGES = "jmx.remote.protocol.provider.pkgs";
/*    */   public static final String PROTOCOL_PROVIDER_CLASS_LOADER = "jmx.remote.protocol.provider.class.loader";
/*    */   
/*    */   public static JMXConnector connect(JMXServiceURL url)
/*    */     throws IOException
/*    */   {
/* 33 */     return connect(url, null);
/*    */   }
/*    */   
/*    */   public static JMXConnector connect(JMXServiceURL url, Map environment) throws IOException
/*    */   {
/* 38 */     JMXConnector connector = newJMXConnector(url, environment);
/* 39 */     connector.connect(environment);
/* 40 */     return connector;
/*    */   }
/*    */   
/*    */   public static JMXConnector newJMXConnector(JMXServiceURL url, Map env) throws IOException
/*    */   {
/* 45 */     Map envCopy = env == null ? new HashMap() : new HashMap(env);
/* 46 */     JMXConnectorProvider provider = ProviderFactory.newJMXConnectorProvider(url, envCopy);
/* 47 */     return provider.newJMXConnector(url, Collections.unmodifiableMap(envCopy));
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/JMXConnectorFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */