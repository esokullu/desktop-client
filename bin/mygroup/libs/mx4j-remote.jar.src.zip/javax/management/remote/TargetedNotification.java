/*    */ package javax.management.remote;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.management.Notification;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TargetedNotification
/*    */   implements Serializable
/*    */ {
/*    */   private final Notification notif;
/*    */   private final Integer id;
/*    */   
/*    */   public TargetedNotification(Notification notif, Integer id)
/*    */   {
/* 30 */     this.notif = notif;
/* 31 */     this.id = id;
/*    */   }
/*    */   
/*    */   public Notification getNotification()
/*    */   {
/* 36 */     return this.notif;
/*    */   }
/*    */   
/*    */   public Integer getListenerID()
/*    */   {
/* 41 */     return this.id;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 46 */     StringBuffer buffer = new StringBuffer("TargetedNotification[id=");
/* 47 */     buffer.append(getListenerID()).append(", notification=");
/* 48 */     buffer.append(getNotification()).append("]");
/* 49 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/TargetedNotification.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */