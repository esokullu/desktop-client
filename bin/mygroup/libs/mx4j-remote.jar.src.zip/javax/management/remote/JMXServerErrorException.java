/*    */ package javax.management.remote;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMXServerErrorException
/*    */   extends IOException
/*    */ {
/*    */   private Error cause;
/*    */   private static final long serialVersionUID = 3996732239558744666L;
/*    */   
/*    */   public JMXServerErrorException(String message, Error error)
/*    */   {
/* 26 */     super(message);
/* 27 */     this.cause = error;
/*    */   }
/*    */   
/*    */   public Throwable getCause()
/*    */   {
/* 32 */     return this.cause;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/JMXServerErrorException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */