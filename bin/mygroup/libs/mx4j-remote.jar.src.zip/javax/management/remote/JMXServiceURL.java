/*     */ package javax.management.remote;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.net.InetAddress;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.UnknownHostException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMXServiceURL
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 8173364409860779292L;
/*     */   private String protocol;
/*     */   private String host;
/*     */   private int port;
/*     */   private String urlPath;
/*     */   private transient int hash;
/*     */   
/*     */   public JMXServiceURL(String url)
/*     */     throws MalformedURLException
/*     */   {
/*  44 */     if (url == null) throw new NullPointerException("Null JMXServiceURL string");
/*  45 */     parse(url);
/*     */   }
/*     */   
/*     */   public JMXServiceURL(String protocol, String host, int port) throws MalformedURLException
/*     */   {
/*  50 */     this(protocol, host, port, null);
/*     */   }
/*     */   
/*     */   public JMXServiceURL(String protocol, String host, int port, String urlPath) throws MalformedURLException
/*     */   {
/*  55 */     if (port < 0) { throw new MalformedURLException("Port number cannot be less than zero");
/*     */     }
/*  57 */     setProtocol(protocol);
/*  58 */     setHost(host);
/*  59 */     setPort(port);
/*  60 */     setURLPath(urlPath);
/*     */   }
/*     */   
/*     */   private String resolveHost() throws MalformedURLException
/*     */   {
/*     */     try
/*     */     {
/*  67 */       return InetAddress.getLocalHost().getHostName();
/*     */     }
/*     */     catch (UnknownHostException x)
/*     */     {
/*  71 */       throw new MalformedURLException("Cannot resolve local host name");
/*     */     }
/*     */   }
/*     */   
/*     */   public String getProtocol()
/*     */   {
/*  77 */     return this.protocol;
/*     */   }
/*     */   
/*     */   private void setProtocol(String protocol)
/*     */   {
/*  82 */     if (protocol != null) {
/*  83 */       this.protocol = protocol.toLowerCase();
/*     */     } else {
/*  85 */       this.protocol = "jmxmp";
/*     */     }
/*     */   }
/*     */   
/*     */   public String getHost() {
/*  90 */     return this.host;
/*     */   }
/*     */   
/*     */   private void setHost(String host) throws MalformedURLException
/*     */   {
/*  95 */     if (host != null) {
/*  96 */       this.host = host.toLowerCase();
/*     */     } else {
/*  98 */       this.host = resolveHost().toLowerCase();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getPort() {
/* 103 */     return this.port;
/*     */   }
/*     */   
/*     */   private void setPort(int port)
/*     */   {
/* 108 */     this.port = port;
/*     */   }
/*     */   
/*     */   public String getURLPath()
/*     */   {
/* 113 */     return this.urlPath;
/*     */   }
/*     */   
/*     */   private void setURLPath(String urlPath)
/*     */   {
/* 118 */     if (urlPath != null)
/*     */     {
/* 120 */       if ((urlPath.length() > 0) && (!urlPath.startsWith("/"))) urlPath = "/" + urlPath;
/* 121 */       this.urlPath = urlPath;
/*     */     }
/*     */     else
/*     */     {
/* 125 */       this.urlPath = "";
/*     */     }
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 131 */     if (this.hash == 0)
/*     */     {
/* 133 */       this.hash = getProtocol().hashCode();
/* 134 */       String host = getHost();
/* 135 */       this.hash = (29 * this.hash + (host != null ? host.hashCode() : 0));
/* 136 */       this.hash = (29 * this.hash + getPort());
/* 137 */       String path = getURLPath();
/* 138 */       this.hash = (29 * this.hash + (path != null ? path.hashCode() : 0));
/*     */     }
/* 140 */     return this.hash;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 145 */     if (obj == this) return true;
/* 146 */     if (!(obj instanceof JMXServiceURL)) { return false;
/*     */     }
/* 148 */     JMXServiceURL other = (JMXServiceURL)obj;
/*     */     
/* 150 */     if (!getProtocol().equalsIgnoreCase(other.getProtocol())) { return false;
/*     */     }
/* 152 */     String host = getHost();
/* 153 */     String otherHost = other.getHost();
/* 154 */     if (host != null ? !host.equalsIgnoreCase(otherHost) : otherHost != null) { return false;
/*     */     }
/* 156 */     if (getPort() != other.getPort()) { return false;
/*     */     }
/* 158 */     String path = getURLPath();
/* 159 */     String otherPath = other.getURLPath();
/* 160 */     if (path != null ? !path.equals(otherPath) : otherPath != null) { return false;
/*     */     }
/* 162 */     return true;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 167 */     StringBuffer buffer = new StringBuffer("service:jmx:");
/* 168 */     buffer.append(getProtocol()).append("://");
/* 169 */     buffer.append(getHost());
/* 170 */     int port = getPort();
/* 171 */     if (port > 0) buffer.append(":").append(port);
/* 172 */     String path = getURLPath();
/* 173 */     if (path != null)
/*     */     {
/* 175 */       if (!path.startsWith("/")) buffer.append("/");
/* 176 */       buffer.append(path);
/*     */     }
/* 178 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private void parse(String url) throws MalformedURLException
/*     */   {
/* 183 */     String prefix = "service:jmx:";
/* 184 */     if (url.length() <= prefix.length()) throw new MalformedURLException("JMXServiceURL " + url + " must start with " + prefix);
/* 185 */     String servicejmx = url.substring(0, prefix.length());
/* 186 */     if (!servicejmx.equalsIgnoreCase(prefix)) { throw new MalformedURLException("JMXServiceURL " + url + " must start with " + prefix);
/*     */     }
/* 188 */     String parse = url.substring(prefix.length());
/*     */     
/* 190 */     String hostSeparator = "://";
/* 191 */     int index = parse.indexOf(hostSeparator);
/* 192 */     if (index < 0) throw new MalformedURLException("No protocol defined for JMXServiceURL " + url);
/* 193 */     String protocol = parse.substring(0, index);
/* 194 */     checkProtocol(url, protocol);
/* 195 */     setProtocol(protocol);
/*     */     
/* 197 */     String hostAndMore = parse.substring(index + hostSeparator.length());
/* 198 */     index = hostAndMore.indexOf('/');
/* 199 */     if (index < 0)
/*     */     {
/* 201 */       parseHostAndPort(url, hostAndMore);
/* 202 */       setURLPath(null);
/*     */     }
/*     */     else
/*     */     {
/* 206 */       String hostAndPort = hostAndMore.substring(0, index);
/* 207 */       parseHostAndPort(url, hostAndPort);
/*     */       
/* 209 */       String pathAndMore = hostAndMore.substring(index);
/* 210 */       if (pathAndMore.length() > 0)
/*     */       {
/* 212 */         checkURLPath(url, pathAndMore);
/* 213 */         String path = "/".equals(pathAndMore) ? "" : pathAndMore;
/* 214 */         setURLPath(path);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseHostAndPort(String url, String hostAndPort) throws MalformedURLException
/*     */   {
/* 221 */     if (hostAndPort.length() == 0)
/*     */     {
/* 223 */       setHost(null);
/* 224 */       setPort(0);
/* 225 */       return;
/*     */     }
/*     */     
/* 228 */     int colon = hostAndPort.indexOf(':');
/* 229 */     if (colon == 0) { throw new MalformedURLException("No host defined for JMXServiceURL " + url);
/*     */     }
/* 231 */     if (colon > 0)
/*     */     {
/* 233 */       String host = hostAndPort.substring(0, colon);
/* 234 */       checkHost(url, host);
/* 235 */       setHost(host);
/* 236 */       String portString = hostAndPort.substring(colon + 1);
/*     */       try
/*     */       {
/* 239 */         int port = Integer.parseInt(portString);
/* 240 */         setPort(port);
/*     */       }
/*     */       catch (NumberFormatException x)
/*     */       {
/* 244 */         throw new MalformedURLException("Invalid port " + portString + " for JMXServiceURL " + url);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 249 */       checkHost(url, hostAndPort);
/* 250 */       setHost(hostAndPort);
/* 251 */       setPort(0);
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkProtocol(String url, String protocol) throws MalformedURLException
/*     */   {
/* 257 */     if (protocol.length() == 0) throw new MalformedURLException("No protocol defined for JMXServiceURL " + url);
/* 258 */     if (!protocol.trim().equals(protocol)) throw new MalformedURLException("No leading or trailing white space allowed in protocol for JMXServiceURL " + url);
/*     */   }
/*     */   
/*     */   private void checkHost(String url, String host) throws MalformedURLException
/*     */   {
/* 263 */     if (host.length() == 0) throw new MalformedURLException("No host defined for JMXServiceURL " + url);
/* 264 */     if (!host.trim().equals(host)) throw new MalformedURLException("No leading or trailing white space allowed in host for JMXServiceURL " + url);
/*     */   }
/*     */   
/*     */   private void checkURLPath(String url, String path) throws MalformedURLException
/*     */   {
/* 269 */     if (!path.startsWith("/")) throw new MalformedURLException("Invalid path for JMXServiceURL " + url);
/* 270 */     if (!path.trim().equals(path)) throw new MalformedURLException("No leading or trailing white space allowed in path for JMXServiceURL " + url);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/JMXServiceURL.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */