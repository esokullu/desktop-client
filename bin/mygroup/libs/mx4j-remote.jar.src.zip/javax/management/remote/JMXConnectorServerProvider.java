package javax.management.remote;

import java.io.IOException;
import java.util.Map;
import javax.management.MBeanServer;

public abstract interface JMXConnectorServerProvider
{
  public abstract JMXConnectorServer newJMXConnectorServer(JMXServiceURL paramJMXServiceURL, Map paramMap, MBeanServer paramMBeanServer)
    throws IOException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/JMXConnectorServerProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */