/*     */ package javax.management.remote;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.management.MBeanNotificationInfo;
/*     */ import javax.management.MBeanRegistration;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.NotificationBroadcasterSupport;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JMXConnectorServer
/*     */   extends NotificationBroadcasterSupport
/*     */   implements JMXConnectorServerMBean, MBeanRegistration
/*     */ {
/*     */   public static final String AUTHENTICATOR = "jmx.remote.authenticator";
/*  28 */   private static final MBeanNotificationInfo[] notifications = { new MBeanNotificationInfo(new String[] { "jmx.remote.connection.opened", "jmx.remote.connection.closed", "jmx.remote.connection.failed" }, JMXConnectionNotification.class.getName(), "Notifications emitted by the JMXConnectorServer MBean upon opening, closing or failing of a connection") };
/*     */   
/*     */ 
/*     */   private static long notificationSequenceNumber;
/*     */   
/*     */   private MBeanServer server;
/*     */   
/*     */   private ObjectName name;
/*     */   
/*  37 */   private final HashSet connections = new HashSet();
/*     */   
/*     */ 
/*     */   public JMXConnectorServer() {}
/*     */   
/*     */ 
/*     */   public JMXConnectorServer(MBeanServer server)
/*     */   {
/*  45 */     this.server = server;
/*     */   }
/*     */   
/*     */   public ObjectName preRegister(MBeanServer server, ObjectName name)
/*     */   {
/*  50 */     if (name == null) throw new NullPointerException("ObjectName cannot be null");
/*  51 */     if (this.server == null) this.server = server;
/*  52 */     this.name = name;
/*  53 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */   public void postRegister(Boolean registrationDone) {}
/*     */   
/*     */   public void preDeregister()
/*     */     throws Exception
/*     */   {
/*  62 */     if (isActive()) { stop();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void postDeregister() {}
/*     */   
/*     */   public MBeanNotificationInfo[] getNotificationInfo()
/*     */   {
/*  71 */     return notifications;
/*     */   }
/*     */   
/*     */   public MBeanServer getMBeanServer()
/*     */   {
/*  76 */     return this.server;
/*     */   }
/*     */   
/*     */   public void setMBeanServerForwarder(MBeanServerForwarder forwarder) throws IllegalArgumentException
/*     */   {
/*  81 */     if (forwarder.getMBeanServer() == null)
/*     */     {
/*  83 */       if (this.server == null) throw new IllegalStateException("This JMXConnectorServer is not attached to an MBeanServer");
/*     */     }
/*  85 */     forwarder.setMBeanServer(this.server);
/*  86 */     this.server = forwarder;
/*     */   }
/*     */   
/*     */   public JMXConnector toJMXConnector(Map environment) throws IOException
/*     */   {
/*  91 */     JMXServiceURL address = getAddress();
/*  92 */     return JMXConnectorFactory.newJMXConnector(address, environment);
/*     */   }
/*     */   
/*     */   public String[] getConnectionIds()
/*     */   {
/*  97 */     Set copy = null;
/*  98 */     synchronized (this.connections)
/*     */     {
/* 100 */       copy = (Set)this.connections.clone();
/*     */     }
/* 102 */     return (String[])copy.toArray(new String[copy.size()]);
/*     */   }
/*     */   
/*     */   protected void connectionOpened(String connectionId, String message, Object userData)
/*     */   {
/* 107 */     synchronized (this.connections)
/*     */     {
/* 109 */       boolean added = this.connections.add(connectionId);
/* 110 */       if (!added) { throw new IllegalStateException("Duplicate connection ID: " + connectionId);
/*     */       }
/*     */     }
/* 113 */     Object source = this.name;
/* 114 */     if (source == null) source = this;
/* 115 */     JMXConnectionNotification notification = new JMXConnectionNotification("jmx.remote.connection.opened", source, connectionId, getNextSequenceNumber(), message, userData);
/* 116 */     sendNotification(notification);
/*     */   }
/*     */   
/*     */   protected void connectionClosed(String connectionId, String message, Object userData)
/*     */   {
/* 121 */     synchronized (this.connections)
/*     */     {
/* 123 */       boolean removed = this.connections.remove(connectionId);
/* 124 */       if (!removed) { throw new IllegalStateException("Connection ID not present: " + connectionId);
/*     */       }
/*     */     }
/* 127 */     Object source = this.name;
/* 128 */     if (source == null) source = this;
/* 129 */     JMXConnectionNotification notification = new JMXConnectionNotification("jmx.remote.connection.closed", source, connectionId, getNextSequenceNumber(), message, userData);
/* 130 */     sendNotification(notification);
/*     */   }
/*     */   
/*     */   protected void connectionFailed(String connectionId, String message, Object userData)
/*     */   {
/* 135 */     synchronized (this.connections)
/*     */     {
/* 137 */       boolean removed = this.connections.remove(connectionId);
/* 138 */       if (!removed) { throw new IllegalStateException("Connection ID not present: " + connectionId);
/*     */       }
/*     */     }
/* 141 */     Object source = this.name;
/* 142 */     if (source == null) source = this;
/* 143 */     JMXConnectionNotification notification = new JMXConnectionNotification("jmx.remote.connection.failed", source, connectionId, getNextSequenceNumber(), message, userData);
/* 144 */     sendNotification(notification);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private long getNextSequenceNumber()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 46	javax/management/remote/JMXConnectorServer:class$javax$management$remote$JMXConnectorServer	Ljava/lang/Class;
/*     */     //   3: ifnonnull +15 -> 18
/*     */     //   6: ldc 47
/*     */     //   8: invokestatic 48	javax/management/remote/JMXConnectorServer:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   11: dup
/*     */     //   12: putstatic 46	javax/management/remote/JMXConnectorServer:class$javax$management$remote$JMXConnectorServer	Ljava/lang/Class;
/*     */     //   15: goto +6 -> 21
/*     */     //   18: getstatic 46	javax/management/remote/JMXConnectorServer:class$javax$management$remote$JMXConnectorServer	Ljava/lang/Class;
/*     */     //   21: dup
/*     */     //   22: astore_1
/*     */     //   23: monitorenter
/*     */     //   24: getstatic 49	javax/management/remote/JMXConnectorServer:notificationSequenceNumber	J
/*     */     //   27: lconst_1
/*     */     //   28: ladd
/*     */     //   29: dup2
/*     */     //   30: putstatic 49	javax/management/remote/JMXConnectorServer:notificationSequenceNumber	J
/*     */     //   33: aload_1
/*     */     //   34: monitorexit
/*     */     //   35: lreturn
/*     */     //   36: astore_2
/*     */     //   37: aload_1
/*     */     //   38: monitorexit
/*     */     //   39: aload_2
/*     */     //   40: athrow
/*     */     // Line number table:
/*     */     //   Java source line #149	-> byte code offset #0
/*     */     //   Java source line #151	-> byte code offset #24
/*     */     //   Java source line #152	-> byte code offset #36
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	41	0	this	JMXConnectorServer
/*     */     //   22	16	1	Ljava/lang/Object;	Object
/*     */     //   36	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   24	35	36	finally
/*     */     //   36	39	36	finally
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/JMXConnectorServer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */