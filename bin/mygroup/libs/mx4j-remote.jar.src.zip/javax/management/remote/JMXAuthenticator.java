package javax.management.remote;

import javax.security.auth.Subject;

public abstract interface JMXAuthenticator
{
  public abstract Subject authenticate(Object paramObject)
    throws SecurityException;
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/javax/management/remote/JMXAuthenticator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */