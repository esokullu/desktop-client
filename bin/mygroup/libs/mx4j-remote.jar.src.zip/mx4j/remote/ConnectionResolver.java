/*     */ package mx4j.remote;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConnectionResolver
/*     */   extends ProviderHelper
/*     */ {
/*     */   public static ConnectionResolver newConnectionResolver(String proto, Map environment)
/*     */   {
/*  41 */     String protocol = normalizeProtocol(proto);
/*  42 */     String resolverPackages = findResolverPackageList();
/*  43 */     ClassLoader classLoader = findResolverClassLoader(environment, "jmx.remote.protocol.provider.class.loader");
/*  44 */     return loadResolver(resolverPackages, protocol, classLoader);
/*     */   }
/*     */   
/*     */   private static String findResolverPackageList()
/*     */   {
/*  49 */     String packages = findSystemPackageList("mx4j.remote.resolver.pkgs");
/*  50 */     if (packages == null) {
/*  51 */       packages = "mx4j.remote.resolver|mx4j.tools.remote.resolver";
/*     */     } else
/*  53 */       packages = packages + "|mx4j.remote.resolver|mx4j.tools.remote.resolver";
/*  54 */     Logger logger = getLogger();
/*  55 */     if (logger.isEnabledFor(10)) logger.debug("Resolver packages list is: " + packages);
/*  56 */     return packages;
/*     */   }
/*     */   
/*     */   private static ClassLoader findResolverClassLoader(Map environment, String loaderKey)
/*     */   {
/*  61 */     if (environment == null) return Thread.currentThread().getContextClassLoader();
/*  62 */     Object object = environment.get(loaderKey);
/*  63 */     if (object == null) return Thread.currentThread().getContextClassLoader();
/*  64 */     if (!(object instanceof ClassLoader)) throw new IllegalArgumentException("Environment property " + loaderKey + " must be a ClassLoader");
/*  65 */     return (ClassLoader)object;
/*     */   }
/*     */   
/*     */   private static ConnectionResolver loadResolver(String packages, String protocol, ClassLoader loader)
/*     */   {
/*  70 */     Logger logger = getLogger();
/*     */     
/*  72 */     StringTokenizer tokenizer = new StringTokenizer(packages, "|");
/*  73 */     String resolverClassName; Class resolverClass; for (;;) { if (!tokenizer.hasMoreTokens())
/*     */         break label254;
/*  75 */       String pkg = tokenizer.nextToken().trim();
/*  76 */       if (logger.isEnabledFor(10)) logger.debug("Resolver package: " + pkg);
/*  77 */       if (pkg.length() != 0)
/*     */       {
/*  79 */         String className = protocol.toUpperCase() + "Resolver";
/*  80 */         resolverClassName = constructClassName(pkg, protocol, className);
/*     */         
/*  82 */         resolverClass = null;
/*     */         try
/*     */         {
/*  85 */           resolverClass = loadClass(resolverClassName, loader);
/*     */         }
/*     */         catch (ClassNotFoundException x)
/*     */         {
/*  89 */           if (logger.isEnabledFor(10)) { logger.debug("Resolver class " + resolverClassName + " not found, continuing with next package");
/*     */           }
/*     */         }
/*     */         catch (Exception x)
/*     */         {
/*  94 */           if (logger.isEnabledFor(0)) logger.trace("Cannot load resolver class " + resolverClassName, x);
/*  95 */           return null;
/*     */         }
/*     */       }
/*     */     }
/*     */     try {
/* 100 */       return (ConnectionResolver)resolverClass.newInstance();
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/* 104 */       if (logger.isEnabledFor(0)) logger.trace("Cannot instantiate resolver class " + resolverClassName, x);
/* 105 */       return null;
/*     */     }
/*     */     
/*     */     label254:
/*     */     
/* 110 */     if (logger.isEnabledFor(10)) logger.debug("Could not find resolver for protocol " + protocol + " in package list '" + packages + "'");
/* 111 */     return null;
/*     */   }
/*     */   
/*     */   public abstract Object lookupClient(JMXServiceURL paramJMXServiceURL, Map paramMap)
/*     */     throws IOException;
/*     */   
/*     */   public abstract Object bindClient(Object paramObject, Map paramMap)
/*     */     throws IOException;
/*     */   
/*     */   public abstract Object createServer(JMXServiceURL paramJMXServiceURL, Map paramMap)
/*     */     throws IOException;
/*     */   
/*     */   public abstract JMXServiceURL bindServer(Object paramObject, JMXServiceURL paramJMXServiceURL, Map paramMap)
/*     */     throws IOException;
/*     */   
/*     */   public abstract void unbindServer(Object paramObject, JMXServiceURL paramJMXServiceURL, Map paramMap)
/*     */     throws IOException;
/*     */   
/*     */   public abstract void destroyServer(Object paramObject, JMXServiceURL paramJMXServiceURL, Map paramMap)
/*     */     throws IOException;
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/ConnectionResolver.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */