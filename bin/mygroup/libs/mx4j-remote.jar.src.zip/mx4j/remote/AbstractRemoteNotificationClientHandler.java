/*     */ package mx4j.remote;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.remote.NotificationResult;
/*     */ import javax.management.remote.TargetedNotification;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRemoteNotificationClientHandler
/*     */   implements RemoteNotificationClientHandler
/*     */ {
/*     */   private static int fetcherID;
/*     */   private static int delivererID;
/*     */   private final ConnectionNotificationEmitter emitter;
/*     */   private final HeartBeat heartbeat;
/*  40 */   private final Map tuples = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private NotificationFetcherThread fetcherThread;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private NotificationDelivererThread delivererThread;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractRemoteNotificationClientHandler(ConnectionNotificationEmitter emitter, HeartBeat heartbeat, Map environment)
/*     */   {
/*  61 */     this.emitter = emitter;
/*  62 */     this.heartbeat = heartbeat;
/*  63 */     this.fetcherThread = new NotificationFetcherThread(environment, null);
/*  64 */     this.delivererThread = new NotificationDelivererThread(environment, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActive()
/*     */   {
/*  75 */     return this.fetcherThread.isActive();
/*     */   }
/*     */   
/*     */   public void start()
/*     */   {
/*  80 */     if (isActive()) return;
/*  81 */     this.delivererThread.start();
/*  82 */     this.fetcherThread.start();
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/*  87 */     if (!isActive()) return;
/*  88 */     this.fetcherThread.stop();
/*  89 */     this.delivererThread.stop();
/*  90 */     synchronized (this.tuples)
/*     */     {
/*  92 */       this.tuples.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   private static synchronized int getFetcherID()
/*     */   {
/*  98 */     return ++fetcherID;
/*     */   }
/*     */   
/*     */   private static synchronized int getDelivererID()
/*     */   {
/* 103 */     return ++delivererID;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean contains(NotificationTuple tuple)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 8	mx4j/remote/AbstractRemoteNotificationClientHandler:tuples	Ljava/util/Map;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 8	mx4j/remote/AbstractRemoteNotificationClientHandler:tuples	Ljava/util/Map;
/*     */     //   11: aload_1
/*     */     //   12: invokeinterface 26 2 0
/*     */     //   17: aload_2
/*     */     //   18: monitorexit
/*     */     //   19: ireturn
/*     */     //   20: astore_3
/*     */     //   21: aload_2
/*     */     //   22: monitorexit
/*     */     //   23: aload_3
/*     */     //   24: athrow
/*     */     // Line number table:
/*     */     //   Java source line #108	-> byte code offset #0
/*     */     //   Java source line #110	-> byte code offset #7
/*     */     //   Java source line #111	-> byte code offset #20
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	25	0	this	AbstractRemoteNotificationClientHandler
/*     */     //   0	25	1	tuple	NotificationTuple
/*     */     //   5	17	2	Ljava/lang/Object;	Object
/*     */     //   20	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	19	20	finally
/*     */     //   20	23	20	finally
/*     */   }
/*     */   
/*     */   public void addNotificationListener(Integer id, NotificationTuple tuple)
/*     */   {
/* 116 */     if (!isActive()) { start();
/*     */     }
/* 118 */     synchronized (this.tuples)
/*     */     {
/* 120 */       this.tuples.put(id, tuple);
/*     */     }
/*     */     
/* 123 */     Logger logger = getLogger();
/* 124 */     if (logger.isEnabledFor(10)) logger.debug("Adding remote NotificationListener " + tuple);
/*     */   }
/*     */   
/*     */   public Integer[] getNotificationListeners(NotificationTuple tuple)
/*     */   {
/* 129 */     synchronized (this.tuples)
/*     */     {
/* 131 */       ArrayList ids = new ArrayList();
/* 132 */       for (Iterator i = this.tuples.entrySet().iterator(); i.hasNext();)
/*     */       {
/* 134 */         Map.Entry entry = (Map.Entry)i.next();
/* 135 */         if (entry.getValue().equals(tuple)) ids.add(entry.getKey());
/*     */       }
/* 137 */       if (ids.size() > 0) return (Integer[])ids.toArray(new Integer[ids.size()]);
/*     */     }
/* 139 */     return null;
/*     */   }
/*     */   
/*     */   public Integer getNotificationListener(NotificationTuple tuple) {
/*     */     Iterator i;
/* 144 */     synchronized (this.tuples)
/*     */     {
/* 146 */       for (i = this.tuples.entrySet().iterator(); i.hasNext();)
/*     */       {
/* 148 */         Map.Entry entry = (Map.Entry)i.next();
/* 149 */         if (entry.getValue().equals(tuple)) return (Integer)entry.getKey();
/*     */       }
/*     */     }
/* 152 */     return null;
/*     */   }
/*     */   
/*     */   public void removeNotificationListeners(Integer[] ids)
/*     */   {
/* 157 */     Logger logger = getLogger();
/* 158 */     synchronized (this.tuples)
/*     */     {
/* 160 */       for (int i = 0; i < ids.length; i++)
/*     */       {
/* 162 */         Integer id = ids[i];
/* 163 */         NotificationTuple tuple = (NotificationTuple)this.tuples.remove(id);
/* 164 */         if ((tuple != null) && (logger.isEnabledFor(10))) { logger.debug("Removing remote NotificationListener " + tuple);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract NotificationResult fetchNotifications(long paramLong1, int paramInt, long paramLong2)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected long getRetryPeriod()
/*     */   {
/* 183 */     return this.heartbeat.getPulsePeriod();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getMaxRetries()
/*     */   {
/* 196 */     return this.heartbeat.getMaxRetries();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendConnectionNotificationLost(long number)
/*     */   {
/* 205 */     this.emitter.sendConnectionNotificationLost(number);
/*     */   }
/*     */   
/*     */   protected int getNotificationsCount()
/*     */   {
/* 210 */     return this.delivererThread.getNotificationsCount();
/*     */   }
/*     */   
/*     */   private int deliverNotifications(TargetedNotification[] notifications)
/*     */   {
/* 215 */     return this.delivererThread.addNotifications(notifications);
/*     */   }
/*     */   
/*     */   private void sendNotification(TargetedNotification notification)
/*     */   {
/* 220 */     NotificationTuple tuple = null;
/* 221 */     synchronized (this.tuples)
/*     */     {
/* 223 */       tuple = (NotificationTuple)this.tuples.get(notification.getListenerID());
/*     */     }
/*     */     
/*     */ 
/* 227 */     if (tuple == null) { return;
/*     */     }
/* 229 */     Notification notif = notification.getNotification();
/*     */     
/* 231 */     Logger logger = getLogger();
/*     */     
/* 233 */     if (tuple.getInvokeFilter())
/*     */     {
/*     */ 
/* 236 */       NotificationFilter filter = tuple.getNotificationFilter();
/* 237 */       if (logger.isEnabledFor(10)) logger.debug("Filtering notification " + notif + ", filter = " + filter);
/* 238 */       if (filter != null)
/*     */       {
/*     */         try
/*     */         {
/* 242 */           boolean deliver = filter.isNotificationEnabled(notif);
/* 243 */           if (!deliver) return;
/*     */         }
/*     */         catch (Throwable x)
/*     */         {
/* 247 */           logger.warn("Throwable caught from isNotificationEnabled, filter = " + filter, x);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 253 */     if (logger.isEnabledFor(10)) { logger.debug("Sending Notification " + notif + ", listener info is " + tuple);
/*     */     }
/* 255 */     NotificationListener listener = tuple.getNotificationListener();
/*     */     
/*     */     try
/*     */     {
/* 259 */       listener.handleNotification(notif, tuple.getHandback());
/*     */     }
/*     */     catch (Throwable x)
/*     */     {
/* 263 */       logger.warn("Throwable caught from handleNotification, listener = " + listener, x);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 270 */   protected Logger getLogger() { return Log.getLogger(getClass().getName()); }
/*     */   
/*     */   private class NotificationFetcherThread implements Runnable {
/* 273 */     NotificationFetcherThread(Map x1, AbstractRemoteNotificationClientHandler.1 x2) { this(x1); }
/*     */     
/*     */ 
/*     */     private long sequenceNumber;
/*     */     
/*     */     private volatile boolean active;
/*     */     private Thread thread;
/*     */     private long timeout;
/*     */     private int maxNumber;
/*     */     private long sleep;
/*     */     private NotificationFetcherThread(Map environment)
/*     */     {
/* 285 */       this.timeout = 60000L;
/*     */       
/* 287 */       this.maxNumber = 25;
/*     */       
/* 289 */       this.sleep = 0L;
/* 290 */       if (environment != null)
/*     */       {
/*     */         try
/*     */         {
/* 294 */           this.timeout = ((Long)environment.get("jmx.remote.x.client.fetch.timeout")).longValue();
/*     */         }
/*     */         catch (Exception ignored) {}
/*     */         
/*     */ 
/*     */         try
/*     */         {
/* 301 */           this.maxNumber = ((Integer)environment.get("jmx.remote.x.client.max.notifications")).intValue();
/*     */         }
/*     */         catch (Exception ignored) {}
/*     */         
/*     */ 
/*     */         try
/*     */         {
/* 308 */           this.sleep = ((Integer)environment.get("jmx.remote.x.notification.fetch.sleep")).intValue();
/*     */         }
/*     */         catch (Exception ignored) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private synchronized long getSequenceNumber()
/*     */     {
/* 318 */       return this.sequenceNumber;
/*     */     }
/*     */     
/*     */     private synchronized void setSequenceNumber(long sequenceNumber)
/*     */     {
/* 323 */       this.sequenceNumber = sequenceNumber;
/*     */     }
/*     */     
/*     */     private boolean isActive()
/*     */     {
/* 328 */       return this.active;
/*     */     }
/*     */     
/*     */     private synchronized void start()
/*     */     {
/* 333 */       this.active = true;
/*     */       
/* 335 */       this.sequenceNumber = -1L;
/* 336 */       this.thread = new Thread(this, "Notification Fetcher #" + AbstractRemoteNotificationClientHandler.access$900());
/* 337 */       this.thread.setDaemon(true);
/* 338 */       this.thread.start();
/*     */     }
/*     */     
/*     */     private synchronized void stop()
/*     */     {
/* 343 */       this.active = false;
/* 344 */       this.thread.interrupt();
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 349 */       Logger logger = AbstractRemoteNotificationClientHandler.this.getLogger();
/*     */       try
/*     */       {
/* 352 */         while ((isActive()) && (!this.thread.isInterrupted()))
/*     */         {
/*     */           try
/*     */           {
/* 356 */             long sequence = getSequenceNumber();
/* 357 */             NotificationResult result = fetchNotifications(sequence, this.maxNumber, this.timeout);
/* 358 */             if (logger.isEnabledFor(10)) { logger.debug("Fetched Notifications: " + result);
/*     */             }
/* 360 */             long sleepTime = this.sleep;
/* 361 */             if (result != null)
/*     */             {
/* 363 */               long nextSequence = result.getNextSequenceNumber();
/* 364 */               TargetedNotification[] targeted = result.getTargetedNotifications();
/* 365 */               int targetedLength = targeted == null ? 0 : targeted.length;
/* 366 */               boolean notifsFilteredByServer = nextSequence - sequence != targetedLength;
/* 367 */               boolean notifsLostByServer = (sequence >= 0L) && (result.getEarliestSequenceNumber() > sequence);
/* 368 */               if (notifsFilteredByServer)
/*     */               {
/*     */ 
/* 371 */                 AbstractRemoteNotificationClientHandler.this.sendConnectionNotificationLost(nextSequence - sequence - targetedLength);
/*     */               }
/* 373 */               if (notifsLostByServer)
/*     */               {
/*     */ 
/* 376 */                 AbstractRemoteNotificationClientHandler.this.sendConnectionNotificationLost(result.getEarliestSequenceNumber() - sequence);
/*     */               }
/*     */               
/* 379 */               setSequenceNumber(nextSequence);
/* 380 */               int delivered = AbstractRemoteNotificationClientHandler.this.deliverNotifications(targeted);
/* 381 */               if (delivered < targetedLength)
/*     */               {
/*     */ 
/* 384 */                 AbstractRemoteNotificationClientHandler.this.sendConnectionNotificationLost(targetedLength - delivered);
/*     */               }
/*     */               
/*     */ 
/* 388 */               if ((targeted != null) && (targeted.length == this.maxNumber)) { sleepTime = 0L;
/*     */               }
/*     */             }
/* 391 */             if (sleepTime > 0L) Thread.sleep(sleepTime);
/*     */           }
/*     */           catch (IOException x)
/*     */           {
/* 395 */             if (logger.isEnabledFor(10)) logger.debug("Caught IOException from fetchNotifications", x);
/* 396 */             break;
/*     */           }
/*     */           catch (InterruptedException x)
/*     */           {
/* 400 */             Thread.currentThread().interrupt();
/* 401 */             break;
/*     */           }
/*     */           catch (Throwable x)
/*     */           {
/* 405 */             if (logger.isEnabledFor(30)) logger.warn("Caught an unexpected exception", x);
/*     */           }
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/* 411 */         AbstractRemoteNotificationClientHandler.this.stop();
/* 412 */         if (logger.isEnabledFor(10)) { logger.debug(this.thread.getName() + " Thread exited");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private NotificationResult fetchNotifications(long sequence, int maxNumber, long timeout)
/*     */       throws IOException, InterruptedException
/*     */     {
/* 425 */       Logger logger = AbstractRemoteNotificationClientHandler.this.getLogger();
/* 426 */       int retries = 0;
/*     */       for (;;)
/*     */       {
/* 429 */         if (logger.isEnabledFor(10)) logger.debug("Fetching notifications, sequence is " + sequence + ", timeout is " + timeout);
/*     */         try
/*     */         {
/* 432 */           return AbstractRemoteNotificationClientHandler.this.fetchNotifications(sequence, maxNumber, timeout);
/*     */         }
/*     */         catch (IOException x)
/*     */         {
/* 436 */           if (logger.isEnabledFor(10)) logger.debug("Could not fetch notifications, sleeping " + AbstractRemoteNotificationClientHandler.this.getRetryPeriod() + " and trying " + (AbstractRemoteNotificationClientHandler.this.getMaxRetries() - retries) + " more times", x);
/* 437 */           Thread.sleep(AbstractRemoteNotificationClientHandler.this.getRetryPeriod());
/* 438 */           if (retries++ == AbstractRemoteNotificationClientHandler.this.getMaxRetries()) throw x;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 444 */   private class NotificationDelivererThread implements Runnable { NotificationDelivererThread(Map x1, AbstractRemoteNotificationClientHandler.1 x2) { this(x1); }
/*     */     
/* 446 */     private final List notificationQueue = new LinkedList();
/*     */     private int capacity;
/*     */     private volatile boolean active;
/*     */     private Thread thread;
/*     */     
/*     */     private NotificationDelivererThread(Map environment)
/*     */     {
/* 453 */       if (environment != null)
/*     */       {
/* 455 */         Object size = environment.get("jmx.remote.x.queue.size");
/* 456 */         if ((size instanceof Integer))
/*     */         {
/* 458 */           this.capacity = ((Integer)size).intValue();
/* 459 */           if (this.capacity < 0) this.capacity = 0;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private int addNotifications(TargetedNotification[] notifications)
/*     */     {
/* 466 */       if ((notifications == null) || (notifications.length == 0)) { return 0;
/*     */       }
/* 468 */       List notifs = Arrays.asList(notifications);
/*     */       
/* 470 */       Logger logger = AbstractRemoteNotificationClientHandler.this.getLogger();
/* 471 */       if (logger.isEnabledFor(10)) { logger.debug("Enqueuing notifications for delivery: " + notifs);
/*     */       }
/* 473 */       synchronized (this)
/*     */       {
/* 475 */         int size = notifs.size();
/* 476 */         int added = size;
/* 477 */         if (this.capacity > 0)
/*     */         {
/* 479 */           int room = this.capacity - this.notificationQueue.size();
/* 480 */           if (room < size)
/*     */           {
/* 482 */             added = room;
/* 483 */             if (logger.isEnabledFor(10)) logger.debug("Notification queue is full, enqueued " + room + " notifications out of " + size + ", exceeding will be lost");
/*     */           }
/* 485 */           this.notificationQueue.addAll(notifs.subList(0, added));
/*     */         }
/*     */         else
/*     */         {
/* 489 */           this.notificationQueue.addAll(notifs);
/*     */         }
/* 491 */         notifyAll();
/* 492 */         return added;
/*     */       }
/*     */     }
/*     */     
/*     */     private boolean isActive()
/*     */     {
/* 498 */       return this.active;
/*     */     }
/*     */     
/*     */     private synchronized void start()
/*     */     {
/* 503 */       this.active = true;
/* 504 */       this.notificationQueue.clear();
/* 505 */       this.thread = new Thread(this, "Notification Deliverer #" + AbstractRemoteNotificationClientHandler.access$1100());
/* 506 */       this.thread.setDaemon(true);
/* 507 */       this.thread.start();
/*     */     }
/*     */     
/*     */     private synchronized void stop()
/*     */     {
/* 512 */       this.active = false;
/* 513 */       this.thread.interrupt();
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 518 */       Logger logger = AbstractRemoteNotificationClientHandler.this.getLogger();
/*     */       try
/*     */       {
/* 521 */         while ((isActive()) && (!this.thread.isInterrupted()))
/*     */         {
/*     */           try
/*     */           {
/* 525 */             TargetedNotification notification = null;
/* 526 */             synchronized (this)
/*     */             {
/* 528 */               while (this.notificationQueue.isEmpty()) wait();
/* 529 */               notification = (TargetedNotification)this.notificationQueue.remove(0);
/*     */             }
/* 531 */             AbstractRemoteNotificationClientHandler.this.sendNotification(notification);
/*     */           }
/*     */           catch (InterruptedException x)
/*     */           {
/* 535 */             Thread.currentThread().interrupt();
/* 536 */             break;
/*     */           }
/*     */           catch (Throwable x)
/*     */           {
/* 540 */             if (logger.isEnabledFor(30)) logger.warn("Caught an unexpected exception", x);
/*     */           }
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/* 546 */         this.active = false;
/* 547 */         if (logger.isEnabledFor(10)) logger.debug(this.thread.getName() + " Thread exited");
/*     */       }
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     private int getNotificationsCount()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: dup
/*     */       //   2: astore_1
/*     */       //   3: monitorenter
/*     */       //   4: aload_0
/*     */       //   5: getfield 10	mx4j/remote/AbstractRemoteNotificationClientHandler$NotificationDelivererThread:notificationQueue	Ljava/util/List;
/*     */       //   8: invokeinterface 26 1 0
/*     */       //   13: aload_1
/*     */       //   14: monitorexit
/*     */       //   15: ireturn
/*     */       //   16: astore_2
/*     */       //   17: aload_1
/*     */       //   18: monitorexit
/*     */       //   19: aload_2
/*     */       //   20: athrow
/*     */       // Line number table:
/*     */       //   Java source line #553	-> byte code offset #0
/*     */       //   Java source line #555	-> byte code offset #4
/*     */       //   Java source line #556	-> byte code offset #16
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	21	0	this	NotificationDelivererThread
/*     */       //   2	16	1	Ljava/lang/Object;	Object
/*     */       //   16	4	2	localObject1	Object
/*     */       // Exception table:
/*     */       //   from	to	target	type
/*     */       //   4	15	16	finally
/*     */       //   16	19	16	finally
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/AbstractRemoteNotificationClientHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */