/*     */ package mx4j.remote.resolver.iiop;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import javax.management.remote.rmi.RMIIIOPServerImpl;
/*     */ import javax.management.remote.rmi.RMIServer;
/*     */ import javax.management.remote.rmi.RMIServerImpl;
/*     */ import javax.rmi.CORBA.Stub;
/*     */ import javax.rmi.PortableRemoteObject;
/*     */ import mx4j.remote.resolver.rmi.RMIResolver;
/*     */ import org.omg.CORBA.BAD_OPERATION;
/*     */ import org.omg.CORBA.ORB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IIOPResolver
/*     */   extends RMIResolver
/*     */ {
/*     */   private static final String IOR_CONTEXT = "/ior/";
/*     */   private ORB orb;
/*     */   
/*     */   protected RMIServer decodeStub(JMXServiceURL url, Map environment)
/*     */     throws IOException
/*     */   {
/*  43 */     String path = url.getURLPath();
/*  44 */     String ior = "/ior/";
/*  45 */     if (path.startsWith(ior))
/*     */     {
/*  47 */       String encoded = path.substring(ior.length());
/*  48 */       ORB orb = getORB(environment);
/*  49 */       Object object = orb.string_to_object(encoded);
/*  50 */       return narrowRMIServerStub(object);
/*     */     }
/*  52 */     throw new MalformedURLException("Unsupported binding: " + url);
/*     */   }
/*     */   
/*     */   protected RMIServer narrowRMIServerStub(Object stub)
/*     */   {
/*  57 */     return (RMIServer)PortableRemoteObject.narrow(stub, RMIServer.class);
/*     */   }
/*     */   
/*     */   public Object bindClient(Object client, Map environment) throws IOException
/*     */   {
/*  62 */     Stub stub = (Stub)client;
/*  63 */     ORB orb = null;
/*     */     try
/*     */     {
/*  66 */       orb = stub._orb();
/*     */     }
/*     */     catch (BAD_OPERATION x) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  73 */     if (orb == null)
/*     */     {
/*  75 */       orb = getORB(environment);
/*  76 */       stub.connect(orb);
/*     */     }
/*  78 */     return stub;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RMIServerImpl createRMIServer(JMXServiceURL url, Map environment)
/*     */     throws IOException
/*     */   {
/*  87 */     return new RMIIIOPServerImpl(environment);
/*     */   }
/*     */   
/*     */   public JMXServiceURL bindServer(Object server, JMXServiceURL url, Map environment) throws IOException
/*     */   {
/*  92 */     RMIServerImpl rmiServer = (RMIServerImpl)server;
/*  93 */     Stub stub = (Stub)PortableRemoteObject.toStub(rmiServer);
/*  94 */     stub.connect(getORB(environment));
/*  95 */     return super.bindServer(server, url, environment);
/*     */   }
/*     */   
/*     */   protected String encodeStub(RMIServerImpl rmiServer, Map environment) throws IOException
/*     */   {
/* 100 */     Stub stub = (Stub)bindClient(rmiServer.toStub(), environment);
/* 101 */     String ior = getORB(environment).object_to_string(stub);
/* 102 */     return "/ior/" + ior;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized ORB getORB(Map environment)
/*     */   {
/* 111 */     if (this.orb == null)
/*     */     {
/* 113 */       Properties props = new Properties();
/*     */       
/* 115 */       for (Iterator i = environment.entrySet().iterator(); i.hasNext();)
/*     */       {
/* 117 */         Map.Entry entry = (Map.Entry)i.next();
/* 118 */         Object key = entry.getKey();
/* 119 */         Object value = entry.getValue();
/* 120 */         if (((key instanceof String)) && ((value instanceof String)))
/*     */         {
/* 122 */           props.setProperty((String)key, (String)value);
/*     */         }
/*     */       }
/* 125 */       this.orb = ORB.init((String[])null, props);
/*     */     }
/* 127 */     return this.orb;
/*     */   }
/*     */   
/*     */   protected boolean isEncodedForm(JMXServiceURL url)
/*     */   {
/* 132 */     String path = url.getURLPath();
/* 133 */     if ((path != null) && (path.startsWith("/ior/"))) return true;
/* 134 */     return super.isEncodedForm(url);
/*     */   }
/*     */   
/*     */   public void destroyServer(Object server, JMXServiceURL url, Map environment) throws IOException
/*     */   {
/* 139 */     if (!isEncodedForm(url)) return;
/* 140 */     if (this.orb != null)
/*     */     {
/* 142 */       this.orb.shutdown(true);
/* 143 */       this.orb.destroy();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/resolver/iiop/IIOPResolver.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */