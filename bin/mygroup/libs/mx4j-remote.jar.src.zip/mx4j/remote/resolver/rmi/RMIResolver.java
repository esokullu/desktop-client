/*     */ package mx4j.remote.resolver.rmi;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.rmi.Remote;
/*     */ import java.rmi.server.RMIClientSocketFactory;
/*     */ import java.rmi.server.RMIServerSocketFactory;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import javax.management.remote.rmi.RMIJRMPServerImpl;
/*     */ import javax.management.remote.rmi.RMIServer;
/*     */ import javax.management.remote.rmi.RMIServerImpl;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import mx4j.log.Logger;
/*     */ import mx4j.remote.ConnectionResolver;
/*     */ import mx4j.util.Base64Codec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RMIResolver
/*     */   extends ConnectionResolver
/*     */ {
/*     */   private static final String JNDI_CONTEXT = "/jndi/";
/*     */   private static final String STUB_CONTEXT = "/stub/";
/*     */   
/*     */   public Object lookupClient(JMXServiceURL url, Map environment)
/*     */     throws IOException
/*     */   {
/*  51 */     return lookupRMIServerStub(url, environment);
/*     */   }
/*     */   
/*     */   public Object bindClient(Object client, Map environment)
/*     */     throws IOException
/*     */   {
/*  57 */     return client;
/*     */   }
/*     */   
/*     */   protected RMIServer lookupRMIServerStub(JMXServiceURL url, Map environment) throws IOException
/*     */   {
/*  62 */     Logger logger = getLogger();
/*     */     
/*  64 */     String path = url.getURLPath();
/*  65 */     if (logger.isEnabledFor(10)) { logger.debug("JMXServiceURL for lookup is: '" + url + "'");
/*     */     }
/*  67 */     if (path != null)
/*     */     {
/*  69 */       if (path.startsWith("/jndi/"))
/*     */       {
/*  71 */         return lookupStubInJNDI(url, environment);
/*     */       }
/*     */       
/*  74 */       return decodeStub(url, environment);
/*     */     }
/*     */     
/*  77 */     throw new MalformedURLException("Unsupported lookup " + url);
/*     */   }
/*     */   
/*     */   private RMIServer lookupStubInJNDI(JMXServiceURL url, Map environment) throws IOException
/*     */   {
/*  82 */     Logger logger = getLogger();
/*     */     
/*  84 */     String path = url.getURLPath();
/*  85 */     String name = path.substring("/jndi/".length());
/*  86 */     if (logger.isEnabledFor(10)) { logger.debug("Looking up RMI stub in JNDI under name " + name);
/*     */     }
/*  88 */     InitialContext ctx = null;
/*     */     try
/*     */     {
/*  91 */       ctx = new InitialContext(new Hashtable(environment));
/*  92 */       Object stub = ctx.lookup(name);
/*  93 */       if (logger.isEnabledFor(10)) logger.debug("Found RMI stub in JNDI " + stub);
/*  94 */       return narrowRMIServerStub(stub);
/*     */     }
/*     */     catch (NamingException x)
/*     */     {
/*  98 */       if (logger.isEnabledFor(10)) logger.debug("Cannot lookup RMI stub in JNDI", x);
/*  99 */       throw new IOException(x.toString());
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 105 */         if (ctx != null) ctx.close();
/*     */       }
/*     */       catch (NamingException x)
/*     */       {
/* 109 */         if (logger.isEnabledFor(10)) logger.debug("Cannot close InitialContext", x);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected RMIServer narrowRMIServerStub(Object stub)
/*     */   {
/* 116 */     return (RMIServer)stub;
/*     */   }
/*     */   
/*     */   protected RMIServer decodeStub(JMXServiceURL url, Map environment) throws IOException
/*     */   {
/* 121 */     String path = url.getURLPath();
/* 122 */     if (path.startsWith("/stub/"))
/*     */     {
/* 124 */       byte[] encoded = path.substring("/stub/".length()).getBytes();
/* 125 */       if (!Base64Codec.isArrayByteBase64(encoded)) throw new IOException("Encoded stub form is not a valid Base64 sequence: " + url);
/* 126 */       byte[] decoded = Base64Codec.decodeBase64(encoded);
/* 127 */       ByteArrayInputStream bais = new ByteArrayInputStream(decoded);
/* 128 */       ObjectInputStream ois = null;
/*     */       try
/*     */       {
/* 131 */         ois = new ObjectInputStream(bais);
/* 132 */         return (RMIServer)ois.readObject();
/*     */       }
/*     */       catch (ClassNotFoundException x)
/*     */       {
/* 136 */         throw new IOException("Cannot decode stub from " + url + ": " + x);
/*     */       }
/*     */       finally
/*     */       {
/* 140 */         if (ois != null) ois.close();
/*     */       }
/*     */     }
/* 143 */     throw new MalformedURLException("Unsupported binding: " + url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object createServer(JMXServiceURL url, Map environment)
/*     */     throws IOException
/*     */   {
/* 153 */     return createRMIServer(url, environment);
/*     */   }
/*     */   
/*     */   protected RMIServerImpl createRMIServer(JMXServiceURL url, Map environment) throws IOException
/*     */   {
/* 158 */     int port = url.getPort();
/* 159 */     RMIClientSocketFactory clientFactory = (RMIClientSocketFactory)environment.get("jmx.remote.rmi.client.socket.factory");
/* 160 */     RMIServerSocketFactory serverFactory = (RMIServerSocketFactory)environment.get("jmx.remote.rmi.server.socket.factory");
/* 161 */     return new RMIJRMPServerImpl(port, clientFactory, serverFactory, environment);
/*     */   }
/*     */   
/*     */ 
/*     */   public JMXServiceURL bindServer(Object server, JMXServiceURL url, Map environment)
/*     */     throws IOException
/*     */   {
/* 168 */     RMIServerImpl rmiServer = (RMIServerImpl)server;
/*     */     
/* 170 */     Logger logger = getLogger();
/* 171 */     if (logger.isEnabledFor(10)) { logger.debug("JMXServiceURL for binding is: '" + url + "'");
/*     */     }
/* 173 */     if (isEncodedForm(url))
/*     */     {
/* 175 */       String path = encodeStub(rmiServer, environment);
/* 176 */       return new JMXServiceURL(url.getProtocol(), url.getHost(), url.getPort(), path);
/*     */     }
/*     */     
/*     */ 
/* 180 */     String jndiURL = parseJNDIForm(url);
/* 181 */     if (logger.isEnabledFor(10)) { logger.debug("JMXServiceURL path for binding is: '" + jndiURL + "'");
/*     */     }
/* 183 */     InitialContext ctx = null;
/*     */     try
/*     */     {
/* 186 */       ctx = new InitialContext(new Hashtable(environment));
/* 187 */       boolean rebind = Boolean.valueOf((String)environment.get("jmx.remote.jndi.rebind")).booleanValue();
/* 188 */       if (rebind) {
/* 189 */         ctx.rebind(jndiURL, rmiServer.toStub());
/*     */       } else
/* 191 */         ctx.bind(jndiURL, rmiServer.toStub());
/* 192 */       if (logger.isEnabledFor(10)) logger.debug("Bound " + rmiServer + " to " + jndiURL);
/* 193 */       return url;
/*     */     }
/*     */     catch (NamingException x)
/*     */     {
/* 197 */       if (logger.isEnabledFor(10)) logger.debug("Cannot bind server " + rmiServer + " to " + jndiURL, x);
/* 198 */       throw new IOException(x.toString());
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 204 */         if (ctx != null) ctx.close();
/*     */       }
/*     */       catch (NamingException x)
/*     */       {
/* 208 */         if (logger.isEnabledFor(10)) logger.debug("Cannot close InitialContext", x);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected String encodeStub(RMIServerImpl rmiServer, Map environment)
/*     */     throws IOException
/*     */   {
/* 216 */     Remote stub = rmiServer.toStub();
/* 217 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 218 */     ObjectOutputStream oos = null;
/*     */     try
/*     */     {
/* 221 */       oos = new ObjectOutputStream(baos);
/* 222 */       oos.writeObject(stub);
/*     */     }
/*     */     finally
/*     */     {
/* 226 */       if (oos != null) oos.close();
/*     */     }
/* 228 */     byte[] bytes = baos.toByteArray();
/* 229 */     byte[] encoded = Base64Codec.encodeBase64(bytes);
/*     */     
/* 231 */     return "/stub/" + new String(encoded);
/*     */   }
/*     */   
/*     */   protected boolean isEncodedForm(JMXServiceURL url)
/*     */   {
/* 236 */     String path = url.getURLPath();
/* 237 */     if ((path == null) || (path.length() == 0) || (path.equals("/")) || (path.startsWith("/stub/"))) return true;
/* 238 */     return false;
/*     */   }
/*     */   
/*     */   private String parseJNDIForm(JMXServiceURL url) throws MalformedURLException
/*     */   {
/* 243 */     String path = url.getURLPath();
/* 244 */     if (path.startsWith("/jndi/"))
/*     */     {
/* 246 */       String jndiURL = path.substring("/jndi/".length());
/* 247 */       if ((jndiURL == null) || (jndiURL.length() == 0)) throw new MalformedURLException("No JNDI URL specified: " + url);
/* 248 */       return jndiURL;
/*     */     }
/* 250 */     throw new MalformedURLException("Unsupported binding: " + url);
/*     */   }
/*     */   
/*     */   public void unbindServer(Object server, JMXServiceURL url, Map environment) throws IOException
/*     */   {
/* 255 */     Logger logger = getLogger();
/* 256 */     if (logger.isEnabledFor(10)) { logger.debug("JMXServiceURL for unbinding is: '" + url + "'");
/*     */     }
/*     */     
/* 259 */     if (isEncodedForm(url))
/*     */     {
/* 261 */       return;
/*     */     }
/*     */     
/*     */ 
/* 265 */     String jndiURL = parseJNDIForm(url);
/* 266 */     if (logger.isEnabledFor(10)) { logger.debug("JMXServiceURL path for binding is: '" + jndiURL + "'");
/*     */     }
/* 268 */     InitialContext ctx = null;
/*     */     try
/*     */     {
/* 271 */       ctx = new InitialContext(new Hashtable(environment));
/* 272 */       ctx.unbind(jndiURL);
/* 273 */       if (logger.isEnabledFor(10)) logger.debug("Unbound " + server + " from " + jndiURL);
/*     */     }
/*     */     catch (NamingException x)
/*     */     {
/* 277 */       if (logger.isEnabledFor(10)) logger.debug("Cannot unbind server " + server + " to " + jndiURL, x);
/* 278 */       throw new IOException(x.toString());
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 284 */         if (ctx != null) ctx.close();
/*     */       }
/*     */       catch (NamingException x)
/*     */       {
/* 288 */         if (logger.isEnabledFor(10)) logger.debug("Cannot close InitialContext", x);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void destroyServer(Object server, JMXServiceURL url, Map environment)
/*     */     throws IOException
/*     */   {}
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/resolver/rmi/RMIResolver.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */