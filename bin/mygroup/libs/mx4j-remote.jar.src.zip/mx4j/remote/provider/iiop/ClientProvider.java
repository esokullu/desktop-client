package mx4j.remote.provider.iiop;

import mx4j.remote.provider.RMIClientProvider;

public class ClientProvider
  extends RMIClientProvider
{}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/provider/iiop/ClientProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */