package mx4j.remote.provider.iiop;

import mx4j.remote.provider.RMIServerProvider;

public class ServerProvider
  extends RMIServerProvider
{}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/provider/iiop/ServerProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */