/*    */ package mx4j.remote.provider;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.management.remote.JMXConnector;
/*    */ import javax.management.remote.JMXConnectorProvider;
/*    */ import javax.management.remote.JMXServiceURL;
/*    */ import javax.management.remote.rmi.RMIConnector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RMIClientProvider
/*    */   implements JMXConnectorProvider
/*    */ {
/*    */   public JMXConnector newJMXConnector(JMXServiceURL url, Map environment)
/*    */     throws IOException
/*    */   {
/* 25 */     return new RMIConnector(url, environment);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/provider/RMIClientProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */