/*    */ package mx4j.remote.provider;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.management.MBeanServer;
/*    */ import javax.management.remote.JMXConnectorServer;
/*    */ import javax.management.remote.JMXConnectorServerProvider;
/*    */ import javax.management.remote.JMXServiceURL;
/*    */ import javax.management.remote.rmi.RMIConnectorServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RMIServerProvider
/*    */   implements JMXConnectorServerProvider
/*    */ {
/*    */   public JMXConnectorServer newJMXConnectorServer(JMXServiceURL url, Map environment, MBeanServer server)
/*    */     throws IOException
/*    */   {
/* 26 */     return new RMIConnectorServer(url, environment, server);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/provider/RMIServerProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */