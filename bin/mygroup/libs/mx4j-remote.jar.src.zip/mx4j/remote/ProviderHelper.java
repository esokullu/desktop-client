/*    */ package mx4j.remote;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ import java.security.PrivilegedAction;
/*    */ import mx4j.log.Log;
/*    */ import mx4j.log.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ProviderHelper
/*    */ {
/*    */   protected static String normalizeProtocol(String protocol)
/*    */   {
/* 25 */     String normalized = protocol.replace('+', '.');
/* 26 */     normalized = normalized.replace('-', '_');
/* 27 */     Logger logger = getLogger();
/* 28 */     if (logger.isEnabledFor(0)) logger.trace("Normalizing protocol: " + protocol + " --> " + normalized);
/* 29 */     return normalized;
/*    */   }
/*    */   
/*    */   protected static String findSystemPackageList(String key)
/*    */   {
/* 34 */     Logger logger = getLogger();
/* 35 */     String providerPackages = (String)AccessController.doPrivileged(new PrivilegedAction() {
/*    */       private final String val$key;
/*    */       
/*    */       public Object run() {
/* 39 */         return System.getProperty(this.val$key);
/*    */       }
/*    */     });
/* 42 */     if (logger.isEnabledFor(10)) logger.debug("Packages in the system property '" + key + "': " + providerPackages);
/* 43 */     return providerPackages;
/*    */   }
/*    */   
/*    */   protected static Class loadClass(String className, ClassLoader loader) throws ClassNotFoundException
/*    */   {
/* 48 */     Logger logger = getLogger();
/* 49 */     if (logger.isEnabledFor(10)) logger.debug("Loading class: " + className + " with classloader " + loader);
/* 50 */     return loader.loadClass(className);
/*    */   }
/*    */   
/*    */   protected static String constructClassName(String packageName, String protocol, String className)
/*    */   {
/* 55 */     return packageName + "." + protocol + "." + className;
/*    */   }
/*    */   
/*    */   protected static Logger getLogger()
/*    */   {
/* 60 */     return Log.getLogger(ProviderHelper.class.getName());
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/ProviderHelper.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */