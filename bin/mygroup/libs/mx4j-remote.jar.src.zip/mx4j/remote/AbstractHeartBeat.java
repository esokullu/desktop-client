/*     */ package mx4j.remote;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHeartBeat
/*     */   implements HeartBeat, Runnable
/*     */ {
/*     */   private final ConnectionNotificationEmitter emitter;
/*     */   private long pulsePeriod;
/*     */   private int maxRetries;
/*     */   private Thread thread;
/*     */   private volatile boolean stopped;
/*     */   
/*     */   protected AbstractHeartBeat(ConnectionNotificationEmitter emitter, Map environment)
/*     */   {
/*  38 */     this.emitter = emitter;
/*  39 */     if (environment != null)
/*     */     {
/*     */       try
/*     */       {
/*  43 */         this.pulsePeriod = ((Long)environment.get("jmx.remote.x.connection.heartbeat.period")).longValue();
/*     */       }
/*     */       catch (Exception ignored) {}
/*     */       
/*     */ 
/*     */       try
/*     */       {
/*  50 */         this.maxRetries = ((Integer)environment.get("jmx.remote.x.connection.heartbeat.retries")).intValue();
/*     */       }
/*     */       catch (Exception ignored) {}
/*     */     }
/*     */     
/*     */ 
/*  56 */     if (this.pulsePeriod <= 0L) this.pulsePeriod = 5000L;
/*  57 */     if (this.maxRetries <= 0) this.maxRetries = 3;
/*     */   }
/*     */   
/*     */   public long getPulsePeriod()
/*     */   {
/*  62 */     return this.pulsePeriod;
/*     */   }
/*     */   
/*     */   public int getMaxRetries()
/*     */   {
/*  67 */     return this.maxRetries;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract void pulse()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */   public void start()
/*     */     throws IOException
/*     */   {
/*  79 */     this.thread = new Thread(this, "Connection HeartBeat");
/*  80 */     this.thread.setDaemon(true);
/*  81 */     this.thread.start();
/*     */   }
/*     */   
/*     */   public void stop() throws IOException
/*     */   {
/*  86 */     if (this.stopped) return;
/*  87 */     this.stopped = true;
/*  88 */     this.thread.interrupt();
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/*  95 */       int retries = 0;
/*  96 */       while ((!this.stopped) && (!this.thread.isInterrupted()))
/*     */       {
/*     */         try
/*     */         {
/* 100 */           Thread.sleep(this.pulsePeriod);
/*     */           
/*     */           try
/*     */           {
/* 104 */             pulse();
/* 105 */             retries = 0;
/*     */           }
/*     */           catch (IOException x)
/*     */           {
/* 109 */             if (retries++ == this.maxRetries)
/*     */             {
/*     */ 
/* 112 */               sendConnectionNotificationFailed();
/* 113 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (InterruptedException x)
/*     */         {
/* 119 */           Thread.currentThread().interrupt();
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 125 */       this.stopped = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendConnectionNotificationFailed()
/*     */   {
/* 135 */     this.emitter.sendConnectionNotificationFailed();
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/AbstractHeartBeat.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */