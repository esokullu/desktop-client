/*    */ package mx4j.remote.rmi;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Proxy;
/*    */ import java.security.AccessController;
/*    */ import java.security.PrivilegedAction;
/*    */ import javax.management.MBeanServerConnection;
/*    */ import mx4j.remote.ClientProxy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientUnmarshaller
/*    */   extends ClientProxy
/*    */ {
/*    */   private final ClassLoader classLoader;
/*    */   
/*    */   private ClientUnmarshaller(MBeanServerConnection target, ClassLoader loader)
/*    */   {
/* 32 */     super(target);
/* 33 */     this.classLoader = loader;
/*    */   }
/*    */   
/*    */   public static MBeanServerConnection newInstance(MBeanServerConnection target, ClassLoader loader)
/*    */   {
/* 38 */     ClientUnmarshaller handler = new ClientUnmarshaller(target, loader);
/* 39 */     return (MBeanServerConnection)Proxy.newProxyInstance(handler.getClass().getClassLoader(), new Class[] { MBeanServerConnection.class }, handler);
/*    */   }
/*    */   
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*    */   {
/* 44 */     if (this.classLoader == null)
/*    */     {
/* 46 */       return chain(proxy, method, args);
/*    */     }
/*    */     
/*    */ 
/* 50 */     ClassLoader old = Thread.currentThread().getContextClassLoader();
/*    */     try
/*    */     {
/* 53 */       setContextClassLoader(this.classLoader);
/* 54 */       return chain(proxy, method, args);
/*    */     }
/*    */     finally
/*    */     {
/* 58 */       setContextClassLoader(old);
/*    */     }
/*    */   }
/*    */   
/*    */   private Object chain(Object proxy, Method method, Object[] args)
/*    */     throws Throwable
/*    */   {
/* 65 */     return super.invoke(proxy, method, args);
/*    */   }
/*    */   
/*    */   private void setContextClassLoader(ClassLoader loader)
/*    */   {
/* 70 */     AccessController.doPrivileged(new PrivilegedAction() {
/*    */       private final ClassLoader val$loader;
/*    */       
/*    */       public Object run() {
/* 74 */         Thread.currentThread().setContextClassLoader(this.val$loader);
/* 75 */         return null;
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/rmi/ClientUnmarshaller.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */