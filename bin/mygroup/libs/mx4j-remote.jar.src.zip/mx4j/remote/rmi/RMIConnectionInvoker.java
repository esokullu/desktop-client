/*     */ package mx4j.remote.rmi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.rmi.MarshalledObject;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.security.SecureClassLoader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.QueryExp;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.loading.ClassLoaderRepository;
/*     */ import javax.management.remote.NotificationResult;
/*     */ import javax.management.remote.rmi.RMIConnection;
/*     */ import javax.security.auth.Subject;
/*     */ import mx4j.remote.NotificationTuple;
/*     */ import mx4j.remote.RemoteNotificationServerHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RMIConnectionInvoker
/*     */   implements RMIConnection
/*     */ {
/*     */   private final MBeanServer server;
/*     */   private final ClassLoader defaultLoader;
/*     */   private final RemoteNotificationServerHandler notificationHandler;
/*     */   
/*     */   public RMIConnectionInvoker(MBeanServer server, ClassLoader defaultLoader, Map environment)
/*     */   {
/*  63 */     this.server = server;
/*  64 */     this.defaultLoader = defaultLoader;
/*     */     
/*  66 */     this.notificationHandler = new RMIRemoteNotificationServerHandler(environment);
/*     */   }
/*     */   
/*     */   public String getConnectionId() throws IOException
/*     */   {
/*  71 */     throw new Error("getConnectionId() must not be propagated along the invocation chain");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectInstance createMBean(String className, ObjectName name, Subject delegate)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException
/*     */   {
/*  82 */     return this.server.createMBean(className, name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectInstance createMBean(String className, ObjectName name, ObjectName loaderName, Subject delegate)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException
/*     */   {
/*  94 */     return this.server.createMBean(className, name, loaderName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectInstance createMBean(String className, ObjectName name, MarshalledObject params, String[] signature, Subject delegate)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException
/*     */   {
/* 105 */     RepositoryClassLoader loader = (RepositoryClassLoader)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public Object run()
/*     */       {
/* 109 */         return new RMIConnectionInvoker.RepositoryClassLoader(RMIConnectionInvoker.this.server.getClassLoaderRepository(), null);
/*     */       }
/* 111 */     });
/* 112 */     Object[] args = (Object[])RMIMarshaller.unmarshal(params, loader, this.defaultLoader);
/* 113 */     return this.server.createMBean(className, name, args, signature);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectInstance createMBean(String className, ObjectName name, ObjectName loaderName, MarshalledObject params, String[] signature, Subject delegate)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException
/*     */   {
/*     */     try
/*     */     {
/* 127 */       ClassLoader loader = (ClassLoader)AccessController.doPrivileged(new PrivilegedExceptionAction() {
/*     */         private final ObjectName val$loaderName;
/*     */         
/*     */         public Object run() throws InstanceNotFoundException {
/* 131 */           return RMIConnectionInvoker.this.server.getClassLoader(this.val$loaderName);
/*     */         }
/* 133 */       });
/* 134 */       Object[] args = (Object[])RMIMarshaller.unmarshal(params, loader, this.defaultLoader);
/* 135 */       return this.server.createMBean(className, name, loaderName, args, signature);
/*     */     }
/*     */     catch (PrivilegedActionException x)
/*     */     {
/* 139 */       throw ((InstanceNotFoundException)x.getException());
/*     */     }
/*     */   }
/*     */   
/*     */   public void unregisterMBean(ObjectName name, Subject delegate) throws InstanceNotFoundException, MBeanRegistrationException, IOException
/*     */   {
/* 145 */     this.server.unregisterMBean(name);
/*     */   }
/*     */   
/*     */   public ObjectInstance getObjectInstance(ObjectName name, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 150 */     return this.server.getObjectInstance(name);
/*     */   }
/*     */   
/*     */   public Set queryMBeans(ObjectName name, MarshalledObject query, Subject delegate) throws IOException
/*     */   {
/* 155 */     QueryExp filter = (QueryExp)RMIMarshaller.unmarshal(query, null, this.defaultLoader);
/* 156 */     return this.server.queryMBeans(name, filter);
/*     */   }
/*     */   
/*     */   public Set queryNames(ObjectName name, MarshalledObject query, Subject delegate) throws IOException
/*     */   {
/* 161 */     QueryExp filter = (QueryExp)RMIMarshaller.unmarshal(query, null, this.defaultLoader);
/* 162 */     return this.server.queryNames(name, filter);
/*     */   }
/*     */   
/*     */   public boolean isRegistered(ObjectName name, Subject delegate) throws IOException
/*     */   {
/* 167 */     return this.server.isRegistered(name);
/*     */   }
/*     */   
/*     */   public Integer getMBeanCount(Subject delegate) throws IOException
/*     */   {
/* 172 */     return this.server.getMBeanCount();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getAttribute(ObjectName name, String attribute, Subject delegate)
/*     */     throws MBeanException, AttributeNotFoundException, InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 182 */     return this.server.getAttribute(name, attribute);
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(ObjectName name, String[] attributes, Subject delegate)
/*     */     throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 188 */     return this.server.getAttributes(name, attributes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttribute(ObjectName name, MarshalledObject attribute, Subject delegate)
/*     */     throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException, IOException
/*     */   {
/* 199 */     Attribute attrib = (Attribute)RMIMarshaller.unmarshal(attribute, getClassLoaderFor(name), this.defaultLoader);
/* 200 */     this.server.setAttribute(name, attrib);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AttributeList setAttributes(ObjectName name, MarshalledObject attributes, Subject delegate)
/*     */     throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 208 */     AttributeList attribs = (AttributeList)RMIMarshaller.unmarshal(attributes, getClassLoaderFor(name), this.defaultLoader);
/* 209 */     return this.server.setAttributes(name, attribs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(ObjectName name, String operationName, MarshalledObject params, String[] signature, Subject delegate)
/*     */     throws InstanceNotFoundException, MBeanException, ReflectionException, IOException
/*     */   {
/* 218 */     Object[] args = (Object[])RMIMarshaller.unmarshal(params, getClassLoaderFor(name), this.defaultLoader);
/* 219 */     return this.server.invoke(name, operationName, args, signature);
/*     */   }
/*     */   
/*     */   public String getDefaultDomain(Subject delegate) throws IOException
/*     */   {
/* 224 */     return this.server.getDefaultDomain();
/*     */   }
/*     */   
/*     */   public String[] getDomains(Subject delegate) throws IOException
/*     */   {
/* 229 */     return this.server.getDomains();
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo(ObjectName name, Subject delegate) throws InstanceNotFoundException, IntrospectionException, ReflectionException, IOException
/*     */   {
/* 234 */     return this.server.getMBeanInfo(name);
/*     */   }
/*     */   
/*     */   public boolean isInstanceOf(ObjectName name, String className, Subject delegate) throws InstanceNotFoundException, IOException
/*     */   {
/* 239 */     return this.server.isInstanceOf(name, className);
/*     */   }
/*     */   
/*     */   public void addNotificationListener(ObjectName name, ObjectName listener, MarshalledObject filter, MarshalledObject handback, Subject delegate)
/*     */     throws InstanceNotFoundException, IOException
/*     */   {
/* 245 */     ClassLoader loader = getClassLoaderFor(name);
/* 246 */     NotificationFilter f = (NotificationFilter)RMIMarshaller.unmarshal(filter, loader, this.defaultLoader);
/* 247 */     Object h = RMIMarshaller.unmarshal(handback, loader, this.defaultLoader);
/* 248 */     this.server.addNotificationListener(name, listener, f, h);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName name, ObjectName listener, Subject delegate)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 254 */     this.server.removeNotificationListener(name, listener);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName name, ObjectName listener, MarshalledObject filter, MarshalledObject handback, Subject delegate)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 260 */     ClassLoader loader = getClassLoaderFor(name);
/* 261 */     NotificationFilter f = (NotificationFilter)RMIMarshaller.unmarshal(filter, loader, this.defaultLoader);
/* 262 */     Object h = RMIMarshaller.unmarshal(handback, loader, this.defaultLoader);
/* 263 */     this.server.removeNotificationListener(name, listener, f, h);
/*     */   }
/*     */   
/*     */   public Integer[] addNotificationListeners(ObjectName[] names, MarshalledObject[] filters, Subject[] delegates) throws InstanceNotFoundException, IOException
/*     */   {
/* 268 */     ArrayList ids = new ArrayList();
/* 269 */     for (int i = 0; i < names.length; i++)
/*     */     {
/* 271 */       ObjectName name = names[i];
/* 272 */       MarshalledObject filter = filters[i];
/* 273 */       NotificationFilter f = (NotificationFilter)RMIMarshaller.unmarshal(filter, getClassLoaderFor(name), this.defaultLoader);
/* 274 */       Integer id = this.notificationHandler.generateListenerID(name, f);
/* 275 */       NotificationListener listener = this.notificationHandler.getServerNotificationListener();
/* 276 */       this.server.addNotificationListener(name, listener, f, id);
/* 277 */       this.notificationHandler.addNotificationListener(id, new NotificationTuple(name, listener, f, id));
/* 278 */       ids.add(id);
/*     */     }
/* 280 */     return (Integer[])ids.toArray(new Integer[ids.size()]);
/*     */   }
/*     */   
/*     */   public void removeNotificationListeners(ObjectName name, Integer[] listenerIDs, Subject delegate) throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 285 */     for (int i = 0; i < listenerIDs.length; i++)
/*     */     {
/* 287 */       Integer id = listenerIDs[i];
/*     */       
/* 289 */       NotificationTuple tuple = this.notificationHandler.removeNotificationListener(id);
/* 290 */       if (tuple != null) this.server.removeNotificationListener(name, tuple.getNotificationListener(), tuple.getNotificationFilter(), tuple.getHandback());
/*     */     }
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 296 */     NotificationTuple[] tuples = this.notificationHandler.close();
/* 297 */     for (int i = 0; i < tuples.length; i++)
/*     */     {
/* 299 */       NotificationTuple tuple = tuples[i];
/*     */       try
/*     */       {
/* 302 */         this.server.removeNotificationListener(tuple.getObjectName(), tuple.getNotificationListener(), tuple.getNotificationFilter(), tuple.getHandback());
/*     */       }
/*     */       catch (InstanceNotFoundException ignored) {}catch (ListenerNotFoundException ignored) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NotificationResult fetchNotifications(long clientSequenceNumber, int maxNotifications, long timeout)
/*     */     throws IOException
/*     */   {
/* 315 */     return this.notificationHandler.fetchNotifications(clientSequenceNumber, maxNotifications, timeout);
/*     */   }
/*     */   
/*     */   private ClassLoader getClassLoaderFor(ObjectName name) throws InstanceNotFoundException
/*     */   {
/* 320 */     if (System.getSecurityManager() == null)
/*     */     {
/* 322 */       return this.server.getClassLoaderFor(name);
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 328 */       (ClassLoader)AccessController.doPrivileged(new PrivilegedExceptionAction() {
/*     */         private final ObjectName val$name;
/*     */         
/*     */         public Object run() throws InstanceNotFoundException {
/* 332 */           return RMIConnectionInvoker.this.server.getClassLoaderFor(this.val$name);
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (PrivilegedActionException x)
/*     */     {
/* 338 */       throw ((InstanceNotFoundException)x.getException());
/*     */     } }
/*     */   
/*     */   private static class RepositoryClassLoader extends SecureClassLoader { private final ClassLoaderRepository repository;
/*     */     
/* 343 */     RepositoryClassLoader(ClassLoaderRepository x0, RMIConnectionInvoker.1 x1) { this(x0); }
/*     */     
/*     */ 
/*     */ 
/*     */     private RepositoryClassLoader(ClassLoaderRepository repository)
/*     */     {
/* 349 */       this.repository = repository;
/*     */     }
/*     */     
/*     */     public Class loadClass(String name) throws ClassNotFoundException
/*     */     {
/* 354 */       return this.repository.loadClass(name);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/rmi/RMIConnectionInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */