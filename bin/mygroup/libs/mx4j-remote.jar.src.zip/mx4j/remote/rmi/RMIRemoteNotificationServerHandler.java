/*    */ package mx4j.remote.rmi;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Map;
/*    */ import javax.management.remote.TargetedNotification;
/*    */ import mx4j.log.Logger;
/*    */ import mx4j.remote.DefaultRemoteNotificationServerHandler;
/*    */ import mx4j.remote.MX4JRemoteUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RMIRemoteNotificationServerHandler
/*    */   extends DefaultRemoteNotificationServerHandler
/*    */ {
/*    */   RMIRemoteNotificationServerHandler(Map environment)
/*    */   {
/* 26 */     super(environment);
/*    */   }
/*    */   
/*    */   protected TargetedNotification[] filterNotifications(TargetedNotification[] notifications)
/*    */   {
/* 31 */     Logger logger = null;
/* 32 */     ArrayList list = new ArrayList();
/* 33 */     for (int i = 0; i < notifications.length; i++)
/*    */     {
/* 35 */       TargetedNotification notification = notifications[i];
/* 36 */       if (MX4JRemoteUtils.isTrulySerializable(notification))
/*    */       {
/* 38 */         list.add(notification);
/*    */       }
/*    */       else
/*    */       {
/* 42 */         if (logger == null) logger = getLogger();
/* 43 */         if (logger.isEnabledFor(20)) logger.info("Cannot send notification " + notification + " to the client: it is not serializable");
/*    */       }
/*    */     }
/* 46 */     return (TargetedNotification[])list.toArray(new TargetedNotification[list.size()]);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/rmi/RMIRemoteNotificationServerHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */