/*     */ package mx4j.remote.rmi;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.rmi.MarshalledObject;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.SecureClassLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RMIMarshaller
/*     */ {
/*  63 */   private static final Method unmarshal = ;
/*     */   
/*     */   private static Method getUnmarshalMethod()
/*     */   {
/*  67 */     (Method)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public Object run()
/*     */       {
/*  71 */         String marshallerName = Marshaller.class.getName();
/*  72 */         InputStream stream = Marshaller.class.getResourceAsStream(marshallerName.substring(marshallerName.lastIndexOf('.') + 1) + ".class");
/*  73 */         if (stream == null) throw new Error("Could not load implementation class " + marshallerName);
/*  74 */         BufferedInputStream bis = new BufferedInputStream(stream);
/*  75 */         ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  76 */         BufferedOutputStream bos = new BufferedOutputStream(baos);
/*     */         try
/*     */         {
/*  79 */           byte[] buffer = new byte['Ā'];
/*  80 */           int read = -1;
/*  81 */           while ((read = bis.read(buffer)) >= 0) bos.write(buffer, 0, read);
/*  82 */           bis.close();
/*  83 */           bos.close();
/*     */         }
/*     */         catch (IOException x)
/*     */         {
/*  87 */           throw new Error(x.toString());
/*     */         }
/*     */         
/*  90 */         byte[] classBytes = baos.toByteArray();
/*     */         
/*  92 */         RMIMarshaller.MarshallerClassLoader loader = new RMIMarshaller.MarshallerClassLoader(classBytes, null);
/*     */         
/*     */         try
/*     */         {
/*  96 */           Class cls = loader.loadClass(marshallerName);
/*  97 */           return cls.getMethod("unmarshal", new Class[] { MarshalledObject.class });
/*     */         }
/*     */         catch (ClassNotFoundException x)
/*     */         {
/* 101 */           throw new Error(x.toString());
/*     */         }
/*     */         catch (NoSuchMethodException x)
/*     */         {
/* 105 */           throw new Error(x.toString());
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static MarshalledObject marshal(Object object)
/*     */     throws IOException
/*     */   {
/* 116 */     if (object == null) return null;
/* 117 */     return new MarshalledObject(object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object unmarshal(MarshalledObject object, ClassLoader mbeanLoader, ClassLoader defaultLoader)
/*     */     throws IOException
/*     */   {
/* 126 */     if (object == null) return null;
/* 127 */     if (mbeanLoader == null) { return unmarshal(object, defaultLoader);
/*     */     }
/* 129 */     ClassLoader loader = (ClassLoader)AccessController.doPrivileged(new PrivilegedAction() {
/*     */       private final ClassLoader val$mbeanLoader;
/*     */       private final ClassLoader val$defaultLoader;
/*     */       
/* 133 */       public Object run() { return new RMIMarshaller.ExtendedClassLoader(this.val$mbeanLoader, this.val$defaultLoader, null);
/*     */       }
/* 135 */     });
/* 136 */     return unmarshal(object, loader);
/*     */   }
/*     */   
/*     */   private static Object unmarshal(MarshalledObject object, ClassLoader loader) throws IOException
/*     */   {
/* 141 */     if (loader != null)
/*     */     {
/* 143 */       ClassLoader old = Thread.currentThread().getContextClassLoader();
/*     */       try
/*     */       {
/* 146 */         setContextClassLoader(loader);
/* 147 */         return unmarshal(object);
/*     */       }
/*     */       catch (IOException x)
/*     */       {
/* 151 */         throw x;
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (ClassNotFoundException ignored) {}finally
/*     */       {
/*     */ 
/* 158 */         setContextClassLoader(old);
/*     */       }
/*     */     }
/* 161 */     throw new IOException("Cannot unmarshal " + object);
/*     */   }
/*     */   
/*     */   private static Object unmarshal(MarshalledObject marshalled) throws IOException, ClassNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 168 */       return unmarshal.invoke(null, new Object[] { marshalled });
/*     */     }
/*     */     catch (InvocationTargetException x)
/*     */     {
/* 172 */       Throwable t = x.getTargetException();
/* 173 */       if ((t instanceof IOException)) throw ((IOException)t);
/* 174 */       if ((t instanceof ClassNotFoundException)) throw ((ClassNotFoundException)t);
/* 175 */       throw new IOException(t.toString());
/*     */     }
/*     */     catch (Exception x)
/*     */     {
/* 179 */       throw new IOException(x.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 185 */   private static void setContextClassLoader(ClassLoader loader) { AccessController.doPrivileged(new PrivilegedAction() {
/*     */       private final ClassLoader val$loader;
/*     */       
/*     */       public Object run() {
/* 189 */         Thread.currentThread().setContextClassLoader(this.val$loader);
/* 190 */         return null;
/*     */       } }); }
/*     */   
/*     */   private static class MarshallerClassLoader extends SecureClassLoader { private byte[] bytes;
/*     */     
/* 195 */     MarshallerClassLoader(byte[] x0, RMIMarshaller.1 x1) { this(x0); }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private MarshallerClassLoader(byte[] classBytes)
/*     */     {
/* 210 */       super();
/* 211 */       this.bytes = classBytes;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Class loadClass(String name)
/*     */       throws ClassNotFoundException
/*     */     {
/* 224 */       if (name.startsWith(Marshaller.class.getName()))
/*     */       {
/*     */         try
/*     */         {
/* 228 */           return defineClass(name, this.bytes, 0, this.bytes.length, getClass().getProtectionDomain());
/*     */         }
/*     */         catch (ClassFormatError x)
/*     */         {
/* 232 */           throw new ClassNotFoundException("Class Format Error", x);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 237 */       return super.loadClass(name);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ExtendedClassLoader extends SecureClassLoader
/*     */   {
/*     */     private final ClassLoader defaultLoader;
/*     */     
/*     */     ExtendedClassLoader(ClassLoader x0, ClassLoader x1, RMIMarshaller.1 x2) {
/* 246 */       this(x0, x1);
/*     */     }
/*     */     
/*     */ 
/*     */     private ExtendedClassLoader(ClassLoader mbeanLoader, ClassLoader defaultLoader)
/*     */     {
/* 252 */       super();
/* 253 */       this.defaultLoader = defaultLoader;
/*     */     }
/*     */     
/*     */     protected Class findClass(String name) throws ClassNotFoundException
/*     */     {
/* 258 */       return this.defaultLoader.loadClass(name);
/*     */     }
/*     */     
/*     */     protected URL findResource(String name)
/*     */     {
/* 263 */       return this.defaultLoader.getResource(name);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/rmi/RMIMarshaller.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */