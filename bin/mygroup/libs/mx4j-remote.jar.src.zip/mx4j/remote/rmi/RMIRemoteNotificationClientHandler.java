/*    */ package mx4j.remote.rmi;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.management.remote.NotificationResult;
/*    */ import javax.management.remote.rmi.RMIConnection;
/*    */ import mx4j.remote.AbstractRemoteNotificationClientHandler;
/*    */ import mx4j.remote.ConnectionNotificationEmitter;
/*    */ import mx4j.remote.HeartBeat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RMIRemoteNotificationClientHandler
/*    */   extends AbstractRemoteNotificationClientHandler
/*    */ {
/*    */   private final RMIConnection connection;
/*    */   
/*    */   public RMIRemoteNotificationClientHandler(RMIConnection connection, ConnectionNotificationEmitter emitter, HeartBeat heartbeat, Map environment)
/*    */   {
/* 31 */     super(emitter, heartbeat, environment);
/* 32 */     this.connection = connection;
/*    */   }
/*    */   
/*    */   protected NotificationResult fetchNotifications(long sequence, int maxNumber, long timeout) throws IOException
/*    */   {
/* 37 */     return this.connection.fetchNotifications(sequence, maxNumber, timeout);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/rmi/RMIRemoteNotificationClientHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */