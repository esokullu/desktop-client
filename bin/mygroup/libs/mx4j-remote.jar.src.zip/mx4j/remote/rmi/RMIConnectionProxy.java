/*    */ package mx4j.remote.rmi;
/*    */ 
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import javax.management.remote.rmi.RMIConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RMIConnectionProxy
/*    */   implements InvocationHandler
/*    */ {
/*    */   private RMIConnection nested;
/*    */   
/*    */   protected RMIConnectionProxy(RMIConnection nested)
/*    */   {
/* 27 */     this.nested = nested;
/*    */   }
/*    */   
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*    */   {
/*    */     try
/*    */     {
/* 34 */       return method.invoke(this.nested, args);
/*    */     }
/*    */     catch (InvocationTargetException x)
/*    */     {
/* 38 */       throw x.getTargetException();
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/rmi/RMIConnectionProxy.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */