/*    */ package mx4j.remote.rmi;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Proxy;
/*    */ import java.rmi.NoSuchObjectException;
/*    */ import javax.management.MBeanServerConnection;
/*    */ import javax.management.remote.JMXServerErrorException;
/*    */ import mx4j.remote.ClientProxy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientExceptionCatcher
/*    */   extends ClientProxy
/*    */ {
/*    */   private ClientExceptionCatcher(MBeanServerConnection target)
/*    */   {
/* 27 */     super(target);
/*    */   }
/*    */   
/*    */   public static MBeanServerConnection newInstance(MBeanServerConnection target)
/*    */   {
/* 32 */     ClientExceptionCatcher handler = new ClientExceptionCatcher(target);
/* 33 */     return (MBeanServerConnection)Proxy.newProxyInstance(handler.getClass().getClassLoader(), new Class[] { MBeanServerConnection.class }, handler);
/*    */   }
/*    */   
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*    */   {
/*    */     try
/*    */     {
/* 40 */       return super.invoke(proxy, method, args);
/*    */ 
/*    */     }
/*    */     catch (NoSuchObjectException x)
/*    */     {
/* 45 */       throw new IOException("Connection closed by the server");
/*    */     }
/*    */     catch (Exception x)
/*    */     {
/* 49 */       throw x;
/*    */     }
/*    */     catch (Error x)
/*    */     {
/* 53 */       throw new JMXServerErrorException("Error thrown during invocation", x);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/rmi/ClientExceptionCatcher.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */