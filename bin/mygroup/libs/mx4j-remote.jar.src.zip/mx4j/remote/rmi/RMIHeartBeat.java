/*    */ package mx4j.remote.rmi;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.management.remote.rmi.RMIConnection;
/*    */ import mx4j.remote.AbstractHeartBeat;
/*    */ import mx4j.remote.ConnectionNotificationEmitter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RMIHeartBeat
/*    */   extends AbstractHeartBeat
/*    */ {
/*    */   private final RMIConnection connection;
/*    */   
/*    */   public RMIHeartBeat(RMIConnection connection, ConnectionNotificationEmitter emitter, Map environment)
/*    */   {
/* 27 */     super(emitter, environment);
/* 28 */     this.connection = connection;
/*    */   }
/*    */   
/*    */   protected void pulse() throws IOException
/*    */   {
/* 33 */     this.connection.getDefaultDomain(null);
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/rmi/RMIHeartBeat.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */