/*     */ package mx4j.remote.rmi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.NotSerializableException;
/*     */ import java.rmi.MarshalledObject;
/*     */ import java.util.Set;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.ListenerNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanRegistrationException;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.NotCompliantMBeanException;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.QueryExp;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.remote.rmi.RMIConnection;
/*     */ import javax.security.auth.Subject;
/*     */ import mx4j.remote.NotificationTuple;
/*     */ import mx4j.remote.RemoteNotificationClientHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientInvoker
/*     */   implements MBeanServerConnection
/*     */ {
/*     */   private final RMIConnection connection;
/*     */   private final Subject delegate;
/*     */   private final RemoteNotificationClientHandler notificationHandler;
/*     */   
/*     */   public ClientInvoker(RMIConnection rmiConnection, RemoteNotificationClientHandler notificationHandler, Subject delegate)
/*     */   {
/*  55 */     this.connection = rmiConnection;
/*  56 */     this.delegate = delegate;
/*  57 */     this.notificationHandler = notificationHandler;
/*     */   }
/*     */   
/*     */   public void addNotificationListener(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback)
/*     */     throws InstanceNotFoundException, IOException
/*     */   {
/*  63 */     NotificationTuple tuple = new NotificationTuple(observed, listener, filter, handback);
/*  64 */     if (this.notificationHandler.contains(tuple)) { return;
/*     */     }
/*  66 */     MarshalledObject f = null;
/*     */     try
/*     */     {
/*  69 */       f = RMIMarshaller.marshal(filter);
/*     */ 
/*     */     }
/*     */     catch (NotSerializableException x)
/*     */     {
/*  74 */       tuple.setInvokeFilter(true);
/*     */     }
/*  76 */     Integer[] ids = this.connection.addNotificationListeners(new ObjectName[] { observed }, new MarshalledObject[] { f }, new Subject[] { this.delegate });
/*  77 */     this.notificationHandler.addNotificationListener(ids[0], tuple);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName observed, NotificationListener listener)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/*  83 */     Integer[] ids = this.notificationHandler.getNotificationListeners(new NotificationTuple(observed, listener));
/*  84 */     if (ids == null) throw new ListenerNotFoundException("Could not find listener " + listener);
/*  85 */     this.connection.removeNotificationListeners(observed, ids, this.delegate);
/*  86 */     this.notificationHandler.removeNotificationListeners(ids);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName observed, NotificationListener listener, NotificationFilter filter, Object handback)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/*  92 */     Integer id = this.notificationHandler.getNotificationListener(new NotificationTuple(observed, listener, filter, handback));
/*  93 */     if (id == null) throw new ListenerNotFoundException("Could not find listener " + listener + " with filter " + filter + " and handback " + handback);
/*  94 */     Integer[] ids = { id };
/*  95 */     this.connection.removeNotificationListeners(observed, ids, this.delegate);
/*  96 */     this.notificationHandler.removeNotificationListeners(ids);
/*     */   }
/*     */   
/*     */   public void addNotificationListener(ObjectName observed, ObjectName listener, NotificationFilter filter, Object handback)
/*     */     throws InstanceNotFoundException, IOException
/*     */   {
/* 102 */     MarshalledObject f = RMIMarshaller.marshal(filter);
/* 103 */     MarshalledObject h = RMIMarshaller.marshal(handback);
/* 104 */     this.connection.addNotificationListener(observed, listener, f, h, this.delegate);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName observed, ObjectName listener)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 110 */     this.connection.removeNotificationListener(observed, listener, this.delegate);
/*     */   }
/*     */   
/*     */   public void removeNotificationListener(ObjectName observed, ObjectName listener, NotificationFilter filter, Object handback)
/*     */     throws InstanceNotFoundException, ListenerNotFoundException, IOException
/*     */   {
/* 116 */     MarshalledObject f = RMIMarshaller.marshal(filter);
/* 117 */     MarshalledObject h = RMIMarshaller.marshal(handback);
/* 118 */     this.connection.removeNotificationListener(observed, listener, f, h, this.delegate);
/*     */   }
/*     */   
/*     */   public MBeanInfo getMBeanInfo(ObjectName objectName)
/*     */     throws InstanceNotFoundException, IntrospectionException, ReflectionException, IOException
/*     */   {
/* 124 */     return this.connection.getMBeanInfo(objectName, this.delegate);
/*     */   }
/*     */   
/*     */   public boolean isInstanceOf(ObjectName objectName, String className)
/*     */     throws InstanceNotFoundException, IOException
/*     */   {
/* 130 */     return this.connection.isInstanceOf(objectName, className, this.delegate);
/*     */   }
/*     */   
/*     */   public String[] getDomains()
/*     */     throws IOException
/*     */   {
/* 136 */     return this.connection.getDomains(this.delegate);
/*     */   }
/*     */   
/*     */   public String getDefaultDomain()
/*     */     throws IOException
/*     */   {
/* 142 */     return this.connection.getDefaultDomain(this.delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException
/*     */   {
/* 148 */     return this.connection.createMBean(className, objectName, this.delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName, Object[] args, String[] parameters)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, IOException
/*     */   {
/* 154 */     MarshalledObject arguments = RMIMarshaller.marshal(args);
/* 155 */     return this.connection.createMBean(className, objectName, arguments, parameters, this.delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName, ObjectName loaderName)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException
/*     */   {
/* 161 */     return this.connection.createMBean(className, objectName, loaderName, this.delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance createMBean(String className, ObjectName objectName, ObjectName loaderName, Object[] args, String[] parameters)
/*     */     throws ReflectionException, InstanceAlreadyExistsException, MBeanRegistrationException, MBeanException, NotCompliantMBeanException, InstanceNotFoundException, IOException
/*     */   {
/* 167 */     MarshalledObject arguments = RMIMarshaller.marshal(args);
/* 168 */     return this.connection.createMBean(className, objectName, loaderName, arguments, parameters, this.delegate);
/*     */   }
/*     */   
/*     */   public void unregisterMBean(ObjectName objectName)
/*     */     throws InstanceNotFoundException, MBeanRegistrationException, IOException
/*     */   {
/* 174 */     this.connection.unregisterMBean(objectName, this.delegate);
/*     */   }
/*     */   
/*     */   public Object getAttribute(ObjectName objectName, String attribute)
/*     */     throws MBeanException, AttributeNotFoundException, InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 180 */     return this.connection.getAttribute(objectName, attribute, this.delegate);
/*     */   }
/*     */   
/*     */   public void setAttribute(ObjectName objectName, Attribute attribute)
/*     */     throws InstanceNotFoundException, AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException, IOException
/*     */   {
/* 186 */     MarshalledObject attrib = RMIMarshaller.marshal(attribute);
/* 187 */     this.connection.setAttribute(objectName, attrib, this.delegate);
/*     */   }
/*     */   
/*     */   public AttributeList getAttributes(ObjectName objectName, String[] attributes)
/*     */     throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 193 */     return this.connection.getAttributes(objectName, attributes, this.delegate);
/*     */   }
/*     */   
/*     */   public AttributeList setAttributes(ObjectName objectName, AttributeList attributes)
/*     */     throws InstanceNotFoundException, ReflectionException, IOException
/*     */   {
/* 199 */     MarshalledObject attribs = RMIMarshaller.marshal(attributes);
/* 200 */     return this.connection.setAttributes(objectName, attribs, this.delegate);
/*     */   }
/*     */   
/*     */   public Object invoke(ObjectName objectName, String methodName, Object[] args, String[] parameters)
/*     */     throws InstanceNotFoundException, MBeanException, ReflectionException, IOException
/*     */   {
/* 206 */     MarshalledObject arguments = RMIMarshaller.marshal(args);
/* 207 */     return this.connection.invoke(objectName, methodName, arguments, parameters, this.delegate);
/*     */   }
/*     */   
/*     */   public Integer getMBeanCount()
/*     */     throws IOException
/*     */   {
/* 213 */     return this.connection.getMBeanCount(this.delegate);
/*     */   }
/*     */   
/*     */   public boolean isRegistered(ObjectName objectName)
/*     */     throws IOException
/*     */   {
/* 219 */     return this.connection.isRegistered(objectName, this.delegate);
/*     */   }
/*     */   
/*     */   public ObjectInstance getObjectInstance(ObjectName objectName)
/*     */     throws InstanceNotFoundException, IOException
/*     */   {
/* 225 */     return this.connection.getObjectInstance(objectName, this.delegate);
/*     */   }
/*     */   
/*     */   public Set queryMBeans(ObjectName patternName, QueryExp filter)
/*     */     throws IOException
/*     */   {
/* 231 */     MarshalledObject query = RMIMarshaller.marshal(filter);
/* 232 */     return this.connection.queryMBeans(patternName, query, this.delegate);
/*     */   }
/*     */   
/*     */   public Set queryNames(ObjectName patternName, QueryExp filter)
/*     */     throws IOException
/*     */   {
/* 238 */     MarshalledObject query = RMIMarshaller.marshal(filter);
/* 239 */     return this.connection.queryNames(patternName, query, this.delegate);
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/rmi/ClientInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */