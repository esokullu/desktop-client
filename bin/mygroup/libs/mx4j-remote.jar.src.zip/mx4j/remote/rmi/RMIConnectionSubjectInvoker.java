/*     */ package mx4j.remote.rmi;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.rmi.MarshalledObject;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.remote.JMXServerErrorException;
/*     */ import javax.management.remote.rmi.RMIConnection;
/*     */ import javax.security.auth.Subject;
/*     */ import mx4j.remote.MX4JRemoteUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RMIConnectionSubjectInvoker
/*     */   extends RMIConnectionProxy
/*     */ {
/*     */   private final Subject subject;
/*     */   private final AccessControlContext context;
/*     */   private Map environment;
/*     */   
/*     */   public static RMIConnection newInstance(RMIConnection nested, Subject subject, AccessControlContext context, Map environment)
/*     */   {
/*  35 */     RMIConnectionSubjectInvoker handler = new RMIConnectionSubjectInvoker(nested, subject, context, environment);
/*  36 */     return (RMIConnection)Proxy.newProxyInstance(handler.getClass().getClassLoader(), new Class[] { RMIConnection.class }, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private RMIConnectionSubjectInvoker(RMIConnection nested, Subject subject, AccessControlContext context, Map environment)
/*     */   {
/*  45 */     super(nested);
/*  46 */     this.subject = subject;
/*  47 */     this.context = context;
/*  48 */     this.environment = environment;
/*     */   }
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] args)
/*     */     throws Throwable
/*     */   {
/*  54 */     String methodName = method.getName();
/*  55 */     if (("fetchNotifications".equals(methodName)) || ("close".equals(methodName)) || ("getConnectionId".equals(methodName))) { return chain(proxy, method, args);
/*     */     }
/*  57 */     if ("addNotificationListeners".equals(methodName))
/*     */     {
/*  59 */       Subject[] delegates = (Subject[])args[(args.length - 1)];
/*  60 */       if ((delegates == null) || (delegates.length == 0)) { return chain(proxy, method, args);
/*     */       }
/*  62 */       if (delegates.length == 1) { return subjectInvoke(proxy, method, args, delegates[0]);
/*     */       }
/*  64 */       ArrayList ids = new ArrayList();
/*  65 */       for (int i = 0; i < delegates.length; i++)
/*     */       {
/*  67 */         ObjectName name = ((ObjectName[])args[0])[i];
/*  68 */         MarshalledObject filter = ((MarshalledObject[])args[1])[i];
/*  69 */         Subject delegate = delegates[i];
/*  70 */         Object[] newArgs = { { name }, { filter }, { delegate } };
/*  71 */         Integer id = ((Integer[])subjectInvoke(proxy, method, newArgs, delegate))[0];
/*  72 */         ids.add(id);
/*     */       }
/*  74 */       return (Integer[])ids.toArray(new Integer[ids.size()]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  79 */     Subject delegate = (Subject)args[(args.length - 1)];
/*  80 */     return subjectInvoke(proxy, method, args, delegate);
/*     */   }
/*     */   
/*     */   private Object subjectInvoke(Object proxy, Method method, Object[] args, Subject delegate)
/*     */     throws Exception
/*     */   {
/*  86 */     MX4JRemoteUtils.subjectInvoke(this.subject, delegate, this.context, this.environment, new PrivilegedExceptionAction() { private final Object val$proxy;
/*     */       private final Method val$method;
/*     */       private final Object[] val$args;
/*     */       
/*  90 */       public Object run() throws Exception { return RMIConnectionSubjectInvoker.this.chain(this.val$proxy, this.val$method, this.val$args); }
/*     */     });
/*     */   }
/*     */   
/*     */   private Object chain(Object proxy, Method method, Object[] args)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  99 */       return super.invoke(proxy, method, args);
/*     */     }
/*     */     catch (Throwable x)
/*     */     {
/* 103 */       if ((x instanceof Exception)) throw ((Exception)x);
/* 104 */       throw new JMXServerErrorException("Error thrown during invocation", (Error)x);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/rmi/RMIConnectionSubjectInvoker.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */