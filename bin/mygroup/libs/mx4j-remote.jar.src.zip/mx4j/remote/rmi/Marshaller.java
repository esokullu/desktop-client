/*    */ package mx4j.remote.rmi;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.rmi.MarshalledObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Marshaller
/*    */ {
/*    */   public static Object unmarshal(MarshalledObject obj)
/*    */     throws IOException, ClassNotFoundException
/*    */   {
/* 23 */     return obj.get();
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/rmi/Marshaller.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */