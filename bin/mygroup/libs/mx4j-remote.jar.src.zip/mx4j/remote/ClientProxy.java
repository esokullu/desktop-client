/*    */ package mx4j.remote;
/*    */ 
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import javax.management.MBeanServerConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientProxy
/*    */   implements InvocationHandler
/*    */ {
/*    */   private final MBeanServerConnection target;
/*    */   
/*    */   protected ClientProxy(MBeanServerConnection target)
/*    */   {
/* 25 */     this.target = target;
/*    */   }
/*    */   
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*    */   {
/*    */     try
/*    */     {
/* 32 */       return method.invoke(this.target, args);
/*    */     }
/*    */     catch (InvocationTargetException x)
/*    */     {
/* 36 */       throw x.getTargetException();
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/ClientProxy.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */