/*     */ package mx4j.remote;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.remote.NotificationResult;
/*     */ import javax.management.remote.TargetedNotification;
/*     */ import mx4j.log.Log;
/*     */ import mx4j.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultRemoteNotificationServerHandler
/*     */   implements RemoteNotificationServerHandler
/*     */ {
/*     */   private static int listenerID;
/*     */   private final NotificationListener listener;
/*  37 */   private final Map tuples = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   private final NotificationBuffer buffer;
/*     */   
/*     */ 
/*     */   private volatile boolean closed;
/*     */   
/*     */ 
/*     */ 
/*     */   public DefaultRemoteNotificationServerHandler(Map environment)
/*     */   {
/*  50 */     this.listener = new ServerListener(null);
/*  51 */     this.buffer = new NotificationBuffer(environment, null);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Integer generateListenerID(javax.management.ObjectName name, javax.management.NotificationFilter filter)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 18	mx4j/remote/DefaultRemoteNotificationServerHandler:class$mx4j$remote$DefaultRemoteNotificationServerHandler	Ljava/lang/Class;
/*     */     //   3: ifnonnull +15 -> 18
/*     */     //   6: ldc 19
/*     */     //   8: invokestatic 20	mx4j/remote/DefaultRemoteNotificationServerHandler:class$	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   11: dup
/*     */     //   12: putstatic 18	mx4j/remote/DefaultRemoteNotificationServerHandler:class$mx4j$remote$DefaultRemoteNotificationServerHandler	Ljava/lang/Class;
/*     */     //   15: goto +6 -> 21
/*     */     //   18: getstatic 18	mx4j/remote/DefaultRemoteNotificationServerHandler:class$mx4j$remote$DefaultRemoteNotificationServerHandler	Ljava/lang/Class;
/*     */     //   21: dup
/*     */     //   22: astore_3
/*     */     //   23: monitorenter
/*     */     //   24: new 21	java/lang/Integer
/*     */     //   27: dup
/*     */     //   28: getstatic 22	mx4j/remote/DefaultRemoteNotificationServerHandler:listenerID	I
/*     */     //   31: iconst_1
/*     */     //   32: iadd
/*     */     //   33: dup
/*     */     //   34: putstatic 22	mx4j/remote/DefaultRemoteNotificationServerHandler:listenerID	I
/*     */     //   37: invokespecial 23	java/lang/Integer:<init>	(I)V
/*     */     //   40: aload_3
/*     */     //   41: monitorexit
/*     */     //   42: areturn
/*     */     //   43: astore 4
/*     */     //   45: aload_3
/*     */     //   46: monitorexit
/*     */     //   47: aload 4
/*     */     //   49: athrow
/*     */     // Line number table:
/*     */     //   Java source line #56	-> byte code offset #0
/*     */     //   Java source line #58	-> byte code offset #24
/*     */     //   Java source line #59	-> byte code offset #43
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	50	0	this	DefaultRemoteNotificationServerHandler
/*     */     //   0	50	1	name	javax.management.ObjectName
/*     */     //   0	50	2	filter	javax.management.NotificationFilter
/*     */     //   22	24	3	Ljava/lang/Object;	Object
/*     */     //   43	5	4	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   24	42	43	finally
/*     */     //   43	47	43	finally
/*     */   }
/*     */   
/*     */   public NotificationListener getServerNotificationListener()
/*     */   {
/*  64 */     return this.listener;
/*     */   }
/*     */   
/*     */   public void addNotificationListener(Integer id, NotificationTuple tuple)
/*     */   {
/*  69 */     if (this.closed) return;
/*  70 */     synchronized (this.tuples)
/*     */     {
/*  72 */       this.tuples.put(id, tuple);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public NotificationTuple removeNotificationListener(Integer id)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 1	mx4j/remote/DefaultRemoteNotificationServerHandler:closed	Z
/*     */     //   4: ifeq +5 -> 9
/*     */     //   7: aconst_null
/*     */     //   8: areturn
/*     */     //   9: aload_0
/*     */     //   10: getfield 11	mx4j/remote/DefaultRemoteNotificationServerHandler:tuples	Ljava/util/Map;
/*     */     //   13: dup
/*     */     //   14: astore_2
/*     */     //   15: monitorenter
/*     */     //   16: aload_0
/*     */     //   17: getfield 11	mx4j/remote/DefaultRemoteNotificationServerHandler:tuples	Ljava/util/Map;
/*     */     //   20: aload_1
/*     */     //   21: invokeinterface 25 2 0
/*     */     //   26: checkcast 26	mx4j/remote/NotificationTuple
/*     */     //   29: aload_2
/*     */     //   30: monitorexit
/*     */     //   31: areturn
/*     */     //   32: astore_3
/*     */     //   33: aload_2
/*     */     //   34: monitorexit
/*     */     //   35: aload_3
/*     */     //   36: athrow
/*     */     // Line number table:
/*     */     //   Java source line #78	-> byte code offset #0
/*     */     //   Java source line #79	-> byte code offset #9
/*     */     //   Java source line #81	-> byte code offset #16
/*     */     //   Java source line #82	-> byte code offset #32
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	37	0	this	DefaultRemoteNotificationServerHandler
/*     */     //   0	37	1	id	Integer
/*     */     //   14	20	2	Ljava/lang/Object;	Object
/*     */     //   32	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   16	31	32	finally
/*     */     //   32	35	32	finally
/*     */   }
/*     */   
/*     */   public NotificationResult fetchNotifications(long sequenceNumber, int maxNotifications, long timeout)
/*     */     throws IOException
/*     */   {
/*  87 */     if (this.closed) throw new IOException("RemoteNotificationServerHandler is closed");
/*  88 */     return this.buffer.getNotifications(sequenceNumber, maxNotifications, timeout);
/*     */   }
/*     */   
/*     */   public NotificationTuple[] close()
/*     */   {
/*  93 */     Logger logger = getLogger();
/*  94 */     this.closed = true;
/*  95 */     stopWaitingForNotifications(this.buffer);
/*  96 */     synchronized (this.tuples)
/*     */     {
/*  98 */       NotificationTuple[] result = (NotificationTuple[])this.tuples.values().toArray(new NotificationTuple[this.tuples.size()]);
/*  99 */       this.tuples.clear();
/* 100 */       if (logger.isEnabledFor(10)) logger.debug("RemoteNotificationServerHandler closed, returning: " + Arrays.asList(result));
/* 101 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void stopWaitingForNotifications(Object lock)
/*     */   {
/* 114 */     synchronized (lock)
/*     */     {
/* 116 */       lock.notifyAll();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean waitForNotifications(Object lock, long timeout)
/*     */   {
/* 133 */     Logger logger = getLogger();
/* 134 */     long start = 0L;
/* 135 */     if (logger.isEnabledFor(10))
/*     */     {
/* 137 */       logger.debug("Waiting for notifications " + timeout + " ms");
/* 138 */       start = System.currentTimeMillis();
/*     */     }
/*     */     
/* 141 */     synchronized (lock)
/*     */     {
/*     */       try
/*     */       {
/* 145 */         lock.wait(timeout);
/*     */       }
/*     */       catch (InterruptedException x)
/*     */       {
/* 149 */         Thread.currentThread().interrupt();
/*     */       }
/*     */     }
/*     */     
/* 153 */     if (logger.isEnabledFor(10))
/*     */     {
/* 155 */       long elapsed = System.currentTimeMillis() - start;
/* 156 */       logger.debug("Waited for notifications " + elapsed + " ms");
/*     */     }
/*     */     
/* 159 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TargetedNotification[] filterNotifications(TargetedNotification[] notifications)
/*     */   {
/* 171 */     return notifications;
/*     */   }
/*     */   
/*     */   private void addNotification(Integer id, Notification notification)
/*     */   {
/* 176 */     this.buffer.add(new TargetedNotification(notification, id));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 181 */   protected Logger getLogger() { return Log.getLogger(getClass().getName()); }
/*     */   
/*     */   private class ServerListener implements NotificationListener {
/* 184 */     ServerListener(DefaultRemoteNotificationServerHandler.1 x1) { this(); }
/*     */     
/*     */     public void handleNotification(Notification notification, Object handback)
/*     */     {
/* 188 */       Integer id = (Integer)handback;
/* 189 */       DefaultRemoteNotificationServerHandler.this.addNotification(id, notification); }
/*     */     
/*     */     private ServerListener() {} }
/*     */   
/* 193 */   private class NotificationBuffer { NotificationBuffer(Map x1, DefaultRemoteNotificationServerHandler.1 x2) { this(x1); }
/*     */     
/* 195 */     private final List notifications = new LinkedList();
/*     */     private int maxCapacity;
/*     */     private int purgeDistance;
/*     */     private long firstSequence;
/*     */     private long lastSequence;
/* 200 */     private long lowestExpectedSequence = -1L;
/*     */     
/*     */     private NotificationBuffer(Map environment)
/*     */     {
/* 204 */       if (environment != null)
/*     */       {
/*     */         try
/*     */         {
/* 208 */           this.maxCapacity = ((Integer)environment.get("jmx.remote.x.buffer.size")).intValue();
/*     */         }
/*     */         catch (Exception ignored) {}
/*     */         
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 216 */           this.purgeDistance = ((Integer)environment.get("jmx.remote.x.notification.purge.distance")).intValue();
/*     */         }
/*     */         catch (Exception ignored) {}
/*     */       }
/*     */       
/*     */ 
/* 222 */       if (this.maxCapacity <= 0) this.maxCapacity = 1024;
/* 223 */       if (this.purgeDistance <= 0) { this.purgeDistance = 128;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void add(TargetedNotification notification)
/*     */     {
/* 236 */       Logger logger = DefaultRemoteNotificationServerHandler.this.getLogger();
/* 237 */       synchronized (this)
/*     */       {
/* 239 */         if (this.notifications.size() == this.maxCapacity)
/*     */         {
/* 241 */           if (logger.isEnabledFor(10)) logger.debug("Notification buffer full: " + this);
/* 242 */           removeRange(0, 1);
/*     */         }
/* 244 */         this.notifications.add(notification);
/* 245 */         this.lastSequence += 1L;
/* 246 */         if (logger.isEnabledFor(10)) logger.debug("Notification added to buffer: " + this);
/* 247 */         notifyAll();
/*     */       }
/*     */     }
/*     */     
/*     */     private void removeRange(int start, int end)
/*     */     {
/* 253 */       synchronized (this)
/*     */       {
/* 255 */         this.notifications.subList(start, end).clear();
/* 256 */         this.firstSequence += end - start;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private NotificationResult getNotifications(long sequenceNumber, int maxNotifications, long timeout)
/*     */     {
/* 278 */       Logger logger = DefaultRemoteNotificationServerHandler.this.getLogger();
/* 279 */       synchronized (this)
/*     */       {
/* 281 */         NotificationResult result = null;
/* 282 */         int size = 0;
/* 283 */         if (sequenceNumber < 0L)
/*     */         {
/*     */ 
/* 286 */           long sequence = getLastSequenceNumber();
/* 287 */           size = new Long(sequence + 1L).intValue();
/* 288 */           result = new NotificationResult(getFirstSequenceNumber(), sequence, new TargetedNotification[0]);
/* 289 */           if (this.lowestExpectedSequence < 0L) this.lowestExpectedSequence = sequence;
/* 290 */           if (logger.isEnabledFor(10)) logger.debug("First fetchNotification call: " + this + ", returning " + result);
/*     */         }
/*     */         else
/*     */         {
/* 294 */           long firstSequence = getFirstSequenceNumber();
/*     */           
/* 296 */           int losts = 0;
/* 297 */           int start = new Long(sequenceNumber - firstSequence).intValue();
/*     */           
/*     */ 
/*     */ 
/* 301 */           if (start < 0)
/*     */           {
/* 303 */             losts = -start;
/* 304 */             start = 0;
/*     */           }
/*     */           
/* 307 */           List sublist = null;
/* 308 */           boolean send = false;
/* 309 */           while (size == 0)
/*     */           {
/* 311 */             int end = this.notifications.size();
/* 312 */             if (end - start > maxNotifications) { end = start + maxNotifications;
/*     */             }
/* 314 */             sublist = this.notifications.subList(start, end);
/* 315 */             size = sublist.size();
/*     */             
/* 317 */             if ((DefaultRemoteNotificationServerHandler.this.closed) || (send))
/*     */               break;
/* 319 */             if (size == 0)
/*     */             {
/* 321 */               if (timeout <= 0L) break;
/* 322 */               if (logger.isEnabledFor(10)) { logger.debug("No notifications to send, waiting " + timeout + " ms");
/*     */               }
/*     */               
/*     */ 
/*     */ 
/* 327 */               send = DefaultRemoteNotificationServerHandler.this.waitForNotifications(this, timeout);
/*     */             }
/*     */           }
/*     */           
/* 331 */           TargetedNotification[] notifications = (TargetedNotification[])sublist.toArray(new TargetedNotification[size]);
/* 332 */           notifications = DefaultRemoteNotificationServerHandler.this.filterNotifications(notifications);
/* 333 */           result = new NotificationResult(firstSequence, sequenceNumber + losts + size, notifications);
/* 334 */           if (logger.isEnabledFor(10)) { logger.debug("Non-first fetchNotification call: " + this + ", returning " + result);
/*     */           }
/* 336 */           int purged = purgeNotifications(sequenceNumber, size);
/* 337 */           if (logger.isEnabledFor(10)) logger.debug("Purged " + purged + " notifications: " + this);
/*     */         }
/* 339 */         return result;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private int purgeNotifications(long sequenceNumber, int size)
/*     */     {
/* 360 */       int result = 0;
/* 361 */       synchronized (this)
/*     */       {
/* 363 */         if (sequenceNumber <= this.lowestExpectedSequence)
/*     */         {
/* 365 */           long lowest = Math.min(this.lowestExpectedSequence, sequenceNumber);
/*     */           
/* 367 */           long firstSequence = getFirstSequenceNumber();
/* 368 */           if (lowest - firstSequence > this.purgeDistance)
/*     */           {
/*     */ 
/* 371 */             int purgeSize = this.purgeDistance >> 1;
/* 372 */             removeRange(0, purgeSize);
/* 373 */             result = purgeSize;
/*     */           }
/*     */           
/* 376 */           long expected = Math.max(sequenceNumber + size, firstSequence);
/* 377 */           this.lowestExpectedSequence = expected;
/*     */         }
/*     */       }
/* 380 */       return result;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 385 */       StringBuffer buffer = new StringBuffer("NotificationBuffer@");
/* 386 */       buffer.append(Integer.toHexString(hashCode())).append("[");
/* 387 */       buffer.append("first=").append(getFirstSequenceNumber()).append(", ");
/* 388 */       buffer.append("last=").append(getLastSequenceNumber()).append(", ");
/* 389 */       buffer.append("size=").append(getSize()).append(", ");
/* 390 */       buffer.append("lowestExpected=").append(this.lowestExpectedSequence).append(", ");
/* 391 */       buffer.append("maxCapacity=").append(this.maxCapacity).append(", ");
/* 392 */       buffer.append("purgeDistance=").append(this.purgeDistance).append("]");
/* 393 */       return buffer.toString();
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     private int getSize()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: dup
/*     */       //   2: astore_1
/*     */       //   3: monitorenter
/*     */       //   4: aload_0
/*     */       //   5: getfield 8	mx4j/remote/DefaultRemoteNotificationServerHandler$NotificationBuffer:notifications	Ljava/util/List;
/*     */       //   8: invokeinterface 20 1 0
/*     */       //   13: aload_1
/*     */       //   14: monitorexit
/*     */       //   15: ireturn
/*     */       //   16: astore_2
/*     */       //   17: aload_1
/*     */       //   18: monitorexit
/*     */       //   19: aload_2
/*     */       //   20: athrow
/*     */       // Line number table:
/*     */       //   Java source line #228	-> byte code offset #0
/*     */       //   Java source line #230	-> byte code offset #4
/*     */       //   Java source line #231	-> byte code offset #16
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	21	0	this	NotificationBuffer
/*     */       //   2	16	1	Ljava/lang/Object;	Object
/*     */       //   16	4	2	localObject1	Object
/*     */       // Exception table:
/*     */       //   from	to	target	type
/*     */       //   4	15	16	finally
/*     */       //   16	19	16	finally
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     private long getFirstSequenceNumber()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: dup
/*     */       //   2: astore_1
/*     */       //   3: monitorenter
/*     */       //   4: aload_0
/*     */       //   5: getfield 37	mx4j/remote/DefaultRemoteNotificationServerHandler$NotificationBuffer:firstSequence	J
/*     */       //   8: aload_1
/*     */       //   9: monitorexit
/*     */       //   10: lreturn
/*     */       //   11: astore_2
/*     */       //   12: aload_1
/*     */       //   13: monitorexit
/*     */       //   14: aload_2
/*     */       //   15: athrow
/*     */       // Line number table:
/*     */       //   Java source line #262	-> byte code offset #0
/*     */       //   Java source line #264	-> byte code offset #4
/*     */       //   Java source line #265	-> byte code offset #11
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	16	0	this	NotificationBuffer
/*     */       //   2	11	1	Ljava/lang/Object;	Object
/*     */       //   11	4	2	localObject1	Object
/*     */       // Exception table:
/*     */       //   from	to	target	type
/*     */       //   4	10	11	finally
/*     */       //   11	14	11	finally
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     private long getLastSequenceNumber()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: dup
/*     */       //   2: astore_1
/*     */       //   3: monitorenter
/*     */       //   4: aload_0
/*     */       //   5: getfield 32	mx4j/remote/DefaultRemoteNotificationServerHandler$NotificationBuffer:lastSequence	J
/*     */       //   8: aload_1
/*     */       //   9: monitorexit
/*     */       //   10: lreturn
/*     */       //   11: astore_2
/*     */       //   12: aload_1
/*     */       //   13: monitorexit
/*     */       //   14: aload_2
/*     */       //   15: athrow
/*     */       // Line number table:
/*     */       //   Java source line #270	-> byte code offset #0
/*     */       //   Java source line #272	-> byte code offset #4
/*     */       //   Java source line #273	-> byte code offset #11
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	16	0	this	NotificationBuffer
/*     */       //   2	11	1	Ljava/lang/Object;	Object
/*     */       //   11	4	2	localObject1	Object
/*     */       // Exception table:
/*     */       //   from	to	target	type
/*     */       //   4	10	11	finally
/*     */       //   11	14	11	finally
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/remote/DefaultRemoteNotificationServerHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */