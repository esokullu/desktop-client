/*    */ package mx4j.log;
/*    */ 
/*    */ import org.apache.log4j.Level;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Log4JLogger
/*    */   extends Logger
/*    */ {
/*    */   private org.apache.log4j.Logger m_logger;
/*    */   
/*    */   protected void setCategory(String category)
/*    */   {
/* 34 */     super.setCategory(category);
/* 35 */     this.m_logger = org.apache.log4j.Logger.getLogger(getCategory());
/*    */   }
/*    */   
/*    */ 
/*    */   protected void log(int priority, Object message, Throwable t)
/*    */   {
/* 41 */     Level l = convertPriority(priority);
/* 42 */     this.m_logger.log(l, message, t);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Level convertPriority(int mx4jPriority)
/*    */   {
/* 50 */     Level log4jPriority = Level.DEBUG;
/* 51 */     switch (mx4jPriority)
/*    */     {
/*    */     case 50: 
/* 54 */       log4jPriority = Level.FATAL;
/* 55 */       break;
/*    */     case 40: 
/* 57 */       log4jPriority = Level.ERROR;
/* 58 */       break;
/*    */     case 30: 
/* 60 */       log4jPriority = Level.WARN;
/* 61 */       break;
/*    */     case 20: 
/* 63 */       log4jPriority = Level.INFO;
/* 64 */       break;
/*    */     case 10: 
/* 66 */       log4jPriority = Level.DEBUG;
/* 67 */       break;
/*    */     case 0: 
/* 69 */       log4jPriority = Level.DEBUG;
/* 70 */       break;
/*    */     default: 
/* 72 */       log4jPriority = Level.INFO;
/*    */     }
/*    */     
/* 75 */     return log4jPriority;
/*    */   }
/*    */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/log/Log4JLogger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */