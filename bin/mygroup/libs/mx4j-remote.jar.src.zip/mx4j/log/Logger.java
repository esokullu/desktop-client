/*     */ package mx4j.log;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Logger
/*     */ {
/*     */   public static final int TRACE = 0;
/*     */   public static final int DEBUG = 10;
/*     */   public static final int INFO = 20;
/*     */   public static final int WARN = 30;
/*     */   public static final int ERROR = 40;
/*     */   public static final int FATAL = 50;
/*  25 */   private int m_priority = 30;
/*     */   
/*     */ 
/*     */   private String m_category;
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPriority(int priority)
/*     */   {
/*  34 */     this.m_priority = priority;
/*     */   }
/*     */   
/*     */   public int getPriority()
/*     */   {
/*  39 */     return this.m_priority;
/*     */   }
/*     */   
/*     */   public String getCategory()
/*     */   {
/*  44 */     return this.m_category;
/*     */   }
/*     */   
/*     */   protected void setCategory(String category)
/*     */   {
/*  49 */     this.m_category = category;
/*     */   }
/*     */   
/*     */   public final boolean isEnabledFor(int priority)
/*     */   {
/*  54 */     return priority >= getPriority();
/*     */   }
/*     */   
/*     */   public final void fatal(Object message)
/*     */   {
/*  59 */     log(50, message, null);
/*     */   }
/*     */   
/*     */   public final void fatal(Object message, Throwable t)
/*     */   {
/*  64 */     log(50, message, t);
/*     */   }
/*     */   
/*     */   public final void error(Object message)
/*     */   {
/*  69 */     log(40, message, null);
/*     */   }
/*     */   
/*     */   public final void error(Object message, Throwable t)
/*     */   {
/*  74 */     log(40, message, t);
/*     */   }
/*     */   
/*     */   public final void warn(Object message)
/*     */   {
/*  79 */     log(30, message, null);
/*     */   }
/*     */   
/*     */   public final void warn(Object message, Throwable t)
/*     */   {
/*  84 */     log(30, message, t);
/*     */   }
/*     */   
/*     */   public final void info(Object message)
/*     */   {
/*  89 */     log(20, message, null);
/*     */   }
/*     */   
/*     */   public final void info(Object message, Throwable t)
/*     */   {
/*  94 */     log(20, message, t);
/*     */   }
/*     */   
/*     */   public final void debug(Object message)
/*     */   {
/*  99 */     log(10, message, null);
/*     */   }
/*     */   
/*     */   public final void debug(Object message, Throwable t)
/*     */   {
/* 104 */     log(10, message, t);
/*     */   }
/*     */   
/*     */   public final void trace(Object message)
/*     */   {
/* 109 */     log(0, message, null);
/*     */   }
/*     */   
/*     */   public final void trace(Object message, Throwable t)
/*     */   {
/* 114 */     log(0, message, t);
/*     */   }
/*     */   
/*     */   protected void log(int priority, Object message, Throwable t)
/*     */   {
/* 119 */     if (isEnabledFor(priority))
/*     */     {
/* 121 */       System.out.println(message);
/* 122 */       if (t != null)
/*     */       {
/* 124 */         t.printStackTrace(System.out);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/log/Logger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */