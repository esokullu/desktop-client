package mx4j.log;

import javax.management.ListenerNotFoundException;
import javax.management.NotificationFilter;
import javax.management.NotificationListener;

public abstract interface LoggerBroadcasterMBean
{
  public abstract void addNotificationListener(NotificationListener paramNotificationListener, NotificationFilter paramNotificationFilter, Object paramObject);
  
  public abstract void removeNotificationListener(NotificationListener paramNotificationListener, NotificationFilter paramNotificationFilter, Object paramObject)
    throws ListenerNotFoundException;
  
  public abstract void start();
  
  public abstract void start(String paramString);
  
  public abstract void stop();
  
  public abstract void stop(String paramString);
}


/* Location:              /Users/groups/Downloads/MyGroupApp.jar!/mygroup/libs/mx4j-remote.jar!/mx4j/log/LoggerBroadcasterMBean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */